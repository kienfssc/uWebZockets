#!/bin/sh
set -u
expected_commit=$1
evidence=/tmp/uwz-m1-final-verification
mkdir -p "$evidence"
git rev-parse HEAD > "$evidence/source_commit.txt"
test "$(cat "$evidence/source_commit.txt")" = "$expected_commit" || exit 2
git diff --exit-code > "$evidence/source_diff.txt" || exit 2
zig version > "$evidence/zig_version.txt" || exit 2
test "$(cat "$evidence/zig_version.txt")" = 0.16.0 || exit 2
sha256sum flake.lock > "$evidence/flake_lock.sha256"
export ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache
status=0
run_gate() {
    gate_name=$1
    shift
    printf '%s\n' "$*" > "$evidence/$gate_name.command.txt"
    "$@" > "$evidence/$gate_name.log" 2>&1
    gate_status=$?
    printf '%s\n' "$gate_status" > "$evidence/$gate_name.exit.txt"
    printf '%s exit %s\n' "$gate_name" "$gate_status"
    if [ "$gate_status" -ne 0 ]; then status=1; fi
}
run_gate build zig build -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate sanitizer zig build test -Dsanitize=true -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate release_safe zig build test-compile -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate release_fast zig build test-compile -Doptimize=ReleaseFast -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate windows zig build test-compile -Dtarget=x86_64-windows-gnu -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate macos_arm64 zig build test-compile -Dtarget=aarch64-macos -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate fuzz zig build fuzz --fuzz=100K -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache
run_gate oss_fuzz_smoke zig build oss-fuzz-smoke -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate msan zig build msan -Dmemory-sanitize=true -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate package sh -c 'cd tests/package_consumer && zig build check -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1-final-package --summary all'
run_gate package_paths sh scripts/check_package_paths.sh
printf '%s\n' "$status" > "$evidence/matrix.exit.txt"
exit "$status"
