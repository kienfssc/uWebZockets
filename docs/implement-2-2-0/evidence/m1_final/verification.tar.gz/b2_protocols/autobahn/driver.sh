#!/bin/bash
set -u
worktree=/home/codespace/.codex/worktrees/05f7/uWebZockets
saved=/tmp/uwz-m1-autobahn-saved
evidence=/tmp/uwz-m1-final-protocols/autobahn
expected=b2d2acb570eb0eae89bdb47e35889d1aa3264a6a
mkdir -p "$evidence" "$saved/zig-out/bin"
test "$(cat /tmp/uwz-m1-final-verification/build.exit.txt)" = 0 || exit 2
test "$(git -C "$worktree" rev-parse HEAD)" = "$expected" || exit 2
test "$(git -C "$saved" rev-parse HEAD)" = "$expected" || exit 2
git -C "$saved" status --porcelain > "$evidence/source_before.txt" || exit 2
test ! -s "$evidence/source_before.txt" || exit 2
cp "$worktree/zig-out/bin/autobahn_server" "$saved/zig-out/bin/autobahn_server" || exit 2
sha256sum "$worktree/zig-out/bin/autobahn_server" "$saved/zig-out/bin/autobahn_server" "$saved/tests/autobahn/server_test.js" "$saved/tests/autobahn/baseline.json" "$saved/tests/autobahn/fuzzingclient.json" > "$evidence/inputs.sha256"
printf '%s\n' "$expected" > "$evidence/source_commit.txt"
/tmp/uwz-deno-2.9.4/deno --version > "$evidence/deno_version.txt"
docker image inspect --format '{{.Id}} {{join .RepoDigests " "}}' crossbario/autobahn-testsuite:0.8.2@sha256:519915fb568b04c9383f70a1c405ae3ff44ab9e35835b085239c258b6fac3074 > "$evidence/image.txt" || exit 2
ss -H -ltn 'sport = :9001' > "$evidence/listener_before.txt" || exit 2
test ! -s "$evidence/listener_before.txt" || exit 2
cd "$saved" || exit 2
printf '%s\n' '/tmp/uwz-deno-2.9.4/deno run --no-prompt --allow-net=127.0.0.1:9001 --allow-read=tests/autobahn,zig-out/bin --allow-run=docker,/tmp/uwz-m1-autobahn-saved/zig-out/bin/autobahn_server --allow-write=tests/autobahn/reports tests/autobahn/server_test.js' > "$evidence/runner.command.txt"
/tmp/uwz-deno-2.9.4/deno run --no-prompt --allow-net=127.0.0.1:9001 --allow-read=tests/autobahn,zig-out/bin --allow-run=docker,/tmp/uwz-m1-autobahn-saved/zig-out/bin/autobahn_server --allow-write=tests/autobahn/reports tests/autobahn/server_test.js > "$evidence/runner.log" 2>&1
result=$?
printf '%s\n' "$result" > "$evidence/runner.exit.txt"
ss -H -ltn 'sport = :9001' > "$evidence/listener_after.txt" || result=1
test ! -s "$evidence/listener_after.txt" || result=1
git status --porcelain > "$evidence/source_after.txt" || result=1
test ! -s "$evidence/source_after.txt" || result=1
printf '%s\n' "$result" > "$evidence/gate.exit.txt"
exit "$result"
