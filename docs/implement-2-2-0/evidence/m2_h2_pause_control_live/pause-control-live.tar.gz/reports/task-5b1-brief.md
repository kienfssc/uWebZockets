# Task 5b-1 Stage A: prepare pause/FIFO and public-control proof

Read this first: exact requirements for this assignment. Root adopted the scoped
architecture in task-5b-architecture.md; read its Next slice section for rationale
and located source references. Do not read/reimplement the entire full plan.

Own ONLY new .uwz-work/evidence/h2-streaming/integration-owned/pause-control/
test-only sources, commands, source/build/review inventories and this task's
report. Use focused profile/state modules if justified; do not make a generic
framework. Reuse the core's reviewed process/identity/cleanup logic without
weakening it. Preserve all original core sources/reviews/runs and public docs.
You are not alone: no reverts, Root/production edits, subagents, commits, refs,
pushes, fetches, package installs or external CLI.

Root HEAD8ab099d243a874197c0a65f2beb8e59e267f4226 is clean/pushed. Actual production
input stays immutable /tmp/uwz-task4d-fix1-frozen,1031 files,
fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de.
Use exact reviewed c22393-file override, stable r2 C bindings and six static
libraries. Client42-file0f85bd19 and helper07a5201 unchanged. Revalidate hashes;
do not restore/rebuild/retest completed prerequisites while their inputs exist.

Public configured-App fixture and profile capacities remain exactly core's:
connections8, streaming on, requestline512, header4096/count80, H1body256,
H2body4096, encodedheader8192, responseheaders4096/count32, captures24,
writequeue65536, unrelated features/devlog off. Requeststride5888/H2stride281200/
slab4098304/router884352. Use Server.preset(...).build_https, real route_body and
get_context, no stand-in server or private Session/transport mutation.

Supported selectable IDs ONLY partial_pause,final_pause,begin_pause_empty,
control_rules,shutdown_idle (must be last). The last repeats only normal teardown,
not old core uploads. Manifest distinguishes prior5core proof from supported new
cases and keeps every remaining full5b/5c case explicitly planned/unimplemented;
unsupported case requests fail rather than skip. StageA is preparation/compile
only, not a live result. No endpoint/server/client/native/fixture execution or
certificate command is authorized, including --help on the fixture binary.

Ruling after the initial report: selectable means any unique subset ending in
shutdown_idle, not a required fixed full list. Compute expected record set and
totals from selected IDs: each pause ID adds1,control_rules adds2,shutdown_idle
adds0. Full selection still requires5/5/0/0/0; idle-only expects0. Every unselected
record must remain untouched. This changes no assertion for the full matrix.

Use two reusable sink slots, /upload/:tag limit100000000/quota2 and a separate
fixed table of five accepted result records. Their exact five tags can be fixed
and validated; record begin attempts/successes, ends, cancels, active, accepted
bytes, incremental hash, chunk count/maxspan, paused and control diagnostics.
Historical result totals survive slot reuse and remain valid through deinit.
Preserve stable definitions/contexts/App/result storage. Never retain callback
Request/StreamingRequest/Response pointers, view arrays, or chunk slices.

Ordinary owning-loop routes provide per-tag status, resume, stale resume/cancel.
Freeze exact200/ok on successful resume and200/literal error-name on expected
refusal. Copy control before calling it; resume may synchronously end/retire the
binding. After it returns inspect stable result storage and the control route's
fresh Response only. Status finalizes a COPY of hash state, never active state.

P(n) uses unchanged helper.payload_block(n,offset,length), independently hashed
client-side in <=8192 spans. For32 it is bytes1..10+final22-byte marker; zero SHA
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855.

partial_pause: total12289; one8192-byte DATA payload withoutEOF; same-connection
status after DATA must prove accepted7,begin1,end0,cancel0,paused and no upload
final. Send4097 remaining bytes+EOF and same-connection status; same predicate.
Public resume200/ok completes upload200/12289/H(P12289),1/1/0,inactive. Do not
assume callback/TLS span is8192: accept ready until cumulative7, then pause at7.
Hash only actual returned accepted prefix. No guessed sleep or callback count.

final_pause: P32+EOF, same-connection status proves accepted32/paused/1/0/0/no
upload final; resume with no additional upload bytes completes200/32/H32/1/1/0.

begin_pause_empty: returnpaused in begin, explicit empty DATAEOF, same-connection
status proves0accepted/0chunks/1/0/0; resume completes200/0/emptySHA/1/1/0.

control_rules: start ready tag1, resume beforeDATA gives exactBodyNotPaused and
no mutation; finishP32 normally. Start different ready tag2 while calling old
tag1 stale resume+cancel; each exactBodyControlExpired, no mutation of either.
FinishP32 normally and repeat stale checks after terminal. These two requests
plus three pause cases make FIVE successful begins/ends,0cancels/failed begins.

In actual begin and chunk callbacks, call the copied public token's resume and
cancel; each must produce exactBodyCallbackActive without mutation. In each
terminal callback both must produce BodyControlExpired. These are ordinary
public API validations, not fabricated callbacks/completions or native error
injection. Record all outcomes and counts; any unexpected success/error fails.
No native runtime is authorized in StageA to check these; source/compile first.

Client same-connection HEADERS status requests after DATA/EOF are parsing
barriers. Wait for explicit record predicates within absolute30s case deadlines,
not sleeps/packetization. Keep positive raw-RST rejection and all bounded metadata/
response/event handling from fix1. No informational/trailers/GOAWAY/prematureEOF.
Healthy request after each completed case, no outstanding stream/binding at idle
shutdown. Post-deinit records must assert5begins/5ends/0cancels/0failed/0active,
all individual count/hash/control results preserved. Do not infer these from
only pre-response counts or aggregate active flags.

Keep process controls from core: fixed127.0.0.1:28443, localhost TLS1.3/h2 and
ephemeral certificate fingerprint; direct child PID/start/nonce/listener inode
before health; deadlines15ready/30ordinary/900total/15graceful, no retry/fallback;
combined output continuously bounded65536; independent cleanup actions, owned
reaping and key deletion; forced/error cleanup never success. Explicit --run,
exact executing runner and explicitly loaded wire/helper path+hash, Python-B-S
and exact package/helper PYTHONPATH; fresh private/tmp runtime path. Compilation
does not authorize execution. A later manifest binds exact frozen sources,
binary/compiler/library/interpreter/client/tool inputs and full inventories.

StageA allowed: source editing in owned directory; Debug and ReleaseSafe compile
only with Zig0.16 fixed compiler,-j2,/tmp cache/output; AST-only syntax/graph,
profile Zig formatting. Pure deterministic codec/data helper checks are allowed
if meaningful, never fake sockets/child scheduling/native callbacks. Do not
manufacture regression red by running an unsupported old case or fake transport.
No full central runtime, fault/race/cancellation schedule/resource/leak/invalid-fd/
kernel-error/injected-completion/panic probes, stopped experiments or denied
socket cases. All native/live acceptance requires later independent review and
Root precise authorization. Route production defects to owner; don't fix them.

Freeze new reviewed sources under a distinct/tmp path; bind exact inputs,
source/client/override/frozen inventories, both build results/logs/binary hashes
and actual optimization modes. Preserve intermediate compile failures honestly.
Compiler caches may be shared; source/binary/log outputs must be verifiable.
All heavy copies/caches/binaries/IR/graphs stay/tmp; disk4.5GiBworkspace free.

Report .superpowers/sdd/h2_streaming_plan/task-5b1-report.md with status, changed
files/hashes, exact commands/raw outcomes, before/after input identity, supported
and remaining cases, source locations, capacities/bounds and unresolved limits.
Never claim unrun native/process/physical lifetime/full/platform gates passed.
Return concise status, report path, compile summary and concerns. No commits.
