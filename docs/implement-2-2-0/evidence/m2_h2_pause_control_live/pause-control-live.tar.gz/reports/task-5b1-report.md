# Task 5b-1 Stage A: prepared, independent review required

The test-only source is prepared and compiled, not live-validated. No fixture, client, server, socket, certificate command, native callback, or binary `--help` was executed. Neither compiler success nor the offline checks establish physical lifetime, protocol behavior, or acceptance of these cases. Root must obtain independent source review and separately authorize any exact live run. The earlier core evidence and production inputs were not edited.

Working artifacts are under `.uwz-work/evidence/h2-streaming/integration-owned/pause-control/`. The final frozen source package is `/tmp/uwz-task5b1-source-frozen-v3`. Its review input manifest is `pause-control/review-manifest.json`, SHA-256 `6144be46524ed740a6a378d539ebea34b8165b7cbc83852812c2a30234901f8d`. This manifest is not an independent review. The earlier prepared revisions and manifests remain at `/tmp/uwz-task5b1-source-frozen`, `/tmp/uwz-task5b1-source-frozen-v2`, `review-manifest-v1.json`, and `review-manifest-v2.json`; the preceding report is preserved as `report-v2-preimage.md`.

| Frozen source | SHA-256 |
| --- | --- |
| profile.zig | `ffc36badc79a2d245bb5e878d1acb7236928e48ffca806cf00e4550518187d6f` |
| run_live.py | `466352f91def7a942858d665ae65997d1f820c5d32ed5a9b6d9b0893e1aefdb0` |
| wire.py | `8aff857fbdbe36a0b483c79cb52faa0670494ca976fdfc06552627e97c3ba78c` |
| prepare.py | `3d944c3f70e123386177b070230df2b09a16f10184b9ded272de95a5bb25829e` |
| case_manifest.json | `fb8b290c399c57ef857d06cf1b6b44c0a4879c3ff8c66a8e14cf8864288186ab` |

The profile retains the core configuration: eight connections, streaming on, request line 512, headers 4096/count 80, H1 body 256, H2 body 4096, encoded header 8192, response headers 4096/count 32, captures 24, write queue 65536, development log off; the prior compile diagnostic established request stride 5888, H2 stride 281200, slab 4098304, router 884352. It uses the configured public HTTPS App, two reusable sink slots, a quota-two limit-100000000 body route, and five persistent records. The source contains public status and copied-token control routes, copied-hash status, callback and terminal diagnostics, accepted-prefix hashing, and post-deinit record emission. The runner expresses the two same-connection barriers for the 12289-byte partial pause, final-byte and empty-begin pause, ready and stale control checks, and a health request after each case. It inherits the core raw-RST rejection, bounded response/event and process cleanup logic. These are source assertions awaiting review and execution.

The five named supported cases are `partial_pause`, `final_pause`, `begin_pause_empty`, `control_rules`, `shutdown_idle`; the runner accepts unique selected subsets in any order with `shutdown_idle` last and rejects unsupported IDs. It computes the exact selected record set: one per pause case and two for `control_rules`. It checks every unused record against the untouched initial state and checks selected aggregate begin/end/attempt counts, zero cancels, zero failed begins and zero active bindings. A full selection requires five successful begins and ends; idle-only requires zero. Post-deinit records must equal all pre-deinit results. The case manifest preserves the five prior core cases as prior proof and lists the remaining 5b/5c cases as planned, unimplemented; no prior upload is rerun by the new shutdown case.

Both final fixture builds used the fixed Zig 0.16 compiler, `-j2`, the coherent immutable production tree and shared existing per-mode compiler caches, with binaries in `/tmp`. The full compiler argv, input hashes and before/after trees are in `debug-v3.command.json`, `debug-v3.json`, `debug-v3-source-inputs.json`, `debug-v3-source-after.json`, and the corresponding `release-v3` records. Exact outer commands:

```sh
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/pause-control/prepare.py --optimization Debug --output /tmp/uwz-task5b1-debug5 --cache-root /tmp/uwz-task5a-debug --record debug-v3
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/pause-control/prepare.py --optimization ReleaseSafe --output /tmp/uwz-task5b1-release4 --cache-root /tmp/uwz-task5a-release --record release-v3
```

Each printed `Exit status: 0`; both raw compiler logs are empty, SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. Each record says `inputs_unchanged: true`. Debug binary SHA-256 `8dd68a9ee2d4a4eb55dbeca88cc84e871f95617365cd5ae6942a4c3ac041eeab`; ReleaseSafe binary SHA-256 `f553e8000d23347195611e241529c07e0b7158768638e35f8f36d7b52be06952`. Neither was executed.

The initial Debug compile exited 1: `no field named 'params' in struct 'http.request.Request'` at the two public route callbacks. The saved raw diagnostic is `debug-first.log`, SHA-256 `8f85b154ef2a9992b23734708d09f950c28582af2b7be56c3c9a1ba21405b2e0`. It was corrected to the public `get_param`; `debug-second` and `release-first` then succeeded on a superseded revision. The subsequent `debug-invariant` and `release-invariant` commands both exited 1 because the cancellation-invariant diagnostic referenced a missing `State.errors` field. Both raw logs have SHA-256 `4b143d037578a381a707ec3676d4fc87368fc2033d3f17497ef3aeef4e7ddac`; adding that field fixed the diagnostic. All records and logs remain in the owned directory. The cancellation callback now increments this independent error counter if its expected slot record is absent, and the shutdown marker requires it to be zero.

The exact freeze and final identity audit commands were:

```sh
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/pause-control/freeze-command.py
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/pause-control/audit-inputs.py
```

Both exited 0. Freeze raw output:

```text
prior manifest, trees and inputs unchanged
frozen source files: 5
review manifest sha256: 6144be46524ed740a6a378d539ebea34b8165b7cbc83852812c2a30234901f8d
```

Audit raw output:

```text
all bound tree inventories and inputs unchanged
tree counts: {"/tmp/uwz-h2-client-tooling/packages": 42, "/tmp/uwz-reviewed-libxev-c223-loop-callbacks": 93, "/tmp/uwz-task4d-fix1-frozen": 1031, "/tmp/uwz-task5a-fix1-frozen": 6, "/tmp/uwz-task5b1-source-frozen-v3": 5, "/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy": 14}
manifest sha256: 6144be46524ed740a6a378d539ebea34b8165b7cbc83852812c2a30234901f8d
```

The inherited manifest inventories and hashes the original six static libraries, stable r2 bindings, Zig compiler, client, helper, interpreter and tools as well as the production and override trees. The builds independently recorded production source digest before and after `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`; the inherited client digest is `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`, and helper SHA-256 is `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`. The new manifest binds both binary hashes and the complete new source inventory. The prior manifest and all its inventories were checked before freezing, and the new manifest and inventories were checked afterward.

Syntax and formatting checks:

```sh
/home/codespace/.python/current/bin/python3 -B -c 'import ast,pathlib; p=pathlib.Path("/tmp/uwz-task5b1-source-frozen-v3"); [ast.parse((p/f).read_text(),filename=f) for f in ("prepare.py","run_live.py","wire.py")]; print("frozen syntax OK")'
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check /tmp/uwz-task5b1-source-frozen-v3/profile.zig
```

Both exited 0; first output `frozen syntax OK`, second was empty. `graphify update /tmp/uwz-task5b1-graph-v3` on a final frozen scratch copy exited 0 and reported `84 nodes, 211 edges, 6 communities`; the workspace graph was not modified.

The following pure helper check used the unchanged helper, no socket or child:

```sh
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S -c 'import hashlib,h2_client; p=h2_client.payload_block(32,0,32); assert p == bytes(range(1,11))+h2_client.SENTINEL; assert hashlib.sha256(b"").hexdigest()=="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"; print("P32:",p.hex(),"SHA256:",hashlib.sha256(p).hexdigest()); print("empty SHA256:",hashlib.sha256(b"").hexdigest())'
```

Exit 0, raw output:

```text
P32: 0102030405060708090a66696e616c2d75706c6f61642d73656e74696e656c21 SHA256: 7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5
empty SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
```

No full local matrix, sanitizer, compliance gate, platform gate, active shutdown, native fault/race or cancellation schedule, injected completion, physical lifetime, real client/server, or full milestone check was run. MSan was not run; it instruments the C boundary rather than Zig and cannot be combined with ASan. All later 5b/5c and original milestone gates remain open.

## Fix round 1: reject final response headers at pause barriers

The independently reported P2 is corrected in test-only source and awaits scoped re-review. A final `200` HEADERS frame without END_STREAM previously left `ended` false, so the v3 pause barrier could accept it. The shared pure `require_upload_pending` guard now rejects either an ended upload or any final response headers, and the actual barrier invokes that guard after each same-connection status response. This applies to both partial-pause barriers and the other pause cases. All other wire, lifecycle, count and status assertions are retained. The exact runner diff is `pause-control/fix1/run_live.diff`, SHA-256 `b6d165b3fcc15271344683e125158e3161806a5252920a39ebd8fb48a4b2d837`.

The original report preimage is `pause-control/fix1/report-preimage.md`, SHA-256 `5136ce0e7ad8db2193e7a81cb498cbe65bcc82092d466a39edebc1996107ad8a`. Frozen v3, its manifest, compile records, binaries and failure evidence remain unchanged. The new frozen package is `/tmp/uwz-task5b1-fix1-frozen` and new review manifest `pause-control/fix1/review-manifest.json` SHA-256 `ca20660a9356b4452bd4a4cede8d4ff4b4851e6ae49d41780d4c6c5d415ed86f`. This is a review input, not a review or runtime authorization.

| Frozen fix source | SHA-256 |
| --- | --- |
| run_live.py | `ddd7fb5403982a1fa2b056f1c173322f212fd662854749c83502d30a684b83cc` |
| offline_checks.py | `1944dd67a8e40cd784ce62bace1ae50baa98c2ecbbf9d6984ff0568b9609a6d2` |
| profile.zig | `ffc36badc79a2d245bb5e878d1acb7236928e48ffca806cf00e4550518187d6f` |
| prepare.py | `3d944c3f70e123386177b070230df2b09a16f10184b9ded272de95a5bb25829e` |
| wire.py | `8aff857fbdbe36a0b483c79cb52faa0670494ca976fdfc06552627e97c3ba78c` |
| case_manifest.json | `fb8b290c399c57ef857d06cf1b6b44c0a4879c3ff8c66a8e14cf8864288186ab` |

The covering check uses the actual frozen runner guard and wire decoder, with real pinned h2 codec-generated frames in memory. It executes no socket, fixture, endpoint, native callback or completion:

```sh
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5b1-fix1-frozen/offline_checks.py
```

Exit 0, raw output:

```text
registered upload with no response: accepted
decoded final 200 HEADERS without END_STREAM: rejected
decoded END_STREAM: rejected
```

The original v3 barrier has no separable pure guard, so no meaningful original behavioral red was executed under the allowed scope. The old source's `not ended` check and the decoded `headers != None, ended == false` state establish the review finding by inspection; this is not an observed old live failure. No fake socket, status call or completion was used.

The identity and recipe proof was run with:

```sh
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/pause-control/fix1/freeze.py
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/pause-control/fix1/audit.py
```

Both exited 0. Freeze raw output:

```text
v3 manifest, all bound trees and inputs unchanged
both recipes, profiles, inputs and actual binaries match v3
fix source files: 6
fix manifest sha256: ca20660a9356b4452bd4a4cede8d4ff4b4851e6ae49d41780d4c6c5d415ed86f
```

Audit raw output:

```text
all fix and v3 trees, recipes, build records, binaries and bound inputs unchanged
manifest sha256: ca20660a9356b4452bd4a4cede8d4ff4b4851e6ae49d41780d4c6c5d415ed86f
```

The new manifest binds both v3 compiler command and result records, complete source inventories, logs, both binaries and every inherited input. The proof compares each command's exact argv and optimization with its successful result, checks unchanged before/after compiler inputs, profile and `prepare.py`, checks the unchanged source digest, and hashes each actual binary against its build record and v3 manifest. The Debug and ReleaseSafe binaries remain respectively `8dd68a9ee2d4a4eb55dbeca88cc84e871f95617365cd5ae6942a4c3ac041eeab` and `f553e8000d23347195611e241529c07e0b7158768638e35f8f36d7b52be06952`. No compilation was repeated.

Additional checks on the exact frozen source:

```sh
/home/codespace/.python/current/bin/python3 -B -c 'import ast,pathlib; p=pathlib.Path("/tmp/uwz-task5b1-fix1-frozen"); [ast.parse((p/f).read_text(),filename=f) for f in ("prepare.py","run_live.py","wire.py","offline_checks.py")]; print("fix1 frozen syntax OK")'
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check /tmp/uwz-task5b1-fix1-frozen/profile.zig
graphify update /tmp/uwz-task5b1-fix1-graph
```

All exited 0. The syntax command printed `fix1 frozen syntax OK`; format output was empty. The isolated AST-only graph reported `92 nodes, 224 edges, 8 communities`. No network, client/server, certificate or fixture execution, native acceptance or full project gate occurred in this fix round. The prior Stage A limitations still apply.
