# Task 5b: owned H2 boundary and control coverage

Root adopts the source-backed read-only plan returned by architect_h2_live_plan.
The original task-5-plan.md and every Task5b/5c case remain binding. Task5a's
five positive core cases passed once; they were not repeated during planning.
Root HEAD8ab099d243a874197c0a65f2beb8e59e267f4226 is clean and pushed.

Production stays immutable at /tmp/uwz-task4d-fix1-frozen,1031 files,
fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de.
The c223 override, bindings, libraries, client/helper and profile capacities stay
unchanged. Verification owns separate test-only fixture/client preparation;
http_protocol guides framing and flow control, dx_router guides controls,
admission and metadata. Root owns reviews and later exact execution authorization.

## Ordered work

1. 5b-1: partial_pause, final_pause, begin_pause_empty and control_rules. Build
   stable per-request history, same-connection barriers and precise public-control
   assertions; positive streams still forbid all resets.
2. 5b-2: empty variants, exact/over limits, zero limits, Continue, quota and failed
   begin rollback. Add explicit informational/refusal expectations and recovery.
3. 5b-3: queued padding/trailers, legitimate credit exhaustion and concurrent
   routes. Track logical DATA separately from padding-inclusive flow bytes.
4. 5b-4: actual overflow headers/captures, metadata/helper refusals and any
   remaining control assertions. Producer-era metadata belongs to Task5c.

Each slice prepares and compiles its own frozen test package, then receives
independent review before Root separately authorizes a precise ordinary owned
run. No live action follows from this plan. Full5c and combined acceptance remain.

## Next slice: public pause and control seam

Use Server.preset(io,config).build_https and actual App.route_body/get_context
(builder41,62-68,383-389; App772-781,978-984). Add no production seam. Keep two
reusable sink slots and a separate fixed table of five accepted result records;
historical counts must survive slot reuse and deinit. Store copied BodyControls
in stable records and use ordinary owning-loop status/resume/stale-control routes.
Hash status through a copy of incremental state; never finalize the active hash.

Control is loop-confined and may release binding state synchronously
(request_body71-97; tcp660-674). Copy the token before resume, then inspect only
stable result records and the control route's own fresh Response. Retain no
callback-local Request/StreamingRequest/Response/view arrays or input spans.
Definitions, contexts, result records and App remain stable through deinit.

Same-connection status HEADERS follow the upload DATA/EOF. Completing that status
response proves the parser passed earlier frames before resume. Another
connection or guessed sleep is insufficient. Wait on explicit predicates within
absolute ordinary-case deadlines; do not assume TLS read or callback counts.

P(n) is the exact existing payload_block sequence for total n, independently
hashed by the client; zero is empty. For n32 it is bytes1..10 followed by the
22-byte final marker. Accept and hash only the returned prefix.

| Case | Before public resume | Final |
| --- | --- | --- |
| partial_pause | Send one8192-byte DATA frame withoutEOF, status barrier: accepted7, paused,1/0/0. Send4097 remaining bytes withEOF, second barrier: same counts and no upload final. | Resume200/ok;12289/H(P12289),1/1/0,inactive. |
| final_pause | Send32 bytes withEOF, barrier: accepted32,paused,1/0/0. | Resume without extra upload bytes;32/H(P32),1/1/0. |
| begin_pause_empty | Paused begin, explicit empty DATAEOF, barrier:0bytes/0chunks/1/0/0. | Resume;0/empty SHA,1/1/0. |
| control_rules | Ready request resume returns200/BodyNotPaused without mutation, then complete32. Start second differently tagged ready request; stale resume and cancel of first return200/BodyControlExpired without changing either request. | Both32/H(P32),1/1/0; stale calls remain expired after completion. |

Begin and chunk callbacks invoke public resume/cancel and require both exact
BodyCallbackActive. Terminal callback invokes both and requires BodyControlExpired.
Record exact diagnostic names/counts without changing real transitions. Generation
and terminal checks precede callback/readiness checks (request_body80-97), binding
generation invalidates before terminal callback and quota releases afterward
(request_body230-268; http2_upload201-220).

Expected aggregate5successful begins/5ends/0cancels/0failed begins/0active,
including post-deinit result totals. Positive responses forbid informational,
trailers, every raw reset, GOAWAY and earlyEOF. Require healthy progress after
each completed case and normal owned shutdown/exit0/reaping/no force.

Ruling:8192 describes the client's first DATA payload, not a promised TLS or sink
callback span. If a callback span ends before the cumulative seven-byte pause
threshold, accept it ready; pause exactly at cumulative7. This preserves exact
FIFO assertions without relying on packetization. Actual maximum span is recorded.

## Later required expectations

5b-2: limit32/quota1 and zero-limit/quota1 definitions, known final middleware
header and invocation counts. Empty forms200/0/no chunks; exact32 forms200/H32;
declared33+Expect413/no100/no begin; observed byte33 does not change accepted32
or hash and cancels body_too_large1/0/1. Zero declared1 refuses before begin;
first undeclared byte cancels without acceptance. Ready/paused Expect receives
exactly one100 before final; wait before DATA. Two held upload bindings cause
third503/no100/no begin. Failed application begin gives503/no cancel and later
admission succeeds. Source: body_admission33-80, http2_upload142-162,
server1637-1650. No weakened credit or informational claims.

Current positive wire rejects all RST and complete assumes200/no informational.
New refusal observer must permit only the expected stream's one NO_ERROR reset
after its complete final END_STREAM frame (server2086-2092), retain records
through a same-connection healthy barrier and observe raw frames even after h2
closes its stream. Count and retain informational status/headers within bounds.
Never globally ignore post-final resets.

5b-3: DATA pad_length7 spends payload+8 flow bytes (pinned h2 connection838-907).
Separate logical bytes, total flow bytes, connection/stream WINDOW_UPDATE and
accepted bytes/hash. Padding may be immediately refunded; queued payload credits
only after reclamation and partial queued prefixes may stay held. Do not require
frame counts, coalescing, exact deltas or closed-stream credit. Source:
server1596-1670,1732-1754;body_queue112-145;connection743-752.
For fresh begin-paused total65536 send exactly65535 legal DATA bytes withoutEOF;
status proves0accepted/0chunks/0end and client credit0. HEADERS-only health and
resume work; after legitimate WINDOW_UPDATE send final1 withEOF, expect200/H65536
and1/1/0. Never send over-window or enlarge server windows. Concurrent uploads
stay below shared exhaustion when asserting sibling DATA progress. Padded queued
DATA/trailerEOF preserves logical hash and unmerged initial metadata.

5b-4: at least65ordinary initial headers within80 and17captures within24, distinct
method/path/query/overflow values and conflicting trailer names. Begin/end compare
owned expectations; text/bytes empty; JSON/schema/detailed schema/form/multipart
exact BodyNotBuffered, detailed issue unchanged. Use fixed caller allocator;
do not substitute fixture parsing. Source: streaming_request31-97.

Task5c still owns producer reuse/output pressure/file/early final/public cancel/
peer reset/application errors/disconnect/>8reuse/active shutdown and full combined
matrix. All platform/full native/sanitizer/physical lifetime/genuine early data/
H3/multipart/adoption/original milestone gates remain open.
