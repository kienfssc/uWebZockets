# Read-only promotion preflight at 8ab099d

Source: completed architect_h2_live_plan read-only inspection. This records
preconditions, not adoption authorization or new semantic verification.

Root8ab099d243a874197c0a65f2beb8e59e267f4226 versus immutable fc69 candidate:
41 product paths,19modified/22new/0deleted;8176insertions/203deletions.
This is cumulative H1/TLS/H2 with H3 refusal groundwork, not H2-only.

Modified runtime13:
- src/client/client.zig,connection.zig
- src/core/loop.zig,tcp.zig,udp.zig
- src/http2/connection.zig,server.zig
- src/quic/engine.zig,stream.zig
- src/router/app.zig,builder.zig,config.zig,radix.zig

Modified verification6:
- src/test_support.zig
- src/tests/config_tests.zig,core_tests.zig,main.zig,tls_tests.zig
- tests/package_consumer/main.zig

New runtime8:
- src/core/http1_upload.zig,http1_upload_storage.zig,http2_upload.zig,
  tcp_http2_upload.zig,tcp_upload.zig
- src/http2/body_queue.zig,body_receive.zig
- src/router/body_admission.zig

New standalone support3:
- src/h2_width_support.zig,h3_width_support.zig,http1_admission_test_support.zig

New centralized tests11 under src/tests/:
body_app_tests.zig,body_h1_head_tests.zig,body_h2_refusal_tests.zig,
body_h2_width_tests.zig,body_h3_refusal_tests.zig,body_h3_width_tests.zig,
http1_upload_admission_tests.zig,http1_upload_driver_tests.zig,
http2_body_queue_tests.zig,http2_upload_driver_tests.zig,tcp_http2_upload_tests.zig.

builds/examples/fuzz/include/build.zig/allfourzonviews/flake.nix match.
Root-only tests/*/zig-pkg entries are untracked caches, not product deletions.

No accepted Root product change is reverted: timer3cc8f81 implementation matches
and core tests onlyadd; pureframing093ef45 and multipart0a26e8e/ec31328 code/fuzz/
registrations/consumers survive; contracts1ff7873/guards00c8564 rootexports,
request_body/streaming_request/response match. Never replace the full Root tree:
Root documentation/evidence/dependency adoption and later edits remain authoritative.

Promotion blockers:
1. Candidate is tested with local reviewed c22393-file override, while ordinary
   manifests still pin c49f. Maintained publication, protected integration ancestry,
   ledger and synchronized four-view adoption precede accepted ordinary-build
   promotion (m3_libxev_lifetime.md). Existing results cannot prove pin equivalence.
   Existing lsquic child-gitlink mismatch/LSQ-003 requirements also stay open
   (m3_dependency_provenance.md), preserving newer HPACK child.
2. The three standalone support roots are not reached by the normal source/build/
   test graph. Resolve their disposition before promotion: legitimate maintained
   verification entry points or retention outside product source. Preserve existing
   recipe/source evidence; no blind copy of unreachable support code.

Required sequence: finish5b/5c; resolve maintained dependencies; selectively
assemble agreed product delta against then-current Root; resolve support-root
reachability; preserve newer Root work and adopted pins; recompute exact drift;
verify and independently review exact assembly with actual maintained inputs;
then normal Root integration. H3 and multipart delivery remain separate required
work; fc69 is not complete H3 streaming.

Acceptance includes exact promotion manifest/no unintended deletion, published
ordinary-build pins without/tmp override, all applicable5/H1/TLS/shared-I/O tests,
required static/docs/version/forks/package gates, Debug/ReleaseSafe/sanitizers/
separateMSan/layouts/foreign32/fuzz/OSS-Fuzz/examples/consumer/ReleaseFast/
h1spec/H2-HPACK/Autobahn/nativeWindows accounted for at actual assembly identity,
and independent correctness/quality/structural review. No weakened thresholds,
historical run relabeling or M2 completion inferred from source copying.

Remote permissions/protections/current refs were not checked in this pass.
No adoption/patch/build/runtime/fetch/ref/source change occurred.
