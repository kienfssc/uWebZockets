# Task5b1 fix round1: reject final HEADERS before resume

Read this first alongside original task-5b1-brief.md and current report. Same
verification implementer owns this fix; all original ownership/safety constraints
remain binding. No live/client/server/fixture/socket/certificate execution.

Independent protocol review reports P2:

Pause barriers permit an early final response. Frozen v3 run_live.py:242 checks
only ended. A regression sending final200 HEADERS before resume, followed by the
valid body and END_STREAM after resume, passes both barriers and finish_upload.
This fails the requirement to prove no upload final while paused. Require upload
response headers to remain None at every pause barrier, alongside unfinished
stream. SPEC/QUALITY request changes; no additional structural findings.

Root confirms actual source and accepts the finding. Process/identity reviewer
otherwise passes assigned scope. Fix only this gap and new breakage directly
caused by its fix; preserve all old assertions, exact numeric/terminal/control
oracles and retained35/full5b/5c requirements. Do not globally ignore early
response, weaken no-RST or change expected status/body/counts.

Preserve original v3 frozen files, manifest6144be46524ed740a6a378d539ebea34b8165b7cbc83852812c2a30234901f8d,
report preimage, both actual Debug/ReleaseSafe records/binaries, original failure
logs and all core prerequisites. Append the fix report to task-5b1-report.md;
do not relabel original runs. Use distinct fix-source/manifest/output paths.

Meaningful covering checks may execute actual pure verifier logic against real
pinned h2/hyperframe codec data: final HEADERS without END_STREAM must reject
before resume; an unresponded registered upload must pass the guard; already
ended must still reject. Share a focused invariant-bearing pure guard with real
barrier only if needed for this proof. No fake sockets, monkeypatched status
calls, fake native callbacks/completions or stand-in live endpoint. Never call
the whole I/O barrier to manufacture red. If a meaningful original behavioral
red cannot be obtained within allowed pure scope, state that limitation rather
than fabricate it. No native run is authorized to prove this verifier fix.

If profile/build inputs remain byte-identical, reuse both actual binaries with
exact new-to-old profile/input/recipe/binary identity proof; do not rerun unrelated
compiles/tests. Run syntax on exact final Python, profileformat, isolated AST-only
graph and the covering pure checks. Bind final frozen source(s), complete trees,
inputs, both unchanged binary identities and original recipes in new manifest.

Report exact diffs, file hashes, commands/raw outputs and limitations. Report
covering tests/command/output before Root dispatches scoped re-review. Do not
self-review into acceptance or authorize runtime. Return concise status/report/
manifest identity and issues; Root will re-review the fix diff only.
