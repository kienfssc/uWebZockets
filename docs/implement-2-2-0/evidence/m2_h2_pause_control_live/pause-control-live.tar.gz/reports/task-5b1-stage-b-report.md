# Task5b1 StageB: owned pause/FIFO/public-control run

After both independent fix1 re-reviews pass, Root independently audits48 inputs,
seven inventories, unchanged actual Debug/ReleaseSafe recipes/profile/binaries
and review records. Audit5eff2fd048d376235221213d9b5bda461e28ab4db0b3a22d54d70adcdb545b21;
precise authorizationa10d056da47be8504b49a69b8475d88745f2931fa6e8cd233ce3304bcbdec16b
is recorded before execution in pause-control/fix1/stage-b-authorization.json.

Exact command from /workspaces/uWebZockets:

```sh
env PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5b1-fix1-frozen/run_live.py --run --manifest /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/pause-control/fix1/review-manifest.json --manifest-sha256 ca20660a9356b4452bd4a4cede8d4ff4b4851e6ae49d41780d4c6c5d415ed86f --output /tmp/uwz-h2-pause-owned-2026-10-28-r1 --cases partial_pause final_pause begin_pause_empty control_rules shutdown_idle
```

Session75092/finalchunk21680b completes exit0 with empty output; no retry or
restart. Actual TLS1.3/h2, owned PID/start/nonce/listener/certificate identity,
normal ownedSIGTERM/deinit/exit0/reaping/no forced cleanup or errors. Key removed;
Root verifies PID/key absence and identical source/input preflight after run.

All5 selected IDs pass. Partial upload remains at7 until owning-loop resume,
including after4097 queuedbytes/EOF, then12289/hashf84149bf. Final32-byte pause
has no end until resume without more DATA; begin-paused empty has0chunks/end
until resume. Control case checks BodyNotPaused and stale BodyControlExpired
without mutations. Five accepted request records each1/1/0; aggregate5/5/0,
42expected BodyCallbackActive checks,10terminal BodyControlExpired checks,
0failed/error/active. All5 post-deinit records equal pre-deinit observations.
Forty-one responses end normally. Actual observed partial chunks13/maxspan8192
is recorded, not a required packetization or callback-count oracle.

Raw result SHA6944b2f396279d8ffc7346f9b03cf0f1a1d82123d992e7c6527becc5cc6d63a8;
Root result audit1e22f282423a124d274745ce8b7da668c76e766ee7915f799714f4b703265320.
Copied raw result/serverlog/publiccertificate/executionreceipt/audit under
pause-control/stage-b. No privatekey or compiler/native rerun in publication.

This proves one Linux ReleaseSafe positive pause/control subset and idle
shutdown. It does not prove active cancellation, active shutdown, native thread/
fault/physical-lifetime/platform/sanitizer/compliance gates, full5b/5c, H3,
multipart transport, genuine earlydata, maintained adoption or full milestones.
Subsets are supported in source but were not separately run. Stopped experiments
remain stopped. Root publishes scoped results and continues original plan.
