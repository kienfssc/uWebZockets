import gzip
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path, PurePosixPath

repo = Path('/workspaces/uWebZockets')
evidence = repo / '.uwz-work/evidence/h2-streaming/integration-owned/pause-control'
output = repo / 'docs/implement-2-2-0/evidence/m2_h2_pause_control_live'
output.mkdir(parents=True, exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
audit = json.loads((evidence / 'stage-b/root-result-audit.json').read_text())
assert audit['checks_passed'] and audit['postrun_preflight_identical']
assert audit['child_exit_zero_reaped'] and audit['key_absent'] and audit['post_deinit_records_match']
assert audit['begin_end_cancel'] == [5, 5, 0]
assert audit['callback_checks'] == 42 and audit['terminal_checks'] == 10
members = {}


def add(name, path):
    assert name not in members and '..' not in PurePosixPath(name).parts
    assert not PurePosixPath(name).is_absolute() and path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    assert not data.startswith(b'\x7fELF'), name
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[0-9A-Z]{16}', data), name
    members[name] = data


for path in sorted(evidence.rglob('*')):
    if path.is_file():
        add('evidence/' + path.relative_to(evidence).as_posix(), path)
for label, root in [('v1', Path('/tmp/uwz-task5b1-source-frozen')),
                    ('v2', Path('/tmp/uwz-task5b1-source-frozen-v2')),
                    ('v3', Path('/tmp/uwz-task5b1-source-frozen-v3')),
                    ('fix1', Path('/tmp/uwz-task5b1-fix1-frozen'))]:
    for path in sorted(root.iterdir()):
        add('fixture/' + label + '/' + path.name, path)
for name in ['task-5b-architecture.md', 'task-5b1-brief.md', 'task-5b1-report.md',
             'task-5b1-fix-1-brief.md', 'task-5b1-stage-b-report.md']:
    add('reports/' + name, repo / '.superpowers/sdd/h2_streaming_plan' / name)
add('reports/component.md', repo / 'docs/implement-2-2-0/m2_h2_pause_control_live.md')
add('reports/promotion-preflight-8ab099d.md', repo / '.uwz-work/plans/m2-promotion-preflight-8ab099d.md')
add('inputs/h2_client.py', repo / '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py')
add('inputs/immutable-libxev-input.json', repo / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json')
add('publication/publish-h2-pause-control-live.py', Path(__file__).resolve())
inventory = [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())]
members['inventory.json'] = (json.dumps({'binding': 'Publication-time bytes; historical compile/run records keep their actual source identities.', 'files': inventory}, indent=2) + '\n').encode()
archive = output / 'pause-control-live.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    entries = tar.getmembers()
    assert len(entries) == len(members) == len({x.name for x in entries})
    for entry in entries:
        assert entry.isfile() and not PurePosixPath(entry.name).is_absolute() and '..' not in PurePosixPath(entry.name).parts
        assert tar.extractfile(entry).read() == members[entry.name]
case_data = json.loads((Path('/tmp/uwz-task5b1-fix1-frozen') / 'case_manifest.json').read_text())
manifest = {'scope': 'One owned Linux ReleaseSafe pause/FIFO/public-validation run plus idle shutdown; remaining matrix and production adoption open.',
            'source_digest': audit['source_digest'], 'source_files': 1031,
            'source_checkpoint': '../m2_h2_native_tcp/README.md', 'prior_core_proof': '../m2_h2_core_live/README.md',
            'archive': archive.name, 'archive_sha256': sha(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
            'safe_regular_members': len(members), 'inventory_entries': len(inventory),
            'binary_sha256': audit['binary_sha256'],
            'review_manifest_sha256': sha((evidence / 'fix1/review-manifest.json').read_bytes()),
            'preflight_audit_sha256': audit['preflight_sha256'],
            'authorization_sha256': sha((evidence / 'fix1/stage-b-authorization.json').read_bytes()),
            'result_sha256': sha((evidence / 'stage-b/result.json').read_bytes()),
            'root_result_audit_sha256': sha((evidence / 'stage-b/root-result-audit.json').read_bytes()),
            'cases_passed': audit['cases_passed'], 'case_manifest': case_data,
            'begin_end_cancel': [5, 5, 0], 'callback_checks': 42, 'terminal_checks': 10,
            'post_deinit_records_equal': True, 'responses_ended': 41,
            'tls': 'TLS1.3 / h2', 'runtime_mode': 'ReleaseSafe', 'exit_status': 0, 'runtime_retries': 0,
            'child_exit_zero_reaped': True, 'private_key_removed': True,
            'deferred_minor': ['Unused copied EXPECTED100M constant in test runner; later fixture cleanup/final review.'],
            'remaining': ['Other5b admission/limits/Continue/quota/trailers/credit/concurrency/metadata/helper cases',
                          'All5c producer/file/pressure/reuse/active cancel/reset/errors/disconnect/active shutdown and combined matrix',
                          'H3/multipart/genuine early data/full native/sanitizer/physical/platform/compliance gates',
                          'Maintained publication, production adoption and complete original milestones']}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(output / 'README.md').write_text(f'''# Owned HTTP/2 pause and public-control evidence

The [archive](pause-control-live.tar.gz) preserves all fixture revisions, retained
compile failures and successful receipts, input inventories, independent initial
and fix reviews, actual pure codec guard checks, Root audit/authorization, exact
executed command, raw result/server log/public certificate and result audit.
All {len(members)} members are safe regular files; {len(inventory)} inventory entries verify.
No private key or compiled executable is included.

Archive SHA-256: `{manifest['archive_sha256']}` ({manifest['archive_bytes']} bytes).
See the [manifest](manifest.json) and [component report](../../m2_h2_pause_control_live.md).

The single Linux ReleaseSafe TLS1.3/h2 run passes partial_pause, final_pause,
begin_pause_empty, control_rules and shutdown_idle. Five accepted requests each
have1/1/0 begin/end/cancel; aggregate5/5/0, zero failed/errors/active. Forty-two
callback refusals and ten terminal refusals match the exact public errors.
All five persistent records match after deinit;41 responses end normally.
Owned SIGTERM exits0/reaps/no force or retry; private key removed.

The partial pause holds accepted7 through queuedDATA/EOF, then resumes12289
bytes with SHA`f84149bf46313d9f7da734e3d53f88b2d01a2c01c38bf422063c507b237915f4`.
Both partial barriers require no finalHEADERS/end. Final-byte pause resumes32
without more upload data; begin-paused emptyEOF has no chunks before/after resume.
Ordinary ready/stale/callback/terminal control validation is distinct from native
cancellation schedules or active cancellation, which this run does not exercise.

Candidate source remains1031-file
`{manifest['source_digest']}` from the
[native checkpoint](../m2_h2_native_tcp/README.md), with unchanged c223 override,
bindings/libraries and [pinned client](../m2_h2_client/README.md). The
[core proof](../m2_h2_core_live/README.md) remains separate. Exact compiler argv
and source/input/binary hashes are in `evidence/*v3*.json`; exact runtime argv
and environment are in `evidence/fix1/stage-b-authorization.json`. That record
authorizes the completed run, not arbitrary future runs.

Initial source review finds an early-final-HEADERS observation gap; the retained
fix adds an actual shared pure guard and real-codec checks. No old live failure
or original behavioral red is claimed. Both scoped re-reviews pass; unchanged
Debug/ReleaseSafe binaries are rehashed, not rebuilt. Only ReleaseSafe is run.
Subset support is source-checked; only the full selected set ran. The unused
copied100M hash constant is a recorded minor for later fixture cleanup.

Remaining5b/5c, full combined H2, H3, multipart transport, genuine earlydata,
physical-lifetime/full-quality/platform/compliance, maintained publication,
production adoption and M2 remain open. Fixed-capacity evidence is not an RSS/
leak/native safety proof. Unread future resets and exceptional cleanup are
outside this run. Stopped experiments and denied socket cases remain stopped.
''')
print(json.dumps({k: manifest[k] for k in ['archive_sha256', 'archive_bytes', 'safe_regular_members', 'inventory_entries', 'result_sha256', 'root_result_audit_sha256']}, indent=2))
