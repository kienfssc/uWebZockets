"""Freeze the guard fix after checking the v3 recipes and every bound input."""
import hashlib
import json
import shutil
from pathlib import Path

root = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/pause-control')
fix = root / 'fix1'
prior = root / 'review-manifest.json'
frozen = Path('/tmp/uwz-task5b1-fix1-frozen')
names = ('profile.zig', 'prepare.py', 'wire.py', 'run_live.py', 'case_manifest.json', 'offline_checks.py')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inventory(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}


assert digest(prior) == '6144be46524ed740a6a378d539ebea34b8165b7cbc83852812c2a30234901f8d'
manifest = json.loads(prior.read_text())
for tree, expected in manifest['trees'].items():
    assert inventory(Path(tree)) == expected, tree
for path, expected in manifest['inputs'].items():
    assert digest(path) == expected, path
for name in ('profile.zig', 'prepare.py', 'wire.py', 'case_manifest.json'):
    assert digest(fix / name) == digest(Path('/tmp/uwz-task5b1-source-frozen-v3') / name)
for mode, output in (('debug-v3', '/tmp/uwz-task5b1-debug5/profile'),
                     ('release-v3', '/tmp/uwz-task5b1-release4/profile')):
    record_path = root / (mode + '.json')
    command_path = root / (mode + '.command.json')
    record = json.loads(record_path.read_text())
    command = json.loads(command_path.read_text())
    assert record['exit_status'] == 0 and record['inputs_unchanged']
    assert record['argv'] == command['argv'] and record['optimization'] == command['optimization']
    assert record['fixture_before']['profile.zig'] == record['fixture_after']['profile.zig'] == digest(fix / 'profile.zig')
    assert record['fixture_before']['prepare.py'] == record['fixture_after']['prepare.py'] == digest(fix / 'prepare.py')
    assert record['input_sha256'] == record['input_after']
    assert record['source_tree_sha256'] == record['source_after_sha256']
    assert digest(output) == record['binary_sha256'] == manifest['inputs'][output]
    for suffix in ('.json', '.command.json', '.log', '-source-inputs.json', '-source-after.json'):
        path = root / (mode + suffix)
        manifest['inputs'][str(path)] = digest(path)
assert not frozen.exists()
frozen.mkdir(mode=0o700)
for name in names:
    shutil.copyfile(fix / name, frozen / name)
files = inventory(frozen)
manifest['trees'][str(frozen)] = files
manifest['tree_counts'][str(frozen)] = len(files)
for name, value in files.items():
    manifest['inputs'][str(frozen / name)] = value
manifest['runner'] = str(frozen / 'run_live.py')
manifest['wire'] = str(frozen / 'wire.py')
manifest['preimage_manifest_sha256'] = digest(prior)
out = fix / 'review-manifest.json'
out.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
print('v3 manifest, all bound trees and inputs unchanged')
print('both recipes, profiles, inputs and actual binaries match v3')
print('fix source files:', len(files))
print('fix manifest sha256:', digest(out))
