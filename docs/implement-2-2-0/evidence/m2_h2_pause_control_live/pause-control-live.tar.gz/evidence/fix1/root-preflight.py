"""Read-only identity/build audit before a separately authorized owned run."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
EVIDENCE = HERE.parent
MANIFEST_SHA = 'ca20660a9356b4452bd4a4cede8d4ff4b4851e6ae49d41780d4c6c5d415ed86f'


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as source:
        while block := source.read(1048576):
            value.update(block)
    return value.hexdigest()


def main():
    manifest_path = HERE / 'review-manifest.json'
    assert digest(manifest_path) == MANIFEST_SHA
    manifest = json.loads(manifest_path.read_text())
    assert manifest['runner'] == '/tmp/uwz-task5b1-fix1-frozen/run_live.py'
    assert manifest['binary'] == '/tmp/uwz-task5b1-release4/profile'
    assert manifest['state'] == 'ready-for-independent-review'
    trees = []
    for root, expected in manifest['trees'].items():
        actual = {str(p.relative_to(root)): digest(p) for p in sorted(Path(root).rglob('*')) if p.is_file()}
        assert actual == expected, root
        tree_digest = hashlib.sha256(json.dumps(list(actual.items())).encode()).hexdigest()
        trees.append({'root': root, 'files': len(actual), 'sha256': tree_digest})
        if root == '/tmp/uwz-task4d-fix1-frozen':
            assert tree_digest == manifest['source_tree_digest']
        if root == '/tmp/uwz-h2-client-tooling/packages':
            assert tree_digest == manifest['client_tree_digest']
    for name, expected in manifest['inputs'].items():
        assert digest(name) == expected, name
    assert digest(EVIDENCE / 'review-manifest.json') == manifest['preimage_manifest_sha256']
    frozen = Path(manifest['runner']).parent
    builds = []
    for stem, mode, binary in (
        ('debug-v3', 'Debug', '/tmp/uwz-task5b1-debug5/profile'),
        ('release-v3', 'ReleaseSafe', manifest['binary']),
    ):
        command_path = EVIDENCE / (stem + '.command.json')
        record_path = EVIDENCE / (stem + '.json')
        command = json.loads(command_path.read_text())
        record = json.loads(record_path.read_text())
        assert record['exit_status'] == 0 and record['inputs_unchanged']
        assert record['optimization'] == command['optimization'] == mode
        assert record['argv'] == command['argv']
        assert record['source_tree_sha256'] == record['source_after_sha256'] == manifest['source_tree_digest']
        assert record['input_sha256'] == record['input_after'] == command['input_sha256']
        for name, expected in record['input_sha256'].items():
            assert digest(name) == expected, name
        for name, expected in record['fixture_before'].items():
            assert digest(frozen / name) == expected, name
        assert record['fixture_before'] == record['fixture_after']
        assert record['override_before'] == record['override_after']
        assert digest(binary) == record['binary_sha256']
        assert (EVIDENCE / (stem + '.log')).read_bytes() == b''
        builds.append({'mode': mode, 'binary': binary, 'sha256': digest(binary),
                       'command_sha256': digest(command_path), 'record_sha256': digest(record_path)})
    evidence = {name: digest(HERE / name) for name in
                ['run_live.diff', 'offline_checks.py', 'report-preimage.md', 'review-process.md', 'review-protocol.md']}
    report = {'checks_passed': True, 'manifest_sha256': MANIFEST_SHA,
              'input_files': len(manifest['inputs']), 'trees': trees, 'builds': builds,
              'evidence_sha256': evidence, 'runner_sha256': digest(manifest['runner']),
              'scope': 'Identity/build receipts and reviewed evidence only; no runtime or new test execution.'}
    (HERE / 'root-preflight-audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'checks_passed': True, 'inputs': report['input_files'],
                      'tree_counts': [x['files'] for x in trees],
                      'binary_modes': [x['mode'] for x in builds],
                      'audit_sha256': digest(HERE / 'root-preflight-audit.json')}))


if __name__ == '__main__':
    main()
