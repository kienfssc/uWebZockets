"""Pure HTTP/2 codec and barrier guard checks; no transport or fixture."""
import importlib.util
from pathlib import Path

import h2.config
import h2.connection


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def rejects(record, runner, expected):
    try:
        runner.require_upload_pending(record)
    except RuntimeError as error:
        assert str(error) == expected, str(error)
        return
    raise AssertionError('guard accepted ' + expected)


def main():
    root = Path(__file__).resolve().parent
    runner = load('runner', root / 'run_live.py')
    wire = load('wire', root / 'wire.py')
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    encoder = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    client.initiate_connection()
    encoder.initiate_connection()
    encoder.receive_data(client.data_to_send())
    client.receive_data(encoder.data_to_send())
    client.send_headers(1, [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'),
                            (':path', '/upload/partial_pause')], end_stream=False)
    encoder.receive_data(client.data_to_send())
    records, trace = {}, {}
    wire.register(records, 1, 1024)
    runner.require_upload_pending(records[1])
    print('registered upload with no response: accepted')
    encoder.send_headers(1, [(':status', '200')], end_stream=False)
    wire.accept(client, encoder.data_to_send(), records, trace)
    assert records[1]['headers'] == [(':status', '200')] and not records[1]['ended']
    rejects(records[1], runner, 'upload final headers before resume')
    print('decoded final 200 HEADERS without END_STREAM: rejected')
    encoder.send_data(1, b'ok', end_stream=True)
    wire.accept(client, encoder.data_to_send(), records, trace)
    assert records[1]['ended'] and bytes(records[1]['body']) == b'ok'
    rejects(records[1], runner, 'upload final before resume')
    print('decoded END_STREAM: rejected')


if __name__ == '__main__':
    main()
