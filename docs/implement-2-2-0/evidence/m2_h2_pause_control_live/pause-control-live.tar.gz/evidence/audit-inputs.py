import hashlib
import json
from pathlib import Path

root = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/pause-control')
manifest_path = root / 'review-manifest.json'
manifest = json.loads(manifest_path.read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


for tree, expected in manifest['trees'].items():
    base = Path(tree)
    actual = {str(p.relative_to(base)): digest(p) for p in sorted(base.rglob('*')) if p.is_file()}
    assert actual == expected, tree
for path, expected in manifest['inputs'].items():
    assert digest(path) == expected, path
for mode in ('debug-v3', 'release-v3'):
    record = json.loads((root / (mode + '.json')).read_text())
    assert record['inputs_unchanged'] and record['exit_status'] == 0
print('all bound tree inventories and inputs unchanged')
print('tree counts:', json.dumps(manifest['tree_counts'], sort_keys=True))
print('manifest sha256:', digest(manifest_path))
