import hashlib
import json
import shutil
from pathlib import Path

root = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned')
work = root / 'pause-control'
frozen = Path('/tmp/uwz-task5b1-source-frozen-v3')
prior = root / 'core/fix1/review-manifest.json'
names = ('profile.zig', 'prepare.py', 'wire.py', 'run_live.py', 'case_manifest.json')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inventory(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}


assert digest(prior) == '0f2ff0dfbe0a73866b12fe7cc858a0db82c0ea7a009eb2fe634089769131f9c0'
manifest = json.loads(prior.read_text())
for tree, expected in manifest['trees'].items():
    assert inventory(Path(tree)) == expected, tree
for path, expected in manifest['inputs'].items():
    assert digest(path) == expected, path
assert not frozen.exists()
frozen.mkdir(mode=0o700)
for name in names:
    shutil.copyfile(work / name, frozen / name)
files = inventory(frozen)
for mode, output in (('debug-v3', '/tmp/uwz-task5b1-debug5/profile'), ('release-v3', '/tmp/uwz-task5b1-release4/profile')):
    record = json.loads((work / (mode + '.json')).read_text())
    assert record['exit_status'] == 0 and record['inputs_unchanged']
    assert record['fixture_before']['profile.zig'] == files['profile.zig'] == record['fixture_after']['profile.zig']
    assert digest(output) == record['binary_sha256']
manifest['trees'][str(frozen)] = files
manifest['tree_counts'][str(frozen)] = len(files)
for name, value in files.items():
    manifest['inputs'][str(frozen / name)] = value
manifest['runner'] = str(frozen / 'run_live.py')
manifest['wire'] = str(frozen / 'wire.py')
manifest['binary'] = '/tmp/uwz-task5b1-release4/profile'
manifest['inputs'][manifest['binary']] = digest(manifest['binary'])
manifest['inputs']['/tmp/uwz-task5b1-debug5/profile'] = digest('/tmp/uwz-task5b1-debug5/profile')
manifest['preimage_manifest_sha256'] = digest(prior)
out = work / 'review-manifest.json'
out.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
print('prior manifest, trees and inputs unchanged')
print('frozen source files:', len(files))
print('review manifest sha256:', digest(out))
