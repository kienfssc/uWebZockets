# Task 5b-1 Stage A: prepared, independent review required

The test-only source is prepared and compiled, not live-validated. No fixture, client, server, socket, certificate command, native callback, or binary `--help` was executed. Neither compiler success nor the offline checks establish physical lifetime, protocol behavior, or acceptance of these cases. Root must obtain independent source review and separately authorize any exact live run. The earlier core evidence and production inputs were not edited.

Working artifacts are under `.uwz-work/evidence/h2-streaming/integration-owned/pause-control/`. The final frozen source package is `/tmp/uwz-task5b1-source-frozen-v2`. Its review input manifest is `pause-control/review-manifest.json`, SHA-256 `91f78de6e0573a533f44c6e9b75167e1d39cab5be9080087bf3d29da0e28a089`. This manifest is not an independent review. The earlier prepared revision and its manifest are retained at `/tmp/uwz-task5b1-source-frozen` and `review-manifest-v1.json`; it lacked per-record begin attempts and is superseded.

| Frozen source | SHA-256 |
| --- | --- |
| profile.zig | `2bd99097d33b0401826afdb505b3156b41449b35ddd3825efcbea4729d33efb1` |
| run_live.py | `b4754a085d0a9ae6e6ad23e1b79cef4db31b31a325f55460c0005768dab42bdd` |
| wire.py | `8aff857fbdbe36a0b483c79cb52faa0670494ca976fdfc06552627e97c3ba78c` |
| prepare.py | `3d944c3f70e123386177b070230df2b09a16f10184b9ded272de95a5bb25829e` |
| case_manifest.json | `fb8b290c399c57ef857d06cf1b6b44c0a4879c3ff8c66a8e14cf8864288186ab` |

The profile retains the core configuration: eight connections, streaming on, request line 512, headers 4096/count 80, H1 body 256, H2 body 4096, encoded header 8192, response headers 4096/count 32, captures 24, write queue 65536, development log off; the prior compile diagnostic established request stride 5888, H2 stride 281200, slab 4098304, router 884352. It uses the configured public HTTPS App, two reusable sink slots, a quota-two limit-100000000 body route, and five persistent records. The source contains public status and copied-token control routes, copied-hash status, callback and terminal diagnostics, accepted-prefix hashing, and post-deinit record emission. The runner expresses the two same-connection barriers for the 12289-byte partial pause, final-byte and empty-begin pause, ready and stale control checks, and a health request after each case. It inherits the core raw-RST rejection, bounded response/event and process cleanup logic. These are source assertions awaiting review and execution.

The five named supported cases are `partial_pause`, `final_pause`, `begin_pause_empty`, `control_rules`, `shutdown_idle`; the current runner requires all five in that order to make its final five-record aggregate assertion. It rejects subsets and alternate ordering as well as unsupported IDs. This is a narrower interpretation of selectable cases and needs Root review against the brief before authorization. The case manifest preserves the five prior core cases as prior proof and lists the remaining 5b/5c cases as planned, unimplemented; no prior upload is rerun by the new shutdown case.

Both final fixture builds used the fixed Zig 0.16 compiler, `-j2`, the coherent immutable production tree and shared existing per-mode compiler caches, with binaries in `/tmp`. The full compiler argv, input hashes and before/after trees are in `debug-final.command.json`, `debug-final.json`, `debug-final-source-inputs.json`, `debug-final-source-after.json`, and the corresponding `release-final` records. Exact outer commands:

```sh
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/pause-control/prepare.py --optimization Debug --output /tmp/uwz-task5b1-debug3 --cache-root /tmp/uwz-task5a-debug --record debug-final
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/pause-control/prepare.py --optimization ReleaseSafe --output /tmp/uwz-task5b1-release2 --cache-root /tmp/uwz-task5a-release --record release-final
```

Each printed `Exit status: 0`; both raw compiler logs are empty, SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. Each record says `inputs_unchanged: true`. Debug binary SHA-256 `28583a5d3c749d09ab98c09f359227918a16d26c156d1ee0096fa7c435e56d02`; ReleaseSafe binary SHA-256 `69e171c846fb8b3de2047258fdb122e621c797ed842098967d188b6c75ad8443`. Neither was executed.

The initial Debug compile exited 1: `no field named 'params' in struct 'http.request.Request'` at the two public route callbacks. The saved raw diagnostic is `debug-first.log`, SHA-256 `8f85b154ef2a9992b23734708d09f950c28582af2b7be56c3c9a1ba21405b2e0`. It was corrected to the public `get_param`; `debug-second` and `release-first` then succeeded on the superseded revision. Their records and logs remain in the owned directory.

The exact freeze and final identity audit commands were:

```sh
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/pause-control/freeze-command.py
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/pause-control/audit-inputs.py
```

Both exited 0. Freeze raw output:

```text
prior manifest, trees and inputs unchanged
frozen source files: 5
review manifest sha256: 91f78de6e0573a533f44c6e9b75167e1d39cab5be9080087bf3d29da0e28a089
```

Audit raw output:

```text
all bound tree inventories and inputs unchanged
tree counts: {"/tmp/uwz-h2-client-tooling/packages": 42, "/tmp/uwz-reviewed-libxev-c223-loop-callbacks": 93, "/tmp/uwz-task4d-fix1-frozen": 1031, "/tmp/uwz-task5a-fix1-frozen": 6, "/tmp/uwz-task5b1-source-frozen-v2": 5, "/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy": 14}
manifest sha256: 91f78de6e0573a533f44c6e9b75167e1d39cab5be9080087bf3d29da0e28a089
```

The inherited manifest inventories and hashes the original six static libraries, stable r2 bindings, Zig compiler, client, helper, interpreter and tools as well as the production and override trees. The builds independently recorded production source digest before and after `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`; the inherited client digest is `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`, and helper SHA-256 is `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`. The new manifest binds both binary hashes and the complete new source inventory. The prior manifest and all its inventories were checked before freezing, and the new manifest and inventories were checked afterward.

Syntax and formatting checks:

```sh
/home/codespace/.python/current/bin/python3 -B -c 'import ast,pathlib; p=pathlib.Path("/tmp/uwz-task5b1-source-frozen-v2"); [ast.parse((p/f).read_text(),filename=f) for f in ("prepare.py","run_live.py","wire.py")]; print("frozen syntax OK")'
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check /tmp/uwz-task5b1-source-frozen-v2/profile.zig
```

Both exited 0; first output `frozen syntax OK`, second was empty. `graphify update /tmp/uwz-task5b1-graph` on a scratch copy exited 0 and reported `84 nodes, 211 edges, 6 communities`; the workspace graph was not modified.

The following pure helper check used the unchanged helper, no socket or child:

```sh
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S -c 'import hashlib,h2_client; p=h2_client.payload_block(32,0,32); assert p == bytes(range(1,11))+h2_client.SENTINEL; assert hashlib.sha256(b"").hexdigest()=="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"; print("P32:",p.hex(),"SHA256:",hashlib.sha256(p).hexdigest()); print("empty SHA256:",hashlib.sha256(b"").hexdigest())'
```

Exit 0, raw output:

```text
P32: 0102030405060708090a66696e616c2d75706c6f61642d73656e74696e656c21 SHA256: 7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5
empty SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
```

No full local matrix, sanitizer, compliance gate, platform gate, active shutdown, native fault/race or cancellation schedule, injected completion, physical lifetime, real client/server, or full milestone check was run. MSan was not run; it instruments the C boundary rather than Zig and cannot be combined with ASan. All later 5b/5c and original milestone gates remain open.
