const support = @import("test_support");
export fn declared_length(header: *const support.quic_stream.HeaderSet) usize {
    const length: ?usize = header.content_length;
    return length orelse 0;
}
