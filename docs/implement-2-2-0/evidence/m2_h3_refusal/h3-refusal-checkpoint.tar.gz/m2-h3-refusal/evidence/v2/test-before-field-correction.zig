const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const stream = support.quic_stream;
const radix = support.radix;
const body = support.request_body;
const Request = support.http_request.Request;
const Response = support.http_response.Response;
const StreamingRequest = support.streaming_request.StreamingRequest;

const capacities: stream.Capacities = .{
    .request_header_size = 1024,
    .request_body_size = 8,
    .response_header_size = 512,
    .response_header_count = 8,
};
const RouterStorage = radix.Bundle(.{ .stream_request_bodies = true });

const Effects = struct {
    sink_calls: usize = 0,
    middleware_calls: usize = 0,
    buffered_calls: usize = 0,

    fn definition(self: *Effects) body.BodyRoute {
        return .{
            .sink = .{ .context = self, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel },
            .limits = .{ .max_body_bytes = 32, .max_active = 1 },
            .middleware_policy = .headers_only,
        };
    }

    fn begin(context: *anyopaque, _: *const StreamingRequest, _: body.BodyControl) !body.BodyBinding {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.sink_calls += 1;
        return .{ .context = context };
    }

    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.sink_calls += 1;
        return .{ .consumed = bytes.len, .readiness = .ready };
    }

    fn end(context: *anyopaque, _: *const StreamingRequest, _: *Response) !void {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.sink_calls += 1;
    }

    fn cancel(context: *anyopaque, _: body.BodyCancelReason) void {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.sink_calls += 1;
    }

    fn middleware(context: *anyopaque, _: *Request, _: *Response) radix.MiddlewareResult {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.middleware_calls += 1;
        return .continue_dispatch;
    }

    fn buffered(context: *anyopaque, _: *Request, response: *Response) void {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.buffered_calls += 1;
        response.end("200 OK", "ok") catch @panic("bounded test response fits");
    }
};

const FakeStream = struct {
    reads: usize = 0,
    headers: usize = 0,
    status: [3]u8 = .{0} ** 3,
    written: usize = 0,
    read_enabled: c_int = -1,
    write_enabled: c_int = -1,
    read_shutdowns: usize = 0,
    write_shutdowns: usize = 0,
    closes: usize = 0,
    header_releases: usize = 0,
    input: []const u8 = "",
    input_offset: usize = 0,
};

const FakeIo = struct {
    fn from(raw: ?*c.lsquic_stream) *FakeStream {
        return @ptrCast(@alignCast(raw.?));
    }

    fn wantread(raw: ?*c.lsquic_stream, want: c_int) callconv(.c) c_int {
        from(raw).read_enabled = want;
        return 0;
    }

    fn read(raw: ?*c.lsquic_stream, buffer: ?*anyopaque, length: usize) callconv(.c) isize {
        const self = from(raw);
        self.reads += 1;
        const accepted = @min(length, self.input.len - self.input_offset);
        const bytes: [*]u8 = @ptrCast(buffer.?);
        @memcpy(bytes[0..accepted], self.input[self.input_offset..][0..accepted]);
        self.input_offset += accepted;
        return @intCast(accepted);
    }

    fn wantwrite(raw: ?*c.lsquic_stream, want: c_int) callconv(.c) c_int {
        from(raw).write_enabled = want;
        return 0;
    }

    fn write(raw: ?*c.lsquic_stream, _: ?*const anyopaque, length: usize) callconv(.c) isize {
        from(raw).written += length;
        return @intCast(length);
    }

    fn send_headers(raw: ?*c.lsquic_stream, headers: [*c]const c.lsquic_http_headers_t, _: c_int) callconv(.c) c_int {
        const self = from(raw);
        self.headers += 1;
        const header: *const c.struct_uz_lsxpack_header = @ptrCast(@alignCast(headers.*.headers));
        const bytes: [*]const u8 = @ptrCast(header.buf);
        @memcpy(&self.status, bytes[@intCast(header.val_offset)..][0..3]);
        return 0;
    }

    fn shutdown(raw: ?*c.lsquic_stream, how: c_int) callconv(.c) c_int {
        const self = from(raw);
        if (how == 0) self.read_shutdowns += 1;
        if (how == 1) self.write_shutdowns += 1;
        return 0;
    }

    fn close(raw: ?*c.lsquic_stream) callconv(.c) c_int {
        from(raw).closes += 1;
        return 0;
    }

    const table: stream.StreamIo = .{
        .wantread = wantread,
        .read = read,
        .wantwrite = wantwrite,
        .write = write,
        .send_headers = send_headers,
        .shutdown = shutdown,
        .close = close,
    };
};

const TestStream = stream.stream_with(FakeIo.table, capacities);

const Fixture = struct {
    fake: FakeStream = .{},
    header_storage: [1024]u8 = undefined,
    body_storage: [8]u8 = .{0xa5} ** 8,
    response_body: [64]u8 = undefined,
    response_headers: [512]u8 = undefined,
    headers: stream.HeaderSet = .{},
    quic: TestStream = .{},

    fn init(self: *Fixture, router: *const radix.Router, method: []const u8, path: []const u8) !void {
        self.headers.reset(self, release_headers, &self.header_storage, &.{}, &.{}, capacities);
        self.headers.router = router;
        self.quic.reset(self, release_stream, @ptrCast(&self.fake), router, &self.body_storage, &self.response_body, &self.response_headers, &.{}, &.{}, &.{}, &.{});
        try std.testing.expect(add_header(&self.headers, ":method", method));
        try std.testing.expect(add_header(&self.headers, ":scheme", "https"));
        try std.testing.expect(add_header(&self.headers, ":authority", "localhost"));
        try std.testing.expect(add_header(&self.headers, ":path", path));
    }

    fn release_headers(context: *anyopaque, _: *stream.HeaderSet) void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        self.fake.header_releases += 1;
    }

    fn release_stream(_: *anyopaque, _: *TestStream) void {}

    fn attach(self: *Fixture) !void {
        try std.testing.expect(self.headers.process_header(null));
        self.quic.attach_headers(&self.headers);
    }

    fn expect_refusal(self: *Fixture) !void {
        try std.testing.expectEqual(@as(u16, 503), self.quic.response_status_code);
        try std.testing.expectEqual(@as(usize, 0), self.fake.reads);
        try std.testing.expectEqual(@as(usize, 0), self.quic.body_length);
        try std.testing.expectEqual(@as(usize, 0), self.quic.response_body_length);
        try std.testing.expectEqual(@as(usize, 1), self.fake.read_shutdowns);
        try std.testing.expectEqual(@as(c_int, 0), self.fake.read_enabled);
        try std.testing.expectEqual(@as(c_int, 1), self.fake.write_enabled);
        try std.testing.expectEqual(@as(usize, 0), self.fake.closes);
        try std.testing.expectEqualSlices(u8, &(.{0xa5} ** 8), &self.body_storage);
    }
};

const HeaderField = struct { name: []const u8, value: []const u8 };

fn add_header(headers: *stream.HeaderSet, name: []const u8, value: []const u8) bool {
    const start = headers.write_offset;
    if (name.len + value.len > headers.storage.len - start) return false;
    @memcpy(headers.storage[start..][0..name.len], name);
    @memcpy(headers.storage[start + name.len ..][0..value.len], value);
    headers.decoded = std.mem.zeroes(c.struct_uz_lsxpack_header);
    headers.decoded.buf = @ptrCast(headers.storage.ptr);
    headers.decoded.name_offset = @intCast(start);
    headers.decoded.name_len = @intCast(name.len);
    headers.decoded.val_offset = @intCast(start + name.len);
    headers.decoded.val_len = @intCast(value.len);
    return headers.process_header(@ptrCast(&headers.decoded));
}

test "body H3: canonical selected route refuses at headers for every valid length" {
    var storage = RouterStorage{};
    var router = try radix.Router.init(storage.storage());
    var effects = Effects{};
    const definition = effects.definition();
    try router.route_body(.post, "/upload", &definition);
    try router.use(&effects, Effects.middleware);
    const lengths = [_]?[]const u8{ null, "0", "4", "9", "33", "18446744073709551615" };
    for (lengths) |length| {
        var fixture = Fixture{};
        try fixture.init(&router, "POST", "/upload?name=zig");
        if (length) |value| try std.testing.expect(add_header(&fixture.headers, "content-length", value));
        try std.testing.expect(add_header(&fixture.headers, "expect", "100-continue"));
        try fixture.attach();
        try fixture.expect_refusal();
        fixture.quic.on_read();
        try fixture.expect_refusal();
        fixture.quic.on_write();
        try std.testing.expectEqualStrings("503", &fixture.fake.status);
        try std.testing.expectEqual(@as(usize, 1), fixture.fake.headers);
        try std.testing.expectEqual(@as(usize, 0), fixture.fake.written);
        try std.testing.expectEqual(@as(usize, 1), fixture.fake.write_shutdowns);
        fixture.quic.on_read();
        try std.testing.expectEqual(@as(usize, 0), fixture.fake.closes);
        fixture.quic.on_close();
        try std.testing.expectEqual(@as(usize, 1), fixture.fake.header_releases);
    }
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
    try std.testing.expectEqual(@as(usize, 0), effects.middleware_calls);
    for (router.body.active) |active| try std.testing.expectEqual(@as(u16, 0), active);
}

test "body H3: strict header rejection precedes selected route refusal" {
    var storage = RouterStorage{};
    var router = try radix.Router.init(storage.storage());
    var effects = Effects{};
    const definition = effects.definition();
    try router.route_body(.post, "/upload", &definition);
    const invalid = [_]HeaderField{
        .{ .name = "content-length", .value = "18446744073709551616" },
        .{ .name = "content-length", .value = "-1" },
        .{ .name = "content-length", .value = "+1" },
        .{ .name = "content-length", .value = "1,1" },
        .{ .name = "content-length", .value = " 1" },
        .{ .name = "content-length", .value = "" },
        .{ .name = "connection", .value = "close" },
        .{ .name = "transfer-encoding", .value = "chunked" },
        .{ .name = "x-Bad", .value = "case" },
        .{ .name = "host", .value = "other" },
        .{ .name = "te", .value = "gzip" },
        .{ .name = "x-bad", .value = "newline\n" },
    };
    for (invalid) |field| {
        var fixture = Fixture{};
        try fixture.init(&router, "POST", "/upload");
        try std.testing.expect(!add_header(&fixture.headers, field.name, field.value));
        try std.testing.expectEqual(@as(u16, 0), fixture.quic.response_status_code);
    }
    var duplicate = Fixture{};
    try duplicate.init(&router, "POST", "/upload");
    try std.testing.expect(add_header(&duplicate.headers, "content-length", "0"));
    try std.testing.expect(!add_header(&duplicate.headers, "content-length", "0"));
    var order = Fixture{};
    try order.init(&router, "POST", "/upload");
    try std.testing.expect(add_header(&order.headers, "x-regular", "value"));
    try std.testing.expect(!add_header(&order.headers, ":path", "/late"));
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}

test "body H3: buffered sibling completes while refusal response is pending" {
    var storage = RouterStorage{};
    var router = try radix.Router.init(storage.storage());
    var effects = Effects{};
    const definition = effects.definition();
    try router.route_body(.post, "/upload", &definition);
    try router.route_context(.post, "/buffered", &effects, Effects.buffered);
    var refused = Fixture{};
    try refused.init(&router, "POST", "/upload");
    try refused.attach();
    var sibling = Fixture{};
    try sibling.init(&router, "POST", "/buffered");
    sibling.fake.input = "test";
    try std.testing.expect(add_header(&sibling.headers, "content-length", "4"));
    try sibling.attach();
    try std.testing.expectEqual(@as(u16, 0), sibling.quic.response_status_code);
    sibling.quic.on_read();
    sibling.quic.on_write();
    try std.testing.expectEqualStrings("200", &sibling.fake.status);
    try std.testing.expectEqual(@as(usize, 1), effects.buffered_calls);
    try std.testing.expectEqual(@as(usize, 4), sibling.quic.body_length);
    refused.quic.on_read();
    try refused.expect_refusal();
    refused.quic.on_write();
    try std.testing.expectEqualStrings("503", &refused.fake.status);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
    for (router.body.active) |active| try std.testing.expectEqual(@as(u16, 0), active);
}

test "body H3: ordinary buffered oversized length still fails header completion" {
    var storage = RouterStorage{};
    var router = try radix.Router.init(storage.storage());
    var effects = Effects{};
    try router.route_context(.post, "/buffered", &effects, Effects.buffered);
    var fixture = Fixture{};
    try fixture.init(&router, "POST", "/buffered");
    const field_accepted = add_header(&fixture.headers, "content-length", "9");
    try std.testing.expect(!field_accepted or !fixture.headers.process_header(null));
    try std.testing.expectEqual(@as(u16, 0), fixture.quic.response_status_code);
    try std.testing.expectEqual(@as(usize, 0), effects.buffered_calls);
}

test "body H3: canonical specificity and method selection preserve buffered outcomes" {
    var storage = RouterStorage{};
    var router = try radix.Router.init(storage.storage());
    var effects = Effects{};
    const definition = effects.definition();
    try router.route_body(.post, "/files/:name", &definition);
    try router.route_body(.get, "/head", &definition);
    try router.route_body(.any, "/fallback", &definition);
    try router.route_context(.post, "/files/static", &effects, Effects.buffered);
    try router.route_context(.get, "/files/:name", &effects, Effects.buffered);
    try router.use(&effects, Effects.middleware);

    const Selection = struct { method: []const u8, path: []const u8, expected: u16 };
    const selections = [_]Selection{
        .{ .method = "POST", .path = "/files/value", .expected = 503 },
        .{ .method = "POST", .path = "/files/static", .expected = 200 },
        .{ .method = "GET", .path = "/files/value", .expected = 200 },
        .{ .method = "PUT", .path = "/files/value", .expected = 405 },
        .{ .method = "OPTIONS", .path = "/files/value", .expected = 204 },
        .{ .method = "HEAD", .path = "/head", .expected = 503 },
        .{ .method = "CUSTOM", .path = "/fallback", .expected = 503 },
        .{ .method = "POST", .path = "/absent", .expected = 404 },
        .{ .method = "OPTIONS", .path = "*", .expected = 204 },
    };
    for (selections) |selection| {
        var fixture = Fixture{};
        try fixture.init(&router, selection.method, selection.path);
        try fixture.attach();
        if (selection.expected == 503) {
            try fixture.expect_refusal();
            try std.testing.expectEqual(@as(u8, 0), fixture.headers.request.param_count);
            continue;
        }
        try std.testing.expectEqual(@as(u16, 0), fixture.quic.response_status_code);
        fixture.quic.on_read();
        try std.testing.expectEqual(selection.expected, fixture.quic.response_status_code);
    }
    try std.testing.expectEqual(@as(usize, 6), effects.middleware_calls);
    try std.testing.expectEqual(@as(usize, 2), effects.buffered_calls);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}

test "body H3: QUERY validation and CONNECT keep their rejection precedence" {
    var storage = RouterStorage{};
    var router = try radix.Router.init(storage.storage());
    var effects = Effects{};
    const definition = effects.definition();
    try router.route_body(.query, "/upload", &definition);
    try router.route_body(.any, "/tunnel", &definition);
    try router.use(&effects, Effects.middleware);

    var invalid_query = Fixture{};
    try invalid_query.init(&router, "QUERY", "/upload");
    try invalid_query.attach();
    try std.testing.expectEqual(@as(u16, 0), invalid_query.quic.response_status_code);
    invalid_query.quic.on_read();
    try std.testing.expectEqual(@as(u16, 400), invalid_query.quic.response_status_code);

    var valid_query = Fixture{};
    try valid_query.init(&router, "QUERY", "/upload");
    try std.testing.expect(add_header(&valid_query.headers, "content-type", "application/json"));
    try valid_query.attach();
    try valid_query.expect_refusal();

    var overcap_query = Fixture{};
    try overcap_query.init(&router, "QUERY", "/upload");
    try std.testing.expect(add_header(&overcap_query.headers, "content-length", "9"));
    try std.testing.expect(!overcap_query.headers.process_header(null));

    var extended = Fixture{};
    try extended.init(&router, "CONNECT", "/tunnel");
    try std.testing.expect(add_header(&extended.headers, ":protocol", "websocket"));
    try extended.attach();
    try std.testing.expectEqual(@as(u16, 0), extended.quic.response_status_code);
    extended.quic.on_read();
    try std.testing.expectEqual(@as(u16, 501), extended.quic.response_status_code);

    var overcap_connect = Fixture{};
    try overcap_connect.init(&router, "CONNECT", "/tunnel");
    try std.testing.expect(add_header(&overcap_connect.headers, ":protocol", "websocket"));
    try std.testing.expect(add_header(&overcap_connect.headers, "content-length", "9"));
    try std.testing.expect(!overcap_connect.headers.process_header(null));
    try std.testing.expectEqual(@as(usize, 0), effects.middleware_calls);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}

test "body H3: standalone and default-off decoders retain buffered framing" {
    var storage = radix.DefaultBundle{};
    var router = try radix.Router.init(storage.storage());
    var effects = Effects{};
    try router.route_context(.post, "/buffered", &effects, Effects.buffered);
    var fixture = Fixture{};
    try fixture.init(&router, "POST", "/buffered");
    try std.testing.expect(add_header(&fixture.headers, "content-length", "4"));
    fixture.fake.input = "ab";
    try fixture.attach();
    try std.testing.expectEqual(@as(u16, 0), fixture.quic.response_status_code);
    fixture.quic.on_read();
    try std.testing.expectEqual(@as(u16, 400), fixture.quic.response_status_code);
    try std.testing.expectEqual(@as(usize, 0), effects.buffered_calls);

    var standalone = Fixture{};
    try standalone.init(&router, "POST", "/buffered");
    standalone.headers.router = null;
    try std.testing.expect(add_header(&standalone.headers, "content-length", "9"));
    try std.testing.expect(!standalone.headers.process_header(null));
}

test "body H3: body selection waits for every structural header invariant" {
    var storage = RouterStorage{};
    var router = try radix.Router.init(storage.storage());
    var effects = Effects{};
    const definition = effects.definition();
    try router.route_body(.post, "/upload", &definition);
    var missing = Fixture{};
    try missing.init(&router, "POST", "/upload");
    missing.headers.scheme = null;
    try std.testing.expect(!missing.headers.process_header(null));
    var wrong_protocol = Fixture{};
    try wrong_protocol.init(&router, "POST", "/upload");
    try std.testing.expect(add_header(&wrong_protocol.headers, ":protocol", "websocket"));
    try std.testing.expect(!wrong_protocol.headers.process_header(null));
    var duplicate_pseudo = Fixture{};
    try duplicate_pseudo.init(&router, "POST", "/upload");
    try std.testing.expect(!add_header(&duplicate_pseudo.headers, ":method", "POST"));
    try std.testing.expectEqual(@as(u16, 0), missing.quic.response_status_code);
    try std.testing.expectEqual(@as(u16, 0), wrong_protocol.quic.response_status_code);

    const forbidden = [_][]const u8{ ":path", "content-length", "host", "te", "trailer", "transfer-encoding" };
    for (forbidden) |name| {
        var trailer = Fixture{};
        trailer.headers.reset_trailer(&trailer, Fixture.release_headers, &trailer.header_storage, &.{}, &.{}, capacities);
        try std.testing.expect(!add_header(&trailer.headers, name, "0"));
    }
    var valid_trailer = Fixture{};
    valid_trailer.headers.reset_trailer(&valid_trailer, Fixture.release_headers, &valid_trailer.header_storage, &.{}, &.{}, capacities);
    try std.testing.expect(add_header(&valid_trailer.headers, "x-checksum", "ok"));
    try std.testing.expect(valid_trailer.headers.process_header(null));
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}
