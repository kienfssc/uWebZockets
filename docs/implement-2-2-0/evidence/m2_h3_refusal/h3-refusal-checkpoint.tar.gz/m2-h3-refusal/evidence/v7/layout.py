from pathlib import Path
import json,subprocess,hashlib,sys
root=Path('/workspaces/uWebZockets');out=Path(__file__).resolve().parent;d=root/'.uwz-work/drafts/m2-h3-body-refusal'
for target in ['native','x86_64-linux-musl','aarch64-linux-musl','aarch64-macos','x86_64-windows-gnu','x86-linux-musl']:
 c=json.loads((out.parent/('layout-'+target+'-baseline.command.json')).read_text());a=c['argv'];a=[('-femit-llvm-ir='+str(out/('layout-'+target+'-after.ll')) if x.startswith('-femit-llvm-ir=') else x) for x in a];a[a.index('--cache-dir')+1]='/tmp/uwz-h3-refusal-layout-cache';a[a.index('--global-cache-dir')+1]='/tmp/uwz-multipart-integrated-global';s={n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in ['src/quic/stream.zig','src/quic/engine.zig']};r=subprocess.run(a,cwd=d,capture_output=True);label='layout-'+target+'-after';(out/(label+'.log')).write_bytes(r.stdout+r.stderr);(out/(label+'.json')).write_text(json.dumps({'argv':a,'cwd':str(d),'exit_status':r.returncode,'sources':s},indent=2)+'\n');print(label,r.returncode,flush=True)
 if r.returncode:print(r.stderr.decode()[-2000:],flush=True);sys.exit(r.returncode)
