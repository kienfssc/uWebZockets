from pathlib import Path
import json,subprocess,time,hashlib,sys
root=Path('/workspaces/uWebZockets');out=Path(__file__).resolve().parent;d=root/'.uwz-work/drafts/m2-h3-body-refusal';base=json.loads((out.parent/'green-header-refusal.command.json').read_text())['argv']
paths=['src/quic/stream.zig','src/quic/engine.zig','src/tests/quic_tests.zig']
def hashes():return {n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in paths}
for mode in ['Debug','ReleaseSafe']:
 label='legacy-corrected-'+mode;a=[('-O'+mode if x=='-ODebug' else '-femit-bin=/tmp/uwz-h3-refusal-'+label if x.startswith('-femit-bin=') else x) for x in base];a=['-Mroot=src/tests/quic_tests.zig' if x.startswith('-Mroot=') else x for x in a];a[a.index('--cache-dir')+1]='/tmp/uwz-h3-refusal-cache';a[a.index('--global-cache-dir')+1]='/tmp/uwz-multipart-integrated-global';s=time.monotonic();rec={'argv':a,'cwd':str(d),'source_before':hashes()};print('START',label,flush=True)
 with (out/(label+'-compile.log')).open('wb') as f:r=subprocess.run(a,cwd=d,stdout=f,stderr=subprocess.STDOUT)
 rec.update(exit_status=r.returncode,elapsed_seconds=time.monotonic()-s,source_after=hashes());(out/(label+'-compile.json')).write_text(json.dumps(rec,indent=2)+'\n');print('COMPILE',label,r.returncode,flush=True)
 if r.returncode:print((out/(label+'-compile.log')).read_text()[-7000:],flush=True);sys.exit(r.returncode)
 binary=Path(a[-1].split('=',1)[1]);args=[str(binary)];s=time.monotonic()
 with (out/(label+'-run.log')).open('wb') as f:r=subprocess.run(args,cwd=d,stdout=f,stderr=subprocess.STDOUT)
 rec={'argv':args,'cwd':str(d),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source_bindings':hashes(),'exit_status':r.returncode,'elapsed_seconds':time.monotonic()-s};(out/(label+'-run.json')).write_text(json.dumps(rec,indent=2)+'\n');print('RUN',label,r.returncode,flush=True);print((out/(label+'-run.log')).read_text()[-4000:],flush=True)
 if r.returncode:sys.exit(r.returncode)
