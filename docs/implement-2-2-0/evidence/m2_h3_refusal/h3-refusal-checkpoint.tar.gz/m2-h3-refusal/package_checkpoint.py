from pathlib import Path
import tarfile,hashlib,io,json,gzip,re,os
root=Path('/workspaces/uWebZockets');e=root/'.uwz-work/evidence/h3-body-refusal';out=root/'docs/implement-2-2-0/evidence/m2_h3_refusal';out.mkdir(parents=True,exist_ok=True);d=root/'.uwz-work/drafts/m2-h3-body-refusal'
m=json.loads((e/'v7/delta-source-manifest.json').read_text());files={}
for n in m['changed']:files['overlay/drafts/m2-h3-body-refusal/'+n]=(d/n).read_bytes()
for v in ['v2','v3','v4','v5','v6','v7']:
 for p in (e/v).rglob('*'):
  if p.is_file():files['evidence/'+str(p.relative_to(e))]=p.read_bytes()
files['SCOPE.md']=b'''# Isolated HTTP/3 body-route refusal checkpoint

No production integration or live uploads. Independent review remains pending.
Restore m2-transport-preparation.tar.gz (SHA256 a079931a4c13dac96546390f316e708a8f491c4a2392c6c19be6f1dbcd6a968b), then copy overlay/drafts/m2-h3-body-refusal/ over that archive's corresponding draft directory. All other archived source bytes match, including the initial engine router wiring. The delta manifest and patch bind exact replacements and new files. src/h3_width_support.zig is verification-only; central tests use ordinary test_support.

The final v7 focused and legacy-corrected command records are authoritative. A labeling error initially ran focused cases with legacy-quic labels; legacy-label-correction.json identifies these and the corrected explicit -Mroot commands. The final actual unchanged QUIC suite has 35 tests per mode, not 12. Earlier records preserve test-field compile errors, compatibility regressions, a mistaken output-capacity fixture and the queued-trailer red case. Version directory names identify retained iterations, not an append-only chronological execution ledger.

The legacy ?usize content_length field is preserved; a separate declared u64 value drives route policy. Actual pure Linux32 tests cover eight wire cases without native sockets/event loops. Layout extraction resolves exported LLVM aliases and requires all nine names per target; initial empty dictionaries are not measurements. Baseline is prepared App/R2 source, not current production.

Full combined gates, independent review, live clients, H1 consumer, H2 refusal and actual H3 upload driver remain required. No readf/FIN peek or private lsquic field access is added; header-only classification cannot claim to diagnose an unread end-of-body mismatch. No dependency pin, native cancellation/race probe or live capability activation is included.
'''
files['package_checkpoint.py']=Path(__file__).read_bytes()
patterns=[re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}'),re.compile(rb'github_pat_[A-Za-z0-9_]{20,}')]
secrets=[v.encode() for k,v in os.environ.items() if re.search('TOKEN|SECRET|PASSWORD|API_KEY',k) and len(v)>=16]
for n,b in files.items():
 if any(p.search(b) for p in patterns) or any(s in b for s in secrets):raise SystemExit('credential scan match in '+n)
inv={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in sorted(files.items())};files['INVENTORY.json']=(json.dumps(inv,indent=2)+'\n').encode()
a=out/'h3-refusal-checkpoint.tar.gz'
with a.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for n,b in sorted(files.items()):
    ti=tarfile.TarInfo('m2-h3-refusal/'+n);ti.size=len(b);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(b))
with tarfile.open(a) as t:
 for ti in t.getmembers():
  assert ti.isfile() and not ti.name.startswith('/') and '..' not in Path(ti.name).parts
  n=ti.name.removeprefix('m2-h3-refusal/');assert t.extractfile(ti).read()==files[n]
summary={'date':'2026-10-27','scope':'Isolated HTTP/3 header refusal; not integrated, independent review pending','archive':a.name,'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'archive_bytes':a.stat().st_size,'safe_regular_members':len(files),'inventory_entries':len(inv),'base_archive_sha256':m['recovery_archive_sha256'],'final_sources':m['changed'],'final_results':{'focused_Debug':12,'focused_ReleaseSafe':12,'unchanged_QUIC_Debug':35,'unchanged_QUIC_ReleaseSafe':35,'pure_native_and_Linux32':{'tests_per_target':1,'wire_cases_per_test':8},'target_layout_compiles':6,'fmt':0,'conventions':0,'release':0},'credential_scan':'No retained byte matches to environment credential values or GitHub token patterns','files':inv}
(out/'manifest.json').write_text(json.dumps(summary,indent=2)+'\n');print({k:v for k,v in summary.items() if k not in ['files','final_sources']})
