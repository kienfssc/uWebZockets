# Isolated HTTP/3 body-route refusal checkpoint

No production integration or live uploads. Independent review remains pending.
Restore m2-transport-preparation.tar.gz (SHA256 a079931a4c13dac96546390f316e708a8f491c4a2392c6c19be6f1dbcd6a968b), then copy overlay/drafts/m2-h3-body-refusal/ over that archive's corresponding draft directory. All other archived source bytes match, including the initial engine router wiring. The delta manifest and patch bind exact replacements and new files. src/h3_width_support.zig is verification-only; central tests use ordinary test_support.

The final v7 focused and legacy-corrected command records are authoritative. A labeling error initially ran focused cases with legacy-quic labels; legacy-label-correction.json identifies these and the corrected explicit -Mroot commands. The final actual unchanged QUIC suite has 35 tests per mode, not 12. Earlier records preserve test-field compile errors, compatibility regressions, a mistaken output-capacity fixture and the queued-trailer red case. Version directory names identify retained iterations, not an append-only chronological execution ledger.

The legacy ?usize content_length field is preserved; a separate declared u64 value drives route policy. Actual pure Linux32 tests cover eight wire cases without native sockets/event loops. Layout extraction resolves exported LLVM aliases and requires all nine names per target; initial empty dictionaries are not measurements. Baseline is prepared App/R2 source, not current production.

Full combined gates, independent review, live clients, H1 consumer, H2 refusal and actual H3 upload driver remain required. No readf/FIN peek or private lsquic field access is added; header-only classification cannot claim to diagnose an unread end-of-body mismatch. No dependency pin, native cancellation/race probe or live capability activation is included.
