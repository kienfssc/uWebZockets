const support = @import("test_support");
const Config = support.config.ServerConfig;
const Owner = @typeInfo(@FieldType(support.config.SlabLayout, "upload_owners")).pointer.child;
const config = Config{};
const small = config.with(.{ .max_connections = 2 });
comptime { @setEvalBranchQuota(200000); }
// Valid defaults and an eligible target prove these fixed sizing calls succeed.
export const uwz_cold_v3_layout = [_]u64{
    @sizeOf(support.tcp.TcpConnection), @alignOf(support.tcp.TcpConnection),
    @sizeOf(Owner), @alignOf(Owner),
    config.slab_bytes() catch unreachable,
    config.with(.{ .stream_request_bodies = true }).slab_bytes() catch unreachable,
    small.slab_bytes() catch unreachable,
    small.with(.{ .stream_request_bodies = true }).slab_bytes() catch unreachable,
    @offsetOf(Owner, "pending_headers"),
    @offsetOf(Owner, "body"),
    @offsetOf(Owner, "decoder"),
    @offsetOf(Owner, "read_retirement_completion"),
    @offsetOf(Owner, "write_retirement_completion"),
    @offsetOf(Owner, "retirement_timer"),
    @offsetOf(Owner, "head"),
    @offsetOf(Owner, "route_definition"),
    @offsetOf(Owner, "loop_handle"),
    @offsetOf(Owner, "pending_header_length"),
    @offsetOf(Owner, "ingress_read_offset"),
    @offsetOf(Owner, "ingress_write_offset"),
    @offsetOf(Owner, "route_record_index"),
    @offsetOf(Owner, "callback_phase"),
    @offsetOf(Owner, "read_retirement"),
    @offsetOf(Owner, "write_retirement"),
    @offsetOf(Owner, "read_callback_active"),
    @offsetOf(Owner, "write_callback_active"),
    @offsetOf(Owner, "read_resume_pending"),
    @offsetOf(Owner, "write_resume_pending"),
    @offsetOf(Owner, "close_pending"),
    @offsetOf(Owner, "initialized"),
    if (@hasField(Owner, "head_target")) @offsetOf(Owner, "head_target") else 0,
    if (@hasField(Owner, "delivery_active")) @offsetOf(Owner, "delivery_active") else 0,
    if (@hasField(Owner, "pending_payload")) @offsetOf(Owner, "pending_payload") else 0,
};
