const body = @import("../http/request_body.zig");
const decoder = @import("../http/body_decoder.zig");
const radix = @import("../router/radix.zig");
const parser = @import("../http/parser.zig");
const Request = @import("../http/request.zig").Request;
const Response = @import("../http/response.zig").Response;

/// Physical tail capacity and the chunk-line content bound excluding CRLF.
pub const IngressBounds = struct {
    capacity: usize,
    line_content_limit: usize,
};

/// Mutable caller-owned overflow header views for one admission borrow.
pub const HeaderSlots = struct {
    names: [][]const u8,
    values: [][]const u8,
};

/// Caller-owned capture capacity for one admission borrow.
pub const CaptureSlots = struct {
    names: [][]const u8,
    values: [][]const u8,
};

/// Head, metadata capacity and transport bounds borrowed only during resolution.
pub const HeadInput = struct {
    request: *Request,
    head: parser.HeadReady,
    method: ?radix.HttpMethod,
    headers: HeaderSlots,
    captures: CaptureSlots,
    ingress: ?IngressBounds,
    pending_header_capacity: usize,
    early_data_forbidden: bool,
};

/// Bounded synchronous admission refusals before a body binding is accepted.
pub const AdmissionRefusal = enum { too_early, invalid_query, body_too_large, unavailable };

/// A selected streaming route remains unreserved until the driver arms it.
pub const HeadDecision = union(enum) {
    buffered,
    final,
    reject: AdmissionRefusal,
    stream: radix.BodyMatch,
};

/// Resolution borrows its input and response only for the callback duration.
pub const HeadResolveFn = *const fn (*anyopaque, *const HeadInput, *Response) HeadDecision;

/// Stable App and route owner; both pointers outlive the connection's drain.
pub const HeadTarget = struct {
    context: *anyopaque,
    router: *radix.Router,
    resolve: HeadResolveFn,
};

/// Existing admission/state errors, including an inconsistent rollback owner.
pub const ArmError = radix.BodyAdmissionError || body.BodyStateError || error{BodyAdmissionMissing};

/// Validates retained storage without narrowing a logical wire body length.
pub fn ingress_bounds(
    storage_capacity: usize,
    head_end: usize,
    framing: decoder.Framing,
    header_limit: usize,
) ?IngressBounds {
    if (head_end > storage_capacity) return null;
    const capacity = storage_capacity - head_end;
    const required: usize = switch (framing) {
        .none => 0,
        .content_length => |length| @intFromBool(length != 0),
        .chunked => 3,
    };
    if (capacity < required) return null;
    const line_content_limit = @min(header_limit, capacity -| 2);
    if (framing == .chunked and line_content_limit == 0) return null;
    return .{ .capacity = capacity, .line_content_limit = line_content_limit };
}

/// Transfers one router reservation to common state without callbacks or I/O.
/// Router, route definition and state must stay stable on the owning loop.
/// After success, only BodyState's terminal/reject booleans authorize release.
pub fn reserve_and_arm(
    router: *radix.Router,
    selected: radix.BodyMatch,
    state: *body.BodyState,
    target: body.BodyControlTarget,
    declared: ?u64,
) ArmError!body.BodyControl {
    if (state.phase != .inactive or state.reserved) return error.BodyStateBusy;
    try router.reserve_body_route(selected);
    return state.arm(target, selected.definition.limits, declared) catch |err| {
        // No callback can intervene: this reservation never entered BodyState.
        try router.release_body_route(selected.record_index);
        return err;
    };
}
