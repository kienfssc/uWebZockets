const std = @import("std");
const xev = @import("xev");
const core_loop = @import("loop.zig");
const request_body = @import("../http/request_body.zig");
const body_decoder = @import("../http/body_decoder.zig");
const parser = @import("../http/parser.zig");
const upload = @import("http1_upload.zig");

/// Callback borrow that prevents metadata or application context recycling.
pub const CallbackPhase = enum { none, begin, chunk, end, cancel, admission };
/// Each fd direction acknowledges its own two successive timer boundaries.
pub const RetirementPhase = enum { idle, first, second };

/// Optional startup-owned cold state; no payload or complete Request copy.
/// Its address and inline completion addresses stay fixed until drained deinit.
pub const Http1UploadStorage = struct {
    pending_headers: [2048]u8 = undefined,
    body: request_body.BodyState = .{},
    decoder: body_decoder.BodyDecoder = body_decoder.init(.none, .{}),
    read_retirement_completion: xev.Completion = .{},
    write_retirement_completion: xev.Completion = .{},
    retirement_timer: xev.Timer,
    head: ?parser.HeadReady = null,
    route_definition: ?*const request_body.BodyRoute = null,
    /// Bound only after the owning App and Loop have reached stable storage.
    loop_handle: ?core_loop.LoopHandle = null,
    head_target: ?upload.HeadTarget = null,
    pending_header_length: usize = 0,
    pending_payload: usize = 0,
    /// Offsets are relative to the existing request buffer tail after head_end.
    ingress_read_offset: usize = 0,
    ingress_write_offset: usize = 0,
    route_record_index: u16 = 0,
    callback_phase: CallbackPhase = .none,
    read_retirement: RetirementPhase = .idle,
    write_retirement: RetirementPhase = .idle,
    delivery_active: bool = false,
    read_callback_active: bool = false,
    write_callback_active: bool = false,
    read_resume_pending: bool = false,
    write_resume_pending: bool = false,
    close_pending: bool = false,
    initialized: bool = false,
};

/// Call after core_loop.init selects its backend; this arms no completion.
pub fn init(storage: *Http1UploadStorage) !void {
    try core_loop.require_request_streaming_setup(true);
    storage.* = .{ .retirement_timer = try xev.Timer.init(), .initialized = true };
}

/// Body ownership, callback borrows, close intent and both timers must drain.
pub fn is_drained(storage: *Http1UploadStorage) bool {
    if (!storage.initialized) return false;
    if (storage.loop_handle) |handle| {
        if (handle.owner.failure_fence) |fence| if (fence.failed) return false;
    }
    if (storage.body.phase != .inactive or storage.body.reserved) return false;
    if (storage.callback_phase != .none or storage.close_pending) return false;
    if (storage.read_callback_active or storage.write_callback_active) return false;
    if (storage.read_retirement != .idle or storage.write_retirement != .idle) return false;
    if (storage.read_retirement_completion.state() != .dead) return false;
    if (storage.write_retirement_completion.state() != .dead) return false;
    return true;
}

/// Reclaims request scalars only; old controls remain expired after reuse.
/// Inline timer/completion storage is never reset or moved here.
pub fn reset(storage: *Http1UploadStorage) void {
    if (storage.loop_handle) |handle| _ = handle.raw();
    std.debug.assert(is_drained(storage));
    storage.body = .{ .generation = storage.body.generation };
    storage.decoder = body_decoder.init(.none, .{});
    storage.head = null;
    storage.route_definition = null;
    storage.pending_header_length = 0;
    storage.ingress_read_offset = 0;
    storage.ingress_write_offset = 0;
    storage.route_record_index = 0;
    storage.read_resume_pending = false;
    storage.write_resume_pending = false;
}

/// App shutdown drains the owning loop before releasing this optional slab.
pub fn deinit(storage: *Http1UploadStorage) void {
    if (storage.loop_handle) |handle| _ = handle.raw();
    std.debug.assert(is_drained(storage));
    storage.retirement_timer.deinit();
    storage.initialized = false;
}
