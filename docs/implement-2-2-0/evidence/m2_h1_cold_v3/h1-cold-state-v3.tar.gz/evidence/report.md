# H1 cold-v3 V2 data-only handoff

Final source is `/tmp/uwz-m2-h1-cold-v3`, frozen 1020 files mode0444, source digest `35bcfec2f32c0f0789b534f0832a37b2e3dd543d97ccdbed52655719005d4fb1`. No symlinks or inherited `.zig-cache` remain. `v2-source-manifest.json`, `v2-final.patch` and `snapshots/v2-final-green/` are durable review inputs. `summary.json` contains exact per-check paths and source/input/override stability assertions.

The four-file slice adds accepted named Head contracts in `src/core/http1_upload.zig`, then optional head_target, delivery_active=false, pending_payload=0 and appended CallbackPhase.admission in the existing cold owner. Drain rejects active delivery; the existing callback-phase guard already rejects admission. Drained reset clears pending payload and request cursors while preserving target, loop handle, body generation, timer and both completion contents. `ArmError` and `reserve_and_arm` remain unchanged. Production target defaults null. No resolver is invoked or production-bound. No callbacks, sinks, TCP, decoder/multipart, config arithmetic, scheduling, cancellation, close or lifecycle paths change.

## Red, green and source preservation

The initial test compile fails on missing data contracts. After types/fields only, the actual pure run has 1 pass and 2 expected failures: active delivery erroneously drains; reset retains pending payload19. The minimal guard/reset delta makes all 3 pass. Concrete before-fix four-file code is in `snapshots/behavioral-red/`, verified against original compiler aggregate `c80b72b49276d4a72442d94bbb3110d9be5e51073cc70f4294f922ccaaf46cc8`.

V1 source/evidence is immutable at `versions/v1/`, including its manifest, overlays, diff, report, exact drivers and raw check records. V1 has digest `e60283d77bb0d579e118d806c180e8d67d592d707e0224f73d35d8c2df2ad89b`. Final V2 changes only two static fixture lines in body_app_tests: typed zero for platform-dependent timer.next and its expectEqualDeep check. Both production files and test_support remain byte-identical V1 to V2. The self pointer, timer operation, distinct initialized userdata and dead-state checks remain. The full original 17-test App file is retained byte-for-byte before the three appended pure tests. See `v2-test-only.patch` and `v2-preservation-proof.md`.

## Assigned final verification

| Check | Outcome |
|---|---|
| Focused pure storage, Debug / ReleaseSafe | 3/3 each |
| Whole App, Debug / ReleaseSafe, ordinary OS | 20/20 each |
| Central native / aarch64-macos / x86_64-windows-gnu |ReleaseSafe compile-only, all 0 |
| Full scoped zig fmt / conventions / release metadata |all 0 |
| Isolated graphify update |AST-only 0; temporary output symlink removed; Root graph untouched |
| Existing pure admission, Debug / ReleaseSafe | 7/7 each, retained V1 binding |

All final V2 compiler and execution records bind source `35bcfec2f32c0f0789b534f0832a37b2e3dd543d97ccdbed52655719005d4fb1` before and after, direct module/library inputs before and after, and all 93 immutable c223 xev file hashes before and after. Actual full argv and raw output are stored beside each record. Run records bind the compiled artifact plus binary_before/binary_after equality. The reviewed override remains c223bd886c6a51d2cd60def39dd9a68d701fea73 / tree86c6944f53dc009d7503a9ab0bc873aef3cd7b79; no dependency pin changed.

The actual V1 driver copied os.environ, explicitly set UWZ_TEST_XEV_BACKEND=io_uring, and passed that same env to subprocess.run. Its metadata literal matched the actual assignment; this was not inferred from passing tests. The preserved driver proves it. V2 records env['UWZ_TEST_XEV_BACKEND'] directly and records executable hashes before/after. No other environment values are dumped. `environment-binding-proof.json` binds both implementations.

## Actual compiler-measured layout

| Target | Owner before -> after (align) | Disabled slab before = after | Enabled slab before -> after |
|---|---:|---:|---:|
| Linux native |2840 ->2880 (8) |684177024 |687095424 ->687136384 |
| aarch64 macOS |2808 ->2848 (8) |684095104 |686980736 ->687021696 |
| x86_64 Windows GNU |3000 ->3040 (8) |684676736 |687758976 ->687799936 |

Growth is 40 bytes per enabled owner, 40960 bytes at the default 1024 owners and 80 bytes for two owners. Disabled totals are exact and unchanged. Every old/new field offset is retained in before/after value records and layout-summary.json. Layout arithmetic, capacity and assertions were not changed. V2 only changes a test file outside the layout/admission graphs, so authorized V1 layout/admission evidence remains applicable without remeasurement.

## Preserved failures and discarded preparation inputs

All failures remain separate from final green evidence: initial aggregate sorting assertion (string sorting differed from baseline pathlib component order; all 1020 individual hashes already matched); IR extractor selected an alias rather than the retained constant (compiler0; retained IR reparsed); initial missing contracts; two fixture compile errors (opaque pointer coercion and untagged timer union); actual two behavioral reds; Debug and ReleaseSafe sandbox expected-io_uring/detected-epoll mismatches; and the V1 macOS static timespec fixture compiler error. No assertion or backend expectation was weakened.

The exact c223 override and original native binding were initially absent from /tmp and were restored by Root from retained local Git/archive inputs, not fetched. Root's retranslation attempt receipts remain under `.uwz-work/evidence/restored-foreign-bindings`: sandbox cache failures, successful normal macOS translation, and failed Windows translation missing vc_compat.h. No header/source repair occurred. One preliminary macOS baseline layout used that new successful mac binding before Root identified the retained originals; its record is preserved as before-aarch64-macos, then the measurement was repeated with the original binding as before-original-aarch64-macos. Values match. Authoritative before/after/final graphs use original r2 native/macOS/Windows bindings with hashes in summary.json. No new/zero failed translation output was used by final graphs.

This completes the bounded data-only implementation and its assigned checks. It does not establish native lifecycle correctness or Windows runtime support. No full centralized runtime, full sanitizer/build gate or forbidden native fault/race/cancellation experiment was run. Root owns independent review, integration, packaging, commit and publication.

Root reported the independent bounded V2 review found no actionable findings. Root owns the separate `independent-review.md` receipt.
