# Cold-v3 V1 checkpoint

Frozen source e60283d77bb0d579e118d806c180e8d67d592d707e0224f73d35d8c2df2ad89b,1020 files0444; four-file overlay snapshots/final-green and final.patch. Production and test-support candidate compiled and focused3/3 passed in Debug and ReleaseSafe; healthy20/20 passed with ordinary OS in both modes. Existing pure admission7/7 passed both modes. Native and Windows central compile-only passed; macOS central compile-only failed because static timer.next expects timespec, not integer5. V1 is superseded solely for this test-fixture portability conflict.

Before/after layout is compiler-measured:40 bytes per enabled owner on all targets; default1024 enabled slabs grow40960, disabled totals unchanged. See layout-summary.json and exact field-offset records.

Sandbox healthy runs fail their unchanged requested io_uring assertions when only epoll is available. Ordinary runs retain the same assertions and requested backend. For every execute invocation, the actual driver copied os.environ, assigned env['UWZ_TEST_XEV_BACKEND']='io_uring', and passed env=env to subprocess.run. Therefore its recorded requested backend was actually set, not inferred from results. See the preserved exact driver-final-v1.py. The metadata dictionary used the same literal; V2 will record env['UWZ_TEST_XEV_BACKEND'] directly and include explicit binary before/after identity. No other environment variables are exposed.

All raw failures are retained: preparation aggregate-sort assertion, IR alias extractor error, missing contracts, two fixture type errors, actual two behavioral reds, two sandbox backend mismatches, and the macOS static timespec compiler error. No central native runtime, native cancellation/fault/race/resource probe, pins or root production edits occurred.
