const std = @import("std");
const support = @import("test_support");
const xev = @import("xev");
const config_module = support.config;
const body = support.request_body;
const Request = support.http_request.Request;
const StreamingRequest = support.streaming_request.StreamingRequest;
const Response = support.http_response.Response;
const TestApp = support.app.app(2);
const streaming_setup_eligible = if (support.loop.require_request_streaming_setup(true)) |_| true else |_| false;

test "body App: ineligible setup rejects owned borrowed and cluster construction" {
    const setup_error = if (support.loop.require_request_streaming_setup(true)) |_|
        return
    else |err|
        err;
    const config = config_module.ServerConfig{ .max_connections = 2, .stream_request_bodies = true };
    try std.testing.expectError(setup_error, TestApp.init_configured(std.testing.io, std.testing.allocator, config));
    var slab = [_]u8{0xa5} ** 128;
    const original = slab;
    try std.testing.expectError(setup_error, TestApp.init_from_slab(std.testing.io, std.testing.allocator, &slab, config));
    try std.testing.expectEqualSlices(u8, &original, &slab);
    const Cluster = TestApp.cluster(1);
    try std.testing.expectError(setup_error, Cluster.init_with_options(std.testing.allocator, std.testing.io, config, .{ .worker_count = 0 }));
    try std.testing.expectError(setup_error, Cluster.init_with_worker_count(std.testing.allocator, std.testing.io, config, .{}, 0));
}

test "body App: null upload detach remains an ordinary disabled operation" {
    var connection = support.tcp.TcpConnection{ .socket = undefined };
    support.tcp.bind_upload_owner(&connection, null);
    try std.testing.expect(connection.upload_owner == null);
}

/// A requested backend is an assertion; production init still owns selection.
fn assert_requested_backend() !void {
    const requested = std.c.getenv("UWZ_TEST_XEV_BACKEND") orelse return;
    try std.testing.expectEqualStrings(std.mem.span(requested), @tagName(xev.backend()));
}

/// Counts callbacks to prove registration and policy checks perform no effects.
const SinkState = struct {
    calls: usize = 0,

    fn definition(state: *SinkState, policy: body.BodyMiddlewarePolicy) body.BodyRoute {
        return .{
            .sink = .{ .context = state, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel },
            .limits = .{ .max_body_bytes = 100_000_000, .max_active = 1 },
            .middleware_policy = policy,
        };
    }

    fn begin(context: *anyopaque, _: *const StreamingRequest, _: body.BodyControl) !body.BodyBinding {
        const state: *SinkState = @ptrCast(@alignCast(context));
        state.calls += 1;
        return .{ .context = state };
    }

    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
        const state: *SinkState = @ptrCast(@alignCast(context));
        state.calls += 1;
        return .{ .consumed = bytes.len, .readiness = .ready };
    }

    fn end(context: *anyopaque, _: *const StreamingRequest, _: *Response) !void {
        const state: *SinkState = @ptrCast(@alignCast(context));
        state.calls += 1;
    }

    fn cancel(context: *anyopaque, _: body.BodyCancelReason) void {
        const state: *SinkState = @ptrCast(@alignCast(context));
        state.calls += 1;
    }

    fn middleware(context: *anyopaque, _: *Request, _: *Response) support.radix.MiddlewareResult {
        const state: *SinkState = @ptrCast(@alignCast(context));
        state.calls += 1;
        return .continue_dispatch;
    }
};

test "body App: pure body registry remains independent of transport eligibility" {
    var bundle: support.radix.Bundle(.{
        .stream_request_bodies = true,
        .max_nodes = 4,
        .max_pattern_routes = 0,
        .max_route_path_size = 64,
        .registry_storage_size = 64,
    }) = .{};
    var router = try support.radix.Router.init(bundle.storage());
    var state = SinkState{};
    const route = state.definition(.reject_legacy);
    try router.route_body(.post, "/upload", &route);
    try std.testing.expect(router.match("/upload", .post).?.body_match.?.definition == &route);
    try std.testing.expectEqual(@as(usize, 0), state.calls);
}

test "body App: streaming config defaults off and overrides propagate" {
    const base = config_module.ServerConfig{};
    try std.testing.expect(!base.stream_request_bodies);
    const enabled = base.with(.{ .stream_request_bodies = true });
    try std.testing.expect(enabled.stream_request_bodies);
    try std.testing.expect(enabled.router_capacities().stream_request_bodies);
    try std.testing.expect(!enabled.with(.{ .stream_request_bodies = false }).stream_request_bodies);
    const base_builder = support.builder.Server.builder(std.testing.io);
    try std.testing.expect(!base_builder.with_stream_request_bodies(false).configuration().stream_request_bodies);
    if (comptime streaming_setup_eligible) {
        const builder = base_builder.with_stream_request_bodies(true);
        try std.testing.expect(builder.configuration().stream_request_bodies);
        try std.testing.expect(!builder.with_stream_request_bodies(false).configuration().stream_request_bodies);
    } else {
        try std.testing.expectError(error.InvalidTransportConfiguration, enabled.validate());
    }
}

test "body App: enabled slab contains typed owners before trailing router" {
    inline for (.{ false, true }) |enabled| {
        const configuration = config_module.ServerConfig{ .max_connections = 2, .stream_request_bodies = enabled };
        if (comptime enabled and !streaming_setup_eligible) {
            try std.testing.expectError(error.InvalidTransportConfiguration, configuration.slab_bytes());
            continue;
        }
        const size = try configuration.slab_bytes();
        const slab = try std.testing.allocator.alignedAlloc(u8, .fromByteUnits(config_module.slab_alignment), size);
        defer std.testing.allocator.free(slab);
        const layout = try config_module.carve(slab, configuration);
        try std.testing.expectEqual(@as(usize, if (enabled) 2 else 0), layout.upload_owners.len);
        try std.testing.expectEqual(@intFromPtr(slab.ptr) + size, @intFromPtr(layout.router_storage.ptr) + layout.router_storage.len);
        if (enabled) {
            const Owner = @typeInfo(@TypeOf(layout.upload_owners)).pointer.child;
            const owner_start = @intFromPtr(layout.upload_owners.ptr);
            const owner_end = owner_start + @sizeOf(Owner) * layout.upload_owners.len;
            try std.testing.expectEqual(@as(usize, 0), owner_start % @alignOf(Owner));
            try std.testing.expect(owner_start >= @intFromPtr(slab.ptr));
            try std.testing.expect(owner_end <= @intFromPtr(layout.router_storage.ptr));
        }
    }
}

test "body App: startup stays unarmed until stable handle binding" {
    inline for (.{ false, true }) |enabled| {
        var allocations = std.testing.FailingAllocator.init(std.testing.allocator, .{ .fail_index = 1, .resize_fail_index = 0 });
        if (comptime enabled and !streaming_setup_eligible) {
            try std.testing.expectError(error.InvalidTransportConfiguration, TestApp.init_configured(std.testing.io, allocations.allocator(), .{ .max_connections = 2, .stream_request_bodies = enabled }));
            try std.testing.expectEqual(@as(usize, 0), allocations.allocations);
            try std.testing.expect(!allocations.has_induced_failure);
            continue;
        }
        var server = try TestApp.init_configured(std.testing.io, allocations.allocator(), .{ .max_connections = 2, .stream_request_bodies = enabled });
        defer server.deinit();
        try assert_requested_backend();
        try std.testing.expect(server.loop.failure_fence == null);
        try std.testing.expectEqual(@as(usize, if (enabled) 2 else 0), server.upload_owners.len);
        for (server.upload_owners) |*owner| {
            try std.testing.expect(owner.initialized);
            try std.testing.expect(owner.loop_handle == null);
            try std.testing.expectEqual(.dead, owner.read_retirement_completion.state());
            try std.testing.expectEqual(.dead, owner.write_retirement_completion.state());
        }
        const first = server.loop_handle();
        const second = server.loop_handle();
        try std.testing.expect(first.owner == &server.loop);
        try std.testing.expect(first.owner == second.owner);
        try std.testing.expect(first.raw() == server.loop.get_xev_loop());
        if (enabled) {
            try std.testing.expect(server.loop.failure_fence.? == &server.upload_failure_fence);
            for (server.upload_owners) |*owner| {
                try std.testing.expect(owner.loop_handle.?.owner == first.owner);
                try std.testing.expect(owner.loop_handle.?.raw() == first.raw());
            }
        } else try std.testing.expect(server.loop.failure_fence == null);
        server.deinit();
        try std.testing.expectEqual(@as(usize, 1), allocations.allocations);
        try std.testing.expectEqual(@as(usize, 1), allocations.deallocations);
        try std.testing.expect(!allocations.has_induced_failure);
    }
}

test "body App: registration copies path and borrows immutable route without allocation" {
    if (comptime !streaming_setup_eligible) return error.SkipZigTest;
    var allocations = std.testing.FailingAllocator.init(std.testing.allocator, .{ .fail_index = 1, .resize_fail_index = 0 });
    var server = try TestApp.init_configured(std.testing.io, allocations.allocator(), .{ .max_connections = 2, .stream_request_bodies = true });
    defer server.deinit();
    try assert_requested_backend();
    var state = SinkState{};
    const route = state.definition(.reject_legacy);
    var path = "/upload".*;
    try std.testing.expect(try server.route_body(.post, &path, &route) == &server);
    @memset(&path, 'x');
    const selected = server.router.match("/upload", .post).?.body_match.?;
    try std.testing.expect(selected.definition == &route);
    try server.router.reserve_body_route(selected);
    try server.router.release_body_route(selected.record_index);
    try std.testing.expectError(error.RouteAlreadyRegistered, server.route_body(.post, "/upload", &route));
    try std.testing.expectEqual(@as(usize, 0), state.calls);
    try std.testing.expectEqual(@as(usize, 1), allocations.allocations);
    try std.testing.expect(!allocations.has_induced_failure);
}

test "body App: disabled registration and limits preserve router records" {
    var state = SinkState{};
    const route = state.definition(.reject_legacy);
    var server = try TestApp.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2 });
    defer server.deinit();
    try assert_requested_backend();
    try std.testing.expectError(error.BodyStreamingDisabled, server.route_body(.post, "/disabled", &route));
    try std.testing.expectEqual(@as(usize, 0), server.router.route_record_count);
    var enabled_router: support.radix.Bundle(.{
        .stream_request_bodies = true,
        .max_nodes = 4,
        .max_pattern_routes = 0,
        .max_route_path_size = 64,
        .registry_storage_size = 64,
    }) = .{};
    server.router = try support.radix.Router.init(enabled_router.storage());
    try std.testing.expectError(error.BodyStreamingDisabled, server.route_body(.post, "/injected", &route));
    server.routes_locked = true;
    try std.testing.expectError(error.RoutesLocked, server.route_body(.post, "bad path", &route));
    try std.testing.expectEqual(@as(usize, 0), server.router.route_record_count);
}

test "body App: middleware policy registration and late use remain effect free" {
    if (comptime !streaming_setup_eligible) return error.SkipZigTest;
    var server = try TestApp.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer server.deinit();
    try assert_requested_backend();
    var state = SinkState{};
    const route = state.definition(.reject_legacy);
    const certified = state.definition(.headers_only);
    _ = try server.route_body(.post, "/early", &route);
    _ = try server.use(&state, SinkState.middleware);
    const early = server.router.match("/early", .post).?.body_match.?;
    try std.testing.expectError(error.BodyMiddlewareIncompatible, server.router.check_body_route(early));
    try std.testing.expectError(error.BodyMiddlewareIncompatible, server.route_body(.post, "/rejected", &route));
    _ = try server.route_body(.post, "/certified", &certified);
    try server.router.check_body_route(server.router.match("/certified", .post).?.body_match.?);
    try std.testing.expectEqual(@as(usize, 0), state.calls);
    var invalid = certified;
    invalid.limits.max_active = 0;
    try std.testing.expectError(error.InvalidBodyLimits, server.route_body(.post, "/invalid", &invalid));
    try std.testing.expectEqual(@as(usize, 2), server.router.route_record_count);
}

test "body App: listen binds policy before accept and locks registration" {
    if (comptime !streaming_setup_eligible) return error.SkipZigTest;
    var server = try TestApp.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true, .enable_dev_log = false });
    defer server.deinit();
    try assert_requested_backend();
    var state = SinkState{};
    const route = state.definition(.reject_legacy);
    try server.listen("127.0.0.1", 0);
    try std.testing.expect(server.routes_locked);
    try std.testing.expect(server.loop.failure_fence.? == &server.upload_failure_fence);
    try std.testing.expectError(error.RoutesLocked, server.route_body(.post, "invalid", &route));
    try std.testing.expectEqual(@as(usize, 0), server.router.route_record_count);
    try server.shutdown();
}

test "body App: shutdown before listen binds stable policy and drains cold owners" {
    if (comptime !streaming_setup_eligible) return error.SkipZigTest;
    var server = try TestApp.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer server.deinit();
    try assert_requested_backend();
    try std.testing.expect(server.loop.failure_fence == null);
    try server.shutdown();
    try std.testing.expect(server.loop.failure_fence.? == &server.upload_failure_fence);
    for (server.upload_owners) |*owner| {
        try std.testing.expect(owner.loop_handle.?.owner == &server.loop);
        try std.testing.expectEqual(.inactive, owner.body.phase);
    }
}

test "body App: startup allocation failure leaves caller allocator clean" {
    var allocations = std.testing.FailingAllocator.init(std.testing.allocator, .{ .fail_index = 0 });
    const expected = if (comptime streaming_setup_eligible) error.OutOfMemory else error.InvalidTransportConfiguration;
    try std.testing.expectError(expected, TestApp.init_configured(std.testing.io, allocations.allocator(), .{ .max_connections = 2, .stream_request_bodies = true }));
    try std.testing.expectEqual(@as(usize, 0), allocations.allocations);
    try std.testing.expectEqual(@as(usize, 0), allocations.deallocations);
    if (comptime !streaming_setup_eligible) try std.testing.expect(!allocations.has_induced_failure);
}

test "body App: run binds before wakeup and shutdown requested before run" {
    if (comptime !streaming_setup_eligible) return error.SkipZigTest;
    var server = try TestApp.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true, .enable_dev_log = false });
    defer server.deinit();
    try assert_requested_backend();
    server.request_shutdown();
    try server.run();
    try std.testing.expect(server.loop.failure_fence.? == &server.upload_failure_fence);
    try std.testing.expect(server.shutting_down);
    try std.testing.expect(!server.cluster_wakeup_active);
}

test "body App: signal watcher binds policy before arming" {
    if (comptime !streaming_setup_eligible) return error.SkipZigTest;
    var server = try TestApp.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer server.deinit();
    try assert_requested_backend();
    try server.catch_shutdown_signals();
    try std.testing.expect(server.loop.failure_fence.? == &server.upload_failure_fence);
    try std.testing.expect(server.signal_watcher != null);
    try server.shutdown();
    try std.testing.expect(server.signal_watcher.?.is_drained());
}

/// One ordinary buffered exchange verifies the first acquired slot's association.
const ConnectionProbe = struct {
    server: *TestApp,
    handled: bool = false,
    owner_matched: bool = false,
    response_ok: bool = false,
    released: bool = false,
    failure: ?anyerror = null,

    fn handle(context: *anyopaque, _: *Request, response: *Response) void {
        const state: *ConnectionProbe = @ptrCast(@alignCast(context));
        state.handled = true;
        const connection = response.target.tcp;
        const index = state.server.pool.index_of(connection).?;
        state.owner_matched = if (state.server.upload_owners.len == 0)
            connection.upload_owner == null
        else
            connection.upload_owner == &state.server.upload_owners[index] and
                connection.upload_owner.?.loop_handle.?.owner == &state.server.loop;
        response.end("200 OK", "ok") catch |err| {
            state.failure = err;
            state.server.request_shutdown();
        };
    }

    fn outcome(context: *anyopaque, result: support.client.FetchOutcome) void {
        const state: *ConnectionProbe = @ptrCast(@alignCast(context));
        state.response_ok = switch (result) {
            .response => |response| response.status == 200 and std.mem.eql(u8, response.body, "ok"),
            .failure => false,
        };
        state.server.request_shutdown();
    }

    fn release(context: *anyopaque, _: *support.client.ClientConnection) void {
        const state: *ConnectionProbe = @ptrCast(@alignCast(context));
        state.released = true;
    }
};

test "body App: first accepted slot binds owner and shared client retains explicit handle" {
    inline for (.{ false, true }) |enabled| {
        var allocations = std.testing.FailingAllocator.init(std.testing.allocator, .{ .fail_index = 1, .resize_fail_index = 0 });
        if (comptime enabled and !streaming_setup_eligible) {
            try std.testing.expectError(error.InvalidTransportConfiguration, TestApp.init_configured(std.testing.io, allocations.allocator(), .{ .max_connections = 2, .stream_request_bodies = enabled, .enable_dev_log = false }));
            try std.testing.expectEqual(@as(usize, 0), allocations.allocations);
            try std.testing.expect(!allocations.has_induced_failure);
            continue;
        }
        var server = try TestApp.init_configured(std.testing.io, allocations.allocator(), .{ .max_connections = 2, .stream_request_bodies = enabled, .enable_dev_log = false });
        defer server.deinit();
        try assert_requested_backend();
        var state = ConnectionProbe{ .server = &server };
        _ = try server.get_context("/probe", &state, ConnectionProbe.handle);
        try server.listen("127.0.0.1", 0);
        var client = support.client.ClientConnection{};
        client.timer = try xev.Timer.init();
        defer client.timer.deinit();
        const handle = server.loop_handle();
        try client.start(.{
            .loop = handle.raw(),
            .loop_handle = handle,
            .io = std.testing.io,
            .request = .{ .host = "127.0.0.1", .path = "/probe" },
            .options = .{ .port = try support.tcp.listener_port(&server.listeners[0]) },
            .ssl_ctx = null,
            .context = &state,
            .callback = ConnectionProbe.outcome,
            .release_context = &state,
            .release_callback = ConnectionProbe.release,
            .slot_index = 0,
        });
        try server.run();
        try std.testing.expect(state.failure == null);
        try std.testing.expect(state.handled);
        try std.testing.expect(state.owner_matched);
        try std.testing.expect(state.response_ok);
        try std.testing.expect(state.released);
        try std.testing.expectEqual(@as(usize, 0), server.pool.count_active());
        try std.testing.expect(client.loop_handle.?.owner == &server.loop);
        try std.testing.expectEqual(@as(usize, 1), allocations.allocations);
        try std.testing.expect(!allocations.has_induced_failure);
    }
}

test "body App: undersized caller slab retains caller ownership on failure" {
    const configuration = config_module.ServerConfig{ .max_connections = 2, .stream_request_bodies = true };
    if (comptime !streaming_setup_eligible) {
        var slab = [_]u8{0xa5} ** 128;
        const original = slab;
        try std.testing.expectError(error.InvalidTransportConfiguration, TestApp.init_from_slab(std.testing.io, std.testing.allocator, &slab, configuration));
        try std.testing.expectEqualSlices(u8, &original, &slab);
        return;
    }
    const size = try configuration.slab_bytes();
    var allocations = std.testing.FailingAllocator.init(std.testing.allocator, .{ .fail_index = 1 });
    const allocator = allocations.allocator();
    const slab = try allocator.alignedAlloc(u8, .fromByteUnits(config_module.slab_alignment), size);
    defer allocator.free(slab);
    @memset(slab, 0xa5);
    try std.testing.expectError(error.SlabTooSmall, TestApp.init_from_slab(std.testing.io, allocator, slab[0 .. size - 1], configuration));
    try std.testing.expectEqual(@as(usize, 1), allocations.allocations);
    try std.testing.expectEqual(@as(usize, 0), allocations.deallocations);
    for (slab) |byte| try std.testing.expectEqual(@as(u8, 0xa5), byte);
}

test "body App: cluster signal startup binds only stable worker storage" {
    if (comptime !streaming_setup_eligible) return error.SkipZigTest;
    const builder = support.builder.Server.builder(std.testing.io)
        .with_max_clients(2)
        .with_stream_request_bodies(true)
        .with_dev_log(false);
    var cluster = try builder.build_cluster(std.testing.allocator, 2, .{});
    defer cluster.deinit();
    try assert_requested_backend();
    for (cluster.workers) |*worker| {
        try std.testing.expect(worker.loop.failure_fence == null);
        try std.testing.expectEqual(@as(usize, 2), worker.upload_owners.len);
    }
    try cluster.catch_shutdown_signals();
    const first = &cluster.workers[0];
    try std.testing.expect(first.loop.failure_fence.? == &first.upload_failure_fence);
    try std.testing.expect(cluster.workers[1].loop.failure_fence == null);
    for (first.upload_owners) |*owner| try std.testing.expect(owner.loop_handle.?.owner == &first.loop);
    try cluster.deinit_checked();
}

/// These fixtures never initialize, submit or inspect native loop storage.
fn inert_upload_timer() xev.Timer {
    if (comptime xev.dynamic) return .{ .backend = .{ .io_uring = .{} } };
    return .{};
}

/// Only its address is retained; no resolver runs in these storage tests.
fn inert_head_resolve(_: *anyopaque, _: *const support.http1_upload.HeadInput, _: *Response) support.http1_upload.HeadDecision {
    return .buffered;
}

test "body App: cold v3 defaults keep admission and delivery inactive" {
    var owner = support.http1_upload_storage.Http1UploadStorage{ .retirement_timer = inert_upload_timer(), .initialized = true };
    try std.testing.expect(owner.head_target == null);
    try std.testing.expect(!owner.delivery_active);
    try std.testing.expectEqual(@as(usize, 0), owner.pending_payload);
    try std.testing.expect(support.http1_upload_storage.is_drained(&owner));
}

test "body App: cold v3 drain rejects delivery and admission independently" {
    var owner = support.http1_upload_storage.Http1UploadStorage{ .retirement_timer = inert_upload_timer(), .initialized = true };
    owner.delivery_active = true;
    try std.testing.expect(!support.http1_upload_storage.is_drained(&owner));
    owner.delivery_active = false;
    owner.callback_phase = .admission;
    try std.testing.expect(!support.http1_upload_storage.is_drained(&owner));
    owner.callback_phase = .none;
    try std.testing.expect(support.http1_upload_storage.is_drained(&owner));
}

test "body App: cold v3 reset clears request accounting and preserves stable owners" {
    var context: u8 = 17;
    var read_context: u8 = 29;
    var write_context: u8 = 43;
    var router = support.radix.Router{};
    var fence = support.loop.IoFailureFence{};
    // raw() reads only failure_fence and takes the unobserved xev_loop address.
    var loop = support.loop.Loop{ .xev_loop = undefined, .failure_fence = &fence };
    var sink_state = SinkState{};
    const route = sink_state.definition(.reject_legacy);
    var owner = support.http1_upload_storage.Http1UploadStorage{
        .retirement_timer = inert_upload_timer(),
        .initialized = true,
        .head_target = .{ .context = &context, .router = &router, .resolve = inert_head_resolve },
        .loop_handle = .{ .owner = &loop },
        .body = .{ .generation = 71 },
        .decoder = support.http_body_decoder.init(.chunked, .{}),
        .head = .{ .framing = .chunked, .header_end = 37, .headers = .{ .names = &.{}, .values = &.{} } },
        .route_definition = &route,
        .pending_payload = 19,
        .pending_header_length = 11,
        .ingress_read_offset = 7,
        .ingress_write_offset = 23,
        .route_record_index = 3,
        .read_resume_pending = true,
        .write_resume_pending = true,
    };
    if (comptime xev.dynamic) {
        owner.read_retirement_completion.value = .{ .io_uring = .{ .userdata = &read_context, .op = .{ .timer = .{ .next = .{ .sec = 5, .nsec = 7 } } } } };
        owner.write_retirement_completion.value = .{ .io_uring = .{ .userdata = &write_context } };
    } else {
        owner.read_retirement_completion = .{ .userdata = &read_context, .op = .{ .timer = .{ .next = 5, .c = &owner.read_retirement_completion } } };
        owner.write_retirement_completion = .{ .userdata = &write_context };
    }
    try std.testing.expect(support.http1_upload_storage.is_drained(&owner));
    support.http1_upload_storage.reset(&owner);
    try std.testing.expectEqual(@as(usize, 0), owner.pending_payload);
    try std.testing.expectEqual(@as(usize, 0), owner.pending_header_length);
    try std.testing.expectEqual(@as(usize, 0), owner.ingress_read_offset);
    try std.testing.expectEqual(@as(usize, 0), owner.ingress_write_offset);
    try std.testing.expectEqual(@as(u16, 0), owner.route_record_index);
    try std.testing.expect(!owner.read_resume_pending and !owner.write_resume_pending);
    try std.testing.expect(owner.head == null and owner.route_definition == null);
    try std.testing.expectEqual(.done, owner.decoder.state);
    try std.testing.expectEqual(@as(u64, 71), owner.body.generation);
    try std.testing.expect(owner.head_target.?.context == &context);
    try std.testing.expect(owner.head_target.?.router == &router);
    try std.testing.expect(owner.head_target.?.resolve == inert_head_resolve);
    try std.testing.expect(owner.loop_handle.?.owner == &loop);
    try std.testing.expectEqual(.dead, owner.read_retirement_completion.state());
    try std.testing.expectEqual(.dead, owner.write_retirement_completion.state());
    if (comptime xev.dynamic) {
        try std.testing.expectEqual(.io_uring, std.meta.activeTag(owner.retirement_timer.backend));
        try std.testing.expect(owner.read_retirement_completion.value.io_uring.userdata == &read_context);
        try std.testing.expectEqual(@as(isize, 5), owner.read_retirement_completion.value.io_uring.op.timer.next.sec);
        try std.testing.expectEqual(@as(isize, 7), owner.read_retirement_completion.value.io_uring.op.timer.next.nsec);
        try std.testing.expect(owner.write_retirement_completion.value.io_uring.userdata == &write_context);
        try std.testing.expectEqual(.noop, std.meta.activeTag(owner.write_retirement_completion.value.io_uring.op));
    } else {
        try std.testing.expect(owner.read_retirement_completion.userdata == &read_context);
        try std.testing.expectEqual(@as(u64, 5), owner.read_retirement_completion.op.timer.next);
        try std.testing.expect(owner.read_retirement_completion.op.timer.c == &owner.read_retirement_completion);
        try std.testing.expect(owner.write_retirement_completion.userdata == &write_context);
        try std.testing.expectEqual(.noop, std.meta.activeTag(owner.write_retirement_completion.op));
    }
    try std.testing.expect(support.http1_upload_storage.is_drained(&owner));
}
