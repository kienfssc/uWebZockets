# Cold-v3 pure storage preservation proof

Final V2 source is frozen at 35bcfec2f32c0f0789b534f0832a37b2e3dd543d97ccdbed52655719005d4fb1. Its sole V1-to-V2 change initializes the static timer deadline with its actual native type and checks typed zero using expectEqualDeep; no OS branch, raw byte comparison or native call was added.

`reset` in src/core/http1_upload_storage.zig invokes `LoopHandle.raw`, checks `is_drained`, then assigns only body request state (preserving generation), decoder, head, route_definition, pending_header_length, pending_payload, raw ingress cursors, route_record_index and the two resume flags. It never assigns head_target, loop_handle, retirement_timer or either inline completion. Generation stays71 in the caller-owned test.

`LoopHandle.raw` in src/core/loop.zig lines117-119 invokes require_healthy and returns &self.owner.xev_loop. require_healthy lines150-153 reads only initialized failure_fence and the initialized fence.failed flag. The pure fixture's uninitialized xev_loop payload is never read, copied, compared or passed to native APIs. thread_pool uses its null default. No native loop initialization or native timer operation occurs.

Reviewed c223 DynamicCompletion.state (src/dynamic.zig lines270-274) switches the completion's own tagged value and calls the inner state(). It never consults global dynamic.backend. Therefore explicit inert io_uring completion values remain valid when the healthy suite has selected epoll. Their dead flags, nonnull distinct caller-owned userdata and timer/noop operation data are inspected without invoking callbacks.

Reviewed c223 TimerLoop (src/watcher/timer.zig lines15 onward) has declarations only, no instance payload fields. TimerDynamic.backend is an untagged union of these empty watcher types. The fixture explicitly initializes the io_uring union arm; its test accesses only @TypeOf to verify that arm is zero-sized, never a runtime tag or raw bytes. Source proof above supplies preservation; there is no timer payload sentinel to invent.

Source hashes: final-source-manifest.json and snapshots/final-green/manifest.json bind the four changed sources; copy-manifest.json binds the remaining1016. Compiler records bind all93 c223 files, its commit/tree and direct compiler/module/library inputs before and after each command. Full raw compiler/test outputs are retained, including fixture compiler errors, behavioral reds and sandbox backend mismatches. No forbidden native cancellation/interleaving/fault/resource probes were constructed or run.
