# Scoped ordinary client correction review

Verdict: Approved. No actionable findings in the reviewed client correction or run wrapper. This is source review, not a corrected runtime result.

Reviewed probe.py SHA-256 `e5bc2059b601243a53c829c52680c5b56de3699ec8bf6003d8c470c935f9f112` and run_bound.py SHA-256 `05dabd4d99a6eb3605360e14b4e675ad732d314564ed41b0ea6e89bbcf437283`.

- Failed begin permits clean EOF before any response header, consistent with the supplied ruling and ADR's failed-begin ownership contract. A reset or partial header still fails. Exact attempt/failed-begin deltas, no accepted binding/end/cancel, inactive state, and a successful same-route retry remain required.
- Declared-size refusal requires exactly 413; quota refusal requires exactly 503. Both prohibit interim Continue and begin ownership.
- The original 33-byte chunk payload and trailer sequence remains, with staged writes and recorded partial-write outcomes. A write failure alone cannot pass: the client must parse a complete empty 413. Reset before completion propagates as failure; clean EOF and reset after complete 413 are recorded distinctly, and surplus bytes fail.
- The additional size-line-only case sends no rejected payload and requires successful size-line transmission, complete 413, zero accepted payload, exact terminal accounting and same-route retry.
- Independently compared function ASTs: payload, send_payload, upload, file_case and pipeline are unchanged. Bytecode suppression precedes execution of the imported helper. The suite now contains 21 cases.
- The run wrapper requires the explicitly supplied reviewed client hash, original successful build inputs/source/binary, and the complete 93-file override manifest before launch. It records pre/post hashes, fails on mutation, and catches post-audit errors before copying raw result/server evidence and writing the binding record. Runner output is written directly to durable evidence.

Preserved initial evidence remains 18/20, with real failures for failed_begin and limit_chunked_over33. Its exact-100M fixed/chunked and both real-file checks passed; recorded child status is zero, child reaped is true, forced kill is false, and the post-deinit marker is present. The correction does not relabel that run as success.

Limits: no harness import, build, server execution, native probe or cancellation/fault experiment was performed in this review. Corrected runtime outcomes and post-run input integrity remain to be established by Root's authorized ordinary run. No transport architecture or unrelated acceptance gate was reopened.
