# Task 3b: corrected v1 client prepared; new features remain paused

Status: Root-approved CLIENT-ONLY correction is ready for independent review and
Root-owned ordinary runtime. No corrected client, server or port operation was
executed by this worker. No compilation was necessary: the original v1 server
profile and ReleaseSafe binary remain the inputs. V1 profile/probe/compile
SHA256 values match their preimages. Root's original two failures remain intact.

Corrected source/evidence: `.uwz-work/evidence/h1-plaintext/integration-corrected/`.
It contains `probe.py`, exact v1 client preimage, unified `probe.diff`, syntax log
and `preparation.json` with identities/counts. Earlier uncompiled Task3b feature
work remains separately preserved in `integration-v2`; no new feature work was
added after Root paused it. The preceding diagnostic report is retained as
`integration-corrected/task-3b-paused-report.preimage.md`.

## Actual v1 findings and binding contract

Root's retained v1 result had 20 cases, 18 passed and these two raw failures:

```text
limit_chunked_over33: ConnectionResetError(104, 'Connection reset by peer')
failed_begin: EOFError('EOF before response header')
```

This worker inspected those records and source, but did not run them. The
original Task3a report incorrectly said21; its list actually contained20. The
corrected list contains21: original20 plus one separate size-line-only33 case.
The original report/records were not modified or reclassified.

ADR0008:114-117 specifies failed-begin rollback, admission release and no cancel;
it promises no particular HTTP response. Root's coherent
`src/core/tcp_upload.zig:144-148` rejects/releases and closes before send_continue.
The v1 final-response requirement was therefore a harness defect.

ADR0008:94-95 requires413 for logical oversize before accepting offending bytes;
quota refusal at line94 requires503. `src/http/body_decoder.zig:145-161` detects
chunk33 at limit32 while parsing its size line, before payload acceptance.
`src/core/tcp_upload.zig:340-353` cancels body_too_large and queues413 then closes
after flush. V1 sent rejected content/trailers, and its post-response EOF check
could throw reset after parsing413 and discard that evidence. The retained
exception alone cannot establish whether413 was actually received.

Root explicitly approved the correction: preserve complete413 before closure;
distinguish a later reset from malformed framing; never pass reset before a
complete413; preserve the original overrun case and add a separate size-line-only
case. No implementation fix or old-result pass is inferred.

## Exact client changes and self-review

- `response(..., trace=...)` optionally records read stage, every complete
  interim/final head, and a completed framed final response BEFORE later closure
  checks. Existing caller behavior and framing parser remain unchanged when no
  trace is passed. A partial/malformed response cannot populate complete_response.
- Original `limit_chunked_over33` keeps the same size extension, deterministic
  33-byte payload, CRLF, zero chunk and ordinary trailer send sequence. Bounded
  recorded sends distinguish actual bytes handed to the socket from intended
  content, preserve partial write counts/payload hex, stage and OSError, and still
  attempt to read413 after an interrupted send. It requires a completely parsed
  empty413. A reset before head or framed body completion remains a failed case
  with its stage/evidence, not an accepted terminal result.
- Only AFTER complete413 is saved, the client checks for surplus and records
  either clean EOF or reset_after_complete413 with errno/error. Any returned
  surplus byte fails. A reset is not described as clean EOF. Root approved this
  distinction for rejected-content closure. Other successful/file/pipeline cases
  retain their strict clean EOF checks.
- Separate `limit_chunk_size_only33` sends only `21\r\n` after its real100, then
  requires complete413 before any offending content/trailer. Its record declares
  chunk33 and actual sent logical payload0. It checks the size-line write actually
  completed; it does not represent the refusal as a successful33-byte upload.
- Both chunked limit cases require one begin attempt/accepted binding, no failed
  begin, one body_too_large cancel, no end, zero accepted payload and inactive
  binding. Each then performs an actual successful max32 request on the same
  route, checking admission became reusable and no extra cancel appeared.
- Dedicated `failed_begin` accepts a clean EOF before any response header. If an
  actual framed error response exists, it records it and requires no100/success
  plus clean EOF; it does not require an invented status. Reset before headers,
  partial headers,100 followed by EOF, malformed response and surplus still fail.
  It asserts exactly one begin attempt/refusal, no accepted binding/end/cancel,
  inactive binding and zero sent content. An actual successful same-route request
  then proves reservation release, with exact begin/end/refusal/cancel deltas.
- Declared refusal now requires final413 without100. Held-route quota refusal
  requires final503 without100. Their prior >=400 assertions were strengthened,
  and both require zero begin attempts and no accepted binding/end/cancel.
- Per-case exception records retain the mutable read/write evidence, including a
  previously completed413, rather than replacing it with only an exception.
- `sys.dont_write_bytecode = True` precedes helper `exec_module`; actual future
  records include that state. No source cache is created by the main script
  execution. Root separately audited/removed only the v1 generated helper cache
  and reported restored coherent digest acff...254b; this worker did not alter
  combined sources or independently claim that cleanup.

The exact100000000 payload generation, ordinary upload/send functions, fixed and
chunked cases, file comparison, file->health/file->EOF cases and stream pipelines
remain. AST comparison verifies `payload`, `send_payload`, `upload`, `file_case`
and `pipeline` are unchanged from v1. Sink errors/malformed framing/public cancel
remain in the original matrix. No threshold, exclusion, native schedule or fault
probe was introduced. Actual upload/client/hash/resource success remains unrun.

## Actual checks and replay

Only Python AST parsing/source comparisons ran. The final syntax command from
`/workspaces/uWebZockets` was:

```sh
python3 -c 'import ast; from pathlib import Path; path = Path(".uwz-work/evidence/h1-plaintext/integration-corrected/probe.py"); tree = ast.parse(path.read_text(), filename=str(path)); run = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "run_cases"); cases = next(node.value for node in run.body if isinstance(node, ast.Assign) and isinstance(node.value, ast.List)); print("AST syntax: passed; exit status 0"); print("Prepared cases:", len(cases.elts)); print("No harness import or runtime execution")'
```

Raw `syntax.log`, exit status0:

```text
AST syntax: passed; exit status 0
Prepared cases: 21
No harness import or runtime execution
```

`preparation.json` records the corrected/preimage/diff identities, unchanged v1
profile/probe/compile identities, existing ReleaseSafe compile record identity,
Python identity and AST comparisons. `probe.diff` is the exact review artifact.
No Zig, sanitizer, compliance, project-matrix or runtime success is claimed.

Root may run this corrected client using the SAME owned v1 profile binary and
successful `compile-combined-v1.json`, with a NEW `/tmp` artifacts directory and
its normal loader/library prefix. No rebuild or package view is required. The
client still requires Root's explicit runtime flag. A failure to obtain complete
413 in the retained original overrun case must stay unresolved and be reported
to transport_io; the size-line-only case cannot substitute for that result.

## Outstanding work

Review and Root-owned runtime of this correction come first. The independent
end-produced output, simultaneous distinct-route bindings, ordinary peer
mid-body disconnect, owned shutdown during upload and end-callback error client
cases remain unprepared/unrun, and feature preparation remains paused. The
separate v2 server WIP has not compiled and must not be used as the corrected v1
profile. The full project matrix and broader milestone gates remain open.
