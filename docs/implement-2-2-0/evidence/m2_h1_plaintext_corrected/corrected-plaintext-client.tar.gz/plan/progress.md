# SDD ledger — plan: .uwz-work/evidence/h1-plaintext/h1_plaintext_plan.md

Spec authority: 2.2.0-TODO.md M2, ADR0008 and referenced accepted head/lifetime contracts.
BASE Root877a2ac8e0d004a566aef1eac775eb06655e37e9; executable baseline source81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108.
Source copies are independent verified inputs, not private Git repositories.

## Pre-flight scan

| Tasks | Shared file/interface or self check | Finding and ruling |
| --- | --- | --- |
| 1 / 2 | HeadTarget/HeadInput/HeadDecision and body contracts | Existing accepted named contract; separate source copies avoid edits/compilation against a moving dependency. No interface redesign authorized. |
| 1 / 3 | App binding, head tests, central test import | Root merges exact App overlay and imports new test once. App task cannot claim native delivery. |
| 2 / 3 | Driver/support/native callbacks and live clients | Native effects only after coherent driver/App merge. Root serializes final support/main/config and performs combined verification. |
| 1 self | Resolver scope versus tests | Real unreserved selection; tests use actual target/registered routes and no sink calls before admission. Matches spec. |
| 2 self | Actual controls versus decoder/resume | Real retained-input continuation included. No no-op resume or fake inactive terminal cleanup. |
| 2 self | Legacy TLS versus deferred TLS destruction | Plaintext ingress only; crypto reviews owner-wide destruction before final acceptance. No TLS upload claim. |
| 3 self | Ordinary clients versus stopped native experiment | Protocol/API requests are permitted; cancellation-schedule/kernel/race/crash/leak/injection probes remain forbidden. |
| All | Root pin/publication and scope | Explicit local candidate override only. Full maintained/publication/final gates remain; no unreviewed production adoption. |

Ruling: parallel implementers use distinct /tmp copies and explicit file ownership — project AGENTS permits independent parallel assignments and architect recommends this split; overrides skill's blanket single-implementer default. Cost if wrong: integration rework, never shared-file mutation.
Ruling: use exact manifest-bound two-tree patches for component review — source snapshots are intentionally isolated until real consumer/pin gates, so Root git diff would show recovery archives rather than actual component code. Root remains sole committer/pusher. Cost if wrong: reviewer rejects unsupported provenance.
Ruling: preserve existing .uwz-work evidence plus this skill-scoped ledger/brief/report namespace — final recovery checkpoint includes all meaningful code/evidence. No scratch deletion during active goal.
Ruling: existing M1 implementation/spec supersedes outdated specialist prose about static-file 413 fallback — never reintroduce closed gaps. Cost if wrong: regressions caught by unchanged suites.
Ruling: user's repeated push authorization applies to every Root verified commit; no repeated permission, no PR. Maintained dependency publication is not authorized by this ruling.
Ruling: first-closing cancellation amendment and inherited delivery borrows are explicit accepted contracts; generic IOCP job callbacks prevent assuming submit never invokes callbacks. Full actual code still independently reviewed.

## Tasks

- [x] Task 1: App head resolution and stable binding; component review approved.
- [x] Task 2: Concrete plaintext driver/native lifetime; v6 scoped fix review approved.
- [ ] Task 3: Combined real-client/full-gate evidence and combined review.

Task 1 and Task 2 are reviewed isolated components. Production adoption and Task 3 acceptance remain pending.

Dispatch: Task1 /root/implement_h1_app_head; Task2 /root/implement_h1_plaintext_driver. Separate fresh contexts/source copies, no shared writes.
Ruling: added exact spec artifact paths to Global Constraints after Task2 correctly reported header-only references absent from extracted brief; no semantic change.

Task1 frozen sourceb97d3b94..., actual Debug12/12, ReleaseSafe12/12 and mac/Win compile0; ordinary unchanged regression checks pending. Manifest-bound review package prepared. No task completion claim yet.

Task1 component review: SpecCompliance Approved; TaskQuality Approved, no findings. Actual12/12 Debug+RS, unchanged31App/39router, foreign compile and scoped gates0. Interface concerns recorded for combined verification; no live claim. Recovery commit pending.
Task2 fix round1/5 started: P1 file_body ownership omitted at upload_tail, zero-copy response could interleave/truncate pipeline. Original implementer assigned narrow fix+covering regression; v5 immutable. Crypto v5 source review no TLS-specific findings, runtime pending.
Ruling: Task3a harness source preparation is independent while Task1/2 run — stable public API and separate files. It may compile/syntax-check, NEVER launch server/client before coherent combined source/Root release. Integration phase remains pending.

Task2 round1 resolved: v6 file ownership guard approved; actual predicate tests19/19 Debug+RS and three-target compile0. No native file-ordering claim.
Task3 combined v1 source acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b contains the approved disjoint overlays and Root's reasoned shutdown call/test imports. Independent scoped integration review Approved, no findings. Actual selected central tests62/62 both modes; full central native semantic compile0. Exact compile inputs and post-compile source/binary checks retained.
Ruling: Root releases ordinary owned plaintext protocol/API client execution against this coherent v1 binary, using the prepared bounded client and owned lifecycle. This is not permission for the stopped cancellation experiment or any native fault/interleaving/schedule/injection probe. Preserve all actual failures.
Task3b independently prepares missing producer metadata, cross-route, ordinary disconnect/shutdown and end-error cases under integration-v2 only. Existing v1 fixtures remain immutable for the current binary/run. No worker runtime authority.

Task3 client correction round1/5: failed-begin expectation and overlimit evidence retention corrected in separate immutable derivative. Independent scoped review Approved/no findings; AST21cases, covering source diff and exact client SHA e5bc2059b601243a53c829c52680c5b56de3699ec8bf6003d8c470c935f9f112 retained. Original18/20 results remain failures. Root releases the corrected ordinary client against the identical compiled combined server; no native fault/schedule authority.
Recovery checkpoint490437dc3b5d7231faeac600e051ad7069f1fb82 pushed to fork immediately.
