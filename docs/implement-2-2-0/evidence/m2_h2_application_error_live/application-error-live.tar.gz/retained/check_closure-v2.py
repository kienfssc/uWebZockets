import hashlib
import importlib.util
from pathlib import Path

here = Path(__file__).resolve().parent
manifest = here / 'manifest-v2.json'
runner = Path('/tmp/uwz-task5c2-runtime-v2/run_live.py')
spec = importlib.util.spec_from_file_location('runner', runner)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
module.check_manifest(manifest, digest)
print('current closure: accepted')
target = here / 'cases.py'
original = target.read_bytes()
try:
    target.write_bytes(original + b'\n')
    try:
        module.check_manifest(manifest, digest)
    except RuntimeError as error:
        print('mutated actual input: rejected:', error)
    else:
        raise AssertionError('mutated input accepted')
finally:
    target.write_bytes(original)
module.check_manifest(manifest, digest)
print('restored closure: accepted')
