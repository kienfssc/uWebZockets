# Actual owned H2/TLS acceptance plan

Root adopts the source-backed plan from architect_h2_live_plan. No runtime or
client/server execution occurred during planning. Initial architect model was at
capacity; fallback completed the public API mapping. Root's original goal and
the ordered-slice5 acceptance remain binding. This plan does not complete M2.

Use immutable fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de,
1031 files at /tmp/uwz-task4d-fix1-frozen; reviewed c22393-file override and existing
bindings/libs. Independent helper07a5201 and pinned42-file client package0f85bd19
remain unchanged. Source identities and current paths were verified on resume.

## Ordered thin slices

Ruling: deliver this large verification task in ordered slices so actual native
upload wiring is proved before elaborate fixture modes. This changes no final
acceptance requirement. Every unimplemented matrix case stays explicitly planned;
unsupported cases must fail, never count as skipped success.

1. Task5a: prepare the minimal real configured-App fixture and independent owned
   runner for TLS/ALPN readiness, buffered compatibility, ordinary async success,
   exact100000000-byte declared/undeclared uploads and idle normal shutdown.
   StageA source/compile only; independent harness review then Root exact StageB
   owned loopback authorization. No native source edits by verification.
2. Task5b: extend/review/run pause/FIFO/Continue/limits/quota/trailers/credit/
   concurrency/metadata/control cases. Keep prior source/run identities intact.
3. Task5c: extend/review/run producer/file/output/reuse/cancel/reset/error/
   disconnect/active-shutdown cases and final combined matrix. The complete
   ordered-slice5 acceptance is unproven until all required cases have evidence.
4. Review and publish results without implying remaining M2/H3/multipart/fork/
   platform/full-quality gates or production adoption completed.

## Public seam and storage

Server.preset(init.io, comptime profile_config).build_https builds the App type
from the same configuration, including24 captures (builder41,62-68,383-389;
root10/22; App300-320). It is not the fixed16 ConfiguredApp shorthand.
App.route_body(.post,...), BodySink/BodyBinding/BodyLimits and get_context provide
the real route/control surface (App772/978; request_body10-38,71-97). Use copied
public controls on the owning loop. Do not retain callback-local Request,
StreamingRequest, HeadersView arrays or Response pointers; individual metadata
slices may be retained only for their documented lifetime, with owned expected
copies. Producer/file state is independent of recyclable sink bindings.

Compile-time profile: max_connections8, stream_request_bodies=true,
max_request_line_size512, max_header_size4096, max_header_count80,
max_body_size256, max_h2_body_size4096, max_h2_header_block_size8192,
max_h2_response_header_size4096, max_h2_response_header_count32,
max_route_params24, write_queue_size65536. Keep unrelated optional features off;
record actual complete configuration/capacities/slab size and source defaults.
Eight native H2 streams and unchanged73728-byte receive payload pool remain.
Fixture status JSON is bounded below4096; never copy H1 multi-KiB reports blindly.

Upload route /upload/:tag has limit100000000/quota2/two caller-owned sink slots.
Later add /limit/:tag limit32/quota1, /empty/:tag limit0/quota1, long capture route
with at least17 captures, buffered health/echo/status and public control routes.
Use fixed bounded result records and independent response contexts/scratch;
App, definitions, contexts and scratch stay at stable addresses through deinit.

## Complete matrix retained across slices

Counts B/E/C mean successful binding admission, end callback invocation (including
application end error), and cancel callback invocation. Track begin attempts and
end errors separately. All accepted requests have exactly one terminal; failed
begin receives no cancel. Quota recovery is observed through later admission,
not internal owner reads. H(n) means independent hash of exact sent logical bytes.

| Case or variants | Required result |
| --- | --- |
| ready_buffered | Verified TLS1.3/h2, health200/ok; buffered POST257 returns257 exact bytes/H(257), no sink callbacks. |
| async_delayed | get_async /delayed HEADERS END_STREAM; AsyncResponse.sleep_complete(10ms,"200 OK",literal text/plain header,"delayed-ok"); exactly200/10 bytes/end/no reset within30s, no timer precision claim. |
| large_declared, large_undeclared | Actual100000000 accepted bytes,200, independent client and server SHA190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2 including final marker; B/E/C1/1/0. |
| partial_pause |12289 total; first8192 offered, seven accepted then pause; later4097 queued; resume yields exact FIFO count/hash and one begin/end. |
| final_pause |32 accepted with paused readiness and END_STREAM already sent; no end until resume without further upload bytes; then exact200/hash/end. |
| begin_pause_empty |Paused begin plus empty EOF; no chunk/end until resume, then zero/empty SHA/end once. |
| empty_headers, empty_data, empty_declared |Zero-limit route, three empty EOF forms;200/zero/empty SHA, no chunk. |
| limit_declared, limit_undeclared |32 exact;200/H(32),1/1/0. |
| limit_declared_reject |33 declared with Expect;413/empty, no100/data/begin/reservation. |
| limit_observed_reject |32 accepted then byte33;413/empty, offending byte not accepted/hashed;1/0/1 body_too_large. |
| zero_declared_reject, zero_observed_reject |Declared1 refuses before begin; undeclared first byte cancels after begin without acceptance; body_too_large. |
| continue_ready, continue_paused |Exactly one100 before final, wait before sending positive DATA; no repeated admission/begin, final middleware header retained. DATA credit cannot block informational HEADERS; no false blocked100 claim. |
| quota_refuse, begin_failure_rollback |Hold two upload contexts, third503/no100/no begin; separately failed begin503/no cancel and no leaked reservation. Later admission and healthy sibling succeed. |
| queued_trailers_padding |Pause, padded DATA, valid trailer END_STREAM, resume; logical count/hash excludes padding, credit includes pad-length/padding; initial metadata survives unmerged. |
| concurrent_routes |Paused upload below exhaustion, other route and health progress on same connection; quotas/captures isolated. |
| receive_credit |Only legitimate advertised DATA credit sent; HEADERS/control remain usable at zero DATA credit; resume continues through genuine WINDOW_UPDATE. No receive-window enlargement. |
| metadata_helpers |Distinct method/path/query, >64 bounded initial headers and >16 captures; retained individual values correct through end; helper errors BodyNotBuffered and unchanged detailed issue; text/bytes empty. |
| control_rules |Begin/chunk BodyCallbackActive; terminal/stale BodyControlExpired; active-ready resume BodyNotPaused. No state mutation/second terminal from rejected calls. |
| producer_reuse |BodyEnd arms real producer; reuse application sink slot while old output pending; independent response context validates retained metadata against owned copies and full output hash. |
| output_pressure_window, output_pressure_ready |Deterministic producer16777313 bytes; zero then granted stream DATA credit, separately ample ordinary credit. Exact output/hash/end and sibling health; record pending/WouldBlock honestly, no offset advance on a failed write. No claim of native saturation if not observed. |
| stream_file |Actual stream_file, separate8192 scratch, nonzero offset/exact selected range larger than4096; Content-Length/bytes/SHA exact. Success transfers descriptor; every returned error retains caller ownership. Keep scratch/io until App deinit. |
| early_final_order |Middleware nonempty final body with held DATA credit; complete final DATA/end precedes NO_ERROR reset; no sink/100/quota, sibling healthy. |
| cancel_ready, cancel_paused |Public control cancels ready/queued target; RST CANCEL8;1/0/1 cancelled, expired control, quota/credit/healthy sibling recover. |
| peer_reset |Ordinary valid peer RST on active paused stream;1/0/1 reset, no success response, unaffected sibling. |
| sink_error, invalid_progress |Application chunk error/invalid accepted progress; INTERNAL_ERROR2,1/0/1 sink_failure, no rejected prefix retained. No native error injection. |
| end_error |Normal application end error; INTERNAL_ERROR2,1/1/0/end_errors1, no second cancel, quota recovers. |
| disconnect |Ordinary client transport close after seven accepted; one cancel/no end, observed cause must follow actual documented EOF/reset/TLS outcome. No linger/shutdown-flag manipulation or accepting arbitrary causes. Resolve exact expected mapping before execution. |
| reuse |More than8 sequential complete requests, distinct metadata/count/hash; stale controls remain expired. |
| shutdown_active |Last full-matrix case, paused request with seven accepted; signal only owned child; one shutdown cancel/no end, no active fixture binding, successful run/deinit/post-marker/exit0/reaped. |
| shutdown_idle |Task5a baseline-only final case: no active binding, installed SIGTERM watcher, successful run/deinit/post-marker/exit0/reaped. Does not substitute for shutdown_active. |

All non-shutdown cases retain healthy traffic and later admission checks where
their specific quota assertion applies. No promise of arbitrary sibling upload
progress after the shared connection DATA receive window is exhausted.

## Stage boundaries, independent client and evidence

StageA may write/compile test-only sources and syntax-check Python, but must not
run a server/client, call native constructors, create sockets or execute a live
runner/selfcheck. Runtime material generation belongs to released StageB. A live
entry requires an explicit run flag, reviewed manifest/source/binary identities,
Root-selected case set and unused output directory; import has no side effects.

Use fixed loopback127.0.0.1:28443, TLS server name localhost, ephemeral trusted
localhost certificate/key in private/tmp run dir. No endpoint contact before
directly owned child/nonce/readiness; no accepting an existing service. Call
catch_shutdown_signals before run; readiness marker follows listen and watcher
installation, then actual TLS/h2 health confirms service progress. No App
is_drained or bound-port getter is assumed. No private native owner reads.

Absolute Python /home/codespace/.python/current/bin/python3, -B, exact packages
and unchanged reviewed helper. A new runner owns interleaving, manual credit,
expected resets/EOF and process lifecycle; helper's happy-path reset rejection
must not be globally weakened. At most8 response records/connection, bounded
8192 send/read spans,65536 retained prefix,16 informational responses/16384
informational header bytes, explicit final/trailer/event bounds. Hash/count full
bytes, aggregate frequent events, drop completed per-case state. Never accumulate
100MB payload or response. Do not mutate source helper or install packages.

Deadlines: readiness15s, ordinary case30s, each100MB case180s, whole run900s,
graceful teardown15s; monotonic absolute overall deadlines, no trickle extension.
No automatic retries or fallback success. Every exit closes owned clients and
reaps exact owned child. Forced cleanup records failure, never drained success.
Successful final marker must be emitted only after explicit public App deinit.

Preserve source/client/compiler/bindings/libs/override/loader/environment/capacity/
binary identities, exact argv, PID/start/nonce/listener/ALPN/TLS/certificate/file
identities, actual count/hash/status/reset/EOF/callback results and exit/reaping.
No private keys/credentials in public archives. Bound memory through fixed source
capacities and bounded callback/retention observations; no new resource/leak probe
or unmeasured whole-process allocator claim. Full project gates remain tracked
separately. No native cancellation schedules/races/faults/injected completions or
stopped experiments may be reconstructed. Ordinary SIGTERM is only for the exact
owned child through installed public shutdown handling.

Root adopts this reversible verification plan under the existing goal; no vendor
skill confirmation is inferred as a new user-permission requirement. Architecture
used a decision tree to expose constraints, not a completed user interview. No
external CLI review or native execution was authorized by the planning pass.
