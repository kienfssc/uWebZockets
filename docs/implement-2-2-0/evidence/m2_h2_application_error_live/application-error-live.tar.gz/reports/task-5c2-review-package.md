# Task5c2 full source review package

Base0b33655; NEW isolated test preparation only. Currentmanifest268d028772435296ad1fcd3959db0ff0ab410799c25f658bdcfa04989b347a22,2433inputs/7trees. No native execution.

diff --git a//tmp/uwz-task5c2-fixture-v2/profile.zig b//tmp/uwz-task5c2-fixture-v2/profile.zig
--- /dev/null
+++ /tmp/uwz-task5c2-fixture-v2/profile.zig
@@ -0,0 +1,360 @@
+const std = @import("std");
+const uz = @import("uWebZockets");
+const Hash = std.crypto.hash.sha2.Sha256;
+const config: uz.ServerConfig = .{
+    .max_connections = 8,
+    .stream_request_bodies = true,
+    .max_request_line_size = 512,
+    .max_header_size = 4096,
+    .max_header_count = 80,
+    .max_body_size = 256,
+    .max_h2_body_size = 4096,
+    .max_h2_header_block_size = 8192,
+    .max_h2_response_header_size = 4096,
+    .max_h2_response_header_count = 32,
+    .max_route_params = 24,
+    .write_queue_size = 65536,
+    .enable_dev_log = false,
+};
+const tags = [_][]const u8{
+    "sink_error", "sink_error_recovery", "invalid_progress", "invalid_progress_recovery",
+    "end_error",  "end_error_recovery",  "spare_00",         "spare_01",
+    "spare_02",   "spare_03",            "spare_04",         "spare_05",
+    "spare_06",   "spare_07",            "spare_08",         "spare_09",
+    "spare_10",   "spare_11",            "spare_12",         "spare_13",
+    "spare_14",   "spare_15",            "spare_16",         "spare_17",
+    "spare_18",   "spare_19",            "spare_20",         "spare_21",
+    "spare_22",   "spare_23",            "spare_24",         "spare_25",
+};
+const Record = struct {
+    token: ?uz.BodyControl = null,
+    hash: Hash = Hash.init(.{}),
+    bytes: u64 = 0,
+    chunks: u32 = 0,
+    max_span: usize = 0,
+    middleware: u32 = 0,
+    attempts: u32 = 0,
+    begins: u32 = 0,
+    ends: u32 = 0,
+    cancels: u32 = 0,
+    failures: u32 = 0,
+    end_errors: u32 = 0,
+    chunk_errors: u32 = 0,
+    invalid_progress: u32 = 0,
+    errors: u32 = 0,
+    metadata_middleware: u32 = 0,
+    metadata_begin: u32 = 0,
+    metadata_end: u32 = 0,
+    stale_resume: u32 = 0,
+    stale_cancel: u32 = 0,
+    active: bool = false,
+    paused: bool = false,
+    reason: ?uz.BodyCancelReason = null,
+};
+const Slot = struct { record: ?*Record = null, owner: *State = undefined, index: usize = 0 };
+const State = struct {
+    slots: [2]Slot = [_]Slot{.{}} ** 2,
+    records: [32]Record = [_]Record{.{}} ** 32,
+    buffered_middleware: u32 = 0,
+    errors: u32 = 0,
+};
+fn tag_index(tag: []const u8) ?usize {
+    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
+    return null;
+}
+fn equal(actual: ?[]const u8, expected: []const u8) bool {
+    return if (actual) |value| std.mem.eql(u8, value, expected) else false;
+}
+fn metadata_matches(request: *const uz.StreamingRequest, index: usize) bool {
+    var path_storage: [128]u8 = undefined;
+    var query_storage: [128]u8 = undefined;
+    var target_storage: [256]u8 = undefined;
+    const path = std.fmt.bufPrint(&path_storage, "/limit/{s}", .{tags[index]}) catch return false;
+    const query = std.fmt.bufPrint(&query_storage, "case={s}", .{tags[index]}) catch return false;
+    const target = std.fmt.bufPrint(&target_storage, "{s}?{s}", .{ path, query }) catch return false;
+    return std.mem.eql(u8, request.method, "POST") and std.mem.eql(u8, request.path, path) and
+        std.mem.eql(u8, request.query, query) and std.mem.eql(u8, request.target, target) and
+        equal(request.params.get("tag"), tags[index]) and equal(request.headers.get("x-case"), tags[index]) and
+        equal(request.headers.get("content-length"), "32");
+}
+fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
+    const state: *State = @ptrCast(@alignCast(context));
+    if (std.mem.startsWith(u8, request.path, "/limit/")) {
+        const tag = request.get_param("tag") orelse {
+            state.errors += 1;
+            return .stop;
+        };
+        const index = tag_index(tag) orelse {
+            state.errors += 1;
+            return .stop;
+        };
+        if (index >= 6) {
+            state.errors += 1;
+            return .stop;
+        }
+        const record = &state.records[index];
+        record.middleware += 1;
+        if (metadata_matches(&uz.StreamingRequest.from_request(request), index)) {
+            record.metadata_middleware += 1;
+        } else record.errors += 1;
+    } else state.buffered_middleware += 1;
+    response.append_header("X-Middleware", "retained") catch {
+        state.errors += 1;
+        return .stop;
+    };
+    return .continue_dispatch;
+}
+fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
+    const state: *State = @ptrCast(@alignCast(context));
+    const tag = request.params.get("tag") orelse return error.MissingTag;
+    const index = tag_index(tag) orelse return error.InvalidTag;
+    if (index >= 6) return error.SpareTag;
+    const record = &state.records[index];
+    record.attempts += 1;
+    if (record.attempts != 1 or record.middleware != 1 or !metadata_matches(request, index)) {
+        record.errors += 1;
+        record.failures += 1;
+        return error.InvalidRequest;
+    }
+    record.metadata_begin += 1;
+    for (&state.slots) |*slot| {
+        if (slot.record != null) continue;
+        slot.* = .{ .owner = state, .record = record, .index = index };
+        record.token = token;
+        record.begins += 1;
+        record.active = true;
+        return .{ .context = slot, .readiness = .ready };
+    }
+    record.failures += 1;
+    record.errors += 1;
+    return error.NoFixtureSlot;
+}
+fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
+    const slot: *Slot = @ptrCast(@alignCast(context));
+    const record = slot.record orelse return error.MissingRecord;
+    record.max_span = @max(record.max_span, input.len);
+    record.chunks += 1;
+    if (record.bytes == 7 and slot.index == 0) {
+        record.chunk_errors += 1;
+        return error.ApplicationChunkRefused;
+    }
+    if (record.bytes == 7 and slot.index == 2) {
+        record.invalid_progress += 1;
+        return .{ .consumed = 0, .readiness = .ready };
+    }
+    record.hash.update(input);
+    record.bytes += input.len;
+    return .{ .consumed = input.len, .readiness = .ready };
+}
+fn format_record(record: *const Record, tag: []const u8, output: []u8) ![]const u8 {
+    var copy = record.hash;
+    var digest: [Hash.digest_length]u8 = undefined;
+    copy.final(&digest);
+    const hex = std.fmt.bytesToHex(digest, .lower);
+    const reason = if (record.reason) |value| @tagName(value) else "none";
+    return std.fmt.bufPrint(output, "{{\"tag\":\"{s}\",\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"accepted\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":\"{s}\",\"metadata_middleware\":{d},\"metadata_begin\":{d},\"metadata_end\":{d},\"stale_resume\":{d},\"stale_cancel\":{d},\"errors\":{d}}}", .{ tag, record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.chunk_errors, record.invalid_progress, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.metadata_middleware, record.metadata_begin, record.metadata_end, record.stale_resume, record.stale_cancel, record.errors });
+}
+fn end(context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response) !void {
+    const slot: *Slot = @ptrCast(@alignCast(context));
+    const record = slot.record orelse return error.MissingRecord;
+    record.ends += 1;
+    if (!metadata_matches(request, slot.index)) {
+        record.errors += 1;
+        record.end_errors += 1;
+        record.active = false;
+        record.paused = false;
+        slot.record = null;
+        return error.MetadataMismatch;
+    }
+    record.metadata_end += 1;
+    var hash_copy = record.hash;
+    var digest: [Hash.digest_length]u8 = undefined;
+    hash_copy.final(&digest);
+    const expected = [_]u8{ 0x7f, 0x0c, 0x58, 0x81, 0xa9, 0xae, 0x26, 0x83, 0xde, 0xbb, 0xa0, 0x16, 0xa4, 0x78, 0x6b, 0x6c, 0x08, 0xdc, 0x68, 0x4c, 0x5a, 0x33, 0x4f, 0xa0, 0xb9, 0x87, 0x6e, 0x6e, 0x32, 0xc3, 0x90, 0xb5 };
+    if (record.bytes != 32 or !std.mem.eql(u8, &digest, &expected)) {
+        record.errors += 1;
+        record.end_errors += 1;
+        record.active = false;
+        slot.record = null;
+        return error.InvalidBody;
+    }
+    if (slot.index == 4) {
+        record.end_errors += 1;
+        record.active = false;
+        slot.record = null;
+        return error.ApplicationEndRefused;
+    }
+    record.active = false;
+    record.paused = false;
+    slot.record = null;
+    var output: [1024]u8 = undefined;
+    const body = format_record(record, tags[slot.index], &output) catch |err| {
+        record.end_errors += 1;
+        return err;
+    };
+    response.text(body) catch |err| {
+        record.end_errors += 1;
+        return err;
+    };
+}
+fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
+    const slot: *Slot = @ptrCast(@alignCast(context));
+    const record = slot.record orelse {
+        slot.owner.errors += 1;
+        return;
+    };
+    record.cancels += 1;
+    record.reason = reason;
+    record.active = false;
+    record.paused = false;
+    slot.record = null;
+}
+fn health(_: *uz.Request, response: *uz.Response) void {
+    response.text("ok") catch |err| std.log.err("health: {}", .{err});
+}
+fn echo(request: *uz.Request, response: *uz.Response) void {
+    response.bytes(request.bytes()) catch |err| std.log.err("echo: {}", .{err});
+}
+fn status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
+    const state: *State = @ptrCast(@alignCast(context));
+    const tag = request.get_param("tag") orelse {
+        state.errors += 1;
+        return;
+    };
+    const index = tag_index(tag) orelse {
+        state.errors += 1;
+        return;
+    };
+    var output: [1024]u8 = undefined;
+    const body = format_record(&state.records[index], tags[index], &output) catch {
+        state.errors += 1;
+        return;
+    };
+    response.text(body) catch {
+        state.errors += 1;
+    };
+}
+const Totals = struct { middleware: u64 = 0, attempts: u64 = 0, begins: u64 = 0, ends: u64 = 0, cancels: u64 = 0, failures: u64 = 0, end_errors: u64 = 0, chunk_errors: u64 = 0, invalid_progress: u64 = 0, accepted: u64 = 0, active: u32 = 0, errors: u64 = 0 };
+fn format_totals(state: *const State, output: []u8) ![]const u8 {
+    var result: Totals = .{ .errors = state.errors };
+    for (state.records) |record| {
+        result.middleware += record.middleware;
+        result.attempts += record.attempts;
+        result.begins += record.begins;
+        result.ends += record.ends;
+        result.cancels += record.cancels;
+        result.failures += record.failures;
+        result.end_errors += record.end_errors;
+        result.chunk_errors += record.chunk_errors;
+        result.invalid_progress += record.invalid_progress;
+        result.accepted += record.bytes;
+        result.active += @intFromBool(record.active);
+        result.errors += record.errors;
+    }
+    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"accepted\":{d},\"active\":{d},\"errors\":{d},\"buffered_middleware\":{d},\"slot0_active\":{any},\"slot1_active\":{any}}}", .{ result.middleware, result.attempts, result.begins, result.ends, result.cancels, result.failures, result.end_errors, result.chunk_errors, result.invalid_progress, result.accepted, result.active, result.errors, state.buffered_middleware, state.slots[0].record != null, state.slots[1].record != null });
+}
+fn metrics(context: *anyopaque, _: *uz.Request, response: *uz.Response) void {
+    const state: *State = @ptrCast(@alignCast(context));
+    var output: [1024]u8 = undefined;
+    const body = format_totals(state, &output) catch {
+        state.errors += 1;
+        return;
+    };
+    response.text(body) catch {
+        state.errors += 1;
+    };
+}
+fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
+    const state: *State = @ptrCast(@alignCast(context));
+    const tag = request.get_param("tag") orelse {
+        state.errors += 1;
+        return;
+    };
+    const index = tag_index(tag) orelse {
+        state.errors += 1;
+        return;
+    };
+    const record = &state.records[index];
+    const token = record.token orelse {
+        state.errors += 1;
+        return;
+    };
+    const operation = request.get_param("op") orelse {
+        state.errors += 1;
+        return;
+    };
+    if (std.mem.eql(u8, operation, "cancel") and record.active) {
+        token.cancel() catch {
+            state.errors += 1;
+            return;
+        };
+        response.text("ok") catch {
+            state.errors += 1;
+        };
+        return;
+    }
+    if (record.active) {
+        state.errors += 1;
+        return;
+    }
+    if (std.mem.eql(u8, operation, "resume")) {
+        if (token.@"resume"()) |_| {
+            state.errors += 1;
+            return;
+        } else |err| {
+            if (err != error.BodyControlExpired) {
+                state.errors += 1;
+                return;
+            }
+        }
+        record.stale_resume += 1;
+    } else if (std.mem.eql(u8, operation, "cancel")) {
+        if (token.cancel()) |_| {
+            state.errors += 1;
+            return;
+        } else |err| {
+            if (err != error.BodyControlExpired) {
+                state.errors += 1;
+                return;
+            }
+        }
+        record.stale_cancel += 1;
+    } else {
+        state.errors += 1;
+        return;
+    }
+    response.text("BodyControlExpired") catch {
+        state.errors += 1;
+    };
+}
+pub fn main(init: std.process.Init) !void {
+    const certificate = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_CERT") orelse return error.MissingCertificate);
+    const key = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_KEY") orelse return error.MissingKey);
+    const nonce = init.environ_map.get("H2_PROFILE_NONCE") orelse return error.MissingNonce;
+    if (nonce.len == 0 or nonce.len > 64) return error.InvalidNonce;
+    var state: State = .{};
+    const sink: uz.BodySink = .{ .context = &state, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel };
+    var upload: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 32, .max_active = 1 }, .middleware_policy = .headers_only };
+    {
+        var server = try uz.Server.preset(init.io, config).build_https(init.arena.allocator(), certificate, key);
+        defer server.deinit();
+        _ = try server.use(&state, middleware);
+        _ = try server.route_body(.post, "/limit/:tag", &upload);
+        _ = try server.get("/health", health);
+        _ = try server.post("/echo", echo);
+        _ = try server.get_context("/status/:tag", &state, status);
+        _ = try server.get_context("/metrics", &state, metrics);
+        _ = try server.get_context("/control/:op/:tag", &state, control);
+        std.log.info("H2_CAPACITY config={f} request_stride={d} h2_bytes={d} h2_stride={d} slab={d} router={d}", .{ std.json.fmt(config, .{}), try config.request_buffer_stride(), try config.h2_session_bytes(), try config.h2_session_stride(), try config.slab_bytes(), try config.router_storage_bytes() });
+        try server.listen("127.0.0.1", 28443);
+        try server.catch_shutdown_signals();
+        std.log.info("H2_READY {s}", .{nonce});
+        try server.run();
+    }
+    for (&state.records, 0..) |*record, i| {
+        var output: [1024]u8 = undefined;
+        std.log.info("H2_RECORD {s} {s}", .{ nonce, try format_record(record, tags[i], &output) });
+    }
+    var output: [1024]u8 = undefined;
+    std.log.info("H2_DEINIT {s} {s}", .{ nonce, try format_totals(&state, &output) });
+}

diff --git a//tmp/uwz-task5c2-runtime-v2/cases.py b//tmp/uwz-task5c2-runtime-v2/cases.py
--- /dev/null
+++ /tmp/uwz-task5c2-runtime-v2/cases.py
@@ -0,0 +1,74 @@
+"""Independent bounded lifecycle case expectations; import is inert."""
+CASES = ('sink_error', 'invalid_progress', 'end_error', 'shutdown_idle')
+PRIMARIES = CASES[:3]
+TAGS = tuple(value for primary in PRIMARIES for value in (primary, primary + '_recovery')) + tuple('spare_%02d' % i for i in range(26))
+H32 = '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5'
+H7 = '32bbe378a25091502b2baf9f7258c19444e7a43ee4593b08030acd790bd66e6a'
+EMPTY = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
+
+
+def require(condition, message):
+    if not condition:
+        raise ValueError(message)
+
+
+def selected_tags(selection):
+    return {tag for case in selection if case in PRIMARIES for tag in (case, case + '_recovery')}
+
+
+def expected(tag, selected):
+    touched = tag in selected
+    recovery = touched and tag.endswith('_recovery')
+    primary = touched and not recovery
+    end_failure = tag == 'end_error' and primary
+    completed = recovery or end_failure
+    return {'tag': tag, 'middleware': int(touched), 'attempts': int(touched), 'begin': int(touched),
+            'end': int(completed), 'cancel': int(primary and not end_failure), 'failure': 0,
+            'end_errors': int(end_failure), 'chunk_errors': int(primary and tag == 'sink_error'),
+            'invalid_progress': int(primary and tag == 'invalid_progress'), 'accepted': 32 if completed else 7 if primary else 0,
+            'sha256': H32 if completed else H7 if primary else EMPTY,
+            'active': False, 'paused': False, 'reason': 'sink_failure' if primary and not end_failure else 'none',
+            'metadata_middleware': int(touched), 'metadata_begin': int(touched), 'metadata_end': int(completed),
+            'stale_resume': 2 if primary else 0, 'stale_cancel': 2 if primary else 0, 'errors': 0}
+
+
+def verify_record(actual, expected_record):
+    require(set(actual) == set(expected_record) | {'chunks', 'max_span'}, 'record fields differ')
+    for key, value in expected_record.items():
+        require(actual[key] == value, 'record %s field %s differs' % (expected_record['tag'], key))
+    chunks, span = actual['chunks'], actual['max_span']
+    require(type(chunks) is int and type(span) is int and chunks >= 0 and 0 <= span <= 8192, 'chunk bounds')
+    require((chunks == 0 and span == 0) if not actual['accepted'] else (chunks > 0 and span > 0), 'chunk evidence')
+
+
+def execute(api, case):
+    require(case in PRIMARIES, 'unsupported case')
+    sibling = api['sibling']()
+    primary = api['start'](case, 'application_failure')
+    if case == 'end_error':
+        api['send'](primary, 32, True)
+        before = None
+    else:
+        api['send'](primary, 7, False)
+        before = api['status'](case)
+        require((before['begin'], before['accepted'], before['sha256'], before['end'], before['cancel'], before['paused']) ==
+                (1, 7, H7, 0, 0, False), 'preterminal barrier differs')
+        api['pending'](primary)
+        api['send'](primary, 8, False)
+    terminal = api['status'](case)
+    end_failure = case == 'end_error'
+    require((terminal['begin'], terminal['end'], terminal['cancel'], terminal['end_errors'], terminal['accepted'], terminal['sha256'], terminal['reason'], terminal['active']) ==
+            (1, int(end_failure), int(not end_failure), int(end_failure), 32 if end_failure else 7,
+             H32 if end_failure else H7, 'none' if end_failure else 'sink_failure', False), 'server terminal barrier differs')
+    terminal_wire = api['finish_terminal'](primary)
+    stale_before = [api['control'](name, case, 'BodyControlExpired') for name in ('resume', 'cancel')]
+    credit = api['reclaim'](32 if end_failure else 15)
+    sibling_response = api['finish_sibling'](sibling)
+    recovery = api['start'](case + '_recovery', 'healthy')
+    api['send'](recovery, 32, True)
+    response = api['finish_recovery'](recovery)
+    verify_record(response, expected(case + '_recovery', {case + '_recovery'}))
+    stale_after = [api['control'](name, case, 'BodyControlExpired') for name in ('resume', 'cancel')]
+    return {'before': before, 'terminal': terminal, 'terminal_wire': terminal_wire,
+            'stale_before': stale_before, 'sibling': sibling_response, 'credit': credit,
+            'recovery': response, 'stale_after': stale_after}

diff --git a//tmp/uwz-task5c2-runtime-v2/flow_ledger.py b//tmp/uwz-task5c2-runtime-v2/flow_ledger.py
--- /dev/null
+++ /tmp/uwz-task5c2-runtime-v2/flow_ledger.py
@@ -0,0 +1,88 @@
+"""Caller-owned HTTP/2 outbound credit accounting; no transport effects."""
+from dataclasses import dataclass, field
+
+INITIAL = 65535
+MAX_STREAMS = 8
+
+
+@dataclass
+class StreamCredit:
+    window: int
+    sent: int = 0
+    refunded: int = 0
+    open: bool = True
+
+
+@dataclass
+class FlowLedger:
+    connection: int = INITIAL
+    initial_stream: int = INITIAL
+    sent: int = 0
+    refunded: int = 0
+    streams: dict[int, StreamCredit] = field(default_factory=dict)
+    unchanged_settings: bool = True
+
+
+def open_stream(ledger: FlowLedger, stream_id: int) -> None:
+    if stream_id in ledger.streams or len(ledger.streams) >= MAX_STREAMS:
+        raise ValueError('duplicate stream or stream capacity exceeded')
+    ledger.streams[stream_id] = StreamCredit(ledger.initial_stream)
+
+
+def send_data(ledger: FlowLedger, stream_id: int, payload: int, padding: int | None, max_frame: int, finished: bool = False) -> int:
+    stream = ledger.streams[stream_id]
+    if not stream.open or payload < 0 or padding is not None and not 0 <= padding <= 255:
+        raise ValueError('invalid DATA request')
+    flow = payload + (padding + 1 if padding is not None else 0)
+    if flow > min(ledger.connection, stream.window, max_frame):
+        raise ValueError('DATA exceeds public credit or frame limit')
+    ledger.connection -= flow
+    ledger.sent += flow
+    stream.window -= flow
+    stream.sent += flow
+    stream.open = not finished
+    return flow
+
+
+def receive_batch(ledger: FlowLedger, updates: list[tuple[int, int]], new_initial: int | None = None) -> None:
+    if new_initial is not None:
+        if not 0 <= new_initial <= 2147483647:
+            raise ValueError('invalid initial window')
+        change = new_initial - ledger.initial_stream
+        ledger.initial_stream = new_initial
+        ledger.unchanged_settings = ledger.unchanged_settings and change == 0
+        for stream in ledger.streams.values():
+            if stream.open:
+                stream.window += change
+    for stream_id, delta in updates:
+        if delta <= 0:
+            raise ValueError('invalid window update')
+        if stream_id == 0:
+            ledger.connection += delta
+            ledger.refunded += delta
+        else:
+            stream = ledger.streams[stream_id]
+            stream.window += delta
+            stream.refunded += delta
+    if ledger.unchanged_settings:
+        if not 0 <= ledger.connection <= INITIAL or ledger.refunded > ledger.sent:
+            raise ValueError('invalid connection refund')
+        for stream in ledger.streams.values():
+            if stream.refunded > stream.sent or stream.open and not 0 <= stream.window <= INITIAL:
+                raise ValueError('invalid stream refund')
+
+
+def check_public(ledger: FlowLedger, connection_window: int, stream_windows: dict[int, int]) -> None:
+    if connection_window != ledger.connection:
+        raise ValueError('connection window differs')
+    for stream_id, public_window in stream_windows.items():
+        stream = ledger.streams[stream_id]
+        if not stream.open or public_window != min(ledger.connection, stream.window):
+            raise ValueError('stream minimum differs or stream closed')
+
+
+def primary_refund_complete(ledger: FlowLedger, target: int, public_window: int) -> bool:
+    if target not in (15, 32) or ledger.sent != target or ledger.refunded > ledger.sent:
+        raise ValueError('primary-only flow differs')
+    check_public(ledger, public_window, {})
+    return ledger.refunded == target

diff --git a//tmp/uwz-task5c2-runtime-v2/raw_observer.py b//tmp/uwz-task5c2-runtime-v2/raw_observer.py
--- /dev/null
+++ /tmp/uwz-task5c2-runtime-v2/raw_observer.py
@@ -0,0 +1,98 @@
+"""Bounded raw HTTP/2 frame-order observation; transport is external."""
+READ_BOUND = 8192
+STREAM_LIMIT = 8
+FRAME_LIMIT = 16384
+POLICIES = ('healthy', 'public_cancel', 'peer_reset', 'refusal_after_final', 'application_failure')
+
+
+def require(condition, message):
+    if not condition:
+        raise ValueError(message)
+
+
+def new_state():
+    return {'header': bytearray(), 'remaining': 0, 'frame': None,
+            'reset_payload': bytearray(), 'streams': {}, 'high_water': 0}
+
+
+def register(state, stream_id, policy):
+    streams = state['streams']
+    require(policy in POLICIES, 'invalid terminal policy')
+    require(state['high_water'] < stream_id <= 0x7fffffff and stream_id & 1, 'invalid stream')
+    require(len(streams) < STREAM_LIMIT, 'stream bound')
+    state['high_water'] = stream_id
+    streams[stream_id] = {'policy': policy, 'end': False, 'reset': False,
+                          'peer_reset': False}
+
+
+def mark_peer_reset(state, stream_id, code):
+    record = state['streams'][stream_id]
+    require(record['policy'] == 'peer_reset' and code == 8, 'invalid peer reset')
+    require(not record['end'] and not record['peer_reset'], 'duplicate peer reset')
+    record['peer_reset'] = True
+
+
+def retire(state, stream_id):
+    record = state['streams'][stream_id]
+    policy = record['policy']
+    complete = ((policy == 'healthy' and record['end'] and not record['reset']) or
+                (policy in ('public_cancel', 'application_failure') and record['reset'] and not record['end']) or
+                (policy == 'peer_reset' and record['peer_reset'] and not record['end'] and not record['reset']) or
+                (policy == 'refusal_after_final' and record['end'] and record['reset']))
+    require(complete, 'incomplete stream')
+    del state['streams'][stream_id]
+
+
+def finish_frame(state):
+    frame = state['frame']
+    stream_id = frame['stream']
+    record = state['streams'].get(stream_id)
+    if frame['type'] == 3:
+        require(record is not None, 'reset on unregistered stream')
+        policy = record['policy']
+        require(policy in ('public_cancel', 'refusal_after_final', 'application_failure'), 'unexpected reset')
+        require(not record['reset'], 'duplicate reset')
+        require((policy == 'refusal_after_final') == record['end'], 'reset order')
+        expected = {'public_cancel': 8, 'refusal_after_final': 0, 'application_failure': 2}[policy]
+        require(int.from_bytes(state['reset_payload'], 'big') == expected, 'wrong reset code')
+        record['reset'] = True
+    elif frame['type'] in (0, 1):
+        require(record is not None, 'payload on unregistered stream')
+        require(not record['end'] and not record['reset'] and not record['peer_reset'],
+                'payload after terminal')
+        if frame['flags'] & 1:
+            record['end'] = True
+    state['frame'] = None
+    state['reset_payload'].clear()
+
+
+def observe(state, data):
+    require(len(data) <= READ_BOUND, 'read bound')
+    offset = 0
+    while offset < len(data):
+        if state['frame'] is None:
+            header = state['header']
+            count = min(9 - len(header), len(data) - offset)
+            header.extend(data[offset:offset + count])
+            offset += count
+            if len(header) < 9:
+                continue
+            length = int.from_bytes(header[:3], 'big')
+            frame_type = header[3]
+            stream_id = int.from_bytes(header[5:9], 'big') & 0x7fffffff
+            require(length <= FRAME_LIMIT, 'frame bound')
+            if frame_type == 3:
+                require(length == 4 and stream_id != 0, 'invalid reset frame')
+            state['frame'] = {'type': frame_type, 'flags': header[4], 'stream': stream_id}
+            state['remaining'] = length
+            header.clear()
+            if length == 0:
+                finish_frame(state)
+            continue
+        count = min(state['remaining'], len(data) - offset)
+        if state['frame']['type'] == 3:
+            state['reset_payload'].extend(data[offset:offset + count])
+        offset += count
+        state['remaining'] -= count
+        if state['remaining'] == 0:
+            finish_frame(state)

diff --git a//tmp/uwz-task5c2-runtime-v2/run_live.py b//tmp/uwz-task5c2-runtime-v2/run_live.py
--- /dev/null
+++ /tmp/uwz-task5c2-runtime-v2/run_live.py
@@ -0,0 +1,569 @@
+"""Explicitly gated ordinary owned H2 fixture runner; importing is inert."""
+import argparse
+import hashlib
+import importlib.util
+import json
+import os
+from pathlib import Path
+import signal
+import socket
+import ssl
+import subprocess
+import sys
+import threading
+import time
+import traceback
+
+HERE = Path(__file__).resolve().parent
+PORT = 28443
+PYTHON = '/home/codespace/.python/current/bin/python3'
+PACKAGES = '/tmp/uwz-h2-client-tooling/packages'
+HELPER = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'
+OPENSSL = '/opt/conda/bin/openssl'
+CASES = ('sink_error', 'invalid_progress', 'end_error', 'shutdown_idle')
+
+
+def require(condition, message):
+    if not condition:
+        raise RuntimeError(message)
+
+
+def digest(path):
+    value = hashlib.sha256()
+    with open(path, 'rb') as source:
+        while block := source.read(8192):
+            value.update(block)
+    return value.hexdigest()
+
+
+def check_manifest(path, expected):
+    require(digest(path) == expected, 'review manifest identity differs')
+    manifest = json.loads(path.read_text())
+    for root, expected_files in manifest['trees'].items():
+        actual = {str(p.relative_to(root)) for p in Path(root).rglob('*') if p.is_file()}
+        require(actual == set(expected_files), 'tree inventory differs: ' + root)
+        for name, value in expected_files.items():
+            require(digest(Path(root) / name) == value, 'tree input identity differs: ' + name)
+    for name, value in manifest['inputs'].items():
+        require(digest(name) == value, 'input identity differs: ' + name)
+    require(manifest['state'] == 'ready-for-independent-review', 'manifest not review ready')
+    checked_path(__file__, manifest['runner'], manifest['inputs'])
+    checked_path(manifest['wire'], manifest['wire'], manifest['inputs'])
+    checked_path(manifest['raw'], manifest['raw'], manifest['inputs'])
+    checked_path(manifest['cases'], manifest['cases'], manifest['inputs'])
+    checked_path(manifest['flow'], manifest['flow'], manifest['inputs'])
+    checked_path(manifest['helper'], manifest['helper'], manifest['inputs'])
+    validator = load_bound('validate_builds', manifest['validator'], manifest['inputs'])
+    validator.validate(manifest, manifest['inputs'])
+    return manifest
+
+
+def checked_path(actual, expected, inputs):
+    require(Path(actual).absolute() == Path(expected).absolute(), 'executing source path differs')
+    require(Path(actual).resolve() == Path(expected).absolute(), 'source path resolves elsewhere')
+    require(expected in inputs and digest(actual) == inputs[expected], 'executing source hash differs')
+
+
+def load_bound(name, path, inputs):
+    checked_path(path, path, inputs)
+    spec = importlib.util.spec_from_file_location(name, path)
+    require(spec is not None and spec.loader is not None, 'module loader unavailable')
+    module = importlib.util.module_from_spec(spec)
+    sys.modules[name] = module
+    spec.loader.exec_module(module)
+    checked_path(module.__file__, path, inputs)
+    return module
+
+
+
+def failure_details(exc, stage):
+    return {'type': type(exc).__name__, 'message': str(exc),
+            'filename': getattr(exc, 'filename', None), 'stage': stage,
+            'traceback': ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))[-16384:]}
+
+
+def new_capture():
+    return {'lock': threading.Lock(), 'bytes': bytearray(), 'overflow': False, 'error': None}
+
+
+def capture_fragment(capture, data):
+    with capture['lock']:
+        room = 65536 - len(capture['bytes'])
+        capture['bytes'].extend(data[:room])
+        if len(data) > room:
+            capture['overflow'] = True
+
+
+def capture_snapshot(capture):
+    with capture['lock']:
+        return bytes(capture['bytes']), capture['overflow'], capture['error']
+
+
+def check_capture(capture):
+    _, overflow, error = capture_snapshot(capture)
+    require(not overflow, 'server output exceeds 65536 bytes')
+    require(error is None, 'server output collector failed: ' + str(error))
+
+
+def drain_capture(pipe, capture):
+    try:
+        while data := os.read(pipe.fileno(), 8192):
+            capture_fragment(capture, data)
+    except BaseException as exc:
+        with capture['lock']:
+            capture['error'] = repr(exc)
+    finally:
+        try:
+            pipe.close()
+        except BaseException as exc:
+            with capture['lock']:
+                capture['error'] = repr(exc)
+
+
+def cleanup_actions(actions):
+    errors = []
+    for name, action in actions:
+        try:
+            action()
+        except BaseException as exc:
+            errors.append({'action': name, 'error': repr(exc)})
+    return errors
+
+
+def remaining(deadline):
+    seconds = deadline - time.monotonic()
+    require(seconds > 0, 'absolute deadline expired')
+    return seconds
+
+
+def child_start(pid):
+    # comm can contain spaces or parentheses; the final ')' ends that field.
+    text = Path('/proc', str(pid), 'stat').read_text()
+    return text[text.rfind(')') + 2:].split()[19]
+
+
+def owned_listener(pid):
+    inodes = set()
+    for entry in Path('/proc', str(pid), 'fd').iterdir():
+        try:
+            target = os.readlink(entry)
+        except FileNotFoundError:
+            continue
+        if target.startswith('socket:['):
+            inodes.add(target[8:-1])
+    rows = Path('/proc/net/tcp').read_text().splitlines()[1:]
+    return [row.split()[9] for row in rows if row.split()[1] == '0100007F:6F1B'
+            and row.split()[3] == '0A' and row.split()[9] in inodes]
+
+
+def wait_marker(child, capture, nonce, deadline):
+    marker = ('H2_READY ' + nonce).encode()
+    while True:
+        check_capture(capture)
+        require(child.poll() is None, 'child exited before readiness')
+        data, _, _ = capture_snapshot(capture)
+        if marker in data:
+            listeners = owned_listener(child.pid)
+            require(len(listeners) == 1, 'owned loopback listener not uniquely identified')
+            return listeners[0]
+        time.sleep(min(0.05, remaining(deadline)))
+
+
+def flush(sock, protocol, deadline, capture):
+    check_capture(capture)
+    pending = protocol.data_to_send()
+    if pending:
+        sock.settimeout(remaining(deadline))
+        sock.sendall(pending)
+
+
+def encoded_headers_size(pending, stream):
+    from hyperframe.frame import Frame, HeadersFrame, ContinuationFrame
+    offset = 0
+    total = 0
+    ended = False
+    while offset < len(pending):
+        require(len(pending) - offset >= 9, 'truncated generated frame header')
+        frame, length = Frame.parse_frame_header(memoryview(pending)[offset:offset + 9])
+        offset += 9
+        require(offset + length <= len(pending), 'truncated generated frame payload')
+        frame.parse_body(memoryview(pending)[offset:offset + length])
+        offset += length
+        require(isinstance(frame, (HeadersFrame, ContinuationFrame)) and frame.stream_id == stream and not ended, 'unexpected generated header frame')
+        total += len(frame.data)
+        require(total <= 8192, 'encoded header block exceeds bound')
+        ended = 'END_HEADERS' in frame.flags
+    require(ended, 'missing generated END_HEADERS')
+    return total
+
+
+def flush_headers(sock, protocol, deadline, capture, stream):
+    check_capture(capture)
+    pending = protocol.data_to_send()
+    total = encoded_headers_size(pending, stream)
+    sock.settimeout(remaining(deadline))
+    sock.sendall(pending)
+    return total
+
+
+def receive(sock, protocol, records, raw, trace, deadline, wire, capture):
+    check_capture(capture)
+    sock.settimeout(remaining(deadline))
+    data = sock.recv(8192)
+    require(data, 'TLS EOF before response completion')
+    events = wire.accept(protocol, data, records, raw, trace['events'])
+    import h2.events
+    import h2.settings
+    updates = [(event.stream_id, event.delta) for event in events if isinstance(event, h2.events.WindowUpdated)]
+    initial = None
+    for event in events:
+        if isinstance(event, h2.events.RemoteSettingsChanged):
+            changed = event.changed_settings.get(h2.settings.SettingCodes.INITIAL_WINDOW_SIZE)
+            if changed is not None:
+                initial = changed.new_value
+                require(initial == 65535, 'peer stream initial window changed')
+    ledger = trace['ledger']
+    for stream_id, entry in ledger.streams.items():
+        observed = raw['streams'].get(stream_id)
+        if observed is not None and observed['reset']:
+            entry.open = False
+    trace['flow'].receive_batch(ledger, updates, initial)
+    windows = {stream_id: protocol.local_flow_control_window(stream_id)
+               for stream_id, item in ledger.streams.items() if item.open}
+    trace['flow'].check_public(ledger, protocol.outbound_flow_control_window, windows)
+    require(len(trace['snapshots']) < 4096, 'flow snapshot bound exceeded')
+    trace['snapshots'].append({'connection': ledger.connection, 'sent': ledger.sent,
+                               'refunded': ledger.refunded, 'windows': windows, 'updates': updates})
+    flush(sock, protocol, deadline, capture)
+
+
+def start(protocol, records, raw, method, path, headers, end_stream, limit, wire, status=200, info=0, policy='healthy'):
+    stream = protocol.get_next_available_stream_id()
+    wire.register(records, raw, stream, limit, status, info, policy)
+    protocol.send_headers(stream, [(':method', method), (':scheme', 'https'),
+                                  (':authority', 'localhost'), (':path', path)] + headers,
+                          end_stream=end_stream)
+    return stream
+
+
+def complete(sock, protocol, records, raw, trace, stream, deadline, wire, capture, keep=False):
+    flush(sock, protocol, deadline, capture)
+    record = records[stream]
+    def finished():
+        policy = record['policy']
+        raw_record = raw['streams'][stream]
+        terminal = (record['ended'] if policy == 'healthy' else
+                    raw_record['reset'] if policy in ('public_cancel', 'application_failure') else
+                    raw_record['peer_reset'] if policy == 'peer_reset' else
+                    record['ended'] and raw_record['reset'])
+        return terminal and not raw['header'] and raw['frame'] is None
+    while not finished():
+        receive(sock, protocol, records, raw, trace, deadline, wire, capture)
+    wire.complete(records, raw, stream)
+    result = {'headers': record['headers'], 'bytes': record['bytes'],
+              'sha256': record['hash'].hexdigest(), 'body': bytes(record['body']).decode('utf-8'),
+              'informationals': record['informationals'], 'raw_reset': raw['streams'][stream]['reset'],
+              'reset_event': record['reset_event']}
+    if not keep:
+        wire.retire(records, raw, stream)
+    return result
+
+
+def request(sock, protocol, records, raw, trace, path, deadline, wire, capture, limit=1024):
+    stream = start(protocol, records, raw, 'GET', path, [], True, limit, wire)
+    return complete(sock, protocol, records, raw, trace, stream, deadline, wire, capture)
+
+
+def status(sock, protocol, records, raw, trace, tag, deadline, wire, capture):
+    response = request(sock, protocol, records, raw, trace, '/status/' + tag, deadline, wire, capture)
+    return json.loads(response['body'])
+
+
+def metrics(sock, protocol, records, raw, trace, deadline, wire, capture):
+    response = request(sock, protocol, records, raw, trace, '/metrics', deadline, wire, capture)
+    return json.loads(response['body'])
+
+
+def health(sock, protocol, records, raw, trace, deadline, wire, capture):
+    response = request(sock, protocol, records, raw, trace, '/health', deadline, wire, capture, 2)
+    require(response['body'] == 'ok', 'health differs')
+    return response
+
+
+def run(args, manifest):
+    helper = load_bound('h2_client', manifest['helper'], manifest['inputs'])
+    raw_module = load_bound('raw_observer', manifest['raw'], manifest['inputs'])
+    sys.modules['raw_observer'] = raw_module
+    wire = load_bound('admission_wire', manifest['wire'], manifest['inputs'])
+    require(wire.raw_observer is raw_module, 'raw observer binding differs')
+    cases = load_bound('credit_cases', manifest['cases'], manifest['inputs'])
+    flow = load_bound('credit_flow', manifest['flow'], manifest['inputs'])
+    require(cases.CASES == CASES, 'case catalogue differs')
+    import h2
+    import hpack
+    import hyperframe
+    for module in (h2, hpack, hyperframe):
+        require(Path(module.__file__).resolve().is_relative_to(Path(PACKAGES)), 'client module origin differs')
+    require(Path(helper.__file__).resolve() == Path(HELPER) / 'h2_client.py', 'helper origin differs')
+    overall = time.monotonic() + 900
+    run_dir = Path(args.output).resolve()
+    run_dir.mkdir(mode=0o700)
+    cert, key, log = run_dir / 'certificate.pem', run_dir / 'private-key.pem', run_dir / 'server.log'
+    nonce = os.urandom(16).hex()
+    result = {'nonce': nonce, 'cases': {}, 'success': False, 'cleanup': {},
+              'python': sys.executable, 'python_path': sys.path, 'openssl': OPENSSL,
+              'profile': manifest['binary'], 'manifest_sha256': args.manifest_sha256}
+    child = None
+    sock = None
+    start_id = None
+    error = None
+    failure = None
+    stage = 'setup'
+    capture = new_capture()
+    collector = None
+    try:
+        stage = 'certificate'
+        command = [OPENSSL, 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
+                   '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost',
+                   '-keyout', str(key), '-out', str(cert)]
+        result['certificate_command'] = command
+        certificate_env = {'OPENSSL_CONF': '/opt/conda/ssl/openssl.cnf'}
+        result['certificate_environment'] = certificate_env
+        subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True,
+                       env=certificate_env, timeout=remaining(overall))
+        os.chmod(key, 0o600)
+        cert_der = ssl.PEM_cert_to_DER_cert(cert.read_text())
+        result['certificate_sha256'] = hashlib.sha256(cert_der).hexdigest()
+        env = {'H2_PROFILE_CERT': str(cert), 'H2_PROFILE_KEY': str(key), 'H2_PROFILE_NONCE': nonce}
+        result['child_argv'] = [manifest['binary']]
+        result['child_environment'] = env.copy()
+        stage = 'launch'
+        child = subprocess.Popen([manifest['binary']], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
+        collector = threading.Thread(target=drain_capture, args=(child.stdout, capture), daemon=True)
+        collector.start()
+        start_id = child_start(child.pid)
+        result['child'] = {'pid': child.pid, 'start': start_id, 'binary_sha256': digest(manifest['binary'])}
+        deadline = min(overall, time.monotonic() + 15)
+        stage = 'readiness'
+        result['listener_inode'] = wait_marker(child, capture, nonce, deadline)
+        ready_output = capture_snapshot(capture)[0].decode('utf-8')
+        capacity = [line for line in ready_output.splitlines() if 'H2_CAPACITY ' in line]
+        require(len(capacity) == 1 and 'slab=4098304' in capacity[0], 'fixture capacity differs')
+        result['capacity'] = capacity[0]
+        require(child_start(child.pid) == start_id and child.poll() is None, 'owned child changed')
+        context = ssl.create_default_context(cafile=str(cert))
+        context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_3
+        context.set_alpn_protocols(['h2'])
+        p32 = helper.payload_block(32, 0, 32)
+        require(p32 == bytes(range(1, 11)) + b'final-upload-sentinel!', 'payload literal differs')
+        require(hashlib.sha256(p32).hexdigest() == cases.H32 and hashlib.sha256(p32[:7]).hexdigest() == cases.H7, 'payload digest differs')
+        result['connections'] = []
+        connection_cases = args.cases
+        for case in connection_cases:
+            stage = 'case:' + case + ':connect'
+            if sock is not None:
+                require(not records and not raw_state['streams'], 'records remain on previous connection')
+                sock.close()
+                sock = None
+            deadline = min(overall, time.monotonic() + 30)
+            require(child.poll() is None and child_start(child.pid) == start_id, 'owned child changed')
+            require(owned_listener(child.pid) == [result['listener_inode']], 'owned listener changed')
+            raw = socket.create_connection(('127.0.0.1', PORT), timeout=remaining(deadline))
+            try:
+                raw.settimeout(remaining(deadline))
+                sock = context.wrap_socket(raw, server_hostname='localhost', suppress_ragged_eofs=False)
+            except BaseException:
+                raw.close()
+                raise
+            require(sock.version() == 'TLSv1.3' and sock.selected_alpn_protocol() == 'h2', 'TLS/ALPN differs')
+            require(hashlib.sha256(sock.getpeercert(binary_form=True)).hexdigest() == result['certificate_sha256'], 'peer certificate identity differs')
+            require(child.poll() is None and child_start(child.pid) == start_id, 'owned child died')
+            protocol, records, raw_state = helper.new_protocol(), {}, raw_module.new_state()
+            trace = {'events': {}, 'ledger': flow.FlowLedger(), 'flow': flow, 'snapshots': []}
+            flush(sock, protocol, deadline, capture)
+            health(sock, protocol, records, raw_state, trace, deadline, wire, capture)
+            require(protocol.remote_settings.initial_window_size == 65535, 'initial stream window differs')
+            if case == 'shutdown_idle':
+                result['connections'].append({'case': case, 'tls': sock.version(), 'alpn': sock.selected_alpn_protocol(), 'snapshots': trace['snapshots']})
+                continue
+            def begin(tag, policy):
+                path = '/limit/' + tag + '?case=' + tag
+                stream = start(protocol, records, raw_state, 'POST', path,
+                               [('content-length', '32'), ('x-case', tag)], False,
+                               1024 if policy == 'healthy' else 0, wire, policy=policy)
+                flow.open_stream(trace['ledger'], stream)
+                flush_headers(sock, protocol, deadline, capture, stream)
+                return stream
+            def sibling():
+                stream = start(protocol, records, raw_state, 'POST', '/echo', [('content-length', '1')], False, 1, wire)
+                flow.open_stream(trace['ledger'], stream)
+                flush_headers(sock, protocol, deadline, capture, stream)
+                return stream
+            def send_bytes(stream, data, end_stream):
+                require(len(data) <= 8192, 'data bound')
+                ledger = trace['ledger']
+                flow.check_public(ledger, protocol.outbound_flow_control_window, {stream: protocol.local_flow_control_window(stream)})
+                flow.send_data(ledger, stream, len(data), None, protocol.max_outbound_frame_size, end_stream)
+                protocol.send_data(stream, data, end_stream=end_stream)
+                flush(sock, protocol, deadline, capture)
+            offsets = {}
+            def send(stream, length, end_stream):
+                offset = offsets.get(stream, 0)
+                require(offset + length <= len(p32), 'payload offset bound')
+                send_bytes(stream, p32[offset:offset + length], end_stream)
+                offsets[stream] = offset + length
+            def do_control(operation, tag, expected):
+                item = request(sock, protocol, records, raw_state, trace, '/control/' + operation + '/' + tag, deadline, wire, capture, 64)
+                require(item['body'] == expected, 'control response differs')
+                return item
+            def finish_terminal(stream):
+                trace['ledger'].streams[stream].open = False
+                return complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture)
+            def finish_sibling(stream):
+                ledger = trace['ledger']
+                sent_before, refunded_before = ledger.sent, ledger.refunded
+                send_bytes(stream, b's', True)
+                item = complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture)
+                require(item['body'] == 's' and item['bytes'] == 1, 'sibling response differs')
+                require(ledger.sent == sent_before + 1 and refunded_before <= ledger.refunded <= ledger.sent, 'sibling flow differs')
+                item['flow'] = {'sent_before': sent_before, 'sent_after': ledger.sent,
+                                'refunded_before': refunded_before, 'refunded_after': ledger.refunded,
+                                'connection_window': ledger.connection, 'public_window': protocol.outbound_flow_control_window}
+                return item
+            def reclaim(target):
+                ledger = trace['ledger']
+                while not flow.primary_refund_complete(ledger, target, protocol.outbound_flow_control_window):
+                    receive(sock, protocol, records, raw_state, trace, deadline, wire, capture)
+                return {'target': target, 'sent': ledger.sent, 'refunded': ledger.refunded,
+                        'connection_window': ledger.connection, 'public_window': protocol.outbound_flow_control_window}
+            def finish_recovery(stream):
+                item = complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture)
+                return json.loads(item['body'])
+            def pending(stream):
+                require(records[stream]['headers'] is None and not records[stream]['ended'] and not raw_state['streams'][stream]['reset'], 'unexpected early target terminal')
+            api = {'start': begin, 'sibling': sibling, 'send': send,
+                   'status': lambda tag: status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture),
+                   'control': do_control, 'finish_terminal': finish_terminal,
+                   'finish_sibling': finish_sibling, 'reclaim': reclaim, 'finish_recovery': finish_recovery,
+                   'pending': pending}
+            stage = 'case:' + case + ':execute'
+            result['cases'][case] = cases.execute(api, case)
+            require(not records and not raw_state['streams'], 'response records remain after case')
+            require(trace['ledger'].sent == (65 if case == 'end_error' else 48), 'case flow total differs')
+            result['connections'].append({'case': case, 'tls': sock.version(), 'alpn': sock.selected_alpn_protocol(),
+                                          'events': trace['events'], 'snapshots': trace['snapshots'],
+                                          'sent_flow': trace['ledger'].sent, 'refunded_flow': trace['ledger'].refunded})
+        stage = 'final_status'
+        deadline = min(overall, time.monotonic() + 30)
+        final = {tag: status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture) for tag in cases.TAGS}
+        aggregate = metrics(sock, protocol, records, raw_state, trace, deadline, wire, capture)
+        selected = cases.selected_tags(args.cases)
+        for tag in cases.TAGS:
+            cases.verify_record(final[tag], cases.expected(tag, selected))
+        for field in ('middleware', 'attempts', 'begin', 'end', 'cancel', 'failure', 'end_errors', 'chunk_errors', 'invalid_progress', 'accepted', 'errors'):
+            require(aggregate[field] == sum(record[field] for record in final.values()), 'aggregate ' + field + ' differs')
+        expected_buffered = len(args.cases) + 33 + sum(6 + (case != 'end_error') for case in args.cases if case in cases.PRIMARIES)
+        require(aggregate['buffered_middleware'] == expected_buffered, 'buffered middleware count differs')
+        require(aggregate['active'] == 0 and not aggregate['slot0_active'] and not aggregate['slot1_active'], 'active fixture')
+        result['final_status'] = final
+        result['final_metrics'] = aggregate
+        sock.close()
+        sock = None
+        require(child_start(child.pid) == start_id and child.poll() is None, 'child identity changed')
+        stage = 'shutdown'
+        graceful_deadline = min(overall, time.monotonic() + 15)
+        os.kill(child.pid, signal.SIGTERM)
+        exit_code = child.wait(timeout=remaining(graceful_deadline))
+        result['cleanup'] = {'signal': 'SIGTERM', 'exit_code': exit_code, 'reaped': True, 'forced': False}
+        require(exit_code == 0, 'owned server exit differs')
+        collector.join(timeout=remaining(graceful_deadline))
+        require(not collector.is_alive(), 'server output collector did not finish')
+        check_capture(capture)
+        text = capture_snapshot(capture)[0].decode('utf-8')
+        post = {}
+        post_metrics = None
+        for line in text.splitlines():
+            marker = 'H2_RECORD ' + nonce + ' '
+            if marker in line:
+                item = json.loads(line.split(marker, 1)[1])
+                require(item['tag'] not in post, 'duplicate post-deinit tag')
+                post[item['tag']] = item
+            marker = 'H2_DEINIT ' + nonce + ' '
+            if marker in line:
+                require(post_metrics is None, 'duplicate post-deinit aggregate')
+                post_metrics = json.loads(line.split(marker, 1)[1])
+        require(post == final and post_metrics == aggregate, 'post-deinit state differs')
+        result['cases']['shutdown_idle'] = {'exit_code': exit_code, 'post_deinit': True}
+        result['success'] = True
+    except BaseException as exc:
+        error = repr(exc)
+        failure = failure_details(exc, stage)
+    finally:
+        def close_socket():
+            if sock is not None:
+                sock.close()
+
+        def signal_child():
+            if child is None or child.poll() is not None:
+                return
+            require(start_id is None or child_start(child.pid) == start_id, 'child identity changed during cleanup')
+            result['cleanup']['forced'] = True
+            child.kill()
+
+        def wait_child():
+            if child is None:
+                return
+            child.wait(timeout=15)
+            result['cleanup']['exit_code'] = child.returncode
+            result['cleanup']['reaped'] = True
+
+        def delete_key():
+            key.unlink(missing_ok=True)
+            require(not key.exists(), 'private key remains')
+
+        def save_log():
+            if collector is not None:
+                collector.join(timeout=15)
+            data, overflow, collector_error = capture_snapshot(capture)
+            log.write_bytes(data)
+            require(collector is None or not collector.is_alive(), 'server output collector did not finish')
+            require(not overflow and collector_error is None, 'server output collection failed or overflowed')
+
+        def close_pipe():
+            if child is not None and child.stdout is not None:
+                child.stdout.close()
+
+        errors = cleanup_actions((('socket', close_socket), ('child_signal', signal_child),
+                                  ('child_wait', wait_child), ('key', delete_key), ('log', save_log),
+                                  ('pipe', close_pipe)))
+        if errors or result['cleanup'].get('forced', False):
+            result['success'] = False
+        result['cleanup']['errors'] = errors
+        result['error'] = error
+        result['failure'] = failure
+        (run_dir / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
+    require(result['success'], 'owned run failed: ' + str(error))
+
+
+def main():
+    parser = argparse.ArgumentParser()
+    parser.add_argument('--run', action='store_true', required=True)
+    parser.add_argument('--manifest', type=Path, required=True)
+    parser.add_argument('--manifest-sha256', required=True)
+    parser.add_argument('--output', required=True)
+    parser.add_argument('--cases', nargs='+', choices=CASES, required=True)
+    args = parser.parse_args()
+    require(dict(os.environ) == {'PYTHONPATH': PACKAGES + ':' + HELPER, 'LC_ALL': 'C.UTF-8'},
+            'runner environment must contain only the pinned locale and PYTHONPATH')
+    require(sys.executable == PYTHON and sys.dont_write_bytecode and sys.flags.no_site and os.environ.get('PYTHONPATH') == PACKAGES + ':' + HELPER,
+            'Python interpreter or PYTHONPATH differs')
+    require(len(set(args.cases)) == len(args.cases) and ('shutdown_idle' not in args.cases or args.cases[-1] == 'shutdown_idle'), 'invalid case order')
+    output = Path(args.output)
+    require(output.is_absolute() and output.resolve().is_relative_to(Path('/tmp')) and output.resolve() != Path('/tmp'), 'output must be new /tmp path')
+    require(not output.exists(), 'output already exists')
+    manifest = check_manifest(args.manifest, args.manifest_sha256)
+    run(args, manifest)
+
+
+if __name__ == '__main__':
+    main()

diff --git a//tmp/uwz-task5c2-runtime-v2/test_credit_case.py b//tmp/uwz-task5c2-runtime-v2/test_credit_case.py
--- /dev/null
+++ /tmp/uwz-task5c2-runtime-v2/test_credit_case.py
@@ -0,0 +1,117 @@
+"""Offline regression for actual case order and the caller-owned flow ledger."""
+import unittest
+
+import cases
+import flow_ledger as flow
+
+
+class CaseHarness:
+    def __init__(self, case, refunded):
+        self.case = case
+        self.refunded = refunded
+        self.ledger = flow.FlowLedger()
+        self.next_stream = 1
+        self.terminal = False
+        self.recovery = False
+        self.sibling_sent = False
+
+    def open(self):
+        stream = self.next_stream
+        self.next_stream += 2
+        flow.open_stream(self.ledger, stream)
+        return stream
+
+    def sibling(self):
+        return self.open()
+
+    def start(self, tag, policy):
+        self.recovery = tag.endswith('_recovery')
+        return self.open()
+
+    def send(self, stream, count, end):
+        flow.send_data(self.ledger, stream, count, None, 16384, end)
+        if not self.recovery and (end or self.ledger.sent >= 15):
+            self.terminal = True
+
+    def status(self, tag):
+        end_failure = self.case == 'end_error'
+        return {'begin': 1, 'accepted': 32 if end_failure else 7,
+                'sha256': cases.H32 if end_failure else cases.H7,
+                'end': int(self.terminal and end_failure),
+                'end_errors': int(self.terminal and end_failure),
+                'cancel': int(self.terminal and not end_failure), 'paused': False,
+                'reason': 'sink_failure' if self.terminal and not end_failure else 'none',
+                'active': not self.terminal}
+
+    def pending(self, stream):
+        return None
+
+    def control(self, operation, tag, expected):
+        if expected == 'ok':
+            self.terminal = True
+        return expected
+
+    def peer_reset(self, stream):
+        self.terminal = True
+        return {'code': 8}
+
+    def finish_terminal(self, stream):
+        self.ledger.streams[stream].open = False
+        flow.receive_batch(self.ledger, [(0, self.refunded)])
+        return {'reset': True}
+
+    def finish_sibling(self, stream):
+        flow.send_data(self.ledger, stream, 1, None, 16384, True)
+        flow.receive_batch(self.ledger, [(0, 1)])
+        self.sibling_sent = True
+        return {'body': 's'}
+
+    def reclaim(self, target):
+        if not flow.primary_refund_complete(self.ledger, target, self.ledger.connection):
+            raise ValueError('primary refund incomplete')
+        return {'target': target, 'sent': self.ledger.sent, 'refunded': self.ledger.refunded}
+
+    def finish_recovery(self, stream):
+        result = cases.expected(self.case + '_recovery', {self.case + '_recovery'})
+        result.update(chunks=1, max_span=32)
+        return result
+
+    def api(self):
+        return {name: getattr(self, name) for name in ('start', 'sibling', 'send', 'status', 'control',
+                'peer_reset', 'finish_terminal', 'finish_sibling', 'reclaim', 'finish_recovery', 'pending')}
+
+
+class CreditCaseTests(unittest.TestCase):
+    def test_partial_primary_cannot_be_masked_by_sibling(self):
+        for case, target in (('sink_error', 15), ('invalid_progress', 15), ('end_error', 32)):
+            with self.subTest(case=case):
+                harness = CaseHarness(case, target - 1)
+                with self.assertRaisesRegex(ValueError, 'primary refund incomplete'):
+                    cases.execute(harness.api(), case)
+                self.assertFalse(harness.sibling_sent)
+
+    def test_sibling_cannot_mask_partial_refund(self):
+        for target in (15, 32):
+            ledger = flow.FlowLedger()
+            flow.open_stream(ledger, 1)
+            flow.open_stream(ledger, 3)
+            flow.send_data(ledger, 1, target, None, 16384, False)
+            flow.receive_batch(ledger, [(0, target - 1)])
+            flow.send_data(ledger, 3, 1, None, 16384, True)
+            flow.receive_batch(ledger, [(0, 1)])
+            with self.assertRaisesRegex(ValueError, 'primary-only flow differs'):
+                flow.primary_refund_complete(ledger, target, ledger.connection)
+
+    def test_complete_primary_before_sibling_and_recovery(self):
+        for case, target in (('sink_error', 15), ('invalid_progress', 15), ('end_error', 32)):
+            with self.subTest(case=case):
+                harness = CaseHarness(case, target)
+                result = cases.execute(harness.api(), case)
+                self.assertEqual(result['credit'], {'target': target, 'sent': target, 'refunded': target})
+                self.assertTrue(harness.sibling_sent)
+                self.assertEqual(harness.ledger.sent, target + 33)
+                self.assertEqual(harness.ledger.refunded, target + 1)
+
+
+if __name__ == '__main__':
+    unittest.main()

diff --git a//tmp/uwz-task5c2-runtime-v2/test_listener.py b//tmp/uwz-task5c2-runtime-v2/test_listener.py
--- /dev/null
+++ /tmp/uwz-task5c2-runtime-v2/test_listener.py
@@ -0,0 +1,96 @@
+"""Offline synthetic filesystem tests for the actual ownership helper."""
+import unittest
+from unittest.mock import patch
+
+import run_live
+
+
+class FakePath:
+    def __init__(self, entries, rows, directory_error=None):
+        self.entries = entries
+        self.rows = rows
+        self.directory_error = directory_error
+
+    def __call__(self, *parts):
+        return FakeNode(self, parts)
+
+
+class FakeNode:
+    def __init__(self, owner, parts):
+        self.owner = owner
+        self.parts = parts
+
+    def iterdir(self):
+        if self.owner.directory_error:
+            raise self.owner.directory_error
+        return iter(self.owner.entries)
+
+    def read_text(self):
+        if isinstance(self.owner.rows, BaseException):
+            raise self.owner.rows
+        return 'header\n' + ''.join(item + '\n' for item in self.owner.rows)
+
+
+def row(inode, endpoint='0100007F:6F1B', state='0A'):
+    return '0: %s 00000000:0000 %s 0 0 0 0 0 %s' % (endpoint, state, inode)
+
+
+def evaluate(entries, targets, rows, directory_error=None):
+    paths = FakePath(entries, rows, directory_error)
+
+    def readlink(entry):
+        value = targets[entry]
+        if isinstance(value, BaseException):
+            raise value
+        return value
+
+    with patch.object(run_live, 'Path', paths), patch.object(run_live.os, 'readlink', readlink):
+        result = run_live.owned_listener(17)
+        run_live.require(len(result) == 1, 'owned loopback listener not uniquely identified')
+        return result
+
+
+class ListenerTests(unittest.TestCase):
+    def test_disappearing_enumerated_nonlistener(self):
+        self.assertEqual(evaluate(['gone', 'listener'], {'gone': FileNotFoundError(2, 'gone', 'gone'),
+                         'listener': 'socket:[42]'}, [row('42')]), ['42'])
+
+    def test_missing_listener_wrong_inode_endpoint_or_state(self):
+        for rows in ([], [row('43')], [row('42', endpoint='0200007F:6F1B')], [row('42', state='01')]):
+            with self.subTest(rows=rows):
+                with self.assertRaisesRegex(RuntimeError, 'listener not uniquely'):
+                    evaluate(['listener'], {'listener': 'socket:[42]'}, rows)
+
+    def test_multiple_owned_listeners_fail(self):
+        with self.assertRaisesRegex(RuntimeError, 'listener not uniquely'):
+            evaluate(['first', 'second'], {'first': 'socket:[42]', 'second': 'socket:[43]'}, [row('42'), row('43')])
+
+    def test_listener_table_error_propagates(self):
+        with self.assertRaises(PermissionError):
+            evaluate(['listener'], {'listener': 'socket:[42]'}, PermissionError(13, 'denied', '/proc/net/tcp'))
+
+    def test_missing_child_directory_propagates(self):
+        with self.assertRaises(FileNotFoundError):
+            evaluate([], {}, [row('42')], FileNotFoundError(2, 'missing child', '/proc/17/fd'))
+
+    def test_permission_and_other_io_errors_propagate(self):
+        for exc in (PermissionError(13, 'denied', 'entry'), OSError(5, 'io', 'entry')):
+            with self.subTest(error=exc):
+                with self.assertRaises(type(exc)):
+                    evaluate(['bad', 'listener'], {'bad': exc, 'listener': 'socket:[42]'}, [row('42')])
+
+    def test_failure_details_retain_type_filename_traceback_and_stage(self):
+        try:
+            raise FileNotFoundError(2, 'missing', '/synthetic/path')
+        except FileNotFoundError as exc:
+            detail = run_live.failure_details(exc, 'case:peer_reset:connect')
+        self.assertEqual(detail['type'], 'FileNotFoundError')
+        self.assertEqual(detail['filename'], '/synthetic/path')
+        self.assertIn('missing', detail['message'])
+        self.assertEqual(detail['stage'], 'case:peer_reset:connect')
+        self.assertIn('FileNotFoundError', detail['traceback'])
+        self.assertIn('test_failure_details', detail['traceback'])
+
+
+if __name__ == '__main__':
+    unittest.main()

diff --git a//tmp/uwz-task5c2-runtime-v2/test_observer.py b//tmp/uwz-task5c2-runtime-v2/test_observer.py
--- /dev/null
+++ /tmp/uwz-task5c2-runtime-v2/test_observer.py
@@ -0,0 +1,138 @@
+"""Offline frame-policy tests using the pinned hyperframe codec."""
+import unittest
+
+from hyperframe.frame import DataFrame, HeadersFrame, RstStreamFrame
+import raw_observer as observer
+
+
+def frame(kind, stream=1, code=8, end=False, payload=b''):
+    item = kind(stream)
+    if kind is RstStreamFrame:
+        item.error_code = code
+    else:
+        item.data = payload
+        if end:
+            item.flags.add('END_STREAM')
+    return item.serialize()
+
+
+class ObserverTests(unittest.TestCase):
+    def state(self, policy='healthy'):
+        state = observer.new_state()
+        observer.register(state, 1, policy)
+        return state
+
+    def test_public_cancel_fragmented_and_coalesced(self):
+        state = self.state('public_cancel')
+        raw = frame(RstStreamFrame) + frame(DataFrame, stream=3, payload=b'x')
+        observer.register(state, 3, 'healthy')
+        for part in (raw[:2], raw[2:11], raw[11:]):
+            observer.observe(state, part)
+        self.assertTrue(state['streams'][1]['reset'])
+        self.assertIsNone(state['frame'])
+        observer.retire(state, 1)
+
+    def test_application_failure_fragmented_reset(self):
+        state = self.state('application_failure')
+        raw = frame(RstStreamFrame, code=2)
+        observer.observe(state, raw[:-1])
+        self.assertFalse(state['streams'][1]['reset'])
+        observer.observe(state, raw[-1:])
+        observer.retire(state, 1)
+        state = self.state('application_failure')
+        observer.register(state, 3, 'healthy')
+        observer.observe(state, frame(RstStreamFrame, code=2) + frame(DataFrame, stream=3, end=True, payload=b'x'))
+        observer.retire(state, 1)
+        observer.retire(state, 3)
+
+    def test_application_failure_rejects_invalid_frames(self):
+        for raw in (frame(RstStreamFrame, stream=3, code=2), frame(RstStreamFrame, code=8),
+                    frame(RstStreamFrame, code=2) * 2):
+            with self.subTest(raw=raw):
+                with self.assertRaises(ValueError):
+                    observer.observe(self.state('application_failure'), raw)
+        state = self.state('application_failure')
+        with self.assertRaises(ValueError):
+            observer.retire(state, 1)
+        observer.observe(state, frame(RstStreamFrame, code=2))
+        with self.assertRaises(ValueError):
+            observer.observe(state, frame(DataFrame, payload=b'x'))
+
+    def test_refusal_after_final(self):
+        state = self.state('refusal_after_final')
+        observer.observe(state, frame(DataFrame, end=True, payload=b'x') + frame(RstStreamFrame, code=0))
+        observer.retire(state, 1)
+        state = self.state('refusal_after_final')
+        with self.assertRaises(ValueError):
+            observer.observe(state, frame(RstStreamFrame, code=0))
+
+    def test_wrong_reset_and_duplicates(self):
+        for raw in (frame(RstStreamFrame, stream=3), frame(RstStreamFrame, code=2),
+                    frame(RstStreamFrame) * 2):
+            with self.subTest(raw=raw):
+                with self.assertRaises(ValueError):
+                    observer.observe(self.state('public_cancel'), raw)
+        state = self.state('public_cancel')
+        with self.assertRaises(ValueError):
+            observer.retire(state, 1)
+        observer.observe(state, frame(RstStreamFrame))
+        observer.retire(state, 1)
+        with self.assertRaises(ValueError):
+            observer.observe(state, frame(RstStreamFrame))
+
+    def test_payload_after_terminal(self):
+        for terminal, policy in ((frame(DataFrame, end=True), 'healthy'),
+                                 (frame(RstStreamFrame), 'public_cancel')):
+            for kind in (DataFrame, HeadersFrame):
+                with self.subTest(policy=policy, kind=kind):
+                    state = self.state(policy)
+                    observer.observe(state, terminal)
+                    with self.assertRaises(ValueError):
+                        observer.observe(state, frame(kind, payload=b'x'))
+
+    def test_end_only_after_payload(self):
+        state = self.state()
+        raw = frame(DataFrame, end=True, payload=b'abc')
+        observer.observe(state, raw[:-1])
+        self.assertFalse(state['streams'][1]['end'])
+        observer.observe(state, raw[-1:])
+        self.assertTrue(state['streams'][1]['end'])
+
+    def test_peer_reset_is_local_observation_only(self):
+        state = self.state('peer_reset')
+        with self.assertRaises(ValueError):
+            observer.retire(state, 1)
+        observer.mark_peer_reset(state, 1, 8)
+        with self.assertRaises(ValueError):
+            observer.observe(state, frame(RstStreamFrame))
+        observer.retire(state, 1)
+        with self.assertRaises(ValueError):
+            observer.observe(state, frame(DataFrame, payload=b'x'))
+
+    def test_more_than_32_sequential_responses_and_old_id(self):
+        state = observer.new_state()
+        for stream in range(1, 81, 2):
+            observer.register(state, stream, 'healthy')
+            observer.observe(state, frame(DataFrame, stream=stream, end=True))
+            observer.retire(state, stream)
+        with self.assertRaises(ValueError):
+            observer.observe(state, frame(DataFrame, stream=1, payload=b'x'))
+        with self.assertRaises(ValueError):
+            observer.observe(state, frame(RstStreamFrame, stream=1))
+        with self.assertRaises(ValueError):
+            observer.register(state, 1, 'healthy')
+
+    def test_bounds(self):
+        state = self.state()
+        with self.assertRaises(ValueError):
+            observer.observe(state, b'x' * (observer.READ_BOUND + 1))
+        with self.assertRaises(ValueError):
+            observer.observe(observer.new_state(), b'\x00\x40\x01\x00\x00\x00\x00\x00\x01')
+        for stream in range(3, 16, 2):
+            observer.register(state, stream, 'healthy')
+        with self.assertRaises(ValueError):
+            observer.register(state, 17, 'healthy')
+
+
+if __name__ == '__main__':
+    unittest.main()

diff --git a//tmp/uwz-task5c2-runtime-v2/validate_builds.py b//tmp/uwz-task5c2-runtime-v2/validate_builds.py
--- /dev/null
+++ /tmp/uwz-task5c2-runtime-v2/validate_builds.py
@@ -0,0 +1,59 @@
+"""Validate the two actual compile receipts against current bound inputs."""
+import hashlib
+import json
+from pathlib import Path
+
+ARCHIVES = tuple('/workspaces/uWebZockets/zig-out/lib/' + n for n in (
+    'libuWebZockets.a', 'libssl.a', 'libcrypto.a', 'liblsquic.a', 'libdeflate.a', 'libz.a'))
+
+
+def digest(path):
+    h = hashlib.sha256()
+    with open(path, 'rb') as stream:
+        while data := stream.read(1048576):
+            h.update(data)
+    return h.hexdigest()
+
+
+def validate(manifest, current):
+    receipts = manifest['build_input_receipts']
+    if len(receipts) != 2:
+        raise ValueError('two actual receipts required')
+    merged = {}
+    for path, mode in zip(receipts, ('Debug', 'ReleaseSafe')):
+        receipt = json.loads(Path(path).read_text())
+        argv = receipt['argv']
+        inputs = {v.split('=', 1)[1] for v in argv if v.startswith('-M') and '=' in v}
+        archives = {v for v in argv if v.endswith('.a')}
+        if len(inputs) != 6 or archives != set(ARCHIVES):
+            raise ValueError('build modules or archives differ')
+        inputs.update(archives)
+        inputs.add(argv[0])
+        before = receipt['input_before']
+        if set(before) != inputs or before != receipt['input_after']:
+            raise ValueError('build input maps differ')
+        if receipt['optimization'] != mode or receipt['exit_status'] != 0 or not receipt['unchanged']:
+            raise ValueError('build failed or changed')
+        if receipt['source_before'] != receipt['source_after'] or receipt['override_before'] != receipt['override_after'] or receipt['snapshot_before'] != receipt['snapshot_after']:
+            raise ValueError('build inventory changed')
+        if len(receipt['source_before']) != 1031 or len(receipt['override_before']) != 93:
+            raise ValueError('build tree count differs')
+        if receipt['source_before'] != manifest['trees']['/tmp/uwz-task4d-fix1-frozen'] or receipt['override_before'] != manifest['trees']['/tmp/uwz-reviewed-libxev-c223-loop-callbacks'] or receipt['snapshot_before'] != manifest['trees']['/tmp/uwz-task5c2-fixture-v2']:
+            raise ValueError('build and current inventory differ')
+        if receipt['cwd'] != '/tmp/uwz-task4d-fix1-frozen' or receipt['environment'] != {'LC_ALL': 'C.UTF-8'} or '-j2' not in argv:
+            raise ValueError('build environment differs')
+        for name, value in before.items():
+            if current.get(name) != value or name in merged and merged[name] != value:
+                raise ValueError('current build input differs: ' + name)
+            merged[name] = value
+        output = next(v.split('=', 1)[1] for v in argv if v.startswith('-femit-bin='))
+        if current.get(output) != receipt['binary_sha256']:
+            raise ValueError('build binary differs')
+        directory = Path(path).parent
+        for key in ('stdout', 'stderr'):
+            log = directory / receipt[key]
+            if log.read_bytes() or current.get(str(log)) != digest(log):
+                raise ValueError('compiler output differs')
+    if any(merged[p] != manifest['approved_archives'][p] for p in ARCHIVES):
+        raise ValueError('reviewed archive differs')
+    return merged

diff --git a//tmp/uwz-task5c2-runtime-v2/wire.py b//tmp/uwz-task5c2-runtime-v2/wire.py
--- /dev/null
+++ /tmp/uwz-task5c2-runtime-v2/wire.py
@@ -0,0 +1,104 @@
+"""Bounded HTTP/2 response event and raw reset observation."""
+import hashlib
+import h2.events
+import raw_observer
+
+READ_BOUND = 8192
+STREAM_LIMIT = 8
+HEADER_FIELDS = 32
+HEADER_BYTES = 4096
+INFO_COUNT = 16
+INFO_BYTES = 16384
+EVENT_LIMIT = 64
+
+
+def require(condition, message):
+    if not condition:
+        raise ValueError(message)
+
+
+def register(records, raw, stream_id, body_limit, final_status, info_count, policy):
+    require(len(records) < STREAM_LIMIT and stream_id not in records, 'stream record bound')
+    require(0 <= body_limit < 4096 and info_count in (0, 1), 'invalid expectation')
+    raw_observer.register(raw, stream_id, policy)
+    records[stream_id] = {'headers': None, 'informationals': 0, 'info_bytes': 0,
+                          'bytes': 0, 'hash': hashlib.sha256(), 'body': bytearray(),
+                          'limit': body_limit, 'ended': False, 'reset_event': False,
+                          'status': str(final_status), 'expected_info': info_count,
+                          'policy': policy}
+
+
+def checked_headers(headers):
+    require(len(headers) <= HEADER_FIELDS, 'header field count bound')
+    size = sum(len(k.encode('utf-8')) + len(v.encode('utf-8')) + 32 for k, v in headers)
+    require(size <= HEADER_BYTES, 'header byte bound')
+    return size
+
+
+def accept(protocol, data, records, raw, trace):
+    require(len(data) <= READ_BOUND, 'read exceeds bound')
+    raw_observer.observe(raw, data)
+    events = protocol.receive_data(data)
+    for event in events:
+        name = type(event).__name__
+        require(name in trace or len(trace) < EVENT_LIMIT, 'event type bound')
+        trace[name] = trace.get(name, 0) + 1
+        if isinstance(event, h2.events.ConnectionTerminated):
+            raise ValueError('HTTP/2 connection terminated')
+        if not isinstance(event, (h2.events.InformationalResponseReceived, h2.events.ResponseReceived,
+                                  h2.events.TrailersReceived, h2.events.DataReceived,
+                                  h2.events.StreamEnded, h2.events.StreamReset)):
+            continue
+        require(event.stream_id in records, 'unregistered response stream')
+        record = records[event.stream_id]
+        if isinstance(event, h2.events.InformationalResponseReceived):
+            size = checked_headers(event.headers)
+            require(record['informationals'] < INFO_COUNT and record['info_bytes'] + size <= INFO_BYTES,
+                    'informational bound')
+            require(record['headers'] is None and [v for k, v in event.headers if k == ':status'] == ['100'] and not any(k == 'x-middleware' for k, _ in event.headers), 'unexpected informational')
+            record['informationals'] += 1
+            record['info_bytes'] += size
+            require(record['informationals'] <= record['expected_info'], 'extra informational')
+        elif isinstance(event, h2.events.ResponseReceived):
+            checked_headers(event.headers)
+            require(record['headers'] is None, 'duplicate response headers')
+            require([v for k, v in event.headers if k == ':status'] == [record['status']], 'wrong final status')
+            require([v for k, v in event.headers if k == 'x-middleware'] == ['retained'], 'middleware header')
+            record['headers'] = list(event.headers)
+        elif isinstance(event, h2.events.TrailersReceived):
+            raise ValueError('unexpected trailers')
+        elif isinstance(event, h2.events.DataReceived):
+            require(not record['ended'] and record['bytes'] + len(event.data) <= record['limit'], 'response body bound')
+            record['bytes'] += len(event.data)
+            record['hash'].update(event.data)
+            record['body'].extend(event.data)
+            protocol.acknowledge_received_data(event.flow_controlled_length, event.stream_id)
+        elif isinstance(event, h2.events.StreamEnded):
+            require(not record['ended'], 'duplicate end')
+            record['ended'] = True
+        elif isinstance(event, h2.events.StreamReset):
+            require(record['policy'] in ('public_cancel', 'refusal_after_final', 'application_failure') and raw['streams'][event.stream_id]['reset'], 'unexpected reset event')
+            code = {'public_cancel': 8, 'refusal_after_final': 0, 'application_failure': 2}[record['policy']]
+            require(not record['reset_event'] and int(event.error_code) == code, 'invalid reset event')
+            record['reset_event'] = True
+
+    return events
+
+
+def complete(records, raw, stream_id):
+    record = records[stream_id]
+    policy = record['policy']
+    if policy in ('healthy', 'refusal_after_final'):
+        require(record['headers'] is not None and record['ended'], 'missing final')
+    else:
+        require(record['headers'] is None and not record['ended'], 'unexpected final')
+    require(record['informationals'] == record['expected_info'], 'missing informational')
+    require(raw['streams'][stream_id]['reset'] == (policy in ('public_cancel', 'refusal_after_final', 'application_failure')), 'missing reset')
+    if policy == 'peer_reset':
+        require(raw['streams'][stream_id]['peer_reset'], 'missing outgoing reset')
+
+
+def retire(records, raw, stream_id):
+    complete(records, raw, stream_id)
+    raw_observer.retire(raw, stream_id)
+    del records[stream_id]

diff --git a//workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/compile_fixture.py b//workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/compile_fixture.py
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/compile_fixture.py
@@ -0,0 +1,85 @@
+"""Compile one frozen fixture only; never execute its output."""
+import hashlib
+import json
+import os
+from pathlib import Path
+import subprocess
+import sys
+
+ROOT = Path('/workspaces/uWebZockets')
+HERE = Path(__file__).resolve().parent
+SOURCE = Path('/tmp/uwz-task4d-fix1-frozen')
+OVERRIDE = Path('/tmp/uwz-reviewed-libxev-c223-loop-callbacks')
+EXPECTED = 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de'
+ENV = {'LC_ALL': 'C.UTF-8'}
+
+
+def digest(path):
+    h = hashlib.sha256()
+    with open(path, 'rb') as stream:
+        while data := stream.read(1048576):
+            h.update(data)
+    return h.hexdigest()
+
+
+def inventory(path):
+    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}
+
+
+def main():
+    snapshot = Path(sys.argv[1])
+    mode = sys.argv[2]
+    label = sys.argv[3]
+    if mode not in ('debug', 'release') or not label.startswith('fixture-'):
+        raise ValueError('invalid compile selection')
+    old = json.loads((HERE.parent / 'metadata' / ('fixture-' + mode + '-final.json')).read_text())
+    argv = old['argv'].copy()
+    argv[next(i for i, v in enumerate(argv) if v.startswith('-Mroot='))] = '-Mroot=' + str(snapshot / 'profile.zig')
+    output = Path('/tmp/uwz-task5c2-' + label)
+    if output.exists():
+        raise ValueError('output exists')
+    output.mkdir()
+    argv[argv.index('--cache-dir') + 1] = '/tmp/uwz-task5c1-fixture-' + mode + '-v1/cache'
+    argv[argv.index('--global-cache-dir') + 1] = '/tmp/uwz-task5c1-fixture-' + mode + '-v1/global'
+    argv[-1] = '-femit-bin=' + str(output / 'profile')
+    before_source = inventory(SOURCE)
+    source_digest = hashlib.sha256(json.dumps(list(before_source.items())).encode()).hexdigest()
+    if len(before_source) != 1031 or source_digest != EXPECTED:
+        raise ValueError('candidate inventory mismatch')
+    before_override = inventory(OVERRIDE)
+    expected_override = json.loads((ROOT / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json').read_text())['files_sha256']
+    if len(before_override) != 93 or before_override != expected_override:
+        raise ValueError('override inventory mismatch')
+    snapshot_before = inventory(snapshot)
+    inputs = [Path(v.split('=', 1)[1]) for v in argv if v.startswith('-M')]
+    inputs += [Path(v) for v in argv if v.endswith('.a')]
+    inputs += [Path(argv[0])]
+    before = {str(p): digest(p) for p in inputs}
+    reviewed = old['input_sha256']
+    for name, value in before.items():
+        if name != str(snapshot / 'profile.zig') and reviewed.get(name) != value:
+            raise ValueError('reviewed input mismatch: ' + name)
+    result = subprocess.run(argv, cwd=SOURCE, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
+    (HERE / (label + '.stdout')).write_bytes(result.stdout)
+    (HERE / (label + '.stderr')).write_bytes(result.stderr)
+    after = {str(p): digest(p) for p in inputs}
+    source_after = inventory(SOURCE)
+    override_after = inventory(OVERRIDE)
+    snapshot_after = inventory(snapshot)
+    record = {'argv': argv, 'cwd': str(SOURCE), 'environment': ENV, 'optimization': old['optimization'],
+              'input_before': before, 'input_after': after, 'source_before': before_source, 'source_after': source_after,
+              'override_before': before_override, 'override_after': override_after, 'snapshot_before': snapshot_before,
+              'snapshot_after': snapshot_after, 'source_digest': source_digest, 'exit_status': result.returncode,
+              'binary_sha256': digest(output / 'profile') if (output / 'profile').exists() else None,
+              'stdout': label + '.stdout', 'stderr': label + '.stderr',
+              'unchanged': before == after and before_source == source_after and before_override == override_after and snapshot_before == snapshot_after}
+    (HERE / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
+    print('mode:', mode, 'exit:', result.returncode, 'stdout bytes:', len(result.stdout), 'stderr bytes:', len(result.stderr), 'unchanged:', record['unchanged'], 'binary sha256:', record['binary_sha256'])
+    if result.stderr:
+        print(result.stderr.decode(), end='')
+    if result.returncode or not record['unchanged']:
+        raise SystemExit(1)
+
+
+if __name__ == '__main__':
+    main()

diff --git a//workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/freeze_runtime.py b//workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/freeze_runtime.py
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/freeze_runtime.py
@@ -0,0 +1,96 @@
+"""Freeze current runtime modules and bind current fixture build receipts."""
+import hashlib
+import importlib.util
+import json
+from pathlib import Path
+import shutil
+import sys
+
+HERE = Path(__file__).resolve().parent
+ROOT = Path('/workspaces/uWebZockets')
+BASE = HERE.parent / 'metadata/fix1/manifest.json'
+FROZEN = Path('/tmp/uwz-task5c2-runtime-v2')
+MANIFEST = HERE / 'manifest-v2.json'
+NAMES = ('run_live.py', 'cases.py', 'wire.py', 'raw_observer.py', 'flow_ledger.py', 'validate_builds.py', 'test_observer.py', 'test_credit_case.py', 'test_listener.py')
+
+
+def digest(path):
+    h = hashlib.sha256()
+    with open(path, 'rb') as stream:
+        while data := stream.read(1048576):
+            h.update(data)
+    return h.hexdigest()
+
+
+def inventory(path):
+    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}
+
+
+def load(name, path):
+    spec = importlib.util.spec_from_file_location(name, path)
+    module = importlib.util.module_from_spec(spec)
+    sys.modules[name] = module
+    spec.loader.exec_module(module)
+    return module
+
+
+def main():
+    if FROZEN.exists() or MANIFEST.exists():
+        raise ValueError('snapshot or manifest exists')
+    base = json.loads(BASE.read_text())
+    keep = [p for p in base['trees'] if not p.startswith('/tmp/uwz-task5b4')]
+    trees = {}
+    for root in keep:
+        current = inventory(Path(root))
+        if current != base['trees'][root]:
+            raise ValueError('reviewed tree differs: ' + root)
+        trees[root] = current
+    FROZEN.mkdir(mode=0o700)
+    for name in NAMES:
+        shutil.copyfile(HERE / name, FROZEN / name)
+        (FROZEN / name).chmod(0o444)
+    FROZEN.chmod(0o555)
+    trees[str(FROZEN)] = inventory(FROZEN)
+    trees['/tmp/uwz-task5c2-fixture-v2'] = inventory(Path('/tmp/uwz-task5c2-fixture-v2'))
+    retained = ('/home/codespace/.python/current/', '/lib/', '/lib64/', '/opt/conda/')
+    inputs = {p: h for p, h in base['inputs'].items() if p.startswith(retained)}
+    helper = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'
+    inputs[helper] = '07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00'
+    receipts = [str(HERE / ('fixture-' + mode + '-v2.json')) for mode in ('debug', 'release')]
+    for receipt_path in receipts:
+        receipt = json.loads(Path(receipt_path).read_text())
+        inputs.update(receipt['input_before'])
+        inputs[receipt_path] = digest(receipt_path)
+        for name in (receipt['stdout'], receipt['stderr']):
+            path = str(HERE / name)
+            inputs[path] = digest(path)
+        output = next(v.split('=', 1)[1] for v in receipt['argv'] if v.startswith('-femit-bin='))
+        inputs[output] = receipt['binary_sha256']
+    for name in NAMES:
+        inputs[str(FROZEN / name)] = digest(FROZEN / name)
+        inputs[str(HERE / name)] = digest(HERE / name)
+    for name in ('profile.zig', 'compile_fixture.py', 'freeze_runtime.py'):
+        inputs[str(HERE / name)] = digest(HERE / name)
+    for path, value in inputs.items():
+        if digest(path) != value:
+            raise ValueError('input differs: ' + path)
+    approved = json.loads((HERE.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
+    validator = load('validate_builds', FROZEN / 'validate_builds.py')
+    manifest = {'state': 'ready-for-independent-review', 'scope': 'intermediate fixture builds and current runtime sources; no live execution',
+                'trees': trees, 'tree_counts': {p: len(v) for p, v in trees.items()}, 'inputs': inputs,
+                'build_input_receipts': receipts, 'approved_archives': {p: approved[p] for p in validator.ARCHIVES},
+                'binary': '/tmp/uwz-task5c2-fixture-release-v2/profile', 'helper': helper,
+                'environment': {'LC_ALL': 'C.UTF-8', 'PYTHONPATH': '/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'},
+                'python': '/home/codespace/.python/current/bin/python3', 'python_flags': ['-B', '-S']}
+    for key, name in (('runner', 'run_live.py'), ('cases', 'cases.py'), ('wire', 'wire.py'), ('raw', 'raw_observer.py'), ('flow', 'flow_ledger.py'), ('validator', 'validate_builds.py')):
+        manifest[key] = str(FROZEN / name)
+    validator.validate(manifest, inputs)
+    MANIFEST.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
+    print('frozen runtime files:', len(trees[str(FROZEN)]))
+    print('tree counts:', manifest['tree_counts'])
+    print('direct inputs:', len(inputs))
+    print('manifest sha256:', digest(MANIFEST))
+
+
+if __name__ == '__main__':
+    main()

diff --git a//workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/check_closure.py b//workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/check_closure.py
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/check_closure.py
@@ -0,0 +1,27 @@
+import hashlib
+import importlib.util
+from pathlib import Path
+
+here = Path(__file__).resolve().parent
+manifest = here / 'manifest-v2.json'
+runner = Path('/tmp/uwz-task5c2-runtime-v2/run_live.py')
+spec = importlib.util.spec_from_file_location('runner', runner)
+module = importlib.util.module_from_spec(spec)
+spec.loader.exec_module(module)
+digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
+module.check_manifest(manifest, digest)
+print('current closure: accepted')
+target = here / 'cases.py'
+original = target.read_bytes()
+try:
+    target.write_bytes(original + b'\n')
+    try:
+        module.check_manifest(manifest, digest)
+    except RuntimeError as error:
+        print('mutated actual input: rejected:', error)
+    else:
+        raise AssertionError('mutated input accepted')
+finally:
+    target.write_bytes(original)
+module.check_manifest(manifest, digest)
+print('restored closure: accepted')
