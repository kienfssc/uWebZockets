# Task5c2 actual application-error run

sink_error/invalid_progress/end_error/shutdown_idle pass in one separately
authorized owned host Linux ReleaseSafe TLS1.3/h2 run, session54682/finalchunk
6a4b13/exit0/emptyoutput. Authorization675925f681ac79824d125120f3b8be535cc6ee1fefdcc2e603553ebdbd2603be.
Exact command:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c2-runtime-v2/run_live.py --run --manifest /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/manifest-v3.json --manifest-sha256 d2bb368da8f912f3b37ed97376d8d73a11259570b44aae893981609e3ac5a62f --output /tmp/uwz-h2-application-error-owned-2026-10-29-r1 --cases sink_error invalid_progress end_error shutdown_idle
```

Nativechild117620/start1196274, Releasef75410391bac1d3e55a55af0f1acecef496e890256de27bbfe3b8a28af0f83ef,
profilec8a11f12dca435220b37f735d1fe00fba6dee880b79d114204d86807f6a4f9e5.
Candidatefc69/c223override/originalC/sixarchives/client/helper/capacities unchanged.
Current2436input/7tree closure bindsactual v2native fixture1/runtime9 and both
actualDebug/RSreceipts. Tool-onlycheckerfix adds3identities; no native rebuild.
Rootpre/postaudit byteidentical9d6cd8911ba29f9c12616ec5ce7090b69fe27029a4a9f870ea0c95a15e41d09a.

Rawresult37497935eeaa31dc7edf5d84b68dca6dd27cd52f23add80c72bbcd0ccb317528.
RootindependentHOSTauditor verifies literalP32/H7/H32, actualbarriers/resetonly
wire summaries, serverrecords, distinctexpectederrorcounters/stalecontrols/
primarycredit-before-sibling/separateflow/recovery, all32finalrows/spares and
matchingpostdeinitlogs/metrics, TLS/certificate, PID/keyabsence/normalcleanup.
Source and result audit retained; no new native execution for auditing.

Actuals:
- sinkerror: first7ready/H7, next8offered beforeapplicationchunkerror, BEC1/0/1,
  sink_failure, chunk_errors1, accepted7/H7; rejectedprefix unaccepted.
- invalidprogress: first7/H7 thennext8, callbackconsumed0/ready, BEC1/0/1,
  sink_failure, invalid_progress1, accepted7/H7. Invalidforanynonemptyspan;
  no segmentation/packet-countoracle or OOBvalue.
- enderror:32/H32, E1/end_errors1/C0, metadataendcheckedbeforeerror, no final
  responseoperation. Allthree rawpolicies assertoneresetINTERNAL_ERROR2/no
  finalheaders/noINFO, actualhighlevelresetevents present.
- Primaryrefunds15/15/32 complete BEFORE siblingDATA. Siblingexactbyte s/200,
  distinctsent/refundsnapshots, threeindependentrecoveries32/H32/BEC1/1/0.
  Oldcontrols2resume+2cancel eachreturnBodyControlExpiredwithoutothermutation.
- FullM6/A6/B6/E4/C2/failedbegin0/end_errors1/chunk_errors1/invalid_progress1,
  accepted142/active0/errors0. Clientflow48+48+65=161sent/161refunded. All32rows
  (26untouchedspares)/metrics matchdeinit; bufferedM57+bodyM6 account63heads.
  No aggregateidleeventcounter is invented. Callbackspan/counts areobservations.
- FourfreshTLS1.3/h2connections sameownedchild, normalSIGTERMexit0/reaped/no
  forcedcleanup/noerrors, keyremoved, log15942B<65536. MetricsLAST after32status
  reads; no laterrequests.

ReviewoneP2 checkerimporteffect fixedguardedmain; actualsource pure-double
REDfivevalidation/writeeffects/GREEN1, explicitCLIactualinputmutationrejected
andrestoredclosureaccepted. Runtime9/nativeprofile/buildsunchanged. Twenty
offlinecodec/credit/listenerchecks andseparateimportregression establishharness
preparation only. Initialcounter-schema omission correctedbeforenativev2builds;
oldv1 receipts preserved. ScopedSPEC/QUALITY/FIXPASS. No stoppednativefault/
FD/resource/kernel/schedule/probe, deniedsocketcase orautomaticretry occurred.

This scopedproofextendsinventory32/40IDs; remaining8/fullcombined, H3/multipart/
genuineearlydata, fullquality/platform/compliance/physical/performance/
provenance/maintainedpublication/adoption/originalmilestones remainopen.
