# Task 5c2 Stage A preparation

Status: prepared for independent review, not authorized for native execution. No fixture, test, constructor, client, server, socket, certificate, or live selfcheck ran. No production source, pins, earlier evidence, or documentation were edited. The frozen current closure is `integration-owned/application-error/manifest-v2.json`, SHA-256 `268d028772435296ad1fcd3959db0ff0ab410799c25f658bdcfa04989b347a22`. Earlier v1 receipts and logs are retained as history; v2 is the current closure and does not union the v1 binaries.

## Scope and schema

All new material is in `.uwz-work/evidence/h2-streaming/integration-owned/application-error/`. The fixture `profile.zig` SHA-256 is `c8a11f12dca435220b37f735d1fe00fba6dee880b79d114204d86807f6a4f9e5`. It retains `/health`, `/echo`, `/status/:tag`, `/metrics`, `/control/:op/:tag`, and quota-one `/limit/:tag`. Thirty-two records include six case/recovery histories and 26 spares. Status and metrics add distinct `chunk_errors` and `invalid_progress` counters; `end_errors` counts the end refusal. Generic `errors` and failed-begin `failure` remain separate. The three individual primary flows use 15, 15, and 32 DATA bytes before sibling DATA, followed by one sibling byte and 32 recovery bytes. `cases.py` derives record and total expectations from selection. `run_live.py` tracks a separate P32 offset for each stream. Failure policy requires incoming INTERNAL_ERROR 2 before a final response while retaining the preexisting reset policies.

Self-review corrected an initial omission of distinct chunk failure counters before the v2 freeze. Fixture has fixed storage and copies controls, not borrowed callback input. The first seven bytes are accepted before the second write; the second callback returns an application error or zero/ready before updating hash or count. End verifies the 32-byte digest and metadata before the application error, and releases its slot before returning. Primary refunds are checked before sending sibling DATA. Pure regression explicitly rejects 14/31 refunded plus sibling 1 as a primary refund. No measurements of product behavior are claimed.

## Commands and raw results

The following compiler invocations are through the retained `compile_fixture.py`, whose receipts contain exact complete argv and environment, all 13 direct input hashes, candidate/override/fixture before and after maps, exit and binary hashes. `-j2`, frozen source and shared task5c1 content-addressed caches were used.

```
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/application-error/compile_fixture.py /tmp/uwz-task5c2-fixture-v2 debug fixture-debug-v2
mode: debug exit: 0 stdout bytes: 0 stderr bytes: 0 unchanged: True binary sha256: 6379ca4d3e482e7ce55235b6f0d235ba8f6050639b420136fbc212393ba582fc
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/application-error/compile_fixture.py /tmp/uwz-task5c2-fixture-v2 release fixture-release-v2
mode: release exit: 0 stdout bytes: 0 stderr bytes: 0 unchanged: True binary sha256: f75410391bac1d3e55a55af0f1acecef496e890256de27bbfe3b8a28af0f83ef
```

Optimization modes are Debug and ReleaseSafe respectively. Receipt hashes: Debug `afe0ef2f31a0869296b6af174f05933413f6f18b6229b0766cfd766ed7bd50b2`; ReleaseSafe `6ce81dd574b15e267f9df5b5ab54f108385cad155a06239448431d5c4c99b93e`. Candidate has 1,031 files, override 93, fixture snapshot 1; all before/after maps equal. The pinned package tree contains 42 files, frozen runtime 9, Zig library tree 19,542, zslay tree 14, and closure has 2,433 direct inputs. Exact maps and compiler logs are in the receipts and manifest.

The pinned codec red test was run before adding `application_failure`: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S -m unittest test_observer.ObserverTests.test_application_failure_fragmented_reset` from the evidence directory. Exit 1, `ValueError: invalid terminal policy`, `Ran 1 test`, `FAILED (errors=1)`; raw output in `red.stderr`. After the policy and regression additions:

```
cd .uwz-work/evidence/h2-streaming/integration-owned/application-error
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S -m unittest test_observer test_credit_case test_listener
....................
----------------------------------------------------------------------
Ran 20 tests in 0.007s

OK
```

Exit 0; `v2-offline.stdout`, `v2-offline.stderr`, and `v2-offline.exit` retain the result. An intermediate run failed because the inherited ledger accepted only 7/32, not 15/32; `offline.stderr` retains that failure, and the current ledger enforces 15/32. Listener tests are pure doubles; no listener was started. Observer coverage includes fragmented and coalesced frames, wrong code/stream, duplicate and missing reset, terminal payload and completion only after full frame payload. Existing other policies remain strict.

```
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/application-error/freeze_runtime.py
frozen runtime files: 9
tree counts: {'/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/lib': 19542, '/tmp/uwz-h2-client-tooling/packages': 42, '/tmp/uwz-reviewed-libxev-c223-loop-callbacks': 93, '/tmp/uwz-task4d-fix1-frozen': 1031, '/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy': 14, '/tmp/uwz-task5c2-runtime-v2': 9, '/tmp/uwz-task5c2-fixture-v2': 1}
direct inputs: 2433
manifest sha256: 268d028772435296ad1fcd3959db0ff0ab410799c25f658bdcfa04989b347a22
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/application-error/check_closure.py
current closure: accepted
mutated actual input: rejected: input identity differs: /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/cases.py
restored closure: accepted
```

Exit 0 for both. The check briefly appended one byte to the actual owned `cases.py`, restored it in `finally`, and rechecked the entire closure. `closure-first.stderr` retains an earlier check-script exception: rejection occurred correctly but the script caught `ValueError` while the runner uses `RuntimeError`; the handler was corrected and repeated. The checker is offline and never calls the live runner.

`zig fmt --check .uwz-work/evidence/h2-streaming/integration-owned/application-error/profile.zig` exited 0 with no output; `/home/codespace/.python/current/bin/python3 -B -S` AST parsing of all 12 owned Python files exited 0 with `AST parsed: 12`. `graphify update .` ran; output reported sequential fallback and no topology changes.

## Remaining gates

Independent review must check the current v2 source, closure, receipts, strict expectations, and ownership before Root separately authorizes one exact ordinary host attempt. No live result, product adoption, native behavior, full local matrix, h1spec, Autobahn, sanitizer or performance result is asserted. Subsequent lifecycle/output/combined milestones and ordinary release gates remain open.

## Fix 1: inert checker import, current manifest v3

This section supersedes the earlier current-manifest identity. Review found that importing `check_closure.py` performed validation and temporarily wrote `cases.py`. The validation and mutation sequence now runs only in guarded `main()`. The explicit CLI still checks acceptance, mutates the actual owned case input, requires rejection, restores it in `finally`, and accepts the restored closure. No fixture or runtime source changed; the nine-file `/tmp/uwz-task5c2-runtime-v2` snapshot and both v2 compile receipts and binaries remain the actual current build evidence. No native compilation or execution was repeated.

`test_checker_import.py` evaluates the actual checker source with `__name__` set to an import name and pure doubles for validation and `Path.read_bytes`/`write_bytes`; it records attempted effects, so restoration cannot mask a write. The exact command below ran first against the old checker and then against the corrected checker, from the evidence directory:

```
/home/codespace/.python/current/bin/python3 -B -S -m unittest test_checker_import
```

RED exit 1, retained in `fix1-red.stderr` and `fix1-red.exit`:

```
FAIL: test_import_has_no_validation_or_writes (test_checker_import.CheckerImportTests.test_import_has_no_validation_or_writes)
AssertionError: Lists differ: ['validate', 'write', 'validate', 'write', 'validate'] != []
Ran 1 test in 0.005s
FAILED (failures=1)
```

GREEN exit 0, retained in `fix1-green.stderr` and `fix1-green.exit`:

```
.
----------------------------------------------------------------------
Ran 1 test in 0.003s

OK
```

`bind_checker.py` verifies the complete unchanged v2 closure against its fixed hash, adds hashes for the corrected checker, its test, and the binding tool, then verifies the resulting closure. It has an inert import guard. Exact command and raw output, exit 0 (`fix1-bind.stdout`, `.stderr`, `.exit`):

```
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/application-error/bind_checker.py
v2 closure accepted; v3 closure accepted
direct inputs: 2436
manifest sha256: d2bb368da8f912f3b37ed97376d8d73a11259570b44aae893981609e3ac5a62f
```

The v2 manifest remains `268d028772435296ad1fcd3959db0ff0ab410799c25f658bdcfa04989b347a22`; v3 differs only by the three tool input identities, increasing direct inputs from 2433 to 2436. Tree inventories and build receipts are unchanged. Corrected `check_closure.py` SHA-256 is `5c65b1a72d5d2aaa9fd33667c3a42926bd51abab9778789307a9b04483ca81f5`, `test_checker_import.py` is `181e1669ff9b1b056f5682d0a8ecd1be58fbd53fc4aefc658eb8af998e074a5b`, and `bind_checker.py` is `69040a1a18f9b48a57ffcf8b9d2ada50ccd39f8455afbbeea3bb8b26f5efd524`. Debug and ReleaseSafe receipt hashes remain `afe0ef2f31a0869296b6af174f05933413f6f18b6229b0766cfd766ed7bd50b2` and `6ce81dd574b15e267f9df5b5ab54f108385cad155a06239448431d5c4c99b93e` respectively.

The explicit CLI was rerun against v3, exit 0 (`fix1-closure.stdout`, `.stderr`, `.exit`):

```
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/application-error/check_closure.py
current closure: accepted
mutated actual input: rejected: input identity differs: /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/cases.py
restored closure: accepted
```

`/home/codespace/.python/current/bin/python3 -B -S` parsed the three changed/new tools with `ast.parse`, exit 0, raw output `AST parsed: 3`. Self-review: all three tools are guarded; the new test traps attempted validation and writes instead of relying on hashes; the explicit mutation is limited to the already authorized CLI and restored even on failure. Scoped independent re-review remains required. No native runtime release is authorized.
