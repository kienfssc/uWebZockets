# Task5c ordinary lifecycle architecture

Read-only architect_h2_live_plan result adopted for later preparation. No file,
ref, build, test, native probe, client/server/socket or subagent action occurred
during planning. Original task-5-plan.md and all producer/file/output/early-final
cases and the final combined matrix remain binding. This grants no execution.

Use immutable fc69/c223/client/helper/bindings/libraries and exact production
profile: eight connections/eight H2 streams,73728 receive payload and two fixture
sink slots. Candidate and Root production remain separate. Verification owns
test fixtures/driver; protocol, transport and TLS specialists guide their actual
contracts. Product defects return to the relevant owner.

## Ordered preparation

1. Public stream termination: cancel_ready,cancel_paused,peer_reset.
2. Application failures: sink_error,invalid_progress,end_error.
3. Ordinary connection closure and reuse: disconnect,reuse.
4. shutdown_active LAST, after all other matrix work and response output finish.

Every slice needs frozen preparation, independent review and separate exact Root
release before live use. Same-connection status barriers precede operations.
Copy public controls before use; terminalization can recycle binding inline.
Persistent records/owned expectations survive reusable slots; retain no borrowed
callback-local Request/StreamingRequest/Response/view/chunk pointers.

Use quota-one /limit/:tag,Content-Length32 and distinct bounded metadata/tags.
P32 is the reviewed generator's32-byte payload. H32=SHA256(P32);
H7=SHA256(P32[0..7]), bytes1..7, NOT the generator's separate seven-byte payload.
Every non-shutdown terminated primary gets an independent same-route recovery:
P32/200/32/H32/BEC1/1/0. Do not depend on another selectable case for recovery.

For the six stream-local terminal cases first open buffered sibling POST /echo,
Content-Length1,HEADERS withoutEOF. It occupies no sink binding. After target
termination, send one byte s+EOF; require200/exact s, then same-route recovery.

## Exact primary contracts

| Case | Operation | Primary outcome |
| --- | --- | --- |
| cancel_ready | Ready,first7 P32/noEOF,accepted7/ready barrier,publiccancel | One server CANCEL8,7/H7/BEC1/0/1/cancelled,no final HTTP response |
| cancel_paused | P32/noEOF,cumulative7 thenpause/25queued,barrier,publiccancel | Same CANCEL8/7/H7/1/0/1/cancelled; suffix never accepted |
| peer_reset | Beginpaused,P32/noEOF,barrier accepted0/chunks0,ordinary client reset_stream(CANCEL) | BEC1/0/1/reset,0/emptySHA,no upload success or expected server reset echo |
| sink_error | Ready,first7/barrier,next8 offered; return error.ApplicationChunkRefused before updating hash/count | One INTERNAL_ERROR2,7/H7/BEC1/0/1/sink_failure,no final HTTP response |
| invalid_progress | Same7+8; return consumed1/readinessready without accepting/hash-counting that prefix | Same INTERNAL_ERROR2,7/H7/1/0/1/sink_failure |
| end_error | AllP32+EOF; end validates metadata,counts end/end_error then returns error.ApplicationEndRefused before response ops | One INTERNAL_ERROR2,32/H32/BEC1/1/0/end_errors1,no secondcancel/finalresponse |
| disconnect | P32,accept7/pause,sameconnbarrier,ordinary TLS contract below | BEC1/0/1/peer_closed ONLY,7/H7,no upload success |
| reuse | Nine sequential P32 requests on sameconn,distinct tags/query/header; old controls during each later active request | Each200/32/H32/BEC1/1/0; all old controls expired without mutation |
| shutdown_active | LAST,P32,accept7/pause,barrier,signal exact owned child through installed SIGTERM handling | BEC1/0/1/shutdown,7/H7,no upload success,active0/run+deinit/postmarker/exit0/reaped |

Publiccancel control route must return200/ok. Repeated stale resume/cancel must
return BodyControlExpired without changing terminal/readiness/bytes. No controls
after App deinit. Short-ready progress is invalid because ready requires full
consumption; use no out-of-bounds access or fabricated native outcome.

## Source mapping in immutable fc69

- request_body.zig71-97: generation/phase checks before control target.
- tcp.zig677-688/server.zig1492-1498: publiccancel cause cancelled,CANCEL8.
- server.zig1047-1056,2328-2347: peerRST clears only stream,flushes reclaimed
  connectioncredit,default reset cause absent earlier cause.
- request_body.zig119-123/http2_upload.zig165-183: invalid short-ready rejected
  before acceptance; server.zig1683-1717 maps chunk/progress failure to
  sink_failure/INTERNAL_ERROR2.
- http2_upload.zig201-220: end owns terminal cleanup/reservation release even
  on error; later streamclose finds no binding to cancel twice.
- server.zig2130-2191,2328-2347: queued retirement and complete reset-frame
  output acceptance. Discarded bytes not redelivered does not prove erasure.

## Precise ordinary TLS disconnect

After accepted-seven status response and full framing are consumed, call public
SSLSocket.unwrap() within the remaining absolute deadline. Require successful
TLS shutdown; on returned ordinary socket require normal EOF, then normalclose.
No linger/shutdown(how),GOAWAY,RST or abrupt-close fallback counted as success.
Open replacement TLS/H2, check persistent terminalrecord, run independent same-
route recovery. Preclose barrier is originalconnection; postclose observation
necessarily uses replacement and is not claimed as departed-connection barrier.

Source: pinned Python ssl.py1346-1352 public unwrap calls TLS shutdown; frozen
tcp.zig544-554 maps close-notify SSL_ERROR_ZERO_RETURN to peer_closed then
gracefulclose. tcp.zig1929-1941,2415-2436 drains server alert. First causes survive
genericclose at2277-2283,3212-3227. RawEOF/zerolength also peer_closed at3114-3132;
ConnectionResetByPeer maps separately reset. Accept peer_closed only. Unwrap
failure/unexpectedbytes/timeout/reset/source_failure fails; preserve failure
rather than broadening cause set. This covers clean ordinary disconnect, not
all abrupt-close behavior or the stopped experiment.

## Credit and output observations

Freshcaseconnection/independent flowledger; reclaim target connectioncredit
before recovery, without packet/delta/count or finalclosedstream-credit oracle:
cancel_ready7;cancel_paused/peer_reset/end_error32;sink_error/invalid_progress15.
The open sibling has onlyHEADERS then, so no DATA ledger contamination. Its
later1byte is accounted separately. Cumulativeconnectionrefund<=sentflow;
public currentconnectionwindow matchesledger and permits legal recovery.

Publiccancel/applicationfailure require one incoming exactcode targetRST with
NO preceding-finalresponse requirement. This differs from refusal-after-final
5b2. Healthy sibling/recovery forbid resets. Peerreset is outgoingclientRST plus
actual servercancelrecord, not client-localclosure as serverproof. Middleware
runs once pervalidbodyhead; reset-onlyprimaries have nofinalheaders to inspect;
healthyrecovery finalmiddlewareheader once.

Nine complete requests exceed eight streamslots via fixed-sourcecapacity; no
specific slotindex or connectionpoolreuse claim. For active shutdown all prior
bindings/producers/files finished, keeptargetconnectionopen untilsignalexactPID/
start. App shutdown passes shutdown via app.zig657-675/tcp_upload.zig403-414;
run verifiesdrained app.zig679-704. Require persistentterminal/zeroactive/public
run+deinit/postmarker/normalexit0/reaped. Record actual clienttermination; App
does not promise clean TLSalert on shutdown. Forcedcleanup fails.

## Capacity and scope

Lifecycle requires24persistentbodyrecords:7primaries+7independentrecoveries,
9reuse and1activeshutdown. BEC24/17/7,attempts24,failedbegins0,end_errors1,
accepted586logicalbytes; sixbufferedsiblings use nobodysinkrecord. Together with
prior>=34 this gives>=58 before producer/file/output/early-final records.
Architect proposes an explicitly reviewed128-entry FIXED TEST resultledger
for later combinedfixture, with exactrequiredcount manifestchecked. This is
a proposal, not an adopted production/sinkcapacity change. Keep65536outputcap;
budgetcompactpostlogs<49152,no perchunk/fullmetadatahistory logging. Actual
recordstorage/logsize remains to be measured in future authorized preparation.

Meaningful offline observerchecks may use actual pinned h2/hyperframe encoded
RSTs,fragmentation,stream/code/ordering rules,unexpected/duplicate/postclosed
RST rejection and bounds. They verify harness only, not native lifecycle.
No native cancellation schedules/interleavings/races/fault/resource/fd/kernel/
injectedcompletion/panic/leak/crash probes or stopped-experiment reconstruction.
Remaining producer_reuse/output_pressure_window/output_pressure_ready/stream_file/
early_final_order/producer metadata/fullcombined and all broader milestones
remain required. This plan neither implements nor replaces them.
