SPEC: REQUEST CHANGES. QUALITY: one boundary issue; no other structural findings.

P2 — Make closure checker inert on import. check_closure.py10 executes
validation at module scope and17 modifies actual cases.py. Importing performs
filesystem effects and temporarily invalidates the closure, violating the
explicit inert-import requirement. Put the sequence in main() behind a
__name__ == '__main__' guard.

No other actionable fixture/case offsets/expectations/reset/recovery/refund/
boundedobserver/identity/cleanup findings. Structural lens finds no separate
blocker. Source/retained-evidence review only; no check/test/native/probe rerun.
Wholeclosure recomputation outside review. Preparation approval only afterfix.
