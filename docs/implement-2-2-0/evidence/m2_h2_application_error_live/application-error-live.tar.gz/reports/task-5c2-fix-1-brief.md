# Task5c2 fix1/5: inert preparation checker

Resume the same task/ownership; original brief and all StageA/no-native/no-
subagent/previous-evidence/product/pin/ref boundaries remain unchanged. Root
read actual report, raw outcomes and cited checker source. Keep oldv2 sources,
manifest and actual new Debug/ReleaseSafe receipts. No native rebuild is needed
unless actual native inputs change.

Finding verbatim:

P2 — Make the closure checker inert on import. check_closure.py10 executes
validation at module scope, then17 modifies the actual cases.py. Importing this
preparation tool therefore performs filesystem effects and temporarily
invalidates the reviewed closure, violating the explicit inert-import
requirement. Move the validation/mutation sequence into main() with an
if __name__ == '__main__' guard.

The inert-import requirement includes preparation tools; Root grants no
exception. Move the sequence/needed setup under the guarded entry point.
Preserve the explicit checker CLI's actual acceptance/mutation rejection/
restoration semantics and exact assertions. No automatic run on import.

Add a focused OFFLINE import regression that detects attempted validation/
writes, fails before correction and passes afterward. Hash-before/after alone
is insufficient because the old mutation restores the original bytes; trap or
observe attempted effects using pure test doubles, with no real descriptors,
native programs, sockets or actual kernel-error injection. Name covering test
file, exact RED/GREEN commands/rawoutput/status. Recheck explicit checker CLI
and current frozen identity/mutation/restoration; AST/affected checks suffice,
do not repeat unchanged native compilation or unrelated tests as reassurance.

Bind corrected preparation source in a NEW current manifest. Preserve previous
identities. If the nine actual runtime modules stay byte-identical, keep their
immutable snapshot and the two actual native builds; record precisely which
tool-only source changed and what current counts/hash changed. All source/input
identity gates still apply. If runtime changes, freeze a new snapshot.

Append fix report/commands/rawoutcomes/new current identities/selfreview to
task-5c2-report.md. Return short status. Root creates a scoped diff and sends it
to the original reviewer after reading the report. No native release yet.
