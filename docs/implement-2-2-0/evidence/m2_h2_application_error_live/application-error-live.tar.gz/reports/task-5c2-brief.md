# Task5c2: HTTP/2 application-error acceptance preparation

Read this first; these are the requirements and exact values. Continue the
existing task-5-plan.md and adopted task-5c-lifecycle-architecture.md, implementing
sink_error, invalid_progress, end_error and each independent recovery, plus
baseline idle shutdown. All later lifecycle/output/combined and original
milestone requirements remain binding. StageA preparation only: no runtime
authorization follows from this brief.

## Ownership and preserved boundaries

Own NEW .uwz-work/evidence/h2-streaming/integration-owned/application-error/,
/tmp/uwz-task5c2-* and task-5c2-report.md in this plan workspace. You are not
alone: preserve other agents' changes. Do not edit Root source/pins/docs, old
fixtures, common tools/helper or earlier evidence. No commits/push, subagents
or external model CLI; Root owns review/publication and immediate fork pushes.

Allow source preparation, Python AST/inert identity/offline codec checks and
actual compile-only Debug/ReleaseSafe fixture builds. Do NOT run any native
fixture/test/constructor/client/server/socket/certificate/live selfcheck. The
original stopped native cancellation/fault experiment and denied socket cases
remain stopped. No native schedules/interleavings/races, real FD manipulation,
kernel/OS/resource/registration/completion/error injection, panic/leak/crash
probes or native fault reproduction. These cases use ordinary application-defined
callback errors through the public contract, not injected native I/O outcomes.
If a product contract is missing, report the exact source conflict instead of
editing production or broadening expected results.

Read applicable AGENTS/CODING_CONVENTION, verification instructions and narrow
skills. Use graphify before new searches; given snapshots and cited architecture
source locations are already located. Keep explicit named types, zero-allocation
chunk handling, shallow control flow, no new markers/dead scaffolding.

## Actual current basis

Root HEAD0b33655ce163a464c8082555858f3845b73b3b66 is clean and pushed to fork.
Prior task5c1 is DONE; do not reimplement/retest its completed checkpoint.
Adapt the LATEST reviewed /tmp/uwz-task5c1-runtime-v5 (9files) and
/tmp/uwz-task5c1-fixture-v1/profile.zig into your NEW ownership. Persistent
lifecycle-control/ has its compile/freeze recipes and manifest-v5.json
SHAd74acb0bf0586bdcace73bb772c376ea39e4ea7036da826828a59ee321882f18.
Preserve its strict listener/PID/start/nonce/certificate checks, narrowly handled
vanished enumerated link, bounded error filename/stage/traceback and primary-
credit-before-sibling ordering. Do not revive the older fragile metadata runner.
Remove inapplicable case/fixture scaffolding in your new copy.

Production candidate /tmp/uwz-task4d-fix1-frozen,1031files, source digest
fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de;
override /tmp/uwz-reviewed-libxev-c223-loop-callbacks,93files,
c223bd886c6a51d2cd60def39dd9a68d701fea73. Keep original c-native.zig under
.uwz-work/evidence/h1-transport/r2 and all six static archives/linkage from
body-app/focused-final-ReleaseSafe.command.json unchanged. Root product adoption
and ordinary pins remain separate.

Compiler /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig, -j2,
all caches/output/full snapshots under /tmp. Shared content-addressed caches
from task5c1 are permitted/preferred; no distinct-cache identity requirement.
Freeze native fixture before actual new builds and retain exact argv/env,
13 direct hashes and candidate/override/fixture before-after maps, compiler
stdout/stderr/exit/binary hashes. Actual errors/corrections remain recorded.
Runtime freezes separately after Python completion; current closure must bind
both ACTUAL new build receipts/binaries and every current runtime source/tool/
interpreter/stdlib/loader/TLS/helper/client/environment input. No historic-binary
union and no claimed Python compile dependency. No unchanged native rebuild.

Pinned42-file offline client /tmp/uwz-h2-client-tooling/packages digest
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473;
unchanged integration-client/h2_client.py
07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00.
Absolute Python /home/codespace/.python/current/bin/python3 -B -S. Future env-i
LC_ALL=C.UTF-8 and exact pinned PYTHONPATH only. No package installs.

## Fixed fixture and process bounds

Use the exact task5c1 configured Server.preset(...).build_https profile:
maxconnections8,streamingtrue,reqline512,requestheaders4096/count80,H1body256,
H2body4096,encodedH2headers8192,responseheaders4096/count32,captures24,
writequeue65536, optional features off. Native8streams/73728receive payload,
two reusable sink slots. This isolated task has6 persistent histories in32fixed
records with26untouchedspares. Do not adopt proposed128combined records or raise
production/sink/output limits.

Stable independent records and owned metadata expectations outlive sink slots.
Retain no borrowed callback request/view-array/response/chunk pointers. Copy
public controls; terminal cleanup may retire inline. Middleware/begin/end
validate fixed POST/path/target/query/header/tag expectations. Keep the existing
bounded health/echo/status/control/metrics contracts or document exact changes.
Expected application errors get their own counters, not generic fixture errors.

Future owned localhost127.0.0.1:28443 TLS1.3/h2, PID/start/nonce/listener/cert
before health. Ready15/case30/whole900/graceful15 absolute deadlines, no retry
or fallback. Explicit run flag/current reviewed manifest hash/supported selected
case set/new private output directory; imports remain inert. Continuous output
65536, response records8, read/send8192, statusJSON<4096, headers32/4096,
info16/16384, frame16384 and all other current bounds unchanged. Preserve
high-water/8active observer bookkeeping, not an accumulating retired-ID set.
All32statuses read before metrics LAST, then no requests. After public deinit
require every record and metrics equal, normalexit0/reaped/keyremoved; forced
cleanup fails. Idle shutdown does not substitute for future active shutdown.

## Exact ordinary callback cases

P32=bytes1through10 followed by literal final-upload-sentinel!, length32.
H32=7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5.
H7=32bbe378a25091502b2baf9f7258c19444e7a43ee4593b08030acd790bd66e6a,
the hash of P32[0..7], bytes1through7. Do not substitute a separate7bytegenerator.

Every primary: quota-one /limit/:tag, limit32, CL32, fixed distinct metadata;
first open buffered /echo sibling CL1 HEADERS only. All pre/postoperation barriers
and credit observation use the SAME case connection. Six named histories are
sink_error, sink_error_recovery, invalid_progress, invalid_progress_recovery,
end_error, end_error_recovery. Unsupported selections fail, never skip-success.

- sink_error: ready begin; send FIRST7P32 withoutEOF, require accepted7/H7/ready
  barrier. Send NEXT8P32[7..15] withoutEOF. On the first subsequent nonempty
  chunk return error.ApplicationChunkRefused BEFORE accepting/hashing any of
  that offered slice. Require one incoming INTERNAL_ERROR2, no final HTTP
  response, BEC1/0/1, reason sink_failure, accepted7/H7.
- invalid_progress: same first7/barrier/next8, but return consumed0/readinessready
  on the first subsequent nonempty offered slice BEFORE acceptance/hash. Require
  the same reset2/BEC1/0/1/sink_failure/7H7 and no rejected prefix retained.
- end_error: send allP32+EOF. End validates metadata/hash/32, increments end and
  end_errors, then returns error.ApplicationEndRefused BEFORE response operations.
  Require one incoming INTERNAL_ERROR2, no final HTTP response, BEC1/1/0,
  end_errors1, accepted32/H32, no second cancel; record reason stays none when no
  cancel callback provided a cause. Release fixture binding and admission normally.

Ruling: the adopted architecture's consumed1/ready assumed offeredspan>1, but
request_body.zig119-123 accepts that when a legal span has length1. Consumed0/
ready violates full consumption for EVERY nonempty offered span, preserving
the required invalid-progress case without native scheduling or OOB values.
The spec requires invalid progress, not literal1. Packet/callback segmentation
is never an oracle. Track per-stream client offsets so the second8 bytes are
P32[7..15], not a repeated prefix. Observed callback counts/spans may vary.

After actual terminal record and raw reset, stale copied resume/cancel must
return BodyControlExpired without mutating state. Observe COMPLETE primary
connection refunds15/15/32 BEFORE any sibling DATA; only primary DATA has been
sent then, public window matches ledger, no packet-specific delta/count or
closed-stream refund oracle. Then complete sibling with byte s+EOF/200/exact s,
record its separate sent/refund accounting. Independently admit corresponding
same-route recovery P32+EOF, require200/bounded recordJSON/32H32/BEC1/1/0 and one
middleware header. Check old controls again after reuse. Each case must recover
when selected alone. Positive final-body length is JSON length, not upload32.

Full3-case expectations: bodyM6/attempts6/B6/E4/C2/failedbegin0/end_errors1,
142accepted, active/errors0. All6 have exactly one terminal. Three buffered
siblings consume no sink record. Client DATA flow48+48+65=161 including siblings
and recoveries; rejected16bytes remain unaccepted. These are expectations, not
measurements. Derive selected-subset expectations independently.

## Offline coverage and final deliverable

Add explicit application-failure reset policy expecting code2 before final
response. Preserve existing publicCANCEL8/refusal-after-finalNOERROR0/healthy/
outgoingpeerreset behavior; do not globally weaken reset rules. Offline actual
pinned codec frames must establish RED before supporting code2, then GREEN;
cover wrongcode/stream, duplicate/missing reset, terminal payload, fragmented/
coalesced frames and full payload before terminal. Keep current observer,
actual-case credit and listener regressions relevant to the changed package.
Meaningful pure driver checks must enforce primary-only credit order and reject
partial14/31 primary plus sibling1 masking. Pure doubles are allowed; no native
outcome injection. Harness tests do not prove product behavior.

Finish fixture, driver, separate frozen runtime, actual Debug/ReleaseSafe builds,
current closure acceptance AND mutated ACTUAL input rejection, AST/format and
self-review. Preserve all actual code/commands/logs/results/hashes in owned
workspace, not solely ephemeral/tmp. Record full changed files, routes/schema,
exact commands/raw outcomes/failures, source/binary/input/tree counts and all
remaining gates in task-5c2-report.md. Return short DONE only when full StageA
is ready for independent review; otherwise report a concrete contract/context
blocker. Do not stop just because work is substantial. No native run until
Root reviews frozen source and separately releases one exact owned attempt.
