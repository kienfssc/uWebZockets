# Task5c2 fix1 scoped diff

Runtime9/nativefixture/buildreceipts unchanged; checker/main guard, import regression and tool binding only.
--- reviewed-v2/check_closure.py
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/check_closure.py
@@ -1,27 +1,32 @@
 import hashlib
 import importlib.util
 from pathlib import Path
 
-here = Path(__file__).resolve().parent
-manifest = here / 'manifest-v2.json'
-runner = Path('/tmp/uwz-task5c2-runtime-v2/run_live.py')
-spec = importlib.util.spec_from_file_location('runner', runner)
-module = importlib.util.module_from_spec(spec)
-spec.loader.exec_module(module)
-digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
-module.check_manifest(manifest, digest)
-print('current closure: accepted')
-target = here / 'cases.py'
-original = target.read_bytes()
-try:
-    target.write_bytes(original + b'\n')
+def main():
+    here = Path(__file__).resolve().parent
+    manifest = here / 'manifest-v3.json'
+    runner = Path('/tmp/uwz-task5c2-runtime-v2/run_live.py')
+    spec = importlib.util.spec_from_file_location('runner', runner)
+    module = importlib.util.module_from_spec(spec)
+    spec.loader.exec_module(module)
+    digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
+    module.check_manifest(manifest, digest)
+    print('current closure: accepted')
+    target = here / 'cases.py'
+    original = target.read_bytes()
     try:
-        module.check_manifest(manifest, digest)
-    except RuntimeError as error:
-        print('mutated actual input: rejected:', error)
-    else:
-        raise AssertionError('mutated input accepted')
-finally:
-    target.write_bytes(original)
-module.check_manifest(manifest, digest)
-print('restored closure: accepted')
+        target.write_bytes(original + b'\n')
+        try:
+            module.check_manifest(manifest, digest)
+        except RuntimeError as error:
+            print('mutated actual input: rejected:', error)
+        else:
+            raise AssertionError('mutated input accepted')
+    finally:
+        target.write_bytes(original)
+    module.check_manifest(manifest, digest)
+    print('restored closure: accepted')
+
+
+if __name__ == '__main__':
+    main()

## /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/test_checker_import.py

"""Import must not validate the closure or attempt any file writes."""
import contextlib
import io
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch


class CheckerImportTests(unittest.TestCase):
    def test_import_has_no_validation_or_writes(self):
        path = Path(__file__).resolve().parent / 'check_closure.py'
        code = compile(path.read_bytes(), str(path), 'exec')
        effects = []
        def validate(*args):
            effects.append('validate')
            if effects.count('validate') == 2:
                raise RuntimeError('synthetic mismatch')
        def write(*args):
            effects.append('write')
        module = SimpleNamespace(check_manifest=validate)
        spec = SimpleNamespace(loader=SimpleNamespace(exec_module=lambda _: None))
        with patch('importlib.util.spec_from_file_location', return_value=spec), \
             patch('importlib.util.module_from_spec', return_value=module), \
             patch.object(Path, 'read_bytes', return_value=b'fake input'), \
             patch.object(Path, 'write_bytes', side_effect=write), \
             contextlib.redirect_stdout(io.StringIO()):
            exec(code, {'__name__': 'imported_checker', '__file__': str(path)})
        self.assertEqual(effects, [])


if __name__ == '__main__':
    unittest.main()

## /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/bind_checker.py

"""Bind inert preparation tools to the already reviewed runtime closure."""
import hashlib
import importlib.util
import json
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    here = Path(__file__).resolve().parent
    previous = here / 'manifest-v2.json'
    output = here / 'manifest-v3.json'
    if output.exists():
        raise ValueError('manifest already exists')
    expected = '268d028772435296ad1fcd3959db0ff0ab410799c25f658bdcfa04989b347a22'
    spec = importlib.util.spec_from_file_location('frozen_runner', '/tmp/uwz-task5c2-runtime-v2/run_live.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    manifest = runner.check_manifest(previous, expected)
    for name in ('check_closure.py', 'test_checker_import.py', 'bind_checker.py'):
        path = here / name
        manifest['inputs'][str(path)] = digest(path)
    output.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    result = digest(output)
    runner.check_manifest(output, result)
    print('v2 closure accepted; v3 closure accepted')
    print('direct inputs:', len(manifest['inputs']))
    print('manifest sha256:', result)


if __name__ == '__main__':
    main()

## Added current tool identities

{
  "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/bind_checker.py": "69040a1a18f9b48a57ffcf8b9d2ada50ccd39f8455afbbeea3bb8b26f5efd524",
  "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/check_closure.py": "5c65b1a72d5d2aaa9fd33667c3a42926bd51abab9778789307a9b04483ca81f5",
  "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/application-error/test_checker_import.py": "181e1669ff9b1b056f5682d0a8ecd1be58fbd53fc4aefc658eb8af998e074a5b"
}
