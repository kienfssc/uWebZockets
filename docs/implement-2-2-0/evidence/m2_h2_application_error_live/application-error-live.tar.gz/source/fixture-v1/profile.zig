const std = @import("std");
const uz = @import("uWebZockets");
const Hash = std.crypto.hash.sha2.Sha256;
const config: uz.ServerConfig = .{
    .max_connections = 8,
    .stream_request_bodies = true,
    .max_request_line_size = 512,
    .max_header_size = 4096,
    .max_header_count = 80,
    .max_body_size = 256,
    .max_h2_body_size = 4096,
    .max_h2_header_block_size = 8192,
    .max_h2_response_header_size = 4096,
    .max_h2_response_header_count = 32,
    .max_route_params = 24,
    .write_queue_size = 65536,
    .enable_dev_log = false,
};
const tags = [_][]const u8{
    "sink_error", "sink_error_recovery", "invalid_progress", "invalid_progress_recovery",
    "end_error",  "end_error_recovery",  "spare_00",         "spare_01",
    "spare_02",   "spare_03",            "spare_04",         "spare_05",
    "spare_06",   "spare_07",            "spare_08",         "spare_09",
    "spare_10",   "spare_11",            "spare_12",         "spare_13",
    "spare_14",   "spare_15",            "spare_16",         "spare_17",
    "spare_18",   "spare_19",            "spare_20",         "spare_21",
    "spare_22",   "spare_23",            "spare_24",         "spare_25",
};
const Record = struct {
    token: ?uz.BodyControl = null,
    hash: Hash = Hash.init(.{}),
    bytes: u64 = 0,
    chunks: u32 = 0,
    max_span: usize = 0,
    middleware: u32 = 0,
    attempts: u32 = 0,
    begins: u32 = 0,
    ends: u32 = 0,
    cancels: u32 = 0,
    failures: u32 = 0,
    end_errors: u32 = 0,
    errors: u32 = 0,
    metadata_middleware: u32 = 0,
    metadata_begin: u32 = 0,
    metadata_end: u32 = 0,
    stale_resume: u32 = 0,
    stale_cancel: u32 = 0,
    active: bool = false,
    paused: bool = false,
    reason: ?uz.BodyCancelReason = null,
};
const Slot = struct { record: ?*Record = null, owner: *State = undefined, index: usize = 0 };
const State = struct {
    slots: [2]Slot = [_]Slot{.{}} ** 2,
    records: [32]Record = [_]Record{.{}} ** 32,
    buffered_middleware: u32 = 0,
    errors: u32 = 0,
};
fn tag_index(tag: []const u8) ?usize {
    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
    return null;
}
fn equal(actual: ?[]const u8, expected: []const u8) bool {
    return if (actual) |value| std.mem.eql(u8, value, expected) else false;
}
fn metadata_matches(request: *const uz.StreamingRequest, index: usize) bool {
    var path_storage: [128]u8 = undefined;
    var query_storage: [128]u8 = undefined;
    var target_storage: [256]u8 = undefined;
    const path = std.fmt.bufPrint(&path_storage, "/limit/{s}", .{tags[index]}) catch return false;
    const query = std.fmt.bufPrint(&query_storage, "case={s}", .{tags[index]}) catch return false;
    const target = std.fmt.bufPrint(&target_storage, "{s}?{s}", .{ path, query }) catch return false;
    return std.mem.eql(u8, request.method, "POST") and std.mem.eql(u8, request.path, path) and
        std.mem.eql(u8, request.query, query) and std.mem.eql(u8, request.target, target) and
        equal(request.params.get("tag"), tags[index]) and equal(request.headers.get("x-case"), tags[index]) and
        equal(request.headers.get("content-length"), "32");
}
fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
    const state: *State = @ptrCast(@alignCast(context));
    if (std.mem.startsWith(u8, request.path, "/limit/")) {
        const tag = request.get_param("tag") orelse {
            state.errors += 1;
            return .stop;
        };
        const index = tag_index(tag) orelse {
            state.errors += 1;
            return .stop;
        };
        if (index >= 6) {
            state.errors += 1;
            return .stop;
        }
        const record = &state.records[index];
        record.middleware += 1;
        if (metadata_matches(&uz.StreamingRequest.from_request(request), index)) {
            record.metadata_middleware += 1;
        } else record.errors += 1;
    } else state.buffered_middleware += 1;
    response.append_header("X-Middleware", "retained") catch {
        state.errors += 1;
        return .stop;
    };
    return .continue_dispatch;
}
fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.params.get("tag") orelse return error.MissingTag;
    const index = tag_index(tag) orelse return error.InvalidTag;
    if (index >= 6) return error.SpareTag;
    const record = &state.records[index];
    record.attempts += 1;
    if (record.attempts != 1 or record.middleware != 1 or !metadata_matches(request, index)) {
        record.errors += 1;
        record.failures += 1;
        return error.InvalidRequest;
    }
    record.metadata_begin += 1;
    for (&state.slots) |*slot| {
        if (slot.record != null) continue;
        slot.* = .{ .owner = state, .record = record, .index = index };
        record.token = token;
        record.begins += 1;
        record.active = true;
        return .{ .context = slot, .readiness = .ready };
    }
    record.failures += 1;
    record.errors += 1;
    return error.NoFixtureSlot;
}
fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.max_span = @max(record.max_span, input.len);
    record.chunks += 1;
    if (record.bytes == 7 and slot.index == 0) return error.ApplicationChunkRefused;
    if (record.bytes == 7 and slot.index == 2) return .{ .consumed = 0, .readiness = .ready };
    record.hash.update(input);
    record.bytes += input.len;
    return .{ .consumed = input.len, .readiness = .ready };
}
fn format_record(record: *const Record, tag: []const u8, output: []u8) ![]const u8 {
    var copy = record.hash;
    var digest: [Hash.digest_length]u8 = undefined;
    copy.final(&digest);
    const hex = std.fmt.bytesToHex(digest, .lower);
    const reason = if (record.reason) |value| @tagName(value) else "none";
    return std.fmt.bufPrint(output, "{{\"tag\":\"{s}\",\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"end_errors\":{d},\"accepted\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":\"{s}\",\"metadata_middleware\":{d},\"metadata_begin\":{d},\"metadata_end\":{d},\"stale_resume\":{d},\"stale_cancel\":{d},\"errors\":{d}}}", .{ tag, record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.metadata_middleware, record.metadata_begin, record.metadata_end, record.stale_resume, record.stale_cancel, record.errors });
}
fn end(context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.ends += 1;
    if (!metadata_matches(request, slot.index)) {
        record.errors += 1;
        record.end_errors += 1;
        record.active = false;
        record.paused = false;
        slot.record = null;
        return error.MetadataMismatch;
    }
    record.metadata_end += 1;
    var hash_copy = record.hash;
    var digest: [Hash.digest_length]u8 = undefined;
    hash_copy.final(&digest);
    const expected = [_]u8{ 0x7f, 0x0c, 0x58, 0x81, 0xa9, 0xae, 0x26, 0x83, 0xde, 0xbb, 0xa0, 0x16, 0xa4, 0x78, 0x6b, 0x6c, 0x08, 0xdc, 0x68, 0x4c, 0x5a, 0x33, 0x4f, 0xa0, 0xb9, 0x87, 0x6e, 0x6e, 0x32, 0xc3, 0x90, 0xb5 };
    if (record.bytes != 32 or !std.mem.eql(u8, &digest, &expected)) {
        record.errors += 1;
        record.end_errors += 1;
        record.active = false;
        slot.record = null;
        return error.InvalidBody;
    }
    if (slot.index == 4) {
        record.end_errors += 1;
        record.active = false;
        slot.record = null;
        return error.ApplicationEndRefused;
    }
    record.active = false;
    record.paused = false;
    slot.record = null;
    var output: [1024]u8 = undefined;
    const body = format_record(record, tags[slot.index], &output) catch |err| {
        record.end_errors += 1;
        return err;
    };
    response.text(body) catch |err| {
        record.end_errors += 1;
        return err;
    };
}
fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse {
        slot.owner.errors += 1;
        return;
    };
    record.cancels += 1;
    record.reason = reason;
    record.active = false;
    record.paused = false;
    slot.record = null;
}
fn health(_: *uz.Request, response: *uz.Response) void {
    response.text("ok") catch |err| std.log.err("health: {}", .{err});
}
fn echo(request: *uz.Request, response: *uz.Response) void {
    response.bytes(request.bytes()) catch |err| std.log.err("echo: {}", .{err});
}
fn status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    var output: [1024]u8 = undefined;
    const body = format_record(&state.records[index], tags[index], &output) catch {
        state.errors += 1;
        return;
    };
    response.text(body) catch {
        state.errors += 1;
    };
}
const Totals = struct { middleware: u64 = 0, attempts: u64 = 0, begins: u64 = 0, ends: u64 = 0, cancels: u64 = 0, failures: u64 = 0, end_errors: u64 = 0, accepted: u64 = 0, active: u32 = 0, errors: u64 = 0 };
fn format_totals(state: *const State, output: []u8) ![]const u8 {
    var result: Totals = .{ .errors = state.errors };
    for (state.records) |record| {
        result.middleware += record.middleware;
        result.attempts += record.attempts;
        result.begins += record.begins;
        result.ends += record.ends;
        result.cancels += record.cancels;
        result.failures += record.failures;
        result.end_errors += record.end_errors;
        result.accepted += record.bytes;
        result.active += @intFromBool(record.active);
        result.errors += record.errors;
    }
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"end_errors\":{d},\"accepted\":{d},\"active\":{d},\"errors\":{d},\"buffered_middleware\":{d},\"slot0_active\":{any},\"slot1_active\":{any}}}", .{ result.middleware, result.attempts, result.begins, result.ends, result.cancels, result.failures, result.end_errors, result.accepted, result.active, result.errors, state.buffered_middleware, state.slots[0].record != null, state.slots[1].record != null });
}
fn metrics(context: *anyopaque, _: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    var output: [1024]u8 = undefined;
    const body = format_totals(state, &output) catch {
        state.errors += 1;
        return;
    };
    response.text(body) catch {
        state.errors += 1;
    };
}
fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    const record = &state.records[index];
    const token = record.token orelse {
        state.errors += 1;
        return;
    };
    const operation = request.get_param("op") orelse {
        state.errors += 1;
        return;
    };
    if (std.mem.eql(u8, operation, "cancel") and record.active) {
        token.cancel() catch {
            state.errors += 1;
            return;
        };
        response.text("ok") catch {
            state.errors += 1;
        };
        return;
    }
    if (record.active) {
        state.errors += 1;
        return;
    }
    if (std.mem.eql(u8, operation, "resume")) {
        if (token.@"resume"()) |_| {
            state.errors += 1;
            return;
        } else |err| {
            if (err != error.BodyControlExpired) {
                state.errors += 1;
                return;
            }
        }
        record.stale_resume += 1;
    } else if (std.mem.eql(u8, operation, "cancel")) {
        if (token.cancel()) |_| {
            state.errors += 1;
            return;
        } else |err| {
            if (err != error.BodyControlExpired) {
                state.errors += 1;
                return;
            }
        }
        record.stale_cancel += 1;
    } else {
        state.errors += 1;
        return;
    }
    response.text("BodyControlExpired") catch {
        state.errors += 1;
    };
}
pub fn main(init: std.process.Init) !void {
    const certificate = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_CERT") orelse return error.MissingCertificate);
    const key = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_KEY") orelse return error.MissingKey);
    const nonce = init.environ_map.get("H2_PROFILE_NONCE") orelse return error.MissingNonce;
    if (nonce.len == 0 or nonce.len > 64) return error.InvalidNonce;
    var state: State = .{};
    const sink: uz.BodySink = .{ .context = &state, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel };
    var upload: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 32, .max_active = 1 }, .middleware_policy = .headers_only };
    {
        var server = try uz.Server.preset(init.io, config).build_https(init.arena.allocator(), certificate, key);
        defer server.deinit();
        _ = try server.use(&state, middleware);
        _ = try server.route_body(.post, "/limit/:tag", &upload);
        _ = try server.get("/health", health);
        _ = try server.post("/echo", echo);
        _ = try server.get_context("/status/:tag", &state, status);
        _ = try server.get_context("/metrics", &state, metrics);
        _ = try server.get_context("/control/:op/:tag", &state, control);
        std.log.info("H2_CAPACITY config={f} request_stride={d} h2_bytes={d} h2_stride={d} slab={d} router={d}", .{ std.json.fmt(config, .{}), try config.request_buffer_stride(), try config.h2_session_bytes(), try config.h2_session_stride(), try config.slab_bytes(), try config.router_storage_bytes() });
        try server.listen("127.0.0.1", 28443);
        try server.catch_shutdown_signals();
        std.log.info("H2_READY {s}", .{nonce});
        try server.run();
    }
    for (&state.records, 0..) |*record, i| {
        var output: [1024]u8 = undefined;
        std.log.info("H2_RECORD {s} {s}", .{ nonce, try format_record(record, tags[i], &output) });
    }
    var output: [1024]u8 = undefined;
    std.log.info("H2_DEINIT {s} {s}", .{ nonce, try format_totals(&state, &output) });
}
