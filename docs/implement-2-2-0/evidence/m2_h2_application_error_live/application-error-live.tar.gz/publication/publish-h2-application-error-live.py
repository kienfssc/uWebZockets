"""Publish current application-error source, preparation and owned-run proof."""
import gzip
import importlib.util
import json
from pathlib import Path


def main():
    root = Path('/workspaces/uWebZockets')
    evidence = root / '.uwz-work/evidence/h2-streaming/integration-owned/application-error'
    workspace = root / '.superpowers/sdd/h2_streaming_plan'
    common_path = root / '.uwz-work/tools/publish-h2-admission-live.py'
    spec = importlib.util.spec_from_file_location('publication_common', common_path)
    assert spec is not None and spec.loader is not None
    common = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(common)
    audit = json.loads((evidence / 'stage-b/root-result-audit.json').read_text())
    assert audit['checks_passed'] and audit['post_deinit_records_match'] == 32
    assert audit['post_deinit_metrics_match'] and audit['child_exit_zero_reaped']
    assert audit['host_pid_absent'] and audit['key_absent'] and audit['postrun_preflight_identical']
    members = {}
    for path in sorted(evidence.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            common.add_file(members, 'evidence/' + path.relative_to(evidence).as_posix(), path)
    for kind in ('fixture', 'runtime'):
        for version in (1, 2):
            location = Path('/tmp/uwz-task5c2-' + kind + '-v' + str(version))
            for path in sorted(location.iterdir()):
                common.add_file(members, 'source/' + kind + '-v' + str(version) + '/' + path.name, path)
    for pattern in ('task-5c2-*.md', 'task-5c2-*.json'):
        for path in sorted(workspace.glob(pattern)):
            common.add_file(members, 'reports/' + path.name, path)
    for path in sorted((workspace / 'task-5c2-retained').iterdir()):
        common.add_file(members, 'retained/' + path.name, path)
    for name in ('task-5-plan.md', 'task-5c-lifecycle-architecture.md'):
        common.add_file(members, 'reports/' + name, workspace / name)
    common.add_file(members, 'reports/component.md', root / 'docs/implement-2-2-0/m2_h2_application_error_live.md')
    inputs = {'h2_client.py': '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py',
              'c-native.zig': '.uwz-work/evidence/h1-transport/r2/c-native.zig',
              'immutable-libxev-input.json': '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json',
              'focused-final-ReleaseSafe.command.json': '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json'}
    for name, location in inputs.items():
        common.add_file(members, 'inputs/' + name, root / location)
    for name in ('audit-h2-application-error.py', 'audit-h2-application-error-result.py',
                 'publish-h2-application-error-live.py', 'audit-h2-application-error-publication.py',
                 'publish-h2-admission-live.py'):
        common.add_file(members, 'publication/' + name, root / '.uwz-work/tools' / name)
    for name, data in members.items():
        data.decode('utf-8')
        assert not data.startswith(b'\0asm'), name
    inventory = [{'path': name, 'bytes': len(data), 'sha256': common.digest(data)} for name, data in sorted(members.items())]
    members['inventory.json'] = (json.dumps({'scope': 'Publication bytes. Current executed fixture/runtime are v2; manifest-v3 additionally binds guarded preparation tools. v1 is history.', 'files': inventory}, indent=2) + '\n').encode()
    output = root / 'docs/implement-2-2-0/evidence/m2_h2_application_error_live'
    output.mkdir(parents=True, exist_ok=True)
    archive = output / 'application-error-live.tar.gz'
    archive.write_bytes(gzip.compress(common.tar_bytes(members), mtime=0))
    prior = json.loads((root / 'docs/implement-2-2-0/evidence/m2_h2_control_live/manifest.json').read_text())
    proved = sorted(set(prior['all_verified_case_ids'] + audit['cases_passed']))
    remaining = [name for name in prior['planned_unimplemented'] if name not in audit['cases_passed']]
    assert len(proved) == 32 and len(remaining) == 8 and not set(proved) & set(remaining)
    manifest = {'scope': 'One owned Linux ReleaseSafe TLS1.3/h2 public application-error/invalid-progress/end-error run plus recovery and idle shutdown; full M2/adoption open.',
        'archive': archive.name, 'archive_sha256': common.digest(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
        'safe_regular_members': len(members), 'inventory_entries': len(inventory),
        'source_digest': 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de', 'source_files': 1031,
        'source_checkpoint': '../m2_h2_native_tcp/README.md', 'source_delta_checkpoint': '../m2_h2_metadata_live/README.md',
        'profile_sha256': 'c8a11f12dca435220b37f735d1fe00fba6dee880b79d114204d86807f6a4f9e5',
        'binary_sha256': 'f75410391bac1d3e55a55af0f1acecef496e890256de27bbfe3b8a28af0f83ef',
        'review_manifest_sha256': common.digest((evidence / 'manifest-v3.json').read_bytes()),
        'preflight_sha256': common.digest((evidence / 'root-preflight.json').read_bytes()),
        'authorization_sha256': common.digest((evidence / 'stage-b-authorization.json').read_bytes()),
        'result_sha256': audit['result_sha256'], 'root_result_audit_sha256': common.digest((evidence / 'stage-b/root-result-audit.json').read_bytes()),
        'cases_passed': audit['cases_passed'], 'all_verified_case_ids': proved, 'planned_unimplemented': remaining,
        'totals': audit['totals'], 'primary_credit_targets': [15, 15, 32],
        'client_data_flow_sent': 161, 'client_data_flow_refunded': 161,
        'post_deinit_records_equal': 32, 'post_deinit_metrics_equal': True, 'fresh_tls_connections': 4,
        'server_log_bytes': 15942, 'exit_status': 0, 'runtime_mode': 'ReleaseSafe',
        'owned_attempts': 1, 'completed_successful_runs': 1, 'automatic_retries': 0,
        'child_exit_zero_reaped': True, 'private_key_removed': True, 'postrun_preflight_identical': True,
        'remaining': ['8 further H2 IDs and combined matrix', 'H3/multipart/genuine early data',
                      'Full quality/platform/compliance/physical gates', 'Maintained publication, production adoption and original milestones']}
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (output / 'README.md').write_text(f'''# Owned HTTP/2 application-error evidence

The [archive](application-error-live.tar.gz) retains actual current/historical
fixture and runtime sources, compiler recipes/receipts/full input maps,
offline failures and regressions, initial/scoped source reviews, Root input
audits, exact authorization/command, raw output/results/public certificate and
independent host result audit. All {len(members)} safe regular files have
{len(inventory)} inventory entries. No private key, credential, compiled
executable or Python cache is included.

Archive SHA-256: `{manifest['archive_sha256']}` ({manifest['archive_bytes']} bytes).
See [manifest](manifest.json) and [component report](../../m2_h2_application_error_live.md).

One owned Linux ReleaseSafe TLS1.3/h2 run passes sink_error, invalid_progress,
end_error and idle shutdown. Chunk/invalid cases retain exactly7/H7, one cancel
and no end. End error retains32/H32, one end/error and no second cancel. All
three assert one INTERNAL_ERROR reset with no final HTTP response. Each has
independent same-route recovery, expired old controls and a healthy sibling.
Primary refunds15/15/32 precede sibling DATA; sibling accounting is separate.

Actual totals: six admissions, four ends, two cancels,142accepted, one each
chunk/invalid/end error, no failed begin/fixture errors/active binding. DATA
161sent/refunded, all32records/finalmetrics equal through deinit, four fresh
owned connections, normal SIGTERMexit0/reaped/keyremoved, log15942<65536.
Before/after audits match for2436inputs/7trees/six archives and current native
builds. Neither callback sizes nor packet segmentation is an oracle.

Current fixture-v2 and runtime-v2 remain unchanged for the preparation-tool fix;
manifest-v3 `{manifest['review_manifest_sha256']}` additionally binds the guarded
checker/test/binder. Review caught checker import-time validation/temporary
writes. Its actual-source regression detects attempted effects even if restored,
and the explicit CLI still accepts/mutates/rejects/restores/accepts. Scoped
re-review passes. Initial counter-schema omission and corrected v2 builds,
policy RED, inherited ledger mismatch and checker-handler failure remain in
history. Twenty runtime-harness tests plus one import regression prove
preparation; the separately released run proves the stated live observations.

The unchanged1031-file [candidate](../m2_h2_native_tcp/README.md), reviewedc223
override, original C binding/six archives and
[pinned client](../m2_h2_client/README.md) remain the source/tool basis. Complete
changed candidate src bytes are in the [metadata archive](../m2_h2_metadata_live/README.md).
This archive does not activate candidate code or unpublished dependency pins.

32 H2 case IDs are proved; eight and the full combined matrix remain. Other
lifecycle/output, H3/multipart/genuine early data and fullquality/platform/
compliance/physical/provenance/adoption/release requirements remain open. No
performance/RSS/leak/general native-safety claim, automatic retry, native fault
injection or stopped/denied-case reconstruction is made.
''')
    print(json.dumps({k: manifest[k] for k in ('archive_sha256', 'archive_bytes', 'safe_regular_members', 'inventory_entries', 'result_sha256')}, indent=2))


if __name__ == '__main__':
    main()
