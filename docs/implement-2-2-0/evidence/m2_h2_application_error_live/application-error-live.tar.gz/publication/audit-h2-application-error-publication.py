"""Verify public archive inventory, exclusions and actual source/result linkage."""
import hashlib
import json
import re
import tarfile
from pathlib import Path, PurePosixPath


def main():
    root = Path('/workspaces/uWebZockets')
    base = root / 'docs/implement-2-2-0/evidence/m2_h2_application_error_live'
    manifest = json.loads((base / 'manifest.json').read_text())
    sha = lambda data: hashlib.sha256(data).hexdigest()
    archive = base / manifest['archive']
    assert sha(archive.read_bytes()) == manifest['archive_sha256'] and archive.stat().st_size == manifest['archive_bytes']
    with tarfile.open(archive, 'r:gz') as reader:
        entries = reader.getmembers()
        assert len(entries) == manifest['safe_regular_members'] == len({e.name for e in entries})
        data = {}
        for entry in entries:
            name = PurePosixPath(entry.name)
            assert entry.isfile() and entry.mode == 0o644 and not name.is_absolute()
            assert '..' not in name.parts and '__pycache__' not in name.parts
            payload = reader.extractfile(entry).read()
            payload.decode('utf-8')
            assert not payload.startswith((b'\x7fELF', b'\0asm'))
            assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[0-9A-Z]{16}', payload)
            data[entry.name] = payload
    inventory = json.loads(data['inventory.json'])['files']
    assert len(inventory) == manifest['inventory_entries']
    assert {row['path'] for row in inventory} == set(data) - {'inventory.json'}
    for row in inventory:
        assert row['bytes'] == len(data[row['path']]) and row['sha256'] == sha(data[row['path']])
    assert sha(data['evidence/manifest-v3.json']) == manifest['review_manifest_sha256'] == 'd2bb368da8f912f3b37ed97376d8d73a11259570b44aae893981609e3ac5a62f'
    assert sha(data['evidence/stage-b/result.json']) == manifest['result_sha256'] == '37497935eeaa31dc7edf5d84b68dca6dd27cd52f23add80c72bbcd0ccb317528'
    audit = json.loads(data['evidence/stage-b/root-result-audit.json'])
    assert audit['checks_passed'] and audit['totals'] == manifest['totals']
    assert audit['post_deinit_records_match'] == 32 and audit['post_deinit_metrics_match']
    assert sha(data['evidence/stage-b/root-result-audit.json']) == manifest['root_result_audit_sha256']
    assert len(manifest['all_verified_case_ids']) == 32 and len(manifest['planned_unimplemented']) == 8
    assert not set(manifest['all_verified_case_ids']) & set(manifest['planned_unimplemented'])
    for kind in ('fixture', 'runtime'):
        for version in (1, 2):
            location = Path('/tmp/uwz-task5c2-' + kind + '-v' + str(version))
            prefix = 'source/' + kind + '-v' + str(version) + '/'
            names = {name[len(prefix):] for name in data if name.startswith(prefix)}
            assert names == {p.name for p in location.iterdir()}
            for name in names:
                assert data[prefix + name] == (location / name).read_bytes()
    result = {'checks_passed': True, 'archive_sha256': manifest['archive_sha256'],
              'safe_regular_members': len(entries), 'inventory_entries': len(inventory),
              'raw_result_sha256': manifest['result_sha256'], 'frozen_versions_verified': 4,
              'scope': 'Publication integrity only; no native rerun.'}
    output = root / '.superpowers/sdd/h2_streaming_plan/application-error-publication-audit.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
