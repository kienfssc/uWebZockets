import gzip
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path, PurePosixPath

REPO = Path('/workspaces/uWebZockets')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def add_file(members, name, path):
    assert name not in members and '..' not in PurePosixPath(name).parts
    assert not PurePosixPath(name).is_absolute() and path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    assert not data.startswith(b'\x7fELF'), name
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[0-9A-Z]{16}', data), name
    members[name] = data


def tar_bytes(members):
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w') as tar:
        for name, data in sorted(members.items()):
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            tar.addfile(entry, io.BytesIO(data))
    return buffer.getvalue()


def main():
    evidence = REPO / '.uwz-work/evidence/h2-streaming/integration-owned/admission'
    output = REPO / 'docs/implement-2-2-0/evidence/m2_h2_admission_live'
    output.mkdir(parents=True, exist_ok=True)
    audit = json.loads((evidence / 'stage-b/root-result-audit.json').read_text())
    assert audit['checks_passed'] and audit['postrun_preflight_identical']
    assert audit['child_exit_zero_reaped'] and audit['key_absent']
    assert audit['post_deinit_records_match'] == 32 and audit['post_deinit_metrics_match']
    assert audit['totals'] == {'middleware': 22, 'attempts': 19, 'begin': 18, 'end': 16, 'cancel': 2, 'failure': 1, 'accepted': 384, 'errors': 0}
    members = {}
    for path in sorted(evidence.rglob('*')):
        if path.is_file():
            add_file(members, 'evidence/' + path.relative_to(evidence).as_posix(), path)
    for label, root in [('fixture-v1', Path('/tmp/uwz-task5b2-fixture-source-v1')),
                        ('fixture-v2', Path('/tmp/uwz-task5b2-fixture-source-v2')),
                        ('combined-v1', Path('/tmp/uwz-task5b2-combined-frozen-v1')),
                        ('fix1', Path('/tmp/uwz-task5b2-fix1-frozen'))]:
        for path in sorted(root.iterdir()):
            add_file(members, 'source/' + label + '/' + path.name, path)
    reports = ['task-5b2-architecture.md', 'task-5b2-brief.md', 'task-5b2-report.md',
               'task-5b2-fixture-brief.md', 'task-5b2-fixture-report.md',
               'task-5b2-driver-brief.md', 'task-5b2-driver-report.md',
               'task-5b2-fix-1-brief.md', 'task-5b2-stage-b-report.md']
    for name in reports:
        add_file(members, 'reports/' + name, REPO / '.superpowers/sdd/h2_streaming_plan' / name)
    add_file(members, 'reports/component.md', REPO / 'docs/implement-2-2-0/m2_h2_admission_live.md')
    add_file(members, 'inputs/h2_client.py', REPO / '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py')
    add_file(members, 'inputs/immutable-libxev-input.json', REPO / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json')
    add_file(members, 'publication/publish-h2-admission-live.py', Path(__file__).resolve())
    inventory = [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(members.items())]
    members['inventory.json'] = (json.dumps({'binding': 'Publication-time bytes; partial/fixture/combined/fix receipts retain their actual source identities.', 'files': inventory}, indent=2) + '\n').encode()
    archive = output / 'admission-live.tar.gz'
    archive.write_bytes(gzip.compress(tar_bytes(members), mtime=0))
    with tarfile.open(archive, 'r:gz') as tar:
        entries = tar.getmembers()
        assert len(entries) == len(members) == len({p.name for p in entries})
        for entry in entries:
            assert entry.isfile() and not PurePosixPath(entry.name).is_absolute() and '..' not in PurePosixPath(entry.name).parts
            assert tar.extractfile(entry).read() == members[entry.name]
    remaining = ['queued_trailers_padding', 'concurrent_routes', 'receive_credit', 'metadata_helpers',
                 'producer_reuse', 'output_pressure_window', 'output_pressure_ready', 'stream_file',
                 'early_final_order', 'cancel_ready', 'cancel_paused', 'peer_reset', 'sink_error',
                 'invalid_progress', 'end_error', 'disconnect', 'reuse', 'shutdown_active']
    prior = ['ready_buffered', 'async_delayed', 'large_declared', 'large_undeclared', 'shutdown_idle',
             'partial_pause', 'final_pause', 'begin_pause_empty', 'control_rules']
    manifest = {'scope': 'One Linux ReleaseSafe owned application admission/limits/Continue/quota/recovery run plus idle shutdown; broader gates and adoption open.',
                'source_digest': audit['source_digest'], 'source_files': 1031,
                'source_checkpoint': '../m2_h2_native_tcp/README.md',
                'archive': archive.name, 'archive_sha256': digest(archive.read_bytes()),
                'archive_bytes': archive.stat().st_size, 'safe_regular_members': len(members),
                'inventory_entries': len(inventory), 'binary_sha256': audit['binary_sha256'],
                'review_manifest_sha256': digest((evidence / 'fix1/review-manifest.json').read_bytes()),
                'preflight_audit_sha256': audit['preflight_sha256'],
                'authorization_sha256': digest((evidence / 'fix1/stage-b-authorization.json').read_bytes()),
                'result_sha256': digest((evidence / 'stage-b/result.json').read_bytes()),
                'root_result_audit_sha256': digest((evidence / 'stage-b/root-result-audit.json').read_bytes()),
                'cases_passed': audit['cases_passed'], 'previously_verified': prior,
                'planned_unimplemented': remaining, 'totals': audit['totals'],
                'post_deinit_records_equal': 32, 'post_deinit_metrics_equal': True,
                'responses_ended': 76, 'refused_raw_resets': 6, 'informational_100': 2,
                'tls': 'TLS1.3 / h2', 'runtime_mode': 'ReleaseSafe', 'exit_status': 0,
                'runtime_retries': 0, 'child_exit_zero_reaped': True, 'private_key_removed': True,
                'remaining': ['All18 planned H2 cases and combined matrix', 'H3, multipart transport and genuine early data',
                              'Full native, sanitizer, physical lifetime, compliance and platform gates',
                              'Maintained publication, production adoption and original milestone completion']}
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (output / 'README.md').write_text(f'''# Owned HTTP/2 admission and recovery evidence

The [archive](admission-live.tar.gz) preserves partial observer work, both fixture
snapshots, combined and fixed packages, actual compile receipts, full inventories,
pure codec/ledger/module-binding checks, initial and fix reviews, Root audit and
precise authorization, exact executed command, raw result/server log/public
certificate and result audit. All {len(members)} members are safe regular files;
{len(inventory)} inventory entries verify. No private key or compiled executable is included.

Archive SHA-256: `{manifest['archive_sha256']}` ({manifest['archive_bytes']} bytes).
See the [manifest](manifest.json) and [component report](../../m2_h2_admission_live.md).

All13 admission cases plus idle shutdown pass in one owned Linux ReleaseSafe
TLS1.3/h2 run. Actual totals:22bodyheads/middleware,19beginattempts,18bindings,
16ends,2cancels,1failedbegin,384acceptedbytes,zeroactive/errors. Both cancellations
are body_too_large. Each Continue case has one100 beforepositiveDATA; six refused
primaries have413/503 emptybody followed by one rawNO_ERROR reset afterfinalEOS.
Every finalbody response retains the middleware header. Same-route recovery and
TWO simultaneous quota2 recoveries are asserted by the executed driver.

All32 records, including ten untouched spares, and finalmetrics match after
deinit. All76finalresponses end;54bufferedmiddleware+22bodymiddleware agree.
OwnedSIGTERM exits0/reaps/no force orretry; keyremoved. Raw observations cover
the stated barriers, not arbitraryfutureunreadframes or exceptionalcleanup.

Source is unchanged1031-file
`{manifest['source_digest']}` from the
[native checkpoint](../m2_h2_native_tcp/README.md), with unchanged reviewedc223,
bindings/libraries and [pinned client](../m2_h2_client/README.md). The
[core upload](../m2_h2_core_live/README.md) and
[pause/control](../m2_h2_pause_control_live/README.md) results remain separate.
Exact original and corrected compiler argv/source/input/binary hashes are under
`evidence/fixture-*` and `evidence/fix1/fixture-*`. Runtime argv/environment are
in `evidence/fix1/stage-b-authorization.json`; that describes only this completed
run, not arbitrary future execution permission.

Initial source review passes protocol but requires two four-level branches to
be flattened. Both scoped re-reviews pass the helper extractions; the corrected
profile is newly compiled in Debug and ReleaseSafe, with only ReleaseSafe run.
No behavioralred is fabricated for the control-flow refactor. Pure checks and
compiler acceptance do not substitute for the separate native result.

All18 further planned H2 cases and the combined matrix remain required. H3,
multipart transport, genuine earlydata, fullquality/platform/compliance/physical
lifetime, maintained publication, production adoption and M2 remain open.
Fixed-capacity evidence is not RSS/leak/native safety proof. Stopped experiments
and denied socket cases were not resumed.
''')
    print(json.dumps({k: manifest[k] for k in ['archive_sha256', 'archive_bytes', 'safe_regular_members', 'inventory_entries', 'result_sha256', 'root_result_audit_sha256']}, indent=2))


if __name__ == '__main__':
    main()
