"""Independently verify retained application-error protocol observations."""
import hashlib
import json
import ssl
from pathlib import Path


def main():
    root = Path('/workspaces/uWebZockets')
    base = root / '.uwz-work/evidence/h2-streaming/integration-owned/application-error'
    raw = base / 'stage-b/result.json'
    result = json.loads(raw.read_text())
    assert result['success'] and result['error'] is None and result['failure'] is None
    assert result['manifest_sha256'] == 'd2bb368da8f912f3b37ed97376d8d73a11259570b44aae893981609e3ac5a62f'
    assert result['child']['binary_sha256'] == 'f75410391bac1d3e55a55af0f1acecef496e890256de27bbfe3b8a28af0f83ef'
    assert result['cleanup'] == {'signal': 'SIGTERM', 'exit_code': 0, 'reaped': True, 'forced': False, 'errors': []}
    names = ('sink_error', 'invalid_progress', 'end_error')
    assert list(result['cases']) == [*names, 'shutdown_idle']
    assert result['cases']['shutdown_idle'] == {'exit_code': 0, 'post_deinit': True}
    p32 = bytes(range(1, 11)) + b'final-upload-sentinel!'
    h32, h7, empty = (hashlib.sha256(p).hexdigest() for p in (p32, p32[:7], b''))
    for name in names:
        case = result['cases'][name]
        is_end = name == 'end_error'
        count, target = (32, 32) if is_end else (7, 15)
        before, terminal = case['before'], case['terminal']
        if is_end:
            assert before is None
        else:
            assert (before['begin'], before['end'], before['cancel'], before['accepted'], before['sha256'], before['paused']) == (1, 0, 0, 7, h7, False)
            assert before['chunk_errors'] == before['invalid_progress'] == before['end_errors'] == 0
        assert (terminal['begin'], terminal['end'], terminal['cancel'], terminal['accepted'], terminal['active'], terminal['paused']) == (1, int(is_end), int(not is_end), count, False, False)
        assert terminal['reason'] == ('none' if is_end else 'sink_failure')
        assert terminal['sha256'] == (h32 if is_end else h7)
        assert terminal['chunk_errors'] == int(name == 'sink_error')
        assert terminal['invalid_progress'] == int(name == 'invalid_progress')
        assert terminal['end_errors'] == int(is_end)
        wire = case['terminal_wire']
        assert wire['headers'] is None and wire['bytes'] == 0 and wire['informationals'] == 0
        assert wire['raw_reset'] and wire['reset_event']
        assert case['credit'] == {'target': target, 'sent': target, 'refunded': target, 'connection_window': 65535, 'public_window': 65535}
        sibling = case['sibling']
        assert sibling['body'] == 's' and sibling['bytes'] == 1 and not sibling['raw_reset']
        flow = sibling['flow']
        assert flow['sent_before'] == target and flow['sent_after'] == target + 1
        assert flow['refunded_before'] == target and target <= flow['refunded_after'] <= target + 1
        for phase in ('stale_before', 'stale_after'):
            assert len(case[phase]) == 2
            assert all(item['body'] == 'BodyControlExpired' and not item['raw_reset'] for item in case[phase])
        recovery = case['recovery']
        assert (recovery['accepted'], recovery['sha256'], recovery['begin'], recovery['end'], recovery['cancel']) == (32, h32, 1, 1, 0)
        assert recovery['chunk_errors'] == recovery['invalid_progress'] == recovery['end_errors'] == 0
    statuses = result['final_status']
    admitted = {tag for name in names for tag in (name, name + '_recovery')}
    assert len(statuses) == 32 and set(statuses) == admitted | {'spare_' + str(i).zfill(2) for i in range(26)}
    counters = ('middleware', 'attempts', 'begin', 'end', 'cancel', 'failure', 'end_errors', 'chunk_errors', 'invalid_progress', 'accepted', 'chunks', 'max_span', 'metadata_middleware', 'metadata_begin', 'metadata_end', 'stale_resume', 'stale_cancel')
    for tag, row in statuses.items():
        assert row['tag'] == tag and not row['active'] and not row['paused'] and row['errors'] == 0
        if tag not in admitted:
            assert all(row[k] == 0 for k in counters) and row['sha256'] == empty and row['reason'] == 'none'
            continue
        recovery, is_end = tag.endswith('_recovery'), tag == 'end_error'
        ended = recovery or is_end
        count = 32 if ended else 7
        assert (row['middleware'], row['attempts'], row['begin'], row['end'], row['cancel'], row['failure'], row['accepted']) == (1, 1, 1, int(ended), int(not ended), 0, count)
        assert row['sha256'] == (h32 if ended else h7)
        assert row['reason'] == ('none' if ended else 'sink_failure')
        assert row['chunk_errors'] == int(tag == 'sink_error')
        assert row['invalid_progress'] == int(tag == 'invalid_progress')
        assert row['end_errors'] == int(is_end)
        assert row['metadata_middleware'] == row['metadata_begin'] == 1
        assert row['metadata_end'] == int(ended)
        assert row['stale_resume'] == row['stale_cancel'] == (0 if recovery else 2)
    metrics = result['final_metrics']
    assert metrics == {'middleware': 6, 'attempts': 6, 'begin': 6, 'end': 4, 'cancel': 2, 'failure': 0, 'end_errors': 1, 'chunk_errors': 1, 'invalid_progress': 1, 'accepted': 142, 'active': 0, 'errors': 0, 'buffered_middleware': 57, 'slot0_active': False, 'slot1_active': False}
    log = (base / 'stage-b/server.log').read_text()
    rows, summaries = {}, []
    for line in log.splitlines():
        marker = 'H2_RECORD ' + result['nonce'] + ' '
        if marker in line:
            row = json.loads(line.split(marker, 1)[1])
            assert row['tag'] not in rows
            rows[row['tag']] = row
        marker = 'H2_DEINIT ' + result['nonce'] + ' '
        if marker in line:
            summaries.append(json.loads(line.split(marker, 1)[1]))
    assert rows == statuses and summaries == [metrics]
    assert len(log.encode()) == 15942 and len(log.encode()) < 65536
    connections = result['connections']
    assert len(connections) == 4 and [c['case'] for c in connections] == [*names, 'shutdown_idle']
    assert all(c['tls'] == 'TLSv1.3' and c['alpn'] == 'h2' for c in connections)
    assert [c['sent_flow'] for c in connections[:3]] == [48, 48, 65]
    assert [c['refunded_flow'] for c in connections[:3]] == [48, 48, 65]
    der = ssl.PEM_cert_to_DER_cert((base / 'stage-b/certificate.pem').read_text())
    assert hashlib.sha256(der).hexdigest() == result['certificate_sha256']
    assert not Path('/proc', str(result['child']['pid'])).exists()
    assert not Path('/tmp/uwz-h2-application-error-owned-2026-10-29-r1/private-key.pem').exists()
    pre = root / '.superpowers/sdd/h2_streaming_plan/task-5c2-root-preflight.json'
    assert hashlib.sha256(pre.read_bytes()).hexdigest() == '9d6cd8911ba29f9c12616ec5ce7090b69fe27029a4a9f870ea0c95a15e41d09a'
    audit = {'checks_passed': True, 'result_sha256': hashlib.sha256(raw.read_bytes()).hexdigest(),
             'cases_passed': [*names, 'shutdown_idle'], 'totals': metrics,
             'post_deinit_records_match': 32, 'post_deinit_metrics_match': True,
             'primary_credit_targets': [15, 15, 32], 'client_data_flow_sent': 161,
             'client_data_flow_refunded': 161, 'fresh_tls_connections': 4,
             'child_exit_zero_reaped': True, 'host_pid_absent': True, 'key_absent': True,
             'server_log_bytes': len(log.encode()), 'postrun_preflight_identical': True,
             'scope': 'Ordinary public application-error/protocol observations; broader matrix, physical lifetime, performance and production adoption remain open.'}
    output = base / 'stage-b/root-result-audit.json'
    output.write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps(audit, indent=2))


if __name__ == '__main__':
    main()
