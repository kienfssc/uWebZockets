"""Import must not validate the closure or attempt any file writes."""
import contextlib
import io
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch


class CheckerImportTests(unittest.TestCase):
    def test_import_has_no_validation_or_writes(self):
        path = Path(__file__).resolve().parent / 'check_closure.py'
        code = compile(path.read_bytes(), str(path), 'exec')
        effects = []
        def validate(*args):
            effects.append('validate')
            if effects.count('validate') == 2:
                raise RuntimeError('synthetic mismatch')
        def write(*args):
            effects.append('write')
        module = SimpleNamespace(check_manifest=validate)
        spec = SimpleNamespace(loader=SimpleNamespace(exec_module=lambda _: None))
        with patch('importlib.util.spec_from_file_location', return_value=spec), \
             patch('importlib.util.module_from_spec', return_value=module), \
             patch.object(Path, 'read_bytes', return_value=b'fake input'), \
             patch.object(Path, 'write_bytes', side_effect=write), \
             contextlib.redirect_stdout(io.StringIO()):
            exec(code, {'__name__': 'imported_checker', '__file__': str(path)})
        self.assertEqual(effects, [])


if __name__ == '__main__':
    unittest.main()
