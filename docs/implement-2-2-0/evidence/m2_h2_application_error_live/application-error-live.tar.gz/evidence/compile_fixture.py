"""Compile one frozen fixture only; never execute its output."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspaces/uWebZockets')
HERE = Path(__file__).resolve().parent
SOURCE = Path('/tmp/uwz-task4d-fix1-frozen')
OVERRIDE = Path('/tmp/uwz-reviewed-libxev-c223-loop-callbacks')
EXPECTED = 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de'
ENV = {'LC_ALL': 'C.UTF-8'}


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        while data := stream.read(1048576):
            h.update(data)
    return h.hexdigest()


def inventory(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}


def main():
    snapshot = Path(sys.argv[1])
    mode = sys.argv[2]
    label = sys.argv[3]
    if mode not in ('debug', 'release') or not label.startswith('fixture-'):
        raise ValueError('invalid compile selection')
    old = json.loads((HERE.parent / 'metadata' / ('fixture-' + mode + '-final.json')).read_text())
    argv = old['argv'].copy()
    argv[next(i for i, v in enumerate(argv) if v.startswith('-Mroot='))] = '-Mroot=' + str(snapshot / 'profile.zig')
    output = Path('/tmp/uwz-task5c2-' + label)
    if output.exists():
        raise ValueError('output exists')
    output.mkdir()
    argv[argv.index('--cache-dir') + 1] = '/tmp/uwz-task5c1-fixture-' + mode + '-v1/cache'
    argv[argv.index('--global-cache-dir') + 1] = '/tmp/uwz-task5c1-fixture-' + mode + '-v1/global'
    argv[-1] = '-femit-bin=' + str(output / 'profile')
    before_source = inventory(SOURCE)
    source_digest = hashlib.sha256(json.dumps(list(before_source.items())).encode()).hexdigest()
    if len(before_source) != 1031 or source_digest != EXPECTED:
        raise ValueError('candidate inventory mismatch')
    before_override = inventory(OVERRIDE)
    expected_override = json.loads((ROOT / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json').read_text())['files_sha256']
    if len(before_override) != 93 or before_override != expected_override:
        raise ValueError('override inventory mismatch')
    snapshot_before = inventory(snapshot)
    inputs = [Path(v.split('=', 1)[1]) for v in argv if v.startswith('-M')]
    inputs += [Path(v) for v in argv if v.endswith('.a')]
    inputs += [Path(argv[0])]
    before = {str(p): digest(p) for p in inputs}
    reviewed = old['input_sha256']
    for name, value in before.items():
        if name != str(snapshot / 'profile.zig') and reviewed.get(name) != value:
            raise ValueError('reviewed input mismatch: ' + name)
    result = subprocess.run(argv, cwd=SOURCE, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (HERE / (label + '.stdout')).write_bytes(result.stdout)
    (HERE / (label + '.stderr')).write_bytes(result.stderr)
    after = {str(p): digest(p) for p in inputs}
    source_after = inventory(SOURCE)
    override_after = inventory(OVERRIDE)
    snapshot_after = inventory(snapshot)
    record = {'argv': argv, 'cwd': str(SOURCE), 'environment': ENV, 'optimization': old['optimization'],
              'input_before': before, 'input_after': after, 'source_before': before_source, 'source_after': source_after,
              'override_before': before_override, 'override_after': override_after, 'snapshot_before': snapshot_before,
              'snapshot_after': snapshot_after, 'source_digest': source_digest, 'exit_status': result.returncode,
              'binary_sha256': digest(output / 'profile') if (output / 'profile').exists() else None,
              'stdout': label + '.stdout', 'stderr': label + '.stderr',
              'unchanged': before == after and before_source == source_after and before_override == override_after and snapshot_before == snapshot_after}
    (HERE / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print('mode:', mode, 'exit:', result.returncode, 'stdout bytes:', len(result.stdout), 'stderr bytes:', len(result.stderr), 'unchanged:', record['unchanged'], 'binary sha256:', record['binary_sha256'])
    if result.stderr:
        print(result.stderr.decode(), end='')
    if result.returncode or not record['unchanged']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
