"""Bounded raw HTTP/2 frame-order observation; transport is external."""
READ_BOUND = 8192
STREAM_LIMIT = 8
FRAME_LIMIT = 16384
POLICIES = ('healthy', 'public_cancel', 'peer_reset', 'refusal_after_final', 'application_failure')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def new_state():
    return {'header': bytearray(), 'remaining': 0, 'frame': None,
            'reset_payload': bytearray(), 'streams': {}, 'high_water': 0}


def register(state, stream_id, policy):
    streams = state['streams']
    require(policy in POLICIES, 'invalid terminal policy')
    require(state['high_water'] < stream_id <= 0x7fffffff and stream_id & 1, 'invalid stream')
    require(len(streams) < STREAM_LIMIT, 'stream bound')
    state['high_water'] = stream_id
    streams[stream_id] = {'policy': policy, 'end': False, 'reset': False,
                          'peer_reset': False}


def mark_peer_reset(state, stream_id, code):
    record = state['streams'][stream_id]
    require(record['policy'] == 'peer_reset' and code == 8, 'invalid peer reset')
    require(not record['end'] and not record['peer_reset'], 'duplicate peer reset')
    record['peer_reset'] = True


def retire(state, stream_id):
    record = state['streams'][stream_id]
    policy = record['policy']
    complete = ((policy == 'healthy' and record['end'] and not record['reset']) or
                (policy in ('public_cancel', 'application_failure') and record['reset'] and not record['end']) or
                (policy == 'peer_reset' and record['peer_reset'] and not record['end'] and not record['reset']) or
                (policy == 'refusal_after_final' and record['end'] and record['reset']))
    require(complete, 'incomplete stream')
    del state['streams'][stream_id]


def finish_frame(state):
    frame = state['frame']
    stream_id = frame['stream']
    record = state['streams'].get(stream_id)
    if frame['type'] == 3:
        require(record is not None, 'reset on unregistered stream')
        policy = record['policy']
        require(policy in ('public_cancel', 'refusal_after_final', 'application_failure'), 'unexpected reset')
        require(not record['reset'], 'duplicate reset')
        require((policy == 'refusal_after_final') == record['end'], 'reset order')
        expected = {'public_cancel': 8, 'refusal_after_final': 0, 'application_failure': 2}[policy]
        require(int.from_bytes(state['reset_payload'], 'big') == expected, 'wrong reset code')
        record['reset'] = True
    elif frame['type'] in (0, 1):
        require(record is not None, 'payload on unregistered stream')
        require(not record['end'] and not record['reset'] and not record['peer_reset'],
                'payload after terminal')
        if frame['flags'] & 1:
            record['end'] = True
    state['frame'] = None
    state['reset_payload'].clear()


def observe(state, data):
    require(len(data) <= READ_BOUND, 'read bound')
    offset = 0
    while offset < len(data):
        if state['frame'] is None:
            header = state['header']
            count = min(9 - len(header), len(data) - offset)
            header.extend(data[offset:offset + count])
            offset += count
            if len(header) < 9:
                continue
            length = int.from_bytes(header[:3], 'big')
            frame_type = header[3]
            stream_id = int.from_bytes(header[5:9], 'big') & 0x7fffffff
            require(length <= FRAME_LIMIT, 'frame bound')
            if frame_type == 3:
                require(length == 4 and stream_id != 0, 'invalid reset frame')
            state['frame'] = {'type': frame_type, 'flags': header[4], 'stream': stream_id}
            state['remaining'] = length
            header.clear()
            if length == 0:
                finish_frame(state)
            continue
        count = min(state['remaining'], len(data) - offset)
        if state['frame']['type'] == 3:
            state['reset_payload'].extend(data[offset:offset + count])
        offset += count
        state['remaining'] -= count
        if state['remaining'] == 0:
            finish_frame(state)
