"""Validate the two actual compile receipts against current bound inputs."""
import hashlib
import json
from pathlib import Path

ARCHIVES = tuple('/workspaces/uWebZockets/zig-out/lib/' + n for n in (
    'libuWebZockets.a', 'libssl.a', 'libcrypto.a', 'liblsquic.a', 'libdeflate.a', 'libz.a'))


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        while data := stream.read(1048576):
            h.update(data)
    return h.hexdigest()


def validate(manifest, current):
    receipts = manifest['build_input_receipts']
    if len(receipts) != 2:
        raise ValueError('two actual receipts required')
    merged = {}
    for path, mode in zip(receipts, ('Debug', 'ReleaseSafe')):
        receipt = json.loads(Path(path).read_text())
        argv = receipt['argv']
        inputs = {v.split('=', 1)[1] for v in argv if v.startswith('-M') and '=' in v}
        archives = {v for v in argv if v.endswith('.a')}
        if len(inputs) != 6 or archives != set(ARCHIVES):
            raise ValueError('build modules or archives differ')
        inputs.update(archives)
        inputs.add(argv[0])
        before = receipt['input_before']
        if set(before) != inputs or before != receipt['input_after']:
            raise ValueError('build input maps differ')
        if receipt['optimization'] != mode or receipt['exit_status'] != 0 or not receipt['unchanged']:
            raise ValueError('build failed or changed')
        if receipt['source_before'] != receipt['source_after'] or receipt['override_before'] != receipt['override_after'] or receipt['snapshot_before'] != receipt['snapshot_after']:
            raise ValueError('build inventory changed')
        if len(receipt['source_before']) != 1031 or len(receipt['override_before']) != 93:
            raise ValueError('build tree count differs')
        if receipt['source_before'] != manifest['trees']['/tmp/uwz-task4d-fix1-frozen'] or receipt['override_before'] != manifest['trees']['/tmp/uwz-reviewed-libxev-c223-loop-callbacks'] or receipt['snapshot_before'] != manifest['trees']['/tmp/uwz-task5c2-fixture-v2']:
            raise ValueError('build and current inventory differ')
        if receipt['cwd'] != '/tmp/uwz-task4d-fix1-frozen' or receipt['environment'] != {'LC_ALL': 'C.UTF-8'} or '-j2' not in argv:
            raise ValueError('build environment differs')
        for name, value in before.items():
            if current.get(name) != value or name in merged and merged[name] != value:
                raise ValueError('current build input differs: ' + name)
            merged[name] = value
        output = next(v.split('=', 1)[1] for v in argv if v.startswith('-femit-bin='))
        if current.get(output) != receipt['binary_sha256']:
            raise ValueError('build binary differs')
        directory = Path(path).parent
        for key in ('stdout', 'stderr'):
            log = directory / receipt[key]
            if log.read_bytes() or current.get(str(log)) != digest(log):
                raise ValueError('compiler output differs')
    if any(merged[p] != manifest['approved_archives'][p] for p in ARCHIVES):
        raise ValueError('reviewed archive differs')
    return merged
