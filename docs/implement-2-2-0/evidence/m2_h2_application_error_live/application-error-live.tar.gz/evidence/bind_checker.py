"""Bind inert preparation tools to the already reviewed runtime closure."""
import hashlib
import importlib.util
import json
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    here = Path(__file__).resolve().parent
    previous = here / 'manifest-v2.json'
    output = here / 'manifest-v3.json'
    if output.exists():
        raise ValueError('manifest already exists')
    expected = '268d028772435296ad1fcd3959db0ff0ab410799c25f658bdcfa04989b347a22'
    spec = importlib.util.spec_from_file_location('frozen_runner', '/tmp/uwz-task5c2-runtime-v2/run_live.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    manifest = runner.check_manifest(previous, expected)
    for name in ('check_closure.py', 'test_checker_import.py', 'bind_checker.py'):
        path = here / name
        manifest['inputs'][str(path)] = digest(path)
    output.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    result = digest(output)
    runner.check_manifest(output, result)
    print('v2 closure accepted; v3 closure accepted')
    print('direct inputs:', len(manifest['inputs']))
    print('manifest sha256:', result)


if __name__ == '__main__':
    main()
