"""Offline synthetic filesystem tests for the actual ownership helper."""
import unittest
from unittest.mock import patch

import run_live


class FakePath:
    def __init__(self, entries, rows, directory_error=None):
        self.entries = entries
        self.rows = rows
        self.directory_error = directory_error

    def __call__(self, *parts):
        return FakeNode(self, parts)


class FakeNode:
    def __init__(self, owner, parts):
        self.owner = owner
        self.parts = parts

    def iterdir(self):
        if self.owner.directory_error:
            raise self.owner.directory_error
        return iter(self.owner.entries)

    def read_text(self):
        if isinstance(self.owner.rows, BaseException):
            raise self.owner.rows
        return 'header\n' + ''.join(item + '\n' for item in self.owner.rows)


def row(inode, endpoint='0100007F:6F1B', state='0A'):
    return '0: %s 00000000:0000 %s 0 0 0 0 0 %s' % (endpoint, state, inode)


def evaluate(entries, targets, rows, directory_error=None):
    paths = FakePath(entries, rows, directory_error)

    def readlink(entry):
        value = targets[entry]
        if isinstance(value, BaseException):
            raise value
        return value

    with patch.object(run_live, 'Path', paths), patch.object(run_live.os, 'readlink', readlink):
        result = run_live.owned_listener(17)
        run_live.require(len(result) == 1, 'owned loopback listener not uniquely identified')
        return result


class ListenerTests(unittest.TestCase):
    def test_disappearing_enumerated_nonlistener(self):
        self.assertEqual(evaluate(['gone', 'listener'], {'gone': FileNotFoundError(2, 'gone', 'gone'),
                         'listener': 'socket:[42]'}, [row('42')]), ['42'])

    def test_missing_listener_wrong_inode_endpoint_or_state(self):
        for rows in ([], [row('43')], [row('42', endpoint='0200007F:6F1B')], [row('42', state='01')]):
            with self.subTest(rows=rows):
                with self.assertRaisesRegex(RuntimeError, 'listener not uniquely'):
                    evaluate(['listener'], {'listener': 'socket:[42]'}, rows)

    def test_multiple_owned_listeners_fail(self):
        with self.assertRaisesRegex(RuntimeError, 'listener not uniquely'):
            evaluate(['first', 'second'], {'first': 'socket:[42]', 'second': 'socket:[43]'}, [row('42'), row('43')])

    def test_listener_table_error_propagates(self):
        with self.assertRaises(PermissionError):
            evaluate(['listener'], {'listener': 'socket:[42]'}, PermissionError(13, 'denied', '/proc/net/tcp'))

    def test_missing_child_directory_propagates(self):
        with self.assertRaises(FileNotFoundError):
            evaluate([], {}, [row('42')], FileNotFoundError(2, 'missing child', '/proc/17/fd'))

    def test_permission_and_other_io_errors_propagate(self):
        for exc in (PermissionError(13, 'denied', 'entry'), OSError(5, 'io', 'entry')):
            with self.subTest(error=exc):
                with self.assertRaises(type(exc)):
                    evaluate(['bad', 'listener'], {'bad': exc, 'listener': 'socket:[42]'}, [row('42')])

    def test_failure_details_retain_type_filename_traceback_and_stage(self):
        try:
            raise FileNotFoundError(2, 'missing', '/synthetic/path')
        except FileNotFoundError as exc:
            detail = run_live.failure_details(exc, 'case:peer_reset:connect')
        self.assertEqual(detail['type'], 'FileNotFoundError')
        self.assertEqual(detail['filename'], '/synthetic/path')
        self.assertIn('missing', detail['message'])
        self.assertEqual(detail['stage'], 'case:peer_reset:connect')
        self.assertIn('FileNotFoundError', detail['traceback'])
        self.assertIn('test_failure_details', detail['traceback'])


if __name__ == '__main__':
    unittest.main()
