# Task5e1 fix round1 of5

Same replacement implementer resumes. Read original requirements, existing
report, and task-5e1-review.md. Address all three Important/P2 findings verbatim
in that report (items1-3); no findings are waived. Root accepts them as concrete
preservation gaps. No fixture/client/product/native/build scope expansion.

Ownership unchanged: new combined-contract directory, new task5e1 /tmp paths,
append same task-5e1-report.md. Root owns integration and Git/push/review.
Preserve v2 immutable snapshot, proof-v2, initial partial history and all old
results/reviews. No subagents, classes/assert proofs, errors swallowed, global
mutable model, or unchanged legacy entrypoint runs. No native/constructor/TLS/
socket/descriptor/kernel/resource/fault/cancel/schedule/race/panic/leak probes.

Required fixes:
1. Include shutdown_idle's inherited4096receive/snapshot cap, carried through
   final collection. Keep byte ceiling/J/C/R/deadlines unchanged. Cover idle
   literal4096 regression and relevant unmodified byte bound.
2. Named pure request/response and unchanged-sink contracts for ready_buffered
   and async_delayed, retaining exact257-byte echo/payload/digest, delayed-ok10,
   text/plain singularity and inactive/unchanged sink totals from core source.
   Preserve relevant status/headers/END/header multiplicity requirements; no
   invented unconditional middleware requirement on async. Add actual behavioral
   rejection checks for corrupt payload/hash/header/count and sink mutation.
3. Named producer_reuse_next binding observation/default and selection-aware
   pre/post contract: unselected exact tag/index0/generation0/no prior observation;
   selected matches earlier binding, relative A slot/genA+1; strict types and
   unchanged post binding. Preserve retained post.py behavior. Add rejection
   tests for stale/nonzero idle binding and changed post/invalid relative binding.

Use smallest cohesive model changes. New pure contracts express future client
requirements without pretending wire/formatter action already proved. Preserve
all existing family schemas/tests/budget barriers. Cover amended code through
test_catalogue.py, test_model.py, test_structure.py (normal and-O, pinnedPython
-B -S) rather than rerunning unrelated prior components. Capture behavioral RED
before each missing/weak contract is fixed and raw actual command/tool outputs in
new versioned proof files, in addition to report excerpts. Freeze a new6-file
source snapshot and hash inventory, equality against owned, all41 source hashes.
Report exact commands/raw results/new APIs/identities and remaining scope. Root
reads actual fix/report/evidence before same reviewer's scoped re-review.
