SPEC: Approved for the scoped Task5e1 pure catalogue/model preparation slice.

QUALITY: Approved. All three original Important/P2 findings are addressed; no new actionable findings in the fix diff.

Finding verdicts:

1. **Preserve the idle child's existing 4096 read bound — ADDRESSED.** `catalogue.py:84` now includes `shutdown_idle` in the inherited cap set. `catalogue.py:178` validates cumulative caller-owned receive consumption against that case's ceiling without granting a new allowance at final collection. `test_catalogue.py:18` independently checks the literal 4096 cap, unchanged 3109464-byte ceiling, remaining allowance at 4095 and 4096, rejection at 4097, and rejection of a bool counter. No J/C/R, deadline, final-collection count or byte-ceiling change appears in the fix.

2. **Encode required results for the two cases without body tags — ADDRESSED.** `model.py:396` defines the bounded buffered payload, request contracts and independent literal response hashes. `model.py:410` enforces exact payload/count/hash, terminal state, no informational or trailer response, one status 200, and a singular case-insensitive text/plain content type for delayed responses. It permits async responses without an invented middleware header. `model.py:425` checks the named core sink aggregate, strict u64 counters, inactive state and unchanged totals while allowing nonzero prior completed totals. The existing response-validation entry point dispatches the two core IDs to these checks. `test_model.py:32` covers the independent 257-byte construction and hash, request metadata, corrupt payload/hash/count, status/header multiplicity, terminal state and sink mutation. These pure contracts close the original missing interfaces without adding wire requests or claiming live evidence.

3. **Preserve the binding record's idle/default and post-deinit contract — ADDRESSED.** `model.py:436` supplies the exact separate zero binding record. `model.py:440` validates the selection, strict observation schema, no prior observation/context when unselected, selected A-to-B relative identity, and unchanged post binding. The strengthened `validate_reuse_binding` at `model.py:285` rejects unarmed, zero-generation or out-of-range producer identities. `model.py:382` makes binding observations mandatory keyword inputs to the overall output pre/post check. `test_model.py:58` covers idle and other unselected subsets, stale/nonzero/bool binding fields, changed post state, incorrect relative generation, invalid producer identity, and absent selected evidence. Existing integrated output tests pass the new explicit binding inputs.

New breakage in the fix diff: None found.

Out-of-scope observations: None recorded. Untouched code was not reopened for another broad review.

Structural conclusion: the standard code-quality review and requested structural lens remain satisfied under the project override. The additions are direct pure validators and bounded immutable contract data in their existing owning modules; `model.py` remains 448 lines. There is no file-size explosion, new hidden mutable state, speculative framework, or separate structural defect requiring decomposition.

Verification evidence and limits:

- Reviewed the complete v2-to-v3 five-file fix diff at `task-5e1-fix-1.diff`, identified by the dispatch as 26454 bytes and SHA256 `cda68417041b5e24049350caac3ee72f6749ce789d421d454264c085bd4866f2`. The original task requirements and first review remain the baseline; the fix brief, appended fix report and scoped re-review prompt governed this pass. Base/HEAD remain `2e1573d31bc7734e8fbcb7403381cdb0e2026ab7`. The unrelated documentation-table correction is outside this diff and verdict.
- Read all three actual RED/GREEN JSON pairs in `/tmp/uwz-task5e1-proof-v3`. Each RED records the relevant behavioral failure with exit 1, followed by its covering GREEN result with exit 0. Read `final-tests.json`: the six frozen-v3 runs of `test_catalogue.py`, `test_model.py` and `test_structure.py`, normal and Python `-O`, all use pinned Python with `-B -S`, return exit 0 and contain clean success output. This is retained execution evidence, not a reviewer rerun.
- Read the actual `identity-audit.json` result and Root's `task-5e1-root-fix-1-audit.json`: they record current owned/snapshot equality, preserved v2 source/proof identities, 41 retained sources plus two review inputs, and no authored class/assert statements. I did not independently execute that audit or relabel Root's work as my own.
- No tests, source imports, legacy entrypoints, constructors, builds, native/socket/TLS/descriptor/fault/schedule/race/kernel/resource/panic/leak experiments, subagents, or Git/index/ref operations were run. Only this named review report was written.
- Actual combined formatter/capture bounds, startup serialization/grants, paired action/observation ordering, fixture/client/ledger/closure integration, frozen builds and fresh two-child combined40 execution remain later, unverified work. Broad project/native/compliance/sanitizer/platform/fuzz/package gates remain open. Approval of this pure preparation slice does not establish original milestone or full40 native completion.

Fix round verdict: All original findings addressed; no new Critical/Important breakage.
