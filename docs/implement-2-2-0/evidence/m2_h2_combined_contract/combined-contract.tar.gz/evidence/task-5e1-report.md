# Task 5e1 partial report

Status: INCOMPLETE. The isolated catalogue is a proposed numerical schedule, not a source-proved schedule or a combined expected-state model. Do not release a combined execution on this basis. No fixture, runner, ledger, native operation, build or full gate was run. The requested independent expected records, per-case checked receive and final bounds, family-specific evidence, payload hashes and validation remain unimplemented. No combined formatter or 768/1024/prefix64 bound has been proved.

## Work retained

`.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/catalogue.py` contains 40 ordered IDs, the 67 unique case-to-tag mappings, proposed J/C/R/K data and checked u64 addition. `schedule` validates sequence type, duplicate and unknown IDs, idle first and active shutdown last, processes caller order, adds one 68-response collection for a nonempty main selection without active shutdown, and returns heads, small responses, request flow and connections. Empty selection returns zeros. It does not manufacture a shutdown_idle execution for partial main selections. The full proposed vector is `(802, 789, 200091899, 41)`; idle-only `(69,69,0,1)`; a single `empty_headers` `(71,71,0,1)`; active-only `(71,70,32,1)`. These are copied schedule contracts checked against handoff literals, not observations or source-order proof. Existing timeout, C/S/I/Z, special-output and work-bound data have not been encoded.

Tests are `test_catalogue.py` and `test_structure.py` in that directory. The latter checks no authored class/assert in the three files and checks importing the catalogue under empty and foreign argv produces no output. This is not a proof of absence of every possible side effect.

## Specific unresolved source issues

* `integration-owned/admission/cases.py:69-74` uses a `while True` polling loop around `metrics()`, and lines 100-105 poll `status()` for the accepted prefix. Thus the fixed number of requests attributed to those barriers is not entailed by this source. Smallest needed correction is to implement and independently review an ordered action/observation barrier with a finite exact request count before adopting the proposed counts. Similar polling in other families needs source-by-source review. No schedule constants were changed to conceal this gap.
* The legacy schema is not one schema: `admission/cases.py:40-43` uses `accepted`, `begin`, `end`, `cancel`, `reason='none'`; `/tmp/uwz-task5d1-round3-current/contracts.py:53-61` uses `bytes`, `begins`, `ends`, `cancels`, `reason=None`, and output-specific metadata. The combined model needs an explicit canonical translation preserving all family fields and observation relationships; dropping these differences would weaken checks. Lifecycle close `expectations.py:13-34` separately specifies pre/post active shutdown, stale operations and causes. This slice does not implement that translation.
* Exact startup serialization, finite replacement barriers, and individual debt and receive ceilings remain unproved; the handoff's aggregate arithmetic does not prove them. Callback chunks and maximum span must remain bounded observations, and producer generation must remain relative. These have not been implemented.

## Source identity and small snapshot

SHA-256:

```text
283006a89793df9dc8fbf8795112fe558da3cb32138c7a1d31e223168372c412  .superpowers/sdd/h2_streaming_plan/task-5e-combined-architecture.md
a37c60213318f1d89f76ec15ed81dfb1ab07ca30ecbba8ca7af32b2793e6580b  .superpowers/sdd/h2_streaming_plan/task-5e-root-arithmetic.json
538954fdd49504c6bc6a972cec0747772314d604bf90bf4eda4252ff6d00c469  .uwz-work/evidence/h2-streaming/integration-owned/admission/cases.py
77897c3ccbe4433641f08283f3556e5ff5543d04f0b137a14c42421e38918388  .uwz-work/evidence/h2-streaming/integration-owned/credit/cases.py
d823af892f7ee77377cdd2d22686971e1cffd1c57788ca924c47efaf4ab53585  .uwz-work/evidence/h2-streaming/integration-owned/metadata/cases.py
63cf5977e0c116da6f6f7cc938eca3f04efd3b24b92c1c3189d2bfc72be74a4a  .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/cases.py
a575f77a54a9a9087f468489b86b53f7911459c58e875c623d8a8a0f590dafa8  .uwz-work/evidence/h2-streaming/integration-owned/application-error/cases.py
33ea092f6e5f67b8cfb8fc61dcab425228f284bf77880b0c96ff537299af8324  .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/expectations.py
bcdad460e8748cc2c5e69a21332a075a9408587238fc4e47f29eac83a98392ce  /tmp/uwz-task5d1-round3-current/contracts.py
```

Read-only copies of the admission and output contract files are `/tmp/uwz-task5e1-source-snapshot/admission_cases.py` and `output_contracts.py`, respectively, with the same hashes. The snapshot is permission-protected, not cryptographically immutable; verify hashes before use.

## Raw test evidence

Initial behavioral RED, before catalogue implementation:

```text
$ /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_catalogue.py
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_catalogue.py", line 1, in <module>
    import catalogue
ModuleNotFoundError: No module named 'catalogue'
exit 1
```

After implementation, independently for each normal and optimized command:

```text
$ /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_catalogue.py
catalogue checks passed
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_catalogue.py
catalogue checks passed
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_structure.py
AST and inert import checks passed
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_structure.py
AST and inert import checks passed
exit 0
```

These tests check the stated arithmetic and rejection examples only. They do not verify all requested expected-state, source, schema, bounded-hash, overflow or work-budget requirements. `-O` here is Python optimization, not a Zig build mode.

# Task 5e1 continuation: independent pure contract model

Status: pure catalogue/model slice implemented and ready for Root's fresh
independent review. The earlier incomplete report and its RED/GREEN evidence
above are preserved as history. No actual combined fixture/client, native
constructor, build, socket/TLS operation, certificate, resource/error/fault probe,
legacy live checker, commit or push was performed. Actual combined40 and the
original goal remain open. No formatter or startup serialization proof is claimed.

## What changed and the concrete model boundary

Owned work remains entirely under the new `integration-owned/combined-contract`
directory, this report, and new task5e1 temporary paths. Preserved and extended
`catalogue.py`, `test_catalogue.py`, `test_structure.py`; added `model.py`,
`test_model.py`, `source_notes.md`. No prior source or public evidence was edited.

The catalogue now derives all per-case S/I/Z/special-output/debt/receive/final/
timeout data using checked u64 addition and multiplication. Full receive ceiling
5288609050, final68 once, partial ending large4768262 and main final3065184 match
independent handoff literals. Legacy 4096 receive/snapshot limits remain separate
from byte work ceilings and must persist across final collection on the same
connection. Disconnect final debt is scoped to its replacement's R32, not R64
from two connections. No debt is required to disappear and no budget was widened.
The frozen code also records zero-DATA/trailer allowances, two-child selections,
finite barrier descriptions and the source-supported policy versus untested
combined action-order distinction.

`model.py` independently encodes all 67 expected bodies, selected-subset defaults,
pre/post shutdown transitions, declarations, accepted prefixes and separate
per-stream SHA values. Full after vector is
`(67,62,61,52,9,200091500,0)` for body heads/attempts/begins/ends/cancels/bytes/active;
before is `(67,62,61,52,8,200091500,1)`. Each family's literal vector and each
single-case mapping are tested. Metadata, pause callback diagnostics, failure
classification, stale controls/sibling immutability, relative generation A->B,
producer algebra and file range/ownership/close-once checks have named contracts.
`metrics` distinguishes main666 from idle69 buffered calls; slot validation
requires exactly one active slot before active shutdown, both inactive after,
without assuming which slot was first.

`COMMON_RECORD` and named family evidence tuples define the proposed canonical
combined record shape. `LEGACY_SCHEMAS` accepts each exact retained raw shape,
strictly checks types (bool cannot serve as a counter), and translates raw
accepted/begin/end/cancel/failure and string none without inventing absent legacy
observations. Every existing raw key must survive that projection. Combined
schema fields that legacy core/pause did not emit are a future formatter contract,
not claimed historical observations. Dynamic chunks/span remain bounded
observations: accepted bytes must fit chunks*span, no fixed packet count, and the
one failed/invalid offer is accounted separately. Hash generation is bounded to
100000000 logical bytes and <=8192-byte chunks; tests verify the fixed large SHA,
producer SHA, file-range SHA and an independent pattern repetition algorithm.
No 100 MB payload is materialized.

Full API/schema/source/budget limitations are documented in the owned
`source_notes.md`; do not infer formatter or wire-order evidence from a pure
record vector. Wire relationships requiring future paired action/observation
proof remain explicitly outside this model: no final headers before pause
resume, Continue wire ordering, strict unwrap+EOF, early 403/8+9/END-before-reset,
credit retirement and startup/primary response grants.

## Source-order handoff and corrected source identity

Root supplied and adopted
`.superpowers/sdd/h2_streaming_plan/task-5e-barrier-source-handoff.md`, SHA256
`da223f000b1d7f9528f48ddc1bf3923f7d1b55889608e7856d2772bfaa25e9ec`.
It resolves the earlier source-order concern without changing J/C or deadlines:
fully serialize/flush the action, enqueue ONE same-connection status/metrics GET,
fail immediately on mismatch, no retry. Continue receives one valid100 before
positive DATA. Disconnect requires successful unwrap AND plain TCP EOF before
replacement+health+one peer_closed status. The source handoff cites synchronous
frame processing, callbacks, resume/drain, reservation release and close-body
notification before native socket close. These are source facts, not measurements.
`finite_barrier_source_supported=True`, `combined_action_order_tested=False`,
`startup_serialization_proved=False` are retained explicit model outputs.

The final review manifests identify corrected immutable source copies; the local
fix1 files were hashed and matched those exact entries. Earlier top-level
admission cases were initial history, not final source authority. Relevant hashes:

```text
3f4698e51a6b20ed92463a8988852bd8fe781c8ebeea547b03c519a99fceb363 admission/fix1/cases.py
  matches /tmp/uwz-task5b2-fix1-frozen/cases.py in review-manifest.json
a9f7149c122939a5a404b20b76733818968379443c4138503112b4cda92f1aa8 admission/fix1/profile.zig
be7110ba4335768fd6a559d2f0a9b0b604091e0d3d6503361163050b18ede7c3 admission/fix1/run_live.py
ffc36badc79a2d245bb5e878d1acb7236928e48ffca806cf00e4550518187d6f pause-control/fix1/profile.zig
ddd7fb5403982a1fa2b056f1c173322f212fd662854749c83502d30a684b83cc pause-control/fix1/run_live.py
  matches /tmp/uwz-task5b1-fix1-frozen in review-manifest.json
77897c3ccbe4433641f08283f3556e5ff5543d04f0b137a14c42421e38918388 credit/fix1/cases.py
a370cb6c5a846ff0f628ebb7e76871f933cd5751249cfcb2d3a3898ebf3ef745 credit/fix1/profile.zig
a69428257d582508dff18972c04ed4bdb22a124b1d12b3e2ede19857bf87d016 credit/fix1/run_live.py
  matches /tmp/uwz-task5b3-fix1-frozen-v2 in review-manifest-v2.json
```

Source-order locators and metadata/helper/producer/file predicate locators are
retained in `source_notes.md` and the original handoff. All 41 exact source/
manifest/helper/Python identities used by this slice are recorded in
`/tmp/uwz-task5e1-proof-v2/source-identities.json`, SHA256
`fa28df15cf14145662a440d7afdcfd776be400cc6418055fbff93243b66f0282`.
The snapshot identity check rehashed those 41 sources successfully. One exploratory
read used the nonexistent historical name `m2_h2_pause_live`; the actual published
directory is `m2_h2_pause_control_live`. A manifest inspection initially attempted
to read an expired historical /tmp source; subsequent inspection matched current
fix1 bytes against manifest entries without treating missing history as evidence.
Neither affected pure checks or changed any source.

## New TDD evidence

The command used for new model RED/GREEN iterations was exactly:

```text
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py
```

Initial RED before model implementation, raw combined stdout/stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 5, in <module>
    import model
ModuleNotFoundError: No module named 'model'
exit 1
```

A behavioral RED (strict normalization), before fixing the permissive bool counter:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 160, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 83, in main
    rejects(lambda: model.normalize_legacy('admission',dict(legacy,attempts=True)))
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 18, in rejects
    raise ValueError('invalid model input accepted')
ValueError: invalid model input accepted
exit 1
```

A later behavioral RED (impossible accepted bytes/chunks/span), before adding the
physical consistency bound:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 177, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 68, in main
    rejects(lambda: model.validate_records(catalogue.CASES,'after',changed))
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 18, in rejects
    raise ValueError('invalid model input accepted')
ValueError: invalid model input accepted
exit 1
```

Review also exposed an omitted declaration on limit_observed_recovery; the added
literal test failed `ValueError: observed rejection recovery declaration` (exit1)
before correcting it to32. Stale-control, output pre/post and metrics-slot tests
first failed with their absent validator AttributeError before implementation.
The finite-barrier test first failed `AttributeError: module 'catalogue' has no
attribute 'finite_barriers'` (exit1) using the exact catalogue command below with
the owned source path. Later GREEN outputs were `model checks passed: records,
transitions, schemas, hashes, budgets, family evidence` and `catalogue checks
passed`, exit0. Final complete frozen-source results follow.

## Final covering commands and raw outcomes

Python is3.14.2. Python `-O` is optimization of Python assertions/bytecode, not a
Zig build optimization mode. All authored proof checks use explicit raises and
remain active in both Python modes. AST checks cover all five new/extended Python
files for ClassDef/Assert; inert import checks cover each under empty and foreign
argv and require no stdout/stderr. This is an import proof for these modules,
not a general proof of absence of every possible side effect.

```text
$ /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5e1-contract-v2/test_catalogue.py
catalogue checks passed
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S -O /tmp/uwz-task5e1-contract-v2/test_catalogue.py
catalogue checks passed
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5e1-contract-v2/test_model.py
model checks passed: records, transitions, schemas, hashes, budgets, family evidence
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S -O /tmp/uwz-task5e1-contract-v2/test_model.py
model checks passed: records, transitions, schemas, hashes, budgets, family evidence
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5e1-contract-v2/test_structure.py
AST and inert import checks passed
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S -O /tmp/uwz-task5e1-contract-v2/test_structure.py
AST and inert import checks passed
exit 0
```

The final raw tool result objects are preserved at
`/tmp/uwz-task5e1-proof-v2/final-tests.json`, SHA256
`b12afb55eb43490ea2550d4c29737650520db8863530868e6d72746383a40880`.
All six final covering commands returned exit0. The tests include malformed
schema/type/hash/counter, bool integer confusion, unknown/duplicate/order,
u64 overflow, invalid budget/debt, default rows, helpers, error/cancel causes,
stale controls, generation reuse, output pre/post immutability and file double
close rejection. Full and partial literal vectors are independent of observed
records; source-derived relationships supplement them. No exception is silently
swallowed and no assertion statement serves as proof.

## Frozen small source snapshot

`/tmp/uwz-task5e1-contract-v2` contains six source/test/notes files,65984 bytes.
Files have mode0444 and directory0555. This is permission protection plus an
immutable SHA identity, not a claim that privileged code cannot change files.
Snapshot and owned work were byte/hash compared after final checks. Inventory:

```text
1c96672c140cf1df867ea90427434554891e7266acbce22ae3c256142abfb1cd catalogue.py 10522
27b74d91b7846b21988f265de7378d142f023923e7070b2501e0428e37bf3f38 model.py 25428
124b90a81a7b27c424d8b972a253a0f66dfa90e7c006f27b6c6c31b3bf3086b5 test_catalogue.py 2222
e29c8522a936df232b08c2bd257c43720658592d1bf32814c3369e0dbf31e136 test_model.py 14366
8d60395e2e81b63158792e542959e7a7175f85d78f61fab2aadd66a48f6ef8ba test_structure.py 1241
87fbe8b527743d15f5c667df9417c2a66205919660716814c5bc71ce7edb44f0 source_notes.md 12205
```

`/tmp/uwz-task5e1-proof-v2/snapshot-identities.json` SHA256
`f45ea676a21b4512b2e392bf0457d5a591ad7a9dbf747586beaab7bdce872c44`.
The actual final source identity command was:

```sh
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import hashlib,json,sys
proof=Path('/tmp/uwz-task5e1-proof-v2')
owned=Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-contract')
snapshot=Path('/tmp/uwz-task5e1-contract-v2')
for row in json.loads((proof/'snapshot-identities.json').read_text()):
    for path in (owned/row['name'],snapshot/row['name']):
        if hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
            raise ValueError('snapshot mismatch: '+str(path))
for row in json.loads((proof/'source-identities.json').read_text()):
    if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:
        raise ValueError('source identity changed: '+row['path'])
print('snapshot equality and all 41 retained source identities passed')
print('Python',sys.version.split()[0],'; -B',sys.dont_write_bytecode,'; -S',bool(sys.flags.no_site))
for name in ('final-tests.json','snapshot-identities.json','source-identities.json'):
    print(hashlib.sha256((proof/name).read_bytes()).hexdigest(),name)
PY
```

Raw combined output, exit0:

```text
snapshot equality and all 41 retained source identities passed
Python 3.14.2 ; -B True ; -S True
b12afb55eb43490ea2550d4c29737650520db8863530868e6d72746383a40880 final-tests.json
f45ea676a21b4512b2e392bf0457d5a591ad7a9dbf747586beaab7bdce872c44 snapshot-identities.json
fa28df15cf14145662a440d7afdcfd776be400cc6418055fbff93243b66f0282 source-identities.json
```

## Concrete remaining boundaries for Root and independent review

* Root must read actual frozen source/evidence and obtain fresh independent
  review before integration. This authoring self-check does not substitute for
  that review.
* The finite barriers now have source-order justification, while actual combined
  serialization/one-GET/fail-closed/Continue/unwrap+EOF ordering tests belong to
  the later client slice. The old polling implementation is not relabeled as
  already implementing those finite barriers.
* Startup serialization bytes/grants and combined formatter 768/1024/prefix64
  and capture65536 bounds remain unproved. Canonical records, metadata/helper
  contracts and read ceilings are preparation interfaces until the new fixture
  and paired client observations implement them.
* New fixture/client/ledgers/closure, exact frozen builds, the fresh idle plus
  main39 execution, all40 receipts and broad local/native/sanitizer/platform/
  fuzz/package/protocol gates remain open. No old source, native or quality gate
  was run as part of this strictly pure task. Graphify was queried for source
  navigation; graph update writes outside this task's owned paths and is left
  to Root integration.

# Task 5e1 fix round 1: all three P2 preservation gaps

Status: all three accepted findings addressed in the pure model, ready for Root
and the same reviewer's scoped re-review. Original history, v2 snapshot and v2
proof files remain preserved. No fixture/client/product/dependency change,
native constructor, build, TLS/socket/descriptor/resource/fault/schedule probe,
legacy entrypoint, subagent, commit or push was performed.

## Accepted review findings, verbatim

1. **Important / P2: Preserve the idle child's existing 4096 read bound.** `.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/catalogue.py:84` omits `shutdown_idle` from `LEGACY_CAPPED_CASES`; lines 121-122 consequently assign it `receive_calls=3109464` and `legacy_receive_cap=None`. The retained credit runner applies the 4096 snapshot bound on every receive at `.uwz-work/evidence/h2-streaming/integration-owned/credit/fix1/run_live.py:188`. Its idle case uses that same reader for health, keeps the same trace at lines 326-333, and uses it again for final statuses and metrics at lines 403-405. Thus an idle connection split across 4097 nonempty reads can remain within the new byte ceiling and pass this new work contract, although the retained reader rejects it. This conflicts with the explicit requirement not to loosen existing 4096 limits and with `source_notes.md:114`'s preservation claim. Include idle in the retained cap policy, preserve its connection-scoped consumption through final collection, and add an independent idle-budget regression checking the 4096 ceiling. This does not require changing J/C/R, deadlines or the byte ceiling.

2. **Important / P2: Encode the required results for the two cases without body tags.** `.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/catalogue.py:6` and line 7 give `ready_buffered` and `async_delayed` only schedule counts and empty tag sets. `model.py:206` accepts only body tags, while the response contract at `model.py:353` accepts only the five special-output tags. No other new contract or source-notes section defines these two cases' results. The retained core runner at `.uwz-work/evidence/h2-streaming/integration-owned/core/run_live.py:141` requires the exact 257-byte echo payload and digest plus unchanged inactive sink totals; line 156 requires `delayed-ok`, length 10 and exactly one `text/plain` content type. A future consumer of the new contract can satisfy all currently modeled records, metrics and schedules while returning a corrupted echo or the wrong delayed response. Those checks are explicit in the architecture's required-result table and the brief requires preserving every existing check. Add named pure request/response and sink-invariance contracts for these cases, with literal payload/hash/header expectations and rejection tests. Actual wire scheduling remains the later client slice.

3. **Important / P2: Preserve the separate binding record's idle/default and post-deinit contract.** `.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/model.py:285` validates selected A-to-B reuse only. `default_outputs` at line 299 returns the three producers and file but no `producer_reuse_next` binding observation, and `validate_output_pre_post` at line 378 cannot compare it. The separate body record for that tag has no binding fields either. Retained `/tmp/uwz-task5d3-runtime-v5/post.py:68` checks the post binding marker, requires it to equal the previously observed binding when selected, and requires `(index,generation)=(0,0)` with no prior binding when unselected. The new model cannot express that unselected default through its existing binding validator: producer and binding generation zero fail its A+1 rule. An idle or subset run can therefore retain a nonzero stale binding while satisfying every new default-output/body validator. Add a named binding observation/default contract and a selection-aware pre/post comparison, covering both unselected zero state and the selected relative generation rule. Preserve exact types and test stale/nonzero idle bindings and changed post bindings. Marker parsing itself can stay in the later runner slice.


## Fixes and new contracts

1. Added shutdown_idle to the inherited 4096 cap policy. Its receive_calls and
   legacy_receive_cap now both equal4096; receive byte ceiling3109464 and all
   J/C/R/deadline data are unchanged. New pure receive_calls_left(case, consumed)
   uses cumulative caller-owned receive consumption, including final collection:
   idle4095 leaves1,4096 leaves0,4097 and bool counters reject. Source trace reuse
   is credit/fix1/run_live.py188,326-333,403-405. The regression first failed the
   literal idle cap comparison before implementation.
2. Added named READY_BUFFERED_REQUEST, ASYNC_DELAYED_REQUEST, CORE_REQUESTS,
   CORE_RESPONSES, CORE_RESPONSE_FIELDS and CORE_SINK_COUNTERS. core_request
   returns caller-owned expected request data. validate_core_response (also used
   by validate_output_response for these two IDs) verifies the exact257-byte echo
   algorithm/hash and delayed-ok10/hash, strict byte/count/terminal types, END,
   no reset/trailers/informationals, exactly one200 status, and exactly one
   case-insensitive text/plain content type for async. It accepts async without
   a middleware header and with an extra retained middleware header. No such
   header is unconditionally required. validate_core_sink requires the named
   core aggregate schema, inactive0 and unchanged before/after u64 counters;
   legitimate nonzero prior completed totals are allowed. No extra observation
   requests or count changes are implied. Source: core/run_live.py104-120,141-161
   and core/profile.zig77-91. Tests use an independent bytes(range251)+bytes(range6)
   echo vector and reject corrupt payload/hash/count/status/content type/header
   multiplicity/terminal state and sink mutation. The first RED was the existing
   response validator refusing a correct buffered response because it had no
   core contract.
3. Added BINDING_OBSERVATION, default_binding and selection-aware
   validate_binding_pre_post. The marker remains separate from the three producer
   and file rows, matching retained post.py's four H2_OUTPUT rows plus H2_BINDING.
   Unselected requires exact tag producer_reuse_next/index0/generation0 and no
   prior observation (None). Selected requires a previously observed B, armed A
   with actual slot0/1 and positive generation, relative A slot/genA+1, and strict
   unchanged B post evidence. validate_reuse_binding now rejects zero-generation
   or out-of-range A identity. validate_output_pre_post requires keyword
   binding_before/binding_after so its complete comparison includes this marker.
   Tests reject nonzero/stale idle state, even zero prior evidence when unselected,
   changed post marker, wrong relative generation, missing selected evidence and
   bool-as-index. Source: retained output post.py68-78 and cases.py46-51. First RED
   demonstrated that generation-zero A plus generation-one B previously passed.

The six-file slice remains cohesive. source_notes.md adds the precise boundaries
and normalization details. No marker parsing, fixture formatter, wire actions or
native behavior is claimed. Existing family schemas, budgets, finite barriers,
all67 state records and previous test expectations remain covered.

## Actual behavioral RED/GREEN evidence

Separate raw result files, including exact command, combined stdout/stderr, exit
status and original tool metadata, are retained in /tmp/uwz-task5e1-proof-v3.
All REDs were captured before the corresponding implementation change. No test
assertion is optimized away. Raw command/output excerpts follow verbatim.

### red-1-idle.json

```text
$ /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_catalogue.py
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_catalogue.py", line 52, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_catalogue.py", line 19, in main
    check(idle['legacy_receive_cap']==4096 and idle['receive_calls']==4096, 'idle inherited 4096 receive cap')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_catalogue.py", line 6, in check
    raise ValueError(message)
ValueError: idle inherited 4096 receive cap
exit 1
```

### green-1-idle.json

```text
$ /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_catalogue.py
catalogue checks passed
exit 0
```

### red-2-core.json

```text
$ /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 209, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 59, in main
    core_cases()
    ~~~~~~~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 35, in core_cases
    model.validate_output_response('ready_buffered',echo)
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/model.py", line 354, in validate_output_response
    require(type(tag) is str and tag in PRODUCERS+('stream_file','early_final_order'), 'output response tag')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/model.py", line 56, in require
    raise ValueError(message)
ValueError: output response tag
exit 1
```

### green-2-core.json

```text
$ /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py
model checks passed: records, transitions, schemas, hashes, budgets, family evidence
exit 0
```

### red-3-binding.json

```text
$ /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 234, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 83, in main
    binding_cases()
    ~~~~~~~~~~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 62, in binding_cases
    rejects(lambda: model.validate_reuse_binding(producer,binding))
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py", line 18, in rejects
    raise ValueError('invalid model input accepted')
ValueError: invalid model input accepted
exit 1
```

### green-3-binding.json

```text
$ /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-contract/test_model.py
model checks passed: records, transitions, schemas, hashes, budgets, family evidence
exit 0
```

## Final six covering commands

Pinned Python3.14.2, -B -S. Normal Python and Python -O are reported separately;
these are not Zig optimization modes. Every command below returned exit0 against
the new frozen v3 snapshot. AST/no-ClassDef/no-Assert and empty/foreign-argv inert
imports cover all five Python files. No unrelated prior component was executed.

```text
$ /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5e1-contract-v3/test_catalogue.py
catalogue checks passed
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S -O /tmp/uwz-task5e1-contract-v3/test_catalogue.py
catalogue checks passed
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5e1-contract-v3/test_model.py
model checks passed: records, transitions, schemas, hashes, budgets, family evidence
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S -O /tmp/uwz-task5e1-contract-v3/test_model.py
model checks passed: records, transitions, schemas, hashes, budgets, family evidence
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5e1-contract-v3/test_structure.py
AST and inert import checks passed
exit 0
$ /home/codespace/.python/current/bin/python3 -B -S -O /tmp/uwz-task5e1-contract-v3/test_structure.py
AST and inert import checks passed
exit 0
```

## New snapshot and source identities

/tmp/uwz-task5e1-contract-v3: six files, 80102 bytes,
files0444/directory0555. Protection plus retained SHA identity does not claim
privileged code cannot modify files. Inventory:

```text
7fa639c9372c8f01002fefba3647b2f82381e798484441d4b46c20d5d732453d catalogue.py 10775
ebb6164c01617045b6120a00977aeae88609053318f89b1891d9ede5c89b8175 model.py 29329
0badcb416c02c2e646a12c9e244a057cb5711facfe47b5faa40a741f9fd2f53c test_catalogue.py 2823
7e9cd2ed78127cb4ab06b83c23ff0a26e902bced8dfbe910f552575ec980d841 test_model.py 19775
8d60395e2e81b63158792e542959e7a7175f85d78f61fab2aadd66a48f6ef8ba test_structure.py 1241
b50028c8404b371b55a091c9842a3258173bfe485575641a64872f7bf4a5e21c source_notes.md 16159
```

All41 retained source hashes were rechecked unchanged. v3 owned/snapshot bytes
match; all six v2 snapshot files and its three proof identities also remain
unchanged. New review-input-identities.json separately records the exact fix
brief and original review. identity-audit.json preserves the actual following
command and raw result, exit0:

```sh
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import hashlib,json,sys
owned=Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-contract')
old_proof=Path('/tmp/uwz-task5e1-proof-v2')
proof=Path('/tmp/uwz-task5e1-proof-v3')
for version in ('v2','v3'):
    inventory=json.loads(Path('/tmp/uwz-task5e1-proof-'+version+'/snapshot-identities.json').read_text())
    for row in inventory:
        snapshot=Path('/tmp/uwz-task5e1-contract-'+version)/row['name']
        if hashlib.sha256(snapshot.read_bytes()).hexdigest()!=row['sha256']:
            raise ValueError('snapshot changed: '+str(snapshot))
        if version=='v3' and (owned/row['name']).read_bytes()!=snapshot.read_bytes():
            raise ValueError('owned snapshot differs: '+row['name'])
for name,expected in (('final-tests.json','b12afb55eb43490ea2550d4c29737650520db8863530868e6d72746383a40880'),('snapshot-identities.json','f45ea676a21b4512b2e392bf0457d5a591ad7a9dbf747586beaab7bdce872c44'),('source-identities.json','fa28df15cf14145662a440d7afdcfd776be400cc6418055fbff93243b66f0282')):
    if hashlib.sha256((old_proof/name).read_bytes()).hexdigest()!=expected:
        raise ValueError('v2 proof changed: '+name)
for filename in ('source-identities.json','review-input-identities.json'):
    for row in json.loads((proof/filename).read_text()):
        if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:
            raise ValueError('source/review identity changed: '+row['path'])
print('v3 six-file owned/snapshot equality passed; v2 six-file snapshot and three proof identities unchanged')
print('all 41 retained sources plus fix brief/review identities passed')
print('Python',sys.version.split()[0],'; -B',sys.dont_write_bytecode,'; -S',bool(sys.flags.no_site))
for path in sorted(proof.glob('*.json')):
    print(hashlib.sha256(path.read_bytes()).hexdigest(),path.name)
PY
```

```text
v3 six-file owned/snapshot equality passed; v2 six-file snapshot and three proof identities unchanged
all 41 retained sources plus fix brief/review identities passed
Python 3.14.2 ; -B True ; -S True
d5a9a9aacd6e96b5f047e568a37c9763a259b5bb5b1f9c15e550d0b15ca615d8 final-tests.json
ab595af2dcc3c0b81e7c03aaba8847224a268e6aeb5bfb1976deb588698062d5 green-1-idle.json
be7e015754e1dfaae383575bbb3d505618c24f279ec05143f594eb97819ed509 green-2-core.json
976aae141f16efdaccff9fc654c6e14a92a74072a5b3e646387da89ea23a59f8 green-3-binding.json
86f32f9bdf98e779e7ec7a5f8c677387b42c9703b577c2282a506d0555a96007 red-1-idle.json
6063418ac7e7e6da55e9ba0a07b5453372739a4f5da054327da022d4ae1323fa red-2-core.json
f5e905eec24cfbb2048287edace7b6e4e461a96268f803da5a1bdecc5d7a7472 red-3-binding.json
995adf431ceeb13d9d2c388f3be0b3da016c77006f3b8fc53d42a0e54554982c review-input-identities.json
c7fd81375bb831da8cc674e218acb8ea47080ee7ef93cf07af628a4d99ce35b9 snapshot-identities.json
fa28df15cf14145662a440d7afdcfd776be400cc6418055fbff93243b66f0282 source-identities.json
exit 0
```

Proof-file SHA256 inventory, including the raw identity audit:

```text
d5a9a9aacd6e96b5f047e568a37c9763a259b5bb5b1f9c15e550d0b15ca615d8 final-tests.json
ab595af2dcc3c0b81e7c03aaba8847224a268e6aeb5bfb1976deb588698062d5 green-1-idle.json
be7e015754e1dfaae383575bbb3d505618c24f279ec05143f594eb97819ed509 green-2-core.json
976aae141f16efdaccff9fc654c6e14a92a74072a5b3e646387da89ea23a59f8 green-3-binding.json
9941208de012e1ff5fb2c5d217c14f60836db3d8fae766fefdd365d6ee7bf306 identity-audit.json
86f32f9bdf98e779e7ec7a5f8c677387b42c9703b577c2282a506d0555a96007 red-1-idle.json
6063418ac7e7e6da55e9ba0a07b5453372739a4f5da054327da022d4ae1323fa red-2-core.json
f5e905eec24cfbb2048287edace7b6e4e461a96268f803da5a1bdecc5d7a7472 red-3-binding.json
995adf431ceeb13d9d2c388f3be0b3da016c77006f3b8fc53d42a0e54554982c review-input-identities.json
c7fd81375bb831da8cc674e218acb8ea47080ee7ef93cf07af628a4d99ce35b9 snapshot-identities.json
fa28df15cf14145662a440d7afdcfd776be400cc6418055fbff93243b66f0282 source-identities.json
```

## Remaining scope

Root must read the actual fix/report/proofs before the original reviewer's
scoped re-review. Actual startup serialization/grants, combined formatter and
capture bounds, paired action/observation ordering, fixture/client/ledger/closure
integration, exact frozen builds and fresh two-child all40 execution remain later
work. Broad native/project/compliance/sanitizer/platform/fuzz/package gates and
original milestone completion remain open. Graph update remains Root integration
work outside this task's owned paths. This fix round makes no new native or
full40 completion claim.
