# Task5e1 continuation after implementer capacity error

Read original task-5e1-contract-brief.md and actual task-5e1-report.md, then inspect
the existing three owned catalogue/test files. The prior implementer ended with
an authoritative model-capacity error; it did not complete the task. Preserve
its code/report/initial RED and normal/O results; extend rather than restart.
Same original scope, ownership and no-native/build/fixture/driver boundary.
Root assigns a different standard coding model because capacity failed, not
because an observation timeout expired. No agents/commits/pushes.

Main missing work: independent67-record expected-state and per-family evidence
model, strict validation and bounded hashes; per-case S/I/Z/special/debt/receive/
final/timeout bounds and source notes. The existing catalogue only implements
proposed J/C/R/K counts and selection arithmetic; do not pass that off as full
Task5e1 or repeat its tests as the only new work. Complete the remaining model
and meaningful focused proof within original requirements. Canonical translation
between rawaccepted/begin/end/cancel and normalizedbytes/begins/ends/cancels,
stringnone/None is an implementation boundary, not an unanswerable requirement.
Use an explicit named common record contract and named family-specific evidence
contracts; preserve every old helper/control/metadata/cause check. A combined
fixture format is not yet implemented, so choose/document its model boundary
without claiming formatter or runtime proof. No classes or assertion statements.

Root is obtaining a separate focused read-only source-order handoff for legacy
polling barriers from the original combined architect. Continue expected-state/
schema/budget/pure work independently; don't stop at the catalogue because old
polls exist. Keep J/C schedule assumptions visibly provisional until the source
ordering handoff is integrated; no fabricated source proof or arbitrary new
traffic/deadline/cap changes. Ask Root about exact source conflicts, but no user
permission questions for routine data-model choices. If the handoff is needed
at final readiness, state that concrete remaining item while completing every
independent requirement first.

Keep files cohesive and minimal; avoid a framework or dozens of one-function
modules. New output stays in originalcombined-contract/new/tmp/uwz-task5e1-*;
append progress/final report at same task-5e1-report.md, preservehistory and
recordactual covering commands/rawstdout/stderr/exits normal and-O with -B -S.
Root reads actual source/evidence before fresh task review. All prior native
proof/source/components remain immutable; fullgoal andactualcombined40 open.
