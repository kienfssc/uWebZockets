# Task5e1: combined H2 catalogue and independent expected-state model

Read this first; these are requirements. Implement the first ordered preparation
slice from task-5e-combined-architecture.md beside this brief. That saved original
architect handoff is the numerical/scheduling contract; read it next, along with
task-5e-root-arithmetic.json. Do not repeat architecture or native output work.
The five outputs now passed/are published in commit2e1573d; architecture wording
that calls them in progress is historical. The actual combined40 is still unrun.

## Ownership and execution boundary

Own only NEW
`.uwz-work/evidence/h2-streaming/integration-owned/combined-contract/`, new
`/tmp/uwz-task5e1-*`, and task-5e1-report.md in this plan workspace. Target a
small cohesive catalogue/model plus focused tests and source notes, roughly
three/four files. You are not alone; preserve others' changes and all prior
artifacts. No subagents, external model CLI, commits/pushes, product/dependency/
pin/ref edits, fixture/driver/core12 changes or public evidence edits. Root owns
independent review, publication and later exact build/runtime releases.

Allowed: source/evidence reads, standard hashing, pure caller-owned expected data,
AST/inert imports and new pure Python tests. No native constructor/test/binary/
server/socket/SSLContext/file-descriptor/kernel/resource/error/fault/schedule/
interleaving/race/panic/crash/leak probe; no compiler build, certificate/transfer
file creation, old live script/checker entrypoint or full project/native suite.
Do not execute legacy fixture constructors or tests while reading their evidence.
No native/full40 release is implied by this model task.

Follow AGENTS/CODING and narrow applicable planning/TDD/verification skills.
No authored classes/inheritance (including test/exception classes), no Python
assert proof statements, hidden mutable state, global mutable model, forwarding
layers or speculative framework. Named functions, explicit caller-owned data,
strict types, guard clauses and active checks under -O. Main guards/inert imports
under empty/foreign argv. No emojis/new marker comments or silenced errors.

Graphify before new source questions:
`env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650`.
Provided paths and earlier located source lines may be read directly.

## Actual retained sources

Immutable production candidate /tmp/uwz-task4d-fix1-frozen (1031files,
fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de),
override /tmp/uwz-reviewed-libxev-c223-loop-callbacks (93files). No changes.
Original fixture/model/runner sources live under
`.uwz-work/evidence/h2-streaming/integration-owned/` in these existing dirs:
- core: profile.zig/run_live.py/wire.py.
- pause-control: profile.zig/run_live.py/wire.py.
- admission: profile.zig/cases.py/run_live.py/wire.py.
- credit: profile.zig/cases.py/flow_ledger.py/run_live.py.
- metadata: profile.zig/cases.py/run_live.py.
- lifecycle-control: profile.zig/cases.py/run_live.py.
- application-error: profile.zig/cases.py/run_live.py.
- lifecycle-close: profile.zig/expectations.py/lifecycle_cases.py/runner_adapter.py.
Their published docs/evidence are under docs/implement-2-2-0/m2_h2_* and matching
evidence dirs. Retained /tmp/uwz-task5c3-runtime-v2 contains nine reviewed files,
including expectations.py/lifecycle_cases.py, strict_close.py and runner_adapter.
Old modules may have inherited class-based tests; read them as history, do not
copy authored classes into this new model.

Current output contracts /tmp/uwz-task5d1-round3-current/contracts.py and its
derived-contracts.md are immutable. Current 19-file output runtime is
/tmp/uwz-task5d3-runtime-v5; current fixture /tmp/uwz-task5d2-fix2-final-snapshot.
Their exact source archive is docs/implement-2-2-0/evidence/m2_h2_output_driver/
output-driver.tar.gz SHA6ebc819a8407f43b8b9aafd26b0fe5c52f4345c43e30b32584f8eb896d4544dd.
New native five-case proof is m2_h2_output_live.md, archivefe24a8cd...; read-only.
Pinned independent client helper .uwz-work/evidence/h2-streaming/integration-client/
h2_client.py SHA07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00.
Python /home/codespace/.python/current/bin/python3,3.14.2; -B -S for new checks.

## Required catalogue, model and bounds

1. Encode all40 case IDs and exact67 body tags from the handoff, with explicit
   case-to-tag mapping, per-case J/C/R/K/S/I/Z/special-output/timeout data and
   two-child topology. Full idle baseline child first, then39 main IDs ending
   shutdown_active; disconnect has a replacement connection. Do not count a
   retained checkpoint as an execution or silently sort invalid caller order.
   Reject duplicate/unknown IDs and invalid active-shutdown ordering. Define
   partial selection behavior explicitly: idle-only is its own first child;
   active subset without shutdown_active gets one final68 collection and
   ordinary idle teardown without earning shutdown_idle ID. No double final68.

2. Independent expected records/totals for every selection, both pre/post active
   shutdown. Preserve actual callback, declaration, pause/EOF, failure/cancel
   causes, accepted prefixes/hashes, quotas, controls, metadata and recovery
   contracts from retained source. Common body counters are not enough to erase
   family-specific checks: encode named required evidence/schema/relationships
   for pause callback checks, helpers/allocator/captures, stale controls and
   producer/file observations. Successful-begin counts differ from failed-begin
   attempts. End invocations include the end_error; no duplicate cancel there.
   Callback chunk counts/max spans are bounded observations, not fixed packet
   counts. Output reuse generation is relative A->B, not always initially1.
   Exact defaults for all unselected records and idle child are required.
   Document the concrete canonical field contract with source/hash locators;
   if legacy fixture schemas differ, resolve the model boundary explicitly,
   preserving every existing check rather than discarding extras. Combined
   formatter does not yet exist; do not claim its 768/1024/prefix64 bounds proved.

3. Derive exact full/partial request counts, accepted totals and conservative
   receive/final work bounds using checked u64 arithmetic and per-case declared
   bounds. Never relabel current output R65/final33/32-record constants as full
   scope, loosen a legacy4096receive limit, or return an unrestricted number.
   Planned full totals: main733heads/720small/R200091899, idle69heads/small,
   full802heads/789small, body67heads/62attempts/61successfulbegins/52ends/9cancels/
   accepted200091500. Before active shutdown cancel8/one active paused; afterwards
   cancel9/neither slot active. Main buffered666/idle69. The table values are
   source schedule contracts, not observed traffic. Use the handoff's formula,
   per-case caps/large180s, startup SETTINGS omissions, debt scope and final68
   rules. Newly enumerated finite status barriers require actual source-order
   justification. If a count/barrier cannot be justified, report the exact
   source fact and smallest correction before pretending the table is proved;
   do not infer it merely from arithmetic or tests of copied constants.

4. Prove through meaningful pure tests: exact inventory/cardinality/unique
   mapping/full totals/idle and partial/subset/prepost transitions; representative
   failure, pause, metadata, control and late-debt semantics; reject unknowns,
   duplicates, wrong order/type/hash/counter/schema, overflow/invalid budget
   inputs. Use independent literal totals/vectors/second algorithms and actual
   source-derived relationships; do not just mirror the implementation. Large
   logical hashes use bounded chunks, not100MB allocations. Preserve original
   payload algorithms/sentinels and per-stream expected hashes (large SHA190f...);
   do not substitute one concatenated hash. No wall-clock/host/native dependency
   in model computation or tests. Initial behavioral RED then GREEN, raw commands/
   stdout/stderr/exits retained. Run new focused checks normal and -O with pinned
   Python -B -S; AST/noClass/noAssert and inert import proof for new modules.

Deliver complete catalogue/model/tests/source-notes slice, immutable small source
snapshot/hash inventory and full task-5e1-report.md with exact commands/raw results,
API/model contracts, arithmetic, source identities, assumptions and unresolved
facts. Do not implement the combined fixture, protocol ledgers, runner or closure
in this task. Do not claim the full40 run, formatter, builds, native gates,
milestone or original goal complete. Root reads actual work before fresh task
review; no permission question for routine reversible implementation choices.
