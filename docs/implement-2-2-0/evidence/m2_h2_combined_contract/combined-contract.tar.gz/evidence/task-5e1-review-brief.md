# Task5e1 independent source/model review

Read task-5e1-contract-brief.md first, then task-5e1-resume-brief.md,
task-5e1-report.md (including the superseding completed continuation),
task-5e-combined-architecture.md and task-5e-barrier-source-handoff.md.
The original Terra implementer terminally failed at capacity; the replacement
Sol/high completed the same scope. This is a fresh task review, not a repeat of
the prior output-driver review. Root has read the six files, full current
report and six actual final results, verified all six owned/snapshot identities
and all41 retained source hashes. Root audit: task-5e1-root-audit.json.

Base and current HEAD are both 2e1573d31bc7734e8fbcb7403381cdb0e2026ab7.
All six files are new ignored preparation files, represented in full by
task-5e1-review.diff (67828 bytes, SHA256
5f6b5ec4e0a3ee1bf23f350fe5cef71f560e2f1abea7865937d5c73ba2c347f4).
Read that diff once as the changed-file source; source identities/paths are in
task-5e1-review-source.json. The immutable six-file snapshot is
/tmp/uwz-task5e1-contract-v2. Do not re-read changed files separately unless a
diff hunk is incomplete. Source_notes.md is included in the diff.

Apply .codex/agents/reviewer.toml, AGENTS.md, CODING_CONVENTION.md,
.agents/skills/code-review-and-quality/SKILL.md and the structural lens in
.agents/skills/thermo-nuclear-code-quality-review/SKILL.md (Root expressly
requests this scoped structural pass; project overrides apply). Use the
superpowers task-reviewer-prompt.md method. No subagents or external model CLI.
Review source and retained evidence only; do not rerun passing tests, imports,
old entrypoints, constructors, builds or native/socket/TLS/descriptor/error/
fault/schedule/race/kernel/resource/panic/leak experiments. No product edits,
Git/index/ref operations or public evidence edits. You may write only your
review report at task-5e1-review.md in this plan directory.

Binding requirements are all of the original brief, in particular:
"No authored classes/inheritance (including test/exception classes), no Python
assert proof statements, hidden mutable state, global mutable model, forwarding
layers or speculative framework. Named functions, explicit caller-owned data,
strict types, guard clauses and active checks under -O. Main guards/inert imports
under empty/foreign argv. No emojis/new marker comments or silenced errors."
"Common body counters are not enough to erase family-specific checks"
and "preserving every existing check rather than discarding extras."
Full67/62/61/52/9/200091500, pre cancel8/active1, main666/idle69;
40 case IDs with67 tags, caller-order/two-child/subset semantics, bounded separate
hashes, checked u64 receive/debt/final bounds, family metadata/helpers/causes,
stale controls/sibling and producer/file relationships must be evaluated.
Combined formatter, actual startup serialization, later paired client ordering,
builds and combined40 native execution are later slices: inspect whether the
current contract preserves their required interfaces and states its limits.
Do not infer completion of those slices from this source model.

Raw final GREEN results are /tmp/uwz-task5e1-proof-v2/final-tests.json;
the behavioral RED text is retained in the report, not in separate tool-result
files in that directory. Identities: snapshot-identities.json/source-identities.json.
Name any concrete risk before a focused unchanged-source read. Provided source
locators may be read; before a new codebase question use graphify:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650

Return both explicit SPEC and QUALITY verdicts, actionable severity/file:line/
trigger/fix findings, structural conclusion and exact verification limits.
Persist full report at task-5e1-review.md; final message only verdicts, report
path and concise finding count. No review may imply original milestone or
full40 native completion.
