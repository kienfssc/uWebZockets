import catalogue


def check(condition, message):
    if not condition:
        raise ValueError(message)


def rejects(call):
    try:
        call()
    except ValueError:
        return
    raise ValueError('invalid input accepted')


def main():
    cases = catalogue.CASES
    check(len(cases) == 40 and len(set(cases)) == 40, 'case inventory')
    check(cases[0] == 'shutdown_idle' and cases[-1] == 'shutdown_active', 'topology')
    tags = [tag for case in cases for tag in catalogue.TAGS[case]]
    check(len(tags) == 67 and len(set(tags)) == 67, 'tag inventory')
    totals = catalogue.schedule(cases)
    check(totals == (802, 789, 200091899, 41), 'full schedule')
    check(catalogue.schedule(('shutdown_idle',)) == (69, 69, 0, 1), 'idle')
    check(catalogue.schedule(('empty_headers',)) == (71, 71, 0, 1), 'partial final')
    check(catalogue.schedule(('shutdown_active',)) == (71, 70, 32, 1), 'no double final')
    rejects(lambda: catalogue.schedule(('unknown',)))
    rejects(lambda: catalogue.schedule(('empty_headers', 'empty_headers')))
    rejects(lambda: catalogue.schedule(('shutdown_active', 'empty_headers')))
    rejects(lambda: catalogue.schedule(('empty_headers', 'shutdown_idle')))
    rejects(lambda: catalogue.schedule('empty_headers'))
    check(catalogue.schedule(('empty_data', 'empty_headers')) == (74, 74, 0, 2), 'caller order')
    rejects(lambda: catalogue.add_u64((1 << 64) - 1, 1))
    rejects(lambda: catalogue.add_u64(True, 1))
    check(len(catalogue.finite_barriers('quota_refuse'))==4, 'four exact quota barriers')
    check(catalogue.finite_barriers('partial_pause')[1][1]=='same_record_as_first', 'queued EOF is unchanged')
    check(catalogue.barrier_policy('continue_ready')['before_positive_data']=='receive_single_100', 'Continue prerequisite')
    check(catalogue.barrier_policy('disconnect')['before_replacement']==('ssl_unwrap_success','plain_tcp_eof'), 'disconnect completion boundary')
    check(catalogue.budgets(cases)['finite_barrier_source_supported'] is True and catalogue.budgets(cases)['combined_action_order_tested'] is False, 'source and future implementation evidence separated')
    print('catalogue checks passed')


if __name__ == '__main__':
    main()
