"""Proposed scheduling catalogue; numerical contracts are not execution evidence."""

# Rows are (case, request heads, small responses, outgoing DATA flow, connections, tags).
ROWS = (
    ('shutdown_idle',69,69,0,1,()),
    ('ready_buffered',5,5,257,1,()),
    ('async_delayed',3,3,0,1,()),
    ('large_declared',5,5,100000000,1,('large_declared',)),
    ('large_undeclared',5,5,100000000,1,('large_undeclared',)),
    ('partial_pause',7,7,12289,1,('partial_pause',)),
    ('final_pause',6,6,32,1,('final_pause',)),
    ('begin_pause_empty',6,6,0,1,('begin_pause_empty',)),
    ('control_rules',20,20,64,1,('control_one','control_two')),
    ('empty_headers',3,3,0,1,('empty_headers',)),
    ('empty_data',3,3,0,1,('empty_data',)),
    ('empty_declared',3,3,0,1,('empty_declared',)),
    ('limit_declared',3,3,32,1,('limit_declared',)),
    ('limit_undeclared',3,3,32,1,('limit_undeclared',)),
    ('limit_declared_reject',4,4,32,1,('limit_declared_reject','limit_declared_recovery')),
    ('limit_observed_reject',5,5,65,1,('limit_observed_reject','limit_observed_recovery')),
    ('zero_declared_reject',4,4,0,1,('zero_declared_reject','zero_declared_recovery')),
    ('zero_observed_reject',4,4,1,1,('zero_observed_reject','zero_observed_recovery')),
    ('continue_ready',3,3,32,1,('continue_ready',)),
    ('continue_paused',5,5,32,1,('continue_paused',)),
    ('quota_refuse',11,11,128,1,('quota_holder_one','quota_holder_two','quota_refuse','quota_recovery_one','quota_recovery_two')),
    ('begin_failure_rollback',4,4,32,1,('begin_failure','begin_recovery')),
    ('queued_trailers_padding',6,6,12297,1,('queued_trailers_padding',)),
    ('receive_credit',7,7,65536,1,('receive_credit',)),
    ('concurrent_routes',13,13,96,1,('concurrent_hold','concurrent_refused','concurrent_upload','concurrent_recovery')),
    ('metadata_helpers',6,6,32,1,('metadata_helpers',)),
    ('cancel_ready',12,11,40,1,('cancel_ready','cancel_ready_recovery')),
    ('cancel_paused',12,11,65,1,('cancel_paused','cancel_paused_recovery')),
    ('peer_reset',11,10,65,1,('peer_reset','peer_reset_recovery')),
    ('sink_error',11,10,48,1,('sink_error','sink_error_recovery')),
    ('invalid_progress',11,10,48,1,('invalid_progress','invalid_progress_recovery')),
    ('end_error',10,9,65,1,('end_error','end_error_recovery')),
    ('disconnect',25,24,64,2,('disconnect','disconnect_recovery')),
    ('reuse',389,389,288,1,tuple('reuse_%d' % n for n in range(9))),
    ('producer_reuse',9,8,64,1,('producer_reuse','producer_reuse_next')),
    ('output_pressure_window',8,7,33,1,('output_pressure_window',)),
    ('output_pressure_ready',6,5,33,1,('output_pressure_ready',)),
    ('stream_file',7,6,33,1,('stream_file',)),
    ('early_final_order',7,6,32,1,('early_final_order','early_final_recovery')),
    ('shutdown_active',71,70,32,1,('shutdown_active',)),
)
CASES = tuple(row[0] for row in ROWS)
from types import MappingProxyType

TAGS = MappingProxyType({row[0]: row[5] for row in ROWS})
U64 = (1 << 64) - 1


def add_u64(a, b):
    if type(a) is not int or type(b) is not int or a < 0 or b < 0 or a > U64 - b:
        raise ValueError('u64 overflow or invalid input')
    return a + b


def schedule(selection):
    if type(selection) not in (tuple, list):
        raise ValueError('case IDs must be a sequence')
    seen = set()
    for index, case in enumerate(selection):
        if type(case) is not str or case not in TAGS or case in seen:
            raise ValueError('unknown or duplicate case')
        if case == 'shutdown_idle' and index != 0:
            raise ValueError('idle child must be first')
        if case == 'shutdown_active' and index != len(selection) - 1:
            raise ValueError('active shutdown must be last')
        seen.add(case)
    result = [0, 0, 0, 0]
    for case in selection:
        row = ROWS[CASES.index(case)]
        for index, value in enumerate(row[1:5]):
            result[index] = add_u64(result[index], value)
    if seen - {'shutdown_idle'} and 'shutdown_active' not in seen:
        result[0] = add_u64(result[0], 68)
        result[1] = add_u64(result[1], 68)
    return tuple(result)


RESET_CASES = frozenset(('limit_declared_reject','limit_observed_reject','zero_declared_reject','zero_observed_reject','quota_refuse','begin_failure_rollback','concurrent_routes','cancel_ready','cancel_paused','sink_error','invalid_progress','end_error','early_final_order'))
OUTPUT_CASES = frozenset(('producer_reuse','output_pressure_window','output_pressure_ready','stream_file','early_final_order'))
LEGACY_CAPPED_CASES = frozenset(('queued_trailers_padding','receive_credit','concurrent_routes','metadata_helpers','cancel_ready','cancel_paused','peer_reset','sink_error','invalid_progress','end_error','disconnect','reuse','shutdown_active'))
SPECIAL_WIRE = MappingProxyType(dict(producer_reuse=16799868,output_pressure_window=16799868,output_pressure_ready=16799868,stream_file=250044,early_final_order=4140))


def mul_u64(a: int, b: int) -> int:
    add_u64(a,0)
    add_u64(b,0)
    if b and a > U64 // b:
        raise ValueError('u64 multiplication overflow')
    return a*b


def receive_bound(c: int, special: int, k: int, s: int, r: int, i: int, z: int) -> int:
    result = 0
    for multiplier, value in ((45064,c),(1,special),(39,k),(9,s),(26,r),(4105,i),(13,z)):
        result = add_u64(result,mul_u64(multiplier,value))
    return result


def final_budget(remaining_debt: int) -> int:
    add_u64(remaining_debt,0)
    if remaining_debt>131070:
        raise ValueError('final debt exceeds two request scopes')
    return add_u64(mul_u64(45064,68),mul_u64(13,remaining_debt))


def case_budget(case: str) -> dict:
    if type(case) is not str or case not in TAGS:
        raise ValueError('unknown case budget')
    _, j, c, r, k, _ = ROWS[CASES.index(case)]
    s = 2 if case in OUTPUT_CASES or case=='disconnect' else 1
    i = int(case in ('continue_ready','continue_paused'))
    z = int(case in RESET_CASES)
    special = SPECIAL_WIRE.get(case,0)
    last_flow = 32 if case=='disconnect' else r
    scope_debt = min(last_flow,65535)
    byte_bound = receive_bound(c,special,k,s,r,i,z)
    receive_cap = min(byte_bound,4096) if case in LEGACY_CAPPED_CASES else byte_bound
    return dict(case=case,receive_calls=receive_cap,final_receive_bytes=final_budget(mul_u64(2,scope_debt)),heads=j,small=c,request_flow=r,connections=k,settings=s,informationals=i,resets=z,special_output=special,timeout_seconds=180 if case in ('large_declared','large_undeclared') else 30,connection_debt=scope_debt,stream_debt_total=scope_debt,refund_frames=mul_u64(2,r),receive_bytes=receive_bound(c,special,k,s,r,i,z),legacy_receive_cap=4096 if case in LEGACY_CAPPED_CASES else None,final_included=case in ('shutdown_idle','shutdown_active'),positive_data_frames=r,zero_data_frames=int(case in ('begin_pause_empty','empty_data')),trailers_allowed=case in ('queued_trailers_padding','metadata_helpers'),header_block_bytes=8192,data_span_bytes=8192)


def budgets(selection: tuple | list) -> dict:
    heads, small, flow, connections = schedule(selection)
    total = 0
    refund_frames = 0
    final_collections = 0
    main = [case for case in selection if case!='shutdown_idle']
    for case in selection:
        item = case_budget(case)
        total = add_u64(total,item['receive_bytes'])
        refund_frames = add_u64(refund_frames,item['refund_frames'])
        final_collections += int(item['final_included'])
    final_debt = 0
    if main:
        final_debt = mul_u64(2,case_budget(main[-1])['connection_debt'])
        if main[-1]!='shutdown_active':
            total = add_u64(total,final_budget(final_debt))
            final_collections += 1
    return dict(heads=heads,small=small,request_flow=flow,connections=connections,children=int('shutdown_idle' in selection)+int(bool(main)),receive_bytes=total,refund_frames=refund_frames,final_collections=final_collections,final_remaining_debt=final_debt,ready_timeout_seconds=15,whole_timeout_seconds=900,grace_timeout_seconds=15,finite_barrier_source_supported=True,combined_action_order_tested=False,startup_serialization_proved=False)


def child_plan(selection: tuple | list) -> tuple:
    schedule(selection)
    idle = (('shutdown_idle',),) if 'shutdown_idle' in selection else ()
    main = tuple(case for case in selection if case!='shutdown_idle')
    return idle+((main,) if main else ())


FINITE_BARRIERS = MappingProxyType({
    'quota_refuse': (('both_holder_headers','metrics_active_2'),('both_holder_ends_and_finals','metrics_active_0'),('both_recovery_headers','metrics_active_2'),('both_recovery_ends_and_finals','metrics_active_0')),
    'limit_observed_reject': (('unpadded_32_no_end','accepted_32_ready_active_no_end_no_cancel'),),
    'partial_pause': (('first_8192','accepted_7_paused'),('remaining_4097_end','same_record_as_first')),
    'final_pause': (('p32_end','accepted_32_paused_no_end_callback'),),
    'begin_pause_empty': (('headers_then_empty_data_end','begun_paused_no_chunks_no_end'),),
    'continue_paused': (('single_100_then_p32_end','accepted_0_paused_no_chunks_no_end'),),
    'queued_trailers_padding': (('first_8192','accepted_7_paused'),('padded_4097_then_trailer_end','same_record_as_first')),
    'receive_credit': (('send_65535_then_health','accepted_0_paused_no_chunks'),('resume_response','accepted_65535_ready_no_end')),
    'concurrent_routes': (('holder_data_16','accepted_0_paused'),('other_route_headers','metrics_active_2'),('other_route_completed','holder_unchanged'),('holder_resume_response','accepted_16_ready_no_end')),
    'metadata_helpers': (('data_16','accepted_0_paused_no_chunks'),('data_16_then_trailers_end','same_record_as_first')),
    'disconnect': (('original_data_32','accepted_7_paused'),('unwrap_success_tcp_eof_then_replacement_health','cancel_1_end_0_peer_closed_inactive')),
    'shutdown_active': (('data_32','accepted_7_paused'),('before_signal','all_67_statuses_and_one_metrics')),
})


def finite_barriers(case: str) -> tuple:
    case_budget(case)
    return FINITE_BARRIERS.get(case,())


def barrier_policy(case: str) -> dict:
    case_budget(case)
    return dict(flush_before_observation=True,same_connection=True,observation_requests=1,retry_requests=0,mismatch='fail_immediately',before_positive_data='receive_single_100' if case in ('continue_ready','continue_paused') else None,before_replacement=('ssl_unwrap_success','plain_tcp_eof') if case=='disconnect' else (),refund_wait_adds_heads=0,observations_after_shutdown_signal=0)
