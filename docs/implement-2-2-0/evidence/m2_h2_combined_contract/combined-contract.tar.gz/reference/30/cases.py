"""Output case schedules over the caller-owned protocol adapter."""
import hashlib
import contracts
import diagnostics
import records


def require(condition, message):
    if not condition:
        raise ValueError(message)


def body_complete(raw, tag):
    actual = records.normalize(raw)
    expected = contracts.record(tag, {tag})
    for key, value in expected.items():
        if key in ('chunks', 'max_span') and value is None:
            require(type(actual[key]) is int and actual[key] >= 1 and
                    (key != 'max_span' or actual[key] <= 32), 'body callback span')
        else:
            require(type(actual[key]) is type(value) and actual[key] == value, 'body status: ' + key)


def completed(result, length, digest, reset=False):
    require(result['bytes'] == length and result['sha256'] == digest and
            result['end'] is True and result['reset'] is reset, 'response completion')
    require('body' not in result, 'hash-only response retained body')


def producer_reuse(api):
    a = api['start_upload']('producer_reuse', 3, mode='producer')
    api['send'](a, contracts.P32, True)
    body_complete(api['body_status']('producer_reuse'), 'producer_reuse')
    before = api['output_status']('producer_reuse')
    diagnostics.producer(before, 'producer_reuse', 0, held=True)
    checkpoint(api, a, 0, contracts.EMPTY_HASH)
    b = api['start_upload']('producer_reuse_next', 9, mode='small')
    api['send'](b, contracts.P32, True)
    b_response = api['finish'](b)
    body_complete(records.parse_json(b_response['body']), 'producer_reuse_next')
    held = api['output_status']('producer_reuse')
    diagnostics.producer(held, 'producer_reuse', 0, held=True)
    diagnostics.progress(before, held)
    checkpoint(api, a, 0, contracts.EMPTY_HASH)
    binding = api['output_status']('producer_reuse_next')
    require(type(binding) is dict and binding.keys() == {'tag', 'binding_index', 'binding_generation'} and
            binding['tag'] == 'producer_reuse_next' and type(binding['binding_index']) is int and
            type(binding['binding_generation']) is int and binding['binding_index'] == before['binding_index'] and
            binding['binding_generation'] == before['binding_generation'] + 1 and
            held['binding_index'] == before['binding_index'] and
            held['binding_generation'] == before['binding_generation'], 'reuse binding mismatch')
    api['grant'](a, contracts.TOTAL)
    completed(api['finish'](a), contracts.TOTAL, contracts.PRODUCER_HASH)
    final = api['output_status']('producer_reuse')
    diagnostics.producer(final, 'producer_reuse', contracts.TOTAL, after_reuse=True)
    diagnostics.progress(held, final)
    api['health']()
    return binding['binding_index'], binding['binding_generation']


def output_pressure_window(api):
    echo = api['start_echo'](3)
    primary = api['start_upload']('output_pressure_window', 5, mode='producer')
    api['send'](primary, contracts.P32, True)
    body_complete(api['body_status']('output_pressure_window'), 'output_pressure_window')
    held = api['output_status']('output_pressure_window')
    diagnostics.producer(held, 'output_pressure_window', 0, held=True)
    checkpoint(api, primary, 0, contracts.EMPTY_HASH)
    api['send'](echo, b's', True)
    require(api['finish'](echo)['body'] == b's', 'echo response differs')
    api['grant'](primary, 8192)
    prefix = api['checkpoint'](primary, 8192)
    require(prefix['bytes'] == 8192 and prefix['sha256'] == contracts.digest(contracts.TOTAL, 0, 8192) and
            prefix['end'] is False and prefix['reset'] is False, 'producer prefix differs')
    prefix_status = api['output_status']('output_pressure_window')
    diagnostics.producer(prefix_status, 'output_pressure_window', 8192, held=True)
    diagnostics.progress(held, prefix_status)
    api['grant'](primary, contracts.TOTAL - 8192)
    completed(api['finish'](primary), contracts.TOTAL, contracts.PRODUCER_HASH)
    final = api['output_status']('output_pressure_window')
    diagnostics.producer(final, 'output_pressure_window', contracts.TOTAL)
    diagnostics.progress(prefix_status, final)
    api['health']()


def early_final_order(api):
    holder = api['start_upload']('early_final_recovery', 3, mode='small')
    active = records.normalize(api['body_status']('early_final_recovery'))
    expected = contracts.record('early_final_recovery', {'early_final_recovery'})
    expected.update(bytes=0, sha256=contracts.EMPTY_HASH, chunks=0, max_span=0, ends=0,
                    metadata_end=0, active=True)
    require(active == expected, 'holder admission differs')
    refusal = api['start_upload']('early_final_order', 7, mode='early')
    headers = api['headers'](refusal)
    require(headers == {'status': 403, 'informationals': 0, 'bytes': 0, 'end': False, 'reset': False},
            'early response headers differ')
    body_complete(api['body_status']('early_final_order'), 'early_final_order')
    api['grant'](refusal, 8)
    prefix = api['checkpoint'](refusal, 8)
    require(prefix['bytes'] == 8 and prefix['sha256'] == hashlib.sha256(b'early-fi').hexdigest() and
            prefix['end'] is False and prefix['reset'] is False, 'early response prefix differs')
    body_complete(api['body_status']('early_final_order'), 'early_final_order')
    api['grant'](refusal, 9)
    completed(api['finish'](refusal), 17, contracts.EARLY_HASH, reset=True)
    api['send'](holder, contracts.P32, True)
    body_complete(records.parse_json(api['finish'](holder)['body']), 'early_final_recovery')
    api['health']()


def checkpoint(api, stream, size, digest):
    value = api['checkpoint'](stream, size)
    require(value['bytes'] == size and value['sha256'] == digest and
            value['end'] is False and value['reset'] is False, 'held response checkpoint')


def output_pressure_ready(api):
    echo = api['start_echo'](3)
    primary = api['start_upload']('output_pressure_ready', 5, mode='producer')
    api['send'](primary, contracts.P32, True)
    api['send'](echo, b's', True)
    echo_result, output_result = api['finish_pair'](echo, primary)
    require(echo_result['body'] == b's', 'echo response differs')
    completed(output_result, contracts.TOTAL, contracts.PRODUCER_HASH)
    body_complete(api['body_status']('output_pressure_ready'), 'output_pressure_ready')
    diagnostics.producer(api['output_status']('output_pressure_ready'), 'output_pressure_ready', contracts.TOTAL)
    api['health']()


def stream_file(api):
    echo = api['start_echo'](3)
    primary = api['start_upload']('stream_file', 5, mode='file')
    api['send'](primary, contracts.P32, True)
    body_complete(api['body_status']('stream_file'), 'stream_file')
    observed = api['output_status']('stream_file')
    diagnostics.check_fields(observed, diagnostics.FILE_NUMBERS, frozenset(('transferred', 'caller_owned')), frozenset(('tag',)))
    require(observed['tag'] == 'stream_file' and observed['arms'] == 1 and observed['arm_errors'] == 0 and
            observed['transferred'] and not observed['caller_owned'] and observed['read_errors'] == 0 and
            observed['invalid_spans'] == 0 and observed['close_calls'] == 0 and observed['closed_files'] == 0,
            'held file state differs')
    checkpoint(api, primary, 0, contracts.EMPTY_HASH)
    api['send'](echo, b's', True)
    require(api['finish'](echo)['body'] == b's', 'echo response differs')
    api['grant'](primary, contracts.FILE_LENGTH)
    result = api['finish'](primary)
    completed(result, contracts.FILE_LENGTH, contracts.RANGE_HASH)
    require([value for name, value in result['headers'] if name == 'content-length'] == ['24593'],
            'file content-length differs')
    diagnostics.file_complete(api['output_status']('stream_file'))
    api['health']()
