"""Public TLS shutdown and ordinary EOF helper; importing is inert."""

import ssl

import wire


def unwrap_eof(tls, deadline, clock):
    def remaining():
        seconds = deadline - clock()
        if seconds <= 0:
            raise TimeoutError('absolute close deadline expired')
        return seconds

    tls.settimeout(remaining())
    plain = tls.unwrap()
    try:
        plain.settimeout(remaining())
        data = plain.recv(8192)
        if type(data) is not bytes or data != b'':
            raise ValueError('unexpected bytes after TLS shutdown')
    except BaseException as error:
        try:
            plain.close()
        except BaseException as cleanup_error:
            error.add_note('plain socket cleanup failed: ' + repr(cleanup_error))
        raise
    plain.close()
    return {'method': 'ssl_unwrap', 'tls_shutdown': 'success', 'tcp_eof': True,
            'trailing_bytes': 0, 'close': 'normal'}


def observe_shutdown(tls, protocol, records, raw, trace, stream_id, signal, deadline, clock):
    if not isinstance(signal, dict) or set(signal) != {'signal', 'owned_identity', 'watcher_installed', 'client_open'} or signal['signal'] != 'SIGTERM' or any(signal[key] is not True for key in ('owned_identity', 'watcher_installed', 'client_open')):
        raise ValueError('owned signal evidence differs')
    wire.begin_termination(records, raw, stream_id, 'owned_shutdown', 'post_signal')
    while True:
        seconds = deadline - clock()
        if seconds <= 0:
            raise TimeoutError('absolute shutdown deadline expired')
        tls.settimeout(seconds)
        try:
            data = tls.recv(8192)
        except ssl.SSLEOFError:
            outcome = 'tls_eof'
            break
        if type(data) is not bytes:
            raise ValueError('invalid TLS receive result')
        if not data:
            outcome = 'eof'
            break
        wire.accept(protocol, data, records, raw, trace)
    observation = wire.finish_termination(records, raw, stream_id, 'owned_shutdown', 'post_signal', outcome)
    return ({'phase': 'post_signal', 'outcome': outcome, 'primary_response': False,
             'frames_valid': True, 'trailing_bytes': 0}, observation)
