"""Validate completed body records emitted by the output fixture."""
import json
import contracts


RENAMES = {'accepted': 'bytes', 'begin': 'begins', 'end': 'ends',
           'cancel': 'cancels', 'failure': 'failures'}
RAW_KEYS = frozenset(contracts.record('spare_00', set()).keys()) - frozenset(RENAMES.values()) | frozenset(RENAMES)
BOOL_KEYS = frozenset(('active', 'paused'))
STRING_KEYS = frozenset(('tag', 'sha256', 'reason'))


def normalize(raw):
    if type(raw) is not dict or raw.keys() != RAW_KEYS:
        raise ValueError('fixture record schema')
    normalized = {}
    for name, value in raw.items():
        expected_type = bool if name in BOOL_KEYS else str if name in STRING_KEYS else int
        if type(value) is not expected_type:
            raise ValueError('fixture record type: ' + name)
        normalized[RENAMES.get(name, name)] = value
    if normalized['reason'] != 'none':
        raise ValueError('completed fixture reason')
    normalized['reason'] = None
    return normalized


def validate(case_ids, raw_records):
    if type(raw_records) is not list:
        raise ValueError('fixture records must be a list')
    contracts.validate_records(case_ids, [normalize(item) for item in raw_records])


BUFFERED_REQUESTS = {'output_pressure_window': 7, 'output_pressure_ready': 5,
                     'producer_reuse': 7, 'stream_file': 6, 'early_final_order': 5}


def validate_totals(case_ids, raw):
    expected = contracts.expected_records(case_ids)
    totals = {name: sum(item[key] for item in expected) for name, key in (
        ('middleware', 'middleware'), ('attempts', 'attempts'), ('begin', 'begins'),
        ('end', 'ends'), ('cancel', 'cancels'), ('failure', 'failures'),
        ('end_errors', 'end_errors'), ('chunk_errors', 'chunk_errors'),
        ('invalid_progress', 'invalid_progress'), ('accepted', 'bytes'),
        ('active', 'active'), ('errors', 'errors'))}
    totals['buffered_middleware'] = 33 + sum(BUFFERED_REQUESTS[case] for case in case_ids)
    totals['slot0_active'] = False
    totals['slot1_active'] = False
    if type(raw) is not dict or raw.keys() != totals.keys():
        raise ValueError('fixture totals schema')
    for name, value in totals.items():
        if type(raw[name]) is not type(value) or raw[name] != value:
            raise ValueError('fixture totals mismatch: ' + name)


def parse_json(data):
    if type(data) is not bytes or len(data) >= 4096:
        raise ValueError('invalid JSON body bound')
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate JSON field')
            result[key] = value
        return result
    def invalid_constant(value):
        raise ValueError('invalid JSON constant: ' + value)
    result = json.loads(data, object_pairs_hook=pairs, parse_constant=invalid_constant)
    if type(result) is not dict:
        raise ValueError('JSON object required')
    return result
