"""Validate nonce-scoped fixture observations after server deinitialization."""
import re
import contracts
import diagnostics
import records


PRODUCERS = ('producer_reuse', 'output_pressure_window', 'output_pressure_ready')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def default_producer(tag):
    return {'tag': tag, 'armed': False, 'done': False, 'offset': 0, 'sha256': contracts.EMPTY_HASH,
            'invocations': 0, 'attempts': 0, 'writes': 0, 'blocked': 0, 'pending': 0,
            'terminal_attempts': 0, 'terminals': 0, 'checks': 0, 'after_reuse': 0,
            'errors': 0, 'binding_index': 0, 'binding_generation': 0}


def default_file():
    return {'tag': 'stream_file', 'reads': 0, 'requested': 0, 'returned': 0, 'read_errors': 0,
            'close_calls': 0, 'closed_files': 0, 'invalid_spans': 0, 'min_offset': 24630,
            'max_end': 0, 'arms': 0, 'arm_errors': 0, 'transferred': False, 'caller_owned': True}


def validate(data, nonce, selection, capacity, before_records, before_totals, binding, before_outputs):
    require(type(data) is bytes and len(data) <= 65536 and type(nonce) is str and
            re.fullmatch(r'[A-Za-z0-9_-]{1,64}', nonce) is not None, 'invalid captured evidence')
    lines = data.decode('utf-8').splitlines()
    def matches(marker):
        return [line.split(marker, 1)[1] for line in lines if marker in line]
    require(matches('H2_CAPACITY ') == [capacity.removeprefix('H2_CAPACITY ')], 'capacity marker differs')
    require(matches('H2_READY ' + nonce) == [''], 'ready marker differs')
    prefixes = {kind: kind + ' ' + nonce + ' ' for kind in ('H2_OUTPUT', 'H2_RECORD', 'H2_DEINIT', 'H2_BINDING')}
    output_rows = [records.parse_json(item.encode()) for item in matches(prefixes['H2_OUTPUT'])]
    body_rows = [records.parse_json(item.encode()) for item in matches(prefixes['H2_RECORD'])]
    totals_rows = [records.parse_json(item.encode()) for item in matches(prefixes['H2_DEINIT'])]
    binding_rows = matches(prefixes['H2_BINDING'])
    require(len(output_rows) == 4 and len(body_rows) == 32 and len(totals_rows) == 1 and
            len(binding_rows) == 1, 'post marker count differs')
    records.validate(selection, body_rows)
    records.validate(selection, before_records)
    records.validate_totals(selection, totals_rows[0])
    records.validate_totals(selection, before_totals)
    require(body_rows == before_records and totals_rows[0] == before_totals, 'post body observations differ')
    selected = set(selection)
    required_outputs = selected.intersection(set(PRODUCERS) | {'stream_file'})
    require(type(before_outputs) is dict and set(before_outputs) == required_outputs, 'pre-deinit outputs differ')
    for tag, item in zip(PRODUCERS, output_rows[:3]):
        if tag in selected:
            diagnostics.producer(item, tag, contracts.TOTAL, after_reuse=tag == 'producer_reuse')
            diagnostics.producer(before_outputs[tag], tag, contracts.TOTAL, after_reuse=tag == 'producer_reuse')
            require(item == before_outputs[tag], 'post producer observation differs')
        else:
            diagnostics.check_fields(item, diagnostics.PRODUCER_NUMBERS, frozenset(('armed', 'done')), frozenset(('tag', 'sha256')))
            require(item == default_producer(tag), 'unselected producer differs')
    file = output_rows[3]
    if 'stream_file' in selected:
        diagnostics.file_complete(file)
        diagnostics.file_complete(before_outputs['stream_file'])
        require(file == before_outputs['stream_file'], 'post file observation differs')
    else:
        diagnostics.check_fields(file, diagnostics.FILE_NUMBERS, frozenset(('transferred', 'caller_owned')), frozenset(('tag',)))
        require(file == default_file(), 'unselected file differs')
    match = re.fullmatch(r'tag=producer_reuse_next index=([0-9]+) generation=([0-9]+)', binding_rows[0])
    require(match is not None, 'binding marker differs')
    observed = (int(match.group(1)), int(match.group(2)))
    if 'producer_reuse' in selected:
        require(type(binding) is tuple and len(binding) == 2 and all(type(value) is int for value in binding) and
                observed == binding, 'binding observation differs')
    else:
        require(observed == (0, 0) and binding is None, 'unselected binding differs')
    return {'records': body_rows, 'totals': totals_rows[0], 'outputs': output_rows, 'binding': observed}
