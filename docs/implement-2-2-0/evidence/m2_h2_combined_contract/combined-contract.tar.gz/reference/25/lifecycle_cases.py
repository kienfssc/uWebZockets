"""Pure checks shared by bounded lifecycle case orchestration."""

import hashlib
import json

import expectations

REUSE_METADATA = (
    ('reuse_0', '/limit/reuse_0', 'case=reuse_0', '/limit/reuse_0?case=reuse_0', 'reuse_0'),
    ('reuse_1', '/limit/reuse_1', 'case=reuse_1', '/limit/reuse_1?case=reuse_1', 'reuse_1'),
    ('reuse_2', '/limit/reuse_2', 'case=reuse_2', '/limit/reuse_2?case=reuse_2', 'reuse_2'),
    ('reuse_3', '/limit/reuse_3', 'case=reuse_3', '/limit/reuse_3?case=reuse_3', 'reuse_3'),
    ('reuse_4', '/limit/reuse_4', 'case=reuse_4', '/limit/reuse_4?case=reuse_4', 'reuse_4'),
    ('reuse_5', '/limit/reuse_5', 'case=reuse_5', '/limit/reuse_5?case=reuse_5', 'reuse_5'),
    ('reuse_6', '/limit/reuse_6', 'case=reuse_6', '/limit/reuse_6?case=reuse_6', 'reuse_6'),
    ('reuse_7', '/limit/reuse_7', 'case=reuse_7', '/limit/reuse_7?case=reuse_7', 'reuse_7'),
    ('reuse_8', '/limit/reuse_8', 'case=reuse_8', '/limit/reuse_8?case=reuse_8', 'reuse_8'),
)


def verify_record(tag, actual, expected):
    if not isinstance(actual, dict) or set(actual) != set(expected) | {'chunks', 'max_span'}:
        raise ValueError('incomplete actual record: ' + tag)
    expectations.verify({tag: actual}, {tag: expected})


def record_evidence(digest, event):
    payload = json.dumps(event, sort_keys=True, separators=(',', ':')).encode('utf-8')
    if len(payload) >= 4096:
        raise ValueError('case evidence bound')
    digest.update(len(payload).to_bytes(4, 'big'))
    digest.update(payload)


def expired_pair(status, control, old_tag, active_tag):
    for operation in ('resume', 'cancel'):
        previous = status(old_tag)
        active = status(active_tag)
        if control(operation, old_tag) != 'BodyControlExpired':
            raise ValueError('old control did not expire')
        expected = dict(previous)
        expected['stale_' + operation] += 1
        if status(old_tag) != expected or status(active_tag) != active:
            raise ValueError('expired control mutated a record')


def reuse(api):
    expected = expectations.records(('reuse',), 'after')
    digest = hashlib.sha256()
    count = {'resume': 0, 'cancel': 0}
    for i, (tag, path, query, target, header) in enumerate(REUSE_METADATA):
        metadata = {'method': 'POST', 'path': path, 'query': query, 'target': target,
                    'x-case': header, 'content-length': '32'}
        stream = api['start'](tag, metadata, 'healthy')
        api['send'](stream, 7, False)
        active_expected = dict(expected[tag])
        active_expected.update(accepted=7, sha256=expectations.H7, end=0,
                               active=True, metadata_end=0, stale_resume=0, stale_cancel=0)
        barrier = api['status'](tag)
        verify_record(tag, barrier, active_expected)
        record_evidence(digest, ('barrier', tag, barrier))
        for j in range(i):
            old_tag = REUSE_METADATA[j][0]
            old_expected = dict(expected[old_tag])
            old_expected.update(stale_resume=i-j-1, stale_cancel=i-j-1)
            for operation in ('resume', 'cancel'):
                old_before = api['status'](old_tag)
                current_before = api['status'](tag)
                verify_record(old_tag, old_before, old_expected)
                verify_record(tag, current_before, active_expected)
                reply = api['control'](operation, old_tag)
                if reply != 'BodyControlExpired':
                    raise ValueError('old control did not expire')
                old_expected['stale_' + operation] += 1
                old_after = api['status'](old_tag)
                current_after = api['status'](tag)
                verify_record(old_tag, old_after, old_expected)
                verify_record(tag, current_after, active_expected)
                if current_before != current_after:
                    raise ValueError('active record changed')
                old_compared = dict(old_before)
                old_compared['stale_' + operation] += 1
                if old_compared != old_after:
                    raise ValueError('old record changed')
                count[operation] += 1
                record_evidence(digest, ('control', tag, old_tag, operation, old_before,
                                         old_after, current_before, current_after))
        api['send'](stream, 25, True)
        response = api['finish'](stream)
        if set(response) != {'status', 'record'} or response['status'] != 200:
            raise ValueError('reuse response status differs')
        completed = dict(expected[tag])
        completed.update(stale_resume=0, stale_cancel=0)
        verify_record(tag, response['record'], completed)
        record_evidence(digest, ('complete', tag, response['record']))
    final_counts = []
    for tag, *_ in REUSE_METADATA:
        actual = api['status'](tag)
        verify_record(tag, actual, expected[tag])
        final_counts.append((actual['stale_resume'], actual['stale_cancel']))
        record_evidence(digest, ('final', tag, actual))
    return {'requests': len(REUSE_METADATA), 'stale_resume': count['resume'],
            'stale_cancel': count['cancel'], 'final_stale': final_counts,
            'evidence_sha256': digest.hexdigest()}


def disconnect(api, connection):
    expected = expectations.records(('disconnect',), 'after')
    digest = hashlib.sha256()
    primary_metadata = {'method': 'POST', 'path': '/limit/disconnect', 'query': 'case=disconnect',
                        'target': '/limit/disconnect?case=disconnect', 'x-case': 'disconnect',
                        'content-length': '32'}
    recovery_metadata = {'method': 'POST', 'path': '/limit/disconnect_recovery',
                         'query': 'case=disconnect_recovery',
                         'target': '/limit/disconnect_recovery?case=disconnect_recovery',
                         'x-case': 'disconnect_recovery', 'content-length': '32'}
    primary = api['start'](connection, 'disconnect', primary_metadata, 'clean_disconnect')
    api['send'](connection, primary, 32, False)
    active = dict(expected['disconnect'])
    active.update(cancel=0, reason='none', active=True, paused=True, stale_resume=0, stale_cancel=0)
    before_close = api['status'](connection, 'disconnect')
    verify_record('disconnect', before_close, active)
    record_evidence(digest, ('original_connection_preclose', before_close))
    closure = api['close'](connection)
    required_close = {'method': 'ssl_unwrap', 'tls_shutdown': 'success', 'tcp_eof': True,
                      'trailing_bytes': 0, 'close': 'normal'}
    if closure != required_close or type(closure.get('tcp_eof')) is not bool or type(closure.get('trailing_bytes')) is not int:
        raise ValueError('strict TLS disconnect differs')
    record_evidence(digest, ('strict_close', closure))
    replacement = api['replacement']()
    if not isinstance(replacement, dict) or set(replacement) != {'connection', 'owned', 'tls', 'alpn'}:
        raise ValueError('replacement evidence differs')
    new = replacement['connection']
    if new is None or new is connection or replacement['owned'] is not True or replacement['tls'] != 'TLSv1.3' or replacement['alpn'] != 'h2':
        raise ValueError('replacement connection differs')
    old_expected = dict(expected['disconnect'])
    old_expected.update(stale_resume=0, stale_cancel=0)
    post_close = api['status'](new, 'disconnect')
    verify_record('disconnect', post_close, old_expected)
    record_evidence(digest, ('replacement_postclose', post_close))

    def stale_controls(active_tag, active_expected):
        for operation in ('resume', 'cancel'):
            old_before = api['status'](new, 'disconnect')
            verify_record('disconnect', old_before, old_expected)
            current_before = None
            if active_tag is not None:
                current_before = api['status'](new, active_tag)
                verify_record(active_tag, current_before, active_expected)
            if api['control'](new, operation, 'disconnect') != 'BodyControlExpired':
                raise ValueError('disconnect control did not expire')
            old_expected['stale_' + operation] += 1
            old_after = api['status'](new, 'disconnect')
            verify_record('disconnect', old_after, old_expected)
            compared = dict(old_before)
            compared['stale_' + operation] += 1
            if compared != old_after:
                raise ValueError('disconnect record changed')
            current_after = None
            if active_tag is not None:
                current_after = api['status'](new, active_tag)
                verify_record(active_tag, current_after, active_expected)
                if current_before != current_after:
                    raise ValueError('active recovery record changed')
            record_evidence(digest, ('stale', active_tag, operation, old_before, old_after,
                                     current_before, current_after))

    stale_controls(None, None)
    recovery = api['start'](new, 'disconnect_recovery', recovery_metadata, 'healthy')
    api['send'](new, recovery, 7, False)
    recovery_active = dict(expected['disconnect_recovery'])
    recovery_active.update(accepted=7, sha256=expectations.H7, end=0, active=True, metadata_end=0)
    recovery_barrier = api['status'](new, 'disconnect_recovery')
    verify_record('disconnect_recovery', recovery_barrier, recovery_active)
    record_evidence(digest, ('replacement_recovery_active', recovery_barrier))
    stale_controls('disconnect_recovery', recovery_active)
    api['send'](new, recovery, 25, True)
    response = api['finish'](new, recovery)
    if not isinstance(response, dict) or set(response) != {'status', 'record'} or response['status'] != 200:
        raise ValueError('recovery response differs')
    verify_record('disconnect_recovery', response['record'], expected['disconnect_recovery'])
    record_evidence(digest, ('replacement_recovery_complete', response['record']))
    old_final = api['status'](new, 'disconnect')
    verify_record('disconnect', old_final, expected['disconnect'])
    record_evidence(digest, ('replacement_final', old_final))
    return {'preclose_observation': 'original_connection', 'postclose_observation': 'replacement_connection',
            'close': closure, 'stale_resume': old_final['stale_resume'],
            'stale_cancel': old_final['stale_cancel'], 'preclose_record': before_close,
            'postclose_record': post_close, 'recovery_active_record': recovery_barrier,
            'recovery_record': response['record'], 'evidence_sha256': digest.hexdigest()}


def expected_metrics(selection, phase, buffered_count):
    if type(buffered_count) is not int or buffered_count < 0:
        raise ValueError('invalid independent buffered request count')
    rows = expectations.records(selection, phase)
    fields = ('middleware', 'attempts', 'begin', 'end', 'cancel', 'failure', 'end_errors',
              'chunk_errors', 'invalid_progress', 'accepted', 'active', 'errors')
    result = {field: sum(int(record[field]) for record in rows.values()) for field in fields}
    result['buffered_middleware'] = buffered_count
    return result


def verify_final(records, metrics, selection, phase, buffered_count):
    expected = expectations.records(selection, phase)
    if not isinstance(records, dict) or set(records) != set(expected):
        raise ValueError('final record identities differ')
    for tag, row in expected.items():
        verify_record(tag, records[tag], row)
    totals = expected_metrics(selection, phase, buffered_count)
    if not isinstance(metrics, dict) or set(metrics) != set(totals) | {'slot0_active', 'slot1_active'}:
        raise ValueError('final metric fields differ')
    if any(type(metrics[key]) is not int or metrics[key] != value for key, value in totals.items()):
        raise ValueError('final metrics differ')
    slots = (metrics['slot0_active'], metrics['slot1_active'])
    if any(type(value) is not bool for value in slots) or sum(slots) != totals['active']:
        raise ValueError('fixture active slot count differs')


def shutdown_active(api, connection, selection):
    if not selection or selection[-1] != 'shutdown_active' or len(set(selection)) != len(selection) or not set(selection) <= set(expectations.CASES):
        raise ValueError('invalid shutdown selection order')
    preconditions = api['preconditions'](connection)
    if not isinstance(preconditions, dict) or set(preconditions) != {'prior_complete', 'client_open'} or preconditions['prior_complete'] is not True or preconditions['client_open'] is not True:
        raise ValueError('shutdown preconditions differ')
    metadata = {'method': 'POST', 'path': '/limit/shutdown_active', 'query': 'case=shutdown_active',
                'target': '/limit/shutdown_active?case=shutdown_active', 'x-case': 'shutdown_active',
                'content-length': '32'}
    stream = api['start'](connection, 'shutdown_active', metadata, 'owned_shutdown')
    api['send'](connection, stream, 32, False)
    expected_before = expectations.records(selection, 'before')
    barrier = api['status'](connection, 'shutdown_active')
    verify_record('shutdown_active', barrier, expected_before['shutdown_active'])
    rows = {tag: api['status'](connection, tag) for tag in expectations.TAGS}
    metrics = api['metrics'](connection)
    buffered = api['request_count']()
    verify_final(rows, metrics, selection, 'before', buffered)
    if rows['shutdown_active'] != barrier:
        raise ValueError('shutdown barrier changed before signal')
    deadline = api['graceful_deadline']()
    if deadline is None:
        raise ValueError('missing graceful deadline')
    signal_evidence = api['signal'](connection, deadline)
    if not isinstance(signal_evidence, dict) or set(signal_evidence) != {'signal', 'owned_identity', 'watcher_installed', 'client_open'} or signal_evidence['signal'] != 'SIGTERM' or any(signal_evidence[key] is not True for key in ('owned_identity', 'watcher_installed', 'client_open')):
        raise ValueError('owned signal evidence differs')
    termination = api['termination'](connection, deadline)
    if not isinstance(termination, dict) or set(termination) != {'phase', 'outcome', 'primary_response', 'frames_valid', 'trailing_bytes'}:
        raise ValueError('termination evidence fields differ')
    if termination['phase'] != 'post_signal' or termination['outcome'] not in ('eof', 'tls_eof') or termination['primary_response'] is not False or termination['frames_valid'] is not True or type(termination['trailing_bytes']) is not int or termination['trailing_bytes'] != 0:
        raise ValueError('post-signal termination differs')
    process = api['wait'](deadline)
    required = {'exit_code': 0, 'reaped': True, 'forced': False, 'run_ok': True,
                'deinit_ok': True, 'key_removed': True}
    if not isinstance(process, dict) or set(process) != set(required) or type(process['exit_code']) is not int or process['exit_code'] != 0 or any(process[key] is not value for key, value in required.items() if key != 'exit_code'):
        raise ValueError('shutdown process evidence differs')
    post = api['post'](deadline)
    if not isinstance(post, dict) or set(post) != {'records', 'metrics'}:
        raise ValueError('post-deinit evidence fields differ')
    verify_final(post['records'], post['metrics'], selection, 'after', buffered)
    for tag in expectations.TAGS:
        if any(rows[tag][key] != post['records'][tag][key] for key in ('chunks', 'max_span')):
            raise ValueError('post-deinit chunk diagnostics changed: ' + tag)
    return {'before': {'records': rows, 'metrics': metrics}, 'after': post,
            'signal': signal_evidence, 'termination': termination, 'process': process}
