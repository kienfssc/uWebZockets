# Concrete H2 Session delivery handoff

Architect /root/architect_h2_session_delivery completed a source-only handoff
against frozen 580199bc84e81779dd050943fc0b1bb7a9b8f1af113fcb28e7fab560fc105af6.
No code, build, client or probe was performed. Root records its operative output
here before implementation assignment. ADR0008 and the full original H2 plan
remain the binding scope; this handoff does not replace remaining acceptance.

## First executable slice

Protocol owner guided by DX/transport implements one vertical Session-to-real-
registered-sink slice before startup/native activation. Own server.zig, a focused
core/http2_upload.zig, actual neutral admission extraction, its H1 consumer and
centralized integration tests. Keep HeaderFn/HeaderDecision source compatible.

Add default-null BodySelectFn fn(*anyopaque,*const Request)bool and BodyEventFn
fn(*anyopaque,BodyEvent)anyerror!BodyEventResult. Selection is read-only and cannot
reenter Session; absent/false selection preserves legacy policy. Structural and
full-u64 framing checks precede admission, even for selected routes. Only selected
streaming bypasses buffered ceilings. Malformed length and known END_STREAM
mismatch fail before begin.

Use named event payloads: head has streamID/index, *Request, declared?u64 and
initial END_STREAM; data has streamID/index, borrowed bytes and fresh bool; end
has identity and occurs only after valid EOF/empty queue/ready sink; closed has
identity and BodyCancelReason. BodyEvent has head/data/end/closed tags.
BodyEventResult has head:BodyHeadResult, data:BodyProgress and done; mismatches
are internal errors. Head result separates accepted readiness from final/refusal.

Concrete capacity-specialized driver owns BodyState/reservation/sink logic. Every
effect adapter constructs a fresh explicit *Response, passes it to the driver,
and never retains it. Resume recovers its stable slot and current callbacks;
Session drains real retained bytes. The caller-owned fixture registers real
BodyRoutes, uses shared actual admission, feeds encoded HEADERS/DATA and reaches
begin/chunk/end beyond body_stride with pause/resume and accepted output credit.
Direct sink invocation or queue-only tests do not satisfy this slice.

Extract routing, QUERY/replay, captures, middleware/order, declared limits,
ingress availability, pending-header capacity and quota recheck from the actual
App head resolver. Move reserve_and_arm with it. H1 retains framing, upgrade,
HeadReady and physical-tail arithmetic; H2 passes validated neutral facts.
Never fabricate an H1 HeadReady for H2.

## Required first-slice ownership/output rules

- Each new DATA payload reaches driver fresh=true once; only that path observes
  bytes. Paused driver observes without calling sink and returns zero/paused.
  Session retains unaccepted suffix; queue drains use fresh=false.
- Directly consumed bytes become credit-eligible after callback unwind. Queued
  head prefixes release credit only at full block reclamation. Padding is actual
  flow_length minus data bytes and needs no payload block.
- Validate actual pending/window, submit complete WINDOW_UPDATE, commit only
  accepted scope. WouldBlock retains intent. Connection success followed by
  blocked stream output must not duplicate connection credit.
- Enabled Sessions route buffered/refused/WS DATA refunds through the same
  pending connection ledger; old immediate restore must not bypass it.
- Resume drains retained bytes first, then credit/output; pending EOF can finish
  without another byte. Final-byte pause still requires explicit resume.
- Continue has its own persistent retry state, no END_STREAM and no consumption
  of saved final metadata. Retain DATA while Continue blocks; never repeat begin.
- Early finals use existing refusal completion/reset ordering: NO_ERROR reset
  follows actual final HEADERS/DATA acceptance, preserving hard-writer guard/FIFO.
- Fix unconditional clear_stream under callback before delivering sinks. Record
  cause/invalidate controls/retire identity, but defer metadata, queue, captures
  and notification while borrowed. Guard admission, sink and terminal callbacks.
  Input cannot reenter Session; retired slot cannot be reacquired before unwind.
- End invalidates controls before notification; quota release follows return,
  including error. End error aborts output without cancel. Producer state remains
  independent of upload binding lifetime.

## Later startup/native slice

Session gets one optional receive-state pointer; existing Http1UploadStorage gets
one optional H2 driver-owner pointer, avoiding another TcpConnection pointer.
Carve pool/protocol/driver state only when stream_request_bodies is enabled.
Bind stable App/Loop addresses late and preserve generations across reuse.

Reuse per-stream request/header slabs. Capture overflow is two slice matrices,
each max_streams*(max_route_params-16); native stream count remains8. Enabled
buffered H2 also uses them, preserving siblings' retained metadata until response
completion. Validate/discard trailers in scratch. Save middleware bytes in idle
per-stream response-header storage at min(2048,response_header_stride), then copy
into the fresh terminal Response before encoding overwrites those bytes.

Join existing native delivery borrow/release gates. Preserve first cause:
peer EOF peer_closed; peer RST reset; timeout timeout; shutdown shutdown;
application cancelled; transport/TLS source_failure. Cancel accepted streams once
before release. Inherited SSL_in_init shutdown abort remains; genuine0RTT open.

## Layout proposal requiring measurement

64-bit field arithmetic estimates, NOT compiler measurements:

| Region | Proposed growth |
| --- | --- |
| Callbacks two optional function pointers | 16 bytes, estimated56 to72 |
| Session optional receive-state pointer | 8 bytes |
| Storage default-null receive-state pointer | 8 bytes, estimated288 to296 |
| Capacities default-false streaming bool | estimated56 to64 |
| Optional H1 cold owner's H2 pointer | approximately8 bytes |
| Queue payload/blocks/eight head-tail pairs | 74192 bytes per enabled connection |
| Protocol receive state | approximately144 bytes per enabled connection |
| Concrete driver owner | approximately1288 bytes per enabled connection |
| Capture overflow | 256*(max_route_params-16) bytes per enabled connection |

Receive state: Queue estimated56, one connection and eight stream u32 pending
counters, eight mode bytes, eight each paused/EOF/Continue flags, eight optional
close causes. Reuse callback_active; no new warm per-stream arrays.
Driver slot: BodyState estimated120, owner pointer, route-definition pointer,
streamID, route-record/index/pending-header u16s and callback-phase byte;
estimated152*8. Driver owner: Session pointer, explicit native context, shared
admission target and two capture slices; estimated72, total1288.

Overall estimate75640 bytes per enabled connection including warm pointer:
default disabled1024 connections +8192 slab bytes and no cold allocation;
private8 connections L512/H1024/B256 +605120 bytes;
default explicitly enabled1024 connections +77455360 bytes. Both supplied
profiles have zero capture overflow. Hypothetical default totals if exactly8
warm bytes hold: Linux684185216, macOS684103296, Windows684684928.
Measure actual alignment/optionals/descriptors and three-target totals before
changing assertions or approving behavior implementation. No threshold weakening.

## Limits and review

The deep seams are Session receive events, concrete upload driver and shared
admission. Deleting driver would scatter observe-once/progress/terminal/quota/
control invariants; deleting shared policy duplicates H1/H2 admission. No forwarding
facades or generic scheduler are justified. All original full gates and actual
owned100000000-byte H2/TLS proof remain outstanding; this is architecture only.
No native cancellation/schedule/interleaving/race/crash/leak/invalid-fd/resource/
registration/kernel/injected-completion/panic experiment is authorized.

Skill rulings: project central tests/Zig0.16 outrank generic defaults. Root's
read-only/no-delegation handoff scope overrides planning report locations and
grilling interview/delegation defaults. Generic definition-of-done reference is
missing; project explicit gates remain authoritative. No ADR, vocabulary change
or broad deepening scan is proposed.

## Root correction: observation while delivery is gated

Root found that fresh alone cannot distinguish observation from delivery while
Continue output is blocked or an older queued suffix exists. Architect independently
checked the correction and approved the following explicit contract, with no new
source reads, build or probe. The boolean changes stack event data, not cold layout.

Add BodyDataEvent.delivery_allowed bool. fresh=true always observes once, including
under a blocked Continue; limit/length failures take their normal terminal path.
delivery_allowed=false performs no start_chunk, sink or accept_chunk call. It
returns0/paused as an event result only, without changing actual BodyState.readiness.
Session categorically ignores that result readiness, retains actual sink-paused
state and queues the entire payload. Synthetic holds release no payload credit.

delivery_allowed=true still respects real sink readiness and records its resulting
pause. A complete accepted100 HEADERS lifts Continue; encoding/attempt/WouldBlock
does not. Drain queued input automatically when actual sink is ready. Continue
gates end as well as chunk, including empty EOF. A valid public resume while
Continue is blocked must clear real sink pause, but leave delivery gated; later
Continue acceptance drains without a second resume.

Fresh DATA cannot bypass older queue bytes: observe-only, append, then drain FIFO.
Queue deliveries use fresh=false. Padding remains independently eligible.
Reset/cancel drops pending Continue and forbids later delivery. Test ready sink
with blocked100/multiple frames/early limits, paused sink resuming before100,
empty/final-byte EOF gating, FIFO with older retained suffix, and exact once-only
observation/credit. This is the smallest correction; no new scheduler or stored
response-factory pointer is approved.
