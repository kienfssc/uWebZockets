## Task 2: measure proposed Session and cold-owner layouts

Read session_handoff_2026_10_28.md first for the accepted architect's concrete
field list and next vertical delivery slice. Root authorizes measurements only
in this task; no behavior implementation or source adoption. The full M2 goal,
first registered-sink integration and later native/live acceptance remain open.

Owner verification. Keep baseline /tmp/uwz-m2-h2-body-queue immutable at exact
1025-file digest580199bc84e81779dd050943fc0b1bb7a9b8f1af113fcb28e7fab560fc105af6.
Own only new /tmp/uwz-m2-h2-layout-proposal and /tmp layout artifacts/caches;
small source snapshots/records/report go .uwz-work/evidence/h2-streaming/layout.
These task-local paths override Task1's source/output paths in Global Constraints.
You are not alone; never revert others, change Root source, refs, pins or gates,
commit/push, fetch or dispatch subagents.

Measure actual baseline Session8, Storage, Capacities, Callbacks, TcpConnection,
Http1UploadStorage, BodyState, Queue and default/native/private storage planning
on native Linux, aarch64-macos and x86_64-windows-gnu. Private config is supplied
in .uwz-work/evidence/h1-tls/integration-single/profile.zig: eight connections,
L512/H1024/B256, eight native H2 streams. Inspect real config functions/arguments;
do not invent a plan API. Record exact compilation inputs and target bindings.

In a separate disposable prototype copy, add only the proposed declaration-only
fields: Session optional receive-state pointer; Storage default-null same pointer;
Capacities false streaming bool; Callbacks two default-null function pointers;
H1 cold owner optional H2 owner pointer. Pointee/function-type proxies are allowed
ONLY in the measurement artifact, explicitly labelled as layout proxies rather
than final implementation contracts. No behavior, admission, parser, constructor,
callback execution, capacity allocation or assertion edits. Keep baseline unchanged.
Measure actual resulting warm/default planning/layout totals; don't just sum8.

Use named private prototype data for proposed protocol/driver owner shapes from
the handoff and the real existing Queue/BodyState/route/cancel types. Measure
their alignment and optionals; where the shared target is not yet implemented,
label its layout proxy and show the assumed shape. Calculate enabled totals
including pool, metadata, stream heads/tails, state, driver slots, cold pointer
and config region alignment. State which totals are measured final-type facts
and which remain proposed-region arithmetic. No cold/slab assertion changes.

Use original r2 three-target C bindings, verified immutable c223 override and
existing compiler/static-library identities; -j2, caches and binaries /tmp only.
An intentional @compileLog compile-only report is acceptable: retain real status
and clearly classify expected compile-log termination, never a test pass/red.
No executable, tests, socket/client or native code runs. No full central native
suite and no new native cancellation/schedule/interleaving/race/crash/leak/
invalid-fd/resource/registration/kernel/injected-completion/panic probe.

Graphify first before new source searches using the prefix in Global Constraints;
the supplied paths and earlier located source lines may be read directly.
After prototype code edits refresh AST in an independent identical /tmp copy;
full immutable baseline/candidate/input/override manifests and raw command records
must survive. If a missing module/tool needs broader changes, report before
altering scope. Root owns final approval of fields/growth before Task3 behavior.

Write task-2-report.md beside the extracted task-2-brief.md. Report exact commands,
measured values, proxy assumptions, total arithmetic, source/input identities,
preserved failures and baseline immutability. Return only status, one-line
measurement summary and concerns. No new H2 capability claim follows.
