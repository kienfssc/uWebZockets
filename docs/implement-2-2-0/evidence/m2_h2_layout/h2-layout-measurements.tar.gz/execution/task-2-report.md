# Task 2: declaration-only H2 storage measurements

Status: measurements complete for native Linux (`x86_64-linux-gnu`), `aarch64-macos`, and `x86_64-windows-gnu`, using Zig 0.16.0 and ReleaseSafe. Root has not approved adoption. No H2 behavior, startup activation, capacity allocation, constructor, assertion, gate, native probe, client, test execution, executable, dependency pin, ref or Root source was changed. Full M2 and registered-sink integration remain open.

Evidence directory: `.uwz-work/evidence/h2-streaming/layout/`. Each of the six compiler invocations intentionally terminated with status **1**, solely `error: found compile log statement`. This is a compiler-produced layout report, not a test pass or a red/green regression result. No other compiler error occurred. `*-{native,macos,windows}.log` retain the complete raw compiler output, including every reported field offset, size and alignment. Corresponding JSON records retain full exact argument vectors, cwd, environment, input identities, source manifests and before/after identities. `measurements.json` is the parsed result; raw logs remain authoritative.

## Actual type measurements

Sizes are bytes; all types below align to 8 unless specified. Baseline means real frozen source declarations; proposal means the same declarations with only the five requested additive fields. Pointee and callback proxies are confined to the disposable measurement copy.

| Type | Baseline | Proposal | Change |
| --- | ---: | ---: | ---: |
| Session8, all targets | 1384 | 1392 | 8 |
| Session8.Storage, all targets | 288 | 296 | 8 |
| Session8.Capacities, all targets | 56 | 64 | 8 |
| Callbacks, all targets | 56 | 72 | 16 |
| Linux TcpConnection | 25640 | 25648 | 8 |
| macOS TcpConnection | 25560 | 25568 | 8 |
| Windows TcpConnection | 26128 | 26136 | 8 |
| Linux Http1UploadStorage | 2880 | 2888 | 8 |
| macOS Http1UploadStorage | 2848 | 2856 | 8 |
| Windows Http1UploadStorage | 3040 | 3048 | 8 |
| BodyState, all targets | 120 | 120 | 0 |
| Queue, all targets | 56 | 56 | 0 |
| Queue.Storage, all targets | 48 | 48 | 0 |
| Queue.Block, alignment 2 | 6 | 6 | 0 |
| Queue.Stream, alignment 2 | 4 | 4 | 0 |

The optional receive/owner pointers and optional callback pointers each measure 8 bytes. Optional `BodyCancelReason` is **2 bytes**, alignment 1, not one byte. Capacity flags measure 8 bytes of struct growth because of alignment. `Storage`, `Capacities` and `Callbacks` are descriptors; their growth is not multiplied into the contiguous connection slab. The embedded Session increase is accounted for by the actual TcpConnection size.

## Actual storage planning

The real APIs used are `Session8.storage_bytes(Session8.default_capacities)`, `ServerConfig.slab_bytes()`, `required_alignment()`, `request_buffer_stride()`, `h2_capacities()`, `h2_session_bytes()`, `h2_session_stride()`, `router_storage_bytes()` and `extra_route_param_capacity()`. No plan API was invented or exposed.

`Session8` default storage is **517648 bytes**, alignment 8, on all targets in both versions. The native TCP type is actually specialized with **8 streams** on every target. Default ServerConfig also plans 517648 H2 bytes/stride per connection. The supplied private configuration plans **379408 H2 bytes/stride**, **2816 H1 request bytes/stride**, and 8 connections. Default H1 request stride is 41984. Both profiles have max_route_params=16 and zero capture overflow. Config required alignment is 64 on all three targets.

The private inputs exactly match `.uwz-work/evidence/h1-tls/integration-single/profile.zig`: max_connections=8, stream_request_bodies=true, max_request_line_size=512, max_header_size=1024, max_body_size=256. The 256-byte limit is H1; the real projection retains default H2 body_size=16384. H2 header_block_size=16384, request_header_size=1024, response_header_size=4096, response_header_count=32, decoded_header_count=64, dynamic_table_size=4096. Default capacities differ only by request_header_size=16384. The declaration-only streaming flag defaults false and is not propagated by the unchanged `h2_capacities()` implementation, even for ServerConfig streaming=true. Actual allocation of H2 regions is future implementation work.

| Target/config | Frozen slab bytes | Declaration-only slab bytes | Measured growth |
| --- | ---: | ---: | ---: |
| Linux default disabled | 684177024 | 684185216 | 8192 |
| macOS default disabled | 684095104 | 684103296 | 8192 |
| Windows default disabled | 684676736 | 684684928 | 8192 |
| Linux default enabled | 687136384 | 687152768 | 16384 |
| macOS default enabled | 687021696 | 687038080 | 16384 |
| Windows default enabled | 687799936 | 687816320 | 16384 |
| Linux private enabled | 4826432 | 4826560 | 128 |
| macOS private enabled | 4825536 | 4825664 | 128 |
| Windows private enabled | 4831616 | 4831744 | 128 |

These are measured outputs of the unchanged real planners, rather than assumed additions to old totals. Disabled configurations allocate no H2 cold region and no H1 cold owner; they pay only the embedded warm Session pointer. Enabled configurations' measured growth includes both the warm Session pointer and the new pointer inside each existing H1 cold owner. Router storage remains 874112 bytes disabled or 884352 bytes enabled.

## Measured proxy types and proposed enabled-region arithmetic

The handoff shapes are named private measurement data in `layout_types.zig`. They are **layout proxies, not final implementation contracts**. Their sizes/alignment are compiler measurements, identical on all three targets:

| Shape | Size | Alignment | Assumptions |
| --- | ---: | ---: | --- |
| ReceiveStateProxy | 144 | 8 | Real Queue 56; connection u32 plus eight stream u32 counters 36; eight mode bytes 8; three eight-bool flag arrays 24; eight real optional close reasons 16; four tail padding bytes |
| DriverSlotProxy | 152 | 8 | Real BodyState 120; owner pointer 8; optional real BodyRoute definition pointer 8; stream u32 4; three u16 fields 6; real existing callback-phase enum 1; padding 5 |
| SharedAdmissionTargetProxy | 24 | 8 | Existing H1 HeadTarget's three-pointer descriptor is the size proxy only; its H1-specific resolver signature must not become the shared admission contract |
| DriverOwnerProxy | 1288 | 8 | Session pointer 8; native context assumed one TcpConnection pointer 8; admission descriptor 24; two capture slices 32; eight real-shape driver slots 1216 |

Receive-state offsets are Queue=0, connection_pending=56, stream_pending=60, modes=92, paused=100, EOF=108, Continue=116, close_causes=124. Optional close reasons consume 16 bytes in total; size rounds from 140 to 144. No duplicate Queue descriptor is added outside this state.

Queue's real `required_capacity(8)` returns 73728 payload bytes and 72 blocks. At six metadata bytes/block and four bytes/head-tail pair, the physical pool region is:

```text
73728 + 72*6 + 8*4 = 74192 bytes
74192 + receive_state144 + driver_owner1288 = 75624 cold bytes/connection
75624 + Session_pointer8 + H1_cold_pointer8 = 75640 total growth/enabled connection
8*75640 = 605120 bytes
1024*75640 = 77455360 bytes
```

The enabled totals below are **proposed-region arithmetic**, evaluated at comptime using measured real planner outputs and proxy `@sizeOf/@alignOf`, rather than measurements of a finished allocation/carving implementation. The arithmetic inserts payload, Block arrays, Stream arrays, receive-state array, driver-owner array and two capture matrices between existing upload owners and the router region. Each region aligns to its actual element alignment; the router re-aligns to real `radix.storage_alignment`=8. All padding increments are zero for the supplied profiles. Complete start/end offsets are in `measurements.json` and raw logs. There is no final 64-byte roundup: the real config planner returns its cursor directly, with required base alignment 64.

| Target/config | Proposed enabled total | Growth from corresponding frozen enabled plan |
| --- | ---: | ---: |
| Linux private, 8 connections | 5431552 | 605120 |
| macOS private, 8 connections | 5430656 | 605120 |
| Windows private, 8 connections | 5436736 | 605120 |
| Linux default explicitly enabled, 1024 | 764591744 | 77455360 |
| macOS default explicitly enabled, 1024 | 764477056 | 77455360 |
| Windows default explicitly enabled, 1024 | 765255296 | 77455360 |

Measured declaration-only plans already include the two pointers. The appended cold arithmetic is 604992 bytes for private8 or 77438976 bytes for default1024, avoiding double counting those pointers. The architect's numerical estimates are confirmed for these specific proposed shapes.

Two capture matrices add `8 * 2 * @sizeOf([]const u8) * (max_route_params-16)` = `256*(max_route_params-16)` bytes per enabled connection on these 64-bit targets, plus any insertion alignment. Both measured profiles have zero extra captures. Existing shared captures remain in the unchanged actual config plan; enabled per-stream overflow storage is additional. No 32-bit layout or representability claim follows from this task.

## Inputs and reproducibility

Frozen baseline `/tmp/uwz-m2-h2-body-queue` remains exactly 1025 files, digest `580199bc84e81779dd050943fc0b1bb7a9b8f1af113fcb28e7fab560fc105af6`, before and after all six compiles and final verification. It was not edited. Measurement baseline is an independent copy at `/tmp/uwz-m2-h2-layout-artifacts/baseline-source`, with only two measurement files added, 1027 files, digest `7398157b8fc6ad2e6dd8f24717cd1b5fdb27ec1094cf2071ea56b59482098589`. Candidate `/tmp/uwz-m2-h2-layout-proposal` has 1027 files, digest `5b4c5187f296cc425f91cf91421e59820367eb8624cd6cf7d69ad655c02f3252`. Digests use the previous driver's exact algorithm: SHA256 of default `json.dumps` applied to sorted `(relative_path,file_sha256)` pairs. Complete `source-<digest>.json` manifests survive in evidence.

Only candidate copies of `src/http2/server.zig` and `src/core/http1_upload_storage.zig` differ from existing baseline files. `declaration-only.patch` retains that complete diff: import/aliases plus requested default-null pointers, bool and callbacks. No method, constructor, capacity planner, allocator, assertion or callback body was edited. New `src/layout_measurement.zig` and `src/layout_types.zig` are measurement-only and retained as evidence snapshots. Small Python generation/parse/driver sources are retained; caches, AST outputs and source copies are under `/tmp`.

Compiler: `/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`, SHA256 `2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c`. Each compile inherits the original central command's exact target bindings and module graph, replaces `test` with `build-obj`, replaces only the root with `src/layout_measurement.zig`, removes test execution flags, and uses `-fno-emit-bin`, `-OReleaseSafe`, `-j2`, caches `/tmp/uwz-m2-h2-layout-artifacts/{cache,global}`. Each JSON retains the complete expanded command. These original records and their SHA256 identities are retained by reference:

- `body-queue/focused-rs.json`: restored native module/compiler/static-library identities; all input hashes independently matched before measurement and again for every invocation.
- `body-queue/central-native.json`, `central-macos.json`, `central-windows.json`: original target/module argument graphs; all original input identities independently matched before measurement.
- Original r2 C modules are `h1-transport/r2/c-native.zig`, `c-aarch64-macos.zig`, `c-x86_64-windows-gnu.zig`; each compile record includes its actual hash and target binding.
- Immutable c223 override `/tmp/uwz-reviewed-libxev-c223-loop-callbacks`, commit `c223bd886c6a51d2cd60def39dd9a68d701fea73`, tree `86c6944f53dc009d7503a9ab0bc873aef3cd7b79`. All 93 files matched `loop-callbacks/immutable-libxev-input.json` before/after every compile; original manifest SHA256 is `af909377909a4f0509e8b6c2fdcee1c96d2567d6757f33bf3c197f2ce4897980`.
- Existing native static-library identities are retained and checked in `inputs_before/after`; build-obj does not link them or rebuild dependencies. Existing zslay root-module identity is checked, and a complete external source manifest is retained in `external-sources.json` and `external-source-<digest>.json`.

Exact wrapper commands, run from `/workspaces/uWebZockets`, were:

```sh
python3 .uwz-work/evidence/h2-streaming/layout/driver.py baseline native
python3 .uwz-work/evidence/h2-streaming/layout/driver.py candidate native
python3 .uwz-work/evidence/h2-streaming/layout/driver.py baseline macos
python3 .uwz-work/evidence/h2-streaming/layout/driver.py candidate macos
python3 .uwz-work/evidence/h2-streaming/layout/driver.py baseline windows
python3 .uwz-work/evidence/h2-streaming/layout/driver.py candidate windows
```

Each wrapper exited 0 after retaining the compiler's raw exit 1; it did not convert that exit into a test pass. Classification requires exactly one error and the expected compile-log diagnostic. Each record's before/after source and input sets are identical. `final-identities.json` retains final source identities and hashes of all six command records/raw logs.

Formatting command, exit 0, empty stdout/stderr:

```sh
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check /tmp/uwz-m2-h2-layout-proposal/src/layout_measurement.zig /tmp/uwz-m2-h2-layout-proposal/src/layout_types.zig /tmp/uwz-m2-h2-layout-proposal/src/http2/server.zig /tmp/uwz-m2-h2-layout-proposal/src/core/http1_upload_storage.zig
```

AST refresh command, exit 0, run only in identical independent source copy `/tmp/uwz-m2-h2-layout-artifacts/ast-copy`:

```sh
env PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

Raw result: 595 files extracted, 13098 nodes, 16303 edges, 2082 communities; 14 symbols from the measurement files. Zero semantic input/output tokens. Parallel AST extraction was unavailable with EPERM and automatically fell back to sequential; 28 existing code files yielded no modeled symbols. `ast-refresh.log/json` retain the raw output, exact command/cwd, graph hash and identical pre/post source digest. Generated graph files are only in `/tmp`.

Preserved noncompiler failures: the initial setup copy kept read-only baseline modes, causing PermissionError when writing a copied candidate file; only the two disposable candidate modes were changed to 0644. The initial summary regex failed on commas inside Zig error-set type names; numeric-suffix parsing fixed the evidence parser without changing measured source or rerunning compiler reports. Both raw errors and explanations are retained as `setup-initial-failure.log` and `parser-initial-failure.log`.

## Approval boundaries and remaining concerns

Root must approve actual fields/growth before implementation assignment. The measurements support the numerical handoff, not a public type/event/admission contract: native context is assumed one stable TCP pointer, shared admission currently uses an H1 descriptor only as a three-pointer size proxy, and the event callback signature is only a code-pointer proxy. The actual neutral admission callback and event union/result remain to be implemented and independently reviewed. Larger descriptors, additional fields or another retained context require fresh accounting. The current config projection neither propagates the new bool nor carves any H2 cold state.

No assertion or cold/slab threshold was changed, including frozen existing layout expectations. Broad gates and all behavior tests were intentionally outside this explicit compile-only measurement authorization, not reported passing. No native/live H2 capability, sink lifetime, credit, cancellation, accepted-byte accounting or TLS claim follows. The stopped cancellation/schedule/fault experiment remains stopped. Registered-sink Session integration and all later applicable matrix/live acceptance remain outstanding.
