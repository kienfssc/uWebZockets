from pathlib import Path
import hashlib,json,subprocess,os,sys,time
ROOT=Path('/workspaces/uWebZockets')
OUT=ROOT/'.uwz-work/evidence/h2-streaming/layout'
ART=Path('/tmp/uwz-m2-h2-layout-artifacts')
BASE=Path('/tmp/uwz-m2-h2-body-queue')
CAND=Path('/tmp/uwz-m2-h2-layout-proposal')
ZIG='/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig'
EXPECTED='580199bc84e81779dd050943fc0b1bb7a9b8f1af113fcb28e7fab560fc105af6'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def source(path):
    rows=[(str(p.relative_to(path)),sha(p)) for p in sorted(path.rglob('*')) if p.is_file()]
    digest=hashlib.sha256(json.dumps(rows).encode()).hexdigest()
    (OUT/('source-'+digest+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
    return {'path':str(path),'files':len(rows),'digest':digest}
def override():
    p=ROOT/'.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json';m=json.loads(p.read_text())
    actual={n:sha(Path(m['path'])/n) for n in m['files_sha256']}
    assert actual==m['files_sha256']
    return {'manifest_sha256':sha(p),'commit':m['commit'],'tree':m['tree'],'files_sha256':actual}
def state():
    baseline=source(BASE);assert baseline['digest']==EXPECTED
    return {'frozen_baseline':baseline,'candidate':source(CAND),'measurement_baseline':source(ART/'baseline-source'),'override':override()}
def inputs(argv):
    result={}
    for item in argv:
        raw=item.split('=',1)[1] if item.startswith('-M') else item if item==ZIG else None
        if raw:
            p=Path(raw);p=p if p.is_absolute() else cwd/p
            result[str(p)]=sha(p)
    prior=json.loads((ROOT/'.uwz-work/evidence/h2-streaming/body-queue/focused-rs.json').read_text())
    for p,h in prior['inputs_before'].items():
        assert sha(p)==h,(p,'original identity mismatch')
        result[p]=h
    return result
variant,target_name=sys.argv[1:3]
cwd=CAND if variant=='candidate' else ART/'baseline-source'
original_name={'native':'central-native','macos':'central-macos','windows':'central-windows'}[target_name]
original_path=ROOT/('.uwz-work/evidence/h2-streaming/body-queue/'+original_name+'.json')
original=json.loads(original_path.read_text());argv=[];skip=False
for item in original['argv']:
    if skip:skip=False;continue
    if item in ('--cache-dir','--global-cache-dir'):skip=True;continue
    if item in ('--test-no-exec','-fno-emit-bin'):continue
    if item=='test':item='build-obj'
    if item.startswith('-Mroot='):item='-Mroot=src/layout_measurement.zig'
    argv.append(item)
argv+=['-fno-emit-bin','--cache-dir',str(ART/'cache'),'--global-cache-dir',str(ART/'global')]
label=variant+'-'+target_name
assert not (OUT/(label+'.json')).exists(),label
before=state();env={k:os.environ[k] for k in ['PATH','HOME','LANG','LC_ALL','TMPDIR','PYTHONPATH'] if k in os.environ}
record={'argv':argv,'cwd':str(cwd),'optimization':'ReleaseSafe','operation':'compile-only declaration layout; intentional compileLog termination','origin_record':str(original_path),'origin_sha256':sha(original_path),'environment':env,'before':before,'inputs_before':inputs(argv),'driver_sha256':sha(__file__)}
start=time.monotonic()
with (OUT/(label+'.log')).open('wb') as f:result=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
record.update(exit_status=result.returncode,elapsed_seconds=time.monotonic()-start,after=state(),inputs_after=inputs(argv),raw_log_sha256=sha(OUT/(label+'.log')))
raw=(OUT/(label+'.log')).read_text()
record['classification']='expected compile-log termination' if result.returncode==1 and 'error: found compile log statement' in raw and raw.count('error:')==1 else 'unexpected failure'
(OUT/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(label,record['classification'],'exit',result.returncode)
print('\n'.join(line for line in raw.splitlines() if 'error:' in line or '@as([]const u8, "config")' in line or '@as([]const u8, "proposed_enabled_total")' in line or '@as([]const u8, "optionals")' in line or '@as([]const u8, "session_default_plan")' in line or '@as([]const u8, "type")' in line))
