const queue = @import("http2/body_queue.zig");
const body = @import("http/request_body.zig");
const h1 = @import("core/http1_upload.zig");
const cold = @import("core/http1_upload_storage.zig");
const tcp = @import("core/tcp.zig");
const server = @import("http2/server.zig");

// Declaration-only layout proxies; no final protocol or admission contract.
pub const ReceiveModeProxy = enum(u8) { buffered, selected, refused, websocket };
pub const ReceiveStateProxy = struct {
    queue: queue.Queue,
    connection_pending: u32,
    stream_pending: [8]u32,
    modes: [8]ReceiveModeProxy,
    paused: [8]bool,
    eof: [8]bool,
    continue_pending: [8]bool,
    close_causes: [8]?body.BodyCancelReason,
};
// Existing H1 descriptor gives the assumed three-pointer target size only.
pub const SharedAdmissionTargetProxy = h1.HeadTarget;
pub const DriverSlotProxy = struct {
    body: body.BodyState,
    owner: *DriverOwnerProxy,
    route_definition: ?*const body.BodyRoute,
    stream_id: u32,
    route_record_index: u16,
    stream_index: u16,
    pending_header_length: u16,
    callback_phase: cold.CallbackPhase,
};
pub const DriverOwnerProxy = struct {
    session: *server.server_session(8),
    native_context: *tcp.TcpConnection,
    admission: SharedAdmissionTargetProxy,
    capture_names: [][]const u8,
    capture_values: [][]const u8,
    slots: [8]DriverSlotProxy,
};
// Signatures stand in only for two optional code pointers in Callbacks.
pub const BodySelectFnProxy = *const fn (*anyopaque, *const @import("http/request.zig").Request) bool;
pub const BodyEventFnProxy = *const fn (*anyopaque) anyerror!void;
