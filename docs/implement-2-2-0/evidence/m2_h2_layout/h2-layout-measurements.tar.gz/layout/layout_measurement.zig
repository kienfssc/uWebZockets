const std = @import("std");
const builtin = @import("builtin");
const server = @import("http2/server.zig");
const config = @import("router/config.zig");
const tcp = @import("core/tcp.zig");
const cold = @import("core/http1_upload_storage.zig");
const body = @import("http/request_body.zig");
const queue = @import("http2/body_queue.zig");
const radix = @import("router/radix.zig");
const proxy = @import("layout_types.zig");
const Session8 = server.server_session(8);
const defaults: config.ServerConfig = .{};
const enabled: config.ServerConfig = .{ .stream_request_bodies = true };
const private: config.ServerConfig = .{ .max_connections = 8, .stream_request_bodies = true, .max_request_line_size = 512, .max_header_size = 1024, .max_body_size = 256 };

fn type_layout(comptime name: []const u8, comptime T: type) void {
    @compileLog("type", name, @sizeOf(T), @alignOf(T));
    inline for (@typeInfo(T).@"struct".fields) |field| {
        @compileLog("field", name, field.name, @offsetOf(T, field.name), @sizeOf(field.type), @alignOf(field.type));
    }
}

fn align_up(value: usize, alignment: usize) usize {
    return std.mem.alignForward(usize, value, alignment);
}

fn region(comptime name: []const u8, cursor: *usize, count: usize, size: usize, alignment: usize) void {
    const before = cursor.*;
    cursor.* = align_up(cursor.*, alignment);
    const start = cursor.*;
    cursor.* += count * size;
    @compileLog("proposed_region", name, before, start, cursor.*, alignment);
}

fn plan(comptime name: []const u8, comptime cfg: config.ServerConfig) void {
    const total = cfg.slab_bytes() catch @compileError("slab planning failed");
    const router_bytes = cfg.router_storage_bytes() catch @compileError("router planning failed");
    @compileLog("config", name, cfg.max_connections, cfg.stream_request_bodies, total, cfg.required_alignment(), cfg.request_buffer_stride(), cfg.h2_session_bytes(), cfg.h2_session_stride(), router_bytes, cfg.extra_route_param_capacity());
    @compileLog("h2_capacities", name, cfg.h2_capacities());
    if (!cfg.stream_request_bodies) return;
    const capacity = queue.required_capacity(tcp.max_http2_streams) catch @compileError("queue planning failed");
    var cursor = total - router_bytes;
    region(name ++ ":payload", &cursor, cfg.max_connections, capacity.payload_bytes, @alignOf(u8));
    region(name ++ ":blocks", &cursor, cfg.max_connections * capacity.block_count, @sizeOf(queue.Block), @alignOf(queue.Block));
    region(name ++ ":stream_heads_tails", &cursor, cfg.max_connections * 8, @sizeOf(queue.Stream), @alignOf(queue.Stream));
    region(name ++ ":receive_state_proxy", &cursor, cfg.max_connections, @sizeOf(proxy.ReceiveStateProxy), @alignOf(proxy.ReceiveStateProxy));
    region(name ++ ":driver_owner_proxy", &cursor, cfg.max_connections, @sizeOf(proxy.DriverOwnerProxy), @alignOf(proxy.DriverOwnerProxy));
    const capture_count = (cfg.extra_route_param_capacity() catch @compileError("capture planning failed")) * cfg.max_connections * 8;
    region(name ++ ":capture_names", &cursor, capture_count, @sizeOf([]const u8), @alignOf([]const u8));
    region(name ++ ":capture_values", &cursor, capture_count, @sizeOf([]const u8), @alignOf([]const u8));
    region(name ++ ":router", &cursor, 1, router_bytes, radix.storage_alignment);
    @compileLog("proposed_enabled_total", name, cursor, cursor - total);
}

comptime {
    @setEvalBranchQuota(100000);
    @compileLog("target", builtin.target.cpu.arch, builtin.target.os.tag, builtin.target.abi);
    type_layout("Session8", Session8);
    type_layout("Storage", Session8.Storage);
    type_layout("Capacities", Session8.Capacities);
    type_layout("Callbacks", server.Callbacks);
    type_layout("TcpConnection", tcp.TcpConnection);
    type_layout("Http1UploadStorage", cold.Http1UploadStorage);
    type_layout("BodyState", body.BodyState);
    type_layout("Queue", queue.Queue);
    type_layout("QueueStorage", queue.Storage);
    type_layout("Block", queue.Block);
    type_layout("Stream", queue.Stream);
    type_layout("ReceiveStateProxy", proxy.ReceiveStateProxy);
    type_layout("DriverSlotProxy", proxy.DriverSlotProxy);
    type_layout("DriverOwnerProxy", proxy.DriverOwnerProxy);
    type_layout("SharedAdmissionTargetProxy", proxy.SharedAdmissionTargetProxy);
    @compileLog("optionals", @sizeOf(?*proxy.ReceiveStateProxy), @alignOf(?*proxy.ReceiveStateProxy), @sizeOf(?*proxy.DriverOwnerProxy), @sizeOf(?body.BodyCancelReason), @alignOf(?body.BodyCancelReason), @sizeOf(?proxy.BodySelectFnProxy), @sizeOf(?proxy.BodyEventFnProxy));
    @compileLog("native_stream_count", tcp.max_http2_streams);
    @compileLog("session_default_plan", Session8.storage_bytes(Session8.default_capacities), Session8.storage_alignment, Session8.default_capacities);
    @compileLog("queue_capacity", queue.required_capacity(8));
    plan("default_disabled", defaults);
    plan("default_enabled", enabled);
    plan("private_enabled", private);
}
