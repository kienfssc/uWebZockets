from pathlib import Path
import re,json
out=Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/layout');result={}
for p in sorted(out.glob('*-*.log')):
 if not p.name.startswith(('baseline-','candidate-')):continue
 r={'types':{},'fields':{},'configs':{},'proposed_regions':{},'proposed_totals':{}}
 for l in p.read_text().splitlines():
  if not l.startswith('@as('):continue
  names=re.findall(r'"([^"]+)"',l)
  if not names:continue
  nums=[int(x) for x in re.findall(r', (\d+)\)',l)]
  if names[0]=='type':r['types'][names[1]]={'size':nums[0],'alignment':nums[1]}
  if names[0]=='field':r['fields'].setdefault(names[1],{})[names[2]]={'offset':nums[0],'size':nums[1],'alignment':nums[2]}
  if names[0]=='config':r['configs'][names[1]]={'connections':nums[0],'slab_bytes':nums[1],'alignment':nums[2],'request_stride':nums[3],'h2_session_bytes':nums[4],'h2_session_stride':nums[5],'router_bytes':nums[6],'capture_extra_capacity':nums[7]}
  if names[0]=='proposed_region':r['proposed_regions'][names[1]]={'before':nums[0],'start':nums[1],'end':nums[2],'alignment':nums[3]}
  if names[0]=='proposed_enabled_total':r['proposed_totals'][names[1]]={'total':nums[0],'added_to_measured_plan':nums[1]}
 result[p.stem]=r
(out/'measurements.json').write_text(json.dumps(result,indent=2)+'\n')
for name,r in result.items():
 print(name,{n:v['size'] for n,v in r['types'].items() if n in ['Session8','TcpConnection','Http1UploadStorage']},{n:v['slab_bytes'] for n,v in r['configs'].items()},r['proposed_totals'])
