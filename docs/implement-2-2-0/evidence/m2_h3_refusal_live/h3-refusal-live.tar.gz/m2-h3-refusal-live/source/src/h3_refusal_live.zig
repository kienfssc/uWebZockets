const std = @import("std");
const support = @import("test_support");
const xev = @import("xev");
const body = support.request_body;
const Request = support.http_request.Request;
const Response = support.http_response.Response;
const StreamingRequest = support.streaming_request.StreamingRequest;

/// Counts application effects without requiring an upload binding.
const Effects = struct {
    sink_calls: usize = 0,
    middleware_calls: usize = 0,
    health_calls: usize = 0,

    fn begin(context: *anyopaque, _: *const StreamingRequest, _: body.BodyControl) !body.BodyBinding {
        const state: *Effects = @ptrCast(@alignCast(context));
        state.sink_calls += 1;
        return error.UnexpectedSinkCall;
    }
    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
        const state: *Effects = @ptrCast(@alignCast(context));
        state.sink_calls += 1;
        return .{ .consumed = bytes.len, .readiness = .ready };
    }
    fn end(context: *anyopaque, _: *const StreamingRequest, _: *Response) !void {
        const state: *Effects = @ptrCast(@alignCast(context));
        state.sink_calls += 1;
    }
    fn cancel(context: *anyopaque, _: body.BodyCancelReason) void {
        const state: *Effects = @ptrCast(@alignCast(context));
        state.sink_calls += 1;
    }
    fn middleware(context: *anyopaque, _: *Request, _: *Response) support.radix.MiddlewareResult {
        const state: *Effects = @ptrCast(@alignCast(context));
        state.middleware_calls += 1;
        return .continue_dispatch;
    }
    fn health(context: *anyopaque, _: *Request, response: *Response) void {
        const state: *Effects = @ptrCast(@alignCast(context));
        state.health_calls += 1;
        response.text("ok") catch |err| std.log.err("health response failed: {}", .{err});
    }
};

pub fn main(init: std.process.Init) !void {
    const port = try std.fmt.parseInt(u16, init.environ_map.get("UWZ_H3_REFUSAL_PORT") orelse return error.MissingPort, 10);
    var server = try support.app.app(4).init_configured(init.io, std.heap.page_allocator, .{
        .max_connections = 4,
        .stream_request_bodies = true,
        .max_body_size = 32,
    });
    defer server.deinit();
    server.quic_tls_ctx = try support.tls.TlsContext.init_http3_ephemeral(.{});
    server.http3_enabled = true;
    var effects = Effects{};
    const definition = body.BodyRoute{
        .sink = .{ .context = &effects, .begin = Effects.begin, .chunk = Effects.chunk, .end = Effects.end, .cancel = Effects.cancel },
        .limits = .{ .max_body_bytes = 100_000_000, .max_active = 1 },
        .middleware_policy = .headers_only,
    };
    _ = try server.route_body(.post, "/upload", &definition);
    _ = try server.get_context("/health", &effects, Effects.health);
    _ = try server.use(&effects, Effects.middleware);
    try server.listen_udp("127.0.0.1", port);
    try server.catch_shutdown_signals();
    std.log.info("h3 refusal live ready port={d} backend={s}", .{ port, @tagName(xev.backend()) });
    try server.run();
    try server.shutdown();
    if (effects.sink_calls != 0 or effects.middleware_calls != 2 or effects.health_calls != 2) return error.UnexpectedApplicationEffects;
    for (server.router.body.active) |active| if (active != 0) return error.AdmissionNotPreserved;
    std.log.info("h3 refusal live drained sink=0 middleware=2 health=2 quota=0", .{});
}
