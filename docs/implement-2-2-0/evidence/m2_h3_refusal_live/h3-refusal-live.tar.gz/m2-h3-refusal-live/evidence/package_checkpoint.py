from pathlib import Path
import tarfile,hashlib,io,json,gzip,re,os
root=Path('/workspaces/uWebZockets');e=Path(__file__).resolve().parent;out=root/'docs/implement-2-2-0/evidence/m2_h3_refusal_live';out.mkdir(parents=True,exist_ok=True);d=root/'.uwz-work/drafts/m2-h3-body-refusal';run=json.loads((e/'run.json').read_text());assert run['passed'] and run['owned_server_reaped'] and run['server_exit_status']==0
files={'source/src/h3_refusal_live.zig':(d/'src/h3_refusal_live.zig').read_bytes()}
for p in e.iterdir():
 if p.is_file():files['evidence/'+p.name]=p.read_bytes()
files['SCOPE.md']=b'''# Owned HTTP/3 refusal follow-up

This supplements isolated H3 refusal checkpoint d0998302858dbc114a24d16ae2b57510d0d0ba59a3e4f5462e32caf5ef5abfe1. Its production source bytes are unchanged. Restore that draft over the earlier prepared App/R2 tree, then add source/src/h3_refusal_live.zig. Commands retain historical paths and generated C bindings. Derived executable and Python caches are excluded; ephemeral TLS keys are never written to the artifacts.

The runtime uses an exact export of independently reviewed local libxev commit 7b7b1f14518d9504b15590d123ec494b8fadb2e3, tree 0ae835a79eaea49f8ff086e64d777152c454b928. Restore that commit from the complete-history bundle in the existing M3 libxev UDP review archive if reproducing. dependency-override.json binds all 89 exported files. The export came from git archive of the immutable commit; the separately staged unreviewed duplicate cleanup is excluded. This is test-only, not a root pin adoption or maintained-fork publication.

A normal owned loopback HTTP/3 server runs on io_uring. aioquic 1.3.0 sends valid POST headers with Content-Length 100000000 and Expect: 100-continue, leaves the sending side open and sends no DATA. It observes STOP_SENDING(H3_NO_ERROR=256), complete empty 503 and a concurrent healthy 200 sibling, followed by another healthy 200 on the same QUIC connection. The server records zero sink effects or retained quota, with middleware/handlers only for the two health requests. Client close is normal; SIGTERM requests server graceful shutdown. Both processes exit zero and the owned server is reaped.

Full draft and reviewed dependency source hashes stay unchanged. All four authoritative root zon views stay unchanged. The trace is application events, not transport qlog. observed-inputs-after-run.json is an after-run observation only. Public shutdown behavior is bound to the unchanged pinned lsquic source audit and the actual received error code.

This is normal protocol refusal evidence, not an earlier stopped native experiment, cancellation/race/leak/crash probe, successful 100 MB upload, memory/performance result, full HTTP/3 compliance gate or full M2 result. Independent review, concrete drivers, maintained dependency adoption and final combined verification remain required. No source pin, dependency ref or production integration changes.
'''
patterns=[re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}'),re.compile(rb'github_pat_[A-Za-z0-9_]{20,}')];secrets=[v.encode() for k,v in os.environ.items() if re.search('TOKEN|SECRET|PASSWORD|API_KEY',k) and len(v)>=16]
for n,b in files.items():
 if any(p.search(b) for p in patterns) or any(s in b for s in secrets):raise SystemExit('credential scan match in '+n)
inv={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in sorted(files.items())};files['INVENTORY.json']=(json.dumps(inv,indent=2)+'\n').encode();a=out/'h3-refusal-live.tar.gz'
with a.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for n,b in sorted(files.items()):
    ti=tarfile.TarInfo('m2-h3-refusal-live/'+n);ti.size=len(b);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(b))
with tarfile.open(a) as t:
 for ti in t.getmembers():
  assert ti.isfile() and not ti.name.startswith('/') and '..' not in Path(ti.name).parts
  assert t.extractfile(ti).read()==files[ti.name.removeprefix('m2-h3-refusal-live/')]
s={'date':'2026-10-27','scope':'Owned normal HTTP/3 header refusal, healthy sibling and reuse; reviewed test-only libxev override; isolated unreviewed source','archive':a.name,'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'archive_bytes':a.stat().st_size,'safe_regular_members':len(files),'inventory_entries':len(inv),'base_refusal_archive_sha256':'d0998302858dbc114a24d16ae2b57510d0d0ba59a3e4f5462e32caf5ef5abfe1','client_exit_status':0,'server_exit_status':0,'owned_process_reaped':True,'upload_bytes_sent':0,'refusal_status':503,'healthy_status':200,'connection_reused':True,'dependency_override_commit':'7b7b1f14518d9504b15590d123ec494b8fadb2e3','root_pins_unchanged':True,'stop_sending_error_code':256,'credential_scan':'No retained bytes match environment credentials or GitHub token patterns','files':inv};(out/'manifest.json').write_text(json.dumps(s,indent=2)+'\n');print({k:v for k,v in s.items() if k!='files'})
