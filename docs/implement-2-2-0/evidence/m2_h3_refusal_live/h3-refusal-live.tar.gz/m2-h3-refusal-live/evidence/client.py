from pathlib import Path
import json,select,socket,ssl,sys,time,hashlib
from typing import TextIO,TypedDict
import aioquic
from aioquic.h3.connection import H3Connection,H3_ALPN
from aioquic.h3.events import HeadersReceived,DataReceived
from aioquic.quic.connection import QuicConnection
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.events import HandshakeCompleted,ConnectionTerminated,StopSendingReceived,StreamReset

ResponseState=TypedDict('ResponseState',{'headers':list[tuple[bytes,bytes]],'body':bytearray,'complete':bool})
ClientState=TypedDict('ClientState',{'quic':QuicConnection,'http':H3Connection,'requests':dict[int,ResponseState],'trace':TextIO,'handshake':bool,'terminated':bool,'closing':bool,'stops':list[dict],'events':int})

def record(state:ClientState,event:dict)->None:
    state['events']+=1
    if state['events']>1000:raise RuntimeError('application event bound exceeded')
    state['trace'].write(json.dumps(event)+'\n')

def consume(state:ClientState)->None:
    while (event:=state['quic'].next_event()) is not None:
        if isinstance(event,HandshakeCompleted):
            assert event.alpn_protocol in H3_ALPN
            state['handshake']=True
            record(state,{'event':'handshake','alpn':event.alpn_protocol})
        if isinstance(event,StopSendingReceived):
            assert event.stream_id==0 and event.error_code==0x100,event
            state['stops'].append({'stream_id':event.stream_id,'error_code':event.error_code})
            record(state,{'event':'stop_sending','stream_id':event.stream_id,'error_code':event.error_code})
        if isinstance(event,StreamReset):raise RuntimeError('response reset: '+str(event))
        if isinstance(event,ConnectionTerminated):
            assert state['closing'] and event.error_code in (0,0x100),event
            state['terminated']=True
            record(state,{'event':'connection_terminated','error_code':event.error_code})
        for message in state['http'].handle_event(event):
            if not isinstance(message,(HeadersReceived,DataReceived)):continue
            response=state['requests'][message.stream_id]
            assert not response['complete']
            if isinstance(message,HeadersReceived):
                response['headers'].extend(message.headers)
                assert len(response['headers'])<=64
                assert sum(len(n)+len(v) for n,v in response['headers'])<=65536
                record(state,{'event':'headers','stream_id':message.stream_id,'headers':[[n.decode('ascii'),v.decode('ascii')] for n,v in message.headers],'end_stream':message.stream_ended})
            else:
                assert len(response['body'])+len(message.data)<=4096
                response['body'].extend(message.data)
                record(state,{'event':'data','stream_id':message.stream_id,'bytes':len(message.data),'end_stream':message.stream_ended})
            if message.stream_ended:response['complete']=True

def step(state:ClientState,udp:socket.socket,buffer:bytearray,deadline:float)->None:
    now=time.monotonic()
    if now>=deadline:raise TimeoutError('HTTP3 progress deadline')
    for data,address in state['quic'].datagrams_to_send(now=now):
        while True:
            try:
                assert udp.sendto(data,address)==len(data)
                break
            except BlockingIOError:
                if time.monotonic()>=deadline:raise TimeoutError('UDP send deadline')
                select.select([], [udp], [], .05)
    timer=state['quic'].get_timer();now=time.monotonic()
    if timer is not None and timer<=now:
        state['quic'].handle_timer(now=now);consume(state);return
    timeout=min(.05,max(0,deadline-now))
    if timer is not None:timeout=min(timeout,max(0,timer-now))
    if select.select([udp],[],[],timeout)[0]:
        try:length,address=udp.recvfrom_into(buffer)
        except BlockingIOError:return
        state['quic'].receive_datagram(bytes(memoryview(buffer)[:length]),address,now=time.monotonic())
    consume(state)

def start(state:ClientState,port:int,path:str,upload:bool=False)->int:
    stream=state['quic'].get_next_available_stream_id()
    state['requests'][stream]=ResponseState(headers=[],body=bytearray(),complete=False)
    headers=[(b':method',b'POST' if upload else b'GET'),(b':scheme',b'https'),(b':authority',f'localhost:{port}'.encode()),(b':path',path.encode())]
    if upload:headers.extend([(b'content-length',b'100000000'),(b'expect',b'100-continue')])
    state['http'].send_headers(stream,headers,end_stream=not upload)
    record(state,{'event':'request_headers','stream_id':stream,'path':path,'end_stream':not upload,'upload_data_bytes':0})
    return stream

def main()->None:
    out=Path(sys.argv[1]);port=int(sys.argv[2]);configuration=QuicConfiguration(is_client=True,alpn_protocols=H3_ALPN,verify_mode=ssl.CERT_NONE,server_name='localhost',max_data=262144,max_stream_data=65536)
    quic=QuicConnection(configuration=configuration);quic.connect(('127.0.0.1',port),now=time.monotonic());http=H3Connection(quic);result={}
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as udp,(out/'application.jsonl').open('w',buffering=1) as trace:
        udp.bind(('127.0.0.1',0));udp.setblocking(False)
        state=ClientState(quic=quic,http=http,requests={},trace=trace,handshake=False,terminated=False,closing=False,stops=[],events=0);buffer=bytearray(65536);deadline=time.monotonic()+10
        try:
            while not state['handshake']:step(state,udp,buffer,deadline)
            refused=start(state,port,'/upload',True);sibling=start(state,port,'/health')
            while not all(state['requests'][i]['complete'] for i in [refused,sibling]) or not state['stops']:step(state,udp,buffer,deadline)
            reuse=start(state,port,'/health')
            while not state['requests'][reuse]['complete']:step(state,udp,buffer,deadline)
            for stream_id,status,body in [(refused,b'503',b''),(sibling,b'200',b'ok'),(reuse,b'200',b'ok')]:
                response=state['requests'][stream_id];assert [v for n,v in response['headers'] if n==b':status']==[status]
                assert bytes(response['body'])==body
            assert len(state['stops'])==1
            result={'passed':True,'connection_count':1,'upload_data_bytes':0,'refused_stream':refused,'healthy_sibling':sibling,'reused_stream':reuse,'stop_sending':state['stops'],'responses':{str(i):{'status':[v.decode() for n,v in r['headers'] if n==b':status'],'body_bytes':len(r['body']),'complete':r['complete']} for i,r in state['requests'].items()},'aioquic_version':aioquic.__version__,'python':sys.executable,'trace_kind':'application events, not transport qlog','client_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        finally:
            state['closing']=True;quic.close();closing_deadline=time.monotonic()+3
            while not state['terminated']:step(state,udp,buffer,closing_deadline)
    (out/'client-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

if __name__=='__main__':main()
