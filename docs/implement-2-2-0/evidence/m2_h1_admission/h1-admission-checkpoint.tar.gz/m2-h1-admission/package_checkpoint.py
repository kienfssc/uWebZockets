from pathlib import Path
import tarfile,hashlib,io,json,gzip,re,os
root=Path('/workspaces/uWebZockets');e=root/'.uwz-work/evidence/h1-admission';out=root/'docs/implement-2-2-0/evidence/m2_h1_admission';out.mkdir(parents=True,exist_ok=True);d=root/'.uwz-work/drafts/m2-h1-admission';m=json.loads((e/'v2/delta-source-manifest.json').read_text());files={}
for n in m['changed']:files['overlay/'+n]=(d/n).read_bytes()
for p in e.rglob('*'):
 if p.is_file() and p.name!='package_checkpoint.py':files['evidence/'+str(p.relative_to(e))]=p.read_bytes()
files['package_checkpoint.py']=Path(__file__).read_bytes()
files['SCOPE.md']=b'''# Isolated pure HTTP/1 admission preparation

No production integration or live uploads. Independent review remains pending.
Start from the prepared m2-body-app tree in m2-transport-preparation.tar.gz (SHA256 a079931a4c13dac96546390f316e708a8f491c4a2392c6c19be6f1dbcd6a968b), with ordinary repository metadata at its recorded baseline. Copy overlay/ over that draft root. The delta manifest binds five replacements/additions; all other archived source bytes match. Commands retain historical absolute tool/module/cache paths. src/http1_admission_test_support.zig is verification-only; ordinary central support also imports the real module.

The v1 red result is declaration absence (FileNotFound), not a behavioral reproduction of a production defect. Final v2 actual tests use real prepared router registration/counters and common BodyState, with no sink invocation or native I/O. Seven cases pass on native Debug, ReleaseSafe and ReleaseFast and actual Linux32 ReleaseSafe. The central ReleaseSafe test root filtered to those seven validates test wiring only, not the full combined suite.

The initial release check failed because the new draft omitted CODEBASE.md, then passed after unchanged metadata was copied from the frozen prepared baseline. Both records remain. No release version was changed.

The helper performs checked physical bounds and one reserve-to-arm transfer with a single rollback before common state accepts ownership. It adds no cancellation/retirement algorithm, loop API, HeadTarget, App resolver, middleware execution, callback delivery, socket/TLS hook or public activation. It must not land alone. Required independent review, concrete H1/TLS consumer, backend lifetime prerequisite and combined gates remain open.
'''
patterns=[re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}'),re.compile(rb'github_pat_[A-Za-z0-9_]{20,}')];secrets=[v.encode() for k,v in os.environ.items() if re.search('TOKEN|SECRET|PASSWORD|API_KEY',k) and len(v)>=16]
for n,b in files.items():
 if any(p.search(b) for p in patterns) or any(s in b for s in secrets):raise SystemExit('credential scan match in '+n)
inv={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in sorted(files.items())};files['INVENTORY.json']=(json.dumps(inv,indent=2)+'\n').encode();a=out/'h1-admission-checkpoint.tar.gz'
with a.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for n,b in sorted(files.items()):
    ti=tarfile.TarInfo('m2-h1-admission/'+n);ti.size=len(b);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(b))
with tarfile.open(a) as t:
 for ti in t.getmembers():
  assert ti.isfile() and not ti.name.startswith('/') and '..' not in Path(ti.name).parts
  n=ti.name.removeprefix('m2-h1-admission/');assert t.extractfile(ti).read()==files[n]
s={'date':'2026-10-27','scope':'Pure H1 bounds/admission helper; isolated, unreviewed, not a live driver','archive':a.name,'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'archive_bytes':a.stat().st_size,'safe_regular_members':len(files),'inventory_entries':len(inv),'base_archive_sha256':m['recovery_archive_sha256'],'final_sources':m['changed'],'final_results':{'native_Debug':7,'native_ReleaseSafe':7,'native_ReleaseFast':7,'actual_Linux32_ReleaseSafe':7,'central_ReleaseSafe_filtered':7,'fmt':0,'conventions':0,'release_after_metadata_restoration':0},'credential_scan':'No retained bytes match environment credentials or GitHub token patterns','files':inv};(out/'manifest.json').write_text(json.dumps(s,indent=2)+'\n');print({k:v for k,v in s.items() if k not in ['files','final_sources']})
