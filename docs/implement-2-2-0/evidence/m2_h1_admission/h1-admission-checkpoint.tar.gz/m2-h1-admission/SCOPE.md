# Isolated pure HTTP/1 admission preparation

No production integration or live uploads. Independent review remains pending.
Start from the prepared m2-body-app tree in m2-transport-preparation.tar.gz (SHA256 a079931a4c13dac96546390f316e708a8f491c4a2392c6c19be6f1dbcd6a968b), with ordinary repository metadata at its recorded baseline. Copy overlay/ over that draft root. The delta manifest binds five replacements/additions; all other archived source bytes match. Commands retain historical absolute tool/module/cache paths. src/http1_admission_test_support.zig is verification-only; ordinary central support also imports the real module.

The v1 red result is declaration absence (FileNotFound), not a behavioral reproduction of a production defect. Final v2 actual tests use real prepared router registration/counters and common BodyState, with no sink invocation or native I/O. Seven cases pass on native Debug, ReleaseSafe and ReleaseFast and actual Linux32 ReleaseSafe. The central ReleaseSafe test root filtered to those seven validates test wiring only, not the full combined suite.

The initial release check failed because the new draft omitted CODEBASE.md, then passed after unchanged metadata was copied from the frozen prepared baseline. Both records remain. No release version was changed.

The helper performs checked physical bounds and one reserve-to-arm transfer with a single rollback before common state accepts ownership. It adds no cancellation/retirement algorithm, loop API, HeadTarget, App resolver, middleware execution, callback delivery, socket/TLS hook or public activation. It must not land alone. Required independent review, concrete H1/TLS consumer, backend lifetime prerequisite and combined gates remain open.
