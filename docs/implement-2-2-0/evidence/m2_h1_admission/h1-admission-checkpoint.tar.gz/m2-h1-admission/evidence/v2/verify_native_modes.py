from pathlib import Path
import json,subprocess,time,hashlib,sys
out=Path(__file__).resolve().parent;c=json.loads((out/'width-native-compile.json').read_text());d=Path(c['cwd']);paths=list(c['source_after'])
def hashes():return {n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in paths}
for mode in ['Debug','ReleaseFast']:
 a=[('-O'+mode if x=='-OReleaseSafe' else '-femit-bin=/tmp/uwz-h1-admission-'+mode if x.startswith('-femit-bin=') else x) for x in c['argv']];s=time.monotonic();rec={'argv':a,'cwd':str(d),'source_before':hashes()};r=subprocess.run(a,cwd=d,capture_output=True);(out/(mode+'-compile.log')).write_bytes(r.stdout+r.stderr);rec.update(exit_status=r.returncode,elapsed_seconds=time.monotonic()-s,source_after=hashes());(out/(mode+'-compile.json')).write_text(json.dumps(rec,indent=2)+'\n');print('COMPILE',mode,r.returncode,flush=True)
 if r.returncode:print(r.stderr.decode()[-5000:],flush=True);sys.exit(r.returncode)
 a=['/tmp/uwz-h1-admission-'+mode];s=time.monotonic();r=subprocess.run(a,cwd=d,capture_output=True);(out/(mode+'-run.log')).write_bytes(r.stdout+r.stderr);(out/(mode+'-run.json')).write_text(json.dumps({'argv':a,'cwd':str(d),'source_bindings':hashes(),'binary_sha256':hashlib.sha256(Path(a[0]).read_bytes()).hexdigest(),'exit_status':r.returncode,'elapsed_seconds':time.monotonic()-s},indent=2)+'\n');print('RUN',mode,r.returncode,(r.stdout+r.stderr).decode()[-4500:],flush=True)
 if r.returncode:sys.exit(r.returncode)
