from pathlib import Path
import json,subprocess,time,hashlib,sys
root=Path('/workspaces/uWebZockets');out=Path(__file__).resolve().parent;d=root/'.uwz-work/drafts/m2-h1-admission'
paths=['src/core/http1_upload.zig','src/tests/http1_upload_admission_tests.zig','src/http1_admission_test_support.zig']
for target in ['native','x86-linux-musl']:
 c=json.loads((root/('.uwz-work/evidence/h3-body-refusal/layout-'+target+'-baseline.command.json')).read_text());a=c['argv'];a[1]='test';a=[x for x in a if x!='-fno-emit-bin'];a=[('-Mroot=src/tests/http1_upload_admission_tests.zig' if x.startswith('-Mroot=') else '-Mtest_support=src/http1_admission_test_support.zig' if x.startswith('-Mtest_support=') else '-femit-bin=/tmp/uwz-h1-admission-'+target if x.startswith('-femit-llvm-ir=') else x) for x in a];a[a.index('--cache-dir')+1]='/tmp/uwz-h1-admission-cache';a[a.index('--global-cache-dir')+1]='/tmp/uwz-multipart-integrated-global';a.insert(2,'--test-no-exec');a.insert(3,'--dep');a.insert(4,'c');s=time.monotonic();rec={'argv':a,'cwd':str(d),'source_before':{n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in paths}}
 with (out/('width-'+target+'-compile.log')).open('wb') as f:r=subprocess.run(a,cwd=d,stdout=f,stderr=subprocess.STDOUT)
 rec.update(exit_status=r.returncode,elapsed_seconds=time.monotonic()-s,source_after={n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in paths});(out/('width-'+target+'-compile.json')).write_text(json.dumps(rec,indent=2)+'\n');print(target,r.returncode,flush=True)
 if r.returncode:print((out/('width-'+target+'-compile.log')).read_text()[-5000:],flush=True);sys.exit(r.returncode)
