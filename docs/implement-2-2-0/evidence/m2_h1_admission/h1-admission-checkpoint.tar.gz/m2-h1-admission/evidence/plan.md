# H1 pure admission preparation

Scope: implement pure physical-ingress bounds and one atomic router-reserve to BodyState.arm handoff from the accepted head/admission seam. No sink invocation, loop API, TCP/TLS hook, native teardown, public App activation or live upload claim.

Acceptance: preserve the frozen prepared App/R2 source; require inactive and unreserved common state before any quota mutation; reserve using the actual selected BodyMatch and immediately arm without I/O/callbacks; roll back only the one untransferred reservation on pure arm failure; after success BodyState boolean terminal results remain sole release authority. Preserve other concurrent reservations. Physical bounds derive tail capacity with checked subtraction, require 1 byte for positive fixed bodies and 3 for chunked, and derive chunk line content as min(H,R-2).

Test actual registration, counters, BodyState transitions/control invalidation, zero/maximum logical lengths, full quota, busy/stale state, failed arm, once-only release authority and machine-width arithmetic. Verify pure native/Linux32 and appropriate normal builds. All source remains isolated pending independent review and the full H1 consumer/lifetime prerequisites. This creates no substitute sink or new cancellation/close algorithm.
