"""Fresh caller time prevents actions after expiration or time reversal."""
import adapter
import h2_client


def check():
    current = [1]
    sent = []
    context = adapter.open_case('ready_buffered', h2_client.new_protocol(), sent.append,
                                1, 10, 20, clock=lambda: current[0])
    current[0] = 10
    try:
        adapter.flush(context)
    except ValueError:
        pass
    else:
        raise RuntimeError('expired drain accepted')
    if len(sent) != 1:
        raise RuntimeError('expired drain sent bytes')
    current[0] = 0
    try:
        adapter.flush(context)
    except ValueError:
        pass
    else:
        raise RuntimeError('backwards time accepted')
    print('fresh time checks passed')


if __name__ == '__main__':
    check()
