"""Caller-owned bounded I/O hooks paired to the reviewed codec seam."""
import cases
import catalogue
import json
import hashlib
import model
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def open_case(case, protocol, send, now, case_deadline, whole_deadline, selected_before=(), *, clock):
    cases.select((case,))
    catalogue.schedule(selected_before)
    if case in selected_before or 'shutdown_idle' in selected_before or 'shutdown_active' in selected_before:
        raise ValueError('invalid previous selection')
    if not callable(send) or not callable(clock):
        raise ValueError('send and time hooks required')
    primary = 3 if case == 'async_delayed' else 5
    case_state = output_stage.new_case(case)
    stage = output_stage.new_stage(case_state, primary, 1, case_deadline, whole_deadline)
    output_stage.remaining(stage, now)
    request = request_credit.new_state(request_credit.new_case(case))
    credit = response_credit.new_state()
    raw, records = raw_observer.new_state(), {}
    wire.bind_connection(stage, protocol, raw, request, credit, records)
    context = {'stage': stage, 'protocol': protocol, 'request': request, 'credit': credit,
               'raw': raw, 'records': records, 'trace': {}, 'send': send, 'now': now, 'selected_before': tuple(selected_before), 'completed': False, 'clock': clock}
    tick(context)
    startup = wire.startup(stage)
    tick(context)
    send(startup)
    return context


def tick(context):
    now = context['clock']()
    output_stage.remaining(context['stage'], now)
    if now < context['now']:
        raise ValueError('monotonic time moved backwards')
    context['now'] = now


def flush(context):
    while True:
        tick(context)
        data = wire.drain(context['stage'])
        if not data:
            return
        tick(context)
        context['send'](data)


def observe(context, data, now):
    output_stage.remaining(context['stage'], now)
    if now < context['now']:
        raise ValueError('monotonic time moved backwards')
    context['now'] = now
    if type(data) is not bytes or not 0 < len(data) <= 8192:
        raise ValueError('invalid bounded read')
    tick(context)
    wire.accept(context['protocol'], data, context['records'], context['raw'], context['trace'],
                credit=context['credit'], request=context['request'], stage=context['stage'])
    flush(context)


def start(context, method, path, headers, end_stream, primary, limit, middleware='required'):
    stage = context['stage']
    tick(context)
    stream, chunks = wire.start_request(stage, method, 'localhost', path, headers, end_stream,
                                        role='small', primary=primary, held=False, body_limit=limit,
                                        final_status=200, info_count=0, policy='healthy', mode='small_body',
                                        expected_sha256=None, middleware_policy=middleware)
    for chunk in chunks:
        tick(context)
        context['send'](chunk)
    return stream


def finish(context, stream, receive):
    records = context['records']
    while not records[stream]['ended']:
        tick(context)
        data, now = receive()
        observe(context, data, now)
    tick(context)
    wire.complete(records, context['raw'], stream)
    record = records[stream]
    result = {'body': bytes(record['body']), 'bytes': record['bytes'], 'sha256': record['hash'].hexdigest(),
              'headers': [(name, value) for name, value in record['headers']], 'ended': record['ended'], 'reset': None,
              'trailers': None, 'informationals': record['informationals']}
    tick(context)
    wire.retire(records, context['raw'], stream, request=context['request'], credit=context['credit'],
                stage=context['stage'])
    return result


def get(context, path, receive, primary=False, limit=4095, middleware='required'):
    return finish(context, start(context, 'GET', path, (), True, primary, limit, middleware), receive)


def send_data(context, stream, data, end_stream):
    tick(context)
    wire.send_data(context['protocol'], context['records'], context['request'], stream, data,
                   stage=context['stage'], end_stream=end_stream, pad_length=None)
    flush(context)


def health(context, receive):
    result = get(context, '/health', receive, limit=2)
    if result['body'] != b'ok':
        raise ValueError('health response differs')


def metrics(context, receive):
    result = get(context, '/metrics', receive)
    value = json.loads(result['body'])
    fields = set(model.metrics((), 'before')) | {'slot0_active', 'slot1_active'}
    if type(value) is not dict or value.keys() != fields:
        raise ValueError('metrics schema differs')
    for name, item in value.items():
        if name.startswith('slot'):
            if type(item) is not bool:
                raise ValueError('metrics slot type differs')
        elif type(item) is not int or item < 0:
            raise ValueError('metrics counter differs')
    return value


def verify_metrics(context, actual, completed):
    selected = context['selected_before'] + ((context['stage']['case'],) if completed else ())
    expected = model.metrics(selected, 'before')
    prior = context['selected_before']
    prior_metrics = model.metrics(prior, 'before')
    prior_heads = sum(catalogue.case_budget(case)['heads'] for case in prior)
    current_middleware = expected['middleware'] - prior_metrics['middleware']
    expected['buffered_middleware'] = (prior_heads - prior_metrics['middleware'] +
                                       context['stage']['case_state']['heads'] - current_middleware)
    for key, value in expected.items():
        if type(actual[key]) is not type(value) or actual[key] != value:
            raise ValueError('metrics mismatch: ' + key)
    if actual['slot0_active'] or actual['slot1_active']:
        raise ValueError('unexpected active slot')


def large_upload(context, receive):
    case = context['stage']['case']
    health(context, receive)
    before = metrics(context, receive)
    verify_metrics(context, before, False)
    contract = model.request_contract(case)
    headers = () if contract['declared'] is None else (('content-length', str(contract['declared'])),)
    stream = start(context, contract['method'], contract['target'], headers, False, True, 4095)
    count = 0
    digest = hashlib.sha256()
    while count < model.MAX_PAYLOAD:
        outbound = context['request']
        item = request_credit.stream(outbound, stream)
        available = min(8192, model.MAX_PAYLOAD - count, outbound['connection'], item['window'],
                        65535 - outbound['stream_debt_total'])
        if available == 0:
            tick(context)
            data, now = receive()
            observe(context, data, now)
            continue
        block = model.payload_span(model.MAX_PAYLOAD, count, available)
        digest.update(block)
        count += len(block)
        send_data(context, stream, block, count == model.MAX_PAYLOAD)
    if digest.hexdigest() != model.LARGE_HASH:
        raise ValueError('upload digest differs')
    result = finish(context, stream, receive)
    model.validate_item(json.loads(result['body']), model.record(case, True, 'after'))
    after = metrics(context, receive)
    verify_metrics(context, after, True)
    expected = model.record(case, True, 'after')
    for field in model.COMMON_COUNTERS + ('bytes',):
        if after[field] != before[field] + expected[field]:
            raise ValueError('upload metrics differ: ' + field)
    if after['active'] != 0 or after['paused'] != 0 or after['buffered_middleware'] != before['buffered_middleware'] + 1:
        raise ValueError('upload metrics state differs')
    health(context, receive)
    if context['stage']['case_state']['heads'] != context['stage']['limits']['heads'] or context['request']['case']['sent'] != model.MAX_PAYLOAD:
        raise ValueError('upload counts differ')


def run_case(context, receive):
    stage = context['stage']
    if context['completed'] or stage['initial_settings'] != 1 or stage['acks'] != 1:
        raise ValueError('invalid case start')
    case = stage['case']
    if case in ('large_declared', 'large_undeclared'):
        large_upload(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case == 'async_delayed':
        health(context, receive)
        result = get(context, '/delayed', receive, primary=True, limit=10, middleware='optional')
        model.validate_core_response(case, result)
        health(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case != 'ready_buffered':
        raise ValueError('case schedule not yet implemented')
    health(context, receive)
    before = metrics(context, receive)
    verify_metrics(context, before, False)
    contract = model.core_request(case)
    stream = start(context, contract['method'], contract['path'], contract['headers'], False, True, 257)
    send_data(context, stream, contract['body'], True)
    model.validate_core_response(case, finish(context, stream, receive))
    after = metrics(context, receive)
    verify_metrics(context, after, False)
    if any(before[key] != after[key] for key in before if key != 'buffered_middleware'):
        raise ValueError('buffered request changed sink totals')
    if after['buffered_middleware'] != before['buffered_middleware'] + 2:
        raise ValueError('buffered middleware count differs')
    health(context, receive)
    check_counts(context)
    context['completed'] = True


def check_counts(context):
    stage, request = context['stage'], context['request']
    limits, state = stage['limits'], stage['case_state']
    if (state['heads'], state['small'], request['case']['sent']) != (limits['heads'], limits['small'], limits['request_flow']):
        raise ValueError('case counts differ')
    if stage['active'] or context['records']:
        raise ValueError('unfinished responses')


def final_collection(context, receive):
    if not context['completed']:
        raise ValueError('case not complete')
    selection = context['selected_before'] + (context['stage']['case'],)
    tick(context)
    wire.enter_final(context['stage'])
    records = {}
    for tag, _family, _length, _terminal in model.BODY_SPECS:
        result = get(context, '/status/' + tag, receive)
        records[tag] = json.loads(result['body'])
    model.validate_records(selection, 'before', records)
    observed = metrics(context, receive)
    model.validate_metrics(selection, 'before', observed)
    tick(context)
    wire.finish_final(context['stage'])


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
