"""Actual inert imports under empty and foreign argument lists."""
import builtins
import contextlib
import importlib
import io
import sys
import catalogue
import h2_client
import hpack
import model
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def reject(*_args, **_kwargs):
    raise RuntimeError('import invoked a forbidden caller hook')


def check():
    names = ('cases', 'adapter', 'test_selection', 'test_adapter', 'test_ready', 'test_async', 'test_large', 'test_final', 'test_time', 'test_shared', 'test_imports')
    old_argv, old_open = sys.argv, builtins.open
    try:
        for argv in ([], ['foreign', '--run', 'unexpected']):
            for name in names:
                sys.modules.pop(name, None)
            sys.argv = argv
            builtins.open = reject
            out, err = io.StringIO(), io.StringIO()
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                for name in names:
                    importlib.import_module(name)
            if out.getvalue() or err.getvalue():
                raise RuntimeError('import produced output')
    finally:
        builtins.open = old_open
        sys.argv = old_argv
    print('inert import checks passed')


if __name__ == '__main__':
    check()
