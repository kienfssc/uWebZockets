"""Paired adapter startup and connection identity proof."""
import adapter
import h2_client
import wire


def rejected(call, *args):
    try:
        call(*args)
    except ValueError:
        return
    raise RuntimeError('invalid input accepted')


def check():
    sent = []
    context = adapter.open_case('ready_buffered', h2_client.new_protocol(), sent.append, 1, 30001, 900001)
    if len(sent) != 1 or len(sent[0]) != 75:
        raise RuntimeError('startup serialization differs')
    rejected(adapter.observe, context, b'', 2)
    rejected(adapter.observe, context, b'x' * 8193, 2)
    rejected(adapter.observe, context, b'x', 30001)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    packet = b'\0\0\x1e\4\0\0\0\0\0' + settings + b'\0\0\0\4\1\0\0\0\0'
    adapter.observe(context, packet, 2)
    if context['stage']['acks'] != 1 or context['stage']['initial_settings'] != 1:
        raise RuntimeError('settings accounting differs')
    stream = adapter.start(context, 'POST', '/echo', (), False, False, 257)
    rejected(adapter.send_data, context, stream, b'x' * 8193, False)
    rejected(adapter.send_data, context, stream, 'x', False)
    rejected(adapter.send_data, context, 999, b'x', False)
    try:
        wire.send_data(h2_client.new_protocol(), context['records'], context['request'], stream, b'x',
                       stage=context['stage'], end_stream=False, pad_length=None)
    except ValueError:
        pass
    else:
        raise RuntimeError('foreign protocol accepted')
    rejected(adapter.observe, context, b'x', 1)
    adapter.send_data(context, stream, b'x', True)
    rejected(adapter.send_data, context, stream, b'x', False)
    if context['request']['case']['sent'] != 1:
        raise RuntimeError('rejected DATA changed credit')
    print('paired startup and rejection checks passed')


if __name__ == '__main__':
    check()
