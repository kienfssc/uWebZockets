# Complete Task5e3b1 before independent review

Read this first, then task-5e3b1-brief.md and task-5e3b1-report.md. Preserve
the existing four schedules and adapter; do not restart from a blank rewrite.
The parent all40 scope and six-unit plan remain unchanged. B1 is not accepted.

The former implementer reported source ready with correctness/proof concerns:
multi-case selected-before state, final collection after a large case, malformed
credit/terminal sequences, and fresh caller time between observations. Root
read the actual source/report and handling-reports: resolve these before fresh
independent review, rather than deferring them to the reviewer or later runner.

## Current state and restored inputs

The original case-agent handle is authoritatively missing after the pause and
environment change. You are its replacement, not a concurrent implementer.
The working combined-cases directory persists with9 files/505lines. Root
preserved an immutable recovery copy under this plan's
task-5e3b1-recovered-source; hashes are in
task-5e3b1-root-source-restoration.json. Adapter SHA remains
861566c09e4bcf42cdb9b5e0b3af21e8e1535e7df01556ea61ca0fc13a2dd3d1.

All /tmp inputs and unpublished b1 receipts disappeared. Root verified the
committed archives/inventories and restored2516 exact source/evidence files,
including v3 model, v9 core, pinned42 codec files, fixture25, prior client12,
published runtime19 and all41 retained reference identities. See the restoration
report for exact maps and qualifications. The original unpublished b1 snapshot
and14 raw outcomes could not be recovered: its old report is historical intent,
not current acceptance evidence. Capture fresh actual results for current code.

Original pinned paths from the released addendum now exist again. Python's
actual SHA still matches4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
Only retained reference files exist under the old native-candidate path; the
complete1031-file candidate and native binaries are NOT restored or authorized.
Do not infer a native/build release from any source path's existence.

## Required completion

1. Provide an explicit caller-owned fresh-time input/hook through the adapter
   operations. Validate remaining case/whole time and monotonicity before
   each relevant read/write/action, including long upload sends, bounded
   drains and final collection. Checking only cached last-observation time
   cannot prove this. Preserve the exact original deadlines across boundaries;
   no real clock read or timeout widening is released. Prove expiry after the
   last observation prevents a subsequent I/O/codec action and backwards or
   malformed caller time is rejected. Choose the smallest clear API, with no
   forwarding-only layer or direct mutation of immutable core state.
2. Prove at least two consecutive implemented schedules with independent
   fresh codecs/ledgers and a shared synthetic application state. Check the
   selected-before metrics/records and exact per-case action counts; do not
   reset prior body state or transfer debt. Also exercise67-status+metrics
   final collection after a legitimate large selection, preserving actual
   remaining debt, parser, byte/read counters and original deadlines. Retain
   unselected defaults and no false shutdown_idle/all40 acceptance.
3. Add focused actual-codec negative proof for malformed/duplicate/unearned
   credit and unexpected response terminal/reset sequences on the earned
   adapter path. Match the intended rejection, ensure malformed decoded input
   cannot yield successful completion or continued use of a failed stage,
   and preserve valid same-connection credit/action-order controls. No second
   parser or old aggregate refund pass; keep error controls independent of
   synthetic model-generated success responses.
4. Complete source/input/request-contract checks for the four schedules;
   preserve all original exact method/path/query/header/declaration/payload/
   response/count contracts. No catalogue or model mutation or replacement.
   Keep all data bounded and no whole upload or per-DATA/per-read histories.

Every new/changed behavior requires actual RED/GREEN where appropriate and
fresh normal/-O -B -S final covering outcomes. Because the old receipts are
lost and the adapter changes across all four schedules, recapture the current
full b1 focused suite once after the last edit. Do not rerun unchanged core
or native suites. Include AST noClass/noAssert and actual inert imports of
every authored helper under empty/foreign argv with rejecting output/socket/
TLS/process/clock doubles. No uncovered temporary Python recorder.

## Ownership and release boundary

Own only existing combined-cases source/tests, new /tmp/uwz-task5e3b1-* and
the b1 report. Store current command stdout/stderr/exit evidence in a versioned
subdirectory of the owned workspace evidence directory as well as a small
immutable source snapshot, so another temporary-directory reset cannot erase
all unpublished proof. Preserve the recovery baseline and original reports.
Append completion results/failure history/source identities to the same b1
report and add a short parent-progress note. Return short status/report/tests/
concerns; Root audits actual code and evidence before fresh independent review.

You are not alone: no reverts or edits outside ownership. No agents/external
model CLI, Git/refs/pins, native builds/binaries/fixture/socket/SSLContext/TLS/
certificate/transfer/process ownership/descriptor/kernel/fault/cancel/schedule/
race/panic/leak probes or old entrypoint execution. In-memory public codecs and
explicit pure caller hooks only. Read AGENTS/CODING and the narrow relevant
skills; original role-wide native gates are not a new execution release.
Graphify before new codebase searches; provided paths are already located.
Use the command prefix in task-5e3b-release-addendum.md. Report a concrete core
contradiction to Root and continue independent paths; do not bypass it, weaken
a bound, omit required behavior or return another mapping-only handoff.
