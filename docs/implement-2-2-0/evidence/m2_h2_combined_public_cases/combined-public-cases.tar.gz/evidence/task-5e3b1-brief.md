# Task5e3b1: paired adapter and first four concrete schedules

This is a revised, smaller implementation unit within the unchanged all40
Task5e3b scope. The initial all-case assignment returned no code/tests and no
concrete blocker. Root read handling-reports and split the work, preserving
all40 in task-5e3b-unit-plan.json. Do not mark the parent complete from this
unit. Implement this concrete unit rather than stopping after source mapping.

Retain task-5e3b-release-addendum.md and its linked original brief as the exact
global interfaces/constraints. Same source-only/in-memory codec release,
immutable inputs, original worker and owned combined-cases directory. No
native/build/socket/TLS/SSLContext/process/transfer/clock/probe/old-entrypoint
execution, no edits to core/model/fixture/product/dependencies or Git, no
agents or external model CLI. Preserve the initial parent status report.

## Required implementation

1. Implement the concrete bounded case adapter against approved v9 wire.py.
   Give caller-owned context/hooks explicit contracts. Pair actual public
   startup/settings, HEADERS/DATA, bounded drain/read/observe, grants and
   retirement exactly once; no alternate raw parser/legacy aggregate refund.
   Preserve independent case/connection state, exact counters, inherited
   deadlines and bounded records/hashes. Add only seams used by these actual
   schedules; no placeholders or speculative framework for later families.
2. Implement ready_buffered, async_delayed, large_declared and
   large_undeclared from the authenticated source/model contracts. Preserve
   exact per-case J/C/R and source action order. Ready is the257-byte binary
   echo with unchanged sink totals; async is exact delayed-ok/content-type/END
   without an invented middleware guarantee. Both100000000-byte uploads use
   the canonical bounded payload generator/hash and their correct declaration
   policies, with one DATA-bearing stream and legitimate independent credit.
   Start/end health and observation counts remain the accepted catalogue's.
3. Prove actual serialized action order and exact counts through the public
   codec/bound adapter. Cover legitimate request/response bytes/hashes and
   rejection of malformed types/oversized spans, wrong public/stream identity,
   unexpected terminal/credit and deadline misuse where these paths use them.
   Keep data bounded; no upload body or per-DATA/per-read history retention.
   Synthetic peers/JSON are qualified pure input, not native fixture evidence.
4. This unit may expose an explicitly implemented four-case dispatch surface.
   It must never silently treat the subset as the full40 default: unimplemented
   catalogue selections fail clearly before actions, and parent default/all40
   acceptance stays open. Do not create fake successful handlers for other IDs
   or change the immutable catalogue. Later units reuse this earned adapter.

Use the reviewed model's validators and final fixture schemas for observations;
do not copy a second expected-state model. Final collection support, if needed
by the concrete adapter, uses existing wire.enter_final/finish_final and the
unchanged67-status+metrics contract under the same deadline. Do not claim a
partial selection earned shutdown_idle or combined40 acceptance.

If a specific core/source interface makes one of these four paths impossible,
report its exact failing pure call/required behavior and continue independent
paths. Do not change core, bypass its invariants or lower the bar. Routine
reversible implementation/API choices are yours; no general redesign or
requirements interview is needed.

## Proof and handoff

Use narrow TDD increments, actual new-behavior RED/GREEN and final normal/-O
-B -S covering commands. Every authored executable helper, including any new
temporary recorder, has a main guard and actual empty/foreign-argv silent import
proof. No authored classes/inheritance/custom exception classes or asserts.
Keep modules cohesive, snapshots small/immutable, no unrun-success claims.

Own new /tmp/uwz-task5e3b1-* in addition to the existing combined-cases source.
Write task-5e3b1-report.md with code/APIs/source bindings, all actual commands,
raw outcomes and failure history, final source identity, self-review and precise
remaining facts. Append a short parent-report note referencing this unit;
parent stays incomplete. Root independently reviews this unit before the next
one. Do not substitute another read-only handoff for the requested code/proof.
