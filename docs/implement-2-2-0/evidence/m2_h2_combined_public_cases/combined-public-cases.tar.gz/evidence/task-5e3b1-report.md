# Task 5e3b1 source preparation

Four schedules are implemented for independent review, not accepted as the all40 run. The synthetic peer and in-memory codecs are not native fixture evidence. `cases.py` checks selections against the immutable catalogue and calculates case/whole deadlines in caller-supplied integer units. `adapter.py` binds the reviewed v9 wire seam to caller-owned send/receive hooks, runs the four schedules, and provides final collection. It checks the actual case heads, small responses and request flow and validates records/metrics against the immutable model. The large cases use `model.payload_span` and SHA `190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2`, one DATA-bearing stream, and separate connection/stream credit. Ready checks exact echo and unchanged sink totals; delayed permits absent middleware and verifies `text/plain`.

Files are in `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`. Snapshot `/tmp/uwz-task5e3b1-snapshot/source` is read-only; SHA-256 inventory is `/tmp/uwz-task5e3b1-snapshot/sha256.txt`. Core wire SHA `25d32260dabf3d7a603bf9a2269f7bd4f80bb07ce10f7127e7689242e52b6a86`, catalogue `7fa639c9372c8f01002fefba3647b2f82381e798484441d4b46c20d5d732453d`, model `ebb6164c01617045b6120a00977aeae88609053318f89b1891d9ede5c89b8175`; other retained identities are in `task-5e3b-input-audit.json`.

## Commands and results

TDD RED used the command below with `TEST` set respectively to `test_selection`, `test_adapter`, `test_ready`, `test_async`, `test_large`, and `test_final` before implementing that behavior. Raw stdout/stderr/exits are `/tmp/uwz-task5e3b1-proof/{red,adapter-red,ready-red,async-red,large-red,final-red}.{stdout,stderr,exit}`; each exited 1, respectively with missing `cases`, missing `adapter`, missing `run_case`, unimplemented schedule, unimplemented schedule, and missing `final_collection`. Initial ready GREEN failed model header validation because public header tuples had a subclass type; explicit tuple conversion fixed it. Initial final GREEN failed because synthetic metrics incorrectly counted ready as a body middleware request; the peer calculation was corrected. Those raw results are retained as `ready-green.*`, `ready-green2.*`, `final-green.*`, and `final-green2.*`.

Final test loop, executed once in each mode after the last source edit:

```sh
for mode in normal optimized; do
  for test in test_selection test_adapter test_ready test_async test_large test_final test_imports; do
    if [ "$mode" = optimized ]; then flag=-O; else flag=; fi
    PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:.uwz-work/evidence/h2-streaming/integration-client:.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 $flag -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/$test.py > /tmp/uwz-task5e3b1-proof/release-$mode-$test.stdout 2> /tmp/uwz-task5e3b1-proof/release-$mode-$test.stderr
    printf '%s\n' "$?" > /tmp/uwz-task5e3b1-proof/release-$mode-$test.exit
  done
done
```

All 14 exits were `0`, all stderr files empty. Each mode's outputs, in test order, were:

```text
selection and deadline checks passed
paired startup and rejection checks passed
ready_buffered codec schedule passed
async_delayed codec schedule passed
large_declared codec schedule passed
large_undeclared codec schedule passed
ready_buffered codec schedule passed
inert import checks passed
```

The import test imports each authored module with empty and foreign argv, output capture and a rejecting `open` double. The synthetic peer supplies HPACK/framing input and per-scope refund frames; no networking, native build, fixture, subprocess ownership, clock read, or old entrypoint was executed.

## Self-review and remaining facts

These checks cover startup, the four single-case schedules, declaration policies, both large payload hashes, final 67+metrics for ready, selected malformed inputs, foreign codec identity, and empty/foreign-argv imports. They do not yet prove a multi-case selected-before transition, final collection for a large selection, rejection of every malformed credit/terminal sequence, or the full caller-time progression during long sequences: the adapter tracks the last caller time supplied on observations and cannot itself observe elapsed time between them. These gaps require independent review and targeted tests before treating b1 as accepted. The parent all40 default, other 36 schedules, independent review, and the separately released runtime closure remain outstanding. No global Zig/build matrix was run because this source-only release explicitly forbids native builds.

## Completion work in progress: caller-time boundary

The earlier proof was lost and is historical only. The current adapter now requires a keyword-only `clock` callable supplying synthetic caller-owned integer time. It checks the inherited stage deadlines and monotonicity before startup serialization and send, each drain and send, read callbacks, accepting decoded input, request serialization and header send, DATA serialization, completion/retirement and final-boundary actions. No actual clock is read. The initial regression in `test_time.py` failed with `TypeError: open_case() got an unexpected keyword argument 'clock'` (exit 1); after the change it printed `fresh time checks passed` (exit 0). This test proves expired and reversed time before drain, but does not yet prove every required boundary or malformed clock value. The hook name refers to caller input, not an actual clock operation.

Raw stdout/stderr/exit files and a read-only source snapshot with SHA-256 inventory are under `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v1/`. The full current focused suite was run in both normal and optimized modes with the same environment/prefix as the original report, adding `test_time` to the test list. All 16 commands exited 0 with empty stderr. An additional `-B -S -c "import test_ready; test_ready.check('large_declared', final=True)"` invocation using the same PYTHONPATH exited 0 and printed `large_declared codec schedule passed`. This invokes the actual in-memory codec path; it does not yet independently prove the carried-debt and counters invariants required by the completion brief.

Exact loop used:

```sh
for mode in normal optimized; do
  for test in test_selection test_adapter test_ready test_async test_large test_final test_time test_imports; do
    if [ "$mode" = optimized ]; then flag=-O; else flag=; fi
    PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:.uwz-work/evidence/h2-streaming/integration-client:.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 $flag -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/$test.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v1/$mode-$test.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v1/$mode-$test.stderr
    printf '%s\n' "$?" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v1/$mode-$test.exit
  done
done
```

This is incomplete: selected-before shared-state consecutive schedules, explicit final debt/parser/counter invariants, malformed credit and terminal sequences, complete request-contract checks, stronger inert import doubles and AST proof, and thorough fresh-time boundary regressions remain required. The full b1 acceptance and parent all40 remain open. The focused suite must be rerun after the remaining edits. No native or Zig build was run under this source-only release.

## Completion increment: consecutive schedules and final carried debt

`test_shared.py` runs ready_buffered and large_declared in order with fresh public codec, request/response ledgers, parser and stage per connection and one caller-owned synthetic application. The application derives its metric counters from actual accumulated synthetic records and request heads; the large record is populated from the observed bounded DATA stream and its digest. Immutable model defaults and validators are used for the record schema and expected selection; no successful upload record is supplied from the model. It verifies the two ordered five-request schedules, exact J/C/R `(5,5,257)` and `(5,5,100000000)`, primary HEADERS including declarations, echo bytes, canonical upload hash, prior-state metrics, untouched records and separate ledgers. Ready's actual 257-byte debt remains on its connection while the next connection begins with no debt.

The synthetic peer withholds the final DATA refund until final collection. Entry captures the actual stage bytes/reads, parser/ledger identity, both deadlines, and actual debt. It verifies `catalogue.final_budget` from those amounts when the first final HEADERS arrives. A complete connection WINDOW_UPDATE and the first five bytes of the stream WINDOW_UPDATE are coalesced into one bounded read; the next read contains the remainder and the first status response. Before that second read it checks the parser's partial header, zero connection debt and unchanged stream debt. After all 67 status requests and metrics, it verifies ordered paths, zero debt, exhausted pending peer input, clean parser, unchanged deadlines, cumulative stage/case bytes and reads and model validation of all selected and unselected records. The final byte and read counts are measured synthetic codec observations, not fixture or performance measurements.

Fresh normal and optimized targeted results each exited 0 with empty stderr and stdout:

```text
entry debt connection=1781 stream=1781 budget=3110658; final bytes=28992 reads=69; upload frames=12208
shared schedules and carried final boundary passed
```

A negative control temporarily replaced `selected_before=prior` with `selected_before=()` in the same test. It exited 1 with `ValueError: metrics mismatch: buffered_middleware` before upload. Restoring the selected-before input produced the above results. This is a deliberate sensitivity control, not a pre-fix regression failure: this increment added proof for existing adapter behavior and did not change the adapter. The initial attempt to execute the not-yet-created test also exited 2; it is not counted as behavioral RED. `test_imports.py` now includes the new guarded helper; both modes exited 0 with `inert import checks passed`, under its existing empty/foreign argv and output/open doubles. The wider socket/TLS/process/clock import doubles remain a separate outstanding requirement.

Exact targeted and import commands (the output path is the owned `completion-v2` directory):

```sh
for mode in normal optimized; do
  if [ "$mode" = optimized ]; then flag=-O; else flag=; fi
  PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:.uwz-work/evidence/h2-streaming/integration-client:.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 $flag -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shared.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v2/$mode.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v2/$mode.stderr
  printf '%s\n' "$?" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v2/$mode.exit
done
for mode in normal optimized; do
  if [ "$mode" = optimized ]; then flag=-O; else flag=; fi
  PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:.uwz-work/evidence/h2-streaming/integration-client:.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 $flag -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v2/$mode-imports.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v2/$mode-imports.stderr
  printf '%s\n' "$?" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v2/$mode-imports.exit
done
```

All current raw outputs/exits, the negative control and a read-only source snapshot with SHA-256 inventory are in `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v2/`. Core/model/fixture were unchanged; their identities remain those in the earlier report. No adapter API changed in this increment and no earlier evidence was overwritten. No native execution or unrelated core suite was run. The missing malformed-credit/terminal proofs, fuller fresh-time checks, AST and comprehensive inert import proof remain mandatory before b1 review; all40 acceptance remains open.

## Completion increment: malformed input, caller time and contracts

`test_negative.py` exercises fresh paired adapter/public-codec contexts. It checks zero and excessive unearned connection and stream refunds, duplicate/excess refunds after an earned refund, DATA/END before final HEADERS, unexpected resets, duplicate DATA/END and reset after terminal, and a decoded wrong final status. Each check matches the intended error, checks failed state or failed completion, and prevents further use; a separate same-connection control applies valid connection and stream refunds and completes a valid response. No separate parser or refund pass was added.

`test_time.py` checks expiry after settings observation before drain, headers, DATA and read callback; malformed boolean, string, None and negative values and backwards time; and a legitimate increasing-time DATA action. It also checks expiry before final entry and after entry before the first final observation, preserving deadlines and forbidding a read or header action. A second context has equal case and whole deadlines. All time is supplied by the caller; no actual clock is read. `test_ready.py` now checks every serialized request's exact method, scheme, authority, path, header values and multiplicity, HEADERS end flag, and primary DATA/end actions across all four schedules, in addition to the prior response and bounded payload/hash checks. Its `clock` and `after_case` arguments are test-only seams used for the final-time check; the adapter API did not change in this increment.

`test_imports.py` inventories every directly owned Python module, parses each for authored classes and assertions, checks for a top-level main guard, and imports each with empty and foreign argv. During actual imports, output writes, file open, socket construction, TLS context construction, subprocess entry points, OS process/output entry points and real-time functions use rejecting doubles. This does not execute old entrypoints, a network, or native code. Standard-library and pinned codec classes are not authored here.

The prior completion-v2 source and proof are retained. The first run of the new negative test and the initial time/import/ready/async/large/final tests all exited 0: these are added proofs of already implemented behavior, not pre-fix REDs. For a sensitivity control only, the `output_stage.remaining` call in adapter `tick` was temporarily removed and `test_time.py` exited 1 with `RuntimeError: invalid caller time accepted`; the original adapter was restored byte-for-byte before the final run. This is a deliberate mutation control, not a claim that the current adapter originally failed. The earlier v1 actual pre-implementation RED/GREEN remains historical evidence of the fresh-time API change.

After the final source edit, the following loop ran once. All 20 exits were 0 and all stderr files were empty; raw stdout, stderr and exits are in `completion-v3/current-*`. Normal and optimized stdout in test order was:

```text
selection and deadline checks passed
paired startup and rejection checks passed
ready_buffered codec schedule passed
async_delayed codec schedule passed
large_declared codec schedule passed
large_undeclared codec schedule passed
ready_buffered codec schedule passed
ready_buffered codec schedule passed
fresh time checks passed
entry debt connection=1781 stream=1781 budget=3110658; final bytes=28992 reads=69; upload frames=12208
shared schedules and carried final boundary passed
credit and terminal rejection checks passed
AST and inert import checks passed
```

```sh
for mode in normal optimized; do
  for test in test_selection test_adapter test_ready test_async test_large test_final test_time test_shared test_negative test_imports; do
    if [ "$mode" = optimized ]; then flag=-O; else flag=; fi
    PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:.uwz-work/evidence/h2-streaming/integration-client:.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 $flag -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/$test.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v3/current-$mode-$test.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v3/current-$mode-$test.stderr
    printf '%s\n' "$?" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/completion-v3/current-$mode-$test.exit
  done
done
```

The read-only `completion-v3/snapshot-current` and `snapshot-current.sha256` identify the final 12 authored modules; the earlier v3 `snapshot` predates the equal-whole-deadline test and is historical. Core wire, catalogue, model, fixture and codec inputs remain unchanged from their identities above. This is synthetic in-memory proof, ready for the root's independent source/evidence review; it does not establish native behavior or b1 acceptance. The other 36 cases, full all40/default acceptance, native execution and runtime closure remain outstanding. No native or unrelated core tests were run under this release.

## Fix 1: required nesting correction

The independent initial review identified a mandatory convention violation in `test_shared.py`: the terminal upload-DATA branch was nested beneath the frame loop, DATA branch and upload branch. Extracted that accounting and refund decision into `record_upload(peer, payload, stream, terminal)`, with explicit arguments and an early return. Inspection of `send` now gives at most the frame loop, frame-kind branch and upload branch on that path; the helper's terminal guard is at its own function level. No adapter, core, model, catalogue, fixture, count, timeout or test expectation was changed.

The current 12-file snapshot and SHA-256 inventory are retained in `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/fix-1/`. `comparison.txt` compares each file to `completion-v3/snapshot-current`: only `test_shared.py` differs. The v3 results remain historical for the earlier source. This convention-only change did not require an invented behavioral RED.

After the edit, the exact four covering commands were run via:

```sh
for mode in normal optimized; do
  for test in test_shared test_imports; do
    if [ "$mode" = optimized ]; then flag=-O; else flag=; fi
    PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:.uwz-work/evidence/h2-streaming/integration-client:.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 $flag -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/$test.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/fix-1/$mode-$test.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/fix-1/$mode-$test.stderr
    printf '%s\n' "$?" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/fix-1/$mode-$test.exit
  done
done
```

All four exited 0 with empty stderr. Each `test_shared` mode printed:

```text
entry debt connection=1781 stream=1781 budget=3110658; final bytes=28992 reads=69; upload frames=12208
shared schedules and carried final boundary passed
```

Each `test_imports` mode printed `AST and inert import checks passed`. These checks retain the earned split/coalesced refund and final metrics validation. No full suite or native run was made for this scoped fix. The root and original reviewer must still inspect this correction; native runtime and all40 acceptance remain open.
