# Finish b1 negative, time and inert proof before fresh review

Root read the completion-v2 report and actual test_shared.py, checked all4
normal/O targeted/import raw outcomes (0/empty stderr), its selected-before
sensitivity failure, and all11 snapshot/current hashes. Requirement2's bounded
increment is complete as pure synthetic proof, not native or all40 acceptance.
Preserve it unchanged unless a concrete new concern requires an edit.

Finish the remaining concrete requirements3/4 and missing time/inert/AST proof
from task-5e3b1-completion-brief.md. This is the next changed, bounded assignment
after the previous partial handoff. Keep the actual four schedules and all
original per-case contracts; don't stop with the same unresolved checklist.

- On the actual earned adapter/public-codec path, cover zero, unearned and
  duplicate/excess refund rejection with independent valid credit controls.
  Cover unexpected response reset/terminal or DATA/END before valid final
  headers. Match the intended failure and verify failed decoded input cannot
  complete a response or reuse a failed stage. Use bounded synthetic bytes,
  no native fault or scheduling experiment and no duplicate parser/refund pass.
- Extend caller-time proof beyond drain: expiry after last observation must
  prevent subsequent read callback, header or DATA serialization/send and
  final-boundary/final-observation actions. Include malformed int/bool/string
  and backwards values plus a legitimate increasing-time control. Keep the
  same original case/whole deadlines, including final collection. No real
  clock reads. Use the smallest actual boundary tests; don't mirror constants.
- Verify the exact request/response contracts used by all four schedules;
  don't infer declarations, headers or metadata from a response role. The
  shared proof already validates selected-before/actual byte/hash behavior.
- Replace/extend current test_imports.py with complete current-source AST
  noClass/noAssert, main-guard checks for executable helpers and actual silent
  imports under empty/foreign argv with rejecting output/socket/TLS/process/
  real-clock doubles. Cover every authored module, including any new helper
  or temporary recorder. Imported standard-library/official-codec classes
  remain allowed; no authored classes/custom exceptions/assert proof statements.

Capture new-behavior RED/GREEN as appropriate and exact targeted commands/raw
stdout/stderr/exits. After the final edit, recapture the current full b1 focused
suite once in pinned normal and -O -B -S, since shared adapter/import behavior
is involved. Existing core/model/native suites are not released for rerun.
Durable versioned owned workspace evidence and small immutable snapshot are
required; preserve v1/v2 and recovered original baseline. Identify historical
versus covering results honestly.

Append a complete current b1 report with APIs/source maps, exact commands,
failure history, self-review and precise later work. Return ready-for-review
only after the b1 requirements are implemented/proved, or name the exact
blocking source/call contradiction while completing independent items. The
remaining36 schedules, all40 aggregate/default acceptance, runtime closure and
native execution remain outside this increment and still required overall.

Original owner/scope unchanged: no external edits/reverts, agents/model CLI,
Git/refs/pins, core/model/fixture mutation, native build/binary/socket/SSLContext/
TLS/certificate/transfer/process ownership/descriptor/kernel/fault/cancel/
schedule/race/panic/leak/real-clock work or old entrypoint execution. Explicit
caller-owned data/hooks and pinned in-memory public codecs only. Root audits
actual source/evidence, then assigns fresh independent review.
