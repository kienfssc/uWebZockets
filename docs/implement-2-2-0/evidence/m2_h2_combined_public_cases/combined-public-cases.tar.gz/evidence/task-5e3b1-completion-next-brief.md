# Next bounded completion increment: shared state and carried final boundary

Resume the existing completion owner and code. Root read your partial report,
current source and all16 durable focused normal/O outcomes plus the additional
large-final outcome; all17 actual captured outcomes exit0/empty stderr. This
is progress, not b1 acceptance. Do not repeat the same broad assignment: this
increment is ONLY completion requirement2 in the original completion brief.
Requirements3 and remaining time/import/AST proof still follow before review.

Implement and prove a real consecutive implemented-case sequence, such as
ready_buffered then large_declared, with separate fresh codecs/ledgers and
shared caller-owned synthetic application state. Source-selected previous
records/metrics must persist; no debt or protocol state may transfer between
connections. Check actual request order, exact per-case J/C/R and headers,
both logical payload/hash and prior-state/default invariants. Do not simply
feed model totals as a substitute for exercising the two schedules.

Then collect all67 statuses plus metrics on the last large case connection
using the existing adapter/wire path. Exercise legitimate nonzero outstanding
request debt at entry using bounded peer refund ordering; do not fabricate
ledger counters. Assert the exact budget derived from actual remaining debt,
same parser/ledgers/deadlines and cumulative bytes/read counters across entry,
ordered single application of later refunds and eventual valid final state.
Use legal split/coalesced frames to cover an earned parser-boundary concern;
no native scheduling experiment is implied. Keep final default/unselected
records and exact selection metrics. No extra observation requests/polls.

Use the immutable model and canonical payload, but retain clear labels that
peer records/transport outcomes are synthetic. A bounded test-only shared peer
may replace the current one-case test helper where necessary; reuse the public
codec/wire path and avoid an unbounded parser framework, per-DATA histories or
whole-upload retention. Add only seams this actual sequence uses. No core,
model, fixture, count, capacity or deadline changes.

Actual new RED/GREEN where behavior is missing, then the targeted shared-state/
large-final tests in normal/-O. If a shared helper changes, run the existing
ready/async/large/final scripts that depend on it; no unrelated core/native
suite rerun. Capture separate stdout/stderr/exits under a new versioned owned
workspace evidence directory with a source snapshot. All authored helpers
remain guarded and inert on import; no classes/custom exceptions/asserts.

Append exact changed APIs/files, commands/outcomes, source identities, failures
and remaining facts to the same b1 report. Complete this concrete increment
before returning a handoff; if a specific source/API contradiction prevents it,
report the exact call/required invariant and continue independent assertions.
Root will separately release the remaining negative/time/inert proof, then
fresh independent review. Full b1 and all40 parent remain incomplete until
all acceptance passes.

Original ownership and source-only boundary are unchanged: no agents/external
model CLI/Git/native/build/socket/TLS/SSLContext/transfer/process ownership/
descriptor/kernel/fault/cancel/schedule/race/panic/leak/real-clock work or old
entrypoint execution. You are not alone; preserve all other edits and inputs.
