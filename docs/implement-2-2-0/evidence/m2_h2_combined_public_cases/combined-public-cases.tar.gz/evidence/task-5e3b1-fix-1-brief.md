# Task5e3b1 mandatory nesting correction

Read task-5e3b1-review-report.md. The complete report is saved verbatim in
substance; the sole actionable finding is reproduced below.

Minor - Required convention correction: test_shared.py:99 exceeds the
mandatory three-level control-flow limit. Processing the final large-upload
DATA frame follows while at line75 -> DATA branch at line90 -> upload branch
at line92 -> terminal branch at line99. This concrete exercised path therefore
fails CODING_CONVENTION.md section7.6 despite the passing behavioral tests.
Extract the upload accounting/refund decision into a focused helper, or flatten
frame dispatch, preserving the earned-debt assertions and existing bounds.

Root ruling: the skill normally defers Minor findings, but user AGENTS and
CODING explicitly reject every mandatory convention violation. Apply this
small correction now without inflating its severity or expanding the scope.

Own only the required test_shared.py refactor in the existing combined-cases
directory, its durable evidence/fix-1/ snapshot/raw proof and an appended fix
section in task-5e3b1-report.md. Preserve all12 current source modules in the
fix snapshot and their hash map, comparing against completion-v3/snapshot-current.
Do not change the adapter, model, catalogue, core, fixture, bytes, counts,
capacities, timeouts, native sources or behavior. You are not alone; do not
revert any other work. Original no-native/no-agents/no-Git scope remains.

Run only covering test_shared.py and test_imports.py, each in normal and
optimized modes with the same pinned Python/-B -S/environment; capture the
four actual stdout/stderr/exit outcomes durably after the final edit. This is
a behavior-preserving convention correction, so do not invent a behavioral
RED or rerun all20. Preserve all earlier evidence; do not relabel it as
amended-source proof. Confirm exercised split/coalesced debt and retained
final metrics still match. Inspect final control flow for the mandatory limit.
No new reusable recorder/helper executable outside covered source.

Append changed-file/scope/commands/raw outputs/current identity/self-review
to the same report, then return status/report location/four-command summary.
Root will read the actual diff and evidence before the same reviewer verifies
only this correction and new breakage. Do not edit public delivery files.
