# Fresh independent review: Task5e3b1

Review this four-schedule unit's spec and quality, not the unfinished all40
parent. Read task-5e3b1-brief.md, the release-addendum's global interfaces and
task-5e3b1-completion-brief.md/next/final briefs for its exact acceptance.
Then read the complete task-5e3b1-report.md and task-5e3b1-review-source.diff.
The report is a claim to check, including all appended completion results.

## Exact source/evidence view

Gitbase/currentHEAD e8cc957e1a22022de13fd342c46db6e4c2831825. Owned ignored
source is not yet a Git commit. The supplied full added-file diff includes all
12 current modules/921 lines,45836bytes, SHA256
f25f26ad9585812eb8e3ee192172eb905bc9f24d0cd45c76c54b5a58a80f5932.
Do not generate an empty Git range or re-read unchanged files without a named risk.

Frozen source is owned combined-cases/evidence/completion-v3/snapshot-current;
the earlier v3 snapshot predates the last time test and is historical. Root
read the report/current adapter/case code/actual shared, negative, time, contract
and import proof. Root verified all12 frozen/current hashes and all20 current
normal/O stdout/stderr/exit outcomes (0/empty stderr). See
task-5e3b1-root-final-audit.json and the named raw current-* files in v3.

Earlier v1/v2 proof and snapshots are durable. The original unpublished14
receipts and /tmp snapshot were lost; the report labels that history. Root
restored exact model/core/codecs/reference inputs from committed archives,
checked all inventories and preserved the recovered initial working source.
See task-5e3b1-root-source-restoration.json. No full native candidate/binary
was restored, and no native execution is released by those reference paths.

## Binding scope

The unit implements a bounded explicit-hook adapter and ready_buffered,
async_delayed, large_declared, large_undeclared. Full40/default/aggregate and
the remaining36 schedules remain later required work. Model/catalogue remain
immutable; selected unsupported cases must fail clearly before actions.

The original requirements bind exact per-case J/C/R, declarations, headers,
method/path/query/response/payload hashes, unchanged sink counters for public
routes, independent per-case codecs/credit, selected-before state, bounded
spans/records/counters, inherited case/whole deadlines and no silent fallback.
The approved v9 wire path is the sole authoritative action/observation/parser/
credit/retirement path; the adapter cannot replay aggregate refunds or bypass it.

Completion proof requires fresh caller-owned integer time before relevant
read/write/actions, legitimate increasing time and rejection at expiry or
malformed/reversed time; a consecutive shared synthetic app with independent
connections; actual earned nonzero debt and parser/counter/deadline preservation
through67+metrics final collection; malformed/duplicate/unearned credit and
unexpected terminal/reset rejection; AST/guard checks and actual empty/foreign
argv silent imports with rejecting caller doubles for all authored helpers.
Keep current budgets/deadlines/capacities unchanged and no whole-upload or
per-DATA/per-read history. Public codec/stdlib objects are allowed; no authored
classes/custom exception classes/assert proof statements or hidden mutable globals.

All peer records and outcomes are synthetic/pure; this is not native fixture,
TLS/socket/process cleanup, performance or all40 acceptance evidence. Original
native build/run/socket/SSLContext/transfer/descriptor/kernel/fault/cancel/
scheduling/race/panic/leak/real-clock prohibitions remain. No native tests,
entrypoints or core/model/fixture mutations are authorized by this review.

## Method and output

Read-only: no edits, Git mutations, agents or external model CLI. Read AGENTS,
CODING and reviewer instructions; apply code-review-and-quality and the Root-
requested thermo-nuclear structural lens under AGENTS overrides. Inspect the
provided diff once; outside-source checks require a named concrete risk and a
focused existing locator. Graphify before a new codebase search; provided paths
are located. Do not rerun passed tests/imports; if a specific doubt needs a new
focused check, report the need and why existing evidence doesn't answer it.

Return SPEC COMPLIANCE and TASK QUALITY verdicts, concrete strengths/locators,
actionable Critical/Important/Minor findings with file:line/failure scenario,
and cannot-verify items. Root stores your full final report. No milestone or
parent completion claim. Whole-branch review and native acceptance remain later.
