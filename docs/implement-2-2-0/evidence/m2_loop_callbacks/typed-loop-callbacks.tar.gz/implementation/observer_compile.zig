const support = @import("test_support");
const core_loop = support.loop;
const xev = @import("xev");

export fn check_cancel_ack(owner: *core_loop.Loop, result: *const (xev.CancelError!void)) void {
    const handle = core_loop.LoopHandle{ .owner = owner };
    _ = handle.cancel_ack(result.*);
}

export fn check_callback_failure(owner: *core_loop.Loop) noreturn {
    const handle = core_loop.LoopHandle{ .owner = owner };
    handle.fail_callback(.{ .retirement = error.Canceled });
}
