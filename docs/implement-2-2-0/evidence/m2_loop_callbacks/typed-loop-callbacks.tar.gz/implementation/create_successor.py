from pathlib import Path
import hashlib
import json
import shutil

root = Path('/workspaces/uWebZockets')
base = root / '.uwz-work/drafts/m2-body-app'
successor = root / '.uwz-work/drafts/m2-loop-callbacks'
out = Path(__file__).resolve().parent
excluded = {'.git', '.zig-cache', 'zig-out', 'zig-pkg', 'graphify-out', '__pycache__'}

def manifest(directory):
    files = {}
    for path in directory.rglob('*'):
        relative = path.relative_to(directory)
        if any(part in excluded for part in relative.parts):
            continue
        if path.is_symlink():
            files[str(relative)] = {'symlink': str(path.readlink())}
        elif path.is_file():
            files[str(relative)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return files

before = manifest(base)
shutil.copytree(base, successor, symlinks=True, ignore=lambda directory, names: set(names) & excluded)
after = manifest(base)
copied = manifest(successor)
if before != after or before != copied:
    raise SystemExit('base changed or copy did not preserve identity')
(out / 'copy-manifest.json').write_text(json.dumps({
    'base': str(base), 'successor': str(successor),
    'excluded_names': sorted(excluded),
    'base_unchanged': before == after,
    'copy_identical': before == copied,
    'file_count': len(before), 'files_sha256': before,
}, indent=2) + '\n')
provenance = json.loads((out.parent / 'immutable-libxev-input.json').read_text())
export = Path(provenance['path'])
for name, expected in provenance['files_sha256'].items():
    if hashlib.sha256((export / name).read_bytes()).hexdigest() != expected:
        raise SystemExit('immutable export hash mismatch: ' + name)
(out / 'override-provenance.json').write_text(json.dumps({
    'input_manifest': str(out.parent / 'immutable-libxev-input.json'),
    'input_manifest_sha256': hashlib.sha256((out.parent / 'immutable-libxev-input.json').read_bytes()).hexdigest(),
    'commit': provenance['commit'], 'tree': provenance['tree'],
    'path': str(export), 'verified_files': len(provenance['files_sha256']),
    'compiler_module_argument': '-Mxev_impl=' + str(export / 'src/main.zig'),
    'root_zon_views_sha256': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in [
        'build.zig.zon', 'build.zig.zon.json', 'build.zig.zon.nix', 'build.zig.zon.txt',
    ]},
}, indent=2) + '\n')
print('Copied', len(before), 'files; base unchanged; verified', len(provenance['files_sha256']), 'immutable dependency files')
