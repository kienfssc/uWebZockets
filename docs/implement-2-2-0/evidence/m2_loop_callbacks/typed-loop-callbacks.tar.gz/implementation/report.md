# Loop callback policy slice

The two successor source files are frozen for independent review. This slice
adds typed cancellation acknowledgement and fatal callback-failure entry
points only. R3 activation, target lifetime algorithms, TCP/storage/App changes,
physical close decisions, root exports and dependency adoption remain outside
scope. No staging, commits, refs, publication or pins changed.

## Isolated source and dependency provenance

Base: `/workspaces/uWebZockets/.uwz-work/drafts/m2-body-app`.
Successor: `/workspaces/uWebZockets/.uwz-work/drafts/m2-loop-callbacks`.

`create_successor.py` copied 905 files with an exact SHA256 identity manifest.
It excluded `.git`, `.zig-cache`, `zig-out`, `zig-pkg`, `graphify-out` and
`__pycache__`. The successor has no copied dependency symlink, build output,
cache or Git directory. `final/source-audit.json` proves the complete base is
unchanged, exactly the two assigned successor files differ, and there are no
extra successor files. The other 903 copied files remain identical.

Every recorded test/compiler command uses the explicit module argument:

```text
-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig
```

That immutable 93-file export is commit
`c223bd886c6a51d2cd60def39dd9a68d701fea73`, tree
`86c6944f53dc009d7503a9ab0bc873aef3cd7b79`. Its complete hashes were verified
before and after the slice. The original input manifest is
`../immutable-libxev-input.json`; `override-provenance.json` binds that manifest,
the exact compiler override, and all four original root zon-view hashes.
The final audit verifies those root views are unchanged. The successor's zon
views also remain exact copies of the base. No local build overlay, manifest
override, pin edit or copied replacement dependency was introduced.

Commands derive from the existing prepared body-app module graph and foreign
translation records. Native libraries and generated C inputs are reused with
their actual file hashes recorded by the final verification runner. All
compiler commands use the exact Zig 0.16.0 binary
`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`, `-j2`,
and existing `/tmp` caches. The full compiler argv, working directory,
environment, source hashes and available input hashes are in each check JSON.

## Changed files and frozen identity

| Source | Base SHA256 | Frozen SHA256 |
| --- | --- | --- |
| `src/core/loop.zig` | `0c239030cb26533deebf81a83a8521309918e8fcfc0f004e46c4c121d2c0b222` | `74c4e5b8bc3a624e3b7ce5ce3db6268eb644276b0480fe13c5161372967b93f2` |
| `src/tests/core_tests.zig` | `90b46674623f1eb55c59e67735013b912c554c5724c6e863d5451d776089f6d5` | `b0df5ca9a50c8488519925ce6fd34b7893e0ad9824ff4cc96ff69bf7515c039a` |

`final/complete.diff` SHA256:
`3c2e33a75a93e3015061e2b48158f813d15aa6bac9f6d9bb432281010da280a6`.
Full snapshots are retained under `preimage/`, `declaration-red/`,
`behavior-red-compile-attempt/`, `behavior-red/`, and `final/`.

`core/loop.zig` adds the exact named `CancelAck` enum and flat
`CallbackFailure` union from the accepted contract. The actual production
`cancel_ack_decision` is pure and uses the platform's closed `xev.CancelError`
input and output set. Its policy is:

| Backend/result | Decision |
| --- | --- |
| epoll success | `abandon_target` |
| epoll `NotFound` | `retain_target` |
| io_uring success, `NotFound`, `ExpirationInProgress` | `retain_target` |
| kqueue / IOCP success | `retain_target` |
| Every other representable error | Return the same error |

Neither acknowledgement grants socket close permission. Retain leaves any
existing target flag unchanged and cannot reacquire it. The code does not
mutate target state or close a descriptor.

`LoopHandle.cancel_ack` checks its owner's existing healthy-fence invariant,
reads the selected backend inside `core_loop`, consumes the actual classifier,
and routes an unexpected cancellation error to the typed fatal entry.

`LoopHandle.fail_callback` requires an existing bound fence, sets its existing
`failed` latch before branching to a fixed category panic, and treats missing
binding as an invariant failure. It introduces no stored failure record,
arbitrary callback, new native-completion field, error formatting, `anyerror`
or `anytype`. Existing callers and disabled paths are unchanged.

`core_tests.zig` adds three pure tests: success decisions, all representable
backend/error combinations, and exact closed error-payload types. The error
matrix iterates only the target's real closed error-set fields; it does not
manufacture tags for kqueue or IOCP. Timer retirement remains exactly
`error{Canceled, Unexpected}`. No fake failure latch or observer runtime model
was added.

## Honest failing-first evidence

- `declaration-red`: exit 1 at compilation. It reported missing new
  declarations and a comptime annotation issue in the newly written matrix.
  This is not a behavioral reproduction.
- `behavior-red-compile-attempt`: exit 1 at compilation for that test
  annotation issue, after the initial policy declarations were added.
- The annotation was fixed before the actual `behavior-red` run. Its initial
  conservative production classifier acknowledged success but forwarded every
  error. The actual pure tests executed: success and payload-contract tests
  passed; the error matrix failed on `NotFound`, which must retain the target.
  Outcome: 2 passed, 1 failed, exit 1.
- After adding only the accepted nonterminal-result exceptions, the same
  production classifier passes the full pure matrix. This is a behavioral red
  for the newly introduced policy, not an executed native cancellation race
  reproduction or a claim about a previous native experiment.

## Verification actually run

Each named check has a raw `.log` and exact-argv `.json` record. Quality gates
have `.command`, `.log`, and `.status` records. The terminating observer was
never executed.

| Record | Scope | Outcome |
| --- | --- | --- |
| `pure-Debug` | New actual policy and closed-payload tests | Exit 0; 3/3 |
| `pure-ReleaseSafe` | Same pure tests in ReleaseSafe | Exit 0; 3/3 |
| `core-native-compile` | Entire broader core test graph, ReleaseSafe, `--test-no-exec -fno-emit-bin` | Exit 0; no execution |
| `observer-native` | Actual LoopHandle operations, ReleaseSafe compile/code generation | Exit 0; no execution |
| `foreign-pure-windows` | Windows actual closed error sets and policy test graph | Exit 0; compile only |
| `foreign-pure-macos` | macOS actual closed error sets and policy test graph | Exit 0; compile only |
| `observer-foreign-windows` | Actual operations under Windows types/code generation | Exit 0; no execution |
| `observer-foreign-macos` | Actual operations under macOS types/code generation | Exit 0; no execution |
| `healthy-body-app-Debug-io_uring` | Unchanged prepared body-app suite, normal OS access | Exit 0; 14/14 |
| `healthy-body-app-ReleaseSafe-io_uring` | Same unchanged suite, ReleaseSafe, normal OS access | Exit 0; 14/14 |
| `fmt` / `fmt-check` | Only the two assigned source paths | Exit 0 |
| `conventions` | Unchanged `sh scripts/check_conventions.sh` | Exit 0 |
| `release` | Unchanged `sh scripts/check_release_version.sh` | Exit 0; matches 2.1.6 |

The first healthy attempt, `healthy-body-app-Debug-backend-expectation-attempt`,
is separately retained: 4 pass, 10 fail, exit 1. The harness incorrectly set
the assertion-only `UWZ_TEST_XEV_BACKEND=epoll` while normal production
initialization selected io_uring. The existing prepared `body-app/verify.py`
uses `io_uring` for normal OS runs; correcting that harness expectation made
the unchanged suite pass. No production selector, assertion, or test changed
to accommodate this attempt.

`observer_compile.zig` exists only in evidence and forces the actual two
operations to compile. `observer-native.ll` contains the actual observer's
`store i1 true` before its category switch and fixed panic calls;
`observer-latch-ir.txt` retains a scoped excerpt. Foreign IR records provide
code-generation evidence for kqueue and IOCP types. These are compile-only
artifacts, not new root exports or runnable crash tests.

## Scope limits and remaining work

The existing non-listening-socket accept-failure core test was compiled only
and was not executed, as agreed with root. No new native cancellation,
registration-error, interleaving, race, crash/leak, resource-exhaustion,
invalid-descriptor, injected-completion or native-fault probe was created or
run. There is no subprocess crash test for the observer. Foreign checks were
not executed, and the fatal paths are source-reviewed and compile-checked only.

Independent source review, final integration, graph refresh, archiving,
commits, publication and dependency adoption remain root-owned. The prepared
base, TCP/storage/App, other drafts, root production, root dependency views
and immutable libxev input are unchanged.
