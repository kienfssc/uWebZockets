from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/workspaces/uWebZockets')
out = Path(__file__).resolve().parent
draft = root / '.uwz-work/drafts/m2-loop-callbacks'
label, kind, mode = sys.argv[1:4]
target = sys.argv[4] if len(sys.argv) > 4 else 'native'
source_record = root / '.uwz-work/evidence/body-app' / (
    'focused-final-ReleaseSafe.command.json' if target == 'native' else
    'foreign-' + target + '.command.json'
)
recorded = json.loads(source_record.read_text())
argv = []
skip_next = False
for arg in recorded['argv']:
    if skip_next:
        skip_next = False
        continue
    if arg in ('--test-no-exec', '-fno-emit-bin') or arg.startswith('-femit-bin='):
        continue
    if arg in ('--cache-dir', '--global-cache-dir'):
        skip_next = True
        continue
    if arg.startswith('-O'):
        arg = '-O' + mode
    if arg.startswith('-Mxev_impl='):
        arg = '-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig'
    elif arg.startswith('-Mzslay=zig-pkg/'):
        arg = '-Mzslay=' + str(root / arg.split('=', 1)[1])
    elif arg.startswith('-Mroot='):
        module = 'src/tests/body_app_tests.zig' if kind == 'healthy' else 'src/tests/core_tests.zig'
        arg = '-Mroot=' + (str(out / 'observer_compile.zig') if kind == 'observer' else module)
    if target != 'native' and arg.endswith('.a'):
        continue
    argv.append(arg)
argv.extend(['-j2', '--cache-dir', '/tmp/uwz-relocated-m2-body-app-cache',
             '--global-cache-dir', '/tmp/uwz-multipart-integrated-global'])
if kind == 'pure':
    argv.extend(['--test-filter', 'core: cancellation acknowledgement',
                 '--test-filter', 'core: callback failure payloads'])
if kind in ('compile-core', 'observer') or target != 'native':
    argv.extend(['--test-no-exec', '-fno-emit-bin'])
else:
    argv.append('-femit-bin=' + str(out / ('bin-' + label)))
if kind == 'observer':
    argv.append('-femit-llvm-ir=' + str(out / (label + '.ll')))
environment = os.environ.copy()
environment['UWZ_TEST_XEV_BACKEND'] = 'io_uring'

def source_hashes():
    return {name: hashlib.sha256((draft / name).read_bytes()).hexdigest() for name in [
        'src/core/loop.zig', 'src/tests/core_tests.zig', 'src/core/xev.zig',
        'src/core/tcp.zig', 'src/router/app.zig',
        'build.zig.zon', 'build.zig.zon.json', 'build.zig.zon.nix', 'build.zig.zon.txt',
    ]}

def input_hashes():
    inputs = {}
    for arg in argv:
        name = arg.split('=', 1)[1] if arg.startswith('-M') else arg if arg.endswith('.a') else None
        if name is None:
            continue
        path = Path(name)
        if not path.is_absolute():
            path = draft / path
        if path.is_file():
            inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return inputs

record = {'argv': argv, 'cwd': str(draft), 'environment': {'UWZ_TEST_XEV_BACKEND': 'io_uring'},
          'command_template': str(source_record), 'source_before': source_hashes(),
          'input_before': input_hashes(),
          'override_provenance': str(out / 'override-provenance.json')}
(out / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
with (out / (label + '.log')).open('wb') as log:
    result = subprocess.run(argv, cwd=draft, env=environment, stdout=log, stderr=subprocess.STDOUT)
record.update(exit_status=result.returncode, elapsed_seconds=time.monotonic() - started,
              source_after=source_hashes(), input_after=input_hashes())
binary = next((Path(arg.split('=', 1)[1]) for arg in argv if arg.startswith('-femit-bin=')), None)
if binary is not None and binary.is_file():
    record['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
(out / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print((out / (label + '.log')).read_text(), end='')
print('Exit status:', result.returncode)
raise SystemExit(result.returncode)
