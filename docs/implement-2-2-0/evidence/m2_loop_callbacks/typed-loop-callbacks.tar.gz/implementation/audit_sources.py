from pathlib import Path
import hashlib
import json

root = Path('/workspaces/uWebZockets')
out = Path(__file__).resolve().parent
copy_record = json.loads((out / 'copy-manifest.json').read_text())
base = Path(copy_record['base'])
successor = Path(copy_record['successor'])
excluded = set(copy_record['excluded_names'])

def manifest(directory):
    files = {}
    for path in directory.rglob('*'):
        name = path.relative_to(directory)
        if any(part in excluded for part in name.parts):
            continue
        if path.is_symlink():
            files[str(name)] = {'symlink': str(path.readlink())}
        elif path.is_file():
            files[str(name)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return files

initial = copy_record['files_sha256']
current_base = manifest(base)
current_successor = manifest(successor)
changed = sorted(name for name in initial if initial[name] != current_successor.get(name))
extra = sorted(set(current_successor) - set(initial))
expected = ['src/core/loop.zig', 'src/tests/core_tests.zig']
provenance = json.loads((out / 'override-provenance.json').read_text())
export_record = json.loads((out.parent / 'immutable-libxev-input.json').read_text())
export = Path(export_record['path'])
export_files = {str(path.relative_to(export)): hashlib.sha256(path.read_bytes()).hexdigest()
                for path in export.rglob('*') if path.is_file()}
root_views = {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
              for name in provenance['root_zon_views_sha256']}
audit = {
    'base_unchanged': current_base == initial,
    'changed_successor_files': changed,
    'extra_successor_files': extra,
    'only_owned_sources_changed': changed == expected and not extra,
    'immutable_export_unchanged': export_files == export_record['files_sha256'],
    'immutable_export_files': len(export_files),
    'root_four_zon_views_unchanged': root_views == provenance['root_zon_views_sha256'],
    'excluded_paths_not_copied': {name: not (successor / name).exists() for name in excluded},
    'frozen_source_sha256': {name: current_successor[name] for name in expected},
}
(out / 'final/source-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
if not all(audit[name] for name in ['base_unchanged', 'only_owned_sources_changed',
                                  'immutable_export_unchanged', 'root_four_zon_views_unchanged']):
    raise SystemExit('source audit failed')
print(json.dumps(audit, indent=2))
