cwd: /workspaces/uWebZockets/.uwz-work/drafts/m2-loop-callbacks
command: /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check src/core/loop.zig src/tests/core_tests.zig
