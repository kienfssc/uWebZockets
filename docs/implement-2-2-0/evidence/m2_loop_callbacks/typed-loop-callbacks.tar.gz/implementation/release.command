cwd: /workspaces/uWebZockets/.uwz-work/drafts/m2-loop-callbacks
command: sh scripts/check_release_version.sh
