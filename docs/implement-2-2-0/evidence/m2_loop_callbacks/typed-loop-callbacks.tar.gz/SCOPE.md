# Reviewed isolated loop callback adapter

Reconstruct prepared App/R2 source from m2_transport_preparation's
m2-transport-preparation/drafts/m2-body-app/ prefix, restoring other project
metadata at that archive's recorded baseline, then apply the two overlay/src
replacements. Every base/src file matches that original archive exactly.
Copy manifest binds905 baseline files;903 are unchanged in this successor.
This is an isolated prepared tree, not a replacement for current root source.
Final combined integration MUST preserve later root timer fix3cc8f81 and its
central regression; never overwrite current core_tests wholesale from this overlay.

Actual pure cancel_ack_decision uses named CancelAck and closed xev.CancelError.
Epoll success abandons; epollNotFound retains; io_uring success/NotFound/EALREADY
retain; kqueue/IOCP success retain; other representable errors propagate exactly.
Retain does not acquire a target pin or claim a future callback. No result grants
close permission. LoopHandle consumes this policy under its owner/fence invariant.
Typed CallbackFailure uses cancellation/retirement/close errors; bound failure
latch precedes fixed panic. No failure record, framework, new state or root export.

Initial declaration/comptime failures remain compile-only. Conservative policy
behavior-red actually executes and fails on NotFound,2pass/1fail; finalpure3/3
both modes. Unchanged body-app14/14 both modes uses normal io_uring. The initial
assertion-only epoll expectation mismatch is retained separately. Broader core,
observer and Windows/macOS checks compile/codegen only; observers never execute.
Source/diff,905base files,93export files and allrootpin views are independently
reviewed stable. Every compiler command has explicit c223bd886c6a51d2cd60def39dd9a68d701fea73
module override at /tmp/uwz-reviewed-libxev-c223-loop-callbacks; this is not root
pin adoption or a maintained local build overlay. Full candidate source/history
is separately archived in m3_libxev_registration_rollback. Derived ELF outputs
are omitted with hashes; their original paths remain symlinks to /tmp copies.

R3V6 remains unaccepted due community-BSD worker wakeup liveness. This slice
implements no TCP/storage/App lifecycle, body driver, physical close, platform
activation or native fault/timing probe. Separate platform guard and combined
integration remain required. Maintained publication/protections/pins unchanged.
