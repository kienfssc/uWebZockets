from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,re,tarfile
root=Path('/workspaces/uWebZockets')
e=root/'.uwz-work/evidence/loop-callbacks'
draft=root/'.uwz-work/drafts/m2-loop-callbacks'
dest=root/'docs/implement-2-2-0/evidence/m2_loop_callbacks'
dest.mkdir(parents=True,exist_ok=True)
bindings={'src/core/loop.zig':'74c4e5b8bc3a624e3b7ce5ce3db6268eb644276b0480fe13c5161372967b93f2','src/tests/core_tests.zig':'b0df5ca9a50c8488519925ce6fd34b7893e0ad9824ff4cc96ff69bf7515c039a'}
for name,digest in bindings.items():assert hashlib.sha256((draft/name).read_bytes()).hexdigest()==digest,name
summary=json.loads((e/'implementation/summary.json').read_text())
expected_failures={'declaration-red','behavior-red-compile-attempt','behavior-red','healthy-body-app-Debug-backend-expectation-attempt'}
for name,record in summary['checks'].items():assert record['exit_status']==(1 if name in expected_failures else 0),name
source_input=json.loads((e/'immutable-libxev-input.json').read_text())
export=Path(source_input['path'])
for name,digest in source_input['files_sha256'].items():assert hashlib.sha256((export/name).read_bytes()).hexdigest()==digest,name
(e/'independent-review.md').write_text('''# Independent typed callback adapter review, 2026-10-27

Reviewer /root/review_iocp_cancel_result, read-only. No actionable findings in
the frozen two-file adapter. Verified exact hashes/diff,905 unchanged baseline
files, root four pin views,93-file immutable export and explicit compiler module
overrides. Classification preserves error identity and the accepted backend
policy. Bound owner/fence is checked and existing failed latch precedes fixed
category panic. No activation, layout/storage or physical-close behavior changed.

Evidence supports behavioral policy red,3/3 pure and14/14 unchanged body-app
both modes, observer IR latch-before-panic. Reviewer ran no builds/tests/probes.
Fatal observers were never executed; broader core and Windows/macOS checks are
compile/codegen only. Healthy body-app runtime is io_uring. This does not prove
native cancellation timing, target lifetime, BSD wakeup safety or R3 readiness.
''')
(e/'SCOPE.md').write_text('''# Reviewed isolated loop callback adapter

Reconstruct prepared App/R2 source from m2_transport_preparation's
m2-transport-preparation/drafts/m2-body-app/ prefix, restoring other project
metadata at that archive's recorded baseline, then apply the two overlay/src
replacements. Every base/src file matches that original archive exactly.
Copy manifest binds905 baseline files;903 are unchanged in this successor.
This is an isolated prepared tree, not a replacement for current root source.
Final combined integration MUST preserve later root timer fix3cc8f81 and its
central regression; never overwrite current core_tests wholesale from this overlay.

Actual pure cancel_ack_decision uses named CancelAck and closed xev.CancelError.
Epoll success abandons; epollNotFound retains; io_uring success/NotFound/EALREADY
retain; kqueue/IOCP success retain; other representable errors propagate exactly.
Retain does not acquire a target pin or claim a future callback. No result grants
close permission. LoopHandle consumes this policy under its owner/fence invariant.
Typed CallbackFailure uses cancellation/retirement/close errors; bound failure
latch precedes fixed panic. No failure record, framework, new state or root export.

Initial declaration/comptime failures remain compile-only. Conservative policy
behavior-red actually executes and fails on NotFound,2pass/1fail; finalpure3/3
both modes. Unchanged body-app14/14 both modes uses normal io_uring. The initial
assertion-only epoll expectation mismatch is retained separately. Broader core,
observer and Windows/macOS checks compile/codegen only; observers never execute.
Source/diff,905base files,93export files and allrootpin views are independently
reviewed stable. Every compiler command has explicit c223bd886c6a51d2cd60def39dd9a68d701fea73
module override at /tmp/uwz-reviewed-libxev-c223-loop-callbacks; this is not root
pin adoption or a maintained local build overlay. Full candidate source/history
is separately archived in m3_libxev_registration_rollback. Derived ELF outputs
are omitted with hashes; their original paths remain symlinks to /tmp copies.

R3V6 remains unaccepted due community-BSD worker wakeup liveness. This slice
implements no TCP/storage/App lifecycle, body driver, physical close, platform
activation or native fault/timing probe. Separate platform guard and combined
integration remain required. Maintained publication/protections/pins unchanged.
''')
retained={};omitted={}
for p in sorted(e.rglob('*')):
 if not p.is_file():continue
 name=p.relative_to(e).as_posix();data=p.read_bytes()
 if p.name.startswith('bin-') or data.startswith(b'\x7fELF') or p.suffix in ('.o','.obj','.exe','.a','.lib'):
  omitted[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};continue
 assert not p.is_symlink(),name
 retained[name]=data
for name in bindings:retained['overlay/'+name]=(draft/name).read_bytes()
retained['omitted-derived-binaries.json']=(json.dumps(omitted,indent=2)+'\n').encode()
values=[v.encode() for k,v in os.environ.items() if re.search(r'(?:TOKEN|SECRET|PASSWORD|CREDENTIAL|API_KEY)$',k) and len(v)>=20]
pattern=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})')
for name,data in retained.items():assert not any(v in data for v in values) and not pattern.search(data),name
inventory={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in retained.items()}
retained['inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
archive=dest/'typed-loop-callbacks.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(retained.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
    tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():
  name=PurePosixPath(member.name)
  assert member.isfile() and not name.is_absolute() and '..' not in name.parts
  assert tar.extractfile(member).read()==retained[member.name]
manifest={'date':'2026-10-27','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'safe_regular_members':len(retained),'inventory_entries':len(inventory),'source_sha256':bindings,'independent_review':'No actionable findings in bounded adapter','reviewer':'/root/review_iocp_cancel_result','source_base_and_override':'905baseline files/93immutable c223 files, original recovery base/src verified','runtime_limits':'Pure3/3 and unchanged body-app14/14 per mode; observer/broader core/foreign compile only; no lifetime or R3 activation','root_production_or_pin_change':False,'credential_scan':'All retained bytes checked against environment credential values and GitHub token patterns; derived binaries omitted by hash/size','omitted_derived_binaries':omitted,'files':inventory}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('archive_sha256','archive_bytes','safe_regular_members','inventory_entries')},indent=2))
