"""Preserve the reviewed overlays and actual partial integration evidence."""
from pathlib import Path
import hashlib
import io
import json
import os
import re
import tarfile

ROOT = Path('/workspaces/uWebZockets')
EVIDENCE = ROOT / '.uwz-work/evidence/h1-plaintext'
DEST = ROOT / 'docs/implement-2-2-0/evidence/m2_h1_plaintext'
SOURCE = Path('/tmp/uwz-m2-h1-plaintext-combined')
BASE = Path('/tmp/uwz-m2-h1-native-lifetime')
PATHS = ['src/core/loop.zig', 'src/core/tcp.zig', 'src/core/tcp_upload.zig', 'src/router/app.zig', 'src/test_support.zig', 'src/tests/main.zig', 'src/tests/body_h1_head_tests.zig', 'src/tests/http1_upload_driver_tests.zig']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(path):
    pairs = [(str(p.relative_to(path)), sha(p.read_bytes())) for p in sorted(path.rglob('*')) if p.is_file()]
    return sha(json.dumps(pairs).encode())


assert canonical(SOURCE) == 'acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b'
assert canonical(BASE) == '81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108'
for relative in PATHS:
    target = EVIDENCE / 'combined/snapshot' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((SOURCE / relative).read_bytes())
    if (BASE / relative).exists():
        target = EVIDENCE / 'combined/preimages' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((BASE / relative).read_bytes())
members = {}
for path in sorted(EVIDENCE.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts:
        continue
    if path.relative_to(EVIDENCE).parts[0] in ('integration-v2', 'integration-corrected'):
        continue
    assert not path.is_symlink()
    members[str(Path('evidence') / path.relative_to(EVIDENCE))] = path.read_bytes()
for path in sorted((ROOT / '.superpowers/sdd/h1_plaintext_plan').glob('*.md')):
    members[str(Path('plan') / path.name)] = path.read_bytes()
token = re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})')
credentials = [value.encode() for key, value in os.environ.items() if key in ('GH_TOKEN', 'GITHUB_TOKEN', 'GIT_PASSWORD', 'AWS_SECRET_ACCESS_KEY', 'AWS_SESSION_TOKEN') and len(value) > 12]
for name, data in members.items():
    assert not token.search(data), 'credential-pattern match in ' + name
    assert all(value not in data for value in credentials), 'credential-value match in ' + name
inventory = {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in members.items()}
members['inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
DEST.mkdir(parents=True, exist_ok=True)
archive = DEST / 'h1-plaintext-checkpoint.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as output:
    for name, data in sorted(members.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        entry.mtime = 0
        output.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as check:
    assert len(check.getmembers()) == len(members)
    for entry in check.getmembers():
        assert entry.isfile() and not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts
        assert sha(check.extractfile(entry).read()) == sha(members[entry.name])
manifest = {'archive': archive.name, 'sha256': sha(archive.read_bytes()), 'bytes': archive.stat().st_size, 'members': len(members), 'inventory_entries': len(inventory), 'base_digest': canonical(BASE), 'combined_digest': canonical(SOURCE), 'source_overlay_paths': PATHS, 'status': 'reviewed isolated plaintext components;18/20 initial live cases passed;2 error-path client checks unresolved;not production adoption or M2 completion', 'credential_checks': 'GitHub token patterns and available named credential values absent'}
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
