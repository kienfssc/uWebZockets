const std = @import("std");
const support = @import("test_support");
const driver = support.tcp_upload;
const body = support.request_body;
const radix = support.radix;
const RouterBundle = radix.Bundle(.{ .stream_request_bodies = true });
const View = support.streaming_request.StreamingRequest;
const Response = support.http_response.Response;

const Fixture = struct {
    bundle: RouterBundle = .{},
    router: radix.Router = .{},
    definition: body.BodyRoute = undefined,
    owner: support.http1_upload_storage.Http1UploadStorage = .{ .retirement_timer = undefined, .initialized = true },
    conn: support.tcp.TcpConnection = .{ .socket = undefined },
    input: [512]u8 = undefined,
    output: [2048]u8 = undefined,
    received: [2048]u8 = undefined,
    received_len: usize = 0,
    begins: usize = 0,
    ends: usize = 0,
    cancels: usize = 0,
    fail_begin: bool = false,
    fail_chunk: bool = false,
    fail_end: bool = false,
    invalid_progress: bool = false,
    close_begin: bool = false,
    close_chunk: bool = false,
    reason: ?body.BodyCancelReason = null,
    overflow_seen: bool = false,
    cancel_saw_closing: bool = false,
    pause_begin: bool = false,
    pause_chunk: bool = false,
    prefix: usize = 32,
    control: ?body.BodyControl = null,

    fn init(self: *Fixture) !void {
        self.router = try radix.Router.init(self.bundle.storage());
        self.definition = .{
            .sink = .{ .context = self, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel_sink },
            .limits = .{ .max_body_bytes = 10000, .max_active = 1 },
        };
        try self.router.route_body(.post, "/upload", &self.definition);
        self.owner.head_target = .{ .context = self, .router = &self.router, .resolve = resolve };
        self.conn.router = &self.router;
        self.conn.upload_owner = &self.owner;
        self.conn.request_buffer = &self.input;
        self.conn.write_queue = &self.output;
        self.conn.protocol_state = .http;
        // This caller-owned operation spans all actual sink calls, without native I/O.
        try std.testing.expect(driver.borrow(&self.owner));
        self.conn.begin_write_batch();
    }

    fn resolve(context: *anyopaque, input: *const support.http1_upload.HeadInput, response: *Response) support.http1_upload.HeadDecision {
        const self: *Fixture = @ptrCast(@alignCast(context));
        if (input.head.headers.get("X-Overflow")) |value| {
            self.overflow_seen = std.mem.eql(u8, value, "present") and input.headers.names.len == 1;
        }
        input.request.extra_header_names = input.headers.names;
        input.request.extra_header_values = input.headers.values;
        input.request.extra_header_count = input.headers.names.len;
        response.append_header("X-Saved", "yes") catch return .{ .reject = .unavailable };
        return .{ .stream = self.router.match(input.request.path, input.method).?.body_match.? };
    }

    fn feed_head(self: *Fixture, wire: []const u8) !void {
        @memcpy(self.conn.request_buffer[0..wire.len], wire);
        self.conn.request_len = wire.len;
        const result = support.http_parser.consume_head(&self.conn.parser, &self.conn.req, self.conn.request_buffer[0..wire.len]);
        try std.testing.expect(result.ready != null);
        try std.testing.expect(driver.admit(&self.conn, result));
    }

    fn begin(context: *anyopaque, request: *const View, control: body.BodyControl) !body.BodyBinding {
        const self: *Fixture = @ptrCast(@alignCast(context));
        try std.testing.expectEqualStrings("/upload", request.path);
        try std.testing.expectError(error.BodyCallbackActive, control.cancel());
        self.begins += 1;
        self.control = control;
        if (self.close_begin) support.tcp.close_connection(&self.conn);
        if (self.fail_begin) return error.BeginFailed;
        return .{ .context = self, .readiness = if (self.pause_begin) .paused else .ready };
    }

    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
        const self: *Fixture = @ptrCast(@alignCast(context));
        try std.testing.expectError(error.BodyCallbackActive, self.control.?.@"resume"());
        if (self.close_chunk) support.tcp.close_connection(&self.conn);
        if (self.fail_chunk) return error.ChunkFailed;
        if (self.invalid_progress) return .{ .consumed = bytes.len + 1, .readiness = .ready };
        const count = @min(bytes.len, self.prefix);
        @memcpy(self.received[self.received_len..][0..count], bytes[0..count]);
        self.received_len += count;
        return .{ .consumed = count, .readiness = if (self.pause_chunk or count < bytes.len) .paused else .ready };
    }

    fn end(context: *anyopaque, request: *const View, response: *Response) !void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        try std.testing.expectEqualStrings("/upload", request.path);
        try std.testing.expectError(error.BodyControlExpired, self.control.?.cancel());
        self.ends += 1;
        if (self.fail_end) return error.EndFailed;
        try response.end("200 OK", "done");
    }

    fn cancel_sink(context: *anyopaque, reason: body.BodyCancelReason) void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        self.cancels += 1;
        self.reason = reason;
        self.cancel_saw_closing = self.conn.closing;
    }
};

test "H1 driver: before admission plaintext window respects retained capacity" {
    var bytes: [7]u8 = undefined;
    var conn = support.tcp.TcpConnection{ .socket = undefined, .request_buffer = &bytes, .request_len = 5 };
    try std.testing.expectEqual(@as(usize, 2), driver.read_capacity(&conn));
}

test "H1 driver: partial prefix resumes once and preserves response metadata and pipeline" {
    var fixture = Fixture{ .prefix = 2 };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 4\r\n\r\nabcdNEXT");
    try std.testing.expectEqual(@as(u64, 4), fixture.owner.body.observed);
    try std.testing.expectEqual(@as(usize, 2), fixture.owner.pending_payload);
    try std.testing.expectEqual(@as(usize, 0), driver.read_capacity(&fixture.conn));
    try fixture.control.?.@"resume"();
    try std.testing.expectEqualStrings("abcd", fixture.received[0..fixture.received_len]);
    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
    try std.testing.expectEqual(@as(usize, 0), fixture.cancels);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
    try std.testing.expect(fixture.owner.head != null);
    try std.testing.expect(fixture.owner.delivery_active);
    try std.testing.expectEqualStrings("NEXT", fixture.input[fixture.conn.pending_request_consumed..fixture.conn.request_len]);
    try std.testing.expect(std.mem.indexOf(u8, fixture.output[0..fixture.conn.write_len], "X-Saved: yes\r\n") != null);
}

test "H1 driver: final byte pause delays terminal until explicit resume" {
    var fixture = Fixture{ .pause_chunk = true };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\n\r\nx");
    try std.testing.expectEqual(@as(usize, 0), fixture.ends);
    try std.testing.expectEqual(@as(usize, 0), fixture.owner.pending_payload);
    try fixture.control.?.@"resume"();
    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
    try std.testing.expectError(error.BodyControlExpired, fixture.control.?.@"resume"());
}

test "H1 driver: paused begin sends Continue before content and cancel releases once" {
    var fixture = Fixture{ .pause_begin = true };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 4\r\nExpect: 100-continue\r\n\r\n");
    try std.testing.expect(fixture.conn.expect_continue_sent);
    try std.testing.expectEqualStrings("HTTP/1.1 100 Continue\r\n\r\n", fixture.output[0..fixture.conn.write_len]);
    try fixture.control.?.cancel();
    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
    try std.testing.expectError(error.BodyControlExpired, fixture.control.?.cancel());
}

test "H1 driver: body larger than ingress reclaims only consumed tail" {
    var fixture = Fixture{ .prefix = 2048 };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 600\r\n\r\n");
    const head_end = fixture.owner.head.?.header_end;
    const first = [_]u8{'a'} ** 300;
    const second = [_]u8{'b'} ** 300;
    driver.receive(&fixture.conn, &first);
    try std.testing.expectEqual(head_end, fixture.conn.request_len);
    try std.testing.expectEqualStrings("/upload", fixture.conn.req.path);
    driver.receive(&fixture.conn, &second);
    try std.testing.expectEqual(@as(u64, 600), fixture.owner.body.observed);
    try std.testing.expectEqualSlices(u8, &first, fixture.received[0..300]);
    try std.testing.expectEqualSlices(u8, &second, fixture.received[300..600]);
    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
}

test "H1 driver: chunk framing extensions trailers and following bytes survive split input" {
    var fixture = Fixture{};
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nTransfer-Encoding: chunked\r\n\r\n2;foo=bar\r\na");
    driver.receive(&fixture.conn, "b\r\n0\r\nX-Discard: yes\r");
    try std.testing.expectEqual(@as(usize, 0), fixture.ends);
    driver.receive(&fixture.conn, "\n\r\nNEXT");
    try std.testing.expectEqualStrings("ab", fixture.received[0..fixture.received_len]);
    try std.testing.expect(fixture.conn.req.get_header("X-Discard") == null);
    try std.testing.expectEqualStrings("NEXT", fixture.input[fixture.conn.pending_request_consumed..fixture.conn.request_len]);
    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
}

test "H1 driver: failed begin releases admission without cancel" {
    var fixture = Fixture{ .fail_begin = true };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 0\r\n\r\n");
    try std.testing.expectEqual(@as(usize, 1), fixture.begins);
    try std.testing.expectEqual(@as(usize, 0), fixture.ends + fixture.cancels);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
    try std.testing.expect(fixture.conn.closing);
}

test "H1 driver: close during successful begin cancels returned binding after unwind" {
    var fixture = Fixture{ .close_begin = true };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 0\r\n\r\n");
    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
    try std.testing.expectEqual(@as(usize, 0), fixture.ends);
    try std.testing.expectEqual(body.BodyPhase.inactive, fixture.owner.body.phase);
    try std.testing.expect(fixture.owner.delivery_active);
}

test "H1 driver: chunk failure and invalid progress each cancel exactly once" {
    for ([_]bool{ false, true }) |invalid| {
        var fixture = Fixture{ .fail_chunk = !invalid, .invalid_progress = invalid };
        try fixture.init();
        try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\n\r\nx");
        try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
        try std.testing.expectEqual(@as(?body.BodyCancelReason, .sink_failure), fixture.reason);
        try std.testing.expectEqual(@as(usize, 0), fixture.ends);
        try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
    }
}

test "H1 driver: resumed end error completes terminal ownership without cancel" {
    var fixture = Fixture{ .pause_chunk = true, .fail_end = true };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\n\r\nx");
    try std.testing.expectError(error.BodyDeliveryFailed, fixture.control.?.@"resume"());
    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
    try std.testing.expectEqual(@as(usize, 0), fixture.cancels);
    try std.testing.expectEqual(body.BodyPhase.inactive, fixture.owner.body.phase);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
}

test "H1 driver: malformed trailer cancels and queues bounded final rejection" {
    var fixture = Fixture{};
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nTransfer-Encoding: chunked\r\n\r\n0\r\nHost: forbidden\r\n\r\n");
    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
    try std.testing.expectEqual(@as(?body.BodyCancelReason, .invalid_body), fixture.reason);
    try std.testing.expect(std.mem.indexOf(u8, fixture.output[0..fixture.conn.write_len], "400 Bad Request") != null);
    try std.testing.expectEqual(@as(usize, 0), fixture.ends);
}

test "H1 driver: close during chunk preserves observed and accepted prefix accounting" {
    var fixture = Fixture{ .close_chunk = true };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\n\r\nx");
    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
    try std.testing.expectEqual(@as(u64, 1), fixture.owner.body.consumed);
    try std.testing.expectEqual(@as(usize, 0), fixture.owner.pending_payload);
    try std.testing.expectEqual(@as(usize, 0), fixture.ends);
}

test "H1 driver: resolver receives complete head and used overflow views" {
    var fixture = Fixture{ .pause_begin = true };
    try fixture.init();
    var input: [2048]u8 = undefined;
    var names: [3][]const u8 = undefined;
    var values: [3][]const u8 = undefined;
    fixture.conn.request_buffer = &input;
    fixture.conn.parser.extra_header_names = &names;
    fixture.conn.parser.extra_header_values = &values;
    const wire = "POST /upload HTTP/1.1\r\nHost: x\r\n" ++ "X-Fill: a\r\n" ** 63 ++ "X-Overflow: present\r\n\r\n";
    try fixture.feed_head(wire);
    try std.testing.expect(fixture.overflow_seen);
    try std.testing.expectEqualStrings("present", fixture.conn.req.get_header("X-Overflow").?);
    try fixture.control.?.cancel();
}

test "H1 driver: response completion cannot compact under inherited metadata borrow" {
    var fixture = Fixture{};
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 0\r\n\r\nNEXT");
    const consumed = fixture.conn.pending_request_consumed;
    const length = fixture.conn.request_len;
    fixture.conn.resume_async_dispatch();
    try std.testing.expectEqual(consumed, fixture.conn.pending_request_consumed);
    try std.testing.expectEqual(length, fixture.conn.request_len);
    try std.testing.expectEqualStrings("/upload", fixture.conn.req.path);
    try std.testing.expect(fixture.conn.dispatch_suspended);
}

test "H1 driver: owner EOF cancellation delivers original reason once" {
    var fixture = Fixture{ .pause_begin = true };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 4\r\n\r\na");
    driver.cancel(&fixture.conn, .peer_closed);
    driver.cancel(&fixture.conn, .reset);
    try std.testing.expectEqual(@as(?body.BodyCancelReason, .peer_closed), fixture.reason);
    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
}

test "H1 driver: logical chunk limit rejects before payload acceptance" {
    var fixture = Fixture{};
    try fixture.init();
    fixture.definition.limits.max_body_bytes = 1;
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nab\r\n0\r\n\r\n");
    try std.testing.expectEqual(@as(usize, 0), fixture.received_len);
    try std.testing.expectEqual(@as(?body.BodyCancelReason, .body_too_large), fixture.reason);
    try std.testing.expect(std.mem.indexOf(u8, fixture.output[0..fixture.conn.write_len], "413 Payload Too Large") != null);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
}

test "H1 driver: reasoned close publishes closing before terminal and retains first cause" {
    var fixture = Fixture{ .pause_begin = true };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\n\r\n");
    driver.close(&fixture.conn, .timeout);
    driver.close(&fixture.conn, .shutdown);
    try std.testing.expect(fixture.cancel_saw_closing);
    try std.testing.expectEqual(@as(?body.BodyCancelReason, .timeout), fixture.reason);
    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
    try std.testing.expect(fixture.owner.close_pending);
    try std.testing.expect(fixture.owner.delivery_active);
}

test "H1 driver: outstanding file response retains dispatch after native retirement" {
    try std.testing.expect(support.tcp.response_dispatch_owned(true, false, false));
}

test "H1 driver: producer and async owners retain dispatch until all output owners finish" {
    try std.testing.expect(support.tcp.response_dispatch_owned(false, true, false));
    try std.testing.expect(support.tcp.response_dispatch_owned(false, false, true));
    try std.testing.expect(!support.tcp.response_dispatch_owned(false, false, false));
}
