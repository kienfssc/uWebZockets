# Combined plaintext integration review

Verdict: Approved for the scoped composition review. No actionable findings.

Reviewed combined source `acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b`, composed from typed baseline `81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108`, approved transport v6 `a9022ee14096698cf92d9c66afe4d156b4135382c8f72fc1e35a622d70773e26`, and the approved App overlay (app.zig SHA-256 `e240dc0ee625f71cf311a1b87d83e4202cbbacd55e57983a630b4ff4d8c4733d`). Checked actual overlay file hashes against assembly-inputs.json and the two integration-edits.json replacements; all matched.

Scope checked:

- App loop_handle binds the stable App context and its actual router into each owner; accepted connections bind their corresponding slab owner before read_start.
- Parser HeadReady includes initial and used overflow header views. tcp_upload.admit passes used mutable overflow slots, while capture slots retain capacity. App upgrade detection uses the complete head, and selected streaming requests bind those used slots before middleware and sink delivery.
- The existing driver admission borrow spans actual App resolution and metadata copying; its closing check precedes reservation. The combined shutdown call uses tcp_upload.close(conn, .shutdown) at app.zig:645, with no access to that connection after the call. The reviewed reasoned-close operation retains terminal ownership and the first cancellation reason through closing publication.
- Both new test modules appear exactly once in src/tests/main.zig, at lines 9 and 10. The transport export and previously reviewed component bytes match their approved inputs.

Evidence inspected: combined Debug and ReleaseSafe selected runs each passed 62/62 with UWZ_TEST_XEV_BACKEND=io_uring, stable combined source bindings and recorded binary hashes. Central combined native semantic compilation exited zero. These are recorded results, not executions performed by this reviewer.

Remaining limits: ordinary combined protocol clients, the 16 MiB file pipeline and Connection: close checks, runtime shutdown behavior, deferred TLS destruction review, native platform validation and full project gates remain separate acceptance work. The selected tests do not establish native retirement timing or live file ordering. No build, native execution, fault probe, cancellation experiment or source/ref/pin edit was performed during review. Only this report was written.
