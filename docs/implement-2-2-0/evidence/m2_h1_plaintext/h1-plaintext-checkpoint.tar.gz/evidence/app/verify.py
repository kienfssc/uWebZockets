from pathlib import Path
import subprocess,json,hashlib,os,sys,time,shutil
root=Path('/workspaces/uWebZockets');src=Path('/tmp/uwz-m2-h1-plaintext-app');out=root/'.uwz-work/evidence/h1-plaintext/app';art=Path('/tmp/uwz-m2-h1-plaintext-app-artifacts');art.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def manifest():return {str(p.relative_to(src)):sha(p) for p in sorted(src.rglob('*')) if p.is_file()}
def override():
 p=root/'.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json';m=json.loads(p.read_text());assert {n:sha(Path(m['path'])/n) for n in m['files_sha256']}==m['files_sha256'];return {'manifest':str(p),'sha256':sha(p),'commit':m['commit'],'tree':m['tree']}
label,module,mode,*filters=sys.argv[1:];argv=[];skip=False
target=os.environ.get('UWZ_COMPILE_TARGET','native')
compile_only=target!='native' or os.environ.get('UWZ_COMPILE_ONLY')=='1'
for a in json.loads((root/'.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json').read_text())['argv']:
 if skip:skip=False;continue
 if a in ('--test-no-exec','-fno-emit-bin') or a.startswith('-femit-bin='):continue
 if a in ('--cache-dir','--global-cache-dir'):skip=True;continue
 if a.endswith('.a') and target!='native':continue
 if a=='native':a=target
 if a.startswith('-O'):a='-O'+mode
 if a.startswith('-Mroot='):argv+=['--dep','zslay'];a='-Mroot='+module
 elif a.startswith('-Mc='):a='-Mc='+str(root/('.uwz-work/evidence/h1-transport/r2/c-'+target+'.zig'))
 elif a.startswith('-Mxev_impl='):a='-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig'
 elif a.startswith('-Mzslay=zig-pkg/'):a='-Mzslay='+str(root/a.split('=',1)[1])
 argv.append(a)
argv+=['-j2','--cache-dir','/tmp/uwz-m2-h1-plaintext-app-cache','--global-cache-dir','/tmp/uwz-m2-h1-plaintext-app-global','--test-no-exec']
argv+=['-fno-emit-bin'] if compile_only else ['-femit-bin='+str(art/label)]
for f in filters:argv+=['--test-filter',f]
module_inputs={}
for a in argv:
 if a.startswith('-M') and '=' in a:
  f=Path(a.split('=',1)[1]);f=f if f.is_absolute() else src/f
  if f.is_file():module_inputs[str(f)]=sha(f)
record={'module_inputs':module_inputs,'compile_only':compile_only,'argv':argv,'cwd':str(src),'source_before':manifest(),'override':override(),'env':{'UWZ_TEST_XEV_BACKEND':'epoll'},'inputs':{a:sha(a) for a in argv if Path(a).is_file()}}
env=os.environ.copy();env['UWZ_TEST_XEV_BACKEND']='epoll'
with (out/(label+'.compile.log')).open('wb') as log:r=subprocess.run(argv,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
record['compile_status']=r.returncode
if r.returncode==0 and not compile_only:
 record['binary_sha256']=sha(art/label)
 with (out/(label+'.run.log')).open('wb') as log:r=subprocess.run([str(art/label)],cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
 record['run_argv']=[str(art/label)];record['run_status']=r.returncode;record['binary_after']=sha(art/label)
record['source_after']=manifest();(out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
snap=out/label;snap.mkdir(exist_ok=True)
for name in ['src/router/app.zig','src/tests/body_h1_head_tests.zig']:
 if (src/name).exists():shutil.copy2(src/name,snap/Path(name).name)
print((out/(label+'.compile.log')).read_text());p=out/(label+'.run.log');print(p.read_text() if p.exists() else '');print('RESULT',record['compile_status'],record.get('run_status'))
sys.exit(r.returncode)
