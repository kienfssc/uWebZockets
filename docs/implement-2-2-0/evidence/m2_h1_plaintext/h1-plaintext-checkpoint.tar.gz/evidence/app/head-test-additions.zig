const Request = support.http_request.Request;
const Response = support.http_response.Response;
const upload = support.http1_upload;
const body = support.request_body;
const StreamingRequest = support.streaming_request.StreamingRequest;

/// All callback effects stay in caller-owned bounded records.
const Effects = struct {
    sink_calls: usize = 0,
    globals: usize = 0,
    observed_empty: bool = true,
    incomplete: bool = true,
    stop: bool = false,
    final: bool = false,
    writes: usize = 0,
    producer_guard: bool = true,

    fn definition(self: *Effects, policy: body.BodyMiddlewarePolicy) body.BodyRoute {
        return .{ .sink = .{ .context = self, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel }, .limits = .{ .max_body_bytes = 8, .max_active = 1 }, .middleware_policy = policy };
    }
    fn begin(context: *anyopaque, _: *const StreamingRequest, _: body.BodyControl) !body.BodyBinding {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.sink_calls += 1;
        return .{ .context = self };
    }
    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.sink_calls += 1;
        return .{ .consumed = bytes.len, .readiness = .ready };
    }
    fn end(context: *anyopaque, _: *const StreamingRequest, _: *Response) !void {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.sink_calls += 1;
    }
    fn cancel(context: *anyopaque, _: body.BodyCancelReason) void {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.sink_calls += 1;
    }
    fn global(context: *anyopaque, req: *Request, res: *Response) support.radix.MiddlewareResult {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.globals += 1;
        self.observed_empty = self.observed_empty and req.body.len == 0;
        self.incomplete = self.incomplete and !res.request_body_complete;
        res.header("X-Admission", "kept") catch return .stop;
        res.begin_chunks("200 OK", "") catch |err| {
            self.producer_guard = self.producer_guard and err == error.BodyNotComplete;
            if (self.final) res.end_best_effort("401 Unauthorized", "refused");
            return if (self.stop) .stop else .continue_dispatch;
        };
        self.producer_guard = false;
        return .stop;
    }
    fn response(self: *Effects) Response {
        return .{ .target = .{ .http3 = .{ .context = self, .end_fn = write_end, .begin_fn = write_begin, .write_fn = write_body, .finish_fn = write_finish } } };
    }
    fn write_end(context: *anyopaque, _: []const u8, _: []const u8, _: []const u8) !void {
        const self: *Effects = @ptrCast(@alignCast(context));
        self.writes += 1;
    }
    fn write_begin(_: *anyopaque, _: []const u8, _: []const u8) !void { return error.UnexpectedProducer; }
    fn write_body(_: *anyopaque, _: []const u8) !void { return error.UnexpectedProducer; }
    fn write_finish(_: *anyopaque) !void { return error.UnexpectedProducer; }
    fn buffered(_: *Request, _: *Response) void {}
};

fn input(req: *Request, method: support.radix.HttpMethod) upload.HeadInput {
    return .{ .request = req, .method = method, .head = .{ .framing = .{ .content_length = 4 }, .header_end = 50, .headers = req.headers() }, .headers = .{ .names = &.{}, .values = &.{} }, .captures = .{ .names = &.{}, .values = &.{} }, .ingress = .{ .capacity = 32, .line_content_limit = 30 }, .pending_header_capacity = 2048, .early_data_forbidden = false };
}
fn target(app: *App) !upload.HeadTarget {
    _ = app.loop_handle();
    return app.upload_owners[0].head_target orelse error.MissingHeadTarget;
}
fn expect_reject(expected: upload.AdmissionRefusal, decision: upload.HeadDecision) !void {
    try std.testing.expect(decision == .reject);
    try std.testing.expectEqual(expected, decision.reject);
}

test "H1 head: buffered resolution leaves every Request byte and globals untouched" {
    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer app.deinit();
    var effects = Effects{};
    _ = try app.get("/plain", Effects.buffered);
    _ = try app.use(&effects, Effects.global);
    var req: Request = std.mem.zeroes(Request);
    req.method = "GET";
    req.path = "/plain";
    req.body = "original body";
    req.route_param_count = 1;
    req.route_param_names[0] = "untouched";
    req.route_param_values[0] = "value";
    const before = req;
    var res = effects.response();
    const t = try target(&app);
    const head = input(&req, .get);
    try std.testing.expect(t.resolve(t.context, &head, &res) == .buffered);
    try std.testing.expectEqualSlices(u8, std.mem.asBytes(&before), std.mem.asBytes(&req));
    try std.testing.expectEqual(@as(usize, 0), effects.globals);
    try std.testing.expect(res.request_body_complete);
}

test "H1 head: actual selected stream runs globals before quota and preserves metadata" {
    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer app.deinit();
    var effects = Effects{};
    const route = effects.definition(.headers_only);
    _ = try app.route_body(.post, "/upload/:id", &route);
    _ = try app.use(&effects, Effects.global);
    const t = try target(&app);
    var req = Request{ .method = "POST", .path = "/upload/42", .body = "must disappear" };
    var res = effects.response();
    var head = input(&req, .post);
    const selected = t.resolve(t.context, &head, &res);
    try std.testing.expect(selected == .stream);
    try std.testing.expectEqualStrings("42", req.get_param("id").?);
    try std.testing.expect(effects.observed_empty and effects.incomplete and effects.producer_guard);
    try std.testing.expectEqual(@as(usize, 1), effects.globals);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
    try std.testing.expect(std.mem.indexOf(u8, res.pending_headers[0..res.pending_header_length], "X-Admission: kept\r\n") != null);
    try app.router.reserve_body_route(selected.stream);
    defer app.router.release_body_route(selected.stream.record_index) catch @panic("test reservation must exist");
    res = effects.response();
    try expect_reject(.unavailable, t.resolve(t.context, &head, &res));
    try std.testing.expectEqual(@as(usize, 2), effects.globals);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}

test "H1 head: early data and QUERY refuse before captures globals and sink" {
    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer app.deinit();
    var effects = Effects{};
    const route = effects.definition(.headers_only);
    _ = try app.route_body(.query, "/upload/:id", &route);
    _ = try app.use(&effects, Effects.global);
    const t = try target(&app);
    var req = Request{ .method = "QUERY", .path = "/upload/42", .body = "sentinel", .route_param_count = 1 };
    req.route_param_names[0] = "old";
    req.route_param_values[0] = "old";
    var res = effects.response();
    var head = input(&req, .query);
    head.early_data_forbidden = true;
    try expect_reject(.too_early, t.resolve(t.context, &head, &res));
    try std.testing.expectEqualStrings("sentinel", req.body);
    head.early_data_forbidden = false;
    try expect_reject(.invalid_query, t.resolve(t.context, &head, &res));
    try std.testing.expectEqualStrings("old", req.get_param("old").?);
    try std.testing.expectEqual(@as(usize, 0), effects.globals);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}

test "H1 head: late incompatible middleware refuses before every callback" {
    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer app.deinit();
    var effects = Effects{};
    const route = effects.definition(.reject_legacy);
    _ = try app.route_body(.post, "/upload", &route);
    _ = try app.use(&effects, Effects.global);
    const t = try target(&app);
    var req = Request{ .method = "POST", .path = "/upload" };
    var res = effects.response();
    const head = input(&req, .post);
    try expect_reject(.unavailable, t.resolve(t.context, &head, &res));
    try std.testing.expectEqual(@as(usize, 0), effects.globals);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}

test "H1 head: declared physical and pending capacity checks follow globals" {
    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer app.deinit();
    var effects = Effects{};
    const route = effects.definition(.headers_only);
    _ = try app.route_body(.post, "/upload", &route);
    _ = try app.use(&effects, Effects.global);
    const t = try target(&app);
    var req = Request{ .method = "POST", .path = "/upload" };
    var res = effects.response();
    var head = input(&req, .post);
    head.head.framing = .{ .content_length = 9 };
    try expect_reject(.body_too_large, t.resolve(t.context, &head, &res));
    head.head.framing = .{ .content_length = 8 };
    head.ingress = null;
    res = effects.response();
    try expect_reject(.unavailable, t.resolve(t.context, &head, &res));
    head.ingress = .{ .capacity = 1, .line_content_limit = 0 };
    head.pending_header_capacity = 0;
    res = effects.response();
    try expect_reject(.unavailable, t.resolve(t.context, &head, &res));
    try std.testing.expectEqual(@as(usize, 3), effects.globals);
    try std.testing.expect(res.pending_header_length != 0);
    head.pending_header_capacity = res.pending_header_length;
    res = effects.response();
    try std.testing.expect(t.resolve(t.context, &head, &res) == .stream);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}

test "H1 head: middleware fixed final and missing response stop precede admission" {
    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer app.deinit();
    var effects = Effects{ .stop = true };
    const route = effects.definition(.headers_only);
    _ = try app.route_body(.post, "/upload", &route);
    _ = try app.use(&effects, Effects.global);
    const t = try target(&app);
    var req = Request{ .method = "POST", .path = "/upload" };
    var res = effects.response();
    var head = input(&req, .post);
    head.ingress = null;
    try std.testing.expect(t.resolve(t.context, &head, &res) == .final);
    try std.testing.expect(res.state == .idle);
    effects.final = true;
    res = effects.response();
    try std.testing.expect(t.resolve(t.context, &head, &res) == .final);
    try std.testing.expect(res.state == .ended);
    try std.testing.expectEqual(@as(usize, 1), effects.writes);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}

test "H1 head: method fallback OPTIONS star and WebSocket upgrade preserve precedence" {
    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer app.deinit();
    var effects = Effects{};
    const route = effects.definition(.reject_legacy);
    _ = try app.route_body(.get, "/upload", &route);
    _ = try app.route_body(.any, "/fallback", &route);
    _ = try app.route_body(.options, "*", &route);
    _ = try app.ws("/upload", .{});
    const t = try target(&app);
    var req = Request{ .method = "HEAD", .path = "/upload" };
    var res = effects.response();
    var head = input(&req, .head);
    try std.testing.expect(t.resolve(t.context, &head, &res) == .stream);
    head.method = .post;
    req.method = "POST";
    try std.testing.expect(t.resolve(t.context, &head, &res) == .buffered);
    req.path = "/fallback";
    try std.testing.expect(t.resolve(t.context, &head, &res) == .stream);
    req.path = "*";
    req.method = "OPTIONS";
    head.method = .options;
    try std.testing.expect(t.resolve(t.context, &head, &res) == .buffered);
    req.path = "/upload";
    req.method = "GET";
    head.method = .get;
    try req.append_header("Connection", "keep-alive, upgrade");
    try std.testing.expect(t.resolve(t.context, &head, &res) == .buffered);
    req.header_count = 0;
    try req.append_header("Upgrade", "websocket");
    try std.testing.expect(t.resolve(t.context, &head, &res) == .buffered);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}

test "H1 head: capture overflow is checked before globals then borrows caller slots" {
    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true, .max_route_params = 17 });
    defer app.deinit();
    var effects = Effects{};
    const route = effects.definition(.headers_only);
    _ = try app.route_body(.post, "/:a/:b/:c/:d/:e/:f/:g/:h/:i/:j/:k/:l/:m/:n/:o/:p/:q", &route);
    _ = try app.use(&effects, Effects.global);
    const t = try target(&app);
    var req = Request{ .method = "POST", .path = "/1/2/3/4/5/6/7/8/9/10/11/12/13/14/15/16/17" };
    var res = effects.response();
    var head = input(&req, .post);
    try expect_reject(.unavailable, t.resolve(t.context, &head, &res));
    try std.testing.expectEqual(@as(usize, 0), effects.globals);
    var names: [1][]const u8 = undefined;
    var values: [1][]const u8 = undefined;
    head.captures = .{ .names = &names, .values = &values };
    try std.testing.expect(t.resolve(t.context, &head, &res) == .stream);
    try std.testing.expectEqualStrings("17", req.get_param("q").?);
    try std.testing.expect(req.extra_param_names.?.ptr == &names);
    try std.testing.expectEqual(@as(usize, 1), effects.globals);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}

test "H1 head: QUERY validates mutable used overflow headers before matching" {
    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer app.deinit();
    var effects = Effects{};
    const route = effects.definition(.headers_only);
    _ = try app.route_body(.query, "/upload/:id", &route);
    const t = try target(&app);
    var req = Request{ .method = "QUERY", .path = "/upload/42" };
    var res = effects.response();
    var head = input(&req, .query);
    var names = [_][]const u8{"Content-Type"};
    var values = [_][]const u8{"application/json"};
    head.headers = .{ .names = &names, .values = &values };
    try std.testing.expect(t.resolve(t.context, &head, &res) == .stream);
    try std.testing.expectEqualStrings("application/json", req.get_header("Content-Type").?);
    try std.testing.expect(req.extra_header_values.?.ptr == &values);
    try std.testing.expectEqual(@as(usize, 1), req.extra_header_count);
    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
}
