from pathlib import Path
import os,subprocess,json,hashlib
src=Path('/tmp/uwz-m2-h1-plaintext-app');out=Path('/workspaces/uWebZockets/.uwz-work/evidence/h1-plaintext/app');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[('fmt',['/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig','fmt','--check','src/router/app.zig','src/tests/body_h1_head_tests.zig']),('conventions',['sh','scripts/check_conventions.sh']),('version',['sh','scripts/check_release_version.sh'])]
for label,argv in checks:
 files={str(p.relative_to(src)):sha(p) for p in sorted(src.rglob('*')) if p.is_file()};env=os.environ.copy();env['PATH']='/home/codespace/.codex/packages/app-server-daemon/releases/0.164.0-x86_64-unknown-linux-musl/codex-path:'+env['PATH']
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(argv,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(label+'.json')).write_text(json.dumps({'argv':argv,'cwd':str(src),'status':r.returncode,'files':files,'PATH':env['PATH']},indent=2)+'\n');print(label,r.returncode,(out/(label+'.log')).read_text())
