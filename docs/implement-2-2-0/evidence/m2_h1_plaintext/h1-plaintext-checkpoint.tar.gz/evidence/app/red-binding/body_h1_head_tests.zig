const std = @import("std");
const support = @import("test_support");
const App = support.app.app(2);

test "H1 head: stable placement binds actual App resolver and router once" {
    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
    defer app.deinit();
    try std.testing.expect(app.upload_owners[0].head_target == null);
    _ = app.loop_handle();
    const target = app.upload_owners[0].head_target orelse return error.MissingHeadTarget;
    try std.testing.expect(target.context == @as(*anyopaque, @ptrCast(&app)));
    try std.testing.expect(target.router == &app.router);
    _ = app.loop_handle();
    try std.testing.expect(app.upload_owners[0].head_target.?.resolve == target.resolve);
    support.http1_upload_storage.reset(&app.upload_owners[0]);
    try std.testing.expect(app.upload_owners[0].head_target.?.context == target.context);
}
