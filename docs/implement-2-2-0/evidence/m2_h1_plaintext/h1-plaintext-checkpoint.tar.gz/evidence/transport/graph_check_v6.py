from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
root=Path('/workspaces/uWebZockets');out=root/'.uwz-work/evidence/h1-plaintext/transport';source=Path('/tmp/uwz-m2-h1-plaintext-transport');copy=Path('/tmp/uwz-m2-h1-plaintext-transport-artifacts/graph-source-v6');manifest=json.loads((out/'v6-manifest.json').read_text())
assert not copy.exists()
for name,h in manifest['files']:
 p=source/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h;q=copy/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
env=os.environ.copy();env['PYTHONPATH']=str(root/'.uwz-work/tools/graphify')
argv=[str(root/'.uwz-work/tools/graphify/bin/graphify'),'update','.'];start=time.monotonic()
with (out/'graph-v6.log').open('wb') as log:result=subprocess.run(argv,cwd=copy,env=env,stdout=log,stderr=subprocess.STDOUT)
for name,h in manifest['files']:assert hashlib.sha256((source/name).read_bytes()).hexdigest()==h
(out/'graph-v6.json').write_text(json.dumps(dict(argv=argv,cwd=str(copy),environment={'PYTHONPATH':env['PYTHONPATH']},input_source=manifest['source_digest'],source_unchanged=True,exit_status=result.returncode,elapsed_seconds=time.monotonic()-start,generated_output=str(copy/'graphify-out')),indent=2)+'\n');print((out/'graph-v6.log').read_text());print('Exit status:',result.returncode)
