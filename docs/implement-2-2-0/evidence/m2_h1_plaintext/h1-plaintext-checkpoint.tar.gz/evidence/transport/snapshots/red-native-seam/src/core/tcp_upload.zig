const std = @import("std");
const tcp = @import("tcp.zig");
const storage = @import("http1_upload_storage.zig");
const upload = @import("http1_upload.zig");
const parser = @import("../http/parser.zig");
const decoder = @import("../http/body_decoder.zig");
const body = @import("../http/request_body.zig");
const radix = @import("../router/radix.zig");
const StreamingRequest = @import("../http/streaming_request.zig").StreamingRequest;
const Response = @import("../http/response.zig").Response;

/// Nested callbacks inherit the caller's metadata lifetime instead of releasing it.
pub fn borrow(owner: *storage.Http1UploadStorage) bool {
    if (owner.delivery_active) return false;
    owner.delivery_active = true;
    return true;
}

/// The continuation may close and recycle conn; callers must return immediately.
pub fn finish_borrow(conn: *tcp.TcpConnection, owned: bool) void {
    if (!owned) return;
    conn.upload_owner.?.delivery_active = false;
    tcp.upload_tail(conn);
}

/// Plaintext receives fit the physical accumulator, independently of logical limits.
pub fn read_capacity(conn: *const tcp.TcpConnection) usize {
    if (conn.ssl != null or conn.protocol_state == .http2 or conn.protocol_state == .websocket)
        return tcp.socket_read_capacity;
    if (conn.upload_owner) |owner| {
        if (owner.head != null and owner.body.phase != .inactive and owner.body.readiness == .paused) return 0;
    }
    return @min(tcp.socket_read_capacity, conn.request_buffer.len - conn.request_len);
}

/// Resolves one H0 checkpoint; false commits the caller to legacy body collection.
pub fn admit(conn: *tcp.TcpConnection, result: parser.HeadResult) bool {
    const owner = conn.upload_owner.?;
    const target = owner.head_target orelse {
        _ = parser.commit_head(&conn.parser, &conn.req, result);
        return false;
    };
    const head = result.ready orelse {
        _ = parser.commit_head(&conn.parser, &conn.req, result);
        return false;
    };
    const owned = borrow(owner);
    var response = Response{ .target = .{ .tcp = conn }, .request_body_complete = false };
    const method = radix.HttpMethod.parse(conn.req.method);
    const bounds = upload.ingress_bounds(conn.request_buffer.len, head.header_end, head.framing, conn.parser.max_header_bytes);
    const input = upload.HeadInput{
        .request = &conn.req,
        .head = head,
        .method = method,
        .headers = .{ .names = conn.parser.extra_header_names[0..conn.parser.extra_header_count], .values = conn.parser.extra_header_values[0..conn.parser.extra_header_count] },
        .captures = .{ .names = conn.route_param_names, .values = conn.route_param_values },
        .ingress = bounds,
        .pending_header_capacity = owner.pending_headers.len,
        .early_data_forbidden = conn.early_data_forbids(method),
    };
    owner.callback_phase = .admission;
    const decision = target.resolve(target.context, &input, &response);
    owner.callback_phase = .none;
    std.debug.assert(response.pending_header_length <= owner.pending_headers.len);
    @memcpy(owner.pending_headers[0..response.pending_header_length], response.pending_headers[0..response.pending_header_length]);
    owner.pending_header_length = response.pending_header_length;
    if (conn.closing) {
        finish_borrow(conn, owned);
        return true;
    }
    switch (decision) {
        .buffered => {
            _ = parser.commit_head(&conn.parser, &conn.req, result);
            finish_borrow(conn, owned);
            return false;
        },
        .final => {
            conn.finish_sync_dispatch(&response);
            tcp.close_after_flush(conn);
        },
        .reject => |reason| refuse(conn, &response, reason),
        .stream => |selected| {
            owner.head = head;
            owner.route_definition = selected.definition;
            owner.route_record_index = selected.record_index;
            owner.ingress_write_offset = conn.request_len - head.header_end;
            owner.ingress_read_offset = 0;
            conn.suppress_response_body = method == .head;
            start(conn, selected, bounds, &response);
        },
    }
    finish_borrow(conn, owned);
    return true;
}

fn refuse(conn: *tcp.TcpConnection, response: *Response, reason: upload.AdmissionRefusal) void {
    const status: []const u8 = switch (reason) {
        .too_early => "425 Too Early",
        .invalid_query => "400 Bad Request",
        .body_too_large => "413 Payload Too Large",
        .unavailable => "503 Service Unavailable",
    };
    response.end_with_headers(status, "Connection: close\r\n", "") catch {
        tcp.close_connection(conn);
        return;
    };
    tcp.close_after_flush(conn);
}

fn start(conn: *tcp.TcpConnection, selected: radix.BodyMatch, bounds: ?upload.IngressBounds, response: *Response) void {
    const owner = conn.upload_owner.?;
    const ingress = bounds orelse {
        refuse(conn, response, .unavailable);
        return;
    };
    const declared: ?u64 = switch (owner.head.?.framing) {
        .none => 0,
        .content_length => |n| n,
        .chunked => null,
    };
    const control = upload.reserve_and_arm(owner.head_target.?.router, selected, &owner.body, .{
        .context = conn,
        .resume_fn = resume_delivery,
        .cancel_fn = cancel_delivery,
    }, declared) catch |err| {
        switch (err) {
            error.BodyAdmissionMissing => owner.loop_handle.?.fail_callback(.body_admission_missing),
            error.BodyTooLarge => refuse(conn, response, .body_too_large),
            error.InvalidBodyRoute, error.BodyMiddlewareIncompatible, error.BodyAdmissionFull,
            error.InvalidBodyLimits, error.BodyStateBusy, error.InvalidBodyState,
            error.InvalidBodyLength, error.InvalidBodyProgress, error.BodyNotReady,
            error.BodyNotComplete => refuse(conn, response, .unavailable),
        }
        return;
    };
    owner.decoder = decoder.init(owner.head.?.framing, .{
        .max_body_bytes = selected.definition.limits.max_body_bytes,
        .max_header_bytes = conn.parser.max_header_bytes,
        .line_content_limit = ingress.line_content_limit,
    });
    const view = StreamingRequest.from_request(&conn.req);
    owner.callback_phase = .begin;
    const binding = selected.definition.sink.begin(selected.definition.sink.context, &view, control) catch {
        owner.callback_phase = .none;
        if (owner.body.reject_begin()) release_admission(owner);
        tcp.close_connection(conn);
        return;
    };
    owner.callback_phase = .none;
    if (owner.body.accept_begin(binding)) |terminal| {
        _ = finish_terminal(conn, terminal);
        return;
    }
    if (conn.closing) {
        cancel(conn, .cancelled);
        return;
    }
    if (!send_continue(conn)) return;
    _ = progress(conn);
}

fn send_continue(conn: *tcp.TcpConnection) bool {
    if (conn.expect_continue_sent or conn.req.count_headers("Expect") == 0) return true;
    const value = conn.req.get_unique_header("Expect");
    if (value == null or !std.ascii.eqlIgnoreCase(std.mem.trim(u8, value.?, " \t"), "100-continue")) {
        cancel(conn, .invalid_body);
        var response = restored_response(conn);
        response.end_with_headers("417 Expectation Failed", "Connection: close\r\n", "") catch {
            tcp.close_connection(conn);
            return false;
        };
        tcp.close_after_flush(conn);
        return false;
    }
    conn.write_data("HTTP/1.1 100 Continue\r\n\r\n") catch {
        cancel(conn, .source_failure);
        tcp.close_connection(conn);
        return false;
    };
    conn.expect_continue_sent = true;
    return true;
}

/// Copies a bounded native plaintext window, then retries retained framing/payload.
pub fn receive(conn: *tcp.TcpConnection, bytes: []const u8) void {
    const owner = conn.upload_owner.?;
    const owned = borrow(owner);
    std.debug.assert(bytes.len <= conn.request_buffer.len - conn.request_len);
    @memcpy(conn.request_buffer[conn.request_len..][0..bytes.len], bytes);
    conn.request_len += bytes.len;
    owner.ingress_write_offset += bytes.len;
    _ = progress(conn);
    finish_borrow(conn, owned);
}

/// Requires a delivery borrow spanning every sink and terminal callback.
fn progress(conn: *tcp.TcpConnection) bool {
    const owner = conn.upload_owner.?;
    std.debug.assert(owner.delivery_active);
    while (!conn.closing and owner.body.phase == .active and owner.body.readiness == .ready) {
        const head_end = owner.head.?.header_end;
        const input = conn.request_buffer[head_end..][0..owner.ingress_write_offset];
        if (owner.pending_payload != 0) {
            if (!deliver_chunk(conn, input[owner.decoder.mark..][0..owner.pending_payload])) return false;
            continue;
        }
        switch (decoder.next(&owner.decoder, input)) {
            .data => |bytes| {
                owner.body.observe(bytes.len) catch {
                    fail(conn, .body_too_large);
                    return false;
                };
                owner.pending_payload = bytes.len;
                if (!deliver_chunk(conn, bytes)) return false;
            },
            .need_more => {
                reclaim(conn);
                return true;
            },
            .end => {
                const terminal = owner.body.take_end(true, owner.pending_payload) catch {
                    fail(conn, .invalid_body);
                    return false;
                };
                conn.dispatch_suspended = true;
                conn.pending_request_consumed = head_end + owner.decoder.mark;
                conn.pending_close_requested = conn.req.header_has_token("Connection", "close");
                return finish_terminal(conn, terminal);
            },
            .invalid => {
                fail(conn, .invalid_body);
                return false;
            },
            .too_large => {
                fail(conn, .body_too_large);
                return false;
            },
        }
    }
    if (conn.closing and owner.body.phase == .active) cancel(conn, .cancelled);
    return !conn.closing;
}

fn deliver_chunk(conn: *tcp.TcpConnection, bytes: []const u8) bool {
    const owner = conn.upload_owner.?;
    owner.body.start_chunk(bytes.len) catch {
        fail(conn, .sink_failure);
        return false;
    };
    owner.callback_phase = .chunk;
    const accepted = owner.route_definition.?.sink.chunk(owner.body.binding.?.context, bytes) catch {
        owner.callback_phase = .none;
        _ = finish_terminal(conn, owner.body.fail_chunk());
        tcp.close_connection(conn);
        return false;
    };
    owner.callback_phase = .none;
    const terminal = owner.body.accept_chunk(accepted) catch {
        _ = finish_terminal(conn, owner.body.fail_chunk());
        tcp.close_connection(conn);
        return false;
    };
    decoder.accept_payload(&owner.decoder, accepted.consumed) catch {
        // Shared progress already validated this exact decoder offer.
        fail(conn, .invalid_body);
        return false;
    };
    owner.pending_payload -= accepted.consumed;
    owner.ingress_read_offset = owner.decoder.mark;
    if (terminal) |action| return finish_terminal(conn, action);
    return true;
}

fn reclaim(conn: *tcp.TcpConnection) void {
    const owner = conn.upload_owner.?;
    const consumed = owner.decoder.mark;
    if (consumed == 0) return;
    const start_offset = owner.head.?.header_end;
    const remaining = owner.ingress_write_offset - consumed;
    std.mem.copyForwards(u8, conn.request_buffer[start_offset..][0..remaining], conn.request_buffer[start_offset + consumed ..][0..remaining]);
    decoder.discard_prefix(&owner.decoder, consumed) catch {
        // consumed is exactly the decoder's current mark.
        fail(conn, .invalid_body);
        return;
    };
    owner.ingress_read_offset = 0;
    owner.ingress_write_offset = remaining;
    conn.request_len = start_offset + remaining;
}

fn restored_response(conn: *tcp.TcpConnection) Response {
    const owner = conn.upload_owner.?;
    var response = Response{ .target = .{ .tcp = conn } };
    @memcpy(response.pending_headers[0..owner.pending_header_length], owner.pending_headers[0..owner.pending_header_length]);
    response.pending_header_length = owner.pending_header_length;
    return response;
}

fn finish_terminal(conn: *tcp.TcpConnection, terminal: body.BodyTerminal) bool {
    const owner = conn.upload_owner.?;
    const sink = owner.route_definition.?.sink;
    var successful = true;
    switch (terminal) {
        .cancel => |action| {
            owner.callback_phase = .cancel;
            sink.cancel(action.binding.context, action.reason);
        },
        .end => |binding| {
            owner.callback_phase = .end;
            const view = StreamingRequest.from_request(&conn.req);
            var response = restored_response(conn);
            sink.end(binding.context, &view, &response) catch { successful = false; };
            if (successful and !conn.closing) conn.finish_sync_dispatch(&response);
        },
    }
    owner.callback_phase = .none;
    if (owner.body.finish_terminal()) release_admission(owner);
    if (!successful) tcp.close_connection(conn);
    return successful and !conn.closing;
}

fn release_admission(owner: *storage.Http1UploadStorage) void {
    owner.head_target.?.router.release_body_route(owner.route_record_index) catch |err| switch (err) {
        error.BodyAdmissionMissing => owner.loop_handle.?.fail_callback(.body_admission_missing),
    };
}

/// Close initiation can defer notification until an existing begin/chunk unwinds.
pub fn cancel(conn: *tcp.TcpConnection, reason: body.BodyCancelReason) void {
    const owner = conn.upload_owner.?;
    const owned = borrow(owner);
    if (owner.body.request_cancel(reason)) |terminal| _ = finish_terminal(conn, terminal);
    finish_borrow(conn, owned);
}

fn fail(conn: *tcp.TcpConnection, reason: body.BodyCancelReason) void {
    cancel(conn, reason);
    tcp.close_connection(conn);
}

fn resume_delivery(context: *anyopaque) error{BodyDeliveryFailed}!void {
    const conn: *tcp.TcpConnection = @ptrCast(@alignCast(context));
    const owner = conn.upload_owner.?;
    const owned = borrow(owner);
    const successful = if (conn.closing) blk: {
        cancel(conn, .cancelled);
        break :blk false;
    } else progress(conn);
    conn.touch_activity();
    finish_borrow(conn, owned);
    if (!successful) return error.BodyDeliveryFailed;
}

fn cancel_delivery(context: *anyopaque) void {
    const conn: *tcp.TcpConnection = @ptrCast(@alignCast(context));
    const owned = borrow(conn.upload_owner.?);
    cancel(conn, .cancelled);
    tcp.close_connection(conn);
    finish_borrow(conn, owned);
}
