const std = @import("std");
const support = @import("test_support");
const driver = support.tcp_upload;
const body = support.request_body;
const radix = support.radix;
const RouterBundle = radix.Bundle(.{ .stream_request_bodies = true });
const View = support.streaming_request.StreamingRequest;
const Response = support.http_response.Response;

const Fixture = struct {
    bundle: RouterBundle = .{},
    router: radix.Router = .{},
    definition: body.BodyRoute = undefined,
    owner: support.http1_upload_storage.Http1UploadStorage = .{ .retirement_timer = undefined, .initialized = true },
    conn: support.tcp.TcpConnection = .{ .socket = undefined },
    input: [512]u8 = undefined,
    output: [2048]u8 = undefined,
    received: [32]u8 = undefined,
    received_len: usize = 0,
    begins: usize = 0,
    ends: usize = 0,
    cancels: usize = 0,
    pause_begin: bool = false,
    pause_chunk: bool = false,
    prefix: usize = 32,
    control: ?body.BodyControl = null,

    fn init(self: *Fixture) !void {
        self.router = try radix.Router.init(self.bundle.storage());
        self.definition = .{
            .sink = .{ .context = self, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel_sink },
            .limits = .{ .max_body_bytes = 100, .max_active = 1 },
        };
        try self.router.route_body(.post, "/upload", &self.definition);
        self.owner.head_target = .{ .context = self, .router = &self.router, .resolve = resolve };
        self.conn.router = &self.router;
        self.conn.upload_owner = &self.owner;
        self.conn.request_buffer = &self.input;
        self.conn.write_queue = &self.output;
        self.conn.protocol_state = .http;
        // This caller-owned operation spans all actual sink calls, without native I/O.
        try std.testing.expect(driver.borrow(&self.owner));
        self.conn.begin_write_batch();
    }

    fn resolve(context: *anyopaque, input: *const support.http1_upload.HeadInput, response: *Response) support.http1_upload.HeadDecision {
        const self: *Fixture = @ptrCast(@alignCast(context));
        response.header("X-Saved", "yes") catch return .{ .reject = .unavailable };
        return .{ .stream = self.router.match(input.request.path, input.method).?.body_match.? };
    }

    fn feed_head(self: *Fixture, wire: []const u8) !void {
        @memcpy(self.input[0..wire.len], wire);
        self.conn.request_len = wire.len;
        const result = support.http_parser.consume_head(&self.conn.parser, &self.conn.req, self.input[0..wire.len]);
        try std.testing.expect(result.ready != null);
        try std.testing.expect(driver.admit(&self.conn, result));
    }

    fn begin(context: *anyopaque, request: *const View, control: body.BodyControl) !body.BodyBinding {
        const self: *Fixture = @ptrCast(@alignCast(context));
        try std.testing.expectEqualStrings("/upload", request.path);
        try std.testing.expectError(error.BodyCallbackActive, control.cancel());
        self.begins += 1;
        self.control = control;
        return .{ .context = self, .readiness = if (self.pause_begin) .paused else .ready };
    }

    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
        const self: *Fixture = @ptrCast(@alignCast(context));
        try std.testing.expectError(error.BodyCallbackActive, self.control.?.@"resume"());
        const count = @min(bytes.len, self.prefix);
        @memcpy(self.received[self.received_len..][0..count], bytes[0..count]);
        self.received_len += count;
        return .{ .consumed = count, .readiness = if (self.pause_chunk or count < bytes.len) .paused else .ready };
    }

    fn end(context: *anyopaque, request: *const View, response: *Response) !void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        try std.testing.expectEqualStrings("/upload", request.path);
        try std.testing.expectError(error.BodyControlExpired, self.control.?.cancel());
        self.ends += 1;
        try response.end("200 OK", "done");
    }

    fn cancel_sink(context: *anyopaque, _: body.BodyCancelReason) void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        self.cancels += 1;
    }
};

test "H1 driver: before admission plaintext window respects retained capacity" {
    var bytes: [7]u8 = undefined;
    var conn = support.tcp.TcpConnection{ .socket = undefined, .request_buffer = &bytes, .request_len = 5 };
    try std.testing.expectEqual(@as(usize, 2), driver.read_capacity(&conn));
}

test "H1 driver: partial prefix resumes once and preserves response metadata and pipeline" {
    var fixture = Fixture{ .prefix = 2 };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 4\r\n\r\nabcdNEXT");
    try std.testing.expectEqual(@as(u64, 4), fixture.owner.body.observed);
    try std.testing.expectEqual(@as(usize, 2), fixture.owner.pending_payload);
    try std.testing.expectEqual(@as(usize, 0), driver.read_capacity(&fixture.conn));
    try fixture.control.?.@"resume"();
    try std.testing.expectEqualStrings("abcd", fixture.received[0..fixture.received_len]);
    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
    try std.testing.expectEqual(@as(usize, 0), fixture.cancels);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
    try std.testing.expect(fixture.owner.head != null);
    try std.testing.expect(fixture.owner.delivery_active);
    try std.testing.expectEqualStrings("NEXT", fixture.input[fixture.conn.pending_request_consumed..fixture.conn.request_len]);
    try std.testing.expect(std.mem.indexOf(u8, fixture.output[0..fixture.conn.write_len], "X-Saved: yes\r\n") != null);
}

test "H1 driver: final byte pause delays terminal until explicit resume" {
    var fixture = Fixture{ .pause_chunk = true };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\n\r\nx");
    try std.testing.expectEqual(@as(usize, 0), fixture.ends);
    try std.testing.expectEqual(@as(usize, 0), fixture.owner.pending_payload);
    try fixture.control.?.@"resume"();
    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
    try std.testing.expectError(error.BodyControlExpired, fixture.control.?.@"resume"());
}

test "H1 driver: paused begin sends Continue before content and cancel releases once" {
    var fixture = Fixture{ .pause_begin = true };
    try fixture.init();
    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 4\r\nExpect: 100-continue\r\n\r\n");
    try std.testing.expect(fixture.conn.expect_continue_sent);
    try std.testing.expectEqualStrings("HTTP/1.1 100 Continue\r\n\r\n", fixture.output[0..fixture.conn.write_len]);
    try fixture.control.?.cancel();
    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
    try std.testing.expectError(error.BodyControlExpired, fixture.control.?.cancel());
}
