const std = @import("std");
const support = @import("test_support");

test "H1 driver: before admission plaintext window respects retained capacity" {
    var bytes: [7]u8 = undefined;
    var conn = support.tcp.TcpConnection{ .socket = undefined, .request_buffer = &bytes, .request_len = 5 };
    try std.testing.expectEqual(@as(usize, 2), support.tcp_upload.read_capacity(&conn));
}
