from pathlib import Path
import json,hashlib,shutil,difflib,sys
r=Path('/workspaces/uWebZockets');s=Path('/tmp/uwz-m2-h1-plaintext-transport');b=Path('/tmp/uwz-m2-h1-native-lifetime');o=r/'.uwz-work/evidence/h1-plaintext/transport';name=sys.argv[1];dest=o/'snapshots'/name;dest.mkdir(parents=True)
files=[];diff=[];changes={}
for p in sorted(s.rglob('*')):
 if not p.is_file():continue
 n=p.relative_to(s);h=hashlib.sha256(p.read_bytes()).hexdigest();files.append((str(n),h))
 if (b/n).is_file() and p.read_bytes()==(b/n).read_bytes():continue
 q=dest/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);changes[str(n)]=h
 old=(b/n).read_text() if (b/n).is_file() else ''
 diff.extend(difflib.unified_diff(old.splitlines(True),p.read_text().splitlines(True),fromfile='a/'+str(n),tofile='b/'+str(n)))
(o/(name+'.patch')).write_text(''.join(diff));(o/(name+'-manifest.json')).write_text(json.dumps({'source':str(s),'source_digest':hashlib.sha256(json.dumps(files).encode()).hexdigest(),'files':files,'changed_files':changes},indent=2)+'\n');print(name,hashlib.sha256(json.dumps(files).encode()).hexdigest())
