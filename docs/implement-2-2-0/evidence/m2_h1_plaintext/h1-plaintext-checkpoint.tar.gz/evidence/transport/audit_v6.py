from pathlib import Path
import hashlib,json,os,platform,re
r=Path('/workspaces/uWebZockets/.uwz-work/evidence/h1-plaintext/transport');s=Path('/tmp/uwz-m2-h1-plaintext-transport');b=Path('/tmp/uwz-m2-h1-native-lifetime');m=json.loads((r/'v6-manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(s/n)==h for n,h in m['files'])
unchanged=['src/core/http1_upload_storage.zig','src/core/http1_upload.zig','src/http/request_body.zig','src/http/body_decoder.zig','src/http/parser.zig','src/http/request.zig','src/router/app.zig','src/router/config.zig','src/tests/main.zig']
assert all(sha(s/n)==sha(b/n) for n in unchanged)
def fields(p,marker,end):
 t=p.read_text();return t[t.index(marker):t.index(end,t.index(marker))]
a=fields(s/'src/core/tcp.zig','pub const TcpConnection = struct {','    /// Resets protocol detection');z=fields(b/'src/core/tcp.zig','pub const TcpConnection = struct {','    /// Resets protocol detection');assert a==z
new=(s/'src/core/tcp_upload.zig').read_text();allocation_patterns=re.findall(r'\b(?:allocator|alloc|realloc|create|page_allocator|malloc)\b',new);assert not allocation_patterns
records={}
for p in sorted(r.glob('*.json')):
 record=json.loads(p.read_text())
 if 'argv' not in record:continue
 records[p.name]={'exit_status':record.get('exit_status'),'source_stable':record.get('source_before')==record.get('source_after'),'coverage':record.get('coverage')}
(r/'final-v6-audit.json').write_text(json.dumps({'source_digest':m['source_digest'],'files_verified':len(m['files']),'changed_files':m['changed_files'],'unchanged_canonical_files':{n:sha(s/n) for n in unchanged},'tcp_stored_fields_identical':True,'tcp_stored_fields_sha256':hashlib.sha256(a.encode()).hexdigest(),'new_driver_allocation_identifier_matches':allocation_patterns,'environment':{'platform':platform.platform(),'python':platform.python_version(),'PATH':os.environ.get('PATH'),'LANG':os.environ.get('LANG'),'LC_ALL':os.environ.get('LC_ALL')},'checks':records,'invalid_tdd':['red-driver.json'],'scope':'source/layout textual invariance and recorded checks, no native timing or performance proof'},indent=2)+'\n')
print('Verified',len(m['files']),'files; canonical modules and TCP stored fields unchanged; no allocator identifiers in new driver')
