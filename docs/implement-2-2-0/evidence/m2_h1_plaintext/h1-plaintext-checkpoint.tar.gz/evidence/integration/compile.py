"""Explicit compile-only replay. Never starts a server or client."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/workspaces/uWebZockets')
HERE = Path(__file__).resolve().parent
ZIG = '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig'


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as source:
        while data := source.read(8192):
            result.update(data)
    return result.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, default=Path('/tmp/uwz-m2-h1-native-lifetime'))
    parser.add_argument('--output', type=Path, default=Path('/tmp/uwz-h1-profile-preparation'))
    parser.add_argument('--record', default='compile')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    argv = [ZIG, 'build-exe', '-OReleaseSafe', '--dep', 'uWebZockets', '-Mroot=' + str(HERE / 'profile.zig'), '-OReleaseSafe', '--dep', 'c', '--dep', 'xev', '--dep', 'zslay', '-MuWebZockets=' + str(args.source / 'src/root.zig'), '-Mc=' + str(ROOT / '.uwz-work/evidence/h1-transport/r2/c-native.zig'), '--dep', 'xev_impl', '-Mxev=' + str(args.source / 'src/core/xev.zig'), '-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig']
    seed = json.loads((ROOT / '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json').read_text())['argv']
    zslay = next(value.split('=', 1)[1] for value in seed if value.startswith('-Mzslay='))
    argv += ['-Mzslay=' + str(ROOT / zslay), '-lc++', '-lc']
    argv += [str(ROOT / 'zig-out/lib' / name) for name in ('libuWebZockets.a', 'libssl.a', 'libcrypto.a', 'liblsquic.a', 'libdeflate.a', 'libz.a')]
    argv += ['-j2', '--cache-dir', str(args.output / 'cache'), '--global-cache-dir', str(args.output / 'global'), '-femit-bin=' + str(args.output / 'profile')]
    inputs = [Path(value.split('=', 1)[1]) for value in argv if value.startswith('-M')]
    inputs += [Path(value) for value in argv if value.endswith('.a')]
    inputs += [Path(ZIG)]
    source_inputs = {str(path.relative_to(args.source)): digest(path) for path in sorted(args.source.rglob('*')) if path.is_file()}
    (HERE / (args.record + '-source-inputs.json')).write_text(json.dumps(source_inputs, indent=2) + '\n')
    record = {'source_tree_sha256': hashlib.sha256(json.dumps(list(source_inputs.items())).encode()).hexdigest(), 'source_tree_encoding': 'sha256(json.dumps(relative_path, file_sha256 pairs in sorted pathlib path order))', 'argv': argv, 'cwd': str(args.source), 'optimization': 'ReleaseSafe', 'explicit_environment': {}, 'input_sha256': {str(path): digest(path) for path in inputs}, 'execution': 'compile only; no server/client execution'}
    with (HERE / (args.record + '.log')).open('wb') as log:
        result = subprocess.run(argv, cwd=args.source, stdout=log, stderr=subprocess.STDOUT)
    record['exit_status'] = result.returncode
    if result.returncode == 0:
        record['binary_sha256'] = digest(args.output / 'profile')
    (HERE / (args.record + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print((HERE / (args.record + '.log')).read_text(), end='')
    print('Exit status:', result.returncode)
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
