"""Bind the owned ordinary client run to its actual immutable inputs."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path('/workspaces/uWebZockets')
EVIDENCE = ROOT / '.uwz-work/evidence/h1-plaintext/integration'
SOURCE = Path('/tmp/uwz-m2-h1-plaintext-combined')
ARTIFACTS = Path('/tmp/uwz-h1-profile-live-v1')
RECORD = EVIDENCE / 'runtime-combined-v1-binding.json'
LOADER = Path('/nix/store/znb3q6g1ik34454j3vcjx824h1871asg-glibc-2.42-84/lib/ld-linux-x86-64.so.2')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_snapshot():
    pairs = [(str(p.relative_to(SOURCE)), sha(p)) for p in sorted(SOURCE.rglob('*')) if p.is_file()]
    return {'digest': hashlib.sha256(json.dumps(pairs).encode()).hexdigest(), 'files': pairs}


def snapshot():
    build = json.loads((EVIDENCE / 'compile-combined-v1.json').read_text())
    manifest = ROOT / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json'
    override = json.loads(manifest.read_text())
    files = {p: sha(p) for p in build['input_sha256']}
    for path in [EVIDENCE / 'probe.py', Path(__file__), EVIDENCE / 'compile-combined-v1.json', SOURCE / 'tests/static_interop/probe.py', Path(sys.executable), Path('/tmp/uwz-h1-profile-combined/profile'), LOADER, LOADER.parent / 'libc.so.6', LOADER.parent / 'libm.so.6']:
        files[str(path)] = sha(path)
    actual_override = {p: sha(Path(override['path']) / p) for p in override['files_sha256']}
    assert actual_override == override['files_sha256']
    sources = source_snapshot()
    assert sources['digest'] == build['source_tree_sha256']
    assert all(files[p] == h for p, h in build['input_sha256'].items())
    assert files['/tmp/uwz-h1-profile-combined/profile'] == build['binary_sha256']
    return {'source': sources, 'files': files, 'override_manifest_sha256': sha(manifest), 'override_commit': override['commit'], 'override_files': actual_override}


assert not RECORD.exists() and not ARTIFACTS.exists()
record = {'authorization': 'Root combined integration review approved; ordinary owned protocol/API clients only', 'before': snapshot()}
argv = [sys.executable, str(EVIDENCE / 'probe.py'), '--source', str(SOURCE), '--server', '/tmp/uwz-h1-profile-combined/profile', '--build-record', str(EVIDENCE / 'compile-combined-v1.json'), '--artifacts', str(ARTIFACTS), '--port', '18886', '--loader', str(LOADER), '--library-path', str(LOADER.parent), '--root-authorized-runtime']
record.update(argv=argv, cwd=str(ROOT))
RECORD.write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
try:
    with (EVIDENCE / 'runtime-combined-v1-runner.log').open('wb') as log:
        result = subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    record['exit_status'] = result.returncode
finally:
    record['elapsed_seconds'] = time.monotonic() - started
    record['after'] = snapshot()
    record['inputs_unchanged'] = record['before'] == record['after']
    for name in ['results.json', 'server.log', 'server.command']:
        source = ARTIFACTS / name
        if source.exists():
            target = EVIDENCE / ('runtime-combined-v1-' + name)
            target.write_bytes(source.read_bytes())
    RECORD.write_text(json.dumps(record, indent=2) + '\n')
print('Exit status:', record.get('exit_status'))
print('Inputs unchanged:', record['inputs_unchanged'])
sys.exit(record.get('exit_status', 1))
