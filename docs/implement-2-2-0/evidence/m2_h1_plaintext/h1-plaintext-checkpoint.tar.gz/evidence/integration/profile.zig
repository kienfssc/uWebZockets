const std = @import("std");
const uz = @import("uWebZockets");
const Hash = std.crypto.hash.sha2.Sha256;

const Metadata = struct {
    expected: [512]u8 = undefined,
    length: usize = 0,
    borrowed: []const u8 = "",
};
const Slot = struct {
    owner: *State,
    active: bool = false,
    hash: Hash = Hash.init(.{}),
    bytes: u64 = 0,
    pause_at: ?u64 = null,
    paused_once: bool = false,
    mode: enum { normal, sink_error, invalid_progress } = .normal,
    metadata: [6]Metadata = [_]Metadata{.{}} ** 6,
};
const State = struct {
    slot: Slot = undefined,
    control: ?uz.BodyControl = null,
    stale: ?uz.BodyControl = null,
    begin_calls: u64 = 0,
    failed_begins: u64 = 0,
    begins: u64 = 0,
    ends: u64 = 0,
    cancels: u64 = 0,
    reason: []const u8 = "none",
};

fn save(output: *Metadata, value: []const u8) !void {
    if (value.len > output.expected.len) return error.MetadataTooLong;
    @memcpy(output.expected[0..value.len], value);
    output.length = value.len;
    output.borrowed = value;
}

fn begin(context: *anyopaque, request: *const uz.StreamingRequest, control: uz.BodyControl) !uz.BodyBinding {
    const state: *State = @ptrCast(@alignCast(context));
    state.begin_calls += 1;
    const mode = request.headers.get("x-mode") orelse "normal";
    if (std.mem.eql(u8, mode, "failed_begin")) {
        state.failed_begins += 1;
        return error.ApplicationBeginRefused;
    }
    if (state.slot.active) return error.FixtureSlotBusy;
    state.slot = .{ .owner = state };
    const slot = &state.slot;
    const tag = request.params.get("tag") orelse return error.MissingTag;
    const marker = request.headers.get("x-metadata") orelse return error.MissingMetadata;
    const values = [_][]const u8{ request.method, request.target, request.path, request.query, tag, marker };
    for (&slot.metadata, values) |*output, value| try save(output, value);
    const pause = request.headers.get("x-pause") orelse "none";
    if (std.mem.eql(u8, mode, "sink_error")) slot.mode = .sink_error;
    if (std.mem.eql(u8, mode, "invalid_progress")) slot.mode = .invalid_progress;
    if (std.mem.eql(u8, pause, "partial")) slot.pause_at = 7;
    if (std.mem.eql(u8, pause, "final")) {
        slot.pause_at = try std.fmt.parseInt(u64, request.headers.get("x-size") orelse return error.MissingSize, 10);
    }
    const paused = std.mem.eql(u8, pause, "begin");
    slot.paused_once = paused;
    slot.active = true;
    state.begins += 1;
    state.control = control;
    return .{ .context = slot, .readiness = if (paused) .paused else .ready };
}

fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    if (slot.mode == .sink_error) return error.ApplicationSinkRefused;
    if (slot.mode == .invalid_progress) return .{ .consumed = input.len + 1, .readiness = .ready };
    var accepted = input.len;
    var pause = false;
    if (!slot.paused_once) {
        if (slot.pause_at) |at| {
            accepted = @intCast(@min(input.len, at - slot.bytes));
            pause = slot.bytes + accepted == at;
        }
    }
    slot.hash.update(input[0..accepted]);
    slot.bytes += accepted;
    if (pause) slot.paused_once = true;
    return .{ .consumed = accepted, .readiness = if (pause) .paused else .ready };
}

fn end(context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const state = slot.owner;
    defer slot.active = false;
    state.ends += 1;
    state.stale = state.control;
    state.control = null;
    var metadata_ok = true;
    const values = [_][]const u8{ request.method, request.target, request.path, request.query, request.params.get("tag") orelse "", request.headers.get("x-metadata") orelse "" };
    for (&slot.metadata, values) |*saved, value| {
        const expected = saved.expected[0..saved.length];
        metadata_ok = metadata_ok and std.mem.eql(u8, expected, value) and std.mem.eql(u8, expected, saved.borrowed);
    }
    var digest: [Hash.digest_length]u8 = undefined;
    slot.hash.final(&digest);
    const hex = std.fmt.bytesToHex(digest, .lower);
    var output: [256]u8 = undefined;
    const body = try std.fmt.bufPrint(&output, "{{\"bytes\":{d},\"sha256\":\"{s}\",\"metadata_ok\":{}}}", .{ slot.bytes, hex, metadata_ok });
    try response.text(body);
}

fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    slot.active = false;
    slot.owner.cancels += 1;
    slot.owner.reason = @tagName(reason);
    slot.owner.stale = slot.owner.control;
    slot.owner.control = null;
}

fn middleware(_: *anyopaque, _: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
    response.append_header("X-Middleware", "retained") catch |err| {
        std.log.err("middleware failed: {}", .{err});
        return .stop;
    };
    return .continue_dispatch;
}

fn reply(response: *uz.Response, value: []const u8) void {
    response.text(value) catch |err| std.log.err("response failed: {}", .{err});
}

fn health(_: *uz.Request, response: *uz.Response) void {
    reply(response, "ok");
}

fn echo(_: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    reply(response, request.body);
}

fn status(context: *anyopaque, _: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    var output: [512]u8 = undefined;
    const body = std.fmt.bufPrint(&output, "{{\"begin_calls\":{d},\"failed_begins\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"active\":{},\"bytes\":{d},\"pause_reached\":{},\"reason\":\"{s}\"}}", .{ state.begin_calls, state.failed_begins, state.begins, state.ends, state.cancels, state.slot.active, state.slot.bytes, state.slot.paused_once, state.reason }) catch |err| {
        std.log.err("status formatting failed: {}", .{err});
        return;
    };
    reply(response, body);
}

fn control_route(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const stale = std.mem.eql(u8, request.path, "/stale");
    const control = (if (stale) state.stale else state.control) orelse {
        reply(response, "missing");
        return;
    };
    const result = if (std.mem.eql(u8, request.path, "/cancel")) control.cancel() else control.@"resume"();
    result catch |err| {
        reply(response, @errorName(err));
        return;
    };
    reply(response, "ok");
}

pub fn main(init: std.process.Init) !void {
    const root = init.environ_map.get("H1_PROFILE_ROOT") orelse return error.MissingRoot;
    const port = try std.fmt.parseInt(u16, init.environ_map.get("H1_PROFILE_PORT") orelse return error.MissingPort, 10);
    var state: State = .{};
    state.slot = .{ .owner = &state };
    const sink: uz.BodySink = .{ .context = &state, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel };
    const upload: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 100000000, .max_active = 1 }, .middleware_policy = .headers_only };
    const limit: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 32, .max_active = 1 }, .middleware_policy = .headers_only };
    const empty: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 0, .max_active = 1 }, .middleware_policy = .headers_only };
    {
        var server = try uz.Server.preset(init.io, .{ .max_connections = 8, .stream_request_bodies = true }).build(init.arena.allocator());
        defer server.deinit();
        _ = try server.use(&state, middleware);
        _ = try server.route_body(.post, "/upload/:tag", &upload);
        _ = try server.route_body(.post, "/limit/:tag", &limit);
        _ = try server.route_body(.post, "/empty/:tag", &empty);
        _ = try server.get("/health", health);
        _ = try server.get_context("/status", &state, status);
        _ = try server.get_context("/resume", &state, control_route);
        _ = try server.get_context("/cancel", &state, control_route);
        _ = try server.get_context("/stale", &state, control_route);
        _ = try server.route_context(.post, "/echo", &state, echo);
        _ = try server.static("/files", root, .{});
        try server.listen("127.0.0.1", port);
        try server.catch_shutdown_signals();
        try server.run();
        try server.shutdown();
    }
    std.log.info("h1 profile shutdown drained", .{});
}
