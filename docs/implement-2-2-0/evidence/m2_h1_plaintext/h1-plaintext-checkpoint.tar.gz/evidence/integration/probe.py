"""Ordinary owned plaintext checks. Run only after Root authorizes combined source."""
import argparse
import hashlib
import importlib.util
import json
import os
import shlex
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

BOUND = 8192
EXACT = 100000000
FILE_SIZE = 16 * 1024 * 1024 + 97
SENTINEL = b'final-upload-sentinel!'


def require(condition, detail):
    if not condition:
        raise RuntimeError(detail)


def payload(size):
    offset = 0
    pattern = bytes(range(1, 252))
    while offset < size:
        count = min(BOUND, size - offset)
        block = bytearray(pattern[(offset + index) % 251] for index in range(count))
        start = max(offset, size - len(SENTINEL))
        if start < offset + count:
            block[start - offset:] = SENTINEL[len(SENTINEL) - (size - start):]
        yield bytes(block)
        offset += count


def connect(port):
    client = socket.create_connection(('127.0.0.1', port), timeout=30)
    client.settimeout(120)
    return client


def read_line(source):
    line = source.readline(65537)
    if not line:
        raise EOFError('EOF before response header')
    require(len(line) <= 65536 and line.endswith(b'\r\n'), 'missing/bounded CRLF line')
    return line


def read_exact(source, size):
    require(size <= BOUND, 'harness read exceeds bound')
    data = source.read(size)
    require(len(data) == size, f'premature EOF: {len(data)} != {size}')
    return data


def response(source, *, expected=None, interim_only=False):
    interim = []
    while True:
        line = read_line(source)
        parts = line.split(maxsplit=2)
        require(len(parts) == 3 and parts[0] == b'HTTP/1.1', f'invalid status line: {line!r}')
        status = int(parts[1])
        fields = {}
        total = len(line)
        while (line := read_line(source)) != b'\r\n':
            total += len(line)
            require(total <= 65536, 'headers exceed bound')
            name, value = line[:-2].split(b':', 1)
            fields.setdefault(name.decode().lower(), []).append(value.strip().decode())
        if status != 100:
            require(not interim_only, f'expected 100, got final {status}')
            break
        interim.append({'status': status, 'headers': fields})
        if interim_only:
            return {'interim': interim}
    count = 0
    digest = hashlib.sha256()
    small = bytearray()

    def consume(size):
        nonlocal count
        while size:
            block = read_exact(source, min(BOUND, size))
            if expected is not None:
                require(block == expected.read(len(block)), f'exact file mismatch at {count}')
            elif len(small) + len(block) <= 4096:
                small.extend(block)
            else:
                raise RuntimeError('unexpected non-file response exceeds 4096')
            digest.update(block)
            count += len(block)
            size -= len(block)

    if 'transfer-encoding' in fields:
        require(fields['transfer-encoding'] == ['chunked'] and 'content-length' not in fields, 'ambiguous response framing')
        while True:
            size = int(read_line(source).split(b';', 1)[0].strip(), 16)
            if not size:
                require(read_line(source) == b'\r\n', 'unexpected response trailers')
                break
            consume(size)
            require(read_exact(source, 2) == b'\r\n', 'chunk terminator differs')
    else:
        require(len(fields.get('content-length', [])) == 1, 'missing/surplus Content-Length')
        consume(int(fields['content-length'][0]))
    if expected is not None:
        require(expected.read(1) == b'', 'file response truncated expected fixture')
    return {'status': status, 'headers': fields, 'bytes': count, 'sha256': digest.hexdigest(), 'body': bytes(small).decode('ascii'), 'interim': interim}


def head(path, size, *, chunked=False, pause='none', mode='normal', expect=False, close=False):
    fields = [f'POST {path} HTTP/1.1', 'Host: fixture', 'X-Metadata: retained-individual-header', f'X-Size: {size}', f'X-Pause: {pause}', f'X-Mode: {mode}']
    fields += ['Transfer-Encoding: chunked'] if chunked else [f'Content-Length: {size}']
    if expect:
        fields += ['Expect: 100-continue']
    if close:
        fields += ['Connection: close']
    return ('\r\n'.join(fields) + '\r\n\r\n').encode()


def send_payload(client, size, chunked=False, split=False):
    digest = hashlib.sha256()
    count = 0
    for block in payload(size):
        if chunked:
            prefix = f'{len(block):x};bounded=yes\r\n'.encode()
            if split:
                client.sendall(prefix[:1])
                client.sendall(prefix[1:])
            else:
                client.sendall(prefix)
        client.sendall(block)
        if chunked:
            client.sendall(b'\r\n')
        digest.update(block)
        count += len(block)
    if chunked:
        client.sendall(b'0\r\nX-Discarded-Trailer: ordinary\r\n\r\n')
    require(count == size, 'logical generator count differs')
    return {'bytes': count, 'sha256': digest.hexdigest()}


def get(port, path):
    with connect(port) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(f'GET {path} HTTP/1.1\r\nHost: fixture\r\nConnection: close\r\n\r\n'.encode())
        result = response(source)
        require(source.read(1) == b'', 'surplus bytes after close response')
        require(result['status'] == 200, f'{path} status differs')
        return result


def counters(port):
    return json.loads(get(port, '/status')['body'])


def paused(port):
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        value = counters(port)
        if value['active'] and value['pause_reached']:
            return value
        time.sleep(0.02)
    raise RuntimeError('ordinary HTTP status did not report pause')


def upload_result(result, sent):
    require(result['status'] == 200, f'upload final status: {result}')
    require(result['headers'].get('x-middleware') == ['retained'], 'pending middleware header lost')
    actual = json.loads(result['body'])
    require(actual['bytes'] == sent['bytes'] and actual['sha256'] == sent['sha256'] and actual['metadata_ok'] is True, f'upload digest/metadata differs: {actual}, {sent}')
    return actual


def upload(port, size, *, chunked=False, pause='none', expect=False, path='/upload/capture?q=retained'):
    before = counters(port)
    with connect(port) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head(path, size, chunked=chunked, pause=pause, expect=expect, close=True))
        interim = response(source, interim_only=True) if expect else None
        pause_state = None
        if pause == 'begin':
            pause_state = paused(port)
            require(get(port, '/resume')['body'] == 'ok', 'begin resume failed')
        sent = send_payload(client, size, chunked, split=chunked)
        if pause in ('partial', 'final'):
            pause_state = paused(port)
            require(pause_state['bytes'] == (7 if pause == 'partial' else size), 'accepted prefix count differs')
            require(get(port, '/resume')['body'] == 'ok', 'body resume failed')
        result = response(source)
        actual = upload_result(result, sent)
        require(source.read(1) == b'', 'upload response surplus / missing EOF')
    after = counters(port)
    require(after['begins'] == before['begins'] + 1 and after['ends'] == before['ends'] + 1 and after['cancels'] == before['cancels'], 'successful upload terminal counts differ')
    require(get(port, '/stale')['body'] == 'BodyControlExpired', 'completed control remained valid')
    return {'sent': sent, 'response': result, 'actual': actual, 'before': before, 'after': after, 'pause': pause_state, 'interim': interim}


def pipeline(port):
    with connect(port) as client, client.makefile('rb', buffering=BOUND) as source:
        sent = []
        for chunked in (False, True):
            client.sendall(head('/upload/pipeline?q=retained', 257, chunked=chunked))
            sent.append(send_payload(client, 257, chunked))
        client.sendall(b'POST /echo HTTP/1.1\r\nHost: fixture\r\nContent-Length: 4\r\nConnection: close\r\n\r\necho')
        values = [response(source), response(source), response(source)]
        for item, expected in zip(values[:2], sent):
            upload_result(item, expected)
        require(values[2]['status'] == 200 and values[2]['body'] == 'echo', 'buffered pipeline differs')
        require(source.read(1) == b'', 'pipeline surplus / missing EOF')
        return values


def file_case(port, fixture, close):
    with connect(port) as client, client.makefile('rb', buffering=BOUND) as source, fixture.open('rb') as expected:
        request = b'GET /files/large.bin HTTP/1.1\r\nHost: fixture\r\nAccept-Encoding: identity\r\n'
        request += b'Connection: close\r\n\r\n' if close else b'\r\nGET /health HTTP/1.1\r\nHost: fixture\r\nConnection: close\r\n\r\n'
        client.sendall(request)
        result = response(source, expected=expected)
        require(result['status'] == 200 and result['bytes'] == FILE_SIZE, 'file status/length differs')
        sibling = None if close else response(source)
        if sibling is not None:
            require(sibling['status'] == 200 and sibling['body'] == 'ok', 'file pipeline health differs')
        require(source.read(1) == b'', 'file response surplus / missing EOF')
        return {'file': result, 'health': sibling}


def observe_refusal(port, path, size, mode='normal', chunked=False):
    before = counters(port)
    with connect(port) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head(path, size, mode=mode, expect=True, close=True, chunked=chunked))
        result = response(source)
        require(result['status'] >= 400 and not result['interim'], 'Expect refusal unexpectedly admitted content')
        require(source.read(1) == b'', 'refusal surplus / missing EOF')
    after = counters(port)
    require(after['ends'] == before['ends'] and after['cancels'] == before['cancels'] and after['begins'] == before['begins'], 'refusal acquired binding ownership')
    attempts = 1 if mode == 'failed_begin' else 0
    require(after['begin_calls'] == before['begin_calls'] + attempts and after['failed_begins'] == before['failed_begins'] + attempts, 'refusal begin accounting differs')
    return {'response': result, 'before': before, 'after': after, 'sent_logical_bytes': 0}


def terminal_result(source):
    if not source.peek(1):
        return {'terminal': 'EOF', 'detail': 'EOF before response header'}
    value = response(source)
    require(value['status'] >= 400, 'failed upload emitted success')
    require(source.read(1) == b'', 'failed upload surplus / missing EOF')
    return {'terminal': 'final_response', 'response': value}


def sink_failure(port, mode):
    before = counters(port)
    with connect(port) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head('/upload/failure?q=retained', 257, mode=mode, close=True))
        sent = send_payload(client, 257)
        terminal = terminal_result(source)
    after = counters(port)
    require(after['begins'] == before['begins'] + 1 and after['ends'] == before['ends'] and after['cancels'] == before['cancels'] + 1 and after['reason'] == 'sink_failure', 'sink failure terminal accounting differs')
    return {'sent': sent, 'terminal': terminal, 'before': before, 'after': after}


def application_cancel_and_quota(port):
    before = counters(port)
    with connect(port) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head('/upload/held?q=retained', 257, pause='begin', expect=True))
        interim = response(source, interim_only=True)
        held = paused(port)
        refused = observe_refusal(port, '/upload/quota?q=retained', 1)
        require(refused['after']['begins'] == held['begins'], 'quota refusal called begin')
        require(get(port, '/cancel')['body'] == 'ok', 'application cancel failed')
        terminal = terminal_result(source)
    after = counters(port)
    require(after['begins'] == before['begins'] + 1 and after['ends'] == before['ends'] and after['cancels'] == before['cancels'] + 1 and after['reason'] == 'cancelled', 'application cancellation accounting differs')
    require(get(port, '/stale')['body'] == 'BodyControlExpired', 'cancelled token remained valid')
    return {'before': before, 'after': after, 'held': held, 'quota': refused, 'interim': interim, 'terminal': terminal, 'sent_logical_bytes': 0}


def malformed_body(port):
    before = counters(port)
    with connect(port) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head('/upload/malformed?q=retained', 1, chunked=True, expect=True, close=True))
        interim = response(source, interim_only=True)
        client.sendall(b'G\r\n')
        terminal = terminal_result(source)
    after = counters(port)
    require(after['ends'] == before['ends'] and after['cancels'] == before['cancels'] + 1 and after['reason'] == 'invalid_body', 'malformed framing accounting differs')
    return {'before': before, 'after': after, 'interim': interim, 'terminal': terminal}


def chunked_limit(port):
    before = counters(port)
    with connect(port) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head('/limit/chunked?q=retained', 33, chunked=True, expect=True, close=True))
        interim = response(source, interim_only=True)
        sent = send_payload(client, 33, True)
        terminal = terminal_result(source)
    after = counters(port)
    require(after['ends'] == before['ends'] and after['cancels'] == before['cancels'] + 1 and after['reason'] == 'body_too_large', 'chunked limit accounting differs')
    return {'sent': sent, 'interim': interim, 'terminal': terminal, 'before': before, 'after': after}


def run_cases(port, fixture, results, output):
    cases = [
        ('fixed_exact100000000', lambda: upload(port, EXACT)),
        ('chunked_exact100000000', lambda: upload(port, EXACT, chunked=True)),
        ('empty', lambda: upload(port, 0, path='/empty/zero?q=retained')),
        ('empty_chunked', lambda: upload(port, 0, chunked=True, path='/empty/zero?q=retained')),
        ('limit_exact32', lambda: upload(port, 32, path='/limit/bound?q=retained')),
        ('limit_chunked_exact32', lambda: upload(port, 32, chunked=True, path='/limit/bound?q=retained')),
        ('limit_chunked_over33', lambda: chunked_limit(port)),
        ('begin_expect100', lambda: upload(port, 257, pause='begin', expect=True)),
        ('partial_prefix', lambda: upload(port, 257, pause='partial', chunked=True)),
        ('final_byte_fixed', lambda: upload(port, 257, pause='final')),
        ('final_byte_chunked', lambda: upload(port, 257, pause='final', chunked=True)),
        ('stream_stream_buffered_pipeline', lambda: pipeline(port)),
        ('file_health_pipeline', lambda: file_case(port, fixture, False)),
        ('file_close', lambda: file_case(port, fixture, True)),
        ('declared_limit_refusal', lambda: observe_refusal(port, '/limit/refused?q=retained', 33)),
        ('failed_begin', lambda: observe_refusal(port, '/upload/refused?q=retained', 1, 'failed_begin')),
        ('sink_error', lambda: sink_failure(port, 'sink_error')),
        ('invalid_progress', lambda: sink_failure(port, 'invalid_progress')),
        ('application_cancel_quota', lambda: application_cancel_and_quota(port)),
        ('malformed_chunk', lambda: malformed_body(port)),
    ]
    for label, operation in cases:
        try:
            results['cases'][label] = {'status': 'passed', 'result': operation()}
        except Exception as error:
            results['cases'][label] = {'status': 'failed', 'error': repr(error)}
        output.write_text(json.dumps(results, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--server', type=Path, required=True)
    parser.add_argument('--build-record', type=Path, required=True)
    parser.add_argument('--artifacts', type=Path, required=True)
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--loader', default='')
    parser.add_argument('--library-path', default='')
    parser.add_argument('--root-authorized-runtime', action='store_true')
    args = parser.parse_args()
    require(args.root_authorized_runtime, 'Root must explicitly authorize combined-source runtime first')
    args.artifacts.mkdir(parents=True, exist_ok=False)
    helper_path = args.source / 'tests/static_interop/probe.py'
    spec = importlib.util.spec_from_file_location('normal_static_helpers', helper_path)
    helpers = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helpers)
    build_record = json.loads(args.build_record.read_text())
    require(build_record['exit_status'] == 0 and build_record['binary_sha256'] == helpers.digest_file(args.server)['sha256'], 'binary differs from successful compile record')
    helpers.precheck_port(args.port)
    results = {'cases': {}, 'optimization': 'ReleaseSafe', 'allocation_scope': 'Bounded application sink and client chunks; no allocator instrumentation claim', 'helper': helpers.digest_file(helper_path), 'server_identity': helpers.digest_file(args.server), 'runtime_started': False, 'build_record': build_record, 'build_record_identity': helpers.digest_file(args.build_record), 'python_version': sys.version, 'client_identity': helpers.digest_file(Path(__file__)), 'python_identity': helpers.digest_file(Path(os.sys.executable))}
    output = args.artifacts / 'results.json'
    forced = False
    with tempfile.TemporaryDirectory(prefix='uwz-h1-profile-') as temporary:
        runtime = Path(temporary)
        fixture = runtime / 'large.bin'
        with fixture.open('wb') as target:
            for block in payload(FILE_SIZE):
                target.write(block)
        results['fixture'] = helpers.digest_file(fixture)
        env_values = {'H1_PROFILE_ROOT': str(runtime), 'H1_PROFILE_PORT': str(args.port)}
        environment = dict(os.environ)
        environment.update(env_values)
        arguments = [str(args.server.resolve())]
        if args.loader:
            require(bool(args.library_path) and '*' not in args.loader, 'invalid loader prefix')
            arguments = [args.loader, '--library-path', args.library_path, *arguments]
        results.update(argv=arguments, cwd=str(args.source.resolve()), explicitly_passed_environment=env_values)
        (args.artifacts / 'server.command').write_text(shlex.join(arguments) + '\n')
        with (args.artifacts / 'server.log').open('wb') as log:
            server = subprocess.Popen(arguments, cwd=args.source, env=environment, stdout=log, stderr=subprocess.STDOUT)
            results.update(child_pid=server.pid, runtime_started=True, port=args.port)
            try:
                for _ in range(50):
                    require(server.poll() is None, 'owned server exited before readiness')
                    try:
                        record = helpers.listener_record(server.pid, args.port, False)
                        break
                    except RuntimeError:
                        time.sleep(0.1)
                else:
                    raise RuntimeError('owned server listener readiness deadline')
                results['listener_raw'] = record
                results['readiness'] = get(args.port, '/health')
                require(results['readiness']['body'] == 'ok', 'health readiness differs')
                run_cases(args.port, fixture, results, output)
            except Exception as error:
                results['harness_failure'] = repr(error)
                raise
            finally:
                if server.poll() is None:
                    server.terminate()
                    try:
                        server.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        forced = True
                        server.kill()
                        server.wait(timeout=5)
                results.update(child_reaped=server.poll() is not None, child_status=server.returncode, forced_kill_failure=forced)
                output.write_text(json.dumps(results, indent=2) + '\n')
        require(not forced and server.returncode == 0, 'owned server shutdown/reap failed')
        results['post_deinit_marker'] = b'h1 profile shutdown drained' in (args.artifacts / 'server.log').read_bytes()
        output.write_text(json.dumps(results, indent=2) + '\n')
        require(results['post_deinit_marker'], 'post-deinit marker absent')
    require(all(item['status'] == 'passed' for item in results['cases'].values()), 'ordinary case failures; see results.json')


if __name__ == '__main__':
    main()
