# Full plaintext H1 request-streaming implementation

Architect: /root/architect_h1_retirement_implementation. Root owns decisions,
integration, final evidence and delivery. This executes M2 of 2.2.0-TODO.md;
the full milestone and later milestones remain the active goal.

Spec: docs/adr/0008-request-body-streaming.md, the accepted head seam at
.uwz-work/evidence/h1-transport/r3/h1-head-driver-seam.md, and the native unit
contract at .uwz-work/evidence/h1-transport/r3/native-lifetime-minimum-contract.md.
The source-only submit audit beside that contract is binding context.

## Global Constraints

- Authoritative specs (read only relevant sections, not task history):
  docs/adr/0008-request-body-streaming.md;
  .uwz-work/evidence/h1-transport/r3/h1-head-driver-seam.md;
  .uwz-work/evidence/h1-transport/r3/native-lifetime-minimum-contract.md;
  .uwz-work/evidence/h1-transport/r3/submit-callback-source-audit.md;
  .uwz-work/evidence/upload-platform/eligible-retirement-contract.md;
  .uwz-work/evidence/h1-retirement-policy-contract.md.
- Read AGENTS.md and CODING_CONVENTION.md. Zig 0.16.0; named explicit types,
  explicit callback contexts, shallow flow, no hidden globals or OOP. No new
  markers, emojis, direct src stdout/stderr, or silenced errors. Do not weaken
  any test, assertion, threshold or lint. No dynamic library allocation after
  startup. Do not alter maintained refs, pins, build dependencies or root exports.
- Immutable starting source: /tmp/uwz-m2-h1-native-lifetime, 1020 files0444,
  digest81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108.
  Durable recovery is in docs/implement-2-2-0/evidence/m2_h1_invariant_failure
  and its predecessor archives. Root HEAD877a2ac8e0d004a566aef1eac775eb06655e37e9
  changes recovery documentation; production source remains3cc8f81.
- Work in separate NEW /tmp source copies, no hardlinks, symlinks or inherited
  caches. App copy: /tmp/uwz-m2-h1-plaintext-app. Transport copy:
  /tmp/uwz-m2-h1-plaintext-transport. All binaries/cache/generated inputs/large IR
  stay /tmp. Keep exact small source snapshots/preimages/patches and every
  command/status/log/hash durably under the task's workspace evidence directory.
  /tmp can disappear across goal continuations; paths/hashes alone cannot save code.
- You are not alone. Do not revert others. No subagents. Root serializes final
  test_support/tests/main/config/docs and owns git staging/commits/push. Workers
  make no commits, refs, dependency fetches or publication. Push destination is
  the already authorized kienfssc/uWebZockets feature branch; user makes PR.
- Before new codebase search use graphify query. Callable:
  env PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify
  /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query QUESTION
  --budget 800. Supplied paths are located. Isolated sources are not graph indexed.
- Compiler: /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig -j2.
  rg: /home/codespace/.codex/packages/app-server-daemon/releases/0.164.0-x86_64-unknown-linux-musl/codex-path/rg.
  Existing replay recipes: .uwz-work/evidence/h1-native-lifetime/driver.py and
  earlier m2-h1-baseline/verify.py. Native libs remain in zig-out/lib.
- Explicit staged xev override only:
  /tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig, immutable93files,
  commitc223bd886c6a51d2cd60def39dd9a68d701fea73,
  tree86c6944f53dc009d7503a9ab0bc873aef3cd7b79. Manifest:
  .uwz-work/evidence/loop-callbacks/immutable-libxev-input.json. Original C bindings:
  .uwz-work/evidence/h1-transport/r2/c-{native,aarch64-macos,x86_64-windows-gnu}.zig.
  Do not substitute a dependency or pin. Maintained adoption remains external.
- The stopped native cancellation experiment stays stopped. No new cancellation
  schedule/interleaving/race/crash/leak/registration-error/invalid-fd/resource
  exhaustion/kernel-error/injected-completion probes or panic subprocesses.
  Allowed: actual pure policy/driver operations with caller data, unchanged
  healthy suites, foreign compilation, and ordinary owned protocol clients once
  coherent. Never fabricate native callbacks/completions to prove timing.
- User confirmed community BSD streaming setup refusal until wakeups/native
  validation. Linux/macOS/Windows eligibility does not prove runtime support.
  Native Windows, maintained publication/protections/allfourzon and full final
  project gates remain open. No whole V6 fourth design review or global liveness
  claim. This unit delivers plaintext only; TLS extraction/caps/live uploads next.
- Preserve all buffered APIs/helper errors, Request/OwnedRequest layouts,
  default behavior, HeadTarget contract, pure H0/common BodyState/BodyDecoder,
  multipart/fuzz/timer fixes and tests. No new stored fields/layout growth or
  activation flag expected. If actually necessary, report before adding state.

## Task 1: App head resolution and stable binding

Role: dx_router. Read global constraints and the referenced specs; do not read
the entire task history. Own only router/app.zig and new
src/tests/body_h1_head_tests.zig in /tmp/uwz-m2-h1-plaintext-app. Evidence:
.uwz-work/evidence/h1-plaintext/app. Do not edit transport, config, root exports,
test_support or tests/main. Focused tests may use existing test_support directly;
Root imports the new test in combined central main before final verification.

Bind actual HeadTarget in existing App.loop_handle stable-placement binding:
context=this App pointer, router=its mutable router, resolve=real callback. Do
not bind before stable placement, overwrite active target association, or move
App/loop/router. Existing on_new_connection attaches owner before read_start.
Preserve target through reset. No additional field or callback wrapper.

Resolver returns existing HeadDecision. Use Router.match to choose without
materializing captures, retaining method fallback/OPTIONS-*/WebSocket precedence.
Buffered decision mutates no Request fields and runs no globals. Selected stream:
early-data refusal; bind used mutable overflow header views; empty legacy body;
QUERY validation before capture matching/globals; checked caller capture capacity.
Recheck late middleware compatibility before callbacks. Authorized globals run
once in registered order with request_body_complete=false. Quota full is deferred
until after globals. Then declared logical size, physical ingress, pending-header
capacity and current admission. Return UNRESERVED BodyMatch, final response, or
bounded refusal. No reservation, sink callback, 100 Continue or body collection
inside resolver. Preserve middleware pending headers and existing early response
guards. No fake stream callbacks for refusal; no constCast or Request copy.

Write meaningful failing-first actual resolver tests: stable binding; buffered
nonmutation/no globals; method/upgrade/OPTIONS precedence; QUERY order; capture
capacity; late middleware policy; globals before quota; declared/physical/header
capacity and pending metadata; zero sink calls before driver admission. Use real
registered BodyRoutes and actual owner.head_target.resolve, bounded memory
responses/caller data. New head tests plus unchanged App/router checks and
eligible compile-only, scoped fmt/conventions/version. Preserve every red and
actual dependency/source/environment binding. No native uploads in this component.
Freeze source/snapshots/diff/report for independent spec+quality review.

## Task 2: Concrete plaintext driver and native lifetime

Role: transport_io. Own core/tcp.zig, NEW core/tcp_upload.zig, required
core/loop.zig admission-invariant tag, and NEW src/tests/http1_upload_driver_tests.zig
inside /tmp/uwz-m2-h1-plaintext-transport. Evidence:
.uwz-work/evidence/h1-plaintext/transport. A single driver export may be added
to THIS PRIVATE COPY's test_support only for focused test compilation; Root
serializes its promotion. Do not edit app/config/tests/main/docs or predecessor.

Earned seam: tcp_upload owns retained-tail admission/progression, actual sinks,
controls, terminal/quota cleanup and upload reclamation. TCP keeps native
callbacks/platform close/pool release. Pure helpers/storage/decoder stay canonical.
Deleting this module would scatter payload accounting, callback borrows, pause,
terminal ownership and metadata lifetime across native callbacks and controls.
No generic continuation hook, interception framework or pass-through facade.
Promote only actually needed bounded TCP internal entries; never raw socket close.

Use H0.consume_head before buffered policy. Buffered fallback calls commit_head
and preserves failure checkpoints/legacy collector without rescanning. Pin prefix
[0,header_end), retain physical tail; reuse checked ingress_bounds. No ingress
needed for absent/empty, >=1 for positive fixed length, >=3 chunked. Cap plaintext
reads at min(8192,free retained space), including before admission. Genuine rearm
requires actual retarget_completed_receive; otherwise disarm/retire/fresh arm.
No overwrite of live completion or new buffer allocation.

Hold delivery borrow across real HeadTarget.resolve and metadata preservation;
stop on close before reservation. Copy bounded pending headers. Actual atomic
reserve_and_arm then real sink.begin. Failed begin rejects/releases with no cancel;
success accepts binding before deferred cancellation. Send required100Continue
after successful begin even paused, preserving final headers. No wait for content.

Use actual common BodyState/BodyDecoder. Observe new offered logical payload ONCE;
pending_payload counts unaccepted observed suffix. Resume reoffers it first,
accepts prefixes in state+decoder once, then progresses new data. Reclaim only
consumed tail and discard_prefix/rebase, never move pinned head. Full window
pauses reads; logical u64 limits are separate from bounded usize offsets. Fixed,
chunked extensions/CRLF/trailers reuse strict decoder and accepted bounds; discard
trailers, don't overwrite initial metadata. Final-byte pause needs explicit resume;
end may occur without another read. Implement actual closing-aware BodyControl
resume/cancel, never no-op continuation. Shared generation/phase validation and
exact error precedence remain. BodyDeliveryFailed requires completed legitimate
terminal ownership, not abandoned state.

Actual chunk uses start_chunk/sink.chunk/accept_chunk or fail_chunk. Actual end
uses take_end with real framing/queue facts, projected metadata/fresh restored
Response, sink.end and terminal completion even on error; no second cancel.
Cancel calls request_cancel, defers begin/chunk, otherwise actual sink.cancel and
finish_terminal. Release admission only from reject_begin/finish_terminal bool,
using head_target.router.release_body_route. Add only needed payloadless
CallbackFailure.body_admission_missing + fixed diagnostic after existing latch;
exhaustively map actual release/rollback error, never fake native error.

Consume StageA policy in every enabled recv/send disarm, cancelACK, two fresh
retirement stages and close tail. Frame pin before clearing target; request
retirement before final frame/ACK flag clear. Actual cancel_ack decides retained/
abandoned target. Inactive expiry maps existing retirement_inactive case; native
timer errors stay .retirement. Fresh Timer.run(0) twice, never rearm/reset active
timer or reuse native recv/send/cancel storage. Idle before tail, no post-tail access.

Initial !closing transition is sole cancel discriminator. Capture owner+bound
LoopHandle/local needed directions; acquire delivery only if previously false.
Publish closing/close_pending and BOTH needed cancel flags before generic
LoopHandle.submit (IOCP job-object callback can inline); successful fenced submit
before selected cancels. Never clear target there; later tails NEVER recancel.
Inherited delivery remains true. Drop only owned pin then safe tail as final
action. Nested delivery/cleanup never clears another operation's pin. Re-read
current obligations after inline callbacks, never restore snapshots.

Real body/output cleanup under delivery borrow; existing clear_stream/async cancel,
no invented producer abort callback. Retain metadata/TLS until native obligations
drain. claim_close is sole physical permission. Guard synchronous TLS destruction,
drop owned borrow immediately before platform tail, preserve Windows pairing and
truthful close errors. release_closed_connection adds owner drain; clear callbacks/
pool pointer before final pool callback, never access after potential release.

End/output queue does not authorize reset under frame/retirement borrows. Use
existing dispatch_suspended/pending_request_consumed to keep head and pipeline
bytes until response ownership+canonical borrows drain. Guard resume_async_dispatch
BEFORE mutation/compaction, including pump_stream_body after producer closes.
Paused upload retains idle timeout; initial-header deadline stops after admission.
Select new ingress for plaintext H1 only. Legacy TLS extraction/encrypted reads,
HTTP2 and WebSocket precedence remain; no TLS body upload claim. Native deferred
TLS destruction still needs separate crypto review before combined acceptance.

Tests: actual driver operations/real registered sinks, caller-owned storage,
bounded memory/write batching and real outer borrows where applicable. Effects
requiring native runtime go to coherent owned clients in Task3, not fake native
state or interception hooks. Cover progress, terminal/quota exactly once,
metadata/control generation, pause/resume/EOF/framing/error and pending tail reset.
Keep prior31 App/11 policy/decoder/admission suites. Compile eligible targets,
scope fmt/conventions/version, audit no allocations and layout changes. Preserve
every real failure/input/source/binary/env binding. Freeze exact source/diff/report
for independent spec+quality+structural review. No new native fault/cancel probes.

## Task 3: Combined plaintext integration and verification

Root/integrator combines reviewed Task1/Task2 overlays in NEW /tmp source, preserving
all1020 baseline inputs, currentRoot timer/multipart/fuzz/consumer and four pins.
Serialize new test_support export and both centralized test imports exactly once.
No whole-tree replacement of Root. No public production adoption until pin and
original full gates permit it. Task reviews precede combined final review.

Run actual combined App binding with ordinary owned plaintext clients and bounded
generation. Prove100000000 exact logical bytes and independent hash for BOTH fixed
and chunked. Split framing/extensions/CRLF/trailers, empty/limits, partial-prefix
pause/resume and final-byte pause ending without read;100Continue before content,
paused begin/refusal withoutContinue, middleware metadata, captures/initial headers
through callbacks and longer producers, stream->stream and stream->buffered pipeline.
Failed begin/sink errors/invalid progress, malformed ordinary requests, application
cancel, stale controls and ordinary owned shutdown/disconnect. These are API/client
checks, not authorized kernel/cancellation schedule/race/crash/leak/injection probes.

Crypto specialist reviews deferred TLS destruction and unchanged healthy TLS path.
Full unchanged buffered/regression, mandatory fmt including builds, conventions,
version/dependency/package, Debug/ReleaseSafe, sanitizer/MSan, Smith/OSS-Fuzz,
ReleaseFast, h1spec/applicablecross/compliance/layout/performance and nativeWindows
requirements remain. Scope each claim to executed evidence. Independent combined
review must examine actual consumers and earned structural seam. M2 TLS/H2/H3 and
later milestones stay open. Commit/push each verified deliverable to fork feature
branch; no PR, release or maintained dependency publication.
