# Global Constraints

- Authoritative specs (read only relevant sections, not task history):
  docs/adr/0008-request-body-streaming.md;
  .uwz-work/evidence/h1-transport/r3/h1-head-driver-seam.md;
  .uwz-work/evidence/h1-transport/r3/native-lifetime-minimum-contract.md;
  .uwz-work/evidence/h1-transport/r3/submit-callback-source-audit.md;
  .uwz-work/evidence/upload-platform/eligible-retirement-contract.md;
  .uwz-work/evidence/h1-retirement-policy-contract.md.
- Read AGENTS.md and CODING_CONVENTION.md. Zig 0.16.0; named explicit types,
  explicit callback contexts, shallow flow, no hidden globals or OOP. No new
  markers, emojis, direct src stdout/stderr, or silenced errors. Do not weaken
  any test, assertion, threshold or lint. No dynamic library allocation after
  startup. Do not alter maintained refs, pins, build dependencies or root exports.
- Immutable starting source: /tmp/uwz-m2-h1-native-lifetime, 1020 files0444,
  digest81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108.
  Durable recovery is in docs/implement-2-2-0/evidence/m2_h1_invariant_failure
  and its predecessor archives. Root HEAD877a2ac8e0d004a566aef1eac775eb06655e37e9
  changes recovery documentation; production source remains3cc8f81.
- Work in separate NEW /tmp source copies, no hardlinks, symlinks or inherited
  caches. App copy: /tmp/uwz-m2-h1-plaintext-app. Transport copy:
  /tmp/uwz-m2-h1-plaintext-transport. All binaries/cache/generated inputs/large IR
  stay /tmp. Keep exact small source snapshots/preimages/patches and every
  command/status/log/hash durably under the task's workspace evidence directory.
  /tmp can disappear across goal continuations; paths/hashes alone cannot save code.
- You are not alone. Do not revert others. No subagents. Root serializes final
  test_support/tests/main/config/docs and owns git staging/commits/push. Workers
  make no commits, refs, dependency fetches or publication. Push destination is
  the already authorized kienfssc/uWebZockets feature branch; user makes PR.
- Before new codebase search use graphify query. Callable:
  env PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify
  /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query QUESTION
  --budget 800. Supplied paths are located. Isolated sources are not graph indexed.
- Compiler: /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig -j2.
  rg: /home/codespace/.codex/packages/app-server-daemon/releases/0.164.0-x86_64-unknown-linux-musl/codex-path/rg.
  Existing replay recipes: .uwz-work/evidence/h1-native-lifetime/driver.py and
  earlier m2-h1-baseline/verify.py. Native libs remain in zig-out/lib.
- Explicit staged xev override only:
  /tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig, immutable93files,
  commitc223bd886c6a51d2cd60def39dd9a68d701fea73,
  tree86c6944f53dc009d7503a9ab0bc873aef3cd7b79. Manifest:
  .uwz-work/evidence/loop-callbacks/immutable-libxev-input.json. Original C bindings:
  .uwz-work/evidence/h1-transport/r2/c-{native,aarch64-macos,x86_64-windows-gnu}.zig.
  Do not substitute a dependency or pin. Maintained adoption remains external.
- The stopped native cancellation experiment stays stopped. No new cancellation
  schedule/interleaving/race/crash/leak/registration-error/invalid-fd/resource
  exhaustion/kernel-error/injected-completion probes or panic subprocesses.
  Allowed: actual pure policy/driver operations with caller data, unchanged
  healthy suites, foreign compilation, and ordinary owned protocol clients once
  coherent. Never fabricate native callbacks/completions to prove timing.
- User confirmed community BSD streaming setup refusal until wakeups/native
  validation. Linux/macOS/Windows eligibility does not prove runtime support.
  Native Windows, maintained publication/protections/allfourzon and full final
  project gates remain open. No whole V6 fourth design review or global liveness
  claim. This unit delivers plaintext only; TLS extraction/caps/live uploads next.
- Preserve all buffered APIs/helper errors, Request/OwnedRequest layouts,
  default behavior, HeadTarget contract, pure H0/common BodyState/BodyDecoder,
  multipart/fuzz/timer fixes and tests. No new stored fields/layout growth or
  activation flag expected. If actually necessary, report before adding state.

