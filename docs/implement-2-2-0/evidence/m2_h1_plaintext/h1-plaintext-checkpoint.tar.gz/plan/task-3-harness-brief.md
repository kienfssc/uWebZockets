# Task 3a: prepare ordinary plaintext verification fixtures

This is independent SOURCE PREPARATION for Task3, not permission to execute a
new server/client before Root combines the reviewed App/driver. Read
global_constraints.md here, AGENTS/CODING_CONVENTION and verification role.
Own only .uwz-work/evidence/h1-plaintext/integration and this task's report.
Do not modify production, active developer copies, build graphs, manifests,
test_support/main, existing fixtures, refs or pins. No subagents/commits/push.
You are not alone. The accepted public BodyRoute/BodyControl/StreamingRequest
contract is stable; use it, never private driver APIs or a fake body runtime.

Prepare a standalone bounded Zig profile server and normal Python client harness
against public App route_body. Do not introduce another zon/package view or
Python build requirement. Exact explicit compiler/module replay is sufficient;
you may compile fixtures/syntax-check Python against the immutable starting
source without running the server. All output/caches/generated inputs stay/tmp;
small actual source/scripts/raw compile metadata durable in assigned evidence.
Root builds/runs against combined source later. No current successful upload claim.

Reuse existing NORMAL helpers rather than invent lifecycle plumbing:
- tests/static_interop/probe.py: owned Popen, listener_record/precheck_port,
  PID/socket-inode ownership and health readiness, SIGTERM/wait/reap, forced kill
  recorded as failure. tests/static_interop/main.zig uses public App shutdown and
  post-deinit marker. Preserve normal optional Nix loader/library-path prefix.
- tests/static_interop/probe.py bounded8192 hashing/comparison and EOF/surplus checks.
- src/tests/tls_echo_tests.zig format_echo_head/send_echo_request for ordinary
  fixed/chunked framing, but never copy100KiB full-body storage into100MB tests.
- Normal refusal runner .uwz-work/evidence/h2-body-refusal/live-v1/run.py is
  lifecycle/command provenance only: its100000000 sparse fixture uploads ZERO.
  It is not successful upload evidence. Never inspect/reconstruct stopped probes.

Server profile (private verification endpoints; no product API change):
- Opt in stream_request_bodies, keep default small ingress/body/window capacities,
  no body-sized buffer. Use bounded fixed caller-owned per-request binding slots
  and one owning event loop. No allocator in sink chunk/end or hidden global state.
- POST /upload/:tag with real BodyRoute, logical max100000000 and max_active1.
  /limit/:tag max32 and /empty/:tag max0 may reuse the real sink. Use a certified
  headers_only middleware appending X-Middleware: retained, so final responses
  prove pending-header preservation.
- Sink SHA256 and u64 accepted-byte count update ONLY accepted prefix. End returns
  bounded JSON with bytes, sha256, metadata_ok; compare initial header/capture
  values to bounded expected copies and retained individual byte slices. Never
  retain a StreamingRequest/array-view pointer. Query/header chooses one pause:
  begin, partial prefix, or final offered byte (client declares its test size).
- GET /status, /resume, /cancel and /stale use copies of real BodyControl on that
  same loop. A second ordinary HTTP request drives resume, avoiding timers/native
  scheduling tricks. Copy needed data before resume/cancel because terminal calls
  may finish binding synchronously. Server-owned slot/metrics memory independently
  survives logical request cleanup. Track begin/end/cancel and reasons exactly.
- /health and a bounded ordinary buffered POST /echo for coexistence/pipeline.
- Add a normal plaintext large-file response endpoint using existing send_file
  or static delivery, so an upload-enabled connection can pipeline file->health
  and request Connection:close. Never fake file/completion state. File fixture
  creation occurs at setup under/tmp. This specifically covers the reviewed
  missing file_body ownership gate; validate full exact file then next response.
- If feasible without speculative hooks, include a body-end outgoing producer
  with INDEPENDENT server-owned context retaining initial metadata bytes beyond
  upload cleanup, using existing producer contract (there is no abort callback).
  Record any unprepared acceptance cases honestly for Root; do not fake support.

Client/records:
- Deterministic nonzero payload generated in chunks<=8192, with final sentinel;
  no100MB in-memory/file buffer. Independently hash generated/sent bytes. Prove
  EXACT100000000 logical bytes for BOTH fixed and chunked with count/hash/end
  response, metadata and X-Middleware checks.100MiB104857600 is a different case.
- Smaller bounded cases: empty and logical limit/quota; chunk extensions, split
  write framing and discarded trailers; begin pause (including100Continue before
  content), partial prefix and final-byte pause/end without another body byte.
  Use /status and /resume on separate normal connections; don't depend on a race.
- Parse100 interim separately from final response. Refusal with Expect must not
  be counted as upload success. Preserve final headers and Content-Length/chunked
  response framing, EOF and surplus checks. Keep stream->stream and
  stream->buffered pipelines on one socket with exact response boundaries.
- Prepare ordinary failed-begin, sink-error/invalid-progress, application cancel,
  stale-control and malformed-request cases if fixtures can express them through
  public callback/API behavior. Never assert unknown statuses by guessing; expose
  precise counters/results and report remaining expectation to Root.
- Record actual argv/cwd/compiler/source/library/binary hashes, actual explicitly
  passed env values (never secrets), child PID/port/readiness/status/reap, lengths,
  hashes/counters and every failure separately. No estimates/performance claims.
- NO RUN before Root supplies combined reviewed source and explicitly starts
  verification. NO new native cancellation schedule/interleaving/race/crash/leak,
  invalid-fd/registration/kernel/resource fault, injected completion or panic
  experiment. Ordinary later protocol/API checks are not such probes. Never kill
  unrelated processes or touch arbitrary ports/files.

Full report: task-3-harness-report.md here, with source/preparation status,
compilation/syntax outcomes, exact required runtime invocation, implemented case
matrix and explicit gaps. Return under15 lines. Source snapshots/sha metadata
durable; no Root source or live result claims.
