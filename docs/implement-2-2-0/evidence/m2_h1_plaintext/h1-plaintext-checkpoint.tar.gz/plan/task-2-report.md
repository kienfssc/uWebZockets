# Task 2 transport report — v6 scoped review-fix handoff

Status: v6 fixes the independently reported file-response ownership omission; driver and scoped checks pass. The final appended Round 1 section identifies the authoritative v6 artifacts. Earlier v4/v5 sections remain historical evidence. Scoped re-review and combined integration remain open. No live upload, native cancellation timing, TLS upload or final project-gate claim.

## Initial v4 review artifact (superseded by v5 below)

- Source: `/tmp/uwz-m2-h1-plaintext-transport`.
- Immutable review replacements: `.uwz-work/evidence/h1-plaintext/transport/snapshots/v4/`.
- Manifest: `.uwz-work/evidence/h1-plaintext/transport/v4-manifest.json`.
- Diff: `.uwz-work/evidence/h1-plaintext/transport/v4.patch`.
- Source digest: `3c0fabb0becc51e20bef965d445799ba1da609abf7107b20388488228628cd17`.
- Baseline: exact 1,020-file independent byte copy verified against `.uwz-work/evidence/h1-native-lifetime/final-source-manifest.json`, digest `81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108`. No hardlinks, inherited caches or baseline edits.
- Local maintained prerequisite remains explicit immutable c223bd886c6a51d2cd60def39dd9a68d701fea73 override. No dependency pin/publication change.

## Changed files and actual scope

- `src/core/tcp_upload.zig`: concrete H0/HeadTarget admission, actual atomic router reservation/BodyState arm, real sink callbacks, bounded retained payload/decoder progression, closing-aware control targets, pending response restoration, authoritative admission release and nested delivery borrows.
- `src/core/tcp.zig`: plaintext H0 selection, bounded receive windows, callback/ACK retirement consumers, two fresh timer stages, first-transition cancellation with both ACK flags published before generic submit, guarded physical-close tail, deferred TLS destruction, owner-drained pool release and metadata reset guards.
- `src/core/loop.zig`: only payloadless `body_admission_missing` invariant and fixed diagnostic after existing failure latch.
- `src/tests/http1_upload_driver_tests.zig`: 16 actual driver cases using caller storage, actual router registrations/sinks, legitimate outer delivery borrow and ordinary output batching.
- `src/test_support.zig`: one private-copy driver export for focused compilation. Root owns promotion and central registration.

No stored fields or layouts were added. No changes to parser, decoder, common BodyState, App/config, central tests, root exports or native dependency inputs. `HeadInput.head` is the actual H0 complete head; mutable header slots use exactly parser.extra_header_count, while capture slots retain capacity.

## Ownership details

Initial `!closing` transition selects cancellations once. It acquires delivery only if not already borrowed, publishes close intent and both needed ACK flags, performs real guarded submit, then selected cancels. Later tails never recancel. Every enabled receive/send disarm requests retirement before dropping its callback pin; ACK classification uses actual LoopHandle.cancel_ack before target abandonment and drops its ACK flag only after retirement request. Each direction advances through two fresh Timer.run(0) calls; final expiry records idle before tail. Neither target nor ACK completion storage is reused for timers.

Physical close requires actual claim_close with six current TCP facts. TLS destruction runs under an owned delivery borrow, dropped immediately before platform close. Windows keeps synchronous close/close_complete/release pairing. Non-Windows close result fences its actual error before marking complete. Pool callback and pool pointer clear before final callback. Owner reset reclaims head/route/pending metadata only after canonical drain.

Driver offers newly observed payload once and retains pending_payload until accepted; resume reoffers that suffix first. Final-byte pause requires explicit resume. End uses real decoder end, zero pending payload and shared readiness/length checks; actual sink.end receives fresh projected metadata/Response, and terminal completion releases quota even on error with no second cancel. Failed begin releases via reject_begin and never cancels. Trailer views never replace initial fields. Response completion leaves pending_request_consumed/dispatch_suspended until inherited/native borrows drain.

## Tests and evidence

Every named command has exact argv, status, log, source-before/after digest, compiler/module/archive input hashes, immutable override manifest/hash, and output binary hash in `.uwz-work/evidence/h1-plaintext/transport/`. `driver.py` is the replay recipe; `snapshot.py` preserves source replacements plus full manifests/diffs. Native binaries and independent caches remain in `/tmp`.

- `driver-v3` Debug compilation and run: **16/16 passed**.
- `driver-v4-safe` ReleaseSafe compilation and run: **16/16 passed**.
- `conventions-v4`: passed.
- `fmt-v4`: passed, intentionally recorded before/after formatting source digests.
- `central-v4-macos`: centralized graph semantic compilation passed, no foreign execution.
- Windows central compilation and unchanged App ReleaseSafe compilation later passed (see final results below).
- Native centralized compile, unchanged App run, decoder/admission suites, version, final formatting/source audit and graph update subsequently completed (see final results below).

Cases cover bounded pre-admission windows; partial-prefix retry without double observation; preserved pending response headers and pipeline tail; final-byte pause; paused-begin Continue before content; cancellation/quota once; body larger than physical ingress; split chunk extensions/CRLF/trailers; failed begin; callback-triggered close during begin/chunk; chunk failure/invalid progress; resumed end error; malformed-trailer 400; full head/used overflow views; refused metadata compaction under actual inherited borrow; EOF cancellation reason; logical limit 413 before payload acceptance.

### Truthful TDD accounting

`red-driver` is **INVALID as failing-first evidence**: the initial cold compilation overlapped creation of the driver and passed. Its actual before/after bindings and log are retained; it is not counted as verification. `red-native-seam` found both the absent permitted TCP seam and a test API naming error. `red-native-seam-corrected` removed the test error and then failed on the absent public TCP admission seam with stable source. That corrected declaration red preceded the real native seam implementation. `driver-v1` then compiled and passed four actual driver cases. Later cases are expanded post-implementation behavioral coverage, not falsely claimed individual failing-first reproductions. There was no manufactured native callback/state red or native crash/panic experiment.

## Self-review findings and remaining limits

1. RESOLVED in v5: v4 mapped idle timeout through generic close to `cancelled`. The approved reasoned-close ownership operation now preserves `.timeout` and closing visibility.
2. TCP's generic close API cannot distinguish App shutdown. Root must decide whether its owned App shutdown caller requests `.shutdown` before generic close during integration.
3. Pure driver fixtures deliberately keep their real outer operation borrow through assertions. They prove actual callbacks, bytes, generations, quota, framing, response queues and deferral, **not** final native close/release scheduling. Combined owned clients are Root's next task after review.
4. App HeadTarget binding/resolver is developed separately. The tests' real bounded resolver selects an actual registered route, but is not evidence for App middleware/selection integration.
5. TLS plaintext extraction remains unchanged and is not connected to streaming admission. Deferred native TLS destruction needs the requested crypto review. No TLS upload claim.
6. Cross-target semantic compilation is not native Windows/macOS runtime evidence. Maintained override adoption, full project builds/sanitizers/production graph and final integration gates remain open.
7. No performance measurements or throughput improvement are claimed. The implementation preserves bounded storage and allocations remain absent from the new data path; additional native retirement scheduling has not been benchmarked.
8. This is a structural TCP change requiring Root's independent spec/quality/structural review. Review v4's durable bytes; any subsequent correction will receive a new snapshot/diff rather than overwrite them.

## v5 superseding source correction

Review **v5**, retaining v4 as historical evidence. Manifest `transport/v5-manifest.json`, patch `transport/v5.patch`, read-only replacement snapshots `transport/snapshots/v5/`; source digest `35738519cc5378dd5a716a4588b5e946c44ef82c91429933e3c17bbf12efd27b`, patch SHA-256 `b2dbc41d1ca78be47a85d25c871244b27eeeff93124027a538b2dc49fcbf815b`. Exact delta from v4: `transport/v4-to-v5.patch`.

Root approved the narrow `tcp_upload.close(conn: *TcpConnection, reason: BodyCancelReason) void` ownership operation. It acquires/inherits delivery, calls pure request_cancel first and retains any returned terminal action locally, then calls existing tcp.close_connection. This publishes closing/close_pending/native ACK flags before abort/submission or destructive callbacks. The captured terminal action runs afterward, so the sink observes closing and the requested first reason. BodyState's terminal phase plus the inherited borrow prevent release while the local action is held. Begin/chunk instead retain the pending first reason until unwind. Final finish_borrow may release conn; no caller access afterward is allowed. Owner-null calls the legacy close path.

BodyControl cancel now uses this entry with `.cancelled`; actual idle timeout uses `.timeout`. Root's combined App shutdown must call `tcp_upload.close(conn, .shutdown)` **instead of** generic close, with no subsequent conn access or second close. The driver retains cancel-without-close for bounded 400/413 output paths.

The new real-sink CPU test confirms closing visibility, first reason preserved after repeated close, one terminal call, quota release, and retained outer borrow/close intent. `red-v5-close` is a stable missing-entry declaration red; `driver-v5-debug` compiles and passes **17/17** afterward. ReleaseSafe and final v5 checks passed; exact final results follow. The only other production delta removes the unreachable enabled-owner branch from the now owner-null legacy submission path.

Additional completed v4 evidence: central native and Windows semantic compile passed; admission **7/7** and decoder **20/20** ReleaseSafe passed; version check passed. Unchanged App's sandbox run failed 10 explicit backend assertions (epoll instead of required io_uring), retaining 21 passing cases including all 11 pure policy cases. The exact same binary then passed **31/31** outside the sandbox with io_uring still asserted; both environments/results remain in evidence. No test expectation or policy was weakened.


## Final acceptance evidence and integration handoff

Authoritative v5 source/patch hashes are in the v5 section above. All five changed-file snapshots are read-only. The live independent source copy matches all **1,022** manifest entries; `final-audit.json` proves unchanged canonical parser/decoder/BodyState/admission/storage/App/config/test-root files and byte-identical TCP stored field declarations. The new driver has no allocator identifiers. This is a source-layout invariance proof, not a new cross-target sizeof measurement or performance benchmark.

Final-v5 commands (all status 0, stable source before/after):

- `python3 .uwz-work/evidence/h1-plaintext/transport/driver.py test driver-v5-debug src/tests/http1_upload_driver_tests.zig Debug` and `run driver-v5-debug`: **17/17**.
- Same recipe `test driver-v5-safe ... ReleaseSafe` and `run driver-v5-safe`: **17/17**.
- `central central-v5-native native`, `central central-v5-macos aarch64-macos`, `central central-v5-windows x86_64-windows-gnu`: complete existing central graph semantic compilation, no execution and no claim the unregistered new test module was centrally run.
- `command conventions-v5 sh scripts/check_conventions.sh`, `command version-v5 sh scripts/check_release_version.sh`, scoped `fmt-v5`: passed.
- `graph_check.py`: exact v5 manifest copy under `/tmp/...-artifacts/graph-source`, `graphify update .` passed with 590 AST inputs, 13,020 nodes and 16,179 edges; no LLM/API cost. Sandbox blocked parallel extraction so it used sequential fallback; 27 unsupported-symbol files and 318 unclassified files are truthfully reported in `graph-v5.log`. Root's production graph was not touched.
- `audit.py`: all source hashes, unchanged canonical modules, field-layout text and allocation-identifier audit passed.

Unchanged predecessor suites were verified on v4 immediately before the narrow v5 reasoned-close change: App **31/31** including all **11** policy tests (io_uring asserted, unchanged binary outside sandbox), admission **7/7**, decoder **20/20** ReleaseSafe. Those source bindings are retained as v4, not relabeled v5; final v5 driver and three-target central compilation cover the actual subsequent change. No additional unrelated repetition was needed.

Root must merge the independently reviewed App resolver overlay, promote the one test_support export, register the new test module in central main, and replace App shutdown's generic close with `tcp_upload.close(conn, .shutdown)`. That operation can release at its final tail: caller must not touch conn/owner or close again. Keep the immutable dependency override/prerequisites and platform activation gate. Root owns independent spec/quality/structural and crypto review, ordinary coherent client gates, production build/sanitizer/full suites, final docs and publication. No live-client, native scheduling, TLS-body, native-Windows or full-project acceptance is claimed by this component report.

## Review fix round 1 — file response ownership (in progress)

Independent review found v5's healthy upload tail omitted `file_body` when deciding whether to resume suspended HTTP/1 dispatch. A pending zero-copy file can outlive native retirement; resuming there may interleave the next response or honor pending Connection: close before the file finishes. `tcp_file.finish_file_body` remains the owner that clears `file_body`, closes the file, and then resumes dispatch or closes after output. No changes to file pumping/completion are needed.

Planned ordinary combined client cases for Root (not executed by this worker): serve a deterministic **16,777,216-byte** regular file through the existing public `send_file` API on an enabled plaintext connection. This exceeds the existing **4,194,304-byte** file tick budget. (1) Send `GET /large` followed immediately by `GET /marker` in one normal HTTP/1.1 pipeline. Read the first response headers, stream exactly its Content-Length through the existing 8192-byte bounded digest checker, verify the full fixture hash/final sentinel, then parse and verify the complete marker response. No marker bytes may enter the first body. (2) On a fresh connection send only `GET /large` with `Connection: close`; verify the same full length/hash/sentinel, then require EOF. Early EOF is failure. Use ordinary reads with existing bounded client/server deadlines, no socket-buffer manipulation, artificial native callback schedule, cancellation injection or fault probe. Root's existing owned process lifecycle supplies readiness, shutdown and reap evidence. These clients, after combined merge/review, establish real ordering; the worker's pure ownership regression will establish only the actual continuation decision.

### Round 1 fix result — frozen v6

The finding is fixed in the actual production continuation guard. `response_dispatch_owned(file_active, producer_active, async_pending)` returns true while any existing response owner remains. `upload_tail` passes actual `file_body != null`, `stream_producer != null` and `async_response_state.is_pending()` and cannot resume while that predicate is true. Canonical body/native-borrow gates remain unchanged. `tcp_file.finish_file_body` still exclusively clears/finishes its file ownership before its existing resume/close action. No file-source, pump, completion, stored-field or cancellation code changed in this round.

Exact immutable artifacts under `.uwz-work/evidence/h1-plaintext/transport/`:

- Prior v5: `35738519cc5378dd5a716a4588b5e946c44ef82c91429933e3c17bbf12efd27b`.
- Behavioral-red source: `421e3624deac74d7811b17dc452bc9e69f398e038af816bfec7bdf71d785ae4d`, `v6-red-manifest.json`, `snapshots/v6-red/`, `v6-red.patch`.
- Fixed v6: `a9022ee14096698cf92d9c66afe4d156b4135382c8f72fc1e35a622d70773e26`, `v6-manifest.json`, read-only `snapshots/v6/`.
- Complete v6 patch: `v6.patch`, SHA-256 `4c550f5d73268cf5c8e4e06808312ceb0bebe008486672789410a2014d4c2d40`.
- Scoped re-review delta: `v5-to-v6.patch`, SHA-256 `7088659d8b63008d4a99242b37b9c0e5fb63ea90609066116b4a86b26be74429`. Exactly `src/core/tcp.zig` and `src/tests/http1_upload_driver_tests.zig` differ from v5.

Behavioral red/green, with exact argv/output/status/source/input/binary bindings in correspondingly named JSON/log files:

1. Extracted the existing faulty response predicate without changing its behavior: it consumed producer/async facts but ignored the file fact. This same extracted function was used by production `upload_tail`; no fake native state or test-only implementation was introduced.
2. `python3 .uwz-work/evidence/h1-plaintext/transport/driver.py test driver-v6-red src/tests/http1_upload_driver_tests.zig Debug`: status **0**, compiled successfully.
3. `.../driver.py run driver-v6-red`: status **1**, **18 passed / 1 failed**. Failure is the actual file-active-only assertion in `H1 driver: outstanding file response retains dispatch after native retirement`; existing producer/async/all-clear assertions pass. Despite the test's scenario name, this is strictly the pure production decision, not fabricated or executed native retirement.
4. Added the file fact to that production predicate. `test driver-v6-debug ... Debug` / `run driver-v6-debug`: status **0**, **19/19 passed**.
5. `test driver-v6-safe ... ReleaseSafe` / `run driver-v6-safe`: status **0**, **19/19 passed**.
6. `central central-v6-native native`, `central central-v6-macos aarch64-macos`, `central central-v6-windows x86_64-windows-gnu`: status **0** on unchanged fixed source; semantic compilation only.
7. Scoped `fmt-v6`, `conventions-v6` and `audit_v6.py`: passed. Final audit verifies all 1,022 source entries and unchanged canonical storage/fields. AST graph refresh on a separate exact v6 copy passed: 590 extracted files, 13,021 nodes, 16,180 edges, no API cost; the same documented sequential fallback/unclassified-symbol warnings remain. Production source remains untouched. `v6-fix-audit.json` verifies exactly two changed paths from v5, unchanged tcp_file.zig, and stable source bindings for every red/green/semantic check.

No unrelated behavioral suites were repeated. This regression verifies the permission to resume dispatch from actual owner facts. The ordinary large-file pipeline and Connection: close wire checks described above remain Root's combined runtime acceptance work. No native file/descriptor fixture, callback/completion injection, new interception framework, fault probe or performance claim was introduced. This fix awaits Root's scoped independent re-review; all previous integration/runtime limitations remain.
