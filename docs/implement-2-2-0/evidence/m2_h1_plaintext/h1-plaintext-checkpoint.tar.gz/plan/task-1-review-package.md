# Task 1 App head-resolution review package

Spec and global requirements: task-1-brief.md and global_constraints.md beside this package.
Report: task-1-report.md beside this package. Final healthy checks may still be pending;
source is frozen; review actual terminal records when present.
RootBASE877a2ac8e0d004a566aef1eac775eb06655e37e9 (archives only).
Executable BASE81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108.
Candidate sourceb97d3b94a2dde50788fc6ae076c7233e61da4914267fae884d4d9d8125e94a4d.
Candidate App e240dc0ee625f71cf311a1b87d83e4202cbbacd55e57983a630b4ff4d8c4733d.
New tests fec97e1121746fd21c289cd7f295732ca63995f64beba21de83b5354e90e1647.
This manifest-bound direct source patch is authoritative, not Root's archive-only git diff.
Two owned paths: src/router/app.zig and src/tests/body_h1_head_tests.zig.
No other source/fields/layout/pins/export change claimed; verify against supplied manifest.

## Direct two-tree source diff

--- a/src/router/app.zig
+++ b/src/router/app.zig
@@ -2,6 +2,7 @@
 const core_loop = @import("../core/loop.zig");
 const core_tcp = @import("../core/tcp.zig");
 const http1_upload = @import("../core/http1_upload_storage.zig");
+const http1_head = @import("../core/http1_upload.zig");
 const request_body = @import("../http/request_body.zig");
 const core_pool = @import("../core/pool.zig");
 const core_timer = @import("../core/timer.zig");
@@ -687,13 +688,63 @@
                 } else {
                     self.loop.failure_fence = &self.upload_failure_fence;
                     for (self.upload_owners) |*owner| {
+                        if (owner.head_target != null) @panic("upload head target already bound");
                         owner.loop_handle = .{ .owner = &self.loop };
+                        owner.head_target = .{ .context = self, .router = &self.router, .resolve = resolve_upload_head };
                     }
                 }
             }
             const handle = core_loop.LoopHandle{ .owner = &self.loop };
             _ = handle.raw();
             return handle;
+        }
+
+        fn upload_upgrade_intent(input: *const http1_head.HeadInput) bool {
+            if (input.method != .get) return false;
+            var headers = input.head.headers.entries();
+            while (headers.next()) |header| {
+                if (std.ascii.eqlIgnoreCase(header.name, "Upgrade")) return true;
+                if (!std.ascii.eqlIgnoreCase(header.name, "Connection")) continue;
+                var tokens = std.mem.splitScalar(u8, header.value, ',');
+                while (tokens.next()) |token| {
+                    if (std.ascii.eqlIgnoreCase(std.mem.trim(u8, token, " \t"), "upgrade")) return true;
+                }
+            }
+            return false;
+        }
+
+        fn resolve_upload_head(context: *anyopaque, input: *const http1_head.HeadInput, response: *Response) http1_head.HeadDecision {
+            const self: *Self = @ptrCast(@alignCast(context));
+            const request = input.request;
+            if (input.method == .options and std.mem.eql(u8, request.path, "*")) return .buffered;
+            const route = self.router.match(request.path, input.method) orelse return .buffered;
+            if (route.ws_behavior != null and upload_upgrade_intent(input)) return .buffered;
+            const selected = route.body_match orelse return .buffered;
+            if (input.early_data_forbidden) return .{ .reject = .too_early };
+
+            request.extra_header_names = input.headers.names;
+            request.extra_header_values = input.headers.values;
+            request.extra_header_count = @min(input.headers.names.len, input.headers.values.len);
+            request.body = "";
+            if (!request.valid_query_content_type()) return .{ .reject = .invalid_query };
+            request.extra_param_names = input.captures.names;
+            request.extra_param_values = input.captures.values;
+            request.extra_param_count = 0;
+            _ = self.router.match_request(request, input.method) orelse return .{ .reject = .unavailable };
+            self.router.check_body_route(selected) catch |err| switch (err) {
+                // Authorized globals precede quota refusal, even when already full.
+                error.BodyAdmissionFull => {},
+                else => return .{ .reject = .unavailable },
+            };
+            response.request_body_complete = false;
+            if (self.router.run_middleware(request, response) == .stop) return .final;
+            if (input.head.framing == .content_length and
+                input.head.framing.content_length > selected.definition.limits.max_body_bytes)
+                return .{ .reject = .body_too_large };
+            if (input.ingress == null) return .{ .reject = .unavailable };
+            if (response.pending_header_length > input.pending_header_capacity) return .{ .reject = .unavailable };
+            self.router.check_body_route(selected) catch return .{ .reject = .unavailable };
+            return .{ .stream = selected };
         }
 
         /// Registers a streaming route. Its immutable definition and sink
--- a/src/tests/body_h1_head_tests.zig
+++ b/src/tests/body_h1_head_tests.zig
@@ -0,0 +1,375 @@
+const std = @import("std");
+const support = @import("test_support");
+const App = support.app.app(2);
+
+test "H1 head: stable placement binds actual App resolver and router once" {
+    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
+    defer app.deinit();
+    try std.testing.expect(app.upload_owners[0].head_target == null);
+    _ = app.loop_handle();
+    const target = app.upload_owners[0].head_target orelse return error.MissingHeadTarget;
+    try std.testing.expect(target.context == @as(*anyopaque, @ptrCast(&app)));
+    try std.testing.expect(target.router == &app.router);
+    _ = app.loop_handle();
+    try std.testing.expect(app.upload_owners[0].head_target.?.resolve == target.resolve);
+    support.http1_upload_storage.reset(&app.upload_owners[0]);
+    try std.testing.expect(app.upload_owners[0].head_target.?.context == target.context);
+}
+const Request = support.http_request.Request;
+const Response = support.http_response.Response;
+const upload = support.http1_upload;
+const body = support.request_body;
+const StreamingRequest = support.streaming_request.StreamingRequest;
+
+/// All callback effects stay in caller-owned bounded records.
+const Effects = struct {
+    sink_calls: usize = 0,
+    globals: usize = 0,
+    observed_empty: bool = true,
+    incomplete: bool = true,
+    stop: bool = false,
+    final: bool = false,
+    writes: usize = 0,
+    producer_guard: bool = true,
+
+    fn definition(self: *Effects, policy: body.BodyMiddlewarePolicy) body.BodyRoute {
+        return .{ .sink = .{ .context = self, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel }, .limits = .{ .max_body_bytes = 8, .max_active = 1 }, .middleware_policy = policy };
+    }
+    fn begin(context: *anyopaque, _: *const StreamingRequest, _: body.BodyControl) !body.BodyBinding {
+        const self: *Effects = @ptrCast(@alignCast(context));
+        self.sink_calls += 1;
+        return .{ .context = self };
+    }
+    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
+        const self: *Effects = @ptrCast(@alignCast(context));
+        self.sink_calls += 1;
+        return .{ .consumed = bytes.len, .readiness = .ready };
+    }
+    fn end(context: *anyopaque, _: *const StreamingRequest, _: *Response) !void {
+        const self: *Effects = @ptrCast(@alignCast(context));
+        self.sink_calls += 1;
+    }
+    fn cancel(context: *anyopaque, _: body.BodyCancelReason) void {
+        const self: *Effects = @ptrCast(@alignCast(context));
+        self.sink_calls += 1;
+    }
+    fn global(context: *anyopaque, req: *Request, res: *Response) support.radix.MiddlewareResult {
+        const self: *Effects = @ptrCast(@alignCast(context));
+        self.globals += 1;
+        self.observed_empty = self.observed_empty and req.body.len == 0;
+        self.incomplete = self.incomplete and !res.request_body_complete;
+        res.append_header("X-Admission", "kept") catch return .stop;
+        res.begin_chunked("200 OK", "") catch |err| {
+            self.producer_guard = self.producer_guard and err == error.BodyNotComplete;
+            if (self.final) res.end_best_effort("401 Unauthorized", "refused");
+            return if (self.stop) .stop else .continue_dispatch;
+        };
+        self.producer_guard = false;
+        return .stop;
+    }
+    fn response(self: *Effects) Response {
+        return .{ .target = .{ .http3 = .{ .context = self, .end_fn = write_end, .begin_fn = write_begin, .write_fn = write_body, .finish_fn = write_finish } } };
+    }
+    fn write_end(context: *anyopaque, _: []const u8, _: []const u8, _: []const u8) !void {
+        const self: *Effects = @ptrCast(@alignCast(context));
+        self.writes += 1;
+    }
+    fn write_begin(_: *anyopaque, _: []const u8, _: []const u8) !void {
+        return error.UnexpectedProducer;
+    }
+    fn write_body(_: *anyopaque, _: []const u8) !void {
+        return error.UnexpectedProducer;
+    }
+    fn write_finish(_: *anyopaque) !void {
+        return error.UnexpectedProducer;
+    }
+    fn buffered(_: *Request, _: *Response) void {}
+};
+
+fn input(req: *Request, method: support.radix.HttpMethod) upload.HeadInput {
+    return .{ .request = req, .method = method, .head = .{ .framing = .{ .content_length = 4 }, .header_end = 50, .headers = req.headers() }, .headers = .{ .names = &.{}, .values = &.{} }, .captures = .{ .names = &.{}, .values = &.{} }, .ingress = .{ .capacity = 32, .line_content_limit = 30 }, .pending_header_capacity = 2048, .early_data_forbidden = false };
+}
+fn head_target(app: *App) !upload.HeadTarget {
+    _ = app.loop_handle();
+    return app.upload_owners[0].head_target orelse error.MissingHeadTarget;
+}
+fn expect_reject(expected: upload.AdmissionRefusal, decision: upload.HeadDecision) !void {
+    try std.testing.expect(decision == .reject);
+    try std.testing.expectEqual(expected, decision.reject);
+}
+
+test "H1 head: buffered resolution leaves every Request byte and globals untouched" {
+    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
+    defer app.deinit();
+    var effects = Effects{};
+    _ = try app.get("/plain", Effects.buffered);
+    _ = try app.use(&effects, Effects.global);
+    var req: Request = std.mem.zeroes(Request);
+    req.method = "GET";
+    req.path = "/plain";
+    req.body = "original body";
+    req.route_param_count = 1;
+    req.route_param_names[0] = "untouched";
+    req.route_param_values[0] = "value";
+    const before = req;
+    var res = effects.response();
+    const t = try head_target(&app);
+    const head = input(&req, .get);
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .buffered);
+    try std.testing.expectEqualSlices(u8, std.mem.asBytes(&before), std.mem.asBytes(&req));
+    try std.testing.expectEqual(@as(usize, 0), effects.globals);
+    try std.testing.expect(res.request_body_complete);
+}
+
+test "H1 head: actual selected stream runs globals before quota and preserves metadata" {
+    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
+    defer app.deinit();
+    var effects = Effects{};
+    const route = effects.definition(.headers_only);
+    _ = try app.route_body(.post, "/upload/:id", &route);
+    _ = try app.use(&effects, Effects.global);
+    const t = try head_target(&app);
+    var req = Request{ .method = "POST", .path = "/upload/42", .body = "must disappear" };
+    var res = effects.response();
+    var head = input(&req, .post);
+    const selected = t.resolve(t.context, &head, &res);
+    try std.testing.expect(selected == .stream);
+    try std.testing.expectEqualStrings("42", req.get_param("id").?);
+    try std.testing.expect(effects.observed_empty and effects.incomplete and effects.producer_guard);
+    try std.testing.expectEqual(@as(usize, 1), effects.globals);
+    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
+    try std.testing.expect(std.mem.indexOf(u8, res.pending_headers[0..res.pending_header_length], "X-Admission: kept\r\n") != null);
+    try app.router.reserve_body_route(selected.stream);
+    defer app.router.release_body_route(selected.stream.record_index) catch @panic("test reservation must exist");
+    res = effects.response();
+    try expect_reject(.unavailable, t.resolve(t.context, &head, &res));
+    try std.testing.expectEqual(@as(usize, 2), effects.globals);
+    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
+}
+
+test "H1 head: early data and QUERY refuse before captures globals and sink" {
+    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
+    defer app.deinit();
+    var effects = Effects{};
+    const route = effects.definition(.headers_only);
+    _ = try app.route_body(.query, "/upload/:id", &route);
+    _ = try app.use(&effects, Effects.global);
+    const t = try head_target(&app);
+    var req = Request{ .method = "QUERY", .path = "/upload/42", .body = "sentinel", .route_param_count = 1 };
+    req.route_param_names[0] = "old";
+    req.route_param_values[0] = "old";
+    var res = effects.response();
+    var head = input(&req, .query);
+    head.early_data_forbidden = true;
+    try expect_reject(.too_early, t.resolve(t.context, &head, &res));
+    try std.testing.expectEqualStrings("sentinel", req.body);
+    head.early_data_forbidden = false;
+    try expect_reject(.invalid_query, t.resolve(t.context, &head, &res));
+    try std.testing.expectEqualStrings("old", req.get_param("old").?);
+    try std.testing.expectEqual(@as(usize, 0), effects.globals);
+    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
+}
+
+test "H1 head: late incompatible middleware refuses before every callback" {
+    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
+    defer app.deinit();
+    var effects = Effects{};
+    const route = effects.definition(.reject_legacy);
+    _ = try app.route_body(.post, "/upload", &route);
+    _ = try app.use(&effects, Effects.global);
+    const t = try head_target(&app);
+    var req = Request{ .method = "POST", .path = "/upload" };
+    var res = effects.response();
+    const head = input(&req, .post);
+    try expect_reject(.unavailable, t.resolve(t.context, &head, &res));
+    try std.testing.expectEqual(@as(usize, 0), effects.globals);
+    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
+}
+
+test "H1 head: declared physical and pending capacity checks follow globals" {
+    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
+    defer app.deinit();
+    var effects = Effects{};
+    const route = effects.definition(.headers_only);
+    _ = try app.route_body(.post, "/upload", &route);
+    _ = try app.use(&effects, Effects.global);
+    const t = try head_target(&app);
+    var req = Request{ .method = "POST", .path = "/upload" };
+    var res = effects.response();
+    var head = input(&req, .post);
+    head.head.framing = .{ .content_length = 9 };
+    try expect_reject(.body_too_large, t.resolve(t.context, &head, &res));
+    head.head.framing = .{ .content_length = 8 };
+    head.ingress = null;
+    res = effects.response();
+    try expect_reject(.unavailable, t.resolve(t.context, &head, &res));
+    head.ingress = .{ .capacity = 1, .line_content_limit = 0 };
+    head.pending_header_capacity = 0;
+    res = effects.response();
+    try expect_reject(.unavailable, t.resolve(t.context, &head, &res));
+    try std.testing.expectEqual(@as(usize, 3), effects.globals);
+    try std.testing.expect(res.pending_header_length != 0);
+    head.pending_header_capacity = res.pending_header_length;
+    res = effects.response();
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .stream);
+    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
+}
+
+test "H1 head: middleware fixed final and missing response stop precede admission" {
+    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
+    defer app.deinit();
+    var effects = Effects{ .stop = true };
+    const route = effects.definition(.headers_only);
+    _ = try app.route_body(.post, "/upload", &route);
+    _ = try app.use(&effects, Effects.global);
+    const t = try head_target(&app);
+    var req = Request{ .method = "POST", .path = "/upload" };
+    var res = effects.response();
+    var head = input(&req, .post);
+    head.ingress = null;
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .final);
+    try std.testing.expect(res.state == .idle);
+    effects.final = true;
+    res = effects.response();
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .final);
+    try std.testing.expect(res.state == .ended);
+    try std.testing.expectEqual(@as(usize, 1), effects.writes);
+    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
+}
+
+test "H1 head: method fallback OPTIONS star and WebSocket upgrade preserve precedence" {
+    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
+    defer app.deinit();
+    var effects = Effects{};
+    const route = effects.definition(.reject_legacy);
+    _ = try app.route_body(.get, "/upload", &route);
+    _ = try app.route_body(.any, "/fallback", &route);
+    _ = try app.ws("/upload", .{});
+    const t = try head_target(&app);
+    var req = Request{ .method = "HEAD", .path = "/upload" };
+    var res = effects.response();
+    var head = input(&req, .head);
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .stream);
+    head.method = .post;
+    req.method = "POST";
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .buffered);
+    req.path = "/fallback";
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .stream);
+    req.path = "*";
+    req.method = "OPTIONS";
+    head.method = .options;
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .buffered);
+    req.path = "/upload";
+    req.method = "GET";
+    head.method = .get;
+    try req.add_header("Connection", "keep-alive, upgrade");
+    head.head.headers = req.headers();
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .buffered);
+    req.header_count = 0;
+    try req.add_header("Upgrade", "websocket");
+    head.head.headers = req.headers();
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .buffered);
+    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
+}
+
+test "H1 head: capture overflow is checked before globals then borrows caller slots" {
+    const CaptureApp = support.app.configured_app_with_route_params(2, 16 * 1024, 64 * 1024, 120_000, 17, support.quic_stream.default_capacities);
+    var app = try CaptureApp.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true, .max_route_params = 17 });
+    defer app.deinit();
+    var effects = Effects{};
+    const route = effects.definition(.headers_only);
+    _ = try app.route_body(.post, "/:a/:b/:c/:d/:e/:f/:g/:h/:i/:j/:k/:l/:m/:n/:o/:p/:q", &route);
+    _ = try app.use(&effects, Effects.global);
+    _ = app.loop_handle();
+    const t = app.upload_owners[0].head_target orelse return error.MissingHeadTarget;
+    var req = Request{ .method = "POST", .path = "/1/2/3/4/5/6/7/8/9/10/11/12/13/14/15/16/17" };
+    var res = effects.response();
+    var head = input(&req, .post);
+    try expect_reject(.unavailable, t.resolve(t.context, &head, &res));
+    try std.testing.expectEqual(@as(usize, 0), effects.globals);
+    var names: [1][]const u8 = undefined;
+    var values: [1][]const u8 = undefined;
+    head.captures = .{ .names = &names, .values = &values };
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .stream);
+    try std.testing.expectEqualStrings("17", req.get_param("q").?);
+    try std.testing.expect(req.extra_param_names.?.ptr == &names);
+    try std.testing.expectEqual(@as(usize, 1), effects.globals);
+    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
+}
+
+test "H1 head: QUERY validates mutable used overflow headers before matching" {
+    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
+    defer app.deinit();
+    var effects = Effects{};
+    const route = effects.definition(.headers_only);
+    _ = try app.route_body(.query, "/upload/:id", &route);
+    const t = try head_target(&app);
+    var req = Request{ .method = "QUERY", .path = "/upload/42" };
+    var res = effects.response();
+    var head = input(&req, .query);
+    var names = [_][]const u8{"Content-Type"};
+    var values = [_][]const u8{"application/json"};
+    head.headers = .{ .names = &names, .values = &values };
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .stream);
+    try std.testing.expectEqualStrings("application/json", req.get_header("Content-Type").?);
+    try std.testing.expect(req.extra_header_values.?.ptr == &values);
+    try std.testing.expectEqual(@as(usize, 1), req.extra_header_count);
+    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
+}
+
+test "H1 head: overflow WebSocket intent remains buffered without binding Request views" {
+    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
+    defer app.deinit();
+    var effects = Effects{};
+    const route = effects.definition(.headers_only);
+    _ = try app.route_body(.get, "/upload", &route);
+    _ = try app.ws("/upload", .{});
+    _ = try app.use(&effects, Effects.global);
+    const t = try head_target(&app);
+    var req = Request{ .method = "GET", .path = "/upload" };
+    var res = effects.response();
+    var head = input(&req, .get);
+    var names = [_][]const u8{"Connection"};
+    var values = [_][]const u8{"keep-alive, UpGrAdE"};
+    head.headers = .{ .names = &names, .values = &values };
+    head.head.headers = support.fetch.HeadersView.init_with_extra(&.{}, &.{}, &names, &values);
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .buffered);
+    try std.testing.expect(req.extra_header_names == null);
+    try std.testing.expectEqual(@as(usize, 0), effects.globals);
+    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
+}
+
+const GlobalOrder = struct {
+    calls: [3]u8 = @splat(0),
+    count: usize = 0,
+    fn first(context: *anyopaque, _: *Request, _: *Response) support.radix.MiddlewareResult {
+        const self: *GlobalOrder = @ptrCast(@alignCast(context));
+        self.calls[self.count] = 1;
+        self.count += 1;
+        return .continue_dispatch;
+    }
+    fn second(context: *anyopaque, _: *Request, _: *Response) support.radix.MiddlewareResult {
+        const self: *GlobalOrder = @ptrCast(@alignCast(context));
+        self.calls[self.count] = 2;
+        self.count += 1;
+        return .continue_dispatch;
+    }
+};
+
+test "H1 head: every authorized global runs once in registered order" {
+    var app = try App.init_configured(std.testing.io, std.testing.allocator, .{ .max_connections = 2, .stream_request_bodies = true });
+    defer app.deinit();
+    var effects = Effects{};
+    const route = effects.definition(.headers_only);
+    var order = GlobalOrder{};
+    _ = try app.route_body(.post, "/upload", &route);
+    _ = try app.use(&order, GlobalOrder.first);
+    _ = try app.use(&order, GlobalOrder.second);
+    const t = try head_target(&app);
+    var req = Request{ .method = "POST", .path = "/upload" };
+    var res = effects.response();
+    const head = input(&req, .post);
+    try std.testing.expect(t.resolve(t.context, &head, &res) == .stream);
+    try std.testing.expectEqualSlices(u8, &.{ 1, 2 }, order.calls[0..order.count]);
+    try std.testing.expectEqual(@as(usize, 0), effects.sink_calls);
+}
