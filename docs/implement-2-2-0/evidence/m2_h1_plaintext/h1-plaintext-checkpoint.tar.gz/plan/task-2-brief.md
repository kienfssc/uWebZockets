## Task 2: Concrete plaintext driver and native lifetime

Role: transport_io. Own core/tcp.zig, NEW core/tcp_upload.zig, required
core/loop.zig admission-invariant tag, and NEW src/tests/http1_upload_driver_tests.zig
inside /tmp/uwz-m2-h1-plaintext-transport. Evidence:
.uwz-work/evidence/h1-plaintext/transport. A single driver export may be added
to THIS PRIVATE COPY's test_support only for focused test compilation; Root
serializes its promotion. Do not edit app/config/tests/main/docs or predecessor.

Earned seam: tcp_upload owns retained-tail admission/progression, actual sinks,
controls, terminal/quota cleanup and upload reclamation. TCP keeps native
callbacks/platform close/pool release. Pure helpers/storage/decoder stay canonical.
Deleting this module would scatter payload accounting, callback borrows, pause,
terminal ownership and metadata lifetime across native callbacks and controls.
No generic continuation hook, interception framework or pass-through facade.
Promote only actually needed bounded TCP internal entries; never raw socket close.

Use H0.consume_head before buffered policy. Buffered fallback calls commit_head
and preserves failure checkpoints/legacy collector without rescanning. Pin prefix
[0,header_end), retain physical tail; reuse checked ingress_bounds. No ingress
needed for absent/empty, >=1 for positive fixed length, >=3 chunked. Cap plaintext
reads at min(8192,free retained space), including before admission. Genuine rearm
requires actual retarget_completed_receive; otherwise disarm/retire/fresh arm.
No overwrite of live completion or new buffer allocation.

Hold delivery borrow across real HeadTarget.resolve and metadata preservation;
stop on close before reservation. Copy bounded pending headers. Actual atomic
reserve_and_arm then real sink.begin. Failed begin rejects/releases with no cancel;
success accepts binding before deferred cancellation. Send required100Continue
after successful begin even paused, preserving final headers. No wait for content.

Use actual common BodyState/BodyDecoder. Observe new offered logical payload ONCE;
pending_payload counts unaccepted observed suffix. Resume reoffers it first,
accepts prefixes in state+decoder once, then progresses new data. Reclaim only
consumed tail and discard_prefix/rebase, never move pinned head. Full window
pauses reads; logical u64 limits are separate from bounded usize offsets. Fixed,
chunked extensions/CRLF/trailers reuse strict decoder and accepted bounds; discard
trailers, don't overwrite initial metadata. Final-byte pause needs explicit resume;
end may occur without another read. Implement actual closing-aware BodyControl
resume/cancel, never no-op continuation. Shared generation/phase validation and
exact error precedence remain. BodyDeliveryFailed requires completed legitimate
terminal ownership, not abandoned state.

Actual chunk uses start_chunk/sink.chunk/accept_chunk or fail_chunk. Actual end
uses take_end with real framing/queue facts, projected metadata/fresh restored
Response, sink.end and terminal completion even on error; no second cancel.
Cancel calls request_cancel, defers begin/chunk, otherwise actual sink.cancel and
finish_terminal. Release admission only from reject_begin/finish_terminal bool,
using head_target.router.release_body_route. Add only needed payloadless
CallbackFailure.body_admission_missing + fixed diagnostic after existing latch;
exhaustively map actual release/rollback error, never fake native error.

Consume StageA policy in every enabled recv/send disarm, cancelACK, two fresh
retirement stages and close tail. Frame pin before clearing target; request
retirement before final frame/ACK flag clear. Actual cancel_ack decides retained/
abandoned target. Inactive expiry maps existing retirement_inactive case; native
timer errors stay .retirement. Fresh Timer.run(0) twice, never rearm/reset active
timer or reuse native recv/send/cancel storage. Idle before tail, no post-tail access.

Initial !closing transition is sole cancel discriminator. Capture owner+bound
LoopHandle/local needed directions; acquire delivery only if previously false.
Publish closing/close_pending and BOTH needed cancel flags before generic
LoopHandle.submit (IOCP job-object callback can inline); successful fenced submit
before selected cancels. Never clear target there; later tails NEVER recancel.
Inherited delivery remains true. Drop only owned pin then safe tail as final
action. Nested delivery/cleanup never clears another operation's pin. Re-read
current obligations after inline callbacks, never restore snapshots.

Real body/output cleanup under delivery borrow; existing clear_stream/async cancel,
no invented producer abort callback. Retain metadata/TLS until native obligations
drain. claim_close is sole physical permission. Guard synchronous TLS destruction,
drop owned borrow immediately before platform tail, preserve Windows pairing and
truthful close errors. release_closed_connection adds owner drain; clear callbacks/
pool pointer before final pool callback, never access after potential release.

End/output queue does not authorize reset under frame/retirement borrows. Use
existing dispatch_suspended/pending_request_consumed to keep head and pipeline
bytes until response ownership+canonical borrows drain. Guard resume_async_dispatch
BEFORE mutation/compaction, including pump_stream_body after producer closes.
Paused upload retains idle timeout; initial-header deadline stops after admission.
Select new ingress for plaintext H1 only. Legacy TLS extraction/encrypted reads,
HTTP2 and WebSocket precedence remain; no TLS body upload claim. Native deferred
TLS destruction still needs separate crypto review before combined acceptance.

Tests: actual driver operations/real registered sinks, caller-owned storage,
bounded memory/write batching and real outer borrows where applicable. Effects
requiring native runtime go to coherent owned clients in Task3, not fake native
state or interception hooks. Cover progress, terminal/quota exactly once,
metadata/control generation, pause/resume/EOF/framing/error and pending tail reset.
Keep prior31 App/11 policy/decoder/admission suites. Compile eligible targets,
scope fmt/conventions/version, audit no allocations and layout changes. Preserve
every real failure/input/source/binary/env binding. Freeze exact source/diff/report
for independent spec+quality+structural review. No new native fault/cancel probes.

