# Task 1 App head resolver handoff

Status: DONE_WITH_CONCERNS. Component source is frozen for independent review; all assigned final checks completed. Combined-driver integration and project-wide verification remain Root-owned.

Owned source is `/tmp/uwz-m2-h1-plaintext-app`, a new independent ordinary-file copy (no Git, links or inherited caches) of immutable `/tmp/uwz-m2-h1-native-lifetime`. All 1020 baseline files were checked against `.uwz-work/evidence/h1-native-lifetime/final-source-manifest.json`; baseline digest `81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108`.

Only changed paths:

- `src/router/app.zig`, SHA256 `e240dc0ee625f71cf311a1b87d83e4202cbbacd55e57983a630b4ff4d8c4733d`.
- New `src/tests/body_h1_head_tests.zig`, SHA256 `fec97e1121746fd21c289cd7f295732ca63995f64beba21de83b5354e90e1647`.

Frozen complete source digest `b97d3b94a2dde50788fc6ae076c7233e61da4914267fae884d4d9d8125e94a4d`. Durable review inputs are `.uwz-work/evidence/h1-plaintext/app/frozen/{app.zig,body_h1_head_tests.zig}`, `frozen-source-manifest.json`, `preimage/app.zig`, and manifest-bound `app.patch` (SHA256 `c8b10e32e425ba61e06861c3d0bfe6ed2486fa74072abcb82b7b832b74419e7f`). No production Root source, transport, dependencies, exports, shared tests/main or test_support changed.

## Implementation contract

Existing first stable `App.loop_handle` upload-owner binding installs the actual App context, mutable router and resolver together with the loop handle. Existing non-null target refuses replacement; subsequent bindings preserve identity; existing reset preserves the target. No fields/layout growth or callback wrapper.

Resolution chooses through non-capturing Router.match. OPTIONS-* and WebSocket intent remain buffered; WebSocket header inspection uses HeadReady.headers including overflow without mutating Request. Buffered decisions change no Request bytes and run no globals. Selected stream applies early-data refusal, binds used mutable header arrays and empty body, checks QUERY before capture materialization/globals, then matches using caller capture capacity. Incompatible late global policy refuses before callbacks. Only quota-full is deferred until after authorized globals. Response is incomplete during globals, preserving producer guards. Middleware final/stop precedes later checks. Declared length, physical ingress availability, pending-header capacity and current admission are checked in order; stream returns the original unreserved BodyMatch. Resolver performs no reservation, sink callback, Continue or collection.

Driver integration must supply `HeadInput.headers` as USED mutable overflow slots and `HeadReady.headers` as the complete initial header view; `ingress` is already checked by existing ingress_bounds. Root's driver owns bounded refusal output, pending-byte persistence, final/missing-response handling and close-after-drain. This component makes no native upload/TLS/liveness claim.

## Failing-first evidence

Each label has exact compiler argv, cwd, source-before/after hashes, compiler/archive hashes, override identity, requested environment, compile/run status and binary hashes in `.uwz-work/evidence/h1-plaintext/app/<label>.json`; compile/run logs and durable exact source snapshots are adjacent. `verify.py` records/replays the commands, all binaries/cache stay under `/tmp`.

- `red-binding`: actual baseline App stable-binding test compiled successfully and failed `MissingHeadTarget` (0/1). Behavioral red, not declaration failure.
- `red-resolver-suite`: declaration errors in test drafting (shadowed name, incorrect existing method names/config specialization); preserved, not counted as behavior proof.
- `red-resolver-behavior`: second drafting declaration failure (`begin_chunks` should be existing `begin_chunked`); preserved, not counted as behavior proof.
- `red-resolver-baseline`: corrected ten tests compiled; nine failed MissingHeadTarget, and one exposed invalid test registration of literal `*` (removed before the next stage).
- `red-bound-resolver`: stable binding plus intentionally buffered-only resolver candidate compiled; binding and buffered nonmutation passed, eight actual resolver expectations failed. Exact candidate and binary/run evidence preserved. This candidate is superseded and is not deliverable source.
- `green-resolver`: full resolver, 10/10 Debug pass.
- `red-overflow-upgrade`: 11/12 Debug pass; actual resolver incorrectly selected stream for overflow WebSocket intent. Behavioral red preserved.
- `green-overflow-upgrade`: final frozen source, 12/12 Debug pass. Includes explicit multi-global registration order, bounded final response, missing-response stop, method fallback, capture capacity, late middleware, quota order, pending metadata and sink call counts.

No fake native callbacks, fabricated completions, fault/cancellation schedules or panic subprocesses were executed. Tests invoke the actual `owner.head_target.resolve` and real registered BodyRoutes; the bounded transport-neutral response target only records synchronous response writes.

## Final verification

All results below use the unchanged frozen two-file source identity above. Exact full compiler argv are stored in each named JSON record; no inherited Git status is used.

- `green-overflow-upgrade`: native Debug resolver suite 12/12, compile/run 0/0. Runs in the default sandbox, where backend selection is epoll; its requested io_uring environment was not asserted by these generic head tests. This proves resolver policy, not io_uring behavior.
- `final-head-ReleaseSafe`: native ReleaseSafe resolver suite 12/12, compile/run 0/0, likewise generic head policy in the sandbox.
- `final-existing-app-epoll-ordinary-os-io_uring`: existing unchanged App suite 31/31, run status 0. Uses the already-built binary from `final-existing-app-epoll.json`, reverified binary/source hashes, ordinary OS access, requested and asserted actual io_uring.
- `final-existing-router-ordinary-os-io_uring`: existing unchanged router suite 39/39, run status 0. Uses the already-built binary from `final-existing-router.json`, with source/binary hashes preserved and io_uring requested in the ordinary OS environment. This suite does not independently assert backend; the paired App suite does.
- `final-head-macos`: aarch64-macos ReleaseSafe compile-only status 0, no binary or execution.
- `final-head-windows`: x86_64-windows-gnu ReleaseSafe compile-only status 0, no binary or execution.
- `fmt.json`, `conventions.json`, `version.json`: scoped `zig fmt --check src/router/app.zig src/tests/body_h1_head_tests.zig`, unchanged `sh scripts/check_conventions.sh`, and `sh scripts/check_release_version.sh` each status 0; metadata matches 2.1.6.

Preserved nonpassing harness records: `final-existing-app` requested io_uring in the sandbox but actual backend was epoll, so ten unchanged backend assertions failed (21/31 pass). `final-existing-app-epoll` matched the sandbox backend and passed29/31; two ordinary listener cases failed socket EPERM. `final-existing-router` passed34/39, with five same sandbox socket EPERM failures. These were ordinary unchanged healthy suites, not new or injected fault probes. `final-existing-app-epoll-ordinary-os` mistakenly retained the sandbox's epoll expectation when ordinary OS selected io_uring, yielding21/31; this record is preserved. `final-existing-router-ordinary-os` passed39/39 with epoll requested but without a backend assertion and is superseded for final environment binding by the io_uring-labelled record. No source/assertion changed to correct the harness expectations. Root explicitly instructed the final ordinary OS io_uring runs; only already-built unchanged binaries were rerun.

Actual replay entry argv (cwd `/workspaces/uWebZockets`):

```sh
python3 .uwz-work/evidence/h1-plaintext/app/verify.py green-overflow-upgrade src/tests/body_h1_head_tests.zig Debug
python3 .uwz-work/evidence/h1-plaintext/app/verify.py final-head-ReleaseSafe src/tests/body_h1_head_tests.zig ReleaseSafe
python3 .uwz-work/evidence/h1-plaintext/app/verify.py final-existing-app-epoll src/tests/body_app_tests.zig Debug
python3 .uwz-work/evidence/h1-plaintext/app/verify.py final-existing-router src/tests/router_tests.zig Debug
UWZ_COMPILE_TARGET=aarch64-macos python3 .uwz-work/evidence/h1-plaintext/app/verify.py final-head-macos src/tests/body_h1_head_tests.zig ReleaseSafe
UWZ_COMPILE_TARGET=x86_64-windows-gnu python3 .uwz-work/evidence/h1-plaintext/app/verify.py final-head-windows src/tests/body_h1_head_tests.zig ReleaseSafe
python3 .uwz-work/evidence/h1-plaintext/app/checks.py
python3 .uwz-work/evidence/h1-plaintext/app/rerun.py final-existing-app-epoll
python3 .uwz-work/evidence/h1-plaintext/app/rerun.py final-existing-router
```

The final two commands run with ordinary OS permission and `UWZ_TEST_XEV_BACKEND=io_uring` installed by the runner. Earlier `verify.py` revisions and records are not silently relabelled: the final helper currently requests epoll for sandbox runs, while the original records explicitly retain their actual requested environment. Use fresh output labels when replaying to preserve existing evidence. Full compiler commands, input hashes, module roots, override identity, source manifests and binary hashes live in the immutable evidence records, not just these shorthand invocations.

Full build/examples/package-consumer/compliance/live clients belong to Root's combined unit; this component does not claim them. Graphify query was used before source exploration; this separate unindexed source copy does not modify Root's graph. Root owns the final integrated graph refresh.

The compiler is the required `/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`, `-j2`. Required immutable c223 libxev override is checked against `.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json` before each test compilation. C bindings use original r2 `c-native.zig` and target-matching original r2 foreign bindings; native archives remain existing `zig-out/lib` inputs. No dependency fetching, pin/ref changes, commit, push or publication.

## Self-review and limits

Reviewed the two-file direct diff against the immutable manifest baseline. Existing early-data/QUERY precedence, HTTP method fallback and WebSocket intent are retained; missing captures refuse before globals; quota is checked again after globals and before the driver can reserve. Response pending bytes remain intact on resolver refusals, and no sink callback can occur inside this component. Changes are additive/internal, with unchanged public Request/OwnedRequest layouts, exports, capacities and error sets. The new test needs Root's final central-main import.

Remaining review concern: independent review should verify the actual combined driver constructs complete header views and used mutable overflow views and applies refusal/final handling with pinned metadata. The App resolver deliberately trusts existing typed ingress_bounds output rather than creating a duplicate physical parser policy. Native Windows runtime, maintained publication/protections/all-four zon adoption and complete final project gates remain open per global constraints.
