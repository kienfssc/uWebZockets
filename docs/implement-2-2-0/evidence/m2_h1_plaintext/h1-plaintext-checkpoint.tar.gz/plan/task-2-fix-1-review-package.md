# Task2 fix round1 scoped review package

Prior reviewed source35738519cc5378dd5a716a4588b5e946c44ef82c91429933e3c17bbf12efd27b.
Fixed sourcea9022ee14096698cf92d9c66afe4d156b4135382c8f72fc1e35a622d70773e26.
Finding: P1 upload_tail omitted file_body, allowing dispatch while a file response owns completion.
Fix diff SHA7088659d8b63008d4a99242b37b9c0e5fb63ea90609066116b4a86b26be74429.
Read task-2-report.md appended round1 exact covering tests/commands/outcomes; all
v6 checks terminal. Pure policy guard tests are not native file-ordering proof;
Root's combined ordinary client gate remains pending.

## Scoped diff

--- v5/src/core/tcp.zig
+++ v6/src/core/tcp.zig
@@ -3053,7 +3053,7 @@
     }
     if (owner.delivery_active or owner.read_callback_active or owner.write_callback_active) return;
     if (conn.pending_request_consumed != 0 and conn.dispatch_suspended and
-        conn.stream_producer == null and !conn.async_response_state.is_pending() and upload_storage.is_drained(owner))
+        !response_dispatch_owned(conn.file_body != null, conn.stream_producer != null, conn.async_response_state.is_pending()) and upload_storage.is_drained(owner))
     {
         conn.resume_async_dispatch();
         return;
@@ -3081,3 +3081,8 @@
     release_closed_connection(conn);
     return .disarm;
 }
+
+/// An unfinished response retains dispatch until its existing owner completes it.
+pub fn response_dispatch_owned(file_active: bool, producer_active: bool, async_pending: bool) bool {
+    return file_active or producer_active or async_pending;
+}
--- v5/src/tests/http1_upload_driver_tests.zig
+++ v6/src/tests/http1_upload_driver_tests.zig
@@ -316,3 +316,13 @@
     try std.testing.expect(fixture.owner.close_pending);
     try std.testing.expect(fixture.owner.delivery_active);
 }
+
+test "H1 driver: outstanding file response retains dispatch after native retirement" {
+    try std.testing.expect(support.tcp.response_dispatch_owned(true, false, false));
+}
+
+test "H1 driver: producer and async owners retain dispatch until all output owners finish" {
+    try std.testing.expect(support.tcp.response_dispatch_owned(false, true, false));
+    try std.testing.expect(support.tcp.response_dispatch_owned(false, false, true));
+    try std.testing.expect(!support.tcp.response_dispatch_owned(false, false, false));
+}
