## Task 1: App head resolution and stable binding

Role: dx_router. Read global constraints and the referenced specs; do not read
the entire task history. Own only router/app.zig and new
src/tests/body_h1_head_tests.zig in /tmp/uwz-m2-h1-plaintext-app. Evidence:
.uwz-work/evidence/h1-plaintext/app. Do not edit transport, config, root exports,
test_support or tests/main. Focused tests may use existing test_support directly;
Root imports the new test in combined central main before final verification.

Bind actual HeadTarget in existing App.loop_handle stable-placement binding:
context=this App pointer, router=its mutable router, resolve=real callback. Do
not bind before stable placement, overwrite active target association, or move
App/loop/router. Existing on_new_connection attaches owner before read_start.
Preserve target through reset. No additional field or callback wrapper.

Resolver returns existing HeadDecision. Use Router.match to choose without
materializing captures, retaining method fallback/OPTIONS-*/WebSocket precedence.
Buffered decision mutates no Request fields and runs no globals. Selected stream:
early-data refusal; bind used mutable overflow header views; empty legacy body;
QUERY validation before capture matching/globals; checked caller capture capacity.
Recheck late middleware compatibility before callbacks. Authorized globals run
once in registered order with request_body_complete=false. Quota full is deferred
until after globals. Then declared logical size, physical ingress, pending-header
capacity and current admission. Return UNRESERVED BodyMatch, final response, or
bounded refusal. No reservation, sink callback, 100 Continue or body collection
inside resolver. Preserve middleware pending headers and existing early response
guards. No fake stream callbacks for refusal; no constCast or Request copy.

Write meaningful failing-first actual resolver tests: stable binding; buffered
nonmutation/no globals; method/upgrade/OPTIONS precedence; QUERY order; capture
capacity; late middleware policy; globals before quota; declared/physical/header
capacity and pending metadata; zero sink calls before driver admission. Use real
registered BodyRoutes and actual owner.head_target.resolve, bounded memory
responses/caller data. New head tests plus unchanged App/router checks and
eligible compile-only, scoped fmt/conventions/version. Preserve every red and
actual dependency/source/environment binding. No native uploads in this component.
Freeze source/snapshots/diff/report for independent spec+quality review.

