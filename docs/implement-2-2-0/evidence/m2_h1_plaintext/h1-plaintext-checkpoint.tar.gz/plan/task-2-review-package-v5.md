# Task 2 plaintext driver/native lifetime review package v5

Read task-2-brief.md, global_constraints.md and task-2-report.md beside this file.
RootBASE877a2ac8e0d004a566aef1eac775eb06655e37e9 is recovery metadata only.
Executable BASE81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108.
Frozen candidate35738519cc5378dd5a716a4588b5e946c44ef82c91429933e3c17bbf12efd27b;
actual patchb2dbc41d1ca78be47a85d25c871244b27eeeff93124027a538b2dc49fcbf815b.
Authoritative manifest-bound two-tree diff follows, not Root Git archive diff.
Driver Debug17/17; other final v5 checks pending, earlier v4 records retain exact
bindings and never stand for changed v5. App resolver reviewed separately and is
NOT merged into this copy; live/full combined/central new-test registration not
claimed. Root later adds actual App shutdown call tcp_upload.close(conn,.shutdown)
in place of generic close, with no subsequent current-conn access, and re-reviews.
Full source freeze/snapshots and exact v4-to-v5 correction are in transport evidence.

## Direct source diff

--- a/src/core/loop.zig
+++ b/src/core/loop.zig
@@ -95,6 +95,7 @@
     retirement: xev.Timer.RunError,
     close: xev.CloseError,
     retirement_inactive,
+    body_admission_missing,
 };
 
 /// Decides whether cancellation may clear an existing target flag.
@@ -145,6 +146,7 @@
             .retirement => @panic("guarded event loop retirement callback failed"),
             .close => @panic("guarded event loop close callback failed"),
             .retirement_inactive => @panic("guarded event loop retirement callback was inactive"),
+            .body_admission_missing => @panic("guarded event loop body admission was missing"),
         }
     }
 };
--- a/src/core/tcp.zig
+++ b/src/core/tcp.zig
@@ -4,6 +4,7 @@
 const c = @import("c");
 const Loop = @import("loop.zig").Loop;
 const core_loop = @import("loop.zig");
+const tcp_upload = @import("tcp_upload.zig");
 const upload_storage = @import("http1_upload_storage.zig");
 const core_timer = @import("timer.zig");
 const timer_wheel = @import("timer_wheel.zig");
@@ -266,8 +267,9 @@
             _ = scheduler.cancel(&self.idle_timer);
             return;
         }
-        const partial_request = self.request_len != 0 or
-            self.parser.state != .method and self.parser.state != .done;
+        const admitted = if (self.upload_owner) |owner| owner.head != null else false;
+        const partial_request = !admitted and (self.request_len != 0 or
+            self.parser.state != .method and self.parser.state != .done);
         const timeout = if (partial_request) self.header_timeout_ms else self.idle_timeout_ms;
         if (timeout == 0) {
             _ = scheduler.cancel(&self.idle_timer);
@@ -524,6 +526,9 @@
 
     /// Routes mutable plaintext to HTTP/1, HTTP/2, or WebSocket state.
     pub fn route_decrypted_data(self: *TcpConnection, data: []u8) void {
+        const owner = checked_upload_owner(self);
+        const owned = if (owner) |value| tcp_upload.borrow(value) else false;
+        defer if (owner != null) tcp_upload.finish_borrow(self, owned);
         switch (self.protocol_state) {
             .detect => self.route_detect_data(data),
             .http => self.route_http_data(data),
@@ -1164,7 +1169,19 @@
         // HTTP/2 reads remain armed while other streams await completion.
     }
 
-    fn route_http_data(self: *TcpConnection, data: []const u8) void {
+    /// Pins enabled metadata through parser, dispatch and every nested close.
+    pub fn route_http_data(self: *TcpConnection, data: []const u8) void {
+        const owner = checked_upload_owner(self);
+        const owned = if (owner) |value| tcp_upload.borrow(value) else false;
+        defer if (owner != null) tcp_upload.finish_borrow(self, owned);
+        if (self.ssl == null) {
+            if (owner) |value| {
+                if (value.head != null and value.body.phase != .inactive) {
+                    tcp_upload.receive(self, data);
+                    return;
+                }
+            }
+        }
         // Re-arm the idle/header deadline after every parse or dispatch exit;
         // the partial-request check sees the post-dispatch parser state.
         defer self.touch_activity();
@@ -1196,6 +1213,15 @@
         self.request_len += data.len;
 
         while (self.request_len > 0 and !self.closing) {
+            if (self.ssl == null and owner != null) {
+                switch (self.parser.state) {
+                    .method, .path, .protocol, .headers => {
+                        const head = http_parser.consume_head(&self.parser, &self.req, self.request_buffer[0..self.request_len]);
+                        if (tcp_upload.admit(self, head)) return;
+                    },
+                    else => {},
+                }
+            }
             const consumed = http_parser.consume(
                 &self.parser,
                 &self.req,
@@ -1215,6 +1241,13 @@
                 return;
             }
             if (self.parser.state != .done) {
+                if (owner != null and self.ssl == null and self.request_len == self.request_buffer.len) {
+                    switch (self.parser.state) {
+                        .body, .chunk_size, .chunk_ext, .chunk_data, .chunk_crlf, .chunk_trailer => self.reject_payload_too_large(),
+                        else => self.reject_headers_too_large(),
+                    }
+                    return;
+                }
                 self.handle_expect_continue();
                 return;
             }
@@ -1358,7 +1391,8 @@
         }
     }
 
-    fn finish_sync_dispatch(self: *TcpConnection, response: *Response) void {
+    /// Applies bounded synchronous response ownership after a borrowed callback.
+    pub fn finish_sync_dispatch(self: *TcpConnection, response: *Response) void {
         if (self.buffered_file.file != null) {
             self.dispatch_suspended = true;
             return;
@@ -1505,6 +1539,14 @@
     }
 
     pub fn resume_async_dispatch(self: *TcpConnection) void {
+        if (self.closing) return;
+        const owner = checked_upload_owner(self);
+        if (owner) |value| {
+            if (!upload_storage.is_drained(value)) return;
+            upload_storage.reset(value);
+        }
+        const owned = if (owner) |value| tcp_upload.borrow(value) else false;
+        defer if (owner != null) tcp_upload.finish_borrow(self, owned);
         self.dispatch_suspended = false;
         const consumed = self.pending_request_consumed;
         self.pending_request_consumed = 0;
@@ -1547,14 +1589,23 @@
         }
     }
 
-    fn arm_read(self: *TcpConnection) void {
-        _ = checked_upload_owner(self);
-        if (self.read_active or self.dispatch_suspended or self.closing) return;
+    /// Submits only a fresh, unborrowed receive slot and bounded plaintext window.
+    pub fn arm_read(self: *TcpConnection) void {
+        const owner = checked_upload_owner(self);
+        if (self.read_active or self.dispatch_suspended or self.closing or self.close_when_drained) return;
+        if (owner) |value| {
+            if (value.read_callback_active or self.read_cancel_active or value.read_retirement != .idle) {
+                value.read_resume_pending = true;
+                return;
+            }
+        }
+        const capacity = if (owner != null) tcp_upload.read_capacity(self) else socket_read_capacity;
+        if (capacity == 0) return;
         self.read_active = true;
         self.socket.read(
             self.loop,
             &self.read_completion,
-            .{ .slice = &self.read_buffer },
+            .{ .slice = self.read_buffer[0..capacity] },
             TcpConnection,
             self,
             on_read_complete,
@@ -1742,6 +1793,12 @@
     /// direct send, so the completion can drain the remainder.
     pub fn arm_write(self: *TcpConnection) void {
         if (self.is_writing or self.write_len == 0 or self.closing) return;
+        if (checked_upload_owner(self)) |owner| {
+            if (owner.write_callback_active or self.write_cancel_active or owner.write_retirement != .idle) {
+                owner.write_resume_pending = true;
+                return;
+            }
+        }
 
         const contiguous_len = @min(self.write_len, self.write_queue.len - self.write_head);
         self.write_in_flight_len = contiguous_len;
@@ -1887,7 +1944,8 @@
     ///
     /// Early data is replayable, so only safe methods are dispatched before the
     /// handshake is confirmed.
-    fn early_data_forbids(self: *const TcpConnection, method: ?radix.HttpMethod) bool {
+    /// Preserves the transport early-data policy during header admission.
+    pub fn early_data_forbids(self: *const TcpConnection, method: ?radix.HttpMethod) bool {
         const ssl = self.ssl orelse return false;
         if (c.SSL_in_early_data(ssl) == 0) return false;
         const parsed = method orelse return true;
@@ -1997,12 +2055,11 @@
     buffer: xev.ReadBuffer,
     result: xev.ReadError!usize,
 ) xev.CallbackAction {
-    _ = completion;
+    const conn = user_data.?;
+    if (checked_upload_owner(conn) != null)
+        return on_upload_read_complete(conn, loop, completion, result);
     _ = socket;
     _ = buffer;
-
-    const conn = user_data.?;
-    _ = checked_upload_owner(conn);
     conn.loop = loop;
     conn.read_active = false;
 
@@ -2046,7 +2103,7 @@
     return .rearm;
 }
 
-fn on_write_complete(
+fn on_write_complete_inner(
     user_data: ?*TcpConnection,
     loop: *xev.Loop,
     completion: *xev.Completion,
@@ -2156,7 +2213,11 @@
 
 /// Closes plaintext or gracefully shuts down TLS after queued bytes drain.
 pub fn close_after_flush(conn: *TcpConnection) void {
-    _ = checked_upload_owner(conn);
+    const owner = checked_upload_owner(conn);
+    if (conn.closing) return;
+    const owned = if (owner) |value| tcp_upload.borrow(value) else false;
+    defer if (owner != null) tcp_upload.finish_borrow(conn, owned);
+    if (owner != null) tcp_upload.cancel(conn, .cancelled);
     if (conn.closing) return;
     conn.begin_tls_shutdown() catch {
         close_connection(conn);
@@ -2173,6 +2234,10 @@
 /// Cancels active completions and begins idempotent socket teardown.
 pub fn close_connection(conn: *TcpConnection) void {
     const upload_owner = checked_upload_owner(conn);
+    if (upload_owner) |owner| {
+        close_upload_connection(conn, owner);
+        return;
+    }
     if (conn.closing) return;
     conn.closing = true;
     _ = conn.abort_controller.abort(.connection_closed);
@@ -2199,10 +2264,7 @@
         // callback: IOCP marks it dead, and kqueue drops it while it is still
         // in the submission queue. Flush first so every cancel observes an
         // active target whose callback clears the target flag.
-        const submission = if (upload_owner) |owner|
-            owner.loop_handle.?.submit()
-        else
-            xev.submit(conn.loop);
+        const submission = xev.submit(conn.loop);
         submission catch |err| {
             // Keep the target flags set: the backend cannot dispatch the
             // queued completions, so reusing the slot could fire a stale
@@ -2292,6 +2354,10 @@
     result: xev.CancelError!void,
 ) xev.CallbackAction {
     const conn = user_data.?;
+    if (conn.upload_owner != null) {
+        upload_cancel_ack(conn, true, result);
+        return .disarm;
+    }
     _ = result catch |err| {
         if (err != error.NotFound) log.debug("read cancel error: {}", .{err});
     };
@@ -2307,6 +2373,10 @@
     result: xev.CancelError!void,
 ) xev.CallbackAction {
     const conn = user_data.?;
+    if (conn.upload_owner != null) {
+        upload_cancel_ack(conn, false, result);
+        return .disarm;
+    }
     _ = result catch |err| {
         if (err != error.NotFound) log.debug("write cancel error: {}", .{err});
     };
@@ -2318,7 +2388,7 @@
 fn on_idle_timeout(ctx: *anyopaque) void {
     const conn: *TcpConnection = @ptrCast(@alignCast(ctx));
     if (conn.closing) return;
-    close_connection(conn);
+    tcp_upload.close(conn, .timeout);
 }
 
 fn on_sleep_expired_slot(ctx: *anyopaque) void {
@@ -2351,6 +2421,11 @@
     if (!conn.closing or !conn.close_complete) return;
     if (conn.read_active or conn.is_writing) return;
     if (conn.read_cancel_active or conn.write_cancel_active) return;
+    if (checked_upload_owner(conn)) |owner| {
+        if (!upload_storage.is_drained(owner)) return;
+        upload_storage.reset(owner);
+        conn.req = .{};
+    }
 
     const callback = conn.on_close_cb orelse return;
     const pool = conn.pool_ptr orelse return;
@@ -2829,3 +2904,180 @@
 fn close_unregistered_socket(socket: xev.TCP) void {
     close_socket(xev.tcp_fd(socket));
 }
+
+fn on_upload_read_complete(conn: *TcpConnection, loop: *xev.Loop, completion: *xev.Completion, result: xev.ReadError!usize) xev.CallbackAction {
+    const owner = conn.upload_owner.?;
+    owner.read_callback_active = true;
+    conn.read_active = false;
+    conn.loop = loop;
+    var action: xev.CallbackAction = .disarm;
+    defer {
+        if (action == .disarm) request_upload_retirement(conn, true);
+        owner.read_callback_active = false;
+        if (action == .disarm) upload_tail(conn);
+    }
+    if (conn.closing) return .disarm;
+    const length = result catch |err| {
+        tcp_upload.cancel(conn, if (err == error.EOF) .peer_closed else if (err == error.ConnectionResetByPeer) .reset else .source_failure);
+        close_connection(conn);
+        return .disarm;
+    };
+    if (length == 0) {
+        tcp_upload.cancel(conn, .peer_closed);
+        close_connection(conn);
+        return .disarm;
+    }
+    const now = std.Io.Clock.now(.awake, conn.io);
+    conn.last_active_ms = @intCast(@divTrunc(now.nanoseconds, std.time.ns_per_ms));
+    if (conn.ssl) |ssl| conn.process_tls_data(ssl, conn.read_buffer[0..length]) else conn.route_decrypted_data(conn.read_buffer[0..length]);
+    conn.touch_activity();
+    if (conn.closing or conn.close_when_drained or conn.dispatch_suspended) return .disarm;
+    const capacity = tcp_upload.read_capacity(conn);
+    if (capacity == 0) return .disarm;
+    core_loop.retarget_completed_receive(completion, conn.read_buffer[0..capacity]) catch return .disarm;
+    conn.read_active = true;
+    action = .rearm;
+    return action;
+}
+
+fn on_write_complete(user_data: ?*TcpConnection, loop: *xev.Loop, completion: *xev.Completion, socket: xev.TCP, buffer: xev.WriteBuffer, result: xev.WriteError!usize) xev.CallbackAction {
+    const conn = user_data.?;
+    const owner = checked_upload_owner(conn) orelse
+        return on_write_complete_inner(user_data, loop, completion, socket, buffer, result);
+    owner.write_callback_active = true;
+    _ = on_write_complete_inner(user_data, loop, completion, socket, buffer, result);
+    request_upload_retirement(conn, false);
+    owner.write_callback_active = false;
+    upload_tail(conn);
+    return .disarm;
+}
+
+fn request_upload_retirement(conn: *TcpConnection, comptime read: bool) void {
+    const owner = conn.upload_owner.?;
+    const phase = if (read) &owner.read_retirement else &owner.write_retirement;
+    if (!upload_storage.request_retirement(phase)) return;
+    arm_upload_retirement(conn, read);
+}
+
+fn arm_upload_retirement(conn: *TcpConnection, comptime read: bool) void {
+    const owner = conn.upload_owner.?;
+    const completion = if (read) &owner.read_retirement_completion else &owner.write_retirement_completion;
+    owner.retirement_timer.run(owner.loop_handle.?.raw(), completion, 0, TcpConnection, conn, if (read) on_read_retired else on_write_retired);
+}
+
+fn on_read_retired(context: ?*TcpConnection, _: *xev.Loop, _: *xev.Completion, result: xev.Timer.RunError!void) xev.CallbackAction {
+    expire_upload_retirement(context.?, true, result);
+    return .disarm;
+}
+
+fn on_write_retired(context: ?*TcpConnection, _: *xev.Loop, _: *xev.Completion, result: xev.Timer.RunError!void) xev.CallbackAction {
+    expire_upload_retirement(context.?, false, result);
+    return .disarm;
+}
+
+fn expire_upload_retirement(conn: *TcpConnection, comptime read: bool, result: xev.Timer.RunError!void) void {
+    const owner = conn.upload_owner.?;
+    const handle = owner.loop_handle.?;
+    result catch |err| handle.fail_callback(.{ .retirement = err });
+    const phase = if (read) &owner.read_retirement else &owner.write_retirement;
+    const expiry = upload_storage.expire_retirement(phase) catch |err| switch (err) {
+        error.RetirementInactive => handle.fail_callback(.retirement_inactive),
+    };
+    if (expiry == .arm_second) {
+        arm_upload_retirement(conn, read);
+        return;
+    }
+    upload_tail(conn);
+}
+
+fn upload_cancel_ack(conn: *TcpConnection, comptime read: bool, result: xev.CancelError!void) void {
+    const owner = conn.upload_owner.?;
+    const outcome = owner.loop_handle.?.cancel_ack(result);
+    if (outcome == .abandon_target) {
+        if (read) conn.read_active = false else conn.is_writing = false;
+    }
+    request_upload_retirement(conn, read);
+    if (read) conn.read_cancel_active = false else conn.write_cancel_active = false;
+    upload_tail(conn);
+}
+
+fn close_upload_connection(conn: *TcpConnection, owner: *upload_storage.Http1UploadStorage) void {
+    if (conn.closing) return;
+    const handle = owner.loop_handle;
+    const owned = tcp_upload.borrow(owner);
+    const cancel_read = conn.read_active;
+    const cancel_write = conn.is_writing;
+    conn.closing = true;
+    owner.close_pending = true;
+    conn.read_cancel_active = cancel_read;
+    conn.write_cancel_active = cancel_write;
+    _ = conn.abort_controller.abort(.connection_closed);
+    tcp_upload.cancel(conn, .cancelled);
+    conn.close_when_drained = false;
+    conn.clear_stream();
+    conn.cancel_timers();
+    conn.async_response_state.cancel();
+    for (&conn.h2_async_states) |*state| state.cancel();
+    for (0..max_http2_streams) |index| conn.clear_http2_producer(@intCast(index));
+    if (conn.ws.initialized) conn.ws.deinit();
+    conn.release_file_body();
+    if (cancel_read or cancel_write) {
+        // The guarded handle terminates a failed submission before cancellation.
+        handle.?.submit() catch |err| std.debug.panic("guarded close submission failed: {}", .{err});
+    }
+    if (cancel_read) core_loop.cancel(conn.loop, &conn.read_completion, &conn.read_cancel_completion, TcpConnection, conn, on_read_cancel_complete);
+    if (cancel_write) core_loop.cancel(conn.loop, &conn.write_completion, &conn.write_cancel_completion, TcpConnection, conn, on_write_cancel_complete);
+    tcp_upload.finish_borrow(conn, owned);
+}
+
+/// Final enabled-owner continuation; no caller may touch conn after this tail.
+pub fn upload_tail(conn: *TcpConnection) void {
+    const owner = conn.upload_owner.?;
+    if (conn.closing) {
+        if (upload_storage.claim_close(owner, .{
+            .closing = conn.closing,
+            .close_complete = conn.close_complete,
+            .read_active = conn.read_active,
+            .is_writing = conn.is_writing,
+            .read_cancel_active = conn.read_cancel_active,
+            .write_cancel_active = conn.write_cancel_active,
+        })) {
+            const owned = tcp_upload.borrow(owner);
+            conn.deinit_tls();
+            if (owned) owner.delivery_active = false;
+            close_upload_socket(conn);
+            return;
+        }
+        release_closed_connection(conn);
+        return;
+    }
+    if (owner.delivery_active or owner.read_callback_active or owner.write_callback_active) return;
+    if (conn.pending_request_consumed != 0 and conn.dispatch_suspended and
+        conn.stream_producer == null and !conn.async_response_state.is_pending() and upload_storage.is_drained(owner))
+    {
+        conn.resume_async_dispatch();
+        return;
+    }
+    owner.read_resume_pending = false;
+    owner.write_resume_pending = false;
+    conn.start_write();
+    conn.arm_read();
+}
+
+fn close_upload_socket(conn: *TcpConnection) void {
+    if (builtin.os.tag == .windows) {
+        close_socket(xev.tcp_fd(conn.socket));
+        conn.close_complete = true;
+        release_closed_connection(conn);
+        return;
+    }
+    conn.socket.close(conn.loop, &conn.close_completion, TcpConnection, conn, on_upload_close_complete);
+}
+
+fn on_upload_close_complete(context: ?*TcpConnection, _: *xev.Loop, _: *xev.Completion, _: xev.TCP, result: xev.CloseError!void) xev.CallbackAction {
+    const conn = context.?;
+    result catch |err| conn.upload_owner.?.loop_handle.?.fail_callback(.{ .close = err });
+    conn.close_complete = true;
+    release_closed_connection(conn);
+    return .disarm;
+}
--- a/src/core/tcp_upload.zig
+++ b/src/core/tcp_upload.zig
@@ -0,0 +1,387 @@
+const std = @import("std");
+const tcp = @import("tcp.zig");
+const storage = @import("http1_upload_storage.zig");
+const upload = @import("http1_upload.zig");
+const parser = @import("../http/parser.zig");
+const decoder = @import("../http/body_decoder.zig");
+const body = @import("../http/request_body.zig");
+const radix = @import("../router/radix.zig");
+const StreamingRequest = @import("../http/streaming_request.zig").StreamingRequest;
+const Response = @import("../http/response.zig").Response;
+
+/// Nested callbacks inherit the caller's metadata lifetime instead of releasing it.
+pub fn borrow(owner: *storage.Http1UploadStorage) bool {
+    if (owner.delivery_active) return false;
+    owner.delivery_active = true;
+    return true;
+}
+
+/// The continuation may close and recycle conn; callers must return immediately.
+pub fn finish_borrow(conn: *tcp.TcpConnection, owned: bool) void {
+    if (!owned) return;
+    conn.upload_owner.?.delivery_active = false;
+    tcp.upload_tail(conn);
+}
+
+/// Plaintext receives fit the physical accumulator, independently of logical limits.
+pub fn read_capacity(conn: *const tcp.TcpConnection) usize {
+    if (conn.ssl != null or conn.protocol_state == .http2 or conn.protocol_state == .websocket)
+        return tcp.socket_read_capacity;
+    if (conn.upload_owner) |owner| {
+        if (owner.head != null and owner.body.phase != .inactive and owner.body.readiness == .paused) return 0;
+    }
+    const probe = if (conn.protocol_state == .detect) conn.protocol_probe_len else 0;
+    return @min(tcp.socket_read_capacity, conn.request_buffer.len - conn.request_len -| probe);
+}
+
+/// Resolves one H0 checkpoint; false commits the caller to legacy body collection.
+pub fn admit(conn: *tcp.TcpConnection, result: parser.HeadResult) bool {
+    const owner = conn.upload_owner.?;
+    const target = owner.head_target orelse {
+        _ = parser.commit_head(&conn.parser, &conn.req, result);
+        return false;
+    };
+    const head = result.ready orelse {
+        _ = parser.commit_head(&conn.parser, &conn.req, result);
+        return false;
+    };
+    const owned = borrow(owner);
+    var response = Response{ .target = .{ .tcp = conn }, .request_body_complete = false };
+    const method = radix.HttpMethod.parse(conn.req.method);
+    const bounds = upload.ingress_bounds(conn.request_buffer.len, head.header_end, head.framing, conn.parser.max_header_bytes);
+    const input = upload.HeadInput{
+        .request = &conn.req,
+        .head = head,
+        .method = method,
+        .headers = .{ .names = conn.parser.extra_header_names[0..conn.parser.extra_header_count], .values = conn.parser.extra_header_values[0..conn.parser.extra_header_count] },
+        .captures = .{ .names = conn.route_param_names, .values = conn.route_param_values },
+        .ingress = bounds,
+        .pending_header_capacity = owner.pending_headers.len,
+        .early_data_forbidden = conn.early_data_forbids(method),
+    };
+    owner.callback_phase = .admission;
+    const decision = target.resolve(target.context, &input, &response);
+    owner.callback_phase = .none;
+    std.debug.assert(response.pending_header_length <= owner.pending_headers.len);
+    @memcpy(owner.pending_headers[0..response.pending_header_length], response.pending_headers[0..response.pending_header_length]);
+    owner.pending_header_length = response.pending_header_length;
+    if (conn.closing or conn.close_when_drained) {
+        finish_borrow(conn, owned);
+        return true;
+    }
+    if (decision != .buffered) {
+        if (conn.metrics) |registry| registry.add(.http_requests, 1);
+    }
+    switch (decision) {
+        .buffered => {
+            _ = parser.commit_head(&conn.parser, &conn.req, result);
+            finish_borrow(conn, owned);
+            return false;
+        },
+        .final => {
+            conn.finish_sync_dispatch(&response);
+            tcp.close_after_flush(conn);
+        },
+        .reject => |reason| refuse(conn, &response, reason),
+        .stream => |selected| {
+            owner.head = head;
+            owner.route_definition = selected.definition;
+            owner.route_record_index = selected.record_index;
+            owner.ingress_write_offset = conn.request_len - head.header_end;
+            owner.ingress_read_offset = 0;
+            conn.suppress_response_body = method == .head;
+            start(conn, selected, bounds, &response);
+        },
+    }
+    finish_borrow(conn, owned);
+    return true;
+}
+
+fn refuse(conn: *tcp.TcpConnection, response: *Response, reason: upload.AdmissionRefusal) void {
+    const status: []const u8 = switch (reason) {
+        .too_early => "425 Too Early",
+        .invalid_query => "400 Bad Request",
+        .body_too_large => "413 Payload Too Large",
+        .unavailable => "503 Service Unavailable",
+    };
+    response.end_with_headers(status, "Connection: close\r\n", "") catch {
+        tcp.close_connection(conn);
+        return;
+    };
+    tcp.close_after_flush(conn);
+}
+
+fn start(conn: *tcp.TcpConnection, selected: radix.BodyMatch, bounds: ?upload.IngressBounds, response: *Response) void {
+    const owner = conn.upload_owner.?;
+    const ingress = bounds orelse {
+        refuse(conn, response, .unavailable);
+        return;
+    };
+    const declared: ?u64 = switch (owner.head.?.framing) {
+        .none => 0,
+        .content_length => |n| n,
+        .chunked => null,
+    };
+    const control = upload.reserve_and_arm(owner.head_target.?.router, selected, &owner.body, .{
+        .context = conn,
+        .resume_fn = resume_delivery,
+        .cancel_fn = cancel_delivery,
+    }, declared) catch |err| {
+        switch (err) {
+            error.BodyAdmissionMissing => owner.loop_handle.?.fail_callback(.body_admission_missing),
+            error.BodyTooLarge => refuse(conn, response, .body_too_large),
+            error.InvalidBodyRoute, error.BodyMiddlewareIncompatible, error.BodyAdmissionFull, error.InvalidBodyLimits, error.BodyStateBusy, error.InvalidBodyState, error.InvalidBodyLength, error.InvalidBodyProgress, error.BodyNotReady, error.BodyNotComplete => refuse(conn, response, .unavailable),
+        }
+        return;
+    };
+    owner.decoder = decoder.init(owner.head.?.framing, .{
+        .max_body_bytes = selected.definition.limits.max_body_bytes,
+        .max_header_bytes = conn.parser.max_header_bytes,
+        .line_content_limit = ingress.line_content_limit,
+    });
+    const view = StreamingRequest.from_request(&conn.req);
+    owner.callback_phase = .begin;
+    const binding = selected.definition.sink.begin(selected.definition.sink.context, &view, control) catch {
+        owner.callback_phase = .none;
+        if (owner.body.reject_begin()) release_admission(owner);
+        tcp.close_connection(conn);
+        return;
+    };
+    owner.callback_phase = .none;
+    if (owner.body.accept_begin(binding)) |terminal| {
+        _ = finish_terminal(conn, terminal);
+        return;
+    }
+    if (conn.closing) {
+        cancel(conn, .cancelled);
+        return;
+    }
+    if (!send_continue(conn)) return;
+    _ = progress(conn);
+}
+
+fn send_continue(conn: *tcp.TcpConnection) bool {
+    if (conn.expect_continue_sent or conn.req.count_headers("Expect") == 0) return true;
+    const value = conn.req.get_unique_header("Expect");
+    if (value == null or !std.ascii.eqlIgnoreCase(std.mem.trim(u8, value.?, " \t"), "100-continue")) {
+        cancel(conn, .invalid_body);
+        var response = restored_response(conn);
+        response.end_with_headers("417 Expectation Failed", "Connection: close\r\n", "") catch {
+            tcp.close_connection(conn);
+            return false;
+        };
+        tcp.close_after_flush(conn);
+        return false;
+    }
+    conn.write_data("HTTP/1.1 100 Continue\r\n\r\n") catch {
+        cancel(conn, .source_failure);
+        tcp.close_connection(conn);
+        return false;
+    };
+    conn.expect_continue_sent = true;
+    return true;
+}
+
+/// Copies a bounded native plaintext window, then retries retained framing/payload.
+pub fn receive(conn: *tcp.TcpConnection, bytes: []const u8) void {
+    const owner = conn.upload_owner.?;
+    const owned = borrow(owner);
+    std.debug.assert(bytes.len <= conn.request_buffer.len - conn.request_len);
+    @memcpy(conn.request_buffer[conn.request_len..][0..bytes.len], bytes);
+    conn.request_len += bytes.len;
+    owner.ingress_write_offset += bytes.len;
+    _ = progress(conn);
+    conn.touch_activity();
+    finish_borrow(conn, owned);
+}
+
+/// Requires a delivery borrow spanning every sink and terminal callback.
+fn progress(conn: *tcp.TcpConnection) bool {
+    const owner = conn.upload_owner.?;
+    std.debug.assert(owner.delivery_active);
+    while (!conn.closing and owner.body.phase == .active and owner.body.readiness == .ready) {
+        const head_end = owner.head.?.header_end;
+        const input = conn.request_buffer[head_end..][0..owner.ingress_write_offset];
+        if (owner.pending_payload != 0) {
+            if (!deliver_chunk(conn, input[owner.decoder.mark..][0..owner.pending_payload])) return false;
+            continue;
+        }
+        switch (decoder.next(&owner.decoder, input)) {
+            .data => |bytes| {
+                owner.body.observe(bytes.len) catch {
+                    fail(conn, .body_too_large);
+                    return false;
+                };
+                owner.pending_payload = bytes.len;
+                if (!deliver_chunk(conn, bytes)) return false;
+            },
+            .need_more => {
+                reclaim(conn);
+                return true;
+            },
+            .end => {
+                const terminal = owner.body.take_end(true, owner.pending_payload) catch {
+                    fail(conn, .invalid_body);
+                    return false;
+                };
+                conn.dispatch_suspended = true;
+                conn.pending_request_consumed = head_end + owner.decoder.mark;
+                conn.pending_close_requested = conn.req.header_has_token("Connection", "close");
+                return finish_terminal(conn, terminal);
+            },
+            .invalid => {
+                fail(conn, .invalid_body);
+                return false;
+            },
+            .too_large => {
+                fail(conn, .body_too_large);
+                return false;
+            },
+        }
+    }
+    if (conn.closing and owner.body.phase == .active) cancel(conn, .cancelled);
+    return !conn.closing;
+}
+
+fn deliver_chunk(conn: *tcp.TcpConnection, bytes: []const u8) bool {
+    const owner = conn.upload_owner.?;
+    owner.body.start_chunk(bytes.len) catch {
+        fail(conn, .sink_failure);
+        return false;
+    };
+    owner.callback_phase = .chunk;
+    const accepted = owner.route_definition.?.sink.chunk(owner.body.binding.?.context, bytes) catch {
+        owner.callback_phase = .none;
+        _ = finish_terminal(conn, owner.body.fail_chunk());
+        tcp.close_connection(conn);
+        return false;
+    };
+    owner.callback_phase = .none;
+    const terminal = owner.body.accept_chunk(accepted) catch {
+        _ = finish_terminal(conn, owner.body.fail_chunk());
+        tcp.close_connection(conn);
+        return false;
+    };
+    decoder.accept_payload(&owner.decoder, accepted.consumed) catch {
+        // Shared progress already validated this exact decoder offer.
+        fail(conn, .invalid_body);
+        return false;
+    };
+    owner.pending_payload -= accepted.consumed;
+    owner.ingress_read_offset = owner.decoder.mark;
+    if (terminal) |action| return finish_terminal(conn, action);
+    return true;
+}
+
+fn reclaim(conn: *tcp.TcpConnection) void {
+    const owner = conn.upload_owner.?;
+    const consumed = owner.decoder.mark;
+    if (consumed == 0) return;
+    const start_offset = owner.head.?.header_end;
+    const remaining = owner.ingress_write_offset - consumed;
+    std.mem.copyForwards(u8, conn.request_buffer[start_offset..][0..remaining], conn.request_buffer[start_offset + consumed ..][0..remaining]);
+    decoder.discard_prefix(&owner.decoder, consumed) catch {
+        // consumed is exactly the decoder's current mark.
+        fail(conn, .invalid_body);
+        return;
+    };
+    owner.ingress_read_offset = 0;
+    owner.ingress_write_offset = remaining;
+    conn.request_len = start_offset + remaining;
+}
+
+fn restored_response(conn: *tcp.TcpConnection) Response {
+    const owner = conn.upload_owner.?;
+    var response = Response{ .target = .{ .tcp = conn } };
+    @memcpy(response.pending_headers[0..owner.pending_header_length], owner.pending_headers[0..owner.pending_header_length]);
+    response.pending_header_length = owner.pending_header_length;
+    return response;
+}
+
+fn finish_terminal(conn: *tcp.TcpConnection, terminal: body.BodyTerminal) bool {
+    const owner = conn.upload_owner.?;
+    const sink = owner.route_definition.?.sink;
+    var successful = true;
+    switch (terminal) {
+        .cancel => |action| {
+            owner.callback_phase = .cancel;
+            sink.cancel(action.binding.context, action.reason);
+        },
+        .end => |binding| {
+            owner.callback_phase = .end;
+            const view = StreamingRequest.from_request(&conn.req);
+            var response = restored_response(conn);
+            sink.end(binding.context, &view, &response) catch {
+                successful = false;
+            };
+            if (successful and !conn.closing) conn.finish_sync_dispatch(&response);
+        },
+    }
+    owner.callback_phase = .none;
+    if (owner.body.finish_terminal()) release_admission(owner);
+    if (!successful) tcp.close_connection(conn);
+    return successful and !conn.closing;
+}
+
+fn release_admission(owner: *storage.Http1UploadStorage) void {
+    owner.head_target.?.router.release_body_route(owner.route_record_index) catch |err| switch (err) {
+        error.BodyAdmissionMissing => owner.loop_handle.?.fail_callback(.body_admission_missing),
+    };
+}
+
+/// Close initiation can defer notification until an existing begin/chunk unwinds.
+pub fn cancel(conn: *tcp.TcpConnection, reason: body.BodyCancelReason) void {
+    const owner = conn.upload_owner.?;
+    const owned = borrow(owner);
+    if (owner.body.request_cancel(reason)) |terminal| _ = finish_terminal(conn, terminal);
+    finish_borrow(conn, owned);
+}
+
+fn fail(conn: *tcp.TcpConnection, reason: body.BodyCancelReason) void {
+    cancel(conn, reason);
+    if (conn.closing) return;
+    if (reason != .invalid_body and reason != .body_too_large) {
+        tcp.close_connection(conn);
+        return;
+    }
+    var response = restored_response(conn);
+    const status: []const u8 = if (reason == .body_too_large) "413 Payload Too Large" else "400 Bad Request";
+    response.end_with_headers(status, "Connection: close\r\n", "") catch {
+        tcp.close_connection(conn);
+        return;
+    };
+    tcp.close_after_flush(conn);
+}
+
+fn resume_delivery(context: *anyopaque) error{BodyDeliveryFailed}!void {
+    const conn: *tcp.TcpConnection = @ptrCast(@alignCast(context));
+    const owner = conn.upload_owner.?;
+    const owned = borrow(owner);
+    const successful = if (conn.closing) blk: {
+        cancel(conn, .cancelled);
+        break :blk false;
+    } else progress(conn);
+    conn.touch_activity();
+    finish_borrow(conn, owned);
+    if (!successful) return error.BodyDeliveryFailed;
+}
+
+/// Preserves the first cancellation reason across closing publication and cleanup.
+/// May release conn at the final tail; callers must not access it afterward.
+pub fn close(conn: *tcp.TcpConnection, reason: body.BodyCancelReason) void {
+    const owner = conn.upload_owner orelse {
+        tcp.close_connection(conn);
+        return;
+    };
+    const owned = borrow(owner);
+    // Claim terminal ownership before abort/submit callbacks can choose a cause.
+    const terminal = owner.body.request_cancel(reason);
+    tcp.close_connection(conn);
+    if (terminal) |action| _ = finish_terminal(conn, action);
+    finish_borrow(conn, owned);
+}
+
+fn cancel_delivery(context: *anyopaque) void {
+    const conn: *tcp.TcpConnection = @ptrCast(@alignCast(context));
+    close(conn, .cancelled);
+}
--- a/src/test_support.zig
+++ b/src/test_support.zig
@@ -1,3 +1,4 @@
+pub const tcp_upload = @import("core/tcp_upload.zig");
 pub const http1_upload_storage = @import("core/http1_upload_storage.zig");
 pub const http1_upload = @import("core/http1_upload.zig");
 pub const fuzz_http_body = @import("fuzz/http_body.zig");
--- a/src/tests/http1_upload_driver_tests.zig
+++ b/src/tests/http1_upload_driver_tests.zig
@@ -0,0 +1,318 @@
+const std = @import("std");
+const support = @import("test_support");
+const driver = support.tcp_upload;
+const body = support.request_body;
+const radix = support.radix;
+const RouterBundle = radix.Bundle(.{ .stream_request_bodies = true });
+const View = support.streaming_request.StreamingRequest;
+const Response = support.http_response.Response;
+
+const Fixture = struct {
+    bundle: RouterBundle = .{},
+    router: radix.Router = .{},
+    definition: body.BodyRoute = undefined,
+    owner: support.http1_upload_storage.Http1UploadStorage = .{ .retirement_timer = undefined, .initialized = true },
+    conn: support.tcp.TcpConnection = .{ .socket = undefined },
+    input: [512]u8 = undefined,
+    output: [2048]u8 = undefined,
+    received: [2048]u8 = undefined,
+    received_len: usize = 0,
+    begins: usize = 0,
+    ends: usize = 0,
+    cancels: usize = 0,
+    fail_begin: bool = false,
+    fail_chunk: bool = false,
+    fail_end: bool = false,
+    invalid_progress: bool = false,
+    close_begin: bool = false,
+    close_chunk: bool = false,
+    reason: ?body.BodyCancelReason = null,
+    overflow_seen: bool = false,
+    cancel_saw_closing: bool = false,
+    pause_begin: bool = false,
+    pause_chunk: bool = false,
+    prefix: usize = 32,
+    control: ?body.BodyControl = null,
+
+    fn init(self: *Fixture) !void {
+        self.router = try radix.Router.init(self.bundle.storage());
+        self.definition = .{
+            .sink = .{ .context = self, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel_sink },
+            .limits = .{ .max_body_bytes = 10000, .max_active = 1 },
+        };
+        try self.router.route_body(.post, "/upload", &self.definition);
+        self.owner.head_target = .{ .context = self, .router = &self.router, .resolve = resolve };
+        self.conn.router = &self.router;
+        self.conn.upload_owner = &self.owner;
+        self.conn.request_buffer = &self.input;
+        self.conn.write_queue = &self.output;
+        self.conn.protocol_state = .http;
+        // This caller-owned operation spans all actual sink calls, without native I/O.
+        try std.testing.expect(driver.borrow(&self.owner));
+        self.conn.begin_write_batch();
+    }
+
+    fn resolve(context: *anyopaque, input: *const support.http1_upload.HeadInput, response: *Response) support.http1_upload.HeadDecision {
+        const self: *Fixture = @ptrCast(@alignCast(context));
+        if (input.head.headers.get("X-Overflow")) |value| {
+            self.overflow_seen = std.mem.eql(u8, value, "present") and input.headers.names.len == 1;
+        }
+        input.request.extra_header_names = input.headers.names;
+        input.request.extra_header_values = input.headers.values;
+        input.request.extra_header_count = input.headers.names.len;
+        response.append_header("X-Saved", "yes") catch return .{ .reject = .unavailable };
+        return .{ .stream = self.router.match(input.request.path, input.method).?.body_match.? };
+    }
+
+    fn feed_head(self: *Fixture, wire: []const u8) !void {
+        @memcpy(self.conn.request_buffer[0..wire.len], wire);
+        self.conn.request_len = wire.len;
+        const result = support.http_parser.consume_head(&self.conn.parser, &self.conn.req, self.conn.request_buffer[0..wire.len]);
+        try std.testing.expect(result.ready != null);
+        try std.testing.expect(driver.admit(&self.conn, result));
+    }
+
+    fn begin(context: *anyopaque, request: *const View, control: body.BodyControl) !body.BodyBinding {
+        const self: *Fixture = @ptrCast(@alignCast(context));
+        try std.testing.expectEqualStrings("/upload", request.path);
+        try std.testing.expectError(error.BodyCallbackActive, control.cancel());
+        self.begins += 1;
+        self.control = control;
+        if (self.close_begin) support.tcp.close_connection(&self.conn);
+        if (self.fail_begin) return error.BeginFailed;
+        return .{ .context = self, .readiness = if (self.pause_begin) .paused else .ready };
+    }
+
+    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
+        const self: *Fixture = @ptrCast(@alignCast(context));
+        try std.testing.expectError(error.BodyCallbackActive, self.control.?.@"resume"());
+        if (self.close_chunk) support.tcp.close_connection(&self.conn);
+        if (self.fail_chunk) return error.ChunkFailed;
+        if (self.invalid_progress) return .{ .consumed = bytes.len + 1, .readiness = .ready };
+        const count = @min(bytes.len, self.prefix);
+        @memcpy(self.received[self.received_len..][0..count], bytes[0..count]);
+        self.received_len += count;
+        return .{ .consumed = count, .readiness = if (self.pause_chunk or count < bytes.len) .paused else .ready };
+    }
+
+    fn end(context: *anyopaque, request: *const View, response: *Response) !void {
+        const self: *Fixture = @ptrCast(@alignCast(context));
+        try std.testing.expectEqualStrings("/upload", request.path);
+        try std.testing.expectError(error.BodyControlExpired, self.control.?.cancel());
+        self.ends += 1;
+        if (self.fail_end) return error.EndFailed;
+        try response.end("200 OK", "done");
+    }
+
+    fn cancel_sink(context: *anyopaque, reason: body.BodyCancelReason) void {
+        const self: *Fixture = @ptrCast(@alignCast(context));
+        self.cancels += 1;
+        self.reason = reason;
+        self.cancel_saw_closing = self.conn.closing;
+    }
+};
+
+test "H1 driver: before admission plaintext window respects retained capacity" {
+    var bytes: [7]u8 = undefined;
+    var conn = support.tcp.TcpConnection{ .socket = undefined, .request_buffer = &bytes, .request_len = 5 };
+    try std.testing.expectEqual(@as(usize, 2), driver.read_capacity(&conn));
+}
+
+test "H1 driver: partial prefix resumes once and preserves response metadata and pipeline" {
+    var fixture = Fixture{ .prefix = 2 };
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 4\r\n\r\nabcdNEXT");
+    try std.testing.expectEqual(@as(u64, 4), fixture.owner.body.observed);
+    try std.testing.expectEqual(@as(usize, 2), fixture.owner.pending_payload);
+    try std.testing.expectEqual(@as(usize, 0), driver.read_capacity(&fixture.conn));
+    try fixture.control.?.@"resume"();
+    try std.testing.expectEqualStrings("abcd", fixture.received[0..fixture.received_len]);
+    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
+    try std.testing.expectEqual(@as(usize, 0), fixture.cancels);
+    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
+    try std.testing.expect(fixture.owner.head != null);
+    try std.testing.expect(fixture.owner.delivery_active);
+    try std.testing.expectEqualStrings("NEXT", fixture.input[fixture.conn.pending_request_consumed..fixture.conn.request_len]);
+    try std.testing.expect(std.mem.indexOf(u8, fixture.output[0..fixture.conn.write_len], "X-Saved: yes\r\n") != null);
+}
+
+test "H1 driver: final byte pause delays terminal until explicit resume" {
+    var fixture = Fixture{ .pause_chunk = true };
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\n\r\nx");
+    try std.testing.expectEqual(@as(usize, 0), fixture.ends);
+    try std.testing.expectEqual(@as(usize, 0), fixture.owner.pending_payload);
+    try fixture.control.?.@"resume"();
+    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
+    try std.testing.expectError(error.BodyControlExpired, fixture.control.?.@"resume"());
+}
+
+test "H1 driver: paused begin sends Continue before content and cancel releases once" {
+    var fixture = Fixture{ .pause_begin = true };
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 4\r\nExpect: 100-continue\r\n\r\n");
+    try std.testing.expect(fixture.conn.expect_continue_sent);
+    try std.testing.expectEqualStrings("HTTP/1.1 100 Continue\r\n\r\n", fixture.output[0..fixture.conn.write_len]);
+    try fixture.control.?.cancel();
+    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
+    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
+    try std.testing.expectError(error.BodyControlExpired, fixture.control.?.cancel());
+}
+
+test "H1 driver: body larger than ingress reclaims only consumed tail" {
+    var fixture = Fixture{ .prefix = 2048 };
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 600\r\n\r\n");
+    const head_end = fixture.owner.head.?.header_end;
+    const first = [_]u8{'a'} ** 300;
+    const second = [_]u8{'b'} ** 300;
+    driver.receive(&fixture.conn, &first);
+    try std.testing.expectEqual(head_end, fixture.conn.request_len);
+    try std.testing.expectEqualStrings("/upload", fixture.conn.req.path);
+    driver.receive(&fixture.conn, &second);
+    try std.testing.expectEqual(@as(u64, 600), fixture.owner.body.observed);
+    try std.testing.expectEqualSlices(u8, &first, fixture.received[0..300]);
+    try std.testing.expectEqualSlices(u8, &second, fixture.received[300..600]);
+    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
+}
+
+test "H1 driver: chunk framing extensions trailers and following bytes survive split input" {
+    var fixture = Fixture{};
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nTransfer-Encoding: chunked\r\n\r\n2;foo=bar\r\na");
+    driver.receive(&fixture.conn, "b\r\n0\r\nX-Discard: yes\r");
+    try std.testing.expectEqual(@as(usize, 0), fixture.ends);
+    driver.receive(&fixture.conn, "\n\r\nNEXT");
+    try std.testing.expectEqualStrings("ab", fixture.received[0..fixture.received_len]);
+    try std.testing.expect(fixture.conn.req.get_header("X-Discard") == null);
+    try std.testing.expectEqualStrings("NEXT", fixture.input[fixture.conn.pending_request_consumed..fixture.conn.request_len]);
+    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
+}
+
+test "H1 driver: failed begin releases admission without cancel" {
+    var fixture = Fixture{ .fail_begin = true };
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 0\r\n\r\n");
+    try std.testing.expectEqual(@as(usize, 1), fixture.begins);
+    try std.testing.expectEqual(@as(usize, 0), fixture.ends + fixture.cancels);
+    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
+    try std.testing.expect(fixture.conn.closing);
+}
+
+test "H1 driver: close during successful begin cancels returned binding after unwind" {
+    var fixture = Fixture{ .close_begin = true };
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 0\r\n\r\n");
+    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
+    try std.testing.expectEqual(@as(usize, 0), fixture.ends);
+    try std.testing.expectEqual(body.BodyPhase.inactive, fixture.owner.body.phase);
+    try std.testing.expect(fixture.owner.delivery_active);
+}
+
+test "H1 driver: chunk failure and invalid progress each cancel exactly once" {
+    for ([_]bool{ false, true }) |invalid| {
+        var fixture = Fixture{ .fail_chunk = !invalid, .invalid_progress = invalid };
+        try fixture.init();
+        try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\n\r\nx");
+        try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
+        try std.testing.expectEqual(@as(?body.BodyCancelReason, .sink_failure), fixture.reason);
+        try std.testing.expectEqual(@as(usize, 0), fixture.ends);
+        try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
+    }
+}
+
+test "H1 driver: resumed end error completes terminal ownership without cancel" {
+    var fixture = Fixture{ .pause_chunk = true, .fail_end = true };
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\n\r\nx");
+    try std.testing.expectError(error.BodyDeliveryFailed, fixture.control.?.@"resume"());
+    try std.testing.expectEqual(@as(usize, 1), fixture.ends);
+    try std.testing.expectEqual(@as(usize, 0), fixture.cancels);
+    try std.testing.expectEqual(body.BodyPhase.inactive, fixture.owner.body.phase);
+    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
+}
+
+test "H1 driver: malformed trailer cancels and queues bounded final rejection" {
+    var fixture = Fixture{};
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nTransfer-Encoding: chunked\r\n\r\n0\r\nHost: forbidden\r\n\r\n");
+    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
+    try std.testing.expectEqual(@as(?body.BodyCancelReason, .invalid_body), fixture.reason);
+    try std.testing.expect(std.mem.indexOf(u8, fixture.output[0..fixture.conn.write_len], "400 Bad Request") != null);
+    try std.testing.expectEqual(@as(usize, 0), fixture.ends);
+}
+
+test "H1 driver: close during chunk preserves observed and accepted prefix accounting" {
+    var fixture = Fixture{ .close_chunk = true };
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\n\r\nx");
+    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
+    try std.testing.expectEqual(@as(u64, 1), fixture.owner.body.consumed);
+    try std.testing.expectEqual(@as(usize, 0), fixture.owner.pending_payload);
+    try std.testing.expectEqual(@as(usize, 0), fixture.ends);
+}
+
+test "H1 driver: resolver receives complete head and used overflow views" {
+    var fixture = Fixture{ .pause_begin = true };
+    try fixture.init();
+    var input: [2048]u8 = undefined;
+    var names: [3][]const u8 = undefined;
+    var values: [3][]const u8 = undefined;
+    fixture.conn.request_buffer = &input;
+    fixture.conn.parser.extra_header_names = &names;
+    fixture.conn.parser.extra_header_values = &values;
+    const wire = "POST /upload HTTP/1.1\r\nHost: x\r\n" ++ "X-Fill: a\r\n" ** 63 ++ "X-Overflow: present\r\n\r\n";
+    try fixture.feed_head(wire);
+    try std.testing.expect(fixture.overflow_seen);
+    try std.testing.expectEqualStrings("present", fixture.conn.req.get_header("X-Overflow").?);
+    try fixture.control.?.cancel();
+}
+
+test "H1 driver: response completion cannot compact under inherited metadata borrow" {
+    var fixture = Fixture{};
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 0\r\n\r\nNEXT");
+    const consumed = fixture.conn.pending_request_consumed;
+    const length = fixture.conn.request_len;
+    fixture.conn.resume_async_dispatch();
+    try std.testing.expectEqual(consumed, fixture.conn.pending_request_consumed);
+    try std.testing.expectEqual(length, fixture.conn.request_len);
+    try std.testing.expectEqualStrings("/upload", fixture.conn.req.path);
+    try std.testing.expect(fixture.conn.dispatch_suspended);
+}
+
+test "H1 driver: owner EOF cancellation delivers original reason once" {
+    var fixture = Fixture{ .pause_begin = true };
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 4\r\n\r\na");
+    driver.cancel(&fixture.conn, .peer_closed);
+    driver.cancel(&fixture.conn, .reset);
+    try std.testing.expectEqual(@as(?body.BodyCancelReason, .peer_closed), fixture.reason);
+    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
+    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
+}
+
+test "H1 driver: logical chunk limit rejects before payload acceptance" {
+    var fixture = Fixture{};
+    try fixture.init();
+    fixture.definition.limits.max_body_bytes = 1;
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nab\r\n0\r\n\r\n");
+    try std.testing.expectEqual(@as(usize, 0), fixture.received_len);
+    try std.testing.expectEqual(@as(?body.BodyCancelReason, .body_too_large), fixture.reason);
+    try std.testing.expect(std.mem.indexOf(u8, fixture.output[0..fixture.conn.write_len], "413 Payload Too Large") != null);
+    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
+}
+
+test "H1 driver: reasoned close publishes closing before terminal and retains first cause" {
+    var fixture = Fixture{ .pause_begin = true };
+    try fixture.init();
+    try fixture.feed_head("POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\n\r\n");
+    driver.close(&fixture.conn, .timeout);
+    driver.close(&fixture.conn, .shutdown);
+    try std.testing.expect(fixture.cancel_saw_closing);
+    try std.testing.expectEqual(@as(?body.BodyCancelReason, .timeout), fixture.reason);
+    try std.testing.expectEqual(@as(usize, 1), fixture.cancels);
+    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[fixture.owner.route_record_index]);
+    try std.testing.expect(fixture.owner.close_pending);
+    try std.testing.expect(fixture.owner.delivery_active);
+}
