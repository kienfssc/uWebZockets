# Task 3b paused source preparation and v1 failure diagnosis

Status: PAUSED at Root's request for a decision on the two actual v1 failures.
Only NEW `.uwz-work/evidence/h1-plaintext/integration-v2/` fixtures/records and
this report were edited. V1 profile/probe/compile hashes match their captured
preimages. No v2 compile, server/client execution, port precheck/contact, source
cleanup, native experiment, subagent or commit occurred.

The earlier Task3a report overstated its case count: `run_cases` contains **20**,
not 21. Its existing report remains immutable. AST inspection confirms 20 in v1
and the current copied v2 client. Root's actual retained v1 results contain 20
cases, 18 passed and 2 failed; this worker did not execute that run. The copied
small failure details, source result hash, unchanged v1 identities and v2 WIP
identities are retained in `integration-v2/pause-diagnosis.json`.

## Required decision: failed_begin expectation

Actual retained error:

```text
EOFError('EOF before response header')
```

This is a harness expectation defect. ADR0008 lines 114-117 requires a failed
begin to roll back its partial ownership, release admission and receive no
cancel. It does not promise a final HTTP error response. In Root's coherent
`src/core/tcp_upload.zig:144-148`, the real begin error path clears callback
phase, calls `reject_begin`, releases admission when required, then closes the
connection. `send_continue` is reached only after successful begin.

V1 incorrectly calls `observe_refusal` for failed_begin and requires a framed
final response. The smallest correction is a dedicated ordinary failed-begin
case that records a pre-header EOF (or an actual framed error response if one
exists), asserts no100, no accepted binding, no end/cancel, exactly one failed
begin attempt, then succeeds on a new same-route request. The retry proves the
max_active1 reservation was released. Pre-header EOF must not be accepted for
any case whose spec explicitly promises an HTTP status. No production change
is indicated by this EOF alone.

## Required decision: chunked logical limit reset

Actual retained error:

```text
ConnectionResetError(104, 'Connection reset by peer')
```

This is currently insufficient evidence to decide whether the implementation
met its wire contract. ADR0008 lines 94-95 explicitly requires 413 for declared
or observed logical oversize, before accepting offending bytes. Root's coherent
`src/http/body_decoder.zig:145-161` rejects a chunk length 33 at limit32 during
size-line parsing, before returning its payload. `src/core/tcp_upload.zig:340-353`
then cancels with body_too_large, constructs 413 and calls close_after_flush.

V1 `chunked_limit` sends the entire rejected chunk, CRLF, zero chunk and trailers
before reading. `terminal_result` parses the final response and then performs
an extra EOF check; if that check raises reset, the caller loses the parsed
response because only the exception is retained. Reset could also have happened
earlier. The current record does not distinguish those points. Unread incoming
rejected content is a plausible reason for a later TCP reset; that is an
inference, not an established runtime finding.

The smallest proposed harness correction has two parts:

1. Preserve every complete interim/final head and completed framed response in
   the case record before the closure/surplus check; retain EOF/reset/send-stage
   details separately. Never count a reset without the required parsed413 as a
   pass, and never swallow a partial/malformed response.
2. Exercise the same limit32/announced chunk33 boundary by sending the chunk-size
   line and waiting for the required413, without sending rejected payload,
   terminator or trailers after the decoder has enough input to reject it.
   Record logical chunk declaration33 and actual content sent0 distinctly. This
   tests refusal before accepting offending bytes and preserves the threshold.

Keep the original overrun case as its own real result. Whether a fully received
413 followed by reset is acceptable for that separate overrun case needs Root's
explicit contract decision; no gate has been weakened and no v1 result has been
reclassified. If the minimal size-line case does not deliver413, route that
production defect to transport_io; this verification worker must not edit it.

## Bytecode write diagnosis and implemented v2-only correction

V1 imports the static helper with `exec_module` and did not disable Python bytecode
writes. Root reported an extra `__pycache__` file in the coherent source tree.
This does not by itself imply production-source mutation, but invalidates a
literal full-tree equality snapshot. Root owns its actual inventory/recovery.
This worker did not remove or alter that file or the coherent source.

V2 now sets `sys.dont_write_bytecode = True` BEFORE `spec.loader.exec_module`.
The harness itself is launched as a script, so its main source is not imported
into a cache. This was syntax checked only. Root may additionally launch it with
`PYTHONDONTWRITEBYTECODE=1`; that exact passed environment value should be
recorded if used.

## Preserved source preparation before Root paused additions

V2 began as independent copied v1 fixtures. Exact v1 preimages live in
`*.preimage` and `v1-fixture-preimages.json`. WIP server source introduces three
fixed caller-owned route binding slots/control tokens and separate fixed
server-lifetime outgoing producer storage. The producer uses public begin_stream,
write_chunk and end_chunks, with 8192-byte output chunks, checks retained initial
individual metadata slices on each real invocation, and records invocations
after the upload end callback returns. It does not use private driver callbacks,
fake output completion, a body-sized buffer or an invented abort callback.

This producer is grounded in `src/http/response.zig:56-72,576-600`: the callback
runs immediately and on drain, returns pending on write backpressure and done
after end_chunks. There is no abort callback. Its context therefore remains
allocated in server-lifetime fixed storage; no false early cleanup claim is made.
Actual final output completion would be proved by a future client reading the
full framed body and EOF, not merely by a producer returning done.

V2's compile replay now targets Root's supplied coherent path
`/tmp/uwz-m2-h1-plaintext-combined` and expected canonical digest
`acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b`, with independent
`/tmp/uwz-h1-profile-v2-preparation` outputs/caches and new evidence paths. It uses
original r2 bindings, the manifest-verified c223 override, existing native libs,
ReleaseSafe and -j2. It records fixture/source/module/library/compiler pre/post
hashes, raw status/log and binary identity; it rejects changed inputs. It has
NOT been invoked. The current extra pyc may cause its strict full-tree digest
check to fail; Root must supply the decision/clean coherent source, rather than
this worker removing files or excluding inputs silently.

The copied client still contains its original 20 cases, including both exact
100000000-byte uploads and real file pipeline/close checks. New producer,
simultaneous-success, peer-disconnect, owned shutdown-during-upload and end-error
client cases have NOT yet been added. The v2 profile is also not yet compile
verified. These are preserved WIP sources, not a ready runnable v2 bundle.

## Checks actually run

AST parsing only, through an inline Python script using `ast.parse` on both v2
Python files and inspecting `run_cases`' list node. No harness import/execution:

```text
AST syntax passed; run_cases entries: 20
V1 fixture hashes unchanged: True
```

The new profile passed Zig formatting (formatter command, not compilation):

```sh
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt .uwz-work/evidence/h1-plaintext/integration-v2/profile.zig
```

Raw formatter output was empty, exit status 0. Full local/project checks and all
v2 runtime cases remain unrun. Further implementation awaits Root's decision.
