# Task 3a source preparation report

Status: prepared and compiled, NOT run. No server/client was started, no port was
prechecked or contacted, and no upload, shutdown, allocation, performance or native
lifetime success is claimed. Root must supply the combined reviewed App/transport
source and explicitly start ordinary runtime verification.

Owned durable evidence: `.uwz-work/evidence/h1-plaintext/integration/` only, plus
this report. No production sources, developer copies, build graph, manifest,
package view, shared test root, refs or pins were modified. No agents were spawned.
No stopped probe was inspected or reconstructed. No cancellation schedule, fault,
race, invalid descriptor, kernel/resource failure, injected completion, panic,
crash or leak experiment was performed or prepared.

## Actual preparation evidence

Final server source: `profile.zig`; normal Python protocol/lifecycle client:
`probe.py`; explicit compile-only replay: `compile.py`. `preparation.json` retains
final fixture hashes, Python identity, source digest and no-runtime declaration.
The successful `compile-r3.json` retains exact argv/cwd, ReleaseSafe mode, compiler,
module, native-library and binary SHA256 values. `compile-r3-source-inputs.json`
retains all 1020 immutable source input identities. Its canonical digest is
`81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108`, verified in
`preparation.json`. Earlier r2/r3 compile record `source_tree_sha256` fields use
lexically sorted relative paths; canonical preparation uses the predecessor's
sorted pathlib traversal. These are different encodings of the same retained
1020 per-file hashes, not a source change. The current replay uses the canonical
encoding for future combined-source records.

Exact compile command executed from `/workspaces/uWebZockets`:

```sh
python3 .uwz-work/evidence/h1-plaintext/integration/compile.py --record compile-r3
```

Raw result: `Exit status: 0`. Compiler stdout/stderr in `compile-r3.log` is empty.
Binary and all compiler caches are under `/tmp/uwz-h1-profile-preparation`.
Compiler: `/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`, `-j2`.
The compile input uses only immutable source, original r2 C bindings, the explicit
c223 libxev override and existing `zig-out/lib` libraries. It fetches nothing.
The final profile SHA256 equals the successful r3 compile input hash.

The initial compile found a fixture initializer type error (`Metadata` versus an
untyped anonymous initializer). `compile.log`/`compile.json` retain exit status 1
and the diagnostic. It was corrected to an explicitly typed array; r2 and final
r3 each compiled with status 0. This is fixture compilation evidence, not a
production regression red/green claim.

Exact formatting command executed:

```sh
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check .uwz-work/evidence/h1-plaintext/integration/profile.zig
```

Raw result: no output, exit status 0.

Both final Python sources were parsed with `ast.parse`, without importing or
executing the harness. Raw result retained in `syntax.log`:

```text
Python syntax: passed (AST parse only; no harness execution)
zig fmt --check: exit status 0, raw output empty
```

Full project checks, sanitizer matrix, compliance runners, fuzzing, package
consumer and runtime have NOT run for these preparation fixtures. No whole
change verification claim is made.

## Public server fixture and ownership review

The server opts into `stream_request_bodies` through public `Server.preset` and
keeps default ingress/body/window capacities; it selects eight connection slots.
Its stack-owned `State` and one fixed sink binding slot survive logical request
cleanup for the entire event loop. Each route uses `max_active = 1`; the fixture
also deliberately refuses overlapping successful bindings across different
streaming routes because its total binding capacity is one. Concurrent different
route admission is therefore not covered by this profile.

`POST /upload/:tag` uses logical maximum 100000000; `/limit/:tag` uses 32 and
`/empty/:tag` uses 0. All use real borrowed `BodyRoute` definitions, public
`StreamingRequest` and `BodyControl`. A certified header-only middleware appends
`X-Middleware: retained`; the client checks its final preservation. Ordinary
`/health` and bounded buffered `/echo` coexist with streaming routes.

Begin retains six individual metadata byte slices (method, target, path, query,
capture, marker header), plus independent bounded 512-byte copies of each. It
never retains a request pointer or array-view pointer. End compares the fresh
view and all initial individual slices against those copies, then returns
bounded JSON `{bytes,sha256,metadata_ok}`. Chunk/end contain no allocator call;
SHA256 and accepted u64 byte accounting update only the returned accepted prefix.
This is source inspection, not allocator-instrumented proof.

Pause modes are begin, accepted prefix 7, and declared final logical byte. Only
ordinary same-loop `/status`, `/resume`, `/cancel` and `/stale` routes drive copied
real controls. Terminal calls copy the token before invoking it, and do not read
binding storage afterward. The independent State owns counters/control copies;
status distinguishes begin callback attempts, successful begin, intentional
failed-begin, end, cancel and latest cancellation reason. Stale control use is
ordinary public API validation, never a native callback experiment.

`GET /files/large.bin` uses public static delivery. Existing static delivery
selects real plaintext `send_file` and real descriptor ownership. The client
creates a non-sparse deterministic 16777313-byte fixture under its owned `/tmp`
directory in chunks at most 8192. It sends file->health together on one socket,
checks every file byte against an independently opened real file before parsing
the health response, and separately requests Connection:close and checks exact
file completion before EOF. File body storage/completion is never fabricated.
This is prepared coverage for the identified missing file_body owner-tail gate;
it has not yet demonstrated a fix.

## Prepared ordinary case matrix (all runtime pending)

| Case | Prepared assertions |
| --- | --- |
| fixed_exact100000000 | Exact decimal logical count, client/server SHA256, nonzero chunks and final sentinel, metadata, pending header, one end/no cancel, EOF, stale token |
| chunked_exact100000000 | Same exact count/hash; extensions, split framing writes, discarded trailer |
| empty / empty_chunked | Zero-length fixed/chunked success on max0 route |
| limit_exact32 / limit_chunked_exact32 | Exact max32 success |
| limit_chunked_over33 | Observed terminal response or clean pre-header EOF; no end, one body_too_large cancel |
| declared_limit_refusal | Expect refusal before sending content; no begin/binding/end/cancel |
| begin_expect100 | Separate interim100 parsing before content; HTTP-reported pause/resume |
| partial_prefix | Accepted prefix exactly7 before resume; retained suffix hashes once |
| final_byte_fixed / final_byte_chunked | Final accepted-byte pause, resume/end without another body byte |
| stream_stream_buffered_pipeline | Same socket fixed->chunked->buffered with exact response framing/hashes/echo/EOF |
| file_health_pipeline | Exact real file bytes before next response |
| file_close | Exact real file bytes before EOF |
| failed_begin | Intentional public begin error: attempt/refusal increments, no accepted binding/end/cancel; observed final status |
| sink_error / invalid_progress | Public callback error or oversized progress; one sink_failure cancel/no end; observed wire terminal |
| application_cancel_quota | Paused admitted upload, ordinary second Expect request refused with zero content, public cancel, one cancelled callback, stale control |
| malformed_chunk | Ordinary invalid chunk-size line after100; one invalid_body cancel/no end; observed wire terminal |

The client requires successful finals to be 200 and refusals to be errors; it
does not invent a specific unknown 4xx/5xx code. Full final headers/status and
interim headers are retained. Error-path EOF is accepted only before any response
header; partially emitted/malformed responses fail parsing. Response parsing
preserves Content-Length/chunked boundaries, bounds headers and reads, checks
file equality incrementally, and requires EOF/surplus checks on closing sockets.
It does not store a 100MB body in memory or on disk. Socket framing can coalesce
split writes; the fixture does not claim deterministic native packet boundaries.

## Lifecycle, provenance and evidence review

The client imports normal helpers from `tests/static_interop/probe.py`:
`precheck_port`, `listener_record` and bounded `digest_file`. It adapts the same
owned Popen, PID/socket-inode readiness, health request, SIGTERM/wait/reap and
forced-kill-as-failure lifecycle, with normal optional Nix loader/library prefix.
No refusal runner sparse fixture is represented as upload evidence.

Runtime requires a successful supplied build record whose binary hash matches
the executable. Records include actual argv/cwd, explicitly passed H1_PROFILE
values, compiler/source/library/binary build identities, Python/client/helper
identities, child PID, selected port, listener raw inode evidence, readiness,
per-case individual success/failure, actual counts/hashes/headers/counters,
child exit/reap/forced status and post-deinit marker. Inherited environment is
not dumped. Runtime artifacts and generated fixtures stay under `/tmp`; Root
must retain the small real result/log records under assigned evidence afterward.

## Exact remaining prerequisites and invocation

1. Root combines and independently reviews App and transport, including the
   file_body ownership guard. Root supplies its actual coherent source path.
2. Root authorizes ordinary runtime; no current runtime permission is inferred.
3. Compile that coherent source with the prepared explicit replay, using the
   existing native libraries and c223 override. No new package view is needed.
4. Select an unused owned loopback port and existing Nix loader/library prefix
   if required. The client only prechecks/binds/contacts the selected port.

After Root supplies `combined_source`, this is the complete replay shape (the
variable must contain the actual supplied source directory):

```sh
python3 .uwz-work/evidence/h1-plaintext/integration/compile.py --source "$combined_source" --output /tmp/uwz-h1-profile-combined --record compile-combined
python3 .uwz-work/evidence/h1-plaintext/integration/probe.py --source "$combined_source" --server /tmp/uwz-h1-profile-combined/profile --build-record /workspaces/uWebZockets/.uwz-work/evidence/h1-plaintext/integration/compile-combined.json --artifacts /tmp/uwz-h1-profile-live-records --port 18886 --root-authorized-runtime
```

Add `--loader "$nix_loader" --library-path "$nix_library_path"` only when Root
provides the actual existing Nix values. Client artifacts directory must not
already exist, preserving prior raw records. The authorization flag is a guard
against accidental invocation; it does not itself grant permission.

## Explicit gaps and limits

- Independent body-end outgoing-producer context retaining metadata beyond
  upload cleanup is NOT prepared. Existing metadata checks end at the successful
  upload end callback. No fake producer lifetime or abort hook was invented.
- TLS, HTTP/2, HTTP/3, Windows/macOS native runtime, community BSD activation,
  parser fuzz targets, native fault schedules and all global final gates remain
  outside this plaintext preparation.
- No 104857600-byte (100MiB) upload is claimed; successful large cases use exactly
  100000000. Declared oversize checks use the small real logical-limit route.
- No low-level allocator/leak or runtime-liveness measurement is included.
- Cross-route simultaneous successful bindings, peer disconnect mid-body,
  shutdown during upload, timeout schedules, end-callback error, and exhaustive
  malformed framing variants are not prepared in this fixture.
- Source-only self-review is complete; Root's independent component/combined
  review and actual ordinary runtime evidence remain required.
- Graph refresh was not run: only ignored private evidence fixtures were edited,
  and graph files lie outside this worker's assigned ownership.
