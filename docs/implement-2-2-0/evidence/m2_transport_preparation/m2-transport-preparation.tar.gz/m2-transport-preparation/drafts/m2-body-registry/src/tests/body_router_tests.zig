const std = @import("std");
const support = @import("test_support");
const radix = support.radix;
const body = support.request_body;
const Request = support.http_request.Request;
const Response = support.http_response.Response;
const StreamingRequest = support.streaming_request.StreamingRequest;

fn buffered(_: *Request, _: *Response) void {}
fn begin(context: *anyopaque, _: *const StreamingRequest, _: body.BodyControl) !body.BodyBinding {
    return .{ .context = context };
}
fn chunk(_: *anyopaque, bytes: []const u8) !body.BodyProgress {
    return .{ .consumed = bytes.len, .readiness = .ready };
}
fn end(_: *anyopaque, _: *const StreamingRequest, _: *Response) !void {}
fn cancel(_: *anyopaque, _: body.BodyCancelReason) void {}
fn middleware(context: *anyopaque, _: *Request, _: *Response) radix.MiddlewareResult {
    const calls: *usize = @ptrCast(@alignCast(context));
    calls.* += 1;
    return .continue_dispatch;
}
fn definition(context: *anyopaque, max_active: u16) body.BodyRoute {
    return .{
        .sink = .{ .context = context, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel },
        .limits = .{ .max_body_bytes = 100_000_000, .max_active = max_active },
    };
}
const capacities: radix.Capacities = .{
    .max_nodes = 16,
    .max_pattern_routes = 8,
    .max_middleware = 4,
    .max_route_path_size = 128,
    .registry_storage_size = 1024,
    .stream_request_bodies = true,
};

test "body router rejects disabled registration without storage mutation" {
    var bundle: radix.Bundle(.{}) = .{};
    var router = try radix.Router.init(bundle.storage());
    var calls: usize = 0;
    const route = definition(&calls, 1);
    try std.testing.expectEqual(@as(usize, 0), router.body.definitions.len);
    try std.testing.expectError(error.BodyStreamingDisabled, router.route_body(.post, "/upload", &route));
    try std.testing.expectEqual(@as(u16, 0), router.route_record_count);
    try std.testing.expectEqual(@as(u32, 0), router.route_storage_length);
    try std.testing.expectEqual(@as(u32, 0), router.registry_storage_length);
}

test "body router copies path and retains immutable definition and stable record" {
    var bundle: radix.Bundle(capacities) = .{};
    var router = try radix.Router.init(bundle.storage());
    var calls: usize = 0;
    const route = definition(&calls, 2);
    var path = [_]u8{ '/', 'u', 'p', 'l', 'o', 'a', 'd' };
    try router.route_body(.post, &path, &route);
    @memset(&path, 'x');
    const selected = router.match("/upload", .post).?;
    try std.testing.expect(selected.has_http);
    try std.testing.expect(selected.handler == null and selected.http_handler == null);
    try std.testing.expect(selected.body_match.?.definition == &route);
    try std.testing.expectEqual(@as(u16, 0), selected.body_match.?.record_index);
    try router.get("/up", buffered);
    try router.get("/upper", buffered);
    try std.testing.expectEqual(selected.body_match, router.match("/upload", .post).?.body_match);
    try std.testing.expectEqualStrings("/upload", router.registry_storage[0..7]);
}

test "body router and buffered routes share specificity methods captures and Allow" {
    var streamed_bundle: radix.Bundle(capacities) = .{};
    var buffered_bundle: radix.Bundle(capacities) = .{};
    var streamed = try radix.Router.init(streamed_bundle.storage());
    var legacy = try radix.Router.init(buffered_bundle.storage());
    var calls: usize = 0;
    const route = definition(&calls, 1);
    const paths = [_][]const u8{ "/items/*rest", "/items/:id", "/items/:id/fixed", "/items/fixed", "/items/fix", "/other" };
    for (paths) |path| {
        try streamed.route_body(.get, path, &route);
        try legacy.get(path, buffered);
    }
    try streamed.route_body(.post, "/items/:id", &route);
    try legacy.post("/items/:id", buffered);
    try streamed.route_body(.any, "/fallback", &route);
    try legacy.any("/fallback", buffered);
    const lookups = [_][]const u8{ "/items/a", "/items/a/fixed", "/items/fixed", "/items/fix", "/items/a/b", "/items/", "/other", "/fallback", "/missing" };
    const methods = [_]?radix.HttpMethod{ .get, .head, .post, .put, null };
    for (lookups) |path| {
        for (methods) |method| {
            var first: Request = .{ .path = path };
            var second: Request = .{ .path = path };
            const actual = streamed.match_request(&first, method);
            const expected = legacy.match_request(&second, method);
            try std.testing.expectEqual(expected == null, actual == null);
            if (actual == null) continue;
            try std.testing.expectEqual(expected.?.handler != null, actual.?.body_match != null);
            try std.testing.expectEqual(expected.?.allowed_methods, actual.?.allowed_methods);
            try std.testing.expectEqual(expected.?.has_http, actual.?.has_http);
            try std.testing.expectEqual(first.route_param_count, second.route_param_count);
            for (0..first.route_param_count) |index| {
                try std.testing.expectEqualStrings(second.route_param_names[index], first.route_param_names[index]);
                try std.testing.expectEqualStrings(second.route_param_values[index], first.route_param_values[index]);
            }
        }
    }
}

test "body router method selection combines buffered and streaming fallbacks" {
    var bundle: radix.Bundle(capacities) = .{};
    var router = try radix.Router.init(bundle.storage());
    var calls: usize = 0;
    const route = definition(&calls, 1);
    try router.route_body(.get, "/upload", &route);
    try router.any("/upload", buffered);
    try std.testing.expect(router.match("/upload", .head).?.body_match != null);
    try std.testing.expect(router.match("/upload", .post).?.handler != null);
    try router.head("/upload", buffered);
    try std.testing.expect(router.match("/upload", .head).?.body_match == null);
    try router.get("/reverse", buffered);
    try router.route_body(.any, "/reverse", &route);
    try std.testing.expect(router.match("/reverse", .head).?.handler != null);
    try std.testing.expect(router.match("/reverse", null).?.body_match != null);
    try std.testing.expectError(error.RouteAlreadyRegistered, router.get("/upload", buffered));
    try std.testing.expectError(error.RouteAlreadyRegistered, router.route_body(.get, "/reverse", &route));
}

test "body router rejects invalid limits and middleware before registration effects" {
    var bundle: radix.Bundle(capacities) = .{};
    var router = try radix.Router.init(bundle.storage());
    var calls: usize = 0;
    const invalid = definition(&calls, 0);
    const valid = definition(&calls, 1);
    try std.testing.expectError(error.InvalidBodyLimits, router.route_body(.post, "/invalid", &invalid));
    try router.use(&calls, middleware);
    try std.testing.expectError(error.BodyMiddlewareIncompatible, router.route_body(.post, "/rejected", &valid));
    try std.testing.expectEqual(@as(u16, 0), router.route_record_count);
    try std.testing.expectEqual(@as(u32, 0), router.route_storage_length);
    try std.testing.expectEqual(@as(usize, 0), calls);
    var permitted = valid;
    permitted.middleware_policy = .headers_only;
    try router.route_body(.post, "/allowed", &permitted);
    const selected = router.match("/allowed", .post).?.body_match.?;
    try router.check_body_route(selected);
    try router.reserve_body_route(selected);
    try router.release_body_route(selected.record_index);
    try std.testing.expectEqual(@as(usize, 0), calls);
}

test "body router late middleware rejects admission while reserved cleanup stays valid" {
    var bundle: radix.Bundle(capacities) = .{};
    var router = try radix.Router.init(bundle.storage());
    var calls: usize = 0;
    const route = definition(&calls, 2);
    try router.route_body(.post, "/upload", &route);
    const selected = router.match("/upload", .post).?.body_match.?;
    try router.reserve_body_route(selected);
    try router.use(&calls, middleware);
    try std.testing.expectError(error.BodyMiddlewareIncompatible, router.check_body_route(selected));
    try std.testing.expectError(error.BodyMiddlewareIncompatible, router.reserve_body_route(selected));
    try std.testing.expectEqual(@as(u16, 1), router.body.active[selected.record_index]);
    try router.release_body_route(selected.record_index);
    try std.testing.expectError(error.BodyAdmissionMissing, router.release_body_route(selected.record_index));
    try std.testing.expectEqual(@as(usize, 0), calls);
}

test "body router quota checks are pure independent and u16 bounded" {
    var bundle: radix.Bundle(capacities) = .{};
    var router = try radix.Router.init(bundle.storage());
    var calls: usize = 0;
    const route = definition(&calls, std.math.maxInt(u16));
    try router.route_body(.post, "/first", &route);
    try router.route_body(.post, "/second", &route);
    const first = router.match("/first", .post).?.body_match.?;
    const second = router.match("/second", .post).?.body_match.?;
    for (0..std.math.maxInt(u16)) |_| try router.reserve_body_route(first);
    try std.testing.expectError(error.BodyAdmissionFull, router.check_body_route(first));
    try std.testing.expectError(error.BodyAdmissionFull, router.reserve_body_route(first));
    try router.check_body_route(second);
    try std.testing.expectEqual(@as(u16, 0), router.body.active[second.record_index]);
    try router.release_body_route(first.record_index);
    try router.reserve_body_route(first);
    const forged: radix.BodyMatch = .{ .definition = &route, .record_index = std.math.maxInt(u16) };
    try std.testing.expectError(error.InvalidBodyRoute, router.check_body_route(forged));
    try std.testing.expectError(error.BodyAdmissionMissing, router.release_body_route(forged.record_index));
    const other = definition(&calls, 1);
    try std.testing.expectError(error.InvalidBodyRoute, router.reserve_body_route(.{ .definition = &other, .record_index = first.record_index }));
}

test "body router failed split and pattern registrations preserve all storage" {
    var bundle: radix.Bundle(capacities) = .{};
    @memset(&bundle.bytes, 0);
    var storage = bundle.storage();
    storage.route_storage = storage.route_storage[0..10];
    var router = try radix.Router.init(storage);
    var calls: usize = 0;
    const route = definition(&calls, 1);
    try router.route_body(.post, "/abcde", &route);
    const original = router.match("/abcde", .post).?.body_match.?;
    const before = bundle.bytes;
    const node_count = router.node_count;
    const route_count = router.route_record_count;
    const path_bytes = router.route_storage_length;
    const registry_bytes = router.registry_storage_length;
    try std.testing.expectError(error.RouteStorageCapacityReached, router.route_body(.post, "/abxyz", &route));
    try std.testing.expectEqualSlices(u8, &before, &bundle.bytes);
    try std.testing.expectError(error.RouteStorageCapacityReached, router.get("/abxyz", buffered));
    try std.testing.expectEqualSlices(u8, &before, &bundle.bytes);
    try std.testing.expectError(error.RouteStorageCapacityReached, router.route_body(.post, "/:parameter", &route));
    try std.testing.expectEqualSlices(u8, &before, &bundle.bytes);
    try std.testing.expectError(error.RouteAlreadyRegistered, router.route_body(.post, "/abcde", &route));
    try std.testing.expectEqualSlices(u8, &before, &bundle.bytes);
    try std.testing.expectError(error.InvalidRoutePattern, router.route_body(.post, "/:id/:id", &route));
    try std.testing.expectEqualSlices(u8, &before, &bundle.bytes);
    try std.testing.expectEqual(node_count, router.node_count);
    try std.testing.expectEqual(route_count, router.route_record_count);
    try std.testing.expectEqual(path_bytes, router.route_storage_length);
    try std.testing.expectEqual(registry_bytes, router.registry_storage_length);
    try std.testing.expectEqual(original, router.match("/abcde", .post).?.body_match.?);
}

test "body router failed conflicts registry and record exhaustion are atomic" {
    var bundle: radix.Bundle(capacities) = .{};
    @memset(&bundle.bytes, 0);
    var router = try radix.Router.init(bundle.storage());
    var calls: usize = 0;
    const route = definition(&calls, 1);
    try router.route_body(.post, "/:id", &route);
    try std.testing.expectError(error.RouteAlreadyRegistered, router.post("/:id", buffered));
    const before = bundle.bytes;
    try std.testing.expectError(error.RoutePatternConflicts, router.route_body(.get, "/:other", &route));
    try std.testing.expectEqualSlices(u8, &before, &bundle.bytes);
    router.registry_storage = router.registry_storage[0..router.registry_storage_length];
    try std.testing.expectError(error.RouteStorageCapacityReached, router.route_body(.get, "/new", &route));
    try std.testing.expectEqualSlices(u8, &before, &bundle.bytes);
    router.route_records = router.route_records[0..router.route_record_count];
    try std.testing.expectError(error.RouteCapacityReached, router.route_body(.get, "/new", &route));
    try std.testing.expectEqualSlices(u8, &before, &bundle.bytes);
    try std.testing.expectEqual(@as(u16, 1), router.route_record_count);
    try std.testing.expectEqual(@as(u8, 1), router.pattern_count);
}

test "body router enabled columns use existing record bound and disabled columns are empty" {
    var enabled: radix.Bundle(capacities) = .{};
    const storage = enabled.storage();
    try std.testing.expectEqual(capacities.max_registered_routes(), storage.body.definitions.len);
    try std.testing.expectEqual(capacities.max_registered_routes(), storage.body.active.len);
    try std.testing.expectEqual(capacities.max_nodes, storage.body.node_records.len);
    try std.testing.expectEqual(capacities.max_pattern_routes, storage.body.pattern_records.len);
    var disabled_capacities = capacities;
    disabled_capacities.stream_request_bodies = false;
    try std.testing.expect(try capacities.storage_bytes() > try disabled_capacities.storage_bytes());
    var disabled: radix.Bundle(.{}) = .{};
    const absent = disabled.storage().body;
    try std.testing.expectEqual(@as(usize, 0), absent.definitions.len);
    try std.testing.expectEqual(@as(usize, 0), absent.active.len);
    try std.testing.expectEqual(@as(usize, 0), absent.node_records.len);
    try std.testing.expectEqual(@as(usize, 0), absent.pattern_records.len);
    var partial = storage;
    partial.body.active = partial.body.active[0 .. partial.body.active.len - 1];
    try std.testing.expectError(error.InvalidRouterCapacity, radix.Router.init(partial));
}

fn resume_owner(_: *anyopaque) error{BodyDeliveryFailed}!void {}
fn cancel_owner(_: *anyopaque) void {}

test "body router owner guard releases each upload once with another reservation active" {
    var bundle: radix.Bundle(capacities) = .{};
    var router = try radix.Router.init(bundle.storage());
    var calls: usize = 0;
    const route = definition(&calls, 2);
    try router.route_body(.post, "/upload", &route);
    const selected = router.match("/upload", .post).?.body_match.?;
    try router.reserve_body_route(selected);
    try router.reserve_body_route(selected);
    var state: body.BodyState = .{};
    _ = try state.arm(.{ .context = &calls, .resume_fn = resume_owner, .cancel_fn = cancel_owner }, route.limits, 0);
    if (state.reject_begin()) try router.release_body_route(selected.record_index);
    try std.testing.expect(!state.finish_terminal());
    try std.testing.expectEqual(@as(u16, 1), router.body.active[selected.record_index]);
    _ = try state.arm(.{ .context = &calls, .resume_fn = resume_owner, .cancel_fn = cancel_owner }, route.limits, 0);
    try std.testing.expect(state.accept_begin(.{ .context = &calls }) == null);
    _ = try state.take_end(true, 0);
    if (state.finish_terminal()) try router.release_body_route(selected.record_index);
    try std.testing.expect(!state.finish_terminal());
    try std.testing.expectEqual(@as(u16, 0), router.body.active[selected.record_index]);
    try std.testing.expectError(error.BodyAdmissionMissing, router.release_body_route(selected.record_index));
}

test "body router static and websocket paths keep canonical precedence without the index" {
    var bundle: radix.Bundle(capacities) = .{};
    var router = try radix.Router.init(bundle.storage());
    var calls: usize = 0;
    const route = definition(&calls, 1);
    try router.route_body(.post, "/files/*rest", &route);
    try router.route_body(.post, "/files/:id", &route);
    try router.get("/files/fixed", buffered);
    try router.ws("/files/socket", .{});
    try std.testing.expect(router.match("/files/fixed", .post).?.body_match == null);
    try std.testing.expect(router.match("/files/socket", .post).?.body_match == null);
    try std.testing.expect(router.match("/files/socket", .get).?.ws_behavior != null);
    const selected = router.match("/files/value", .post).?.body_match.?;
    router.static_nodes = &.{};
    try std.testing.expectEqual(selected, router.match("/files/value", .post).?.body_match.?);
    try std.testing.expect(router.match("/files/fixed", .post).?.body_match == null);
    var request: Request = .{ .path = "/files/socket" };
    try std.testing.expect(router.match_request(&request, .post).?.body_match == null);
    request.path = "/files";
    try std.testing.expect(router.match_request(&request, .post).?.body_match != null);
    try std.testing.expectEqualStrings("", request.get_param("rest").?);
}

test "body router admission leaves authorized middleware execution explicit and complete" {
    var bundle: radix.Bundle(capacities) = .{};
    var router = try radix.Router.init(bundle.storage());
    var calls: usize = 0;
    var route = definition(&calls, 1);
    route.middleware_policy = .headers_only;
    try router.use(&calls, middleware);
    try router.route_body(.post, "/upload", &route);
    try router.use(&calls, middleware);
    const selected = router.match("/upload", .post).?.body_match.?;
    try router.check_body_route(selected);
    try std.testing.expectEqual(@as(usize, 0), calls);
    var request: Request = .{ .path = "/upload" };
    // These callbacks touch metadata only and never access the unused target.
    var response: Response = .{ .target = undefined };
    try std.testing.expectEqual(radix.MiddlewareResult.continue_dispatch, router.run_middleware(&request, &response));
    try std.testing.expectEqual(@as(usize, 2), calls);
    try router.reserve_body_route(selected);
    try std.testing.expectEqual(@as(usize, 2), calls);
    try router.release_body_route(selected.record_index);
}

test "body router enabled carving is aligned exact bounded and guarded" {
    const bytes = comptime capacities.storage_bytes() catch @compileError("test capacities are valid");
    var backing: [bytes + 16]u8 align(radix.storage_alignment) = @splat(0x5a);
    const storage = try radix.carve_storage(backing[1 .. bytes + radix.storage_alignment], capacities);
    const base = @intFromPtr(storage.route_storage.ptr);
    const end_address = @intFromPtr(storage.static_hashes.ptr) + storage.static_hashes.len * @sizeOf(u64);
    try std.testing.expectEqual(bytes, end_address - base);
    try std.testing.expectEqual(@as(usize, 0), @intFromPtr(storage.body.definitions.ptr) % @alignOf(?*const body.BodyRoute));
    try std.testing.expectEqual(@as(usize, 0), @intFromPtr(storage.body.active.ptr) % @alignOf(u16));
    try std.testing.expectEqual(@as(usize, 0), @intFromPtr(storage.body.node_records.ptr) % @alignOf(radix.BodyMethodRecords));
    try std.testing.expectEqual(@as(usize, 0), @intFromPtr(storage.body.pattern_records.ptr) % @alignOf(radix.BodyMethodRecords));
    var router = try radix.Router.init(storage);
    var calls: usize = 0;
    var route = definition(&calls, 1);
    route.limits.max_body_bytes = 0;
    try router.route_body(.post, "/empty", &route);
    try router.reserve_body_route(router.match("/empty", .post).?.body_match.?);
    try router.release_body_route(0);
    try std.testing.expectEqual(@as(u8, 0x5a), backing[0]);
    try std.testing.expectEqual(@as(u8, 0x5a), backing[bytes + radix.storage_alignment]);
    try std.testing.expectError(error.InvalidRouterCapacity, radix.carve_storage(backing[0 .. bytes - 1], capacities));
}
