const std = @import("std");
const support = @import("test_support");
const storage = support.http1_upload_storage;

test "http1 upload storage: startup arms nothing and deinitializes drained" {
    var event_loop = try support.loop.init();
    defer support.loop.deinit(&event_loop);
    var owner: storage.Http1UploadStorage = undefined;
    try storage.init(&owner);
    defer storage.deinit(&owner);
    try std.testing.expect(storage.is_drained(&owner));
    try std.testing.expectEqual(@as(usize, 2048), owner.pending_headers.len);
    try std.testing.expectEqual(@as(usize, 0), owner.pending_header_length);
    try event_loop.xev_loop.run(.until_done);
}

test "http1 upload storage: reset preserves control generation and completion addresses" {
    var event_loop = try support.loop.init();
    defer support.loop.deinit(&event_loop);
    var owner: storage.Http1UploadStorage = undefined;
    try storage.init(&owner);
    defer storage.deinit(&owner);
    const read_address = @intFromPtr(&owner.read_retirement_completion);
    const write_address = @intFromPtr(&owner.write_retirement_completion);
    owner.body.generation = 71;
    owner.pending_headers[0..4].* = "test".*;
    owner.pending_header_length = 4;
    owner.ingress_read_offset = 3;
    owner.ingress_write_offset = 9;
    owner.route_record_index = 12;
    owner.read_resume_pending = true;
    owner.write_resume_pending = true;
    storage.reset(&owner);
    try std.testing.expectEqual(@as(u64, 71), owner.body.generation);
    try std.testing.expectEqual(read_address, @intFromPtr(&owner.read_retirement_completion));
    try std.testing.expectEqual(write_address, @intFromPtr(&owner.write_retirement_completion));
    try std.testing.expectEqual(@as(usize, 0), owner.pending_header_length);
    try std.testing.expectEqual(@as(usize, 0), owner.ingress_read_offset);
    try std.testing.expectEqual(@as(usize, 0), owner.ingress_write_offset);
    try std.testing.expect(!owner.read_resume_pending and !owner.write_resume_pending);
    try std.testing.expect(storage.is_drained(&owner));
}

test "http1 upload storage: callback, admission, close and retirement each prevent drain" {
    var event_loop = try support.loop.init();
    defer support.loop.deinit(&event_loop);
    var owner: storage.Http1UploadStorage = undefined;
    try storage.init(&owner);
    defer storage.deinit(&owner);
    owner.callback_phase = .end;
    try std.testing.expect(!storage.is_drained(&owner));
    owner.callback_phase = .none;
    owner.body.reserved = true;
    try std.testing.expect(!storage.is_drained(&owner));
    owner.body.reserved = false;
    owner.close_pending = true;
    try std.testing.expect(!storage.is_drained(&owner));
    owner.close_pending = false;
    owner.read_callback_active = true;
    try std.testing.expect(!storage.is_drained(&owner));
    owner.read_callback_active = false;
    owner.write_callback_active = true;
    try std.testing.expect(!storage.is_drained(&owner));
    owner.write_callback_active = false;
    owner.read_retirement = .first;
    try std.testing.expect(!storage.is_drained(&owner));
    owner.read_retirement = .idle;
    owner.write_retirement = .second;
    try std.testing.expect(!storage.is_drained(&owner));
    owner.write_retirement = .idle;
    try std.testing.expect(storage.is_drained(&owner));
}
