comptime {
    _ = @import("loop_retarget_tests.zig");
    _ = @import("http1_upload_storage_tests.zig");
    _ = @import("loop_handle_tests.zig");
    _ = @import("loop_handle_transport_tests.zig");
}
