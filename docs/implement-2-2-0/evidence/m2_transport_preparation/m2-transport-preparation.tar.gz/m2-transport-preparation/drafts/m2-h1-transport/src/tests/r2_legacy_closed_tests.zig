const std = @import("std");
const xev = @import("xev");
const support = @import("test_support");
const LegacyStartError = error{ SystemResources, AccessDenied, Unexpected, ProcessFdQuotaExceeded, SystemFdQuotaExceeded, AddressFamilyNotSupported, InvalidPath, InvalidHost, InvalidHeaderName, InvalidHeaderValue, ReservedHeader, HeadTooLarge, InvalidHostAddress, TlsUnavailable, ServerNameEmpty, ServerNameTooLong, SslAllocationFailed, BioAllocationFailed, SniConfigurationFailed, AlpnConfigurationFailed, HostnameVerificationFailed, ProtocolNotSupported, SocketTypeNotSupported };
const LegacyFetchError = error{ SystemResources, AccessDenied, Unexpected, ProcessFdQuotaExceeded, SystemFdQuotaExceeded, AddressFamilyNotSupported, InvalidPath, InvalidHost, InvalidHeaderName, InvalidHeaderValue, ReservedHeader, HeadTooLarge, InvalidHostAddress, TlsUnavailable, ServerNameEmpty, ServerNameTooLong, SslAllocationFailed, BioAllocationFailed, SniConfigurationFailed, AlpnConfigurationFailed, HostnameVerificationFailed, ProtocolNotSupported, SocketTypeNotSupported, ResponseBodyCapacityExceeded, CaPathRequired, CaPathTooLong, TlsConfigurationMismatch, CertificateLoadFailed, TlsContextCreationFailed, InflightCapacityReached };
const LegacyRunError = error{ SystemResources, Unexpected, FileDescriptorAlreadyPresentInSet, OperationCausesCircularLoop, FileDescriptorNotRegistered, UserResourceLimitReached, FileDescriptorIncompatibleWithEpoll, NestedRunsNotAllowed, FileDescriptorInvalid, FileDescriptorInBadState, CompletionQueueOvercommitted, SubmissionQueueEntryInvalid, BufferInvalid, RingShuttingDown, OpcodeNotSupported, InvalidThread, SignalInterrupt };

const Client = support.client.client(1);
fn narrow_start(connection: *support.client.ClientConnection, params: support.client_connection.StartParams) LegacyStartError!void {
    return connection.start(params);
}
fn narrow_fetch(client: *Client, context: *anyopaque) LegacyFetchError!void {
    return client.fetch(.{ .host = "127.0.0.1", .path = "/bad\r\npath" }, .{ .port = 80 }, context, outcome);
}
fn narrow_run(loop: *support.loop.Loop) LegacyRunError!void {
    return support.loop.run(loop);
}
fn narrow_owned_run(client: *Client) LegacyRunError!void {
    return client.run();
}
fn outcome(_: *anyopaque, _: support.client.FetchOutcome) void {}
fn released(_: *anyopaque, _: *support.client.ClientConnection) void {}

test "legacy closed: old raw initializer and exact start fetch run errors" {
    const get_raw: *const fn (*support.loop.Loop) callconv(.@"inline") *xev.Loop = support.loop.Loop.get_xev_loop;
    var event_loop = try support.loop.init();
    defer support.loop.deinit(&event_loop);
    var connection: support.client.ClientConnection = .{};
    connection.timer = try xev.Timer.init();
    defer connection.timer.deinit();
    var token: u8 = 0;
    try std.testing.expectError(error.InvalidPath, narrow_start(&connection, .{
        .loop = get_raw(&event_loop),
        .io = std.testing.io,
        .request = .{ .host = "127.0.0.1", .path = "/bad\r\npath" },
        .options = .{ .port = 80 },
        .ssl_ctx = null,
        .context = &token,
        .callback = outcome,
        .release_callback = released,
        .release_context = &token,
        .slot_index = 0,
    }));
    try narrow_run(&event_loop);
    var client = try Client.init(std.testing.io);
    defer client.deinit();
    try std.testing.expectError(error.InvalidPath, narrow_fetch(&client, &token));
    try narrow_owned_run(&client);
}
