const std = @import("std");
const support = @import("test_support");
const core_loop = support.loop;

test "loop handle: one stable pointer observes later healthy fence binding" {
    var event_loop = try core_loop.init();
    defer core_loop.deinit(&event_loop);
    const handle = core_loop.LoopHandle{ .owner = &event_loop };
    try std.testing.expectEqual(@sizeOf(*core_loop.Loop), @sizeOf(core_loop.LoopHandle));
    try std.testing.expectEqual(event_loop.get_xev_loop(), handle.raw());
    try handle.submit();
    var first: core_loop.IoFailureFence = .{};
    event_loop.failure_fence = &first;
    try std.testing.expectEqual(event_loop.get_xev_loop(), handle.raw());
    try handle.submit();
    try core_loop.run(&event_loop);
    var second: core_loop.IoFailureFence = .{};
    event_loop.failure_fence = &second;
    try handle.submit();
    try core_loop.run(&event_loop);
    try std.testing.expect(!first.failed and !second.failed);
}

test "loop handle: cold owner reset preserves stable association" {
    var event_loop = try core_loop.init();
    defer core_loop.deinit(&event_loop);
    var owner: support.http1_upload_storage.Http1UploadStorage = undefined;
    try support.http1_upload_storage.init(&owner);
    defer support.http1_upload_storage.deinit(&owner);
    try std.testing.expectEqual(@as(?core_loop.LoopHandle, null), owner.loop_handle);
    owner.loop_handle = .{ .owner = &event_loop };
    support.http1_upload_storage.reset(&owner);
    try std.testing.expectEqual(&event_loop, owner.loop_handle.?.owner);
    try std.testing.expectEqual(event_loop.get_xev_loop(), owner.loop_handle.?.raw());
}
