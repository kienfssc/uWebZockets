const std = @import("std");
const support = @import("test_support");

test "legacy client and loop inferred errors" {
    print_errors("START", @TypeOf(support.client.ClientConnection.start));
    print_errors("FETCH", @TypeOf(support.client.client(1).fetch));
    print_errors("RUN", @TypeOf(support.loop.run));
}

fn print_errors(comptime name: []const u8, comptime function: type) void {
    const result = @typeInfo(function).@"fn".return_type.?;
    const errors = @typeInfo(result).error_union.error_set;
    std.debug.print("{s}", .{name});
    inline for (@typeInfo(errors).error_set.?) |item| std.debug.print(" {s}", .{item.name});
    std.debug.print("\n", .{});
}
