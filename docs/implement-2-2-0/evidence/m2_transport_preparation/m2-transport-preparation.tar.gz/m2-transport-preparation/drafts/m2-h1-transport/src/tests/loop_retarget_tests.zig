const std = @import("std");
const builtin = @import("builtin");
const core_loop = @import("test_support").loop;
const xev = @import("xev");

const transfer_len = 8196;
const stage_ends = [_]usize{ 1, 4, transfer_len };

/// Owned descriptors for a real local TCP connection.
const Pair = struct { reader: std.posix.fd_t, writer: std.posix.fd_t };

fn loopback_pair() !Pair {
    const listener = std.c.socket(std.posix.AF.INET, std.posix.SOCK.STREAM, 0);
    if (listener < 0) return error.SocketFailed;
    defer _ = std.c.close(listener);
    var address: std.posix.sockaddr.in = .{
        .family = std.posix.AF.INET,
        .port = 0,
        .addr = std.mem.nativeToBig(u32, 0x7f000001),
        .zero = @splat(0),
    };
    if (std.c.bind(listener, @ptrCast(&address), @sizeOf(@TypeOf(address))) != 0)
        return error.BindFailed;
    if (std.c.listen(listener, 1) != 0) return error.ListenFailed;
    var size: std.posix.socklen_t = @sizeOf(@TypeOf(address));
    if (std.c.getsockname(listener, @ptrCast(&address), &size) != 0)
        return error.AddressFailed;
    const writer = std.c.socket(std.posix.AF.INET, std.posix.SOCK.STREAM, 0);
    if (writer < 0) return error.SocketFailed;
    errdefer _ = std.c.close(writer);
    if (std.c.connect(writer, @ptrCast(&address), size) != 0) return error.ConnectFailed;
    const reader = std.c.accept(listener, null, null);
    if (reader < 0) return error.AcceptFailed;
    return .{ .reader = reader, .writer = writer };
}

fn selected_loop() !core_loop.Loop {
    const requested = std.c.getenv("UWZ_TEST_XEV_BACKEND");
    if (requested) |raw| {
        const name = std.mem.span(raw);
        const wanted = std.meta.stringToEnum(xev.Backend, name) orelse
            return error.UnknownRequestedBackend;
        if (!xev.prefer(wanted)) return error.RequestedBackendUnavailable;
    }
    // core_loop.init detects once, so explicit backend coverage constructs the
    // requested loop directly and cannot silently fall back during detection.
    var result: core_loop.Loop = if (requested != null)
        .{ .xev_loop = try xev.Loop.init(.{ .entries = 4096 }) }
    else
        try core_loop.init();
    errdefer core_loop.deinit(&result);
    if (requested) |raw| {
        try std.testing.expectEqualStrings(std.mem.span(raw), @tagName(xev.backend()));
    }
    return result;
}

fn pattern(offset: usize) u8 {
    return @intCast(offset % 251);
}

/// All callback storage outlives its inline completion and every rearm.
const Receive = struct {
    completion: xev.Completion = .{},
    storage: [8194]u8 = @splat(0xa5),
    received: usize = 0,
    stage: usize = 0,
    calls: usize = 0,
    failure: ?anyerror = null,

    fn callback(
        userdata: ?*Receive,
        _: *xev.Loop,
        completion: *xev.Completion,
        _: xev.TCP,
        buffer: xev.ReadBuffer,
        result: xev.ReadError!usize,
    ) xev.CallbackAction {
        const owner = userdata.?;
        return owner.deliver(completion, buffer, result) catch |err| {
            owner.failure = err;
            return .disarm;
        };
    }

    fn deliver(self: *Receive, completion: *xev.Completion, buffer: xev.ReadBuffer, result: xev.ReadError!usize) !xev.CallbackAction {
        const count = try result;
        if (count == 0) return error.UnexpectedEmptyRead;
        try std.testing.expectEqual(@intFromPtr(&self.completion), @intFromPtr(completion));
        try std.testing.expectEqual(stage_ends[self.stage] - self.received, buffer.slice.len);
        try std.testing.expect(count <= buffer.slice.len);
        try std.testing.expectEqual(@as(u8, 0xa5), self.storage[0]);
        try std.testing.expectEqual(@as(u8, 0xa5), self.storage[buffer.slice.len + 1]);
        for (buffer.slice[0..count], self.received..) |byte, offset|
            try std.testing.expectEqual(pattern(offset), byte);
        self.calls += 1;
        self.received += count;
        if (self.received == transfer_len) return .disarm;
        if (self.received == stage_ends[self.stage]) self.stage += 1;
        @memset(&self.storage, 0xa5);
        const capacity = stage_ends[self.stage] - self.received;
        try core_loop.retarget_completed_receive(completion, self.storage[1..][0..capacity]);
        return .rearm;
    }
};

test "loop: completed TCP receive retargets to 1, 3, and 8192 byte windows" {
    if (builtin.os.tag == .windows) return error.SkipZigTest;
    var event_loop = try selected_loop();
    defer core_loop.deinit(&event_loop);
    const pair = try loopback_pair();
    defer _ = std.c.close(pair.reader);
    defer _ = std.c.close(pair.writer);
    var bytes: [transfer_len]u8 = undefined;
    for (&bytes, 0..) |*byte, offset| byte.* = pattern(offset);
    var sent: usize = 0;
    while (sent < bytes.len) {
        const count = std.c.send(pair.writer, bytes[sent..].ptr, bytes.len - sent, 0);
        if (count <= 0) return error.SendFailed;
        sent += @intCast(count);
    }
    var owner: Receive = .{};
    const socket = xev.TCP.initFd(pair.reader);
    socket.read(event_loop.get_xev_loop(), &owner.completion, .{ .slice = owner.storage[1..2] }, Receive, &owner, Receive.callback);
    try core_loop.run(&event_loop);
    if (owner.failure) |err| return err;
    try std.testing.expectEqual(transfer_len, owner.received);
    try std.testing.expect(owner.calls >= 3);
    try std.testing.expectEqual(@as(usize, 2), owner.stage);
}

/// Refill only after the previous write no longer borrows these bytes.
const Send = struct {
    completion: xev.Completion = .{},
    storage: [8192]u8 = undefined,
    sent: usize = 0,
    stage: usize = 0,
    calls: usize = 0,
    failure: ?anyerror = null,

    fn fill(self: *Send) []const u8 {
        const length = stage_ends[self.stage] - self.sent;
        for (self.storage[0..length], self.sent..) |*byte, offset| byte.* = pattern(offset);
        return self.storage[0..length];
    }

    fn callback(
        userdata: ?*Send,
        _: *xev.Loop,
        completion: *xev.Completion,
        _: xev.TCP,
        buffer: xev.WriteBuffer,
        result: xev.WriteError!usize,
    ) xev.CallbackAction {
        const owner = userdata.?;
        return owner.deliver(completion, buffer, result) catch |err| {
            owner.failure = err;
            return .disarm;
        };
    }

    fn deliver(self: *Send, completion: *xev.Completion, buffer: xev.WriteBuffer, result: xev.WriteError!usize) !xev.CallbackAction {
        const count = try result;
        if (count == 0) return error.UnexpectedEmptyWrite;
        try std.testing.expectEqual(@intFromPtr(&self.completion), @intFromPtr(completion));
        try std.testing.expectEqual(stage_ends[self.stage] - self.sent, buffer.slice.len);
        try std.testing.expect(count <= buffer.slice.len);
        self.calls += 1;
        self.sent += count;
        if (self.sent == transfer_len) return .disarm;
        if (self.sent == stage_ends[self.stage]) self.stage += 1;
        try core_loop.retarget_completed_send(completion, self.fill());
        return .rearm;
    }
};

test "loop: completed TCP send refills successive 1, 3, and 8192 byte buffers" {
    if (builtin.os.tag == .windows) return error.SkipZigTest;
    var event_loop = try selected_loop();
    defer core_loop.deinit(&event_loop);
    const pair = try loopback_pair();
    defer _ = std.c.close(pair.reader);
    defer _ = std.c.close(pair.writer);
    var owner: Send = .{};
    const socket = xev.TCP.initFd(pair.writer);
    socket.write(event_loop.get_xev_loop(), &owner.completion, .{ .slice = owner.fill() }, Send, &owner, Send.callback);
    try core_loop.run(&event_loop);
    if (owner.failure) |err| return err;
    try std.testing.expectEqual(transfer_len, owner.sent);
    try std.testing.expect(owner.calls >= 3);
    try std.testing.expectEqual(@as(usize, 2), owner.stage);
    var received: [transfer_len]u8 = undefined;
    var total: usize = 0;
    while (total < received.len) {
        const count = std.c.recv(pair.reader, received[total..].ptr, received.len - total, 0);
        if (count <= 0) return error.ReceiveFailed;
        total += @intCast(count);
    }
    for (received, 0..) |byte, offset| try std.testing.expectEqual(pattern(offset), byte);
}

test "loop: retarget validation rejects empty, oversized, and wrong operation buffers" {
    var completion: xev.Completion = .{};
    var storage: [8193]u8 = undefined;
    try std.testing.expectError(error.EmptyBuffer, core_loop.retarget_completed_receive(&completion, storage[0..0]));
    try std.testing.expectError(error.ReceiveBufferTooLarge, core_loop.retarget_completed_receive(&completion, &storage));
    try std.testing.expectError(error.InvalidCompletedOperation, core_loop.retarget_completed_receive(&completion, storage[0..1]));
    try std.testing.expectError(error.EmptyBuffer, core_loop.retarget_completed_send(&completion, storage[0..0]));
    try std.testing.expectError(error.InvalidCompletedOperation, core_loop.retarget_completed_send(&completion, storage[0..1]));
}
