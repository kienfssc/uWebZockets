const support = @import("test_support");
const Params = @typeInfo(@TypeOf(support.client.ClientConnection.start)).@"fn".params[1].type.?;
const default_config: support.config.ServerConfig = .{};
const slab_bytes = support.config.required_bytes(default_config) catch @compileError("invalid default configuration");

export const uwz_r2_layout: [10]usize = .{
    @sizeOf(support.loop.Loop),
    @sizeOf(support.tcp.TcpConnection),
    @alignOf(support.tcp.TcpConnection),
    @sizeOf(support.client.ClientConnection),
    @sizeOf(Params),
    @sizeOf(support.client.client(1)),
    @sizeOf(support.udp.quic_transport(struct {})),
    slab_bytes,
    default_config.max_connections,
    if (@hasDecl(support, "http1_upload_storage")) @sizeOf(support.http1_upload_storage.Http1UploadStorage) else 0,
};
