const std = @import("std");
const c = @import("c");
const xev = @import("xev");
const support = @import("test_support");
const core_loop = support.loop;
const DatagramFn = *const fn (*anyopaque) void;

/// No protocol work is needed to exercise guarded UDP lifecycle ownership.
const Engine = struct {
    context: ?*anyopaque = null,
    on_datagram: ?DatagramFn = null,
    packets: usize = 0,
    pub fn init() !Engine {
        return .{};
    }
    pub fn start(_: *Engine, _: *c.SSL_CTX, _: *const support.radix.Router, _: xev.SocketFd, _: std.Io.net.IpAddress) !void {}
    pub fn deinit(_: *Engine) void {}
    pub fn process_datagram(self: *Engine, _: []const u8, _: std.Io.net.IpAddress) void {
        self.packets += 1;
        if (self.on_datagram) |callback| callback(self.context.?);
    }
    pub fn process(_: *Engine) void {}
    pub fn next_timeout_ms(_: *const Engine) u64 {
        return 60_000;
    }
    pub fn cooldown(_: *Engine) void {}
};

const Transport = support.udp.quic_transport(Engine);

fn stop_after_datagram(context: *anyopaque) void {
    const transport: *Transport = @ptrCast(@alignCast(context));
    transport.shutdown();
}

/// Explicit backend tests own the thread pool in fixed storage because core
/// init deliberately detects once and may override a requested preference.
fn init_udp_loop(event_loop: *core_loop.Loop, thread_pool: *xev.ThreadPool) !?xev.Backend {
    thread_pool.* = xev.ThreadPool.init(.{});
    errdefer {
        thread_pool.shutdown();
        thread_pool.deinit();
    }
    const requested = std.c.getenv("UWZ_TEST_XEV_BACKEND") orelse {
        event_loop.* = try core_loop.init();
        return null;
    };
    const previous = xev.backend();
    const wanted = std.meta.stringToEnum(xev.Backend, std.mem.span(requested)) orelse
        return error.UnknownRequestedBackend;
    if (!xev.prefer(wanted)) return error.RequestedBackendUnavailable;
    errdefer {
        if (!xev.prefer(previous)) @panic("cannot restore test backend");
    }
    event_loop.* = .{ .xev_loop = try xev.Loop.init(.{ .entries = 4096, .thread_pool = thread_pool }) };
    return previous;
}

fn deinit_udp_loop(event_loop: *core_loop.Loop, thread_pool: *xev.ThreadPool, previous: ?xev.Backend) void {
    // A pool worker may still deliver into the loop until shutdown joins it.
    thread_pool.shutdown();
    thread_pool.deinit();
    core_loop.deinit(event_loop);
    if (previous) |backend| {
        if (!xev.prefer(backend)) @panic("cannot restore test backend");
    }
}

fn assert_udp_backend() !void {
    std.debug.print("UDP lifecycle backend={s}\n", .{@tagName(xev.backend())});
    if (std.c.getenv("UWZ_TEST_XEV_BACKEND")) |requested|
        try std.testing.expectEqualStrings(std.mem.span(requested), @tagName(xev.backend()));
}

test "loop handle transport: TCP owner binds only to its stable loop" {
    var event_loop = try core_loop.init();
    defer core_loop.deinit(&event_loop);
    var owner: support.http1_upload_storage.Http1UploadStorage = undefined;
    try support.http1_upload_storage.init(&owner);
    defer support.http1_upload_storage.deinit(&owner);
    owner.loop_handle = .{ .owner = &event_loop };
    var connection = support.tcp.TcpConnection{ .socket = undefined, .loop = event_loop.get_xev_loop() };
    try std.testing.expectEqual(@as(?*support.http1_upload_storage.Http1UploadStorage, null), connection.upload_owner);
    support.tcp.bind_upload_owner(&connection, &owner);
    try std.testing.expectEqual(&owner, connection.upload_owner.?);
    support.tcp.bind_upload_owner(&connection, null);
    try std.testing.expectEqual(@as(?*support.http1_upload_storage.Http1UploadStorage, null), connection.upload_owner);
}

test "loop handle transport: UDP startup immediate shutdown drains" {
    var event_loop: core_loop.Loop = undefined;
    var thread_pool: xev.ThreadPool = undefined;
    const previous = try init_udp_loop(&event_loop, &thread_pool);
    defer deinit_udp_loop(&event_loop, &thread_pool, previous);
    try assert_udp_backend();
    var fence: core_loop.IoFailureFence = .{};
    event_loop.failure_fence = &fence;
    var bundle = support.radix.DefaultBundle{};
    var router = try support.radix.Router.init(bundle.storage());
    var transport = try Transport.init(@ptrFromInt(1), &router, "127.0.0.1", 0);
    defer transport.deinit();
    try transport.start_on_loop(.{ .owner = &event_loop });
    try std.testing.expectEqual(&event_loop, transport.loop_handle.?.owner);
    transport.shutdown();
    try core_loop.run(&event_loop);
    try std.testing.expect(transport.is_drained());
    try std.testing.expect(!fence.failed);
}

test "loop handle transport: UDP datagram success retains handle through shutdown" {
    if (@import("builtin").os.tag == .windows) return error.SkipZigTest;
    var event_loop: core_loop.Loop = undefined;
    var thread_pool: xev.ThreadPool = undefined;
    const previous = try init_udp_loop(&event_loop, &thread_pool);
    defer deinit_udp_loop(&event_loop, &thread_pool, previous);
    try assert_udp_backend();
    var fence: core_loop.IoFailureFence = .{};
    event_loop.failure_fence = &fence;
    var bundle = support.radix.DefaultBundle{};
    var router = try support.radix.Router.init(bundle.storage());
    var transport = try Transport.init(@ptrFromInt(1), &router, "127.0.0.1", 0);
    defer transport.deinit();
    transport.engine.context = &transport;
    transport.engine.on_datagram = stop_after_datagram;
    try transport.start_on_loop(.{ .owner = &event_loop });
    try std.testing.expectEqual(&event_loop, transport.loop_handle.?.owner);
    var address: std.posix.sockaddr.in = undefined;
    var address_length: std.posix.socklen_t = @sizeOf(@TypeOf(address));
    if (std.c.getsockname(xev.udp_fd(transport.socket), @ptrCast(&address), &address_length) != 0)
        return error.SocketAddressFailed;
    const sender = std.c.socket(std.posix.AF.INET, std.posix.SOCK.DGRAM, 0);
    if (sender < 0) return error.SocketFailed;
    defer _ = std.c.close(sender);
    if (std.c.sendto(sender, "one", 3, 0, @ptrCast(&address), address_length) != 3)
        return error.DatagramSendFailed;
    try core_loop.run(&event_loop);
    try std.testing.expect(transport.is_drained());
    try std.testing.expectEqual(@as(usize, 1), transport.engine.packets);
    try std.testing.expect(!fence.failed);
}

/// Start rejects this pure request before creating or arming a socket.
fn invalid_request() support.client.Request {
    return .{ .host = "127.0.0.1", .path = "/bad\r\npath" };
}

fn outcome(_: *anyopaque, _: support.client.FetchOutcome) void {}
fn released(_: *anyopaque, _: *support.client.ClientConnection) void {}

test "loop handle transport: legacy raw client initializer remains unguarded" {
    var event_loop = try core_loop.init();
    defer core_loop.deinit(&event_loop);
    var connection: support.client.ClientConnection = .{};
    connection.timer = try xev.Timer.init();
    defer connection.timer.deinit();
    var token: u8 = 0;
    try std.testing.expectError(error.InvalidPath, connection.start(.{
        .loop = event_loop.get_xev_loop(),
        .io = std.testing.io,
        .request = invalid_request(),
        .options = .{ .port = 80 },
        .ssl_ctx = null,
        .context = &token,
        .callback = outcome,
        .release_callback = released,
        .release_context = &token,
        .slot_index = 0,
    }));
    try std.testing.expectEqual(@as(?core_loop.LoopHandle, null), connection.loop_handle);
    try std.testing.expect(!connection.active);
}

test "loop handle transport: explicit shared client retains its owning handle" {
    var event_loop = try core_loop.init();
    defer core_loop.deinit(&event_loop);
    const handle = core_loop.LoopHandle{ .owner = &event_loop };
    var fence: core_loop.IoFailureFence = .{};
    event_loop.failure_fence = &fence;
    var connection: support.client.ClientConnection = .{};
    connection.timer = try xev.Timer.init();
    defer connection.timer.deinit();
    var token: u8 = 0;
    try std.testing.expectError(error.InvalidPath, connection.start(.{
        .loop = handle.raw(),
        .loop_handle = handle,
        .io = std.testing.io,
        .request = invalid_request(),
        .options = .{ .port = 80 },
        .ssl_ctx = null,
        .context = &token,
        .callback = outcome,
        .release_callback = released,
        .release_context = &token,
        .slot_index = 0,
    }));
    try std.testing.expectEqual(&event_loop, connection.loop_handle.?.owner);
    try std.testing.expect(!connection.active and !fence.failed);
}

test "loop handle transport: owned client passes association before slot startup" {
    var client = try support.client.client(1).init(std.testing.io);
    defer client.deinit();
    var token: u8 = 0;
    try std.testing.expectError(error.InvalidPath, client.fetch(invalid_request(), .{ .port = 80 }, &token, outcome));
    try std.testing.expectEqual(&client.loop, client.slots[0].loop_handle.?.owner);
    try std.testing.expectEqual(@as(usize, 1), client.free_count);
    try std.testing.expectEqual(@as(usize, 0), client.inflight);
}
