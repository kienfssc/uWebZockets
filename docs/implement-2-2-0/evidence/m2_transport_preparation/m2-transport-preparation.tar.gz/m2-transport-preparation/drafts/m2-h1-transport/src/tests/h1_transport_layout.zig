const owner = @import("test_support").http1_upload_storage.Http1UploadStorage;

export const uwz_upload_storage_layout: [12]usize = .{
    @sizeOf(owner),
    @alignOf(owner),
    @offsetOf(owner, "pending_headers"),
    @offsetOf(owner, "body"),
    @offsetOf(owner, "decoder"),
    @offsetOf(owner, "read_retirement_completion"),
    @offsetOf(owner, "write_retirement_completion"),
    @offsetOf(owner, "retirement_timer"),
    @offsetOf(owner, "head"),
    @offsetOf(owner, "ingress_read_offset"),
    @offsetOf(owner, "callback_phase"),
    @offsetOf(owner, "initialized"),
};
