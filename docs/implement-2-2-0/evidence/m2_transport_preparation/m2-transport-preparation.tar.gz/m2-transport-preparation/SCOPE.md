# Prepared and partial transport work

This archive preserves separate source/evidence namespaces, not one authoritative
combined build. Root source remains at reviewed checkpoints. Prepared registry,
R2 guarded loop/cold owner, and App/config slices received scoped independent
review and focused tests. Their complete H1 consumer, close/reuse protocol,
H2/H3 drivers and combined gates remain absent.

R3 retirement and duplicate cleanup are source proposals. The head/admission
handoff is provisionally accepted, not implemented. No native cancellation,
crash, leak or race probe may be inferred from these proposals.

H2/H3 header-refusal drafts were interrupted by account usage limits. They are
partial and unreviewed: narrow red/green checks do not satisfy the architect's
complete acceptance plan. Keep their source snapshots as recovery data, not
production changes or proof of live streaming. Evidence contains original seed
bindings; root's later H0 test import correction is not backported into them.

Derived objects and executables are omitted with hashes; compiler caches and
symlinks are not included. Reproduction requires the recorded Zig/tool versions,
root baseline and authoritative dependency pins or explicitly scoped local test
candidate, as stated by each original command. Historical source manifests and
outputs retain their original paths and narrower claims. No fork pin, default
capability, request layout, or root source behavior is changed by this archive.
