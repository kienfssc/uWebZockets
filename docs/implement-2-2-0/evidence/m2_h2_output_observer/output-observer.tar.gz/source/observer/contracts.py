"""Pure, bounded expectations for output streaming preparation."""
import hashlib

LIMIT = 8192
TOTAL = 16777313
FILE_TOTAL = 24659
FILE_OFFSET = 37
FILE_LENGTH = 24593
SENTINEL = b'final-upload-sentinel!'
P32 = bytes(range(1, 11)) + SENTINEL
EARLY = b'early-final-order'
EMPTY_HASH = hashlib.sha256(b'').hexdigest()
H32 = '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5'
CASES = {
    'producer_reuse': ('producer_reuse', 'producer_reuse_next'),
    'output_pressure_window': ('output_pressure_window',),
    'output_pressure_ready': ('output_pressure_ready',),
    'stream_file': ('stream_file',),
    'early_final_order': ('early_final_order', 'early_final_recovery'),
}
TAGS = tuple(tag for tags in CASES.values() for tag in tags) + tuple('spare_%02d' % i for i in range(25))


def span(total, offset, length):
    if any(type(x) is not int for x in (total, offset, length)):
        raise ValueError('integer bounds required')
    if total < len(SENTINEL) or offset < 0 or length < 0 or length > LIMIT or offset + length > total:
        raise ValueError('invalid bounds')
    return bytes(1 + (i % 251) if i < total - len(SENTINEL) else SENTINEL[i - (total - len(SENTINEL))] for i in range(offset, offset + length))


def digest(total, offset, length):
    if type(length) is not int or length < 0:
        raise ValueError('invalid length')
    h = hashlib.sha256()
    if length == 0:
        span(total, offset, 0)
    while length:
        n = min(length, LIMIT)
        h.update(span(total, offset, n))
        offset += n
        length -= n
    return h.hexdigest()


def record(tag, selected):
    active = tag in selected
    accepted = active and tag != 'early_final_order'
    return dict(tag=tag, bytes=32 if accepted else 0, sha256=H32 if accepted else EMPTY_HASH,
                chunks=None if accepted else 0, max_span=None if accepted else 0,
                middleware=int(active), attempts=int(accepted), begins=int(accepted), ends=int(accepted),
                cancels=0, failures=0, end_errors=0, chunk_errors=0, invalid_progress=0, errors=0,
                metadata_middleware=int(active), metadata_begin=int(accepted), metadata_end=int(accepted),
                stale_resume=0, stale_cancel=0, active=False, paused=False, reason=None)


def expected_records(case_ids):
    if type(case_ids) not in (tuple, list):
        raise ValueError('case IDs must be a sequence')
    selected = set()
    seen = set()
    for case in case_ids:
        if type(case) is not str or case not in CASES or case in seen:
            raise ValueError('invalid or duplicate case ID')
        seen.add(case)
        selected.update(CASES[case])
    return [record(tag, selected) for tag in TAGS]


def validate_records(case_ids, records):
    expected = expected_records(case_ids)
    if type(records) is not list or len(records) != 32:
        raise ValueError('record count')
    for want, got in zip(expected, records):
        if type(got) is not dict or got.keys() != want.keys():
            raise ValueError('record schema')
        for key, value in want.items():
            actual = got[key]
            if key in ('chunks', 'max_span') and value is None:
                if type(actual) is not int or actual < 1 or (key == 'max_span' and actual > 32):
                    raise ValueError('invalid callback diagnostic')
            elif type(actual) is not type(value) or actual != value:
                raise ValueError('record mismatch: ' + key)

PRODUCER_HASH = 'e5b7e8c5bbad59c7bc86f18236a37661571e972f65c707d7dc1902386ec5e91d'
FILE_HASH = '2cd533d3b2bd76e62ead7795d612fcc1f4d5121bedeed4499f5e629f5b358bd3'
RANGE_HASH = '8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac'
EARLY_HASH = 'd826bcf95ee8850cecb39accdeb84b32336a0415411938da42da7edcac891da7'
