# Task5d source-derived work budgets and file I/O ruling

Root preserves the same architect's followup and adopts it as preparation
requirements, not implementation or runtime evidence. Exact source inputs were
restored and authenticated by task-5d1-restoration.json. The architect performed
source inspection only; no source edit, build, test or native activity.

## Decrypted H2 receive work

Count decrypted bytes returned by bounded SSLSocket.recv, not ciphertext,
packets or assumed fragmentation. Each nonempty receive contributes at least
one byte, so its count is bounded by the stage byte budget. Keep 8192-byte
reads/sends, aggregate counters and existing absolute deadlines; no per-read
history. The legacy4096-call limit remains for legacy cases.

Source: immutable src/http2/server.zig958-998 atomic producer DATA;
1930-1971 initial SETTINGS and one bounded HEADERS;2027-2069 unpadded bounded
DATA;1732-1754 positive committed request refunds.

H =4096 encoded response header bytes+9 frame header=4105.
Small response =4105+4095+9*(4095 nonempty DATA+1 empty terminal)=45064.
For one case stage, A<=32 auxiliary responses, R<=65 sent request flow bytes,
S<=2 client SETTINGS (initial plus custom), Z<=1 permitted server reset.
Control =39 initial server SETTINGS+9*S+13*(2*R)+13*Z=1760 at these maxima.
These are bounds for the declared schedule, not permission for extra traffic.
Health/echo/status/control/reuse-next responses count toward A. Source-specific
output-stage policy rejects PING, trailers, informationals, extensions and
additional SETTINGS; never globally weaken/change legacy policies.

| Case stage | Conservative H2 byte budget |
| --- | ---: |
| Producer N16777313+4105+9*2050+32*45064+1760 | 18243676 |
| File24593+4105+9*24594+32*45064+1760 | 1693852 |
| Early final17+4105+9*2+32*45064+1760 | 1447948 |

Producer count is2049 successful nonempty atomic DATA writes and at most one
empty terminal. File/small bounds conservatively allow one-byte nonempty DATA;
early final has the explicitly separated8+9 credit schedule. Exact semantics,
hashes/counts/frame policies remain mandatory even when a byte budget is spare.

Final32 statuses+metrics are a separate33-response stage, all primary/auxiliary
response obligations complete and settings acknowledged, at a raw frame boundary.
Base=33*45064=1487112. Preserve parser, clock and request debt across that boundary.
Allow only known late request refunds, adding13*(remaining connection debt+sum
remaining stream debts); no new request DATA. R<=65 gives at most1690 carried
bytes and absolute maximum1488802, but use actual remaining debt at entry.
Never infer quiescence from END or sleep. A pre-run snapshot, if actually used,
needs its own explicit stage. Extra health/new connections must be enumerated.
See task-5d-credit-order.md for exact raw/event ordering and closed-stream rules.

## Confined positional read and close observation

Pinned Zig SDK std/Io/File.zig576 readPositionalAll loops through readPositional;
506 dispatches fileReadPositional(io.userdata,...);221 dispatches fileClose.
Candidate http/file_transfer.zig15-29 uses those two operations; tcp.zig1105-1109
HEAD/empty transfer also closes via that callback.

Keep original base:std.Io unchanged. Stable final-address state and vtable
override both reachable callbacks. Delegate every argument/result/error unchanged
using base.vtable.fileReadPositional(base.userdata,...) and
base.vtable.fileClose(base.userdata,...), never wrapper userdata. Wrapper is
confined to this FileSource; original init.io handles setup/open/write/stat,
caller-owned cleanup, Server/logging and every unrelated operation. Copied
other vtable callbacks must remain provably unreachable with wrapper userdata.
This is not a general-purpose I/O wrapper.

State/vtable/base backend/separate8192 scratch live through Appdeinit. Counters
only observe ordinary read/close, inject no error, suppress no close and alter
no descriptor. Record calls/requested/returned lengths/offset/errors/close count;
read spans<=8192 within[37,24630). Do not require four reads or total read bytes
24593: short reads and rereads after WouldBlock are valid. Wire hash/length proves
the range. Inline transport close can precede successful stream_file return,
so its callback cannot require a post-return transfer-success flag already set.
Successful return relinquishes caller ownership; every returned error retains
it and caller cleanup uses baseIo. Ordinary success requires one transport close
and no second close through deinit.

Instrumentation remains separately source-review gated before execution.
file_stream_http2_tests.zig360-416 construct native fixtures and transport
pressure; do not run/reconstruct them. Authenticated existing receipts or
separately released pure caller-data callbacks can establish returned-error
public ownership, not native H2 head atomicity. No dummy descriptor to native.
