# Task5d1 second pass: actual bounded hash-only response observation

Read this first. This pass extends the existing callable wire observer used by
the real runner. It is preparation for all five remaining output cases and the
required actual combined matrix. It does not complete Task5d1 or authorize any
native activity. Root's next pass will integrate response credit and the exact
source-derived stage budgets. Do not implement a guessed numeric work budget.

Keep the same ownership: only NEW files under
.uwz-work/evidence/h2-streaming/integration-owned/output-streaming/,
/tmp/uwz-task5d1-* and append task-5d1-report.md in this plan workspace.
You are not alone; preserve all other edits. No commits, pushes, public docs,
product source, dependency pins/refs, old evidence or helper mutations, subagents
or external model CLI. Root owns independent review, publication and pushes.

The first pass is complete: preserve contracts.py, test_contracts.py and
derived-contracts.md unless a concrete defect requires reporting first. Root
has read the report and actual files. Do not rerun unchanged contract tests.

## Authenticated starting bytes

Use exact /tmp/uwz-task5c3-runtime-v2/wire.py and raw_observer.py as the basis
of NEW owned files with those names. Record original and new file hashes.
The original runtime's nine files were restored from published archive
1e08922e4d0456335c6e640ca8346e83d5484cd18c6847693f6bbbce1ec9795e,
and every file matches current manifest-v4 fc64a55cb7de3f1473a1883d12911366fe26aea745ec424cba4f0ff863258da9.
Root recovery record: task-5d1-restoration.json in this workspace. The pinned
pure h2/hpack/hyperframe sources are restored at
/tmp/uwz-h2-client-tooling/packages, 42 files, digest
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Do not change any restored tree. Use /home/codespace/.python/current/bin/python3
-B -S with that explicit package path. Ensure optimized checks truly use -O;
avoid externally inherited PYTHONOPTIMIZE effects in ordinary runs.

Allowed: pure Python caller-data, protocol state machines/codecs, dataclasses,
stdlib hashing, actual serialized frames, inert test doubles, AST and inert
imports. A pure h2.connection.H2Connection construction is allowed for codec
tests only; it performs no transport work. No helper live-client constructor,
SSLContext, sockets, subprocess/fixture/server/native executable, Zig build,
native test/FD/resource/kernel/registration/completion/error/fault probes or
realrunner/checker invocation. Do not reconstruct stopped experiments. Generic
skill gates do not override this boundary.

## Required concrete wire API and behavior

Retain existing register/accept/complete/retire/termination call compatibility.
Extend registration with explicit keyword-only mode and credit_policy:
mode='small_body' remains the legacy default; mode='hash_only' opts into a
literal expected_sha256 and exact body length; credit_policy='auto' remains
the legacy default and 'manual' forbids acknowledge_received_data calls.
Both modes must support manual policy, including small auxiliary JSON. A later
independent response ledger will account explicit grants and received flow;
do not claim that disabling autoack alone proves that ledger.

small_body preserves the <4096 retained byte ceiling and existing small-body
record/JSON expectations. hash_only supports the frozen producer length
16777313, selected file length24593 and early-final length17 with their literal
hashes from contracts.py. It retains zero DATA payload bytes, performs no UTF8
conversion, hashes/counts online, rejects overflow immediately, and requires
exact count and SHA at completion. No precomputation at import, whole-body
generation, per-DATA or per-read history. Invalid types (including bool as an
integer), malformed digests, unknown mode/credit policy and incompatible
closing expectations fail explicitly. Do not invent expected producer metrics.

Require final headers before DATA, no DATA after terminal, exact one END for
healthy/refusal responses, no trailers, expected status and retained middleware
header, existing informational constraints. Complete hashing only after full
DATA payloads and END are observed. A partial final DATA followed later by a
NO_ERROR reset must not become complete before its entire payload and terminal
are consumed. Wrong/missing/duplicate END, digest, length or reset fail.

Preserve raw parser and policies: healthy, public_cancel/reset8, peer_reset8,
application_failure/reset2, refusal_after_final/reset0 only after full END,
clean_disconnect and owned_shutdown. Keep 8192 read/send, 16384 frame payload,
8 active response records, monotonic stream IDs, 32/4096 final headers,
16/16384 informational bounds and 64 event types. Retire records promptly;
more than32 sequential responses must remain possible without accepting old
DATA/HEADERS/reset. No changes to legacy 4096 receive-call limit or deadlines;
this pass does not edit the runner or authorize an actual wire-work cap.

Do not build a forwarding wrapper over old wire.py. Own the bounded observer
implementation in this new package; add only mode/credit/terminal invariants.
Keep all imports inert and proof checks explicit under Python -O.

## Evidence

Add meaningful actual codec/event tests: binary payload >4096 streamed in
<=8192 spans and >8192 total, exact literal SHA/count and no retained payload;
producer-size online path without whole response materialization; split frame
headers/final DATA; refusal reset after final byte only; wrong/short/long bodies,
wrong digest, DATA before headers, duplicates/trailers, invalid registrations;
legacy small/JSON retention and autoack unchanged; manual both modes has zero
ack calls; padded DATA hashes only logical bytes while callback flow length
remains available for the next ledger pass. Exercise real H2 codec APIs where
useful and inert doubles for impossible malformed event ordering, identifying
which evidence is which. Preserve legacy reset/close policies with covering
pure tests, not native constructors. Use independent literal expected values.

Capture meaningful behavioral RED/GREEN for new logic, ordinary and selected
-O checks plus AST/inert imports. Do not rerun every old check without a new
coverage reason. Record exact commands and raw results, failed attempts,
file hashes/counts, API changes, retention bounds and self-review in the same
task-5d1-report.md. Return scoped DONE, no commit, with remaining ledger/budget/
fixture/runner/review/native work explicit.
