# Task5d pinned closed-stream refund ordering

Root adopts the original architect's focused final source ruling after exact
restoration: codec42 digest0f85 and runtime9 from manifestfc64. Source inspection
only, no code/test/native proof. Request-send and response-receive credit are
different directions and must remain separate ledgers.

Pinned h2/connection.py1792-1825: connection WINDOW_UPDATE increments outbound
window and emits WindowUpdated. A removed closed stream's StreamClosedError is
caught without an event. stream.py735 accepts WINDOW_UPDATE in CLOSED without a
state-machine event;1133 updates stream window only when an event exists.
OPEN/HALF_CLOSED states634/666/695 produce window events. Thus both existing and
removed fully closed streams produce no WindowUpdated/window change.

Each completed incoming raw WINDOW_UPDATE is the refund authority. Validate
length4, positive increment, known exact identity and increment<=specific
remaining request-byte debt. Debit debt/credit independent ledger exactly once;
public events only corroborate, never apply refunds a second time.

Predict event presence at that frame's position: connection exactlyone; known
not-fully-closed stream exactlyone; known fully closed stream none. Unknown,
zero/excess or zero-debt refunds fail. Track distinct caller-owned request and
response closure from outgoing END/reset and complete incoming END/reset frames.
Legacy FlowLedger.open means request DATA may still be sent, not fully closed;
do not use it as the full-closure predicate.

Within each bounded receive compare the ordered expected(stream_id,increment)
occurrences to exactly the emitted WindowUpdated subsequence, preserving equal
duplicates/multiplicity. An update before END in the same read requires its
event even if later closed; update after full closure requires no event. Partial
frames cause no refund/event obligation until complete. <=8192 incoming bytes
can complete at most631 13-byte updates including a prior partial frame. Bound
this per-read sequence at631 and retain no cross-read event history.

Request direction public checks: outbound_flow_control_window equals connection
request ledger; for known not-fully-closed streams local_flow_control_window(id)
equals min(connection,stream request credit). Skip closed public stream queries;
retired caller debt still validates late raw updates that H2 deliberately ignores.
Unexpected resets/parser errors remain failures, never missing-event exceptions.

Response direction public checks: inbound_flow_control_window (connection.py464)
is connection receive credit; remote_flow_control_window(id),1318, is min of
connection/stream receive credit, not a raw stream getter. Track acknowledged
client INITIAL_WINDOW_SIZE and explicit outgoing grants plus DATA flow length
including padding independently; hash only logical body bytes.

Response-record retirement and stage changes never clear request debts. Retain
bounded known retired request IDs. At final collection enter at complete raw
frame boundary, no new request DATA; budget1487112+13*(remaining connection debt+
sum remaining stream debt). Unreturned closed debts may remain and are reported,
not asserted refunded. No sleeps/private H2 state/quiescence inference.
