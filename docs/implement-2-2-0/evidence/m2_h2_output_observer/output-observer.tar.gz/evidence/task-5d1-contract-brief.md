# Task5d1 first pass: independent payload and fixture contracts

Read this first: exact requirements for a new Task5d1 preparation owner. This
is the first bounded pass of the hash-only response/response-credit preparation;
after it Root supplies the reviewed wire-work budget and observer integration
brief. Do not implement an unreviewed numeric budget now. All5outputIDs and the
later actualfull40IDcombinedmatrix remain required; this pass closes none.

Own ONLY NEW .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/,
/tmp/uwz-task5d1-* and task-5d1-report.md in thisplanworkspace. You are notalone;
preserveothers. No prior source/evidence/helper edits, product/docs/pins/refs/
commits/push/subagents/externalmodelCLI. Root owns independent review/exactlater
native releases/publication/immediateforkpush. CurrentHEAD5b7a101clean/pushed.

Allowed NOW: purecallerdata/payload/hash/modelcode, Python AST/inertimports and
meaningful pure tests. NO native executable/test/constructor/socket/TLScontext/
client/server/cert/realprocess/FD/resource/kernel/completion/error/faultprobe,
realrunner/checker/nativegate invocation or file creation outside your owned
text artifacts. No Zigfixture/build yet. Generic skill gates do not override
this phase boundary. Do not reconstruct stopped/denied experiments.

Source basis: immutablecandidatefc69(1031files), reviewedC223(93), originalr2C/
sixarchives and previous5c3fixtures/runtime unchanged. Pinned helper
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client/h2_client.py
SHA07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00;
client42files/tmp/uwz-h2-client-tooling/packages
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Use /home/codespace/.python/current/bin/python3 -B -S, no installs. Helper
imports must be inert, no helperclient/nativeconstructor. Use graphify before
new source searches; paths in this brief are located. Narrow skills and project
conventions apply, no newmarkers/deadscaffolding/unbounded retainedpayload.

## Exact independent payload contracts

P32 = bytes1through10 followed by literal final-upload-sentinel!,32total.
H32=7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5.
H7(first7ofP32)=32bbe378a25091502b2baf9f7258c19444e7a43ee4593b08030acd790bd66e6a.
Do not reproduce the architect's corrected1..11typo (would be33bytes).

Eachproducer output N=16777313=2048*8192+97 bytes. For offseti<N-22,
byte1+(i modulo251); last22bytes are final-upload-sentinel!. Future server
usesboundedZigloop, independentclient mayuse immutablehelper or boundedperiodic
byte-slice implementation. Derive/freeze literal fullSHA256 using two independent
bounded implementations and fixed boundary vectors. Do not hash a server result
or retain/generate the entireNpayload in one object. Maximumgeneration span8192;
2049successful8192-or-final97 writes is an independent futureexpectation, no
native timing/write-count claim now. Import must not precompute16MB.

File total24659 uses samepattern(total24659), selectedoffset37,length24593,
selectedend24630/leaves29suffix; selectedlength=3*8192+17. Independently derive
whole-file and selected-range hashes in boundedspans; freeze literal rangehash.
Selectedrange is not the wholefile and does not include final22sentinel.
No real file/descriptor or I/Oobject is opened by this pass; bytes only.

Early middleware final literal early-final-order is17bytes. Freezeits exact
hash and8+9 split prefixearly-fi. Preserve request and response digests separately.

Boundarychecks independently cover start,250/251periodwrap,8192boundary,
N-23/N-22tailtransition/final!, P32first7/suffix and fileoffset/end/final17.
Use exact independently literal vectors plus second algorithm/pinned helper,
not tests calling the same implementation for expected and actual. Invalid
offset/length/overrun and oversize generation spans fail explicitly. Capture
meaningful behavioral RED/GREEN if logic changes; no missingimport as productred.

## Exact fixture and selected-subset models

Sevenusedtags within32records/25untouchedspares:
producer_reuse,producer_reuse_next,output_pressure_window,output_pressure_ready,
stream_file,early_final_order,early_final_recovery.
Five selectablecaseIDs: producer_reuse,output_pressure_window,
output_pressure_ready,stream_file,early_final_order. producer_reuse selects
itsprimary+next; early_final_order selectsrefusal+recovery; othercasesoneeach.

Acceptedbodytags finalMW1/attempt1/begin1/end1/cancel0/failure0/32H32,
metadataMW/begin/end1, activefalse/pausedfalse/reasonnone/errors0. Refusal
MW1/metadataMW1 withallbodyadmission/callback/acceptedcounts0/emptyhash,
activefalse/reasonnone. Unselected/spareszero andemptyhash. Allchunk/invalid/
enderror counters0. Callbackchunkcount/maxspan are actual boundeddiagnostics,
not predetermined packets/callbacksizes. FullselectionMW7/attempt6/B6/E6/C0/
F0/accepted192/active0/errors0. Derive eachsubset independently, rejectbad or
duplicatecaseIDs andidentity/hash/type swaps. Preserve32-bodyrecordschema
from5c3 but do not pretend newproducer/file metrics are already measured.

Newproducercontexts3, own8192scratch and1024metadata store/eight individual
slices+ownedcopies, lifetimeAppdeinit. Filecontext1/separate8192scratch/io/owned
descriptor futureonly. Old callerbodybindings2, native8slots/73728receive,
8connections/writequeue65536 remain unchanged. Any fixturebinding index/gen
witness is application-owned, not native slot proof. Expected producer-state
stages may specify pendingoffset0, prefix8192 and finalN/2049writes/terminal1/
errors0; attempts/pending/blocked actualexceptzero-creditmustobservepositive
WouldBlock+pending. Never create fake measuredcounts from model.

Deliver guardedpuremodules, compact derived-hashes/boundary artifact and tests;
do not touch actualwire/runner yet. Append exactAPI/commands/rawoutputs/failures/
hashes/filecounts/peakgeneration bound/self-review/remainingobserverwork to
task-5d1-report.md. All tools must be inert. Return scopedDONE when contracts/
independenthashes/models complete; fullTask5d1 stillneeds actualhash-onlywire/
responsecredit integration, Rootruling/review and separate preparation gates.
