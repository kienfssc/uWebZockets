# Task5d1 observer checkpoint fix round1/5

Resume same Task5d1 owner. Original contract/observer briefs and sole ownership/
pure-only/no-native boundaries remain binding. This is a fix of the frozen
six-file checkpoint, not a response-credit/budget/fixture/runner implementation.
Preserve /tmp/uwz-task5d1-observer-review-v1 and all old evidence unchanged.
Append commands/raw results and fix report to same task-5d1-report.md. No
commits/push/subagents/external model CLI or other file ownership changes.

Open finding verbatim:

P2 — Preserve refusal completion when the codec suppresses a reset event.
wire.py121-122 now requires reset_event for refusal_after_final. When the client
has sent request END_STREAM, receiving the complete final response closes the
codec stream. A subsequent valid NO_ERROR reset produces no StreamReset: pinned
stream.py737-738 and1230-1236 explicitly suppresses it for closed streams. The
raw observer correctly records the reset, but complete/retire now fails with
missing reset event. Preserve raw full-frame END and reset-code/order validation
without requiring an event the codec legitimately omits. Add actual codec
coverage for this closed-stream sequence; the current test_wire.py151 injects
the missing event through Fake and conceals the regression.

Root confirms source and adopts this as a real compatibility defect, not a
weaker raw reset rule. Keep exact logical count/hash, complete DATA/end before
one NO_ERROR reset, existing other policies/codes and emitted-event validation.
Cover both legitimate closed and still-half-open refusal paths using the actual
pinned pure H2 codec and raw serialized reset where public server state would
otherwise prevent sending a reset on its closed stream. This is bytes-only;
no native objects/sockets/process/resources. Preserve deliberate impossible
ordering doubles as identified tests, not a substitute for actual codec proof.

Capture meaningful actual regression RED on current frozen behavior, GREEN
after fix, covering test_wire.py tests normal/selected -O plus AST/inert checks
for changed files. No unchanged contract rerun or full gates/native. Record
hashes/file diffs and API effect. Root reads actual report/evidence before
same reviewer's scoped re-review. Full Task5d1 and five cases/combined stay open.
