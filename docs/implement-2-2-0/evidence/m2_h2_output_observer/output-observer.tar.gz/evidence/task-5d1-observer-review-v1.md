# Task5d1 observer checkpoint initial independent review

Reviewer /root/review_h2_output_observer, Astra/high, read-only.
SPEC: CHANGES REQUIRED. QUALITY: REQUEST CHANGES.

P2 — Preserve refusal completion when the codec suppresses a reset event.
Frozen wire.py121 now requires reset_event for refusal_after_final. When the
client has sent request END_STREAM, receiving the complete final response closes
the codec stream. A subsequent valid NO_ERROR reset produces no StreamReset:
pinned stream.py737/1230-1236 explicitly suppresses it for closed streams. Raw
observer correctly records the reset, but complete/retire fails with missing
reset event. Preserve raw full-frame END and reset-code/order validation without
requiring an event the codec legitimately omits. Add actual codec coverage;
current test_wire.py151 injects the missing event through Fake and conceals the
regression.

No additional actionable contracts/ownership/security/conventions/structural
findings. Recorded tests/mutations inspected, not rerun. Producer-size/refusal
ordering use event doubles; actual codec did not cover closed-stream refusal.
Ledger/budget/fixture/runner/native/five cases/combined remain open as scoped.
Scope: frozen six-file checkpoint, identity map, authenticated runtime basis,
both briefs, actual report/evidence and pinned codec source. No edits/checks/
native activity.
