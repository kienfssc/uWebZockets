"""Pure codec and event checks; no transport or native handles."""
import unittest
import h2.config
import h2.connection
import h2.events
import wire
import raw_observer
import contracts


def pair():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    client.initiate_connection()
    server.initiate_connection()
    server.receive_data(client.data_to_send())
    client.receive_data(server.data_to_send())
    server.receive_data(client.data_to_send())
    client.send_headers(1, [(':method', 'GET'), (':scheme', 'https'), (':authority', 'x'), (':path', '/')], end_stream=True)
    server.receive_data(client.data_to_send())
    return client, server


def headers(server):
    server.send_headers(1, [(':status', '200'), ('x-middleware', 'retained')])
    return server.data_to_send()


def frame(kind, flags, payload=b'', stream=1):
    return len(payload).to_bytes(3, 'big') + bytes((kind, flags)) + stream.to_bytes(4, 'big') + payload


class Fake:
    def __init__(self, events):
        self.events = events
        self.acks = []
    def receive_data(self, data):
        result, self.events = self.events, []
        return result
    def acknowledge_received_data(self, length, stream):
        self.acks.append((length, stream))


def event(cls, stream=1, **values):
    item = cls(stream_id=stream)
    for key, value in values.items(): setattr(item, key, value)
    return item


class WireTests(unittest.TestCase):
    def setup_record(self, length=0, policy='healthy', **kw):
        records, raw = {}, raw_observer.new_state()
        wire.register(records, raw, 1, length, 200, 0, policy, **kw)
        return records, raw

    def test_real_codec_manual_hash_and_split(self):
        client, server = pair()
        records, raw = self.setup_record(10000, mode='hash_only', credit_policy='manual', expected_sha256='27dd1f61b867b6a0f6e9d8a41c43231de52107e53ae424de8f847b821db4b711')
        trace = {}
        head = headers(server)
        wire.accept(client, head[:3], records, raw, trace)
        wire.accept(client, head[3:], records, raw, trace)
        for size in (5000, 5000):
            server.send_data(1, b'a' * size, end_stream=size == 5000 and records[1]['bytes'] == 5000)
            encoded = server.data_to_send()
            wire.accept(client, encoded[:8], records, raw, trace)
            if records[1]['bytes'] == 5000:
                with self.assertRaises(ValueError): wire.complete(records, raw, 1)
            wire.accept(client, encoded[8:], records, raw, trace)
        wire.complete(records, raw, 1)
        self.assertEqual(records[1]['body'], bytearray())
        self.assertEqual(records[1]['bytes'], 10000)
        wire.retire(records, raw, 1)

    def test_producer_stream_online(self):
        records, raw = self.setup_record(contracts.TOTAL, mode='hash_only', credit_policy='manual', expected_sha256=contracts.PRODUCER_HASH)
        trace = {}
        f = Fake([event(h2.events.ResponseReceived, headers=[(':status','200'),('x-middleware','retained')])])
        wire.accept(f, frame(1, 4, b'x'), records, raw, trace)
        for pos in range(0, contracts.TOTAL, 8192):
            part = contracts.span(contracts.TOTAL, pos, min(8192, contracts.TOTAL - pos))
            final = pos + len(part) == contracts.TOTAL
            f.events = [event(h2.events.DataReceived, data=part, flow_controlled_length=len(part))]
            if final: f.events.append(event(h2.events.StreamEnded))
            encoded = frame(0, int(final), part)
            wire.accept(f, encoded[:8192], records, raw, trace)
            if len(encoded) > 8192: wire.accept(f, encoded[8192:], records, raw, trace)
        wire.complete(records, raw, 1)
        self.assertEqual(records[1]['body'], bytearray())
        self.assertEqual(f.acks, [])

    def test_small_auto_and_manual_padded(self):
        for policy in ('auto', 'manual'):
            records, raw = self.setup_record(3, credit_policy=policy)
            f = Fake([event(h2.events.ResponseReceived, headers=[(':status','200'),('x-middleware','retained')])])
            wire.accept(f, frame(1, 4, b'x'), records, raw, {})
            f.events = [event(h2.events.DataReceived, data=b'abc', flow_controlled_length=6), event(h2.events.StreamEnded)]
            wire.accept(f, frame(0, 9, b'\x02abc\0\0'), records, raw, {})
            wire.complete(records, raw, 1)
            self.assertEqual(bytes(records[1]['body']), b'abc')
            self.assertEqual(f.acks, [(6, 1)] if policy == 'auto' else [])

    def test_frozen_range_and_early_responses(self):
        for length, expected, kind in ((24593, '8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac', 'range'), (17, 'd826bcf95ee8850cecb39accdeb84b32336a0415411938da42da7edcac891da7', 'early')):
            records, raw = self.setup_record(length, mode='hash_only', credit_policy='manual', expected_sha256=expected)
            f = Fake([event(h2.events.ResponseReceived, headers=[(':status','200'),('x-middleware','retained')])])
            wire.accept(f, frame(1, 4, b'x'), records, raw, {})
            for pos in range(0, length, 4096):
                size = min(4096, length - pos)
                data = contracts.span(24659, 37 + pos, size) if kind == 'range' else b'early-final-order'[pos:pos + size]
                final = pos + size == length
                f.events = [event(h2.events.DataReceived, data=data, flow_controlled_length=size)]
                if final: f.events.append(event(h2.events.StreamEnded))
                wire.accept(f, frame(0, int(final), data), records, raw, {})
            wire.complete(records, raw, 1)
            self.assertEqual(records[1]['body'], bytearray())
            self.assertEqual(f.acks, [])

    def test_invalid_registration(self):
        for kw in ({'mode':'bad'}, {'credit_policy':'bad'}, {'mode':'hash_only', 'expected_sha256':'F'*64}, {'expected_sha256':'0'*64}, {'mode':'hash_only', 'expected_sha256':'0'*64, 'policy':'public_cancel'}):
            policy = kw.pop('policy', 'healthy')
            with self.assertRaises(ValueError): self.setup_record(1, policy, **kw)
        for val in (True, -1, 16777314):
            with self.assertRaises(ValueError): self.setup_record(val)

    def test_inert_bad_events(self):
        for events in ([event(h2.events.DataReceived, data=b'a', flow_controlled_length=1)], [event(h2.events.StreamEnded)], [event(h2.events.TrailersReceived, headers=[])], [event(h2.events.ResponseReceived, headers=[(':status','200'),('x-middleware','retained')]), event(h2.events.ResponseReceived, headers=[(':status','200'),('x-middleware','retained')])]):
            records, raw = self.setup_record(3)
            with self.assertRaises(ValueError): wire.accept(Fake(events), b'', records, raw, {})

    def test_wrong_length_digest_and_overflow(self):
        for length, digest, data in ((4, '0'*64, b'abc'), (3, '0'*64, b'abc'), (2, '0'*64, b'abc')):
            records, raw = self.setup_record(length, mode='hash_only', expected_sha256=digest)
            f = Fake([event(h2.events.ResponseReceived, headers=[(':status','200'),('x-middleware','retained')])])
            wire.accept(f, frame(1, 4, b'x'), records, raw, {})
            f.events = [event(h2.events.DataReceived, data=data, flow_controlled_length=len(data)), event(h2.events.StreamEnded)]
            with self.assertRaises(ValueError):
                wire.accept(f, frame(0, 1, data), records, raw, {})
                wire.complete(records, raw, 1)

    def test_refusal_partial_and_reset(self):
        records, raw = self.setup_record(3, 'refusal_after_final', mode='hash_only', expected_sha256='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
        f = Fake([event(h2.events.ResponseReceived, headers=[(':status','200'),('x-middleware','retained')])])
        wire.accept(f, frame(1, 4, b'x'), records, raw, {})
        data = frame(0, 1, b'abc')
        f.events = [event(h2.events.DataReceived, data=b'abc', flow_controlled_length=3), event(h2.events.StreamEnded)]
        wire.accept(f, data[:-1], records, raw, {})
        with self.assertRaises(ValueError): wire.complete(records, raw, 1)
        wire.accept(f, data[-1:], records, raw, {})
        with self.assertRaises(ValueError): wire.complete(records, raw, 1)
        f.events = [event(h2.events.StreamReset, error_code=0)]
        wire.accept(f, frame(3, 0, bytes(4)), records, raw, {})
        wire.retire(records, raw, 1)

    def test_reset_and_close_policies(self):
        for policy, code in (('public_cancel', 8), ('application_failure', 2)):
            records, raw = self.setup_record(0, policy)
            f = Fake([event(h2.events.StreamReset, error_code=code)])
            wire.accept(f, frame(3, 0, code.to_bytes(4, 'big')), records, raw, {})
            wire.retire(records, raw, 1)
        records, raw = self.setup_record(0, 'peer_reset')
        raw_observer.mark_peer_reset(raw, 1, 8)
        wire.retire(records, raw, 1)
        for policy, phase, outcome in (('clean_disconnect', 'pre_unwrap', {'method':'ssl_unwrap','tls_shutdown':'success','tcp_eof':True,'trailing_bytes':0,'close':'normal'}), ('owned_shutdown', 'post_signal', 'eof')):
            records, raw = self.setup_record(0, policy)
            wire.begin_termination(records, raw, 1, policy, phase)
            self.assertEqual(wire.finish_termination(records, raw, 1, policy, phase, outcome)['kind'], 'local_transport_only')
        records, raw = self.setup_record(0, 'clean_disconnect')
        with self.assertRaises(ValueError): wire.accept(Fake([]), frame(0, 1), records, raw, {})
        records, raw = self.setup_record(0, 'refusal_after_final')
        with self.assertRaises(ValueError): wire.accept(Fake([]), frame(3, 0, bytes(4)), records, raw, {})

    def test_retirement_and_old_stream(self):
        records, raw = {}, raw_observer.new_state()
        for stream in range(1, 81, 2):
            wire.register(records, raw, stream, 0, 200, 0, 'healthy')
            f = Fake([event(h2.events.ResponseReceived, stream, headers=[(':status','200'),('x-middleware','retained')]), event(h2.events.StreamEnded, stream)])
            wire.accept(f, frame(1, 5, b'x', stream), records, raw, {})
            wire.retire(records, raw, stream)
        for kind, payload in ((0,b'x'), (1,b'x'), (3,bytes(4))):
            with self.assertRaises(ValueError): raw_observer.observe(raw, frame(kind, 0, payload))

    def test_real_codec_padded_data(self):
        client, server = pair()
        records, raw = self.setup_record(3, mode='hash_only', credit_policy='manual', expected_sha256='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
        wire.accept(client, headers(server), records, raw, {})
        server.send_data(1, b'abc', end_stream=True, pad_length=2)
        events = wire.accept(client, server.data_to_send(), records, raw, {})
        data = [item for item in events if isinstance(item, h2.events.DataReceived)]
        self.assertEqual((data[0].data, data[0].flow_controlled_length), (b'abc', 6))
        wire.complete(records, raw, 1)
        self.assertEqual(records[1]['body'], bytearray())

    def test_manual_hash_padded_and_json(self):
        records, raw = self.setup_record(3, mode='hash_only', credit_policy='manual', expected_sha256='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
        f = Fake([event(h2.events.ResponseReceived, headers=[(':status','200'),('x-middleware','retained')])])
        wire.accept(f, frame(1, 4, b'x'), records, raw, {})
        f.events = [event(h2.events.DataReceived, data=b'abc', flow_controlled_length=6), event(h2.events.StreamEnded)]
        events = wire.accept(f, frame(0, 9, b'\x02abc\0\0'), records, raw, {})
        wire.complete(records, raw, 1)
        self.assertEqual(events[0].flow_controlled_length, 6)
        self.assertEqual(f.acks, [])
        self.assertEqual(records[1]['body'], bytearray())
        import json
        records, raw = self.setup_record(7)
        f = Fake([event(h2.events.ResponseReceived, headers=[(':status','200'),('x-middleware','retained')])])
        wire.accept(f, frame(1, 4, b'x'), records, raw, {})
        f.events = [event(h2.events.DataReceived, data=b'{"x":1}', flow_controlled_length=7), event(h2.events.StreamEnded)]
        wire.accept(f, frame(0, 1, b'{"x":1}'), records, raw, {})
        self.assertEqual(json.loads(records[1]['body']), {'x':1})

if __name__ == '__main__': unittest.main()
