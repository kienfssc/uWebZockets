from pathlib import Path
import json,subprocess,hashlib,time,os,sys
root=Path('/workspaces/uWebZockets');d=root/'.uwz-work/drafts/libxev-udp-fix';out=Path(__file__).resolve().parent;zig='/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig';env=os.environ.copy();env['ZIG_GLOBAL_CACHE_DIR']=str(root/'.uwz-work/evidence/libxev-udp-fix/cache-global');paths=subprocess.check_output(['git','ls-files','-z'],cwd=d).decode().split('\0');paths=[n for n in paths if n and (d/n).is_file()]
def hashes():return {n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in paths}
expected='6c0423ad7161c435f30b84fefd57853246657a4bd21accdaceedf6689e966bc9';assert hashlib.sha256((d/'src/backend/epoll.zig').read_bytes()).hexdigest()==expected
for label,flags in [('pure-Debug',['-Dtest-filter=duplicate decision']),('pure-ReleaseSafe',['-Dtest-filter=duplicate decision','-Doptimize=ReleaseSafe']),('healthy-Debug',[]),('healthy-ReleaseSafe',['-Doptimize=ReleaseSafe'])]:
 a=[zig,'build','test',*flags,'-j2','--summary','all'];rec={'argv':a,'cwd':str(d),'ZIG_GLOBAL_CACHE_DIR':env['ZIG_GLOBAL_CACHE_DIR'],'reviewed_candidate_tree':'e13b3948e95075cd1245b25a872fa714045ba95e','all_source_before':hashes()};(out/(label+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print('START',label,flush=True);start=time.monotonic()
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(a,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
 rec.update(exit_status=r.returncode,elapsed_seconds=time.monotonic()-start,all_source_after=hashes());(out/(label+'.json')).write_text(json.dumps(rec,indent=2)+'\n');assert rec['all_source_before']==rec['all_source_after'];print('END',label,r.returncode,round(rec['elapsed_seconds'],2),flush=True);print((out/(label+'.log')).read_text()[-4000:],flush=True)
 if r.returncode:sys.exit(r.returncode)
