# Independently reviewed registered-duplicate cleanup

Local append commit 29490914cf58b24d7ab32ca5349f9a03a910435f, parent 7b7b1f14518d9504b15590d123ec494b8fadb2e3, tree e13b3948e95075cd1245b25a872fa714045ba95e. This is the exact prior source-only candidate, now independently source-reviewed and verified without a source change. The reviewer permitted its two pure decision tests and unchanged healthy suite.

Each duplicate-decision filter passes 28 cases in Debug and ReleaseSafe: the two named actual-decision tests plus existing declaration/discovery cases. The healthy suite passes 151 tests with four existing skips in both modes (155 total). Sources stay unchanged throughout. Formatting and whitespace checks pass. No new native cancellation/interleaving/race/crash/leak probe, invalid descriptor, resource exhaustion or injected completion was added or run. The earlier stopped experiment stays stopped. Healthy existing tests do not establish a native leak or race result.

registered-duplicate-cleanup.bundle includes complete reachable history, verifies and restores exact commit/tree in an empty repository, and passes strict fsck. source.tar.gz is the exact candidate source tree. Neither archive is applied to the normal root build. No root pin, maintained ref, branch protection, tag or publication changed. Root's feature branch carries this recovery/review package for the user's later manual review.

The bounded result concerns private-active registered non-worker duplicated descriptors only. Generic adding/deleting/worker cancellation and the complete H1 retirement design remain outside this correction. Further fresh R3 review found a separate IOCP error-mapping prerequisite and an io_uring result classification gap; this epoll patch makes no claim to resolve those.
