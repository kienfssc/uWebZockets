from pathlib import Path
import tarfile,hashlib,io,json,gzip,re,os
root=Path('/workspaces/uWebZockets');e=Path(__file__).resolve().parent;out=root/'docs/implement-2-2-0/evidence/m3_libxev_dup_verified';out.mkdir(parents=True,exist_ok=True);candidate=json.loads((e/'candidate.json').read_text());files={}
for p in e.iterdir():
 if p.is_file():files[p.name]=p.read_bytes()
files['SCOPE.md']=b'''# Independently reviewed registered-duplicate cleanup

Local append commit 29490914cf58b24d7ab32ca5349f9a03a910435f, parent 7b7b1f14518d9504b15590d123ec494b8fadb2e3, tree e13b3948e95075cd1245b25a872fa714045ba95e. This is the exact prior source-only candidate, now independently source-reviewed and verified without a source change. The reviewer permitted its two pure decision tests and unchanged healthy suite.

Each duplicate-decision filter passes 28 cases in Debug and ReleaseSafe: the two named actual-decision tests plus existing declaration/discovery cases. The healthy suite passes 151 tests with four existing skips in both modes (155 total). Sources stay unchanged throughout. Formatting and whitespace checks pass. No new native cancellation/interleaving/race/crash/leak probe, invalid descriptor, resource exhaustion or injected completion was added or run. The earlier stopped experiment stays stopped. Healthy existing tests do not establish a native leak or race result.

registered-duplicate-cleanup.bundle includes complete reachable history, verifies and restores exact commit/tree in an empty repository, and passes strict fsck. source.tar.gz is the exact candidate source tree. Neither archive is applied to the normal root build. No root pin, maintained ref, branch protection, tag or publication changed. Root's feature branch carries this recovery/review package for the user's later manual review.

The bounded result concerns private-active registered non-worker duplicated descriptors only. Generic adding/deleting/worker cancellation and the complete H1 retirement design remain outside this correction. Further fresh R3 review found a separate IOCP error-mapping prerequisite and an io_uring result classification gap; this epoll patch makes no claim to resolve those.
'''
patterns=[re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}'),re.compile(rb'github_pat_[A-Za-z0-9_]{20,}')];secrets=[v.encode() for k,v in os.environ.items() if re.search('TOKEN|SECRET|PASSWORD|API_KEY',k) and len(v)>=16]
for n,b in files.items():
 if any(p.search(b) for p in patterns) or any(s in b for s in secrets):raise SystemExit('credential scan match '+n)
with tarfile.open(e/'source.tar.gz') as t:
 for m in t.getmembers():
  assert not m.name.startswith('/') and '..' not in Path(m.name).parts
  if m.isfile():
   b=t.extractfile(m).read()
   if any(p.search(b) for p in patterns) or any(s in b for s in secrets):raise SystemExit('decoded credential scan match '+m.name)
inv={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in sorted(files.items())};files['INVENTORY.json']=(json.dumps(inv,indent=2)+'\n').encode();a=out/'reviewed-duplicate-cleanup.tar.gz'
with a.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for n,b in sorted(files.items()):
    q=tarfile.TarInfo('reviewed-duplicate-cleanup/'+n);q.mode=0o644;q.size=len(b);t.addfile(q,io.BytesIO(b))
with tarfile.open(a) as t:
 for m in t.getmembers():
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  assert t.extractfile(m).read()==files[m.name.removeprefix('reviewed-duplicate-cleanup/')]
summary={'date':'2026-10-27','scope':'Independently reviewed local epoll candidate, pure decisions and unchanged healthy verification only','archive':a.name,'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'archive_bytes':a.stat().st_size,'safe_regular_members':len(files),'inventory_entries':len(inv),'candidate':candidate,'credential_scan':'Outer retained bytes and decoded source have no matching environment credential values or GitHub token patterns; packed historical Git objects not exhaustively decoded','files':inv};(out/'manifest.json').write_text(json.dumps(summary,indent=2)+'\n');print({k:v for k,v in summary.items() if k not in ['files','candidate']})
