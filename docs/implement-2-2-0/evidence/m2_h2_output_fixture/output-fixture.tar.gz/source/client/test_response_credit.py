from test_support import check_equal, check_true, expect_error, run
from types import SimpleNamespace
import sys
'Offline codec and pure receive-credit tests.'
import h2.config
import h2.connection
import h2.events
import h2.exceptions
from h2.settings import SettingCodes, ChangedSetting
import raw_observer
import response_credit as credit
import wire

def setup_codec():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    records, raw, trace, ledger = ({}, raw_observer.new_state(), {}, credit.new_state())
    client.initiate_connection()
    credit.settings_sent(ledger, 65535, initial=True)
    server.initiate_connection()
    server.receive_data(client.data_to_send())
    wire.accept(client, server.data_to_send(), records, raw, trace, credit=ledger)
    server.receive_data(client.data_to_send())
    return (client, server, records, raw, trace, ledger)

def open_stream(client, server, records, raw, ledger, stream_id=1, length=17, digest='d826bcf95ee8850cecb39accdeb84b32336a0415411938da42da7edcac891da7'):
    client.send_headers(stream_id, [(':method', 'GET'), (':scheme', 'https'), (':authority', 'x'), (':path', '/')], end_stream=False)
    server.receive_data(client.data_to_send())
    credit.open_stream(ledger, stream_id)
    wire.register(records, raw, stream_id, length, 200, 0, 'healthy', mode='hash_only', credit_policy='manual', expected_sha256=digest)

def change_window(client, server, records, raw, trace, ledger, value):
    client.update_settings({SettingCodes.INITIAL_WINDOW_SIZE: value})
    credit.settings_sent(ledger, value)
    server.receive_data(client.data_to_send())
    wire.accept(client, server.data_to_send(), records, raw, trace, credit=ledger)

def grant(client, server, ledger, stream_id, amount):
    client.increment_flow_control_window(amount, stream_id=stream_id or None)
    credit.grant(ledger, stream_id, amount)
    server.receive_data(client.data_to_send())

def headers(server, client, records, raw, trace, ledger):
    server.send_headers(1, [(':status', '200'), ('x-middleware', 'retained')])
    wire.accept(client, server.data_to_send(), records, raw, trace, credit=ledger)

def ack(old=None, new=None):
    event = h2.events.SettingsAcknowledged()
    if old is not None:
        event.changed_settings[SettingCodes.INITIAL_WINDOW_SIZE] = ChangedSetting(SettingCodes.INITIAL_WINDOW_SIZE, old, new)
    return event

def ready():
    state = credit.new_state()
    credit.settings_sent(state, 65535, initial=True)
    credit.settings_acknowledged(state, ack())
    return state

def test_real_ack_stages_and_early_response():
    client, server, records, raw, trace, state = setup_codec()
    check_true(state['initial_acked'])
    open_stream(client, server, records, raw, state)
    credit.compare_public(state, client, [1])
    client.update_settings({SettingCodes.INITIAL_WINDOW_SIZE: 0})
    credit.settings_sent(state, 0)
    check_equal(state['streams'][1]['window'], 65535)
    server.receive_data(client.data_to_send())
    wire.accept(client, server.data_to_send(), records, raw, trace, credit=state)
    check_equal(state['streams'][1]['window'], 0)
    credit.compare_public(state, client, [1])
    headers(server, client, records, raw, trace, state)
    for amount, data, final in ((8, b'early-fi', False), (9, b'nal-order', True)):
        grant(client, server, state, 1, amount)
        credit.compare_public(state, client, [1])
        server.send_data(1, data, end_stream=final)
        wire.accept(client, server.data_to_send(), records, raw, trace, credit=state)
        credit.compare_public(state, client, [1])
    check_equal((state['logical_bytes'], state['flow_bytes'], state['streams'][1]['window']), (17, 17, 0))
    wire.retire(records, raw, 1)
    credit.retire(state, 1)
    check_equal(state['streams'], {})

def test_real_8192_and_padded():
    client, server, records, raw, trace, state = setup_codec()
    open_stream(client, server, records, raw, state, length=17)
    change_window(client, server, records, raw, trace, state, 0)
    grant(client, server, state, 1, 8192)
    credit.compare_public(state, client, [1])
    headers(server, client, records, raw, trace, state)
    server.send_data(1, b'early-final-order', end_stream=True, pad_length=2)
    events = wire.accept(client, server.data_to_send(), records, raw, trace, credit=state)
    data = next((e for e in events if isinstance(e, h2.events.DataReceived)))
    check_equal((len(data.data), data.flow_controlled_length), (17, 20))
    check_equal((state['logical_bytes'], state['flow_bytes'], state['streams'][1]['window']), (17, 20, 8172))
    credit.compare_public(state, client, [1])
    wire.complete(records, raw, 1)

def test_actual_staged_8192():
    client, server, records, raw, trace, state = setup_codec()
    open_stream(client, server, records, raw, state, length=8193, digest='9c10c48d1f1d6618db88fde2c25409181c9201ed34ec6815d62bcf57c10d177b')
    change_window(client, server, records, raw, trace, state, 0)
    headers(server, client, records, raw, trace, state)
    grant(client, server, state, 1, 8192)
    server.send_data(1, b'a' * 8192)
    encoded = server.data_to_send()
    wire.accept(client, encoded[:8192], records, raw, trace, credit=state)
    wire.accept(client, encoded[8192:], records, raw, trace, credit=state)
    check_equal(state['streams'][1]['window'], 0)
    credit.compare_public(state, client, [1])
    with expect_error(h2.exceptions.FlowControlError):
        server.send_data(1, b'a')
    grant(client, server, state, 1, 1)
    server.send_data(1, b'a', end_stream=True)
    wire.accept(client, server.data_to_send(), records, raw, trace, credit=state)
    wire.complete(records, raw, 1)

def test_actual_connection_exhaustion_and_grant():
    client, server, records, raw, trace, state = setup_codec()
    open_stream(client, server, records, raw, state, length=65536, digest='bf718b6f653bebc184e1479f1935b8da974d701b893afcf49e701f3e2f9f9c5a')
    headers(server, client, records, raw, trace, state)
    grant(client, server, state, 1, 1)
    for offset in range(0, 65535, 8192):
        size = min(8192, 65535 - offset)
        server.send_data(1, b'a' * size)
        encoded = server.data_to_send()
        wire.accept(client, encoded[:8192], records, raw, trace, credit=state)
        wire.accept(client, encoded[8192:], records, raw, trace, credit=state)
    check_equal((state['connection'], state['streams'][1]['window']), (0, 1))
    credit.compare_public(state, client, [1])
    with expect_error(h2.exceptions.FlowControlError):
        server.send_data(1, b'a')
    grant(client, server, state, 0, 1)
    credit.compare_public(state, client, [1])
    server.send_data(1, b'a', end_stream=True)
    wire.accept(client, server.data_to_send(), records, raw, trace, credit=state)
    wire.complete(records, raw, 1)
    client.end_stream(1)
    credit.compare_public(state, client, [])
    with expect_error(ValueError):
        credit.receive(state, 1, 0, 0)
    credit.retire(state, 1)

def test_settings_and_negative():
    state = ready()
    credit.open_stream(state, 1)
    credit.receive(state, 1, 10, 10)
    credit.settings_sent(state, 0)
    check_equal(state['streams'][1]['window'], 65525)
    credit.settings_acknowledged(state, ack(65535, 0))
    check_equal(state['streams'][1]['window'], -10)
    credit.receive(state, 1, 0, 0)
    with expect_error(ValueError):
        credit.receive(state, 1, 1, 1)
    credit.grant(state, 1, 11)
    credit.receive(state, 1, 1, 1)
    with expect_error(ValueError):
        credit.settings_acknowledged(state, ack())

def test_invalid_inputs_and_exhaustion():
    state = ready()
    for value in (True, -1, 2147483648):
        with expect_error(ValueError):
            credit.settings_sent(state, value)
    for value in (True, 0, 2, -1):
        with expect_error(ValueError):
            credit.open_stream(state, value)
    credit.open_stream(state, 1)
    for sid, inc in ((True, 1), (1, True), (1, 0), (0, 2147483647), (3, 1)):
        with expect_error(ValueError):
            credit.grant(state, sid, inc)
    for sid, logical, flow in ((3, 0, 0), (1, True, 1), (1, 2, 1), (1, 65536, 65536)):
        with expect_error(ValueError):
            credit.receive(state, sid, logical, flow)
    credit.receive(state, 1, 65535, 65535)
    with expect_error(ValueError):
        credit.receive(state, 1, 1, 1)
    credit.grant(state, 0, 1)
    with expect_error(ValueError):
        credit.receive(state, 1, 1, 1)
    credit.grant(state, 1, 1)
    credit.receive(state, 1, 1, 1)
    credit.end_response(state, 1)
    with expect_error(ValueError):
        credit.receive(state, 1, 0, 0)
    credit.retire(state, 1)
    with expect_error(ValueError):
        credit.open_stream(state, 1)

def test_bad_ack_and_public_mismatch():
    state = ready()
    credit.open_stream(state, 1)
    credit.settings_sent(state, 0)
    for event in (ack(), ack(1, 0), ack(65535, 1)):
        with expect_error(ValueError):
            credit.settings_acknowledged(state, event)
    credit.settings_acknowledged(state, ack(65535, 0))
    public = SimpleNamespace(inbound_flow_control_window=65535, remote_flow_control_window=lambda stream_id: 1)
    with expect_error(ValueError):
        credit.compare_public(state, public, [1])
    public.inbound_flow_control_window = 65534
    with expect_error(ValueError):
        credit.compare_public(state, public, [])

def test_bounded_streams_and_pending():
    state = credit.new_state()
    with expect_error(ValueError):
        credit.open_stream(state, 1)
    credit.settings_sent(state, 65535, initial=True)
    with expect_error(ValueError):
        credit.settings_sent(state, 0)
    credit.settings_acknowledged(state, ack(65535, 65535))
    for stream_id in range(1, 16, 2):
        credit.open_stream(state, stream_id)
    with expect_error(ValueError):
        credit.open_stream(state, 17)
    credit.end_response(state, 1)
    credit.retire(state, 1)
    credit.open_stream(state, 17)
    with expect_error(ValueError):
        credit.open_stream(state, 1)
    with expect_error(ValueError):
        credit.grant(state, 3, 2147483647)
    with expect_error(ValueError):
        credit.retire(state, 3)

def test_wire_requires_manual():
    client, server, records, raw, trace, state = setup_codec()
    wire.register(records, raw, 1, 0, 200, 0, 'healthy')
    with expect_error(ValueError):
        wire.accept(client, b'', records, raw, trace, credit=state)
if __name__ == '__main__':
    run(globals(), sys.argv[1:])
