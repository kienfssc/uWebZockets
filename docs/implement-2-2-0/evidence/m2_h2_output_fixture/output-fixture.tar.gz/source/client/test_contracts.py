from test_support import check_equal, expect_error, run
import sys
import hashlib
import itertools
import contracts as c

def independent_digest(total, start, length):
    period = bytes(range(1, 252))
    h = hashlib.sha256()
    for pos in range(start, start + length, 8192):
        n = min(8192, start + length - pos)
        count = max(0, min(n, total - 22 - pos))
        rotated = period[pos % 251:] + period[:pos % 251]
        prefix = rotated * (count // 251) + rotated[:count % 251]
        tail_start = max(0, pos + count - (total - 22))
        tail_end = max(0, pos + n - (total - 22))
        chunk = prefix + b'final-upload-sentinel!'[tail_start:tail_end]
        if len(chunk) != n or len(chunk) > 8192:
            raise ValueError('independent span')
        h.update(chunk)
    return h.hexdigest()

def test_hashes():
    check_equal(len(c.P32), 32)
    check_equal(hashlib.sha256(c.P32).hexdigest(), c.H32)
    check_equal(hashlib.sha256(c.P32[:7]).hexdigest(), '32bbe378a25091502b2baf9f7258c19444e7a43ee4593b08030acd790bd66e6a')
    check_equal(c.P32[10:], b'final-upload-sentinel!')
    check_equal((len(c.EARLY), c.EARLY[:8], c.EARLY[8:]), (17, b'early-fi', b'nal-order'))
    check_equal(hashlib.sha256(c.EARLY).hexdigest(), c.EARLY_HASH)
    for total, start, length, expected in ((c.TOTAL, 0, c.TOTAL, c.PRODUCER_HASH), (c.FILE_TOTAL, 0, c.FILE_TOTAL, c.FILE_HASH), (c.FILE_TOTAL, c.FILE_OFFSET, c.FILE_LENGTH, c.RANGE_HASH)):
        check_equal(independent_digest(total, start, length), expected)
        check_equal(c.digest(total, start, length), expected)

def test_boundaries():
    for total, start, length, expected in ((c.TOTAL, 0, 12, '0102030405060708090a0b0c'), (c.TOTAL, 249, 4, 'fafb0102'), (c.TOTAL, 8189, 7, '9e9fa0a1a2a3a4'), (c.TOTAL, c.TOTAL - 23, 23, 'c866696e616c2d75706c6f61642d73656e74696e656c21'), (c.FILE_TOTAL, 37, 8, '262728292a2b2c2d'), (c.FILE_TOTAL, 24613, 17, '101112131415161718191a1b1c1d1e1f20'), (c.FILE_TOTAL, 24630, 29, '2122232425262766696e616c2d75706c6f61642d73656e74696e656c21')):
        check_equal(c.span(total, start, length).hex(), expected)
    check_equal(c.FILE_OFFSET + c.FILE_LENGTH, 24630)
    check_equal(c.FILE_TOTAL - 24630, 29)
    check_equal(divmod(c.TOTAL, 8192), (2048, 97))

def test_invalid():
    for args in [(c.TOTAL, -1, 1), (c.TOTAL, 0, 8193), (c.TOTAL, c.TOTAL, 1), (c.TOTAL, True, 1), (21, 0, 0), (c.TOTAL, 0, -1)]:
        with expect_error(ValueError):
            c.span(*args)
    for args in [(c.TOTAL, -1, 0), (c.TOTAL, c.TOTAL, 1), (c.TOTAL, 0, -1)]:
        with expect_error(ValueError):
            c.digest(*args)

def test_all_subsets():
    for mask in itertools.product((False, True), repeat=5):
        ids = [case for case, chosen in zip(c.CASES, mask) if chosen]
        rows = c.expected_records(ids)
        chosen_tags = {tag for case in ids for tag in c.CASES[case]}
        check_equal(sum((r['middleware'] for r in rows)), len(chosen_tags))
        check_equal(sum((r['bytes'] for r in rows)), 32 * (len(chosen_tags) - int('early_final_order' in chosen_tags)))
        for row in rows:
            if row['chunks'] is None:
                row['chunks'], row['max_span'] = (1, 32)
        c.validate_records(ids, rows)
    check_equal(len(c.TAGS), 32)
    check_equal(len(set(c.TAGS)), 32)
    rows = c.expected_records(list(c.CASES))
    check_equal(tuple((sum((r[k] for r in rows)) for k in ('middleware', 'attempts', 'begins', 'ends', 'cancels', 'failures', 'bytes', 'active', 'errors'))), (7, 6, 6, 6, 0, 0, 192, 0, 0))
    for ids in (['wrong'], ['producer_reuse'] * 2, [True]):
        with expect_error(ValueError):
            c.expected_records(ids)

def test_reject_swaps():
    ids = ['producer_reuse']
    for key, value in (('tag', 'producer_reuse_next'), ('sha256', c.EMPTY_HASH), ('bytes', True), ('chunks', 0), ('max_span', 33), ('reason', 'none')):
        rows = c.expected_records(ids)
        for row in rows:
            if row['chunks'] is None:
                row['chunks'], row['max_span'] = (1, 32)
        rows[0][key] = value
        with expect_error(ValueError):
            c.validate_records(ids, rows)
if __name__ == '__main__':
    run(globals(), sys.argv[1:])
