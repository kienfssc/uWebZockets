"""Function-based checks and visible, caller-owned pure codec probes."""
from contextlib import contextmanager
from types import SimpleNamespace


def check_equal(actual, expected):
    if actual != expected:
        raise AssertionError('%r != %r' % (actual, expected))


def check_true(value):
    if not value:
        raise AssertionError('expected true: %r' % (value,))


def check_false(value):
    if value:
        raise AssertionError('expected false: %r' % (value,))


def check_not_in(value, container):
    if value in container:
        raise AssertionError('%r unexpectedly present' % (value,))


@contextmanager
def expect_error(error_type):
    try:
        yield
    except error_type:
        return
    raise AssertionError('expected exception %s' % error_type.__name__)


def fake(events):
    probe = {'events': events, 'acks': []}
    def receive_data(data):
        result = probe['events']
        probe['events'] = []
        return result
    def acknowledge_received_data(length, stream):
        probe['acks'].append((length, stream))
    return SimpleNamespace(receive_data=receive_data, acknowledge_received_data=acknowledge_received_data), probe


def run(namespace, selected):
    names = sorted(name for name in namespace if name.startswith('test_') and callable(namespace[name]))
    if selected:
        unknown = set(selected) - set(names)
        if unknown:
            raise ValueError('unknown tests: %r' % sorted(unknown))
        names = selected
    for name in names:
        namespace[name]()
        print('PASS', name)
    print('PASS %d checks' % len(names))
