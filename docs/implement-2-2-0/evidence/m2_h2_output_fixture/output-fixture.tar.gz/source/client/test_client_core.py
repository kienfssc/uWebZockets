from test_support import check_equal, check_true, check_false, check_not_in, expect_error, run
import sys
'Offline codec checks for ordered refunds and bounded output stages.'
import h2.config
import h2.connection
import h2.events
import output_stage as stage
import raw_observer
import request_credit as request
import response_credit
import wire

def frame(kind, flags=0, stream=0, payload=b''):
    return len(payload).to_bytes(3, 'big') + bytes((kind, flags)) + stream.to_bytes(4, 'big') + payload

def update(stream, amount):
    return frame(8, stream=stream, payload=amount.to_bytes(4, 'big'))

def pair():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    client.initiate_connection()
    server.initiate_connection()
    server.receive_data(client.data_to_send())
    client.receive_data(server.data_to_send())
    server.receive_data(client.data_to_send())
    return (client, server)

def opened(request_end=True, policy='healthy'):
    client, server = pair()
    client.send_headers(1, [(':method', 'POST'), (':scheme', 'https'), (':authority', 'x'), (':path', '/')])
    client.send_data(1, b'ab', end_stream=request_end)
    server.receive_data(client.data_to_send())
    ledger = request.new_state()
    request.open_stream(ledger, 1)
    request.send_data(ledger, 1, 2, 2)
    if request_end:
        request.end_request(ledger, 1)
    records, raw = ({}, raw_observer.new_state())
    wire.register(records, raw, 1, 0, 200, 0, policy)
    return (client, server, ledger, records, raw)

def test_actual_ordered_before_after_end():
    client, server, ledger, records, raw = opened()
    server.send_headers(1, [(':status', '200'), ('x-middleware', 'retained')], end_stream=True)
    headers = server.data_to_send()
    events = wire.accept(client, update(1, 1) + headers + update(1, 1) + update(0, 2), records, raw, {}, request=ledger)
    check_equal([(e.stream_id, e.delta) for e in events if isinstance(e, h2.events.WindowUpdated)], [(1, 1), (0, 2)])
    check_equal((ledger['connection_debt'], ledger['streams'][1]['debt']), (0, 0))
    request.compare_public(ledger, client, [])
    wire.retire(records, raw, 1)
    request.retire(ledger, 1)

def test_actual_equal_and_late_refunds():
    client, server, ledger, records, raw = opened()
    events = wire.accept(client, update(1, 1) + update(1, 1), records, raw, {}, request=ledger)
    check_equal([(e.stream_id, e.delta) for e in events if isinstance(e, h2.events.WindowUpdated)], [(1, 1), (1, 1)])
    request.compare_public(ledger, client, [1])
    server.send_headers(1, [(':status', '200'), ('x-middleware', 'retained')], end_stream=True)
    wire.accept(client, server.data_to_send(), records, raw, {}, request=ledger)
    wire.retire(records, raw, 1)
    request.retire(ledger, 1)
    events = wire.accept(client, update(0, 1) + update(0, 1), records, raw, {}, request=ledger)
    check_equal([(e.stream_id, e.delta) for e in events if isinstance(e, h2.events.WindowUpdated)], [(0, 1), (0, 1)])
    request.compare_public(ledger, client, [])

def test_actual_reset_closes_unfinished_upload():
    client, server, ledger, records, raw = opened(request_end=False, policy='refusal_after_final')
    server.send_headers(1, [(':status', '200'), ('x-middleware', 'retained')], end_stream=True)
    headers = server.data_to_send()
    events = wire.accept(client, headers + frame(3, 0, 1, bytes(4)) + update(1, 1), records, raw, {}, request=ledger)
    check_equal(len([e for e in events if isinstance(e, h2.events.StreamReset)]), 1)
    check_false(any((isinstance(e, h2.events.WindowUpdated) for e in events)))
    check_true(request.closed(ledger['streams'][1]))
    with expect_error(ValueError):
        request.compare_public(ledger, client, [1])
    check_equal(ledger['streams'][1]['debt'], 1)
    wire.retire(records, raw, 1)
    request.retire(ledger, 1)
    check_equal(ledger['streams'][1]['debt'], 1)
    events = wire.accept(client, update(1, 1), records, raw, {}, request=ledger)
    check_false(any((isinstance(e, h2.events.WindowUpdated) for e in events)))
    check_not_in(1, ledger['streams'])
    request.compare_public(ledger, client, [])

def test_actual_late_closed_stream_debt():
    client, server, ledger, records, raw = opened()
    server.send_headers(1, [(':status', '200'), ('x-middleware', 'retained')], end_stream=True)
    wire.accept(client, server.data_to_send(), records, raw, {}, request=ledger)
    wire.retire(records, raw, 1)
    request.retire(ledger, 1)
    events = wire.accept(client, update(1, 2), records, raw, {}, request=ledger)
    check_false(any((isinstance(e, h2.events.WindowUpdated) for e in events)))
    check_not_in(1, ledger['streams'])

def test_partial_invalid_and_direction_isolation():
    client, server, ledger, records, raw = opened()
    other = response_credit.new_state()
    data = update(1, 2)
    wire.accept(client, data[:-1], records, raw, {}, request=ledger)
    check_equal(ledger['streams'][1]['debt'], 2)
    wire.accept(client, data[-1:], records, raw, {}, request=ledger)
    check_equal(ledger['streams'][1]['debt'], 0)
    check_equal(other['connection'], 65535)
    for stream_id, amount in ((1, 1), (3, 1), (0, 0), (0, 3)):
        with expect_error(ValueError):
            raw_observer.observe(raw, update(stream_id, amount), request=ledger)
        raw = raw_observer.new_state()

def test_stage_budget_and_invalid_frames():
    for kind, budget in stage.BUDGETS.items():
        s = stage.new_stage(kind, 1, 0)
        chunk = b'x' * 8192
        for _ in range(budget // len(chunk)):
            stage.read(s, chunk)
        stage.read(s, b'x' * (budget % len(chunk)))
        check_equal(s['bytes'], budget)
        with expect_error(ValueError):
            stage.read(s, b'x')
    for kind, flags, stream, payload in ((6, 0, 0, b'12345678'), (9, 4, 1, b'x'), (1, 0, 1, b'x'), (0, 8, 1, b'x'), (4, 1, 0, b'x'), (8, 1, 0, b'1234')):
        s = stage.new_stage('early', 1, 0)
        stage.register(s, 1, primary=True)
        stage.frame(s, 30, 4, 0, 0, False)
        with expect_error(ValueError):
            stage.frame(s, len(payload), kind, flags, stream, False)
    s = stage.new_stage('early', 1, 0)
    stage.register(s, 1, primary=True)
    stage.frame(s, 30, 4, 0, 0, False)
    stage.frame(s, 1, 1, 4, 1, False)
    stage.frame(s, 1, 0, 0, 1, False)
    stage.frame(s, 1, 0, 1, 1, False)
    with expect_error(ValueError):
        stage.frame(s, 0, 0, 1, 1, False)

def test_strict_ack_size_and_boundary():
    s = stage.new_stage('early', 1, 1)
    stage.register(s, 1, primary=True)
    with expect_error(ValueError):
        stage.frame(s, 0, 4, 1, 0, False)
    stage.frame(s, 30, 4, 0, 0, False)
    stage.frame(s, 0, 4, 1, 0, False)
    with expect_error(ValueError):
        stage.frame(s, 0, 4, 1, 0, False)
    with expect_error(ValueError):
        stage.frame(s, 4097, 1, 4, 1, False)
    with expect_error(ValueError):
        stage.frame(s, 1, 1, 4, 1, True)
    with expect_error(ValueError):
        stage.retire(s, 1)
    stage.frame(s, 1, 1, 4, 1, False)
    with expect_error(ValueError):
        stage.frame(s, 16385, 0, 1, 1, False)
    with expect_error(ValueError):
        stage.frame(s, 1, 1, 4, 1, False)

def test_invalid_server_initial_window():
    s = stage.new_stage('early', 1, 0)
    raw, ledger = (raw_observer.new_state(), request.new_state())
    payload = b''.join((i.to_bytes(2, 'big') + (1 if i == 4 else 0).to_bytes(4, 'big') for i in range(1, 6)))
    with expect_error(ValueError):
        raw_observer.observe(raw, frame(4, payload=payload), request=ledger, stage=s)

def test_actual_wire_strict_stage_both_ledgers():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    records, raw, trace = ({}, raw_observer.new_state(), {})
    sent, receive = (request.new_state(), response_credit.new_state())
    s = stage.new_stage('early', 1, 1)
    client.initiate_connection()
    response_credit.settings_sent(receive, 65535, initial=True)
    request.client_settings_sent(sent)
    server.initiate_connection()
    server.receive_data(client.data_to_send())
    server.data_to_send()
    values = ((1, 4096), (2, 0), (3, 8), (6, 16384), (8, 1))
    payload = b''.join((key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in values))
    wire.accept(client, frame(4, payload=payload) + frame(4, 1), records, raw, trace, credit=receive, request=sent, stage=s)
    check_true(receive['initial_acked'])
    check_true(sent['settings_seen'])
    server.receive_data(client.data_to_send())
    client.send_headers(1, [(':method', 'GET'), (':scheme', 'https'), (':authority', 'x'), (':path', '/')], end_stream=True)
    request.open_stream(sent, 1)
    request.end_request(sent, 1)
    response_credit.open_stream(receive, 1)
    stage.register(s, 1, primary=True)
    wire.register(records, raw, 1, 17, 200, 0, 'healthy', mode='hash_only', credit_policy='manual', expected_sha256='d826bcf95ee8850cecb39accdeb84b32336a0415411938da42da7edcac891da7')
    server.receive_data(client.data_to_send())
    server.send_headers(1, [(':status', '200'), ('x-middleware', 'retained')])
    server.send_data(1, b'early-final-order', end_stream=True)
    wire.accept(client, server.data_to_send(), records, raw, trace, credit=receive, request=sent, stage=s)
    wire.retire(records, raw, 1)
    request.retire(sent, 1)
    response_credit.retire(receive, 1)
    stage.retire(s, 1)
    check_true(s['primary_complete'])
    check_equal((s['initial_settings'], s['acks'], receive['logical_bytes']), (1, 1, 17))
    check_equal((sent['connection_debt'], sent['streams']), (0, {}))

def test_final_33_with_carried_debt():
    s = stage.new_stage('early', 1, 0)
    raw, ledger, receive = (raw_observer.new_state(), request.new_state(), response_credit.new_state())
    settings = b''.join((i.to_bytes(2, 'big') + (65535 if i == 4 else 0).to_bytes(4, 'big') for i in range(1, 6)))
    raw_observer.observe(raw, frame(4, payload=settings), request=ledger, stage=s)
    request.open_stream(ledger, 1)
    request.send_data(ledger, 1, 2, 2)
    request.end_request(ledger, 1)
    raw_observer.register(raw, 1, 'healthy')
    stage.register(s, 1, primary=True)
    raw_observer.observe(raw, frame(1, 5, 1, b'x'), request=ledger, stage=s)
    raw_observer.retire(raw, 1)
    request.retire(ledger, 1)
    stage.retire(s, 1)
    response_credit.settings_sent(receive, 65535, initial=True)
    response_credit.settings_acknowledged(receive, h2.events.SettingsAcknowledged())
    stage.enter_final(s, raw, ledger, receive)
    check_equal(s['budget'], 1487112 + 52)
    with expect_error(ValueError):
        request.send_data(ledger, 1, 0, 0)
    with expect_error(ValueError):
        request.client_settings_sent(ledger)
    for sid in range(3, 69, 2):
        request.open_stream(ledger, sid)
        request.end_request(ledger, sid)
        raw_observer.register(raw, sid, 'healthy')
        stage.register(s, sid)
        raw_observer.observe(raw, frame(1, 5, sid, b'x'), request=ledger, stage=s)
        raw_observer.retire(raw, sid)
        request.retire(ledger, sid)
        stage.retire(s, sid)
    raw_observer.observe(raw, update(1, 2) + update(0, 1), request=ledger, stage=s)
    check_equal(ledger['connection_debt'], 1)
    stage.finish_final(s, raw)
    with expect_error(ValueError):
        stage.register(s, 69)
if __name__ == '__main__':
    run(globals(), sys.argv[1:])
