import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from unittest import mock

HERE = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get('UWZ_PREPARE_SOURCE', str(HERE / 'prepare.py')))


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def check_import(values):
    source = SOURCE.read_text()
    state = {'reads': [], 'effects': []}
    probe = mock.MagicMock(spec=list)

    def getitem(key):
        state['reads'].append(key)
        return values[key]

    def iterate():
        state['reads'].append('iter')
        return iter(values)

    def length():
        state['reads'].append('len')
        return len(values)

    def blocked(*args, **kwargs):
        state['effects'].append((args, kwargs))
        raise RuntimeError('blocked before filesystem or compiler effect')

    probe.__getitem__.side_effect = getitem
    probe.__iter__.side_effect = iterate
    probe.__len__.side_effect = length
    namespace = {'__name__': 'inert_prepare', '__file__': str(SOURCE)}
    caught = None
    with mock.patch.object(sys, 'argv', probe), mock.patch.object(Path, 'mkdir', side_effect=blocked), mock.patch.object(subprocess, 'run', side_effect=blocked):
        try:
            exec(compile(source, str(SOURCE), 'exec'), namespace)
        except (RuntimeError, IndexError) as exc:
            caught = exc
    require(caught is None, 'import raised: ' + repr(caught))
    require(not state['reads'], 'import read argv: ' + repr(state['reads']))
    require(not state['effects'], 'import attempted effects: ' + repr(state['effects']))


def check_environment():
    source = SOURCE.read_text()
    namespace = {'__name__': 'inert_prepare', '__file__': str(SOURCE)}
    recipe = {'argv': ['/absolute/zig', 'build-exe', '--cache-dir', 'cache', '--global-cache-dir', 'global', '-femit-bin=old'], 'input_sha256': {}}
    state = {'calls': [], 'receipts': []}

    def fake_run(argv, **kwargs):
        state['calls'].append((argv[:], kwargs.copy()))
        return subprocess.CompletedProcess(argv, 0, b'', b'')

    def fake_write_text(path, text, *args, **kwargs):
        state['receipts'].append(json.loads(text))
        return len(text)

    expected = {'LC_ALL': 'C.UTF-8'}
    expected_id = hashlib.sha256(json.dumps(expected, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    with mock.patch.dict(os.environ, {'ZIG_LIB_DIR': '/ambient/override', 'CC': 'ambient-cc', 'SECRET_TEST': 'do-not-copy'}, clear=True), \
         mock.patch.object(Path, 'mkdir'), mock.patch.object(Path, 'chmod'), \
         mock.patch.object(Path, 'read_text', return_value=json.dumps(recipe)), \
         mock.patch.object(Path, 'write_bytes'), mock.patch.object(Path, 'write_text', new=fake_write_text), \
         mock.patch.object(Path, 'exists', return_value=False), mock.patch.object(Path, 'rglob', return_value=[]), \
         mock.patch('shutil.copyfile'), mock.patch.object(subprocess, 'run', side_effect=fake_run), \
         mock.patch.object(sys, 'argv', ['validator', 'double']):
        exec(compile(source, str(SOURCE), 'exec'), namespace)
        if 'main' in namespace:
            namespace['main'](['double'])
    require(len(state['calls']) == 2, 'expected two compiler calls')
    require(len(state['receipts']) == 2, 'expected two in-memory receipts')
    for (_, kwargs), receipt in zip(state['calls'], state['receipts']):
        require(kwargs.get('env') == expected, 'compiler environment differs: ' + repr(kwargs.get('env')))
        require(receipt.get('environment') == kwargs['env'], 'receipt environment differs')
        require(receipt.get('environment_sha256') == expected_id, 'receipt environment identity differs')
        require(receipt.get('exit_status') == 0, 'receipt exit differs from double')


def check_test_ast():
    module = ast.parse(Path(__file__).read_text())
    require(not any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(module)), 'authored class or assert found')


def main(args):
    selection = args[0] if args else 'all'
    require(len(args) <= 1 and selection in ('all', 'import', 'import-empty', 'import-foreign', 'environment'), 'invalid selection')
    count = 0
    if selection in ('all', 'import', 'import-empty'):
        check_import([])
        count += 1
    if selection in ('all', 'import', 'import-foreign'):
        check_import(['validator', 'foreign'])
        count += 1
    if selection in ('all', 'environment'):
        check_environment()
        count += 1
    if selection == 'all':
        check_test_ast()
        count += 1
    print('passed ' + str(count) + ' preparation checks')


if __name__ == '__main__':
    main(sys.argv[1:])
