# Task5d3 driver integration handoff

Original output architect read the reviewed11-file client core1678c387 and
retained9-file Task5c3runtime; no edits/tests/native activity. Root preserves
its concrete handoff here and integrates the now-visible fixture schema.
Fixture Zig source is approved as scoped; preparation-helper fixes/builds still
pending. This plan is not execution authorization and does not replace the
actual combined40-case matrix.

## Process and connections

One fresh owned fixture process per selected subset, one fresh TLS1.3/h2
connection per selected case, at mostfive sequential case connections. The last
completed connection carries final32body-status rows+metrics. No separate health
connection or implicit pre-run33snapshot. Each case has its existing absolute
30-second deadline through its operations; final33 keeps the last case deadline.
Ready15/whole900/idlegrace15 remain, no trickle extension or threshold change.

Preserve existing ownedPID/start/listener/nonce/certificate-before-health and
exactchildshutdown/reaping checks, bounded65536stdout,8192 actualsend/read,
8active response records. Initial H2 settings must be counted from first byte:
create raw/request/response/stage state before first receive. Pair actual helper
initialSETTINGS with both ledgers once, flush, await initialACK BEFORE opening
health (response_credit.open_stream requires initial_acked). Health stream1
manualsmall200/ok, complete/retire. Advertise custom initialstream0 (fourheld
cases) or W33554432(ready), pair both ledgers, await secondACK. Raise connection
response window from actualremainingcredit toW. Never enlarge server request
receive storage/window. Zero-mode auxiliary streams get65535 explicitcredit;
primary grants follow cases. Flush HEADERS separately before grants.

## Actual reviewed API pairing

Per connection: raw_observer.new_state, request_credit.new_state,
response_credit.new_state, output_stage.new_stage(kind,primary_id,2), empty
response records and aggregated event trace. Public get_next_available_stream_id
must match plannedID. Open in request/receive/stage/wire BEFORE receiving any
response; every record manualcredit. Primary hash_only with literal length/SHA;
auxiliary small_body<4096, expectedstatus/retainedmiddleware/info0/policy.

Pair actual public calls once: clientSettings->request.client_settings_sent and
response.settings_sent; clientDATA->request.send_data(logical,flow); outgoing
END inHEADERS/DATA->request.end_request; responsegrant->response.grant. Actions
must be recorded before any nextreceive; errors abort without partially-accounted
retry. Send via public protocol.data_to_send(amount=8192), no arbitrarilylarge
unbounded extraction. Every receive wire.accept(...credit=...,request=...,stage=...).
That applies incomingrawrefunds/ordered events/ACK/DATA/terminals itself; no legacy
flow.receive_batch, automaticack or duplicate incoming end/reset accounting.

Compare request outbound/local and response inbound/remote public windows after
each receive using caller-owned correctfullclosure/query eligibility. Connection
checks remain even if streamsclosed; no privatefield/exception swallowing.
On policy-complete caseassertions savebounded evidence, then retire wire,
request, response andstage exactlyonce. Requestdebtretirement retainsvalidlate
closedrefunds; neverdelete debt manually. Hash-only completion returns count/
hash/headers/terminal evidence, noUTF8/JSON/bodycopy; oldrun_live.complete's
unconditionaldecode is a real integrationchange required here.

## Concrete five schedules

Each admitted body P32/H32 declared32+POST/path/query/tag/x-case metadata;
ordinaryprotocolEMPTY. EverypositiveP32 request is oneunpaddedDATA withEND.
Auxiliary streamgrant onlyinzero mode, preservingprimary0 untilnamedgrant.

| Case | Kind/primary | A | R requestflow | S | Peakresponses |
| --- | --- | ---: | ---: | ---: | ---: |
| output_pressure_window | producer/5 | 7 | 33 | 2 | 3 |
| output_pressure_ready | producer/5 | 5 | 33 | 2 | 2 |
| producer_reuse | producer/3 | 8 | 64 | 2 | 2 |
| stream_file | file/5 | 6 | 33 | 2 | 3 |
| early_final_order | early/7 | 6 | 32 | 2 | 3 |

Root integration ruling: architect proposedreuseA7 while diagnostic schema was
pending. Actual fixture exposes B binding index/generation through separate
/output/producer_reuse_next, and A-onlystatus excludes B. Retain allthree Astatus
barriers and add one Bstatus before unblockingA; reuseA8, wholecase37requests+
final33=70, bufferedmiddleware63, R195. This derives from actualAPI, no failed
run/capacity increase: A32 and allsource budgets unchanged. Never infer Aoffset0
from absenceofDATA alone or wait for postdeinitBmarker before completingA.

Window: health1/settings; open echo3 declared1/noDATA/END; primary5P32 at0;
BodyStatusprimary andOutputStatusprimary require end1/bindinginactive, offset0/
actualpositiveWouldBlock/pending/noDATA/END; echo s/END healthywhileprimaryheld;
grant8192/exactprefix+OutputStatusbarrier offset8192/hash/blockedunchanged/noEND;
grantN-8192/exactN/fullhash/END/noreset; finalOutputStatus andhealth. A=2health+
echo+BodyStatus+3OutputStatus. No premature success fromproducer.done.

Ready: health1/ampleW; echo3heldinput; primary5P32 thenecho s/END; continuously
readboth withnoartificialstarvation/delay; BodyStatus/OutputStatus/finalhealth.
ExactN/hash/end, writes2049/errors0; actualpending/blocked0allowed, no native
saturationclaim. A=2health+echo+body+output.

Reuse: health1/zero; A3P32; BodyStatusA/OutputStatusA proveinputterminal/offset0
pending. BnextP32 creditednormalJSONresponse; OutputStatusA andOutputStatusB
beforegrant require Aoffset0/pending plus Bindex==Aindex/Bgeneration==A+1.
GrantA N/fullhash/end; finalOutputStatusA checksafter_reuse>=1/allmetadataerrors0;
finalhealth. A=2health+BodyStatusA+3AOutputStatus+Bresponse+BOutputStatus.
Omitoptionaloldcontrols toretainauthoritative stale counters0.

File: health1/zero; echo3heldinput; primary5P32; BodyStatus andheldFileOutput;
oneCL24593/noDATA/END/successfularm/ownershiptransferred; echo s/END healthy;
grant24593/exactrangehash/count/END/noreset; finalFileOutput/health. A=2health+
echo+body+2output. Readspans<=8192 within[37,24630), noerror, transportclose1/
closed_files1/caller_ownedfalse; noexactreadcount/totalunderretries. Postdeinit
mustprove nosecondclose. Public returned-error ownership proof remains separate
purecallback/existingidentity-matchingcomponent evidence, not newnativefault.

Early: health1/zero; holder3 declared32/noDATA/END/credited; BodyStatusholder5
activeadmission; refusal7 declared32/Expect100/noDATA/END/zeroresponsecredit.
BodyStatusrefusal MW1/bodycallbacks0;403headers/no100/DATA/END/reset. Grant8,
exactearly-fi prefix/hash, BodyStatusrefusalbarrier noEND/reset. Grant9,
exact17/fullhash/ENDbeforeoneNO_ERRORreset; nevermanuallyEND/resetrefusedrequest.
Incomingreset closesbothdirections via reviewedobserver. FinishholderP32/END/
healthyresult; finalhealth. A=2health+holderresponse+3BodyStatus.

## Fixture diagnostics and exact final accounting

Actual routes: /status/:tag, /metrics, /output/:tag. Producerstatus:
tag,armed,done,offset,sha256,invocations,attempts,writes,blocked,pending,
terminal_attempts,terminals,checks,after_reuse,errors,binding_index,generation
(the actual JSON key is binding_generation). Validate exactfields/types,
checks==invocations, blocked==pending, attempts>=writes, and success N/hash/
writes2049/terminals1/done/armed/errors0. Callback counts are actual, notfixed.
Successfulsource identity supports pending+1==invocations and
blocked==(attempts-writes)+(terminal_attempts-terminals); requireonlywhenmatching
the actual unchanged fixture algorithm, not a generic producerAPI promise.
AfterReusecount requiredonlyforA; globalBflagmayalsoaffectotherproducers.
Bstatus exactlytag/binding_index/binding_generation. Fileformat14namedfields
comes directly from file_observer.format; bind actualsource, no guessed names.

Postdeinit markers: H2_BINDING nonce Bindex/gen; four H2_OUTPUT nonce JSON (three
producers plusfile, includingunuseddefaultstates);32H2_RECORD rows;
H2_DEINIT totals. Existing H2_CAPACITY/H2_READY unchanged. Logprefix mayvarywith
scoping; nonce/markertypes/counts and actualfullrecords mustmatch. Neverread
borrowed metadata afterterminal whenformatting; actualformat onlyusesownedstats.

Beforeclosingnon-lastconnection, allscheduled responses retired/rawframing
complete; recordremainingdebtperconnection, nevertransfer it acrossconnections.
Onlastconnection aftercasefinalhealth/diagnostics callenter_final, additionally
driverrecords andresponseledgerstreams empty. Keeprawparser/debt/clock, then
sequentially32statuses incontracts.TAGSorder andmetricslast, noextrahealth/output
diag inthatstage; finish_final. Finalbudgetactualremainingdebt formulaunchanged.

Normalize exactoldbodyJSON: accepted->bytes, begin/end/cancel/failure->plural,
reason stringnone->None; strictschema/types andliteralhashes, retainrawrecords.
Validate againstcontracts.selectedsubsetmodel, includinguntouchedspares. Fullfive
bodytotals MW7/attempt6/B6/E6/C0/F0/accepted192/activeerrors0, buffered63 andboth
slotsinactive; globalMiddlewareallresponses70. Partialselectioncounts derive
fromthistable andcasecomposition, neverhardcodefullfivetoasubset.

## Final release gates

Oldcompilevalidator assumesonefileTask5c3 andmustbindactualnewmultifilefixture/
finalDebugRSreceipts. Freezeallactualdriver/core/helper/fixture/tool/loader/env
inputs; inertimports, actualpublic-action-pairing puretests, controlledmutation
ofactualownedinput/reject/restore, independentreview, then separateexactRoot
nativecase release. Preserve failures/cleanup/run/deinit/keyremoval/exit0/reap;
forcedcleanupfails. FileenvH2_PROFILE_FILE/privateownedpath is required; file
setupisruntimeonly. No retry/fallback/thresholdwidening. Laterfull40 needsits
ownrecords/topology/source-derivedbudgets, not unionofcheckpoints or reuseR65
for100000000-byteuploads. Fullquality/platform/fuzz/package/adoptionremainopen.
