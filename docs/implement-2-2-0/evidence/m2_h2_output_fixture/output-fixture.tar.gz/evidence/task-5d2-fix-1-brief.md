# Task5d2 fix round1/5: inert preparation and recorded compiler environment

Same original fixture owner and file ownership. Read original fixture brief and
actual review/report. Preserve attempt1/attempt2 receipts/snapshots/binaries and
source history unchanged. No native fixture/constructor/client/server/socket/
file-transfer/certificate/resource/error/fault probe or full test execution.
Pure preparation tests with inert caller doubles and fresh compiler-only builds
are authorized here. No product/client/publicdoc/pin/ref changes, subagents,
commits/push/external model CLI. Append same task-5d2-report.md.

Open findings verbatim:

1. P2 — Make preparation imports inert. prepare.py14 reads sys.argv[1] and creates
the output directory at module scope;26-56 then copy files and invoke both
compiler commands. Importing from a future validator either raises IndexError
or performs preparation/compilation using importing process arguments. This
violates explicit inert-import requirement. Put argument handling and all
effects behind guarded main.

2. P2 — Preserve the actual compiler environment. prepare.py43 launches compiler
with entire inherited environment; receipt48-54 records no environment identity.
Two invocations can use different compiler-affecting environments with identical
recorded argv/source-input identities. Pass explicit controlled environment and
preserve non-secret identity per receipt. Existing receipts cannot establish
historical environment retrospectively; retain limitation explicitly.

Root accepts both source-backed findings. Use a small explicit environment such
as original reviewed compile helper's LC_ALL=C.UTF-8 (absolute compiler/imports/
cache paths already recorded), with no inherited credentials/options. Record
actual supplied mapping and deterministic identity in BOTH fresh receipts. Do
not dump arbitrary os.environ or claim past builds used the new environment.
Keep actual compiler/input/source/override/fixture before-after checks and j2.

Meaningful import RED/GREEN must inspect actual module behavior without allowing
old module to invoke compiler or make output: replace its earliest filesystem
effect and compiler call with inert test doubles that record/reject effects,
using controlled argv. Do not import the unsafe version directly. Cover normal
empty/foreign argv and ensure no argument reads/effects execute at import.
Also prove on the actual command path with a compiler double that ambient
compiler-affecting variables do not propagate and the supplied environment is
the one recorded. Mark such tests as doubles; no fake successful build receipt
may be mistaken for a real build. All actual compiler invocations are separately
recorded fresh attempts, not part of an adverse native/probe experiment.

Freeze a NEW final snapshot under a new /tmp/uwz-task5d2-* name and compile
actual Debug/RS under that explicit environment. Existing successful attempt2
cannot close the environment gap retroactively; do not overwrite it. Preserve
same three reviewed Zig files unless a concrete new defect requires reporting.
If only helper changes, keep old source findings closed and explain new source
snapshot versus historical binary receipts. No source/native scope expansion.

Retain exact argv/env/raw logs/exits/new binary and receipt hashes, original
12 non-fixture input agreement and1031/93 source/override unchanged maps, plus
all final frozen fixture/helper/test identities. Capture ordinary/selected-O
pure tests and AST/inert imports. New test artifacts in owned directory allowed;
do not invent runtime behavior/descriptor/returned-error ownership evidence.
Root reads actual covering tests/commands/raw results before same reviewer's
scoped re-review. Nativefive/fullcombined/runtimeclosure/fullgates remain open.
