# Task 5d2 fixture preparation report

Scope: test-only source and compile preparation. No fixture binary, constructor, test, server, client, socket, transfer file, certificate, fault or resource probe was executed or created. No native output case or combined matrix is claimed. Root owns independent review and any later runtime release.

## Source and bounded state

New source: `.uwz-work/evidence/h2-streaming/integration-owned/output-fixture/`.

- `profile.zig` starts from the restored baseline SHA256 `3336d93a5684d88c6a4373d305838ff646b89173abcfb4999a0fd7b1eb951920`. It retains the 8-connection configuration, 65536 write queue, two body slots, 32 records, body limits and existing health/echo/status/metrics/control routes. Seven tags and 25 spares follow the selected-subset contract. It validates ordinary POST protocol as empty, applies the early final 403 in middleware, and adds `/output/:tag` and post-deinit diagnostics. Each slot records a fixture index and monotonically increasing generation.
- `output.zig` holds three independent states, each with 8192-byte scratch, 1024-byte metadata storage and eight individually borrowed slices paired with owned copies. Initial validation happens in the body-end callback before capture. Each producer invocation compares the slices with the owned values before writing or finishing. Successful writes alone update offset and SHA256; `WouldBlock` retains offset, and successful terminal retirement is followed by no borrowed-slice access. The reuse admission flag records callbacks after the second request's admission.
- `file_observer.zig` holds a separate 8192-byte buffer, file ownership, original Io and copied vtable. Only positional-read and close are overridden for the confined FileSource; both delegate original arguments and results through original userdata. Requested read bounds, lengths, errors, offsets and close counts are recorded without injected errors. Future main setup creates the exclusive regular file from `H2_PROFILE_FILE`; it has not been executed. Caller cleanup uses base Io on setup or arm errors; successful `stream_file` transfers ownership. Inline close is not conditioned on the post-return transfer flag.
- `prepare.py` creates a fresh frozen multi-file snapshot and compiles actual binaries against the retained recipe. It emits complete direct-input and source/override before/after maps, binary identities, argv and raw stdout/stderr. Caches and binaries remain under `/tmp/uwz-task5d2-*`; compiler concurrency is `-j2`.

The output formatter has a 2048-byte buffer. Its fixed ASCII labels, bounded known tags, one 64-character hex digest, booleans and at most 20 decimal digits per u64 leave substantially more than half that buffer unused even at integer maxima. Existing body and total formatter buffers remain 1024 bytes; no JSON truncation or allocation was added. Metadata capture uses a 1024-byte checked store and fails on overflow. There is no output state in the reused body slot.

## Compile evidence

Zig executable: `/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`, SHA256 `2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c`. `zig env` reported Zig 0.16.0 and its SDK under the same store path. Zig formatting was run on the three new Zig files.

Frozen source: `/tmp/uwz-task5d2-attempt2/fixture/` (files mode 0444, directory 0555). Each live file matches its frozen counterpart:

| File | SHA256 |
| --- | --- |
| `profile.zig` | `fbe514fc37399ff11a51380a9372e757b431423816dbce5233c93a38c57119f0` |
| `output.zig` | `a0a4ff2dd4e31da414aa3272369e95138a87d8e4666bb3ed4f885313897f173a` |
| `file_observer.zig` | `190a1d55918df0a7aeb3f8ff96e8816eab6dfe08cb8151aafc3b16e2858fd87d` |
| `prepare.py` | `4c4d22591e3658df103d0ec64bb32c10dcbc82c72df6ed21739fd65c670fb99b` |

`python3 .uwz-work/evidence/h2-streaming/integration-owned/output-fixture/prepare.py attempt2` ran the compiler only. Exact argv, inputs and complete tree maps are in the receipts; compiler stdout/stderr are retained separately and are empty on both successful builds.

| Mode | Exit | Binary SHA256 | Receipt SHA256 |
| --- | --- | --- | --- |
| Debug | 0 | `f00e9624be5b9bc7c865f1534e943c94f8d12a940e8d38f82f54505136da3ec1` | `58abbeed793ca207ad0e601c2a82280aa6b5c39235d6e2c720f66019be4cf3c5` |
| ReleaseSafe | 0 | `addb0c1bb8bc361013b0aff8e176087f08c61bd1e322d51b394b088a6849ddc6` | `3e9133800536697cd49f22da65542e541286471ab8ca7c8dc1017bc7169db7de` |

Receipts, binaries, raw logs and maps are under `/tmp/uwz-task5d2-attempt2/`. Both receipts show all 12 non-fixture direct inputs match their retained recipe and are unchanged before/after; the newly frozen fixture files also match before/after. Both show the 1031-file source tree digest `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de` unchanged, and all 93 override files unchanged. The original 13th direct input is replaced by this new frozen profile; its restored starting identity is recorded above.

Earlier Debug attempt failed on the public `Response.end` signature; its complete raw compiler output and receipt are `/tmp/uwz-task5d2-attempt1/debug.stderr` and `debug-receipt.json`. The first edit failed because the copied baseline retained read-only file mode; an initial formatting attempt also failed on array indexing syntax. Their diagnostics are recorded in `/tmp/uwz-task5d2-edit-failures.txt`; that file reconstructs the displayed errors rather than being the original redirected command log. Both defects were corrected before attempt2. Attempt1 was never used as a successful binary receipt.

## Review and remaining work

Self-review checked the eight metadata values and ordinary empty protocol, producer storage lifetime, unchanged retry offset, terminal retirement ordering, application-only binding generation, file ownership on returned error, close-before-return tolerance, and use of base userdata in both Io callbacks. The exact requested and returned file read totals are observations; short reads and retries do not assume four reads. All counters and hashes are actual callback observations, not saturation or wire-completion claims.

Independent source review is still required, particularly for Zig Io callback confinement, response lifetime and synchronous callback ordering, diagnostics and client contract integration. No pure or native functional test was executed in this pass, and no test proves producer or file behavior yet. Native five-case runs, runtime source/tool closure and independent client verification, combined 40-case matrix, full source/quality/sanitizer/platform/fuzz/package/performance gates, and adoption remain open. General project test and graph update commands were not run: this task authorizes compile-only activity and confines writes to its new fixture directory, report and `/tmp/uwz-task5d2-*`.

## Fix round 1: inert preparation and compiler environment

The independent review's two preparation-tool P2 findings are addressed in the new `prepare.py`; the three Zig files are byte-for-byte unchanged from attempt2. Argument access, output creation, snapshots and compiler calls now occur only inside guarded `main`. Each actual compiler invocation receives exactly `{"LC_ALL":"C.UTF-8"}` as its complete environment, and each new receipt records that mapping plus SHA256 `1d51beac96defee76800a4eb338246af4d2e3069a94efb3a3bc90a0ebd40d61d` of the sorted compact JSON encoding. The prior attempt1 and attempt2 inherited environments were not recorded and cannot be established retrospectively; their receipts and binaries remain historical evidence only.

`test_prepare.py` uses caller-owned Python doubles, not native fixtures or compiler execution. Its import test executes the historical helper with controlled empty and foreign argv, while replacing its earliest filesystem effect and compiler call with rejecting doubles. Both historical subcases failed as expected: one read a missing argument and the other reached the blocked mkdir. The command-path environment test runs the actual helper path with filesystem and compiler calls replaced by doubles, seeded ambient compiler-related and secret-like values, and examines both subprocess arguments and in-memory receipts. It failed against the historical helper because no explicit environment was passed. Raw RED stdout, stderr and exits are `/tmp/uwz-task5d2-fix1-red.*` and `/tmp/uwz-task5d2-fix1-env-red.*`; neither test created a fake build receipt or binary. The displayed errors in the logs are expected failures.

After the fix, `python3 .uwz-work/evidence/h2-streaming/integration-owned/output-fixture/test_prepare.py` and the same command with `python3 -O` each passed all three tests, including the AST guard, inert import and controlled-env command-path double. Raw stdout, stderr and exits are `/tmp/uwz-task5d2-fix1-green.*` and `/tmp/uwz-task5d2-fix1-opt.*`. These tests are preparation checks only; no runtime or I/O behavior of the Zig fixture was tested.

The fresh frozen source is `/tmp/uwz-task5d2-fix1final/fixture/`, with five read-only files and a read-only directory. New or unchanged SHA256 identities:

| File | SHA256 |
| --- | --- |
| `profile.zig` | `fbe514fc37399ff11a51380a9372e757b431423816dbce5233c93a38c57119f0` |
| `output.zig` | `a0a4ff2dd4e31da414aa3272369e95138a87d8e4666bb3ed4f885313897f173a` |
| `file_observer.zig` | `190a1d55918df0a7aeb3f8ff96e8816eab6dfe08cb8151aafc3b16e2858fd87d` |
| `prepare.py` | `7b216069556328214138ee59cf1848705d68bdfad460e6b92b45aad69bda4396` |
| `test_prepare.py` | `3cb5916eaadaaa3aaa955cb6713f8e7ce546b899d6782efe9101f7e72c793a2e` |

The controlled actual compiler invocation is `python3 .uwz-work/evidence/h2-streaming/integration-owned/output-fixture/prepare.py fix1final`; its driver stdout/stderr/exit are `/tmp/uwz-task5d2-fix1-build.*`. Each actual compiler argv, mode, explicit environment, raw output, exit, binary identity and before/after file maps is retained under `/tmp/uwz-task5d2-fix1final/`. Each build has fresh local and global caches under that directory. The previous attempt directories were not changed.

| Controlled mode | Exit | Binary SHA256 | Receipt SHA256 |
| --- | --- | --- | --- |
| Debug | 0 | `57b1fabd6ea6a66ce92e065dbc4a336810ddd38e88cece3bf1a63de17267fe3d` | `c0fd9fad71383e63b501cda23e40b7b9ff0a690c0438bd97bc75edaba4246352` |
| ReleaseSafe | 0 | `d1a8a2c0e7e86d1cf4add784a4f1c48d85afde15cbebe783d7766f3ab88fa543` | `66e4804752ea51d30430f4ca657305c4ab85242a8e4d540a64e431a8b79dc079` |

The driver and both compiler outputs were empty and exited 0. Both receipts independently confirm the 12 non-fixture direct inputs match their retained recipe and are unchanged before/after; all five new snapshot files are unchanged before/after. The 1031-file source map remains `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`, and all 93 override files remain unchanged. Exact paths, complete maps and argv are in the receipts.

Scoped independent re-review of the two fixes remains with Root and the original reviewer. Neither binary was executed. Runtime closure, five native output cases, combined matrix and full gates remain open; no returned-error ownership or descriptor behavior is inferred from the Python doubles.

## Fix round 2: function-based preparation checks

The original reviewer marked the two guard/environment findings addressed and identified the test harness's authored classes and inheritance as a separate P2. Only `test_prepare.py` changed in this round. Its function-based checks use caller-owned lists/dictionaries and standard-library doubles, built-in `RuntimeError`, and explicit `if`/`raise` proof conditions. No authored classes, exception subclasses, `unittest.TestCase` inheritance, or optimization-disabled assertions remain. A syntax-tree check enforces the last two prohibitions; it is not an implementation-shape check on the helper.

The final separately frozen current source set is `/tmp/uwz-task5d2-fix2-final-snapshot/` (files mode 0444, directory 0555). Current `test_prepare.py` SHA256 is `3bddaa0de1a4ca944735beabce491a17d7d23cf3fa41b56a4dacc4d4c0542ce5`. The three Zig files and guarded `prepare.py` match the `fix1final/fixture` identities recorded above exactly. The changed test is not the historical test file: the controlled Debug and ReleaseSafe receipts bind the prior five-file snapshot and its test hash `3cb5916eaadaaa3aaa955cb6713f8e7ce546b899d6782efe9101f7e72c793a2e`. Those binaries and receipts remain byte-identical to their recorded hashes. No compilation was run in this test-only round and no receipt is claimed for the changed test.

From that final snapshot, the following exact pure checks were run:

```sh
UWZ_PREPARE_SOURCE=/tmp/uwz-task5d2-attempt2/fixture/prepare.py python3 /tmp/uwz-task5d2-fix2-final-snapshot/test_prepare.py import-empty
UWZ_PREPARE_SOURCE=/tmp/uwz-task5d2-attempt2/fixture/prepare.py python3 /tmp/uwz-task5d2-fix2-final-snapshot/test_prepare.py import-foreign
UWZ_PREPARE_SOURCE=/tmp/uwz-task5d2-attempt2/fixture/prepare.py python3 /tmp/uwz-task5d2-fix2-final-snapshot/test_prepare.py environment
python3 /tmp/uwz-task5d2-fix2-final-snapshot/test_prepare.py
python3 -O /tmp/uwz-task5d2-fix2-final-snapshot/test_prepare.py
```

The three historical-helper checks exited 1 as expected: empty argv exposed an import-time argument read; foreign argv reached the rejecting mkdir double; the environment double observed no explicit environment. The doubles prevent actual filesystem creation and compiler invocation. The final two commands each exited 0 and reported four preparation checks: empty argv import, foreign argv import, actual command-path environment/receipt double, and the test AST compliance check. Both Python modes use the same explicit conditions. Their exact raw stdout, stderr and exit files are `/tmp/uwz-task5d2-fix2-v2-{empty,foreign,env,green,opt}.{stdout,stderr,exit}`. The earlier round's raw doubles, frozen snapshots and build receipts are retained.

These checks establish neither fixture behavior nor native I/O. The scoped independent re-review, runtime closure, five cases, returned-error evidence, combined matrix, full gates and adoption remain open.
