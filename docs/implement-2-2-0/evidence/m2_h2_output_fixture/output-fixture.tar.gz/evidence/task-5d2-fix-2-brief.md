# Task5d2 fix round2/5: function-based preparation checks

Same original fixture owner and report, all ownership/no-native boundaries
unchanged. Two original tool findings are independently ADDRESSED. No Zig or
guarded prepare.py changes requested; keep those reviewed bytes unchanged and
retain actual controlled Debug/RS receipts/binaries under fix1final. Do not
overwrite any historical/current frozen build or claim it compiled changed
Python test code. A test-only source change does not require another unchanged
native fixture compilation. Bind the new current test/tool version separately
from the actual historical five-file compiler snapshot; three native Zig inputs
and helper remain byte-identical to actual controlled build provenance.

New open finding verbatim:

P2 — Remove the newly authored test classes and inheritance. test_prepare.py14,
28,47 introduce ArgProbe, an exception subclass and
PrepareTest(unittest.TestCase). AGENTS and CODING_CONVENTION7.1 explicitly
prohibit classes and inheritance without a test-harness exception. New regression
harness violates mandatory contract despite passing behavior checks. Use
function-based checks and explicit caller-owned probe state; preserve checks
under python -O.

Root accepts the finding; no inferred exception or user permission is needed.
Rewrite only the preparation tests using functions, explicit list/dict probe
state and existing built-in errors, no authored classes/inheritance/hidden state.
Proof conditions use explicit if/raise rather than optimization-disabled assert.
Imported standard library APIs/doubles are allowed; do not introduce custom
classes as an indirection. Preserve actual-module empty/foreign argv/import
effects and actual command-path controlled environment/receipt checks. An AST
guard-shaped test is redundant with behavior checks; retain meaningful checks,
not implementation-shape assertions. Report actual resulting check count.

Exercise same historical helper with rejecting FS/compiler doubles to prove RED
without allowing an old real compiler/mkdir; exercise fixed actual command path
with I/O/process doubles to prove env isolation and receipt binding. Run current
functions normal and optimized, retain raw outputs/exits and AST/inert proof.
No real filesystem/FD/descriptor/native adverse probes, no fake build receipts
written, no native fixture constructor or execution. Test artifacts stay owned.

Append exact commands/results/current hashes/source version and explicit native
receipt identity relationship to same report. Root reads before original
reviewer's scoped re-review. No new compiler build needed unless actual Zig or
compiler/helper changes; report a concrete issue before expanding that scope.
No client/publicdoc/dependency/ref edits, subagents/commits/push. Driver/fivecases/
returned-error evidence/full40/fullgates/adoption remain open.
