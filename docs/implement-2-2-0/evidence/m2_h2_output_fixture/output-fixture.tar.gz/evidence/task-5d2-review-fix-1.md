# Task5d2 first fix scoped re-review

Reviewer /root/review_h2_output_fixture. Both original P2 ADDRESSED: guard
contains args/filesystem/compiler effects; explicit environment and hash in
both actual fresh receipts, historical uncertainty documented.

New P2 — Remove newly authored test classes and inheritance. test_prepare.py14,
28,47 introduce ArgProbe, exception subclass, PrepareTest(unittest.TestCase).
AGENTS and CODING_CONVENTION7.1 prohibit classes/inheritance without a harness
exception. Use function checks/explicit caller-owned probe state; keep -O checks.

Actual RED import2fail/environment1failure and GREEN3normal/optimized/fresh
controlled DebugRS evidence support original fixes. No other fixdiff/structural
findings. Read-only no imports/builds/tests/edits/native. Driver/five native/
returned-error/full40/gates/adoption open.
