# Task5d2: actual output fixture and compile receipts

Read this first only after Root separately releases Task5d2. Implement the real
configured-App fixture for all five remaining output cases. Required source
contracts are task-5d-architecture.md and task-5d-budget-io.md. This pass writes
and compiles fixture code; it does not execute it or implement/run a client.
All five native cases, actual combined40matrix and original milestones remain.

Own only NEW .uwz-work/evidence/h2-streaming/integration-owned/output-fixture/,
new /tmp/uwz-task5d2-* and task-5d2-report.md in this plan workspace. You are not
alone; preserve others. No previous source/evidence/client/archive/product,
dependency/pin/ref edits, commits/push, subagents/external model CLI. Root owns
independent review, later exact runtime release and public checkpoint/push.

Allowed: new test-only Zig/Python compile/preparation source, Zig format,
compile-only actual Debug and ReleaseSafe fixture builds and inert text checks.
Never execute either binary, invoke a native constructor/test/fixture/server/
client/socket/SSLContext/resource/FD/kernel/registration/completion/error/fault
probe, create an actual transfer file/certificate or run live/checker scripts.
No stopped experiment. Generic full/native gates do not override this boundary.
Real file setup belongs in the future fixture main, not preparation execution.

## Exact restored basis

Start new source from /tmp/uwz-task5c3-fixture-v1/profile.zig,
SHA3336d93a5684d88c6a4373d305838ff646b89173abcfb4999a0fd7b1eb951920.
Root restored it from archive1e08922e and authenticated manifestfc64. Also restored
93-file /tmp/uwz-reviewed-libxev-c223-loop-callbacks from local Git c223bd886c6a51d2cd60def39dd9a68d701fea73.
Source /tmp/uwz-task4d-fix1-frozen1031files/fc69 remains immutable. Recovery is
task-5d2-prereq-recovery.json. All13 original compiler inputs were read/hash
checked: original C-native binding, six zig-out static archives, Zig executable,
xev/main/zslay/root sources match retained recipes. Do not rebuild/replace them.

Use actual Zig0.16 executable
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig. Discover local
SDK metadata with zig env for API verification; narrow Zig/API/lifetime skills
apply. Graphify before new source searches; provided paths are located.
Compiler recipes .uwz-work/evidence/h2-streaming/integration-owned/metadata/
fixture-debug-final.json and fixture-release-final.json are basis only. Copy/
adapt compile helper into your ownership; never run the old helper that writes
old logs. New frozen multi-file snapshot and actual Debug/RS outputs/receipts,
all caches/output under /tmp, bounded compile concurrency (j2 where supported),
no execution. Bind every new fixture file and actual direct inputs before/after,
1031 source/93 override unchanged; no reusing an old binary's receipt. Retain
all compiler stdout/stderr and failures. Any product defect must be reported,
not hidden by a harness substitute or product edit from this task.

## Fixed configuration and records

Retain eight connections/native streams,73728 receive payload, two caller body
bindings, write queue65536 and all prior request/header/capture capacities.
Public Server.preset(init.io,config).build_https/route_body/context/middleware
only. Keep health/echo/status/metrics/expired-control routes and32 body records.
Seven used tags: producer_reuse,producer_reuse_next,output_pressure_window,
output_pressure_ready,stream_file,early_final_order,early_final_recovery;
25 untouched spare_00..24. /limit/:tag quota1/bodylimit32/headers_only.
All six admitted inputs require P32/H32 with one end/no cancel/error, refusal
middleware1 with zero attempts/callbacks/input bytes; selected-subset semantics
in existing output-streaming/contracts.py are authoritative body models.
Actual callback chunks/maxspan are diagnostics, never packet assumptions.

Each admitted tag has distinct POST/path/query/target/tag/x-case/CL32 metadata.
IMPORTANT source ruling: ordinary H2 StreamingRequest.protocol is EMPTY, not
HTTP/2 or h2. Request defaults protocol="" (http/request.zig49); H2 server only
overrides for decoded extended-CONNECT :protocol (server.zig1874), and prior
metadata fixture214 explicitly checks protocol.len==0. Validate that exact
ordinary POST value and include it among the eight named retained byte slices.

Preserve existing bounded body record/status/log schema. Add separate explicit
producer/file diagnostics via a bounded output-status route and post-deinit
log records; each response stays<4096 bytes. Derive formatter bounds from known
ASCII validated metadata/counter fields, no truncation/allocated JSON. Do not
stuff large output state into the reused body binding or enlarge native pools.

## Three real producers and retained metadata

Three independent persistent producer states, each8192 scratch+1024 owned
metadata storage/eight named borrowed slices and owned ranges/copies:
method,target,path,query,protocol,tag,x-case,content-length. Only individual
slices may have response lifetime; never retain Request/StreamingRequest,
HeadersView/ParamsView arrays, BodyChunk or Response pointer. Check all expected
values before copying and on each producer callback before terminal retirement;
fail overflow, no allocation/truncation. Do not dereference borrowed slices
after successful end_chunks, which may synchronously retire their owner.

Real BodyEnd arms public begin_stream(status200,Content-Type,context,producer).
N16777313 output, periodic byte1+(absolute_offset%251) until final22-byte
final-upload-sentinel!, exact SHAe5b7e8c5bbad59c7bc86f18236a37661571e972f65c707d7dc1902386ec5e91d.
Generate/write<=8192 each. Only successful write advances offset/hash/success
count; WouldBlock returns pending with same offset and identical future retry.
Retry end_chunks on WouldBlock; done only after success, then no borrowed access.
Exactly2049 eventual successful writes, one successful terminal, errors0.
Record actual invocations/attempts/WouldBlock/pending/terminal attempts/metadata
checks and offset/hash; no manufactured counts or native saturation claim.

Independent producer state outlives input binding reuse. Record application
binding index/generation at begin, stable per record; B producer_reuse_next must
reuse A's first-free caller binding while A output remains pending. Record at
least one A metadata callback after B admission, checking A owned copies, never
native slot/connection indices. Optional expired controls cannot drive output.
BodyEnd releases fixture binding/admission state exactly once; output state
remains independent through Appdeinit. Producer done is accepted output, not
wire completion; later independent client proves exact payload/END.

## Actual FileSource and confined ordinary I/O observation

One separate stable file state/scratch8192/baseIo/vtable/descriptor ownership,
all live through Appdeinit. Future main creates owned regular24659-byte pattern
file in a Root-provided private runtime path, offset37/length24593/end24630,
selected SHA8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac.
Use real response.stream_file("200 OK","Content-Type: application/octet-stream\r\n",
FileSource{io,file,buffer,offset37,length24593}); API creates CL24593, no manual
CL/legacy send_file/buffered body/application producer substitute. On returned
success relinquish caller ownership once; every returned error retains caller
ownership and fails with no retry/fallback; caller cleanup uses original baseIo.

Implement only reviewed two-operation observation adapter per budget-Io note:
wrapper userdata stable state, reachable readPositional/close callbacks delegate
UNCHANGED args/results/errors through base.vtable(base.userdata,...), not wrapper
userdata. BaseIo for all setup/open/write/stat/server/caller cleanup/unrelated
I/O; copied other callbacks provably unreachable via this confined FileSource.
Count ordinary requested/returned reads/offset/errors/close, check span<=8192
inside[37,24630) without injecting errors, suppressing closes or altering fd.
Do not require exactlyfour reads or totalread24593 (shortreads/rereads valid).
Close may occur inline before successful stream_file return; do not require the
post-return transferred flag already set in close callback. Require one
transport close and no later second through Appdeinit in future success proof.
No error/descriptor/native refusal probe; pure returned-error ownership evidence
is a separately reviewed later task, never reconstruct stopped native tests.

## Early final and lifetimes

Middleware always retains X-Middleware. early_final_order returns403 with
literal17-byte early-final-order body and stop before quota/body admission/100;
no callback. early_final_recovery is the active quota1 holder and later normal
P32 success. The client later holds response stream credit0, grants8 then9 and
proves complete finalDATAEND before oneNO_ERRORreset; fixture must use ordinary
public final response semantics, no native/manual reset or queue manipulation.

All state/route definitions/metadata/producer/file buffers have stable addresses
from initialization through server.deinit and post-deinit logs. Keep modules
cohesive and shallow: producer metadata/output state and confined file-I/O are
real separate invariants if extracted, no forwarding layers/giant-file growth.
No globals, dead helpers, arbitrary public anytype or new markers. Structured
log.scoped, no direct stdout in production. Existing ownership/conventions bind.

Deliver actual source, new immutable snapshot, both actual compile receipts,
all raw failures/logs/maps/identities and report with changes/commands/results/
bounded state/self-review/open API questions. No native execution or output
case completion claim. Root reads/reviews before runner preparation/runtime
release. Full source/quality/native/platform gates and adoption remain required.
