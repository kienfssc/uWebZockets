# Task 5d1 first-pass report

Scoped pure preparation only. Output directory contains `contracts.py`, `test_contracts.py`, and `derived-contracts.md` (3 files). No wire observer, runner, fixture, native execution, or completion of any output case is claimed.

API: `span(total, offset, length)` rejects non-integer, negative, overrun, undersized total, and >8192 span; `digest(total, offset, length)` hashes bounded spans. `expected_records(case_ids)` emits 32 ordered modeled records and rejects invalid/duplicate IDs. `validate_records(case_ids, records)` checks identity, strict types, hashes and fixed fields while requiring bounded actual callback diagnostics for accepted records. The model does not fabricate producer/file measurements. `test_contracts.independent_digest` uses a rotated 251-byte period and bounded chunks, independently of the byte-index implementation. Both generate at most 8192 bytes per output span and neither retains the whole output; imports do not calculate the large digest. Request and response SHA values are separate constants in the contract artifact.

Hash results and literal boundary vectors are in `derived-contracts.md`. Full-set model totals middleware 7, attempts 6, begins 6, ends 6, cancels 0, failures 0, bytes 192, active 0, errors 0; every subset is checked.

Behavioral mutation RED: copy the two modules to `/tmp/uwz-task5d1-red`, replace `1 + (i % 251)` with `1 + ((i + 1) % 251)`, then run `/home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5d1-red/test_contracts.py`. Raw result: `Ran 5 tests in 2.203s`, `FAILED (failures=2)`, exit 1; boundary observed `02030405060708090a0b0c0d` versus `0102030405060708090a0b0c`, and mutated producer hash `abf98a7ff18dd050880face67aa0ec1d4056d0a07bbea6fc94f8f9c85a26825d` versus the frozen digest. An initial test erroneously expected `00` before the sentinel; it failed with actual `c8` and was corrected using the independent literal calculation, not by changing the generator.

GREEN command: `/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_contracts.py`. Raw output: `.....`, `Ran 5 tests in 1.953s`, `OK`, exit 0. Optimized command: `/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_contracts.py`. Raw output: `.....`, `Ran 5 tests in 1.920s`, `OK`, exit 0. Python tests have no Zig optimization mode.

AST parsing and inert importing both files with `/home/codespace/.python/current/bin/python3 -B -S` returned `AST and inert imports: 2 modules OK`, exit 0. No native or full local matrix was run because the first-pass brief explicitly forbids it.

Self-review: boundaries include wrap, 8192 crossing, transition to sentinel, selected range end and excluded suffix. Record identity, digest, and boolean/integer swaps are rejected. No claim is made about network delivery, actual callback sizes, write counts, native reuse, or measured throughput. Remaining: Root budget ruling and review, then separately authorized hash-only wire and response-credit observation, fixture and actual runner integration, and required preparation gates. All five cases and the combined matrix remain open.

## Second pass: response observer

Added three files in output-streaming; six files total in that directory. Authenticated original wire SHA-256 `c11c54602b5e46bd7dadfdeaa4a330b1b8a4661ebe4ee2709e5460e5d438cb5a`, raw observer `05e6565ab4939843d94e1c39df21d8ab85942b76cd237bcb116285f01cc049a7`. New wire `b8175caf974a4bb48ea7af16a89311b36d9ea93ebda423f8f235fa93ee3d624d`, copied raw observer unchanged `05e6565ab4939843d94e1c39df21d8ab85942b76cd237bcb116285f01cc049a7`, new test `2a4d24e0dda7c2d5807031e5453426144aec338ccc64c36202a558539a3acd0b`.

`register` retains positional arguments and adds keyword-only `mode`, `credit_policy`, `expected_sha256`. Small-body auto is default; hash-only needs a lowercase literal digest and exact length and only supports final-response policies. Manual mode never invokes acknowledgement in either body mode. Hash-only keeps an empty body array, hashes logical DATA incrementally and requires exact bytes and digest at completion. DATA needs final headers; end needs headers and cannot repeat; completion requires raw full-frame END and the required reset event. Inherited raw bounds/policies and read bound remain unchanged. Returned events are transient caller data, including flow-controlled padded length; this is not an independent credit ledger. No total numeric work budget was added.

Tests use actual pure h2 codec for 10000 bytes in split frames and padded DATA; inert event doubles plus actual raw frames exercise producer-size streamed in 8192-byte-or-smaller logical pieces, selected file and early-final hashes, premature refusal completion and reset, malformed event ordering, invalid expectations, body errors, small JSON, manual and auto acknowledgement, 40 sequential retired streams and inherited reset/close policies. No complete large response is materialized by the test or observer.

Normal command: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_wire.py`. Raw output: `............`, `Ran 12 tests in 2.115s`, `OK`, exit 0. Optimized command: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_wire.py`. Raw output: `............`, `Ran 12 tests in 2.203s`, `OK`, exit 0. Python has no Zig optimization mode.

Behavioral RED: copied modules to `/tmp/uwz-task5d1-observer-red`, deliberately changed the retention condition to retain both modes, and ran `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5d1-observer-red/test_wire.py WireTests.test_real_codec_padded_data WireTests.test_manual_hash_padded_and_json`. Raw output: `FF`, `Ran 2 tests in 0.002s`, `FAILED (failures=2)`, exit 1; both compare `bytearray(b'abc')` with `bytearray(b'')`. The initial test run had five test-construction errors: event constructors require keyword-only stream ID and the manually entered 10000-byte digest was wrong. Corrected those test inputs; did not change the bar. Copy initially retained read-only permissions and the edit failed with PermissionError; changed only owned copies to writable and continued.

AST parse plus inert imports of the three new modules using the pinned Python and package path returned `AST and inert imports: 3 modules OK`, exit 0. Self-review: raw END is checked independently of event END, so a partial final frame cannot complete; manual mode disables autoack but does not establish explicit-grant accounting. Actual h2 codec test is distinct from deliberately impossible ordering supplied through inert doubles. No runner, fixture, native behavior, timing, producer writes, credit sufficiency or case completion is claimed. Remaining: independently reviewed response ledger and source-derived work budget, fixture, runner, independent review, and separately authorized native gates and combined matrix.

## Observer review fix 1

The pinned h2 codec suppresses `StreamReset` when the request and response have both ended, although the raw observer sees the subsequent reset. Removed only the refusal policy's mandatory event check; emitted reset events still undergo policy, code and duplicate checks, and raw observation still requires a complete END followed by exactly one NO_ERROR reset. Public-cancel and application-failure event requirements remain. No API change. The frozen review-v1 directory remains untouched. Compared with that snapshot, `wire.py` changes one policy tuple; `test_wire.py` parameterizes request END and adds an actual-codec closed/half-open regression. No other observer files changed.

RED command before the wire fix: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_wire.py WireTests.test_refusal_actual_codec_closed_and_half_open`. Raw output: `E`, `Ran 1 test in 0.004s`, `FAILED (errors=1)`, exit 1; the `request_end=True` subtest raised `ValueError: missing reset event` from `wire.complete`. The test uses real h2 client/server state machines and an explicitly serialized reset frame, with no sockets. Closed streams emitted zero reset events; half-open streams emitted one. Both require raw reset evidence and check that completion fails before the last DATA byte and before reset.

GREEN command: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_wire.py`. Raw output: `.............`, `Ran 13 tests in 2.219s`, `OK`, exit 0. Selected optimized command: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_wire.py WireTests.test_refusal_actual_codec_closed_and_half_open WireTests.test_refusal_partial_and_reset WireTests.test_reset_and_close_policies`. Raw output: `...`, `Ran 3 tests in 0.003s`, `OK`, exit 0. Python has no Zig optimization mode.

AST parsing and inert imports of changed `wire` and `test_wire` under pinned Python and package path: `AST and inert imports: 2 modules OK`, exit 0. Current SHA-256: wire `5a008fd535b338da9df4f7b25517e1b76d791d9ba1c8289e43be3581c21947c0`; test `86a33bb79ac17de34f03ab1f830c6b748a5110adeb390073ba36f209ccb8dd37`; raw observer unchanged `05e6565ab4939843d94e1c39df21d8ab85942b76cd237bcb116285f01cc049a7`. Self-review: the raw frame parser, code/order requirement, length/hash checks and event validation are unchanged; no ledger, budget, fixture, runner, native execution or completed case is claimed. Scoped reviewer re-review remains required.

## Response receive-credit preparation

Added `response_credit.py` and `test_response_credit.py`, and extended `wire.accept` with optional keyword-only `credit`; output-streaming now has eight files. Reviewed v2 wire SHA `5a008fd535b338da9df4f7b25517e1b76d791d9ba1c8289e43be3581c21947c0`; new wire SHA `56f1add7d15d4ef102f5cf1bf5f7a7a8fd71977f2a7504637c38d5bbdc67a610`; ledger `30e3a142a51a248a09455ad0f691862cdbeb57c35a42cec2e406b7754920a207`; tests `d6302ba141204b65af2f188a6a5334f1752298ac99a7e910086ff95ccc09ebbb`; raw observer unchanged `05e6565ab4939843d94e1c39df21d8ab85942b76cd237bcb116285f01cc049a7`; prior wire tests unchanged `86a33bb79ac17de34f03ab1f830c6b748a5110adeb390073ba36f209ccb8dd37`.

Caller API: `new_state`, `settings_sent`, `settings_acknowledged`, `open_stream`, `grant`, `receive`, `end_response`, `retire`, `compare_public`. The caller pairs settings/explicit WINDOW_UPDATE actions with actual public h2 calls; these ledger functions never perform I/O or mutate a codec. Initial settings are recorded before the matching ACK; subsequent settings remain pending until a matching ACK, then their delta applies to active stream windows. A caller supplies the independent ledger to `wire.accept`, which applies actual ACK and DATA events once and marks response END. All registered responses must use manual credit when the ledger is supplied. The caller records explicit grants and stream openings and handles reset lifecycle explicitly; after END it retires ledger state when appropriate. `compare_public` checks connection credit and caller-supplied, publicly queryable stream IDs against the connection/stream minimum. The caller decides fully-closed eligibility; exceptions are not swallowed. No private h2 fields are used.

State retains at most eight stream records, one pending settings tuple, monotonic high-water ID and aggregate counters, with no per-DATA history. Flow bytes include padding, logical bytes do not. Negative stream windows after a SETTINGS reduction are supported; nonzero DATA requires both credits, zero-length DATA is valid, and strict integer/bounds/duplicate/unknown checks apply.

Behavioral RED used owned `/tmp/uwz-task5d1-credit-red` copies, changing `wire.accept` to debit logical length instead of `flow_controlled_length`. Command: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5d1-credit-red/test_response_credit.py CreditTests.test_real_8192_and_padded`. Raw output `F`, `Ran 1 test in 0.004s`, `FAILED (failures=1)`, exit 1; actual tuple `(17, 17, 8175)` versus expected `(17, 20, 8172)`.

GREEN ledger command: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_response_credit.py`. Raw output `.........`, `Ran 9 tests in 0.008s`, `OK`, exit 0. Changed observer regression command: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_wire.py`. Raw output `.............`, `Ran 13 tests in 2.159s`, `OK`, exit 0. Optimized ledger command: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_response_credit.py`. Raw output `.........`, `Ran 9 tests in 0.007s`, `OK`, exit 0. Python has no Zig optimization mode.

Real pure h2 codecs exercise initial and zero-setting ACK activation, public minimum comparisons, 8+9 and actual 8192+1 grants, independent stream and connection exhaustion, connection refill, padded DATA, logical hashing and caller-proved closed handling. Pure negative tests cover mismatched/unexpected ACK, duplicate pending, bounds, strict types, eight-stream limit, over-credit and public mismatches. AST and inert imports of changed wire, ledger and new test returned `AST and inert imports: 3 modules OK`, exit 0.

Self-review: ledger is receive-side only and records explicit caller actions; it cannot prove a driver actually sent a SETTINGS or WINDOW_UPDATE without the future driver pairing. It does not deduce full closure from request END or catch public codec query failures. No stage budget, request refund ordering, strict frame policy, fixture, runner or native case was implemented or claimed. Those, independent review, and all five cases plus combined matrix remain open.

## Client-core ordered refund and output-stage preparation

Added `request_credit.py`, `output_stage.py`, `test_client_core.py` and extended owned `raw_observer.py` and `wire.py`; output-streaming now contains 11 files. Reviewed credit-v1 subject was eight files with digest `7408dfc495d9671bdb062d18a5e9695d0ea02341d3d88283dd0f57321b0dac71`; its frozen copy and public observer checkpoint `14cec1650050b0e87a72e21f43967a105944d074` remain untouched. New SHA-256: wire `4d3c3b3edbfcc4d73cf76e6033830e828917263a7395cb26b8a740c6af75bbe6`; raw observer `f0eb75490c73f3280f804b9eca8d94af8b04ae616fef2e223f2e77bc84be8280`; request ledger `2e734c3e02cd90068c78619d6b65e6297b243655ab489af517ad92863a359565`; stage `44ff83978566d5a02356562717989501997c600a4acbb14303cc722799c59279`; tests `7906dbb6e8fe74346a17bc3c812038ecf4a16cfb215f00c00b8d70162f4a9b5a`; response ledger unchanged `30e3a142a51a248a09455ad0f691862cdbeb57c35a42cec2e406b7754920a207`.

Request API: `new_state`, `open_stream`, `send_data`, `end_request`, `reset_request`, `end_response`, `retire`, `refund`, `compare_public`, `server_initial_settings`, `client_settings_sent`. Caller pairs public outgoing actions with ledger mutations and retires response records. Request END and response END are distinct; a closed retired stream with positive debt remains until its exact refunds. At most 65 total request flow bytes, eight not-fully-closed streams, and 73 retained records (65 possible positive-debt identities plus eight active) are allowed. An unused retained zero-debt record consumes that bound rather than permitting unbounded history. Each raw completed WINDOW_UPDATE is checked and applied once; the per-read expected emitted-event sequence is limited to 631 and compared to the exact ordered codec events. Closed stream refunds debit retained debt without fabricating a codec event or updating closed public stream credit. Connection and stream public send windows are checked separately from receive windows.

Output API: `new_stage(kind, primary, expected_acks)`, `register`, `retire`, `enter_final`, `finish_final`; `wire.accept(..., request=..., credit=..., stage=...)` integrates both ledgers and raw/stage checks. The caller pairs actual request/settings/grant actions with the relevant ledger and registration/retirement operations. Stage counts each bounded decrypted read before raw processing; byte budgets producer 18243676, file 1693852, early 1447948. Strict frame admission validates server initial settings and declared ACKs, HEADERS, unpadded DATA, known refunds and allowed reset, with source-derived payload, count and stream bounds. Final entry requires completed primary, no remaining raw/response obligations, a complete raw frame and acknowledged settings, and carries request debt into `1487112 + 13 * debt`; new request DATA/settings/reset are prohibited. Exactly 33 final auxiliary responses must retire before `finish_final`. No receive-call cap or existing deadline was changed.

Behavioral RED: in `/tmp/uwz-task5d1-core-red`, mutate request ledger `emits = not closed(record)` to `emits = True`. Command `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5d1-core-red/test_client_core.py ClientCoreTests.test_actual_ordered_before_after_end ClientCoreTests.test_actual_late_closed_stream_debt`. Raw output `EE`, `Ran 2 tests in 0.004s`, `FAILED (errors=2)`, exit 1; both errors `ValueError: WINDOW_UPDATE event sequence differs` from actual pinned codec events.

GREEN command `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_client_core.py`: raw `........`, `Ran 8 tests in 0.006s`, `OK`, exit 0. Optimized same command with `-O` after `-S`: raw `........`, `Ran 8 tests in 0.006s`, `OK`, exit 0. Affected receive-credit suite with the same interpreter/options and `test_response_credit.py`: raw `.........`, `Ran 9 tests in 0.011s`, `OK`, exit 0. Affected observer suite with `test_wire.py`: raw `.............`, `Ran 13 tests in 2.122s`, `OK`, exit 0. Python has no Zig optimization mode. Initial final-collection test failed because request END was mistakenly prohibited in final stage; GET HEADERS with END are necessary for the 33 final requests. The guard was corrected to prohibit DATA, settings and reset while allowing request END.

Tests exercise actual pure h2 codec equal updates, update before/after END in one read, suppression after closure, late debt after observer retirement, partial frame application, and public minima. Pure frame/stage tests cover exact budgets and one-byte overflow, invalid settings/frame categories/flags/size, duplicate ACK, primary frame caps, 33 final responses with residual debt and no new DATA. AST/inert imports of five changed/new modules under pinned Python returned `AST and inert imports: 5 modules OK`, exit 0.

Self-review: these are caller-owned observations, not evidence that a future driver paired the actual public calls correctly; the driver must explicitly pair each action and enumerate its stage. No per-read history or whole producer body is retained. The exact source/current-input binding, independent preparation review, fixture, runner, native gates, all five actual cases and combined matrix remain outstanding; no completion or throughput claim is made.

## Overall fix round 2: incoming reset closes request side

At completion of a validated incoming reset, `raw_observer` now calls `request_credit.incoming_reset`. The latter marks reset and both directions closed while retaining outstanding request debts. It does not invoke an outgoing operation. Raw reset code/order and emitted-event validation are unchanged. Existing fully-closed eligibility prevents public stream queries; retired positive-debt records remain until their own refunds. Only `raw_observer.py`, `request_credit.py` and `test_client_core.py` changed relative to the frozen client-core review subject; all frozen/public versions remain untouched.

Actual pinned pure-codec RED before the fix: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_client_core.py ClientCoreTests.test_actual_reset_closes_unfinished_upload`. Raw output `E`, `Ran 1 test in 0.003s`, `FAILED (errors=1)`, exit 1: `ValueError: WINDOW_UPDATE event sequence differs`. The client sends two request bytes without END; the same incoming read carries final response END, reset 0, and a one-byte stream refund. The fixed observer sees the emitted reset and no window event, preserves one byte of stream debt through response retirement, and accepts the remaining one-byte late stream refund with no event. Closed public stream query eligibility is rejected.

A separate actual `wire.accept` strict-stage regression feeds a serialized 30-byte SETTINGS payload with source-shaped IDs 1, 2, 3, 6, 8, then an ACK corresponding to the recorded initial client SETTINGS. The public pure h2 codec processes those bytes and a real codec-serialized response HEADERS/DATA/END; both independent ledgers and stage are registered and retired. This source-shaped serialization is protocol-byte evidence, not a native server result.

GREEN commands, each with prefix `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S` and path `.uwz-work/evidence/h2-streaming/integration-owned/output-streaming/`:
- `test_client_core.py`: raw `..........`, `Ran 10 tests in 0.011s`, `OK`, exit 0.
- `test_response_credit.py`: raw `.........`, `Ran 9 tests in 0.007s`, `OK`, exit 0.
- `test_wire.py`: raw `.............`, `Ran 13 tests in 2.242s`, `OK`, exit 0.
- With `-O` immediately after `-S`, `test_client_core.py ClientCoreTests.test_actual_reset_closes_unfinished_upload ClientCoreTests.test_actual_wire_strict_stage_both_ledgers`: raw `..`, `Ran 2 tests in 0.004s`, `OK`, exit 0.

AST parse and inert import of changed `raw_observer`, `request_credit`, and `test_client_core` with pinned Python/package path returned `AST and inert imports: 3 modules OK`, exit 0. Current SHA-256 raw `587e1e586d6e7063c0144b9d74fcf9a16f12c829109fc4ab3e1a469b4aa2d54d`; request `14a0b30cda289a77aff195c534d8aa3af58c2ff849833666e0eef3294252ca24`; test `0cc08362fd68c564277769840228323c3d09137e920772a0af9e0aa4a52c7737`; unchanged wire `4d3c3b3edbfcc4d73cf76e6033830e828917263a7395cb26b8a740c6af75bbe6`, stage `44ff83978566d5a02356562717989501997c600a4acbb14303cc722799c59279`, response ledger `30e3a142a51a248a09455ad0f691862cdbeb57c35a42cec2e406b7754920a207`.

Self-review: closure is recorded at complete raw reset, before any later frame in the same read, with no debt removal and no relaxation of reset policy or event-sequence comparisons. The pinned codec, not a fake, supplies the reset/absence observations. Scoped independent re-review and final preparation/current-input binding remain required. Fixture, runner, native execution, all five output cases, and the actual combined 40-case matrix remain open.

## Overall fix round 3: function-based harness conformance

Converted the four authored test modules to named functions and added one test-only `test_support.py`. There are no authored classes or Python `assert` statements. Explicit `if`/`raise` checks and `expect_error` survive `-O`; the inert `SimpleNamespace` codec double exposes its caller-owned `probe` dictionary, and retained imported h2 codecs remain real codecs. `run(globals(), sys.argv[1:])` runs every named test or only explicitly supplied test names. Guarded imports do not execute tests. The earlier class-based test versions are historical provenance, not the current harness; they remain in prior frozen/public artifacts and `/tmp/uwz-task5d1-round3-before`.

Before conversion, parsing those four prior files reported respectively `ClassDef 1 Assert 0`, `ClassDef 2 Assert 0`, `ClassDef 2 Assert 0`, `ClassDef 1 Assert 0`; the explicit conformance check exited 1. After conversion, AST comparison of names and proof calls with the prior sources returned:
```
test_contracts.py 5 tests 21 proof sites ClassDef/Assert 0
test_wire.py 13 tests 29 proof sites ClassDef/Assert 0
test_response_credit.py 9 tests 34 proof sites ClassDef/Assert 0
test_client_core.py 10 tests 40 proof sites ClassDef/Assert 0
```
The 37 named checks and 124 proof sites map one-for-one. Boundary/literal/second-algorithm and all subset checks, real codec versus event-double ordering, reset/close, padded credit, public window, strict stages, final 33 and all original negative loops remain. The prior `subTest` loop is now an ordinary loop and still checks both request-end states on success. Six runtime modules compare byte-for-byte against `/tmp/uwz-task5d1-round3-before`: `6 runtime modules byte-identical to before`, exit 0.

Ordinary complete command:
```
for suite in test_contracts test_wire test_response_credit test_client_core; do PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S ".uwz-work/evidence/h2-streaming/integration-owned/output-streaming/$suite.py" || exit; done
```
Raw stdout reports each test name as `PASS test_...`, followed by `PASS 5 checks`, `PASS 13 checks`, `PASS 9 checks`, `PASS 10 checks`; stderr empty, exit 0. Identical command with `-O` after `-S` reports the same 37 named PASS lines and four totals, stderr empty, exit 0. Selected-function API example: `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-streaming/test_client_core.py test_actual_reset_closes_unfinished_upload`. Unknown names raise an error. Python has no Zig optimization mode.

Four actual mutation REDs used copied files in `/tmp/uwz-task5d1-round3-{pattern,retention,padding,reset}` and the new function-based selected test with pinned Python `-B -S -O`; each exited 1 and produced these raw final errors:
- pattern `test_contracts.py test_boundaries`: `AssertionError: '02030405060708090a0b0c0d' != '0102030405060708090a0b0c'`;
- retention `test_wire.py test_real_codec_padded_data`: `AssertionError: bytearray(b'abc') != bytearray(b'')`;
- padding `test_response_credit.py test_real_8192_and_padded`: `AssertionError: (17, 17, 8175) != (17, 20, 8172)`;
- reset `test_client_core.py test_actual_reset_closes_unfinished_upload`: `ValueError: WINDOW_UPDATE event sequence differs`.
These mutations altered only owned temporary copies: respectively pattern phase, hash-only body retention, DATA flow debit, and restoration of the old response-only reset behavior. No native faults were used.

AST/static and inert-import check on all four tests plus support returned `ClassDef/Assert: 0; AST/inert imports: 5 modules OK`, exit 0. New frozen 12-file component snapshot `/tmp/uwz-task5d1-round3-current` is read-only. SHA-256 identities:
```
contracts.py bcdad460e8748cc2c5e69a21332a075a9408587238fc4e47f29eac83a98392ce
wire.py 4d3c3b3edbfcc4d73cf76e6033830e828917263a7395cb26b8a740c6af75bbe6
raw_observer.py 587e1e586d6e7063c0144b9d74fcf9a16f12c829109fc4ab3e1a469b4aa2d54d
response_credit.py 30e3a142a51a248a09455ad0f691862cdbeb57c35a42cec2e406b7754920a207
request_credit.py 14a0b30cda289a77aff195c534d8aa3af58c2ff849833666e0eef3294252ca24
output_stage.py 44ff83978566d5a02356562717989501997c600a4acbb14303cc722799c59279
derived-contracts.md 3955075be46dce0b660926ad3ae44f06596690304b35f13321296cb145aeeeba
test_contracts.py 24ca709eff160b535f48c0fabd2d4f46a944021f95385f792424fffebd81eb35
test_wire.py 3c26fd766442d34260fbb459c8eeaeb9111ed6af4d08025024d1162596520829
test_response_credit.py 67b13dfc56aa47bc7433c5798345393b82488adbd00a66af062ba7b6338999be
test_client_core.py 319ba89fb23512071ac9d56a5ed0f4b2157e4481efe57261ccbb7bffaa530c7e
test_support.py f56690f373ae2f037a553f33bc75e8594fe7ef5dd9ad65477fbb586f07e4d095
```
Self-review: the only callable runtime additions are in test-only support; no runtime code or derived payload artifact changed. Pinned pure h2 remains external and untouched. This is overall round 3/5 and requires scoped independent re-review. Fixture/runner/native gates, all five output cases, the actual full 40-case matrix, and final adoption remain open.

The exact common stdout of both the ordinary and optimized complete runs was:
```
PASS test_all_subsets
PASS test_boundaries
PASS test_hashes
PASS test_invalid
PASS test_reject_swaps
PASS 5 checks
PASS test_frozen_range_and_early_responses
PASS test_inert_bad_events
PASS test_invalid_registration
PASS test_manual_hash_padded_and_json
PASS test_producer_stream_online
PASS test_real_codec_manual_hash_and_split
PASS test_real_codec_padded_data
PASS test_refusal_actual_codec_closed_and_half_open
PASS test_refusal_partial_and_reset
PASS test_reset_and_close_policies
PASS test_retirement_and_old_stream
PASS test_small_auto_and_manual_padded
PASS test_wrong_length_digest_and_overflow
PASS 13 checks
PASS test_actual_connection_exhaustion_and_grant
PASS test_actual_staged_8192
PASS test_bad_ack_and_public_mismatch
PASS test_bounded_streams_and_pending
PASS test_invalid_inputs_and_exhaustion
PASS test_real_8192_and_padded
PASS test_real_ack_stages_and_early_response
PASS test_settings_and_negative
PASS test_wire_requires_manual
PASS 9 checks
PASS test_actual_equal_and_late_refunds
PASS test_actual_late_closed_stream_debt
PASS test_actual_ordered_before_after_end
PASS test_actual_reset_closes_unfinished_upload
PASS test_actual_wire_strict_stage_both_ledgers
PASS test_final_33_with_carried_debt
PASS test_invalid_server_initial_window
PASS test_partial_invalid_and_direction_isolation
PASS test_stage_budget_and_invalid_frames
PASS test_strict_ack_size_and_boundary
PASS 10 checks
```
For the four mutation invocations the exact command prefix was `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages PYTHONOPTIMIZE= /home/codespace/.python/current/bin/python3 -B -S -O`, followed by the indicated absolute `/tmp/uwz-task5d1-round3-<mutation>/<test-file>` and selected function listed above; stdout was empty and stderr contained the tracebacks ending with the exact errors listed above.
