# Task5d1 reopened conformance fix round3/5: function-based client checks

Resume original client-core owner, same output-streaming directory and owned
/tmp/uwz-task5d1-* plus task-5d1-report.md append. You are not alone; preserve
others. All frozen/public versions remain immutable; no product/fixture/docs/
pin/ref/commit/push/subagent/external model CLI. Pure-only scope, no native/
SSL/socket/process/FD/resource/kernel/registration/completion/error/fault probes,
compiler/build or realrunner invocation. Pure H2 codec constructors remain
allowed for offline data tests only.

Root-confirmed open P2 from mandatory AGENTS/CODING7.1 contract:
The current authored test_contracts.py, test_wire.py, test_response_credit.py
and test_client_core.py define classes/inheritance. No harness exception exists.
Examples: test_wire.py Fake and WireTests, response_credit test CreditTests and
nested Public, and both other unittest.TestCase subclasses. This is the same
defect found and fixed in Task5d2; prior review omission does not waive the rule.
Current tests must be function-based with explicit caller-owned state, no
authored classes/inheritance/implicit object state. Imported third-party H2
codecs and standard-library doubles are allowed; do not rewrite them.

Rewrite only those four test modules and, if earned by shared invariants, one
small named function-based test support module. Preserve every actual behavior,
boundary, negative check and real codec path in all37 existing tests:5contracts,
13wire,9receive-credit,10client-core. Do not delete checks, narrow input ranges,
weaken expectedtypes/codes/lengths/hashes, replace actual codec with fake, or
change six reviewed production modules/contracts.py/derived-contracts.md.
The six production Python module hashes must remain exactly as reviewed1678c387;
test-support is test-only, not runtime dependency. No production API changes.

Use explicit if/raise proof conditions (built-in exceptions), never Python
assert statements disabled by -O. Named functions and explicit probe dict/list
state; callbacks required by codec doubles may use standard-library tools with
documented visible probe data, not a new custom class. Guard all executable test
entrypoints; imports inert, boundedN/payload generation and retention unchanged.
Preserve independent expected literals/secondary hash algorithm; do not turn
tests into implementation mirrors. Static no-ClassDef/no-Assert conformance is
an explicit repository contract, not a replacement for behavior tests.

Retain historical test versions as frozen provenance and clarify that they are
not the current adopted harness. Show the conformance failure on the actual
current prior test sources before editing; no need to rerun identical old tests.
Run all affected37 behavior checks on the new harness and meaningful selected
optimized checks (prefer whole37 if its small bounded cost); actual pattern/
retention/padded-credit/reset mutation must still be detected using owned copied
production source and function-based checks, no native faults. Preserve raw
commands/stdout/stderr/exits, check names/counts/mappings and any failed edits.
AST/inert imports of every new/changed module; no optional class-style exception
or return to unittest inheritance. Existing unittest.mock library use is allowed.

Freeze a NEW current component snapshot and record allactual unchanged-runtime
versus changed-test/support identities. Do not edit old11files1678c387 or public
70a4028 archive. Append full report including preserved coverage checklist/API
for running selected functions and actual results. Root reads exact evidence
before original client-core reviewer's scoped re-review. This is round3overall
Task5d1, not a counter reset; Root handles any further escalation by skill.
Native driver/five output cases/full40/fullgates/adoption remain required.
