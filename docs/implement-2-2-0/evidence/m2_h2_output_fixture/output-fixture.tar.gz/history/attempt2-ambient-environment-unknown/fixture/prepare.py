import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/workspaces/uWebZockets')
HERE = ROOT / '.uwz-work/evidence/h2-streaming/integration-owned/output-fixture'
SOURCE = Path('/tmp/uwz-task4d-fix1-frozen')
OVERRIDE = Path('/tmp/uwz-reviewed-libxev-c223-loop-callbacks')
RECIPES = ROOT / '.uwz-work/evidence/h2-streaming/integration-owned/metadata'
OUT = Path('/tmp/uwz-task5d2-' + sys.argv[1])
OUT.mkdir(exist_ok=False)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def tree(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}

def tree_hash(mapping):
    return hashlib.sha256(json.dumps(list(mapping.items())).encode()).hexdigest()

snapshot = OUT / 'fixture'
snapshot.mkdir()
for name in ('profile.zig', 'output.zig', 'file_observer.zig', 'prepare.py'):
    shutil.copyfile(HERE / name, snapshot / name)
    (snapshot / name).chmod(0o444)
source_before = tree(SOURCE)
override_before = tree(OVERRIDE)
fixture_before = tree(snapshot)
for mode, recipe in [('debug', 'fixture-debug-final.json'), ('release', 'fixture-release-final.json')]:
    original = json.loads((RECIPES / recipe).read_text())
    argv = original['argv'][:]
    argv = [arg.replace(str(RECIPES / 'profile.zig'), str(snapshot / 'profile.zig')) for arg in argv]
    for i, arg in enumerate(argv):
        if arg == '--cache-dir': argv[i+1] = str(Path('/tmp/uwz-task5d2-attempt1') / (mode + '-cache'))
        if arg == '--global-cache-dir': argv[i+1] = str(Path('/tmp/uwz-task5d2-attempt1') / (mode + '-global'))
        if arg.startswith('-femit-bin='): argv[i] = '-femit-bin=' + str(OUT / (mode + '-profile'))
    inputs = {path: digest(Path(path)) for path in original['input_sha256'] if not path.endswith('/metadata/profile.zig')}
    proc = subprocess.run(argv, cwd=SOURCE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (OUT / (mode + '.stdout')).write_bytes(proc.stdout)
    (OUT / (mode + '.stderr')).write_bytes(proc.stderr)
    after = {path: digest(Path(path)) for path in inputs}
    binary = OUT / (mode + '-profile')
    receipt = {'argv': argv, 'cwd': str(SOURCE), 'exit_status': proc.returncode,
        'inputs_before': inputs, 'inputs_after': after, 'fixture_before': fixture_before,
        'fixture_after': tree(snapshot), 'source_before': source_before, 'source_after': tree(SOURCE),
        'source_before_sha256': tree_hash(source_before), 'source_after_sha256': tree_hash(tree(SOURCE)),
        'override_before': override_before, 'override_after': tree(OVERRIDE),
        'binary_sha256': digest(binary) if binary.exists() else None,
        'execution': 'compile only; binary not executed'}
    (OUT / (mode + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    if proc.returncode: sys.exit(proc.returncode)
