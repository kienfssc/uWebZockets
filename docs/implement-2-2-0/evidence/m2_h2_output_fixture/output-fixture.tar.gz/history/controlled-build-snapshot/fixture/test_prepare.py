import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get('UWZ_PREPARE_SOURCE', str(HERE / 'prepare.py')))

class ArgProbe:
    def __init__(self, values):
        self.values = values
        self.reads = []
    def __getitem__(self, key):
        self.reads.append(key)
        return self.values[key]
    def __iter__(self):
        self.reads.append('iter')
        return iter(self.values)
    def __len__(self):
        self.reads.append('len')
        return len(self.values)

class EffectsBlocked(Exception):
    pass

def load_guarded(argv):
    source = SOURCE.read_text()
    probe = ArgProbe(argv)
    effects = []
    def block(*args, **kwargs):
        effects.append((args, kwargs))
        raise EffectsBlocked('blocked before filesystem or compiler effect')
    namespace = {'__name__': 'inert_prepare', '__file__': str(SOURCE)}
    caught = None
    with mock.patch.object(sys, 'argv', probe), mock.patch.object(Path, 'mkdir', side_effect=block), mock.patch.object(subprocess, 'run', side_effect=block):
        try:
            exec(compile(source, str(SOURCE), 'exec'), namespace)
        except (EffectsBlocked, IndexError) as exc:
            caught = exc
    return namespace, probe.reads, effects, caught

class PrepareTest(unittest.TestCase):
    def test_import_empty_and_foreign_argv_is_inert(self):
        for argv in ([], ['validator', 'foreign']):
            with self.subTest(argv=argv):
                _, reads, effects, caught = load_guarded(argv)
                self.assertIsNone(caught)
                self.assertEqual(reads, [])
                self.assertEqual(effects, [])

    def test_ast_has_main_guard(self):
        module = ast.parse(SOURCE.read_text())
        self.assertTrue(any(isinstance(node, ast.If) and isinstance(node.test, ast.Compare)
                            and isinstance(node.test.left, ast.Name) and node.test.left.id == '__name__'
                            for node in module.body))

    def test_actual_command_path_passes_and_records_only_controlled_env(self):
        source = SOURCE.read_text()
        namespace = {'__name__': 'inert_prepare', '__file__': str(SOURCE)}
        recipe = {'argv': ['/absolute/zig', 'build-exe', '--cache-dir', 'cache', '--global-cache-dir', 'global', '-femit-bin=old'], 'input_sha256': {}}
        calls = []
        receipts = []
        def fake_run(argv, **kwargs):
            calls.append((argv[:], kwargs.copy()))
            return subprocess.CompletedProcess(argv, 0, b'', b'')
        def fake_write_text(path, text, *args, **kwargs):
            receipts.append(json.loads(text))
            return len(text)
        expected = {'LC_ALL': 'C.UTF-8'}
        expected_id = hashlib.sha256(json.dumps(expected, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        with mock.patch.dict(os.environ, {'ZIG_LIB_DIR': '/ambient/override', 'CC': 'ambient-cc', 'SECRET_TEST': 'do-not-copy'}, clear=True), \
             mock.patch.object(Path, 'mkdir'), mock.patch.object(Path, 'chmod'), \
             mock.patch.object(Path, 'read_text', return_value=json.dumps(recipe)), \
             mock.patch.object(Path, 'write_bytes'), mock.patch.object(Path, 'write_text', new=fake_write_text), \
             mock.patch.object(Path, 'exists', return_value=False), \
             mock.patch.object(Path, 'rglob', return_value=[]), \
             mock.patch('shutil.copyfile'), mock.patch.object(subprocess, 'run', side_effect=fake_run), \
             mock.patch.object(sys, 'argv', ['validator', 'double']):
            exec(compile(source, str(SOURCE), 'exec'), namespace)
            if 'main' in namespace:
                namespace['main'](['double'])
        self.assertEqual(len(calls), 2)
        self.assertEqual(len(receipts), 2)
        for (_, kwargs), receipt in zip(calls, receipts):
            self.assertEqual(kwargs.get('env'), expected)
            self.assertEqual(receipt['environment'], kwargs['env'])
            self.assertEqual(receipt['environment_sha256'], expected_id)
            self.assertEqual(receipt['exit_status'], 0)

if __name__ == '__main__':
    unittest.main()
