"""Public-codec synthetic pause and control schedule checks."""
import hashlib
import json
import adapter
import cases
import catalogue
import h2_client
import hpack
import model
import test_ready


def record(tag, state):
    if state == 'paused':
        value = model.checkpoint(tag, 'paused')
    elif state == 'active':
        value = model.record(tag, True, 'after')
        value.update(bytes=0, sha256=model.EMPTY_HASH, chunks=0, max_span=0, ends=0, active=True,
                     callback_checks=2, terminal_checks=0)
    else:
        value = model.record(tag, True, 'after')
    if value['bytes']:
        value.update(chunks=1, max_span=value['bytes'], callback_checks=4)
        if value['max_span'] > 8192:
            value.update(chunks=2, max_span=8192, callback_checks=6)
    return value


def check(case, premature=False, app=None, prior=(), final=False, wrong_tag=False, paths=None):
    dec, enc = hpack.Decoder(), hpack.Encoder()
    if paths is None:
        paths = []
    if app is None:
        app = {'records': {tag: model.record(tag, False, 'before') for tag in model.SPECS}, 'heads': 0}
    peer = {'buffer': bytearray(), 'startup': True, 'pending': [], 'paths': paths, 'stream': {}, 'records': app['records'], 'payload': {}}

    def respond(stream, body):
        block = enc.encode(((':status', '200'), ('x-middleware', 'retained')))
        peer['pending'].append(test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body))

    def finish(tag):
        peer['records'][tag] = record(tag, 'complete')
        respond(peer['stream'][tag], json.dumps(peer['records'][tag]).encode())

    def request(path, stream):
        if path == '/health':
            respond(stream, b'ok')
        elif path == '/metrics':
            metrics = {key: sum(item[key] for item in app['records'].values()) for key in model.COMMON_COUNTERS + ('bytes',)}
            metrics.update(active=0, paused=0, buffered_middleware=app['heads'] - metrics['middleware'], slot0_active=False, slot1_active=False)
            respond(stream, json.dumps(metrics).encode())
        elif path.startswith('/status/'):
            item = dict(peer['records'][path[8:]])
            if wrong_tag and path == '/status/' + case:
                item['tag'] = 'control_one'
            respond(stream, json.dumps(item).encode())
        elif path.startswith('/control/'):
            _, _, action, tag = path.split('/')
            active = peer['records'][tag]['active']
            reply = 'ok' if active and peer['records'][tag]['paused'] else 'BodyNotPaused' if active else 'BodyControlExpired'
            respond(stream, reply.encode())
            if reply == 'ok':
                finish(tag)
        else:
            raise RuntimeError('unexpected request')

    def send(data):
        if peer['startup']:
            peer['startup'] = False
            return
        peer['buffer'].extend(data)
        while len(peer['buffer']) >= 9:
            size = int.from_bytes(peer['buffer'][:3], 'big')
            if len(peer['buffer']) < size + 9:
                return
            packet = bytes(peer['buffer'][:size + 9])
            del peer['buffer'][:size + 9]
            kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
            if kind == 1:
                entries = list(dec.decode(packet[9:]))
                headers = dict(entries)
                if len(entries) != 4 or len(headers) != len(entries):
                    raise RuntimeError('request header multiplicity differs')
                path = headers[':path']
                method = 'POST' if path.startswith('/upload/') else 'GET'
                if headers != {':method': method, ':scheme': 'https', ':authority': 'localhost', ':path': path} or bool(flags & 1) != (method == 'GET'):
                    raise RuntimeError('request headers differ')
                app['heads'] += 1
                peer['paths'].append(path)
                if path.startswith('/upload/'):
                    tag = path[8:]
                    peer['stream'][tag] = stream
                    peer['payload'][stream] = {'hash': hashlib.sha256(), 'count': 0, 'frames': 0, 'ends': 0}
                    peer['records'][tag] = record(tag, 'paused' if tag == 'begin_pause_empty' else 'active')
                elif flags & 1:
                    request(path, stream)
            elif kind == 0:
                tag = next(tag for tag, value in peer['stream'].items() if value == stream)
                ordinal = peer['payload'][stream]['frames']
                expected_data = ((8192, False), (4097, True)) if tag == 'partial_pause' else ((0, True),) if tag == 'begin_pause_empty' else ((32, True),)
                if ordinal >= len(expected_data) or (size, bool(flags & 1)) != expected_data[ordinal] or flags & ~1:
                    raise RuntimeError('DATA ordinal contract differs')
                peer['payload'][stream]['hash'].update(packet[9:])
                peer['payload'][stream]['count'] += size
                peer['payload'][stream]['frames'] += 1
                peer['payload'][stream]['ends'] += int(bool(flags & 1))
                if tag in ('partial_pause', 'final_pause'):
                    peer['records'][tag] = record(tag, 'paused')
                elif tag.startswith('control_') and flags & 1:
                    finish(tag)
                if premature and tag in ('partial_pause', 'final_pause', 'begin_pause_empty'):
                    finish(tag)

    def receive():
        if not peer['pending']:
            raise RuntimeError('missing synthetic response')
        return peer['pending'].pop(0), 2

    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, selected_before=prior, clock=lambda: 2)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), 2)
    adapter.run_case(context, receive)
    if premature:
        raise RuntimeError('premature completion accepted')
    tag = case
    expected = ['/health', '/upload/' + tag, '/status/' + tag]
    if case == 'control_rules':
        expected = ['/health', '/upload/control_one', '/status/control_one', '/control/resume/control_one',
                    '/status/control_one', '/status/control_one', '/upload/control_two', '/status/control_two',
                    '/control/resume/control_one', '/control/cancel/control_one', '/status/control_one', '/status/control_two',
                    '/status/control_two', '/control/resume/control_one', '/control/cancel/control_one',
                    '/control/resume/control_two', '/control/cancel/control_two', '/status/control_one', '/status/control_two', '/health']
    else:
        if case == 'partial_pause':
            expected.append('/status/' + tag)
        expected += ['/control/resume/' + tag, '/status/' + tag, '/health']
    if final:
        adapter.final_collection(context, receive)
        expected += ['/status/' + tag for tag, _, _, _ in model.BODY_SPECS] + ['/metrics']
        model.validate_records(prior + (case,), 'before', app['records'])
    if peer['paths'] != expected:
        raise RuntimeError('request order differs')
    for tag, stream in peer['stream'].items():
        size = peer['payload'][stream]['count']
        frames = 2 if tag == 'partial_pause' else 1
        if peer['payload'][stream]['frames'] != frames or peer['payload'][stream]['ends'] != 1:
            raise RuntimeError('DATA framing differs')
        if peer['payload'][stream]['hash'].hexdigest() != model.accepted_hash(size):
            raise RuntimeError('payload differs')
    print(case + ' passed: heads=%d flow=%d' % (len(expected) - (68 if final else 0), context['request']['case']['sent']))
    return app


def main():
    unsupported = [case for case in catalogue.CASES if case not in cases.IMPLEMENTED]
    if len(unsupported) != 15:
        raise RuntimeError('unsupported inventory differs')
    for case in unsupported:
        try:
            cases.select((case,))
        except ValueError:
            continue
        raise RuntimeError('unsupported case selected')
    for case in ('partial_pause', 'final_pause', 'begin_pause_empty', 'control_rules'):
        check(case)
    app = check('partial_pause')
    check('final_pause', app=app, prior=('partial_pause',), final=True)
    paths = []
    try:
        check('final_pause', wrong_tag=True, paths=paths)
    except ValueError as exc:
        if str(exc) != 'record mismatch: tag' or paths != ['/health', '/upload/final_pause', '/status/final_pause']:
            raise RuntimeError('wrong-tag rejection differs') from exc
        print('wrong tag rejected before control: ' + str(exc))
    else:
        raise RuntimeError('wrong tag accepted')
    try:
        check('final_pause', premature=True)
    except ValueError as exc:
        print('premature response rejected: ' + str(exc))
    else:
        raise RuntimeError('premature response was accepted')


if __name__ == '__main__':
    main()
