"""Serialized cancellation/reset schedules with model-derived synthetic peer records."""
import hashlib
import json
import adapter
import h2_client
import hpack
import model
import test_ready


def terminal(tag):
    item = model.record(tag, True, 'after')
    if item['bytes']:
        item.update(chunks=1, max_span=item['bytes'])
    return item


def paths(case):
    result = ['/health', '/echo', '/limit/' + case + '?case=' + case, '/status/' + case]
    if case != 'peer_reset':
        result.append('/control/cancel/' + case)
    result += ['/status/' + case, '/control/resume/' + case, '/control/cancel/' + case,
               '/limit/' + case + '_recovery?case=' + case + '_recovery',
               '/control/resume/' + case, '/control/cancel/' + case, '/health']
    return result


def check(case, *, app=None, prior=(), final=False, fault=None):
    decoder, encoder = hpack.Decoder(), hpack.Encoder()
    if app is None:
        app = {'records': {tag: model.record(tag, False, 'before') for tag in model.SPECS}, 'heads': 0}
    state = dict(startup=True, buffer=bytearray(), pending=[], heads=0, streams={}, payloads={},
                 statuses=0, stale=0, terminated=False, resets=0, settings=0, refunded=False,
                 refund_queued=False, sibling_done=False, recovery_done=False, final=False, reads=0)
    order, caller_time = paths(case), [1]
    primary_length = 7 if case == 'cancel_ready' else 32

    def clock():
        caller_time[0] += 1
        return caller_time[0]

    def response(stream, body):
        block = encoder.encode(((':status', '200'), ('x-middleware', 'retained')))
        state['pending'].append(test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body))

    def terminate():
        if state['terminated'] or state['statuses'] != 1:
            raise RuntimeError('terminal action ordinal differs')
        state['terminated'] = True
        item = terminal(case)
        item.update(stale_resume=0, stale_cancel=0)
        if fault == 'terminal_reason':
            item['reason'] = 'sink_failure'
        if fault == 'terminal_metadata':
            item['metadata_begin'] = 0
        app['records'][case] = item

    def queue_refund():
        if state['refund_queued'] or state['stale'] != 2:
            raise RuntimeError('primary refund ordinal differs')
        state['refund_queued'] = True
        if fault != 'missing_refund':
            amount = primary_length + int(fault == 'excess_refund')
            state['pending'].append(test_ready.frame(8, 0, 0, amount.to_bytes(4, 'big')))

    def status(stream, tag):
        item = dict(app['records'][tag])
        if not state['final']:
            if tag != case or state['statuses'] >= 2:
                raise RuntimeError('status tag or count differs')
            state['statuses'] += 1
            if state['payloads'][5]['count'] != primary_length or state['stale']:
                raise RuntimeError('status DATA or stale ordinal differs')
            if state['terminated'] != (state['statuses'] == 2):
                raise RuntimeError('status terminal ordinal differs')
            if state['statuses'] == 1 and fault == 'preterminal_bytes':
                item['bytes'] = 1
            if state['statuses'] == 1 and fault == 'preterminal_pause':
                item['paused'] = not item['paused']
            if state['statuses'] == 1 and fault == 'preterminal_chunks':
                item['chunks'] = 1
        response(stream, json.dumps(item).encode())

    def control(stream, path):
        _, _, action, tag = path.split('/')
        if tag != case or action not in ('resume', 'cancel'):
            raise RuntimeError('control binding differs')
        if not state['terminated']:
            if action != 'cancel' or case == 'peer_reset':
                raise RuntimeError('public cancellation action differs')
            terminate()
            code = 2 if fault == 'reset_code' else 8
            reset = test_ready.frame(3, 0, 5, code.to_bytes(4, 'big'))
            state['resets'] += 1
            response(stream, b'ok')
            if fault == 'primary_final':
                response(5, b'')
            elif fault == 'split_reset':
                state['pending'].extend((reset[:11], reset[11:]))
            elif fault != 'missing_reset':
                state['pending'].append(reset + (reset if fault == 'duplicate_reset' else b''))
            return
        expected_action = 'resume' if state['stale'] % 2 == 0 else 'cancel'
        if state['statuses'] != 2 or action != expected_action or state['stale'] >= 4:
            raise RuntimeError('stale control ordinal differs')
        if (state['stale'] >= 2) != state['recovery_done']:
            raise RuntimeError('stale recovery barrier differs')
        if state['stale'] == 0:
            retained = (5 in context['records'], 5 in context['raw']['streams'], 5 in context['stage']['active'],
                        5 in context['credit']['streams'])
            outgoing = context['request']['streams'][5]
            if any(retained) or not outgoing['retired'] or not outgoing['reset'] or not outgoing['response_end']:
                raise RuntimeError('paired primary retirement differs')
        state['stale'] += 1
        if fault != 'stale_counter':
            app['records'][case]['stale_' + action] += 1
        response(stream, b'ok' if fault == 'stale_reply' else b'BodyControlExpired')
        if state['stale'] == 2:
            queue_refund()

    def request(path, stream):
        if path.startswith('/status/'):
            status(stream, path[8:])
            return
        if path.startswith('/control/'):
            control(stream, path)
            return
        if path == '/health':
            if state['heads'] == len(paths(case)) and (state['stale'], state['sibling_done'], state['recovery_done']) != (4, True, True):
                raise RuntimeError('final health barrier differs')
            response(stream, b'ok')
            return
        if path != '/metrics' or not state['final']:
            raise RuntimeError('unexpected auxiliary request')
        values = {key: sum(item[key] for item in app['records'].values()) for key in model.COMMON_COUNTERS + ('bytes',)}
        values.update(active=0, paused=0, buffered_middleware=app['heads'] - values['middleware'],
                      slot0_active=False, slot1_active=False)
        response(stream, json.dumps(values).encode())

    def upload_headers(entries, stream, flags, tag):
        target = '/echo' if tag == 'sibling' else '/limit/' + tag + '?case=' + tag
        fields = [('content-length', '1')] if tag == 'sibling' else [('content-length', '32'), ('x-case', tag)]
        expected = [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', target)] + fields
        if entries != expected or flags != 4:
            raise RuntimeError('upload headers or initial END differ')
        if tag == 'sibling' and stream != 3 or tag == case and stream != 5:
            raise RuntimeError('primary sibling binding differs')
        state['streams'][stream] = tag
        state['payloads'][stream] = dict(count=0, frames=0, digest=hashlib.sha256())
        if tag == 'sibling':
            return
        if tag != case:
            if (state['stale'], state['sibling_done'], state['refunded']) != (2, True, True):
                raise RuntimeError('recovery isolation barrier differs')
            return
        item = terminal(case)
        length = 0 if case == 'peer_reset' else 7
        item.update(bytes=length, sha256=model.accepted_hash(length), chunks=int(length > 0), max_span=length,
                    cancels=0, active=True, paused=case != 'cancel_ready', reason=None, stale_resume=0, stale_cancel=0)
        app['records'][case] = item

    def headers(packet, stream, flags):
        entries = list(decoder.decode(packet[9:]))
        path = dict(entries)[':path']
        index = state['heads']
        if stream != 2 * index + 1 or index >= len(order) or path != order[index]:
            raise RuntimeError('request order or stream binding differs')
        state['heads'] += 1
        app['heads'] += 1
        if path == '/echo' or path.startswith('/limit/'):
            tag = 'sibling' if path == '/echo' else path.split('/')[-1].split('?')[0]
            upload_headers(entries, stream, flags, tag)
            return
        if entries != [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)] or flags != 5:
            raise RuntimeError('auxiliary headers differ')
        request(path, stream)

    def data(packet, stream, flags):
        tag = state['streams'][stream]
        item = state['payloads'][stream]
        payload = packet[9:]
        length = 1 if tag == 'sibling' else primary_length if tag == case else 32
        expected = b's' if tag == 'sibling' else model.payload_span(32, 0, length)
        if payload != expected or len(payload) != length or flags != int(tag != case) or item['frames']:
            raise RuntimeError('DATA hash length END or ordinal differs')
        item['frames'] += 1
        item['count'] += length
        item['digest'].update(payload)
        if tag == case:
            if fault == 'early_final':
                response(stream, b'')
            return
        if tag == 'sibling':
            if (state['stale'], state['refunded'], context['request']['connection_debt']) != (2, True, 1):
                raise RuntimeError('sibling DATA before stale and actual refund barrier')
            state['sibling_done'] = True
            response(stream, b'x' if fault == 'sibling_echo' else b's')
            return
        if not state['sibling_done'] or state['stale'] != 2:
            raise RuntimeError('recovery DATA ordinal differs')
        state['recovery_done'] = True
        app['records'][tag] = terminal(tag)
        if fault == 'recovery_record':
            app['records'][tag]['metadata_end'] = 0
        if fault == 'other_record':
            app['records']['empty_headers']['middleware'] = 1
        response(stream, json.dumps(app['records'][tag]).encode())

    def packet_received(packet):
        kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
        if kind == 1:
            headers(packet, stream, flags)
            return
        if kind == 0:
            data(packet, stream, flags)
            return
        if kind == 3:
            if case != 'peer_reset' or stream != 5 or flags or packet != test_ready.frame(3, 0, 5, (8).to_bytes(4, 'big')):
                raise RuntimeError('canonical outgoing CANCEL8 differs')
            state['resets'] += 1
            terminate()
            if fault == 'primary_final':
                response(5, b'')
            return
        if kind != 4 or flags != 1 or len(packet) != 9 or stream:
            raise RuntimeError('unexpected frame or settings ACK')
        state['settings'] += 1

    def send(data_bytes):
        if type(data_bytes) is not bytes or len(data_bytes) > 8192:
            raise RuntimeError('send bound differs')
        if state['startup']:
            state['startup'] = False
            if data_bytes[:24] != b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' or len(data_bytes) != 75:
                raise RuntimeError('startup differs')
            return
        state['buffer'].extend(data_bytes)
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            packet_received(packet)

    def receive():
        state['reads'] += 1
        if not state['pending'] or state['reads'] > 200:
            raise RuntimeError('missing finite synthetic response')
        packet = state['pending'].pop(0)
        if packet[3:4] == b'\x08':
            if state['stale'] != 2 or state['refunded']:
                raise RuntimeError('refund read ordinal differs')
            state['refunded'] = True
        return packet, clock()

    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, selected_before=prior, clock=clock)
    if context['stage']['primary'] != 5:
        raise RuntimeError('primary binding differs')
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), clock())
    adapter.run_case(context, receive)
    budget = (12, 11, 40) if case == 'cancel_ready' else (12, 11, 65) if case == 'cancel_paused' else (11, 10, 65)
    actual = (state['heads'], context['stage']['case_state']['small'], context['request']['case']['sent'])
    if actual != budget or state['heads'] != len(order) or state['settings'] != 1 or state['resets'] != 1 or state['pending'] or state['buffer']:
        raise RuntimeError('exact J C R settings reset or pending count differs')
    for stream, item in state['payloads'].items():
        tag = state['streams'][stream]
        length = 1 if tag == 'sibling' else primary_length if tag == case else 32
        payload = b's' if tag == 'sibling' else model.payload_span(32, 0, length)
        if item['frames'] != 1 or item['count'] != length or item['digest'].hexdigest() != hashlib.sha256(payload).hexdigest():
            raise RuntimeError('final upload count or hash differs')
    selection = prior + (case,)
    model.validate_records(selection, 'before', app['records'])
    if final:
        state['final'] = True
        order.extend('/status/' + tag for tag in model.SPECS)
        order.append('/metrics')
        adapter.final_collection(context, receive)
        if state['heads'] != len(order) or state['pending'] or state['buffer']:
            raise RuntimeError('shared final collection differs')
    print(case + ' passed: J=%d C=%d R=%d' % actual)
    return app


def rejected(case, fault, message, *, final=False):
    try:
        check(case, fault=fault, final=final)
    except (ValueError, RuntimeError) as exc:
        if str(exc) != message:
            raise RuntimeError('control rejected for wrong reason: ' + fault) from exc
        print(fault + ' rejected: ' + str(exc))
        return
    raise RuntimeError('control accepted: ' + fault)


def main():
    app = None
    prior = ()
    for case in ('cancel_ready', 'cancel_paused', 'peer_reset'):
        app = check(case, app=app, prior=prior, final=case == 'peer_reset')
        prior += (case,)
    check('cancel_ready', fault='split_reset')
    for case in ('cancel_ready', 'cancel_paused', 'peer_reset'):
        for fault, message in (('preterminal_bytes', 'record mismatch: bytes'), ('preterminal_pause', 'record mismatch: paused'),
                               ('terminal_reason', 'record mismatch: reason'), ('terminal_metadata', 'record mismatch: metadata_begin'),
                               ('stale_reply', 'control result differs'), ('missing_refund', 'missing finite synthetic response'),
                               ('excess_refund', 'invalid connection refund'), ('sibling_echo', 'sibling echo differs'),
                               ('recovery_record', 'record mismatch: metadata_end'), ('stale_counter', 'record mismatch: stale_resume'),
                               ('early_final', 'invalid terminal'), ('primary_final', 'invalid terminal')):
            rejected(case, fault, message)
        rejected(case, 'other_record', 'record mismatch: middleware', final=True)
    rejected('peer_reset', 'preterminal_chunks', 'record mismatch: chunks')
    for fault, message in (('reset_code', 'wrong reset code'), ('duplicate_reset', 'duplicate reset'),
                           ('missing_reset', 'missing finite synthetic response')):
        rejected('cancel_ready', fault, message)


if __name__ == '__main__':
    main()
