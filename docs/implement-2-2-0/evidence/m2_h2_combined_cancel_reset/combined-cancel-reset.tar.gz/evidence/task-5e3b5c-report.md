# Task 5e3b5c report

DONE for the three released source schedules: `cancel_ready`, `cancel_paused`, and `peer_reset`. Supported selection is now 28 of the unchanged 40 cases; 12 remain rejected before actions. This is pure in-memory public-codec/control/reset evidence with model-derived synthetic peer records. It is not native fixture evidence or parent acceptance.

The starting 23 modules matched the released B5b manifest exactly, based on reviewed/pushed commit `bde25f6322318d9affff950c2a19ba14e4caa270`. The baseline hashes and copies are retained in `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b5c/baseline.json` and `baseline/`. All paths below beginning with `evidence/` are relative to `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`.

The task brief, release addendum, scoped parent B5 brief, AGENTS, coding conventions, contribution/check/pipeline/codebase/benchmark guidance, and required skills were read. The prescribed graphify prefix ran before the first source read/search; `evidence/b5c/graphify.{stdout,stderr,exit}` retains the result (exit 0, empty stderr, 650-token graph truncation explicitly shown). Exact command:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "combined-cases adapter wire lifecycle-control cancellation peer reset test_metadata" --budget 650
```

`graphify update .` was subsequently run using the same environment/binary prefix. It exited 0 with empty stderr; raw output in `graphify-update.*` says the code scan found no relevant changes, left the graph untouched, and skipped 369 unclassified files. The task's ignored evidence modules were therefore not added to the graph. No semantic model/API request ran.

The implementation is two new modules plus eight changed modules, with 15 of the released 23 modules byte-identical and no removals:

- `control_reset_cases.py`: all three actual schedules, model request construction, finite preterminal/terminal status observations, canonical public cancel or peer reset, paired retirement, stale controls, earned refund, sibling echo, recovery and final health.
- `test_control_reset.py`: serialized peer recorder with independent request/order/header/DATA/reset checks, shared synthetic application records across fresh connection contexts, the inherited final collection and 43 postimplementation negative controls. A fourth positive execution splits an incoming public cancellation reset across two bounded reads.
- `adapter.py`: a used keyword-only `role='small'` extension to `start`, passed through the existing canonical `wire.start_request` preflight; used policy-aware terminal readiness in `finish`; dispatch for the three schedules. Healthy/default behavior and existing healthy/refusal tests remain covered.
- `test_adapter.py`: invalid auxiliary reset-role rejection verifies preflight leaves stage counts/high-water, parser, records, request/response registrations and next codec stream identifier unchanged.
- `cases.py`: accurate 28-case description and explicit implemented names.
- `test_imports.py`: adds the two modules to the exact AST/import inventory.
- `test_pause.py`, `test_admission.py`, `test_continue_quota.py`, `test_metadata_concurrency.py`: exact unsupported inventory maintenance 15 -> 12; existing assertions and rejection loops are retained.

All directly owned module hashes, complete source copies, added/changed/unchanged lists and control-flow depths are in `evidence/b5c/snapshot.json` and `final-source/`. The combined diff is `source.diff`. Key SHA256 identities:

| File | SHA256 |
| --- | --- |
| adapter.py | d04f9d3db6341b80ecb71748b84fb45eda9c87f998a5be2e9085c372ebee9b37 |
| control_reset_cases.py | 36b8fe72e24eaf8cb7a30b470ea4c23823f324373ac3d4d90a6cc8a1595979d7 |
| test_control_reset.py | 7b81f969a0cd5146ac5ac075bd2cc2d25aca890c021db4ab73f828eb04780d67 |
| cases.py | e184eef62c7296d58454a8f92a0c5c682caa4ae982a330f7282013b17e773055 |

The schedule uses existing authoritative interfaces throughout: `adapter.start/get/send_data/observe/finish/retire/health`, `pause_cases.status/control/pending`, model request/checkpoint/record validators, and immutable `wire.start_request`, `wire.send_peer_reset`, `wire.complete`, `wire.retire`, `wire.enter_final`, `wire.finish_final`. There is one bound codec, parser, output stage and pair of independent request/response ledgers per connection. No alternate parser, expected-state model, direct ledger/reset/stage mutation or refund replay was added.

The source authority is authenticated lifecycle-control `cases.py`/`profile.zig` plus current model/catalogue/fixture. Only located legacy `run_live.py` lines 397..451 were read as a source reference for sibling/refund/reset ordering; it was never executed. Current combined schema supersedes its aliases. The role extension uses the existing `wire.register` reset-role contract and existing preflight, rather than changing immutable core APIs.

Each schedule first completes health on stream 1, opens the declared-one-byte POST `/echo` sibling on stream 3, then opens primary stream 5 with exact POST `/limit/<tag>?case=<tag>`, `content-length: 32`, and `x-case: <tag>`. It sends 7 canonical bytes without END for `cancel_ready`, 32 without END for the others. The preterminal status and pending barrier requires begins 1, ends/cancels 0, correct ready/paused state, accepted bytes 7 except peer reset 0, and peer chunks/max-span 0. Metadata and all diagnostics are checked through the current model schema.

Public cancellation sends the exact `/control/cancel/<tag>` request, expects `ok`, and requires incoming CANCEL8 without any primary final HEADERS/END. Peer reset calls `wire.send_peer_reset`, flushes its single canonical outgoing CANCEL8, and requires no server primary final. The terminal status requires exact reason, accepted bytes, callbacks and metadata with stale counters still zero. `finish` waits for the precise reset policy terminal and a complete raw frame parser, then calls canonical `wire.complete` and `wire.retire`. It never fabricates `ended`. Reset result headers remain `None`, ended remains false and its reset code is 8 only after canonical policy validation.

The first stale resume/cancel pair must each return `BodyControlExpired`. The schedule then waits until actual observed connection refund has reclaimed the 7/32 primary bytes and both public codec and ledger windows are 65535; it opens no extra observation stream and sends no late primary DATA. Only then it sends sibling `b's'` with END, validates echo `b's'`, opens recovery with the current model contract, sends 32 canonical bytes with END and validates its record. The second stale pair precedes final health. Stale counters and all six new persistent records are validated by the inherited final collection together with all untouched records.

Retirement checks distinguish response/parser/stage removal from legitimately retained request debt: the recorder checks the primary is absent from records/raw/output-stage/response-credit maps and its retained request-credit entry is reset, response-ended and retired. Remaining earned stream debt is carried by the existing canonical ledger/final-budget rules; no stream refund is invented or forcibly zeroed. The two credit scopes remain distinct.

The independently checked exact counts are:

| Case | J heads | C small responses | R request flow |
| --- | ---: | ---: | ---: |
| cancel_ready | 12 | 11 | 40 |
| cancel_paused | 12 | 11 | 65 |
| peer_reset | 11 | 10 | 65 |

The recorder checks request ordinal and odd stream binding, exact POST/GET method, scheme/authority/path/query/header multiplicity/declaration, open initial request, primary/sibling/recovery DATA length/hash/END/ordinal, and exact outgoing reset serialization. Sibling DATA requires the first stale pair, an actual refund observation and request connection debt exactly one after that DATA. Recovery requires completed sibling echo and the same stale/refund barrier. It checks exactly one startup, one SETTINGS ACK, one directional reset and empty pending/capture buffers, while existing core checks enforce incoming SETTINGS shape and budget limits. Bounded counters/digests replace per-DATA/read histories. Synthetic app state is shared; each positive case has a fresh bound connection with the preceding selection, then the last context runs all 67 status records plus metrics through the inherited final collection.

Actual initial serialized test source was saved as `evidence/b5c/initial-test.py` before implementation and immediately executed. The preserved RED/intermediate history is:

1. `red.*`: exit 1, empty stdout, `ValueError: case schedule not implemented`. This is selection-only rejection, not behavioral RED.
2. `intermediate-1.*`: exit 1, empty stdout, `RuntimeError: missing finite synthetic response`. With the real serialized schedule and used role seam in place, cancellation CANCEL8 had already been parsed, and the old healthy-END-only `adapter.finish` loop requested another synthetic read instead of completing. This is the precise behavioral RED for reset terminal completion. It is finite in-memory input exhaustion, not a native hang. The pre-fix adapter/schedule/test/selection source is retained in `intermediate-1-source/`.
3. `intermediate-2.*`: all three positive cases plus split reset passed. An early-primary-final negative control was rejected by existing pending validation as `upload completed before resume`, rather than the test's predicted `invalid terminal`. The test diagnostic was corrected; the rejection was retained. Source is in `intermediate-2-source/`.
4. `intermediate-3.*`: the public-primary-success control reached finite input exhaustion because the new terminal predicate was waiting for the missing reset. Added fail-fast `unexpected final` validation for reset-policy final headers/END, preserving canonical completion. Source is in `intermediate-3-source/`.
5. `intermediate-4.*`: the peer-reset primary-success control failed at the existing output stage's `invalid terminal`, before the test's predicted raw-parser diagnostic. Corrected only the exact expected diagnostic. Source is in `intermediate-4-source/`.
6. `intermediate-5.*`: duplicate public reset failed at the existing output stage's `invalid reset` bound, before the test's predicted `duplicate reset`. Corrected only the exact expected diagnostic. Source is in `intermediate-5-source/`.
7. `intermediate-6.*`: the full serialized control/reset test passed with empty stderr. Subsequent test-only changes moved untouched/stale-counter negative verification through actual inherited final collection, before inspecting the supplied synthetic app state.
8. `intermediate-7-matrix/`: first normal/-O matrix had 30 successful commands and two `test_adapter` failures. Its newly added role test incorrectly designated next stream 3 as primary 5, so canonical preflight correctly rejected `invalid primary` earlier than the intended role test. The exact test source is retained in `intermediate-7-source/test_adapter.py`. Corrected it to test an invalid auxiliary reset role at actual next stream 3 and require `invalid auxiliary role`; no valid action or threshold was removed. All final 32 commands then passed.
9. `snapshot-attempt-1.*` and `snapshot-attempt-2.*`: metadata-audit failures only. The first audit counted Python `elif` as additional source nesting; the corrected AST traversal treats the same-level branch correctly. The second audit assumed the 42 pinned codec files were all `*.py`; the final audit uses the authoritative ordered rows including licenses/metadata/type markers, rehashes every file, rejects extras/missing files and reproduces the pinned aggregate with default `json.dumps(rows)`. No source or test gate was changed for either audit correction.

All raw stdout, stderr and exit values remain separate. Red and intermediate serialized invocations used the same exact pinned normal command as the final serialized test below. Final command receipts additionally retain each exact command in `.command` files and collectively in `evidence/b5c/final-commands.json`.

Final commands ran after the last module edit with the pinned interpreter and `-B -S` in normal and `-O` modes. No Zig optimization mode applies. The exact environment and command template are:

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_control_reset.py
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_control_reset.py
```

The same two commands, replacing only the last filename, ran each of these 16 test modules: `test_adapter`, `test_admission`, `test_async`, `test_continue_quota`, `test_control_reset`, `test_credit`, `test_final`, `test_imports`, `test_large`, `test_metadata_concurrency`, `test_negative`, `test_pause`, `test_ready`, `test_selection`, `test_shared`, `test_time`. This covers every prior directly owned test because the shared adapter terminal/start seam changed, including the earlier ready/async/large/admission/continue/credit/pause/metadata/concurrency/final/time/shared regressions. All 32 exits are 0, every stderr is empty.

Both final control/reset outputs begin:

```text
cancel_ready passed: J=12 C=11 R=40
cancel_paused passed: J=12 C=11 R=65
peer_reset passed: J=11 C=10 R=65
cancel_ready passed: J=12 C=11 R=40
```

They then retain 43 named negative-control rejections, with exact diagnostics. These are postimplementation synthetic sensitivity controls, not additional pre-fix behavioral RED or an independent server. They cover wrong preterminal bytes/pause, terminal reason/metadata, stale reply/counter, missing/excess refund, wrong sibling echo/recovery metadata, premature final, reset-policy successful primary response, untouched-record contamination, paused-peer chunk evidence, wrong reset code, duplicate reset and missing reset. Wrong/missing refund and missing reset fail through the actual immutable codec/credit or finite receive boundary; other controls target schedule/model/pending/stage invariants. The complete 47-line stdout is retained per mode.

The final import commands print exactly `AST and inert import checks passed`. All 25 root modules have a main guard, no authored class/custom exception/assert proof statement, and actual silent/inert imports under empty and foreign argv while caller-owned doubles reject file/socket/SSLContext/process/clock/console effects. No auxiliary executable recorder module was authored outside these modules; evidence source copies are snapshots. The final AST audit reports maximum source control nesting at most 3 (new schedule 1, new test 2). Caller-owned closures/state, fixed request spans and bounded raw callbacks retain the inherited integer time/deadline and data bounds.

The final source/identity audit used `/home/codespace/.python/current/bin/python3 -B -S -` with guarded inline metadata code. `evidence/b5c/final-audit.*` retains exit 0, empty stderr and the exact raw stdout:

```text
25 final modules: 2 added, 8 changed, 15 unchanged, 0 removed
119 immutable identity entries checked; 42 codec identities match retained ordered rows and pinned aggregate digest
32 final commands exit 0 with empty stderr; normal and -O; AST maximum control depth <=3
```

`evidence/b5c/immutable-inputs.json` retains each path/size/hash and the codec ordered rows. The 119 entries cover 41 family identities, 26 v9 core files, 19 runtime source files, 6 model-publication files, 25 fixture files, the helper pin and codec aggregate; the helper/Python also occur in retained family identities. All comparisons matched. Core remains `/tmp/uwz-task5e3a-snapshot-v9/source`, model/catalogue `/tmp/uwz-task5e1-contract-v3`, and fixture source `/tmp/uwz-task5e2-Fix1Final2/fixture`. Helper SHA256 is `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`, codec aggregate is `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`, and pinned Python binary is `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.

Self-review found no remaining actionable defect within this slice. The minimal used role and terminal seams preserve canonical preflight/completion/retirement and existing defaults. No test/rejection loop/assertion was weakened, no unsupported placeholder succeeds, and no immutable API gap was found. Final source hashes were checked against the exact 25-file saved snapshot and the released B5b map. Root still independently reviews and owns public delivery and Git.

No native build/server/socket/SSLContext/TLS-close, real clock, process ownership/transfer/fault/scheduling/descriptor/kernel/race/panic/leak experiment, old live entrypoint, external model CLI, dependency/capacity/budget/deadline change, product/core/model/fixture edit, agent spawn or Git action was performed. Repository Zig/native/full-platform/compliance checks were not executed under this source-only release; the report does not claim them. The pure Python fixtures and peer records are synthetic.

Parent note: B5/all40/default/aggregate/runtime/native/adoption/full milestones remain incomplete. This slice earns three source schedules and six persistent body records only; 28 of 40 source schedules are implemented, with three application-error B5 schedules and nine B6 schedules remaining. No parent milestone or native acceptance follows from this report.
