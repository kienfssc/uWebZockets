# Task5e3b5c: public cancellation and peer reset

Released after B5b source/publication review and immediate push of commit
bde25f6322318d9affff950c2a19ba14e4caa270. Base23-module map is
docs/implement-2-2-0/evidence/m2_h2_combined_metadata_concurrency/manifest.json
and task-5e3b5b-root-final-audit.json; committed delivery verified in
task-5e3b5b-root-commit-audit.json. Acceptedsource25/40, not native acceptance.
Continue the unchanged all40 source plan under task-5e3b-release-addendum.md
and task-5e3b5-brief.md. Read the release addendum for pinned Python, graphify,
immutable inputs and native-execution prohibitions. No parent acceptance from
this three-case unit. Root supplies the accepted B5b source map on release.

Own concrete lifecycle-control schedule/test modules, minimal actually-used
adapter/cases/import-check seams, evidence/b5c and task-5e3b5c-report.md. Preserve
all prior modules/evidence. Root authorizes necessary exact unsupported-count
assertion15->12 maintenance with all assertions/rejection loops preserved,
and an accurate cases.py description for28 implemented cases. No successful
unsupported placeholders. You are not alone; preserve others' edits. Root owns
public delivery/Git. No agents or external model CLI.

## Source contract

Final authority is .uwz-work/evidence/h2-streaming/integration-owned/
lifecycle-control/cases.py and profile.zig, authenticated in
task-5e3b-input-audit.json, plus current model/catalogue/fixture. Old run_live.py
is a source reference only, never invoke it. Its located lines397..451 show
the actual sibling and reset actions; legacy field aliases are superseded by
the current model. Do not introduce a second expected-state model.

| Case | Heads J | Small C | Request flow R |
| --- | ---: | ---: | ---: |
| cancel_ready | 12 | 11 | 40 |
| cancel_paused | 12 | 11 | 65 |
| peer_reset | 11 | 10 | 65 |

Each case first opens a POST /echo sibling declared1 with request open, then
its primary POST /limit/<tag>?case=<tag>, declared32 and x-case=<tag>. It sends
7 primary bytes for cancel_ready,32 for the others, no END. The finite
preterminal status/pending barrier observes begins1,ends0,cancels0, bytes7
except peer_reset bytes0; cancel_ready ready and others paused. Peer-reset
paused status must have chunks0. Public cancel uses the exact control route;
peer reset sends exactly one canonical outgoing CANCEL8 through
wire.send_peer_reset. No direct ledger/raw/stage state surgery.

The accepted combined architecture lines55..56 requires start/end health for
nonterminal cases, in addition to the retained internal actions above. Thus
health is stream1, sibling3, primary5; final health follows the last stale
control pair. Existing adapter.open_case default primary5 already fits. Do not
infer primary3 from the metadata unit or omit either health to match legacy
runner behavior; exact combined J/C/R above includes both.

Validate terminal status and wire policy: public cancellation CANCEL8, no
successful primary HEADERS; peer-reset outgoing CANCEL8, no server final.
Model validates exact reason/diagnostic/metadata fields. Validate paired request
and response retirement with existing canonical wire.complete/wire.retire,
adding a concrete used terminal-finish adapter only if necessary. Primary
reset policies are not compatible with adapter.finish's healthy-ended loop;
the new seam must wait for its exact policy terminal and complete parser state,
not fabricate ended flags or bypass the wire invariant.

The located wire.register lines92..96 binds these policies to stage role reset;
adapter.start currently fixes role small. A minimal actually-used explicit role
argument or concrete reset-start seam may extend the adapter while preserving
the existing default and canonical wire.start_request preflight. This is an
adapter extension using an existing core contract, not an immutable API defect.

After terminal, resume and cancel each must return BodyControlExpired. Wait
for the actual earned primary connection refund (7 or32) without replay or
extra request heads. Only then send the sibling one byte b's' with END and
verify echo b's'. This is the source of the extra request-flow byte; no late
DATA to a closed primary is required. Start recovery,32 canonical bytes+END,
finish and validate its record. Repeat stale resume/cancel and validate all
six persistent records, all untouched records and inherited shared final
collection. Do not move the sibling DATA across the source barriers.

Every request/action/grant/reset/observation/retirement must pair once through
the same wire/parser/two ledgers/output stage; preserve fresh caller integer
time, inherited deadlines, finite barriers, bounds, hashes, exact J/C/R and
SETTINGS counts. Stale records/token lifetime are validated by the actual
fixture's tag controls; body token generation is private.

## Proof and handoff

Begin actual serialized schedule tests before implementation; preserve initial
test source and real RED/intermediate failures with exact scope. Selection/API
rejection is not behavioral RED. Independently check outgoing headers/order,
primary/sibling DATA lengths/hash/END, canonical reset code/order, absence of
primary successful response, finite preterminal/terminal/stale/refund barriers,
recovery isolation and six new final records using fresh contexts sharing one
synthetic app and selected-before state. Supplied model-derived peer records
are synthetic, never native fixture proof. Target negative controls at named
invariants and qualify postimplementation sensitivity failures accurately.

After final edits run relevant normal and -O checks with exact pinned Python
-B -S and separate raw stdout/stderr/exits, preserve changed-seam regressions
and capture every module/hash in a final snapshot compared to released B5b.
Every authored helper has main guard and actual silent/inert imports for empty
and foreign argv with rejecting effects. No authored classes/assert proof,
custom exceptions/hidden mutable globals/dead code/deep control flow. Use the
required graphify prefix before the first source read/search and retain proof.

No model/core/fixture/product/dependency or capacity/budget/deadline changes,
native builds/server/socket/SSLContext/TLS-close/real-clock/process ownership/
transfer/descriptor/kernel/fault/cancel/schedule/race/panic/leak experiments,
old live entrypoint execution, Git, public delivery or other agents. Pure
in-memory codec/reset/control checks only. Report a smallest concrete immutable
API defect if found and continue independent work; no invented gap or omission.

Write full report with source/API/file identities, commands/raw outcomes,
history, snapshot, self-review and actual remaining facts. Append parent note:
B5/all40/default/aggregate/runtime/native/adoption/full milestones incomplete.
Return concise DONE/report/tests/real concerns. Root reviews independently.
