# Owned TLS/HTTP2 refusal follow-up

This supplements isolated H2 refusal checkpoint af0afe5e2e220a75701a6d6e0ef6165970c9582c2862dd1958e46e09ea804c17. Its production source bytes are unchanged. Restore that draft over the earlier prepared App/R2 tree, then add source/src/h2_refusal_live.zig. Commands retain exact historical paths and generated C bindings. Derived executable and sparse upload fixture are excluded; the sparse fixture was deleted after the run.

A normal owned loopback TLS server runs on io_uring using the unchanged authoritative fetched libxev dependency. curl 8.5.0/nghttp2 negotiates HTTP/2, offers a valid 100,000,000-byte sparse source with Expect: 100-continue, receives empty 503 before sending any upload bytes, then completes /health on the same TLS connection. Server counters establish no sink effects or quota changes and only the healthy route's middleware effect. SIGTERM requests normal graceful shutdown; the owned process exits zero and is reaped. This is no native cancellation/fault/leak/crash probe and the prior stopped experiment remains stopped.

The first harness compilation failed because App.use's returned pointer was ignored. The final fixture uses explicit discard; production source is unchanged. Before/after full draft source hashes and unchanged-run assertions bind the successful result. observed-inputs-after-run.json is an after-run observation only.

This is header refusal evidence, not a successful 100 MB upload, memory benchmark, performance result or complete M2 gate. Independent review, actual H1/H2/H3 drivers and full combined verification remain required. No source pin, dependency publication or production integration is performed.
