from pathlib import Path
import tarfile,hashlib,io,json,gzip,re,os
root=Path('/workspaces/uWebZockets');e=Path(__file__).resolve().parent;out=root/'docs/implement-2-2-0/evidence/m2_h2_refusal_live';out.mkdir(parents=True,exist_ok=True);d=root/'.uwz-work/drafts/m2-h2-body-refusal';run=json.loads((e/'run.json').read_text());assert run['passed'] and run['owned_server_reaped'] and run['server_exit_status']==0
files={'source/src/h2_refusal_live.zig':(d/'src/h2_refusal_live.zig').read_bytes()}
for p in e.iterdir():
 if p.is_file():files['evidence/'+p.name]=p.read_bytes()
files['SCOPE.md']=b'''# Owned TLS/HTTP2 refusal follow-up

This supplements isolated H2 refusal checkpoint af0afe5e2e220a75701a6d6e0ef6165970c9582c2862dd1958e46e09ea804c17. Its production source bytes are unchanged. Restore that draft over the earlier prepared App/R2 tree, then add source/src/h2_refusal_live.zig. Commands retain exact historical paths and generated C bindings. Derived executable and sparse upload fixture are excluded; the sparse fixture was deleted after the run.

A normal owned loopback TLS server runs on io_uring using the unchanged authoritative fetched libxev dependency. curl 8.5.0/nghttp2 negotiates HTTP/2, offers a valid 100,000,000-byte sparse source with Expect: 100-continue, receives empty 503 before sending any upload bytes, then completes /health on the same TLS connection. Server counters establish no sink effects or quota changes and only the healthy route's middleware effect. SIGTERM requests normal graceful shutdown; the owned process exits zero and is reaped. This is no native cancellation/fault/leak/crash probe and the prior stopped experiment remains stopped.

The first harness compilation failed because App.use's returned pointer was ignored. The final fixture uses explicit discard; production source is unchanged. Before/after full draft source hashes and unchanged-run assertions bind the successful result. observed-inputs-after-run.json is an after-run observation only.

This is header refusal evidence, not a successful 100 MB upload, memory benchmark, performance result or complete M2 gate. Independent review, actual H1/H2/H3 drivers and full combined verification remain required. No source pin, dependency publication or production integration is performed.
'''
patterns=[re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}'),re.compile(rb'github_pat_[A-Za-z0-9_]{20,}')];secrets=[v.encode() for k,v in os.environ.items() if re.search('TOKEN|SECRET|PASSWORD|API_KEY',k) and len(v)>=16]
for n,b in files.items():
 if any(p.search(b) for p in patterns) or any(s in b for s in secrets):raise SystemExit('credential scan match in '+n)
inv={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in sorted(files.items())};files['INVENTORY.json']=(json.dumps(inv,indent=2)+'\n').encode();a=out/'h2-refusal-live.tar.gz'
with a.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for n,b in sorted(files.items()):
    ti=tarfile.TarInfo('m2-h2-refusal-live/'+n);ti.size=len(b);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(b))
with tarfile.open(a) as t:
 for ti in t.getmembers():
  assert ti.isfile() and not ti.name.startswith('/') and '..' not in Path(ti.name).parts
  assert t.extractfile(ti).read()==files[ti.name.removeprefix('m2-h2-refusal-live/')]
s={'date':'2026-10-27','scope':'Owned normal TLS/H2 header refusal and same-connection healthy request; isolated unreviewed source','archive':a.name,'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'archive_bytes':a.stat().st_size,'safe_regular_members':len(files),'inventory_entries':len(inv),'base_refusal_archive_sha256':'af0afe5e2e220a75701a6d6e0ef6165970c9582c2862dd1958e46e09ea804c17','client_exit_status':0,'server_exit_status':0,'owned_process_reaped':True,'upload_bytes_sent':0,'refusal_status':503,'healthy_status':200,'connection_reused':True,'credential_scan':'No retained bytes match environment credentials or GitHub token patterns','files':inv};(out/'manifest.json').write_text(json.dumps(s,indent=2)+'\n');print({k:v for k,v in s.items() if k!='files'})
