from pathlib import Path
import subprocess,socket,signal,json,time,os,hashlib,sys
out=Path(__file__).resolve().parent
compiled=json.loads((out/'compile.json').read_text());assert compiled['exit_status']==0 and compiled['all_source_before']==compiled['all_source_after']
draft=Path(compiled['cwd']);before=compiled['all_source_after'];assert all(hashlib.sha256((draft/n).read_bytes()).hexdigest()==h for n,h in before.items())
binary=Path('/tmp/uwz-h2-refusal-live');upload=Path('/tmp/uwz-h2-refusal-live-upload.bin')
with upload.open('wb') as f:f.truncate(100_000_000)
with socket.socket() as reserved:
 reserved.bind(('127.0.0.1',0));port=reserved.getsockname()[1]
env=os.environ.copy();env['UWZ_H2_REFUSAL_PORT']=str(port)
args=[str(binary)];base=['--http2','--insecure','--noproxy','*','--no-progress-meter','--verbose','--max-time','5','--write-out','%{json}\n'];url='https://127.0.0.1:'+str(port)
curl=['/usr/bin/curl','--disable']+base+['--expect100-timeout','20','--header','Expect: 100-continue','--upload-file',str(upload),'--request','POST','--output',str(out/'refusal.body'),'--dump-header',str(out/'refusal.headers'),url+'/upload','--next']+base+['--output',str(out/'health.body'),'--dump-header',str(out/'health.headers'),url+'/health']
record={'server_argv':args,'server_cwd':str(draft),'server_binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'server_source_bindings':before,'port':port,'upload_file_bytes':upload.stat().st_size,'upload_file_allocated_bytes':upload.stat().st_blocks*512,'client_argv':curl,'client_version':subprocess.check_output(['/usr/bin/curl','--version'],text=True)}
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic();server=None;failure=None
try:
 with (out/'server.log').open('wb') as log:
  server=subprocess.Popen(args,cwd=draft,env=env,stdout=log,stderr=subprocess.STDOUT)
  record['owned_server_pid']=server.pid
  for _ in range(100):
   if server.poll() is not None:raise RuntimeError('server exited before readiness: '+str(server.returncode))
   if b'h2 refusal live ready' in (out/'server.log').read_bytes():break
   time.sleep(.05)
  else:raise RuntimeError('server readiness timeout')
  with (out/'client.jsonl').open('wb') as response,(out/'client.log').open('wb') as diagnostic:
   client=subprocess.run(curl,stdout=response,stderr=diagnostic,timeout=15)
  record['client_exit_status']=client.returncode
  if client.returncode:raise RuntimeError('client failed '+str(client.returncode))
  results=[json.loads(line) for line in (out/'client.jsonl').read_text().splitlines()];record['responses']=results
  assert len(results)==2 and results[0]['response_code']==503 and results[1]['response_code']==200
  assert all(str(x['http_version'])=='2' for x in results)
  assert results[0]['size_upload']==0 and results[0]['size_download']==0
  assert results[0]['num_connects']==1 and results[1]['num_connects']==0
  assert (out/'refusal.body').read_bytes()==b'' and (out/'health.body').read_bytes()==b'ok'
  assert b'HTTP/2 100' not in (out/'refusal.headers').read_bytes()
  record['assertions']='HTTP/2 503 from headers with zero upload/download/100 Continue; same TLS connection reused for healthy HTTP/2 200'
except BaseException as e:
 failure=type(e).__name__+': '+str(e);record['failure']=failure
finally:
 if server is not None:
  if server.poll() is None:server.send_signal(signal.SIGTERM)
  try:record['server_exit_status']=server.wait(timeout=5)
  except subprocess.TimeoutExpired:
   server.kill();record['server_exit_status']=server.wait(timeout=5);record['forced_cleanup']=True
  record['owned_server_reaped']=server.poll() is not None
 record['elapsed_seconds']=time.monotonic()-start
 record['source_unchanged']=all(hashlib.sha256((draft/n).read_bytes()).hexdigest()==h for n,h in before.items())
 record['shutdown_assertion']=b'h2 refusal live drained sink=0 middleware=1 health=1 quota=0' in (out/'server.log').read_bytes()
 record['passed']=failure is None and record.get('server_exit_status')==0 and record['source_unchanged'] and record['shutdown_assertion']
 (out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
 upload.unlink(missing_ok=True)
print({k:v for k,v in record.items() if k not in ['server_source_bindings','responses','client_version','client_argv']},flush=True)
print((out/'server.log').read_text()[-4000:],flush=True)
if not record['passed']:
 print((out/'client.log').read_text()[-5000:] if (out/'client.log').exists() else 'client not started',flush=True)
 sys.exit(1)
