# Task5e3b6b: streamed-file and early-final source schedules

Implemented the two released concrete schedules over the unchanged reviewed
public-codec seam. The source inventory is now36/40 cases and31 modules.
This is source-only, supplied-input verification. It is not native execution,
file ownership/callback evidence, post-deinit evidence, combined40 acceptance,
or completion of a2.2.0 milestone. Root owns independent review, public delivery
and Git. No immutable API gap was encountered.

## Scope, inputs and identities

The governing brief is `task-5e3b6b-brief.md`, with
`task-5e3b-release-addendum.md` and `task-5e3b-cases-pending-brief.md`.
Released B6a base: `07434c7a7cd57b5349ce11f7a8a3b27b839673d4`.
The captured29 pre-edit modules match exactly the released
`docs/implement-2-2-0/evidence/m2_h2_combined_producer_pressure/manifest.json`
`current_source_files` map. Their captured bytes are in `evidence/b6b/before-source/`.

All current owned code and evidence below are relative to
`.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`.
`evidence/b6b/snapshot.json` contains all31 final SHA256 identities, the exact
added/changed/unchanged/removed lists, base commit and AST depth per module.
`final-source/`, `before-map.json` and `source.diff` retain exact reviewable
bytes and their comparison to B6a. There are2 added,7 changed,22 unchanged and0
removed modules. Existing schedules were not rewritten.

`evidence/b6b/immutable-inputs.json` retains the previous authenticated list,
and the final audit rechecks every row against actual bytes. It contains119
retained identity entries:118 file rows/113 unique resolved file paths, plus
the codec aggregate. Including that aggregate gives114 unique entries.
These are retained rows, not119 distinct files. The42 codec rows are retained
in order, checked for exact set equality without missing/extra files and
hashed using the same default `json.dumps(rows).encode()` aggregate:
`0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`.
The helper identity remains
`07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`.
No identity mismatch was accommodated.

Actual immutable imports are the model/catalogue under
`/tmp/uwz-task5e1-contract-v3`, the26-file core under
`/tmp/uwz-task5e3a-snapshot-v9/source`, the pinned42 codec files under
`/tmp/uwz-h2-client-tooling/packages`, and the pinned integration-client helper.
Source-only authority was read from authenticated runtime-v5 `cases.py`,
`case_adapter.py`, `diagnostics.py`, `records.py`, `post.py`; original
`/tmp/uwz-task5d1-round3-current/contracts.py`; and retained
`/tmp/uwz-task5d2-fix2-final-snapshot/profile.zig`, `output.zig`,
`file_observer.zig`. No old live/runtime/constructor/file-transfer/close entrypoint
was invoked. No product/core/model/catalogue/fixture/dependency/public/Git file
was edited. No native build, actual file open/read/ownership/transfer,
socket/TLS/SSLContext, real-clock, process-ownership/descriptor/kernel,
fault/cancel/scheduling/race/panic/leak experiment was performed.

Before the first source search/read the exact prescribed query ran:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "combined-cases producer_pressure_cases adapter selection streamed_file early_final tests" --budget 650
```

Exit0; the graph reported16682 nodes,257 matches and a650-token truncated
scoped subgraph. The brief already located the relevant source paths.
After code edits the same prefix ran `graphify update .`; raw command,
stdout/stderr/exit are retained as `evidence/b6b/graphify-update.*`. It exited0,
reported no relevant changes, and left the ignored graph untouched. The owned
ignored harness paths are outside its detected changes.

## Changes and actual used APIs

- Added `file_early_cases.py`: concrete file and early-final schedules,
  exact special request metadata/policy/hash-only binding, parser-complete
  held/prefix checkpoints, exact file content-length multiplicity, model
  file validation and retention of the actual parsed final file diagnostic.
- Added `test_file_early.py`: finite synthetic peer, independent outgoing
  header/frame decoder, canonical bounded range generation, aggregate
  hashes/counts, shared records/output/B-binding across fresh codecs,
  standalone partial selections, final67+metrics and44 focused controls.
- Changed `adapter.py`: early-final primary binds stream7 from actual request
  order; dispatch the two new schedules; after `wire.complete` has validated
  terminal/reset facts, `finish` represents `refusal_after_final` reset as
  NO_ERROR0. Cancellation8, application-failure2 and healthy None remain.
- Changed `cases.py`:34->36 implemented cases and accurate module description.
- Changed `test_imports.py`: exact31-module inventory includes both new modules.
- Changed explicit unsupported inventories6->4 in `test_pause.py`,
  `test_admission.py`, `test_continue_quota.py`, `test_metadata_concurrency.py`.
  Every existing assertion/rejection loop is retained; metadata output says4.

Reused only source-compatible earned producer helpers:
`producer_pressure_cases.configure`, `grant`, `body_status`, `echo`.
The producer upload/output/checkpoint/completion helpers were not reused because
they encode a different response length/hash/schema. New helpers add actual
special request, file-range response and early prefix/completion invariants;
there is no forwarding-only abstraction, alternate inbound parser, duplicate
refund application, direct ledger/stage surgery, hidden history or cache.

The action path remains the single bound wire/parser/request-ledger/
response-ledger/stage path. Actual calls flow through `wire.update_settings`,
`new_grants`, `grant`, `start_request`, `send_data`, `accept`, `drain`,
`complete`, `retire`, `enter_final`, `finish_final`. The model provides
`request_contract`, `record`, `validate_item`, `validate_file`,
`validate_output_response`, `payload_span` and `digest`; tests additionally use
`validate_records` and `validate_output_pre_post` to check supplied data and
retained snapshots. These validators are the current immutable model, not a
second copied model.

## Exact contracts and serialized schedules

| Case | Heads J | Small C | Request flow R | Primary | Special grants |
| --- | ---: | ---: | ---: | ---: | --- |
| stream_file | 7 | 6 | 33 | 5 | 24593 |
| early_final_order | 7 | 6 | 32 | 7 | 8,9 |

Both start with the already-initiated helper's75-byte startup, canonical peer
initial SETTINGS and first ACK. Both send exactly one INITIAL_WINDOW_SIZE0
update and require the actual second parsed SETTINGS ACK before any grant or
request. They apply exactly once stream0 bootstrap
`33554432-credit.connection` (33488897 in the synthetic peer), through the
canonical policy. All six auxiliary streams get their once-only65535 grant;
primary grants are special, never auxiliary. No unearned credit or replayed
refund is introduced. Exact unchanged catalogue contracts are retained in
`evidence/b6b/contracts.json`.

`stream_file`: health1; echo3 opened; primary5 POST with declaration32 and exact
model target/query/x-case; canonical32+END; complete body status7; held file
output9; parser-complete zero-byte/no-END/no-reset checkpoint; sibling`s`+END
and its successful echo before the grant; special24593; hash-only completion;
complete file output11; health13. File headers contain exactly one
`content-length: 24593` and status200. There are4 positive synthetic output DATA
frames and33 bytes of request DATA in two one-shot END frames. Carried request
connection/aggregate stream debts are33/33.

The source file is24659 bytes. The selected range is offset37, length24593,
upper bound24630. The synthetic peer generates each bounded span with
`model.payload_span(24659,37+offset,count)` where count<=8192. It never treats
the range as a fresh24593-byte payload starting at0. Range SHA256:
`8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac`.
Separate full-file SHA256:
`2cd533d3b2bd76e62ead7795d612fcc1f4d5121bedeed4499f5e629f5b358bd3`.
The final audit recomputes both using bounded canonical generator calls.
No real file was created/opened/read/transferred.

Held file diagnostics require the immutable model's schema/types,
`arms=1,arm_errors=0,transferred=true,caller_owned=false,read_errors=0,
invalid_spans=0,close_calls=0,closed_files=0`. Complete diagnostics require
`close_calls=1,closed_files=1,reads>=1,requested>=returned>=1` and
`37<=min_offset<max_end<=24630`, with the same ownership/error fields.
The positive supplied diagnostic uses reads4, requested/returned24593,
min_offset37, max_end24630. These are supplied model inputs, not measurements
of native reads or proof that a native handle closed once.

After complete validation the actual parsed final diagnostic is retained in
`context['output_observations']['stream_file']`. Existing entries and
`context['output_binding']` preserve object identity. The shared positive
sequence first runs the actual existing serialized producer reuse test, then
file and early-final in fresh contexts, carrying its actual parsed producer
outputs and relative B binding. Their values survive final67+metrics and
immutable model snapshot validation with no extra observation requests.
There is no claim of post-deinit comparison.

`early_final_order`: health1; holder3 POST declares32 and leaves request DATA
open; holder status5 proves its actual admitted/active state with0 bytes,
empty hash,0 chunks/max_span/ends/metadata_end; refusal7 uses exact model
method/target/query/x-case/declaration32 plus `Expect: 100-continue`, with no
request DATA. Its actual403 headers arrive before the first checkpoint,
with0 informationals,0 response DATA,no END/reset. Body status9 validates the
complete refusal record rather than a successful upload record. Grant8;
checkpoint proves exactly8 bytes/hash(`early-fi`) with no END/reset; body
status11 validates the same complete record again. Grant9; finish the exact17
bytes/hash of`early-final-order`, accepting END before NO_ERROR0 reset using
the unchanged raw-order and response validators. Only then holder3 sends
canonical32+END, its terminal response record is validated, and health13 ends
the schedule. There are2 response DATA frames,1 NO_ERROR reset,0 informationals,
and only the holder's32 request DATA bytes. Carried request debts are32/32.

Every action/read/drain/retirement/final boundary uses a fresh caller-owned
integer time hook and inherited case/whole deadlines. No real clock read or
changed capacity/budget/deadline/count threshold exists. Small bodies remain
bounded; special responses retain only hashes/counts. Peer reads and generated
spans are<=8192. The peer records aggregates and finite per-upload fields,
not full output/upload bodies or per-frame/read histories. Its200-read limit is
a finite test bound, never an altered catalogue bound.

## Real RED and complete intermediate history

The actual serialized test was authored before implementation and retained as
`evidence/b6b/initial-test.py`. Every attempt has exact `.command`, raw
`.stdout`, `.stderr` and `.exit`. Failed test versions are retained as
`attempt-1-test.py` through `attempt-4-test.py`; later successful versions are
`attempt-5-test.py`, `attempt-6-test.py`. Initial schedule/adapter bytes remain
in `first-schedule.py` and `first-adapter.py`.

The exact environment for all Python tests is:

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

The initial and attempt1-6 invocation is:

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_file_early.py
```

1. `initial-red`: exit1, empty stdout, traceback ends
   `ValueError: case schedule not implemented`. This is selection RED only,
   not a behavioral/native failure or immutable API defect.
2. Implemented both schedules and minimal adapter/selection wiring.
   `attempt-1`: exit1 after the actual file schedule completed, at the test's
   snapshot validation: `ValueError: unselected binding differs`. The peer
   supplied a default binding as the pre-value even though the immutable
   model requires pre=None when producer reuse is unselected. Corrected the
   test call; the caller-owned default binding is still preserved/tested.
3. `attempt-2`: four positive file/early executions pass; exit1 because early
   prefix corruption rejected at `file or early checkpoint differs`, earlier
   than the expected final `body length or digest differs`. Corrected the
   expected named invariant. Also moved synthetic close-twice corruption to
   complete diagnostics, so that control tests the final close predicate.
4. `attempt-3`: positives and earlier controls pass; exit1 because missing END
   with a following NO_ERROR reset rejects `reset order` rather than a
   missing-response read. Corrected the exact expected immutable rejection.
5. `attempt-4`: positives and all preceding controls pass; exit1 on public
   `h2.exceptions.InvalidBodyLengthError: InvalidBodyLengthError: Expected
   24592 bytes, received 24593`. The codec validates a wrong content-length
   before the schedule's final check. Added this exact public exception and
   expected message to the test, without changing codec or policy.
6. `attempt-5`: exit0, empty stderr;4 positives and40 exact synthetic negative
   controls pass. Added actual prior producer snapshot/binding preservation,
   missing/duplicate content-length, second body-record corruption and final
   early-output-tail corruption controls.
7. `attempt-6`: exit0, empty stderr;5 positives (one existing producer) and44
   controls pass. First full38 normal/-O regressions then pass. Self-review
   added assertions consuming the peer's output DATA-frame counter (4 file,
   2 early) and exact terminal reset fact. Final38 regressions rerun afterward.
   Earlier full-pass stdout/stderr/exit receipts remain as `.pre-last.*` and
   `snapshot.pre-last.json`/`final-audit.pre-last.stdout`.

All intermediate failures are test expectation/setup corrections. No failing
implementation was reverted/mutated to manufacture behavioral RED. Synthetic
controls are postimplementation sensitivity checks, never native fault tests
or evidence of an earlier product regression.

## Final verification

After the last module edit the exact invocations below ran for each test:

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/TEST.py
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/TEST.py
```

`TEST` is each of `test_adapter`, `test_admission`, `test_application_error`,
`test_async`, `test_continue_quota`, `test_control_reset`, `test_credit`,
`test_file_early`, `test_final`, `test_imports`, `test_large`,
`test_metadata_concurrency`, `test_negative`, `test_pause`,
`test_producer_pressure`, `test_ready`, `test_selection`, `test_shared`,
`test_time`. All38 true exits are0 and all raw stderr is empty.
`evidence/b6b/final-commands.json` indexes the exact environment/invocation and
raw receipts for every run. Normal and`-O` refer to Python optimization, not a
Zig build mode. No Zig/native/sanitizer/protocol/platform gates ran because
the release expressly permits pure in-memory codec preparation and forbids
native/build execution in this slice. Those gates remain required later.

Both actual import runs print `AST and inert import checks passed`. They test
all31 actual modules under empty and foreign argv with rejecting caller-owned
file/socket/SSLContext/process/clock/console doubles, with silent/inert imports.
All modules have exactly one main guard and no authored classes/custom
exceptions/assert-based proof. The snapshot audit checks depth<=3 everywhere;
new schedule depth2, new test depth3. No dead helper or hidden mutable global
was added. Metadata commands are guarded inline pinned Python, not new modules.

The reproducible final audit is:

```sh
sh .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6b/final-audit.command
```

Its embedded interpreter is the same pinned Python with`-B -S`. It checks all
immutable retained rows, exact ordered42 codecs/default-json aggregate,
captured released B6a source map, exact31 final source hashes and copies,
all38 true exits/empty stderr,36/4 selections,67 persistent records, both
canonical file hashes, identical49-line normal/-O new-suite output and source
stability during snapshot. Exact raw stdout follows below.

## Self-review and remaining facts

Self-review checked correctness, ownership, tests, documentation and gate
integrity. New setup reuses the reviewed two-ACK/grant policy. Every held/prefix
checkpoint waits for an actual parsed final header and complete frame boundary,
then checks exact length/hash and forbids END/reset. Final hash-only responses
pass immutable `wire.complete`; file content-length multiplicity is checked,
and early finish requires the immutable refusal-after-final ordering with
validated NO_ERROR0. Source-compatible producer helpers are reused without
incorrect producer length/schema assumptions. Actual file diagnostics are
retained only after model validation and preserve previous outputs/B binding.

All38 relevant existing/new normal/-O regressions pass. Unsupported selections
remain rejected through existing loops. No gate/threshold, budget/deadline,
capacity, parser, expected native behavior or authenticated identity changed.
No unresolved actionable concern or immutable API gap was found within this
slice. Root's independent review and public/Git delivery remain pending.

The remaining source selections are `shutdown_idle`, `disconnect`, `reuse`,
`shutdown_active`. All40/default/subset/aggregate semantics, strict successful
TLS unwrap AND plain TCP EOF replacement boundary, owned runner/runtime closure,
separately released sequential two-child native all40 run, adoption and all
unchanged2.2.0 project/platform/compliance gates remain required. Supplied
file diagnostics, aggregate synthetic body records and retained output/B
snapshots do not prove native file transfer/read/close behavior, callback
correctness, native two-slot reuse, metadata retention or post-deinit ownership.

## Raw final audit stdout

```text
31 modules: 2 added, 7 changed, 22 unchanged, 0 removed against released B6a
119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate
42 ordered codec identities and default-json aggregate match; no extra or missing codec files
38 final normal/-O commands exit0 with empty stderr; all-module AST and actual inert empty/foreign argv imports pass
maximum control depth=3; new schedule=2; new test=3
36 source schedules; four rejected unsupported selections; final collection67 records plus metrics
new test: five positive executions (one retained producer) and44 exact synthetic negative rejections per mode
remaining selections: shutdown_idle, disconnect, reuse, shutdown_active
```

## Raw new-suite stdout (normal; optimized identical)

```text
producer_reuse passed: J=9 C=8 R=64 output=16777313
stream_file passed: J=7 C=6 R=33 output=24593
early_final_order passed: J=7 C=6 R=32 output=17
stream_file passed: J=7 C=6 R=33 output=24593
early_final_order passed: J=7 C=6 R=32 output=17
body_hash rejected: record mismatch: sha256
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
informationals rejected: invalid HEADERS
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
output_hash rejected: file or early checkpoint differs
output_status rejected: wrong final status
missing_end rejected: reset order
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
informationals rejected: invalid HEADERS
other_record rejected: record mismatch: middleware
held_close rejected: file close once
close_twice rejected: file close once
ownership rejected: file ownership
arm_error rejected: file ownership
read_error rejected: file ownership
invalid_span rejected: file ownership
range rejected: file bounded range
requested rejected: file bounded range
no_reads rejected: file bounded range
range_generator rejected: body length or digest differs
sibling rejected: sibling echo differs
missing_sibling rejected: missing finite synthetic response
content_length rejected: InvalidBodyLengthError: Expected 24592 bytes, received 24593
duplicate_length rejected: file content-length differs
missing_length rejected: file content-length differs
holder_admission rejected: record mismatch: attempts
prefix_body_hash rejected: record mismatch: sha256
output_tail rejected: body length or digest differs
prefix_end rejected: invalid terminal
reset_first rejected: reset order
reset_code rejected: wrong reset code
missing_reset rejected: missing finite synthetic response
```
