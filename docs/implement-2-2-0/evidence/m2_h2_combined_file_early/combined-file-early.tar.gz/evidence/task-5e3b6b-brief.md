# Task5e3b6b: streamed file and early-final ordering

Released after B6a source/publication review and immediate push of commit
07434c7a7cd57b5349ce11f7a8a3b27b839673d4. Accepted29-module map is
docs/implement-2-2-0/evidence/m2_h2_combined_producer_pressure/manifest.json and
task-5e3b6a-root-final-audit.json; committed bytes/push are verified by
task-5e3b6a-root-commit-audit.json. Accepted34/40 source cases, no native acceptance.
Read task-5e3b-release-addendum.md and
task-5e3b-cases-pending-brief.md. Preserve original all40/default/aggregate/native
and all milestone requirements; no acceptance from this source-only unit.

Own concrete file/early-final schedules/tests, minimal actually-used existing
adapter/selection/import changes, evidence/b6b and task-5e3b6b-report.md. Reuse
earned B6a hash-only/SETTINGS/grant/checkpoint seams where their actual contract
fits. Preserve source/evidence and all existing assertion/rejection loops;
explicit unsupported counts6->4 and accurate36-case description authorized.
Root owns public/Git. You are not alone; no reverts/agents/external model CLI.

B6a's reviewed interface retains latest validated diagnostics in caller-owned
context['output_observations'] and its relative B pair in context['output_binding'].
Retain the file's final diagnostic there too, preserving any existing entries.
Later post-deinit comparison consumes
these actual observed values without extra on-wire GETs. No histories or hidden
global cache; supplied diagnostics are not native ownership proof.

Actual located producer_pressure_cases seams: configure(context,receive) uses
canonical two-ACK setup/bootstrap; grant(context,stream,amount,purpose) preserves
time/flush pairing; body_status and echo fit their source predicates. Its upload,
output_status,checkpoint and complete helpers fix producer length/hash/schema,
so do not reuse them blindly for file/early responses. Reuse earned semantics
where they fit and add only concrete used file/early invariants. adapter.start
already has role/mode/expected_sha256 and output-aware auxiliary grants; finish
omits body for hash_only. No immutable API gap follows from missing next-case
adapter bindings or prefix/result normalization.

Source-only authority: authenticated /tmp/uwz-task5d3-runtime-v5/cases.py,
diagnostics.py,records.py,post.py; contracts.py at
/tmp/uwz-task5d1-round3-current; profile.zig,output.zig,file_observer.zig at
/tmp/uwz-task5d2-fix2-final-snapshot. Read-only runtime case_adapter.py/protocol.py
are authenticated by the recovered v5 manifest. Never invoke old live/runtime/
constructor/close/file-transfer entrypoints. Current model/catalogue/fixture
schema and canonical wire supersede old aliases/direct ledger operations.

| Case | Heads J | Small C | Request flow R |
| --- | ---: | ---: | ---: |
| stream_file | 7 | 6 | 33 |
| early_final_order | 7 | 6 | 32 |

Both require second real SETTINGS ACK, initial stream window0, once-only exact
connection bootstrap, auxiliary grants and canonical special grant sequences.
stream_file grants24593; early final grants8 then9. No unearned credit/replayed
refunds or alternate parser. Keep start/end health and exact source barriers.
Three new body records/untouched records/shared app/fresh contexts/final67+
metrics remain mandatory. Diagnostics are supplied synthetic inputs, not native
file ownership/callback correctness evidence.

## Exact schedules

File: initialhealth1,echo3,primary5. Send canonical32+END, validate complete body
status. Observe held file diagnostics: arms1,arm_errors0,transferredtrue,
caller_ownedfalse,read_errors0,invalid_spans0,close_calls0,closed_files0. Require
response0bytes/noEND/reset. Send sibling b's'+END and verify its echo before
grant. Grant24593, finish hash-only output, exact content-length24593, then
validate complete file diagnostics and finalhealth. Require close_calls1 and
closed_files1 and model's exact bounded read/request/returned/range predicates.

The source file is24659bytes, selected offset37/length24593, upper end24630.
Its range SHA256 is8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac;
full-file hash2cd533d3b2bd76e62ead7795d612fcc1f4d5121bedeed4499f5e629f5b358bd3
is separate. Use the current model's total/offset-aware canonical generator,
not a new24593-byte payload starting at0 or a fabricated hash. Never open/read/
transfer a real file during this pure-codec unit; generate bounded peer spans.

Early final: initialhealth1,holder3,one active-holder status5,refusal7. Holder
declares32 with request body open and has actual admitted/active0accepted state.
Refusal uses exact model target/declaration/Expect with no request DATA. Wait
for actual403 HEADERS,0informationals,0bodybytes,noEND/reset. Observe its body
record. Grant8; require exact8bytes/hash(b'early-fi') and noEND/reset. Observe
same complete body record again. Grant9; finish exact17byte hash-only
b'early-final-order' response, with END accepted before NO_ERROR0 reset.
Then send holder32canonical+END, validate its successful terminal record and
finalhealth. No100, no fake successful refusal record, no extra heads.

Refusal primary is stream7, not the ordinary default5; bind from actual request
order. Reuse canonical role-special/refusal_after_final validation. Terminal
result reset fact must reflect validated NO_ERROR0; no stage/parser surgery.
Hash-only results omit body and validate exact length/hash/END via wire.complete.

## Proof and handoff

Begin actual serialized tests before implementing; retain initial test/real RED
scope/all intermediates. Selection/API RED is qualified. Independently decode
header multiplicity/order/END/status/content-length/Expect, SETTINGS/ACK/grants,
DATA spans/hash/flow, exact held/prefix/END-before-reset and sibling ordering,
file ranges/close diagnostics and body/recovery isolation. Use model validators,
not a second model. Synthetic controls are sensitivity checks, not native faults.

All actions/read/drain/final boundaries use fresh caller integer time/inherited
deadlines, one wire/parser/request+response ledgers/stage, bounded spans/hashes,
no full bodies/per-frame/read histories and unchanged budgets/capacities/caps.
Report a smallest actual immutable API gap while independent work continues.
After last edits capture normal/O commands and raw stdout/stderr/exit, changed-
seam regressions, all-module guards/AST/actual silent-inert empty/foreign-argv
rejecting-effect imports and exact snapshot vs released B6a. No authored classes,
custom exceptions/assert proof/hidden mutable globals/dead code/deep nesting.
Pinned Python -B -S for every invocation; graphify before first source read/search.

Use exact retained42codec rows/default-json ordered aggregate and distinguish
retained from unique identity counts. No native/build/socket/SSLContext/TLS/
real-clock/process/ownership/transfer/descriptor/kernel/fault/cancel/scheduling/
race/panic/leak experiment, product/model/core/fixture/dependency/Git/public edit,
old entrypoint or other agent. Full report gives exact contracts/APIs/files/
commands/raw/history/identities/self-review/remaining facts. Root reviews.
