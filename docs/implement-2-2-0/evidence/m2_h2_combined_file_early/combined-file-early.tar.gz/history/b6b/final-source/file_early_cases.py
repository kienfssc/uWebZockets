"""Finite streamed-range and early-final ordering over the bound public codec."""
import hashlib
import json
import adapter
import model
import producer_pressure_cases

FILE_HASH = '8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac'
EARLY_HASH = hashlib.sha256(b'early-final-order').hexdigest()


def upload(context, tag, primary):
    contract = model.request_contract(tag)
    headers = [('content-length', str(contract['declared'])), ('x-case', contract['x-case'])]
    early = tag == 'early_final_order'
    if early:
        headers.append(('expect', '100-continue'))
    return adapter.start(context, contract['method'], contract['target'], headers, False, primary,
                         (17 if early else 24593) if primary else 4095,
                         status=403 if early else 200, policy='refusal_after_final' if early else 'healthy',
                         role='special' if primary else 'small', held=primary,
                         mode='hash_only' if primary else 'small_body',
                         expected_sha256=(EARLY_HASH if early else FILE_HASH) if primary else None)


def checkpoint(context, receive, stream, size, digest):
    record, raw = context['records'][stream], context['raw']
    while record['headers'] is None or record['bytes'] < size or raw['header'] or raw['frame'] is not None or raw['remaining']:
        adapter.tick(context)
        data, now = receive()
        adapter.observe(context, data, now)
    observed = raw['streams'][stream]
    if (record['bytes'] != size or record['hash'].hexdigest() != digest or record['informationals'] != 0 or
            record['ended'] or observed['end'] or observed['reset'] or observed['peer_reset']):
        raise ValueError('file or early checkpoint differs')


def complete(context, receive, stream):
    result = adapter.finish(context, stream, receive)
    if 'body' in result:
        raise ValueError('hash-only response retained body')
    value = dict(bytes=result['bytes'], sha256=result['sha256'], end=result['ended'], reset=result['reset'] is not None)
    if context['stage']['case'] == 'stream_file':
        if [value for name, value in result['headers'] if name == 'content-length'] != ['24593']:
            raise ValueError('file content-length differs')
        value['content_length'] = 24593
    model.validate_output_response(context['stage']['case'], value)


def stream_file(context, receive):
    sibling = adapter.start(context, 'POST', '/echo', [('content-length', '1')], False, False, 1)
    primary = upload(context, 'stream_file', True)
    adapter.send_data(context, primary, model.payload_span(32, 0, 32), True)
    producer_pressure_cases.body_status(context, receive, 'stream_file')
    held = json.loads(adapter.get(context, '/output/stream_file', receive)['body'])
    model.validate_file(held, False)
    checkpoint(context, receive, primary, 0, model.EMPTY_HASH)
    adapter.send_data(context, sibling, b's', True)
    producer_pressure_cases.echo(context, receive, sibling)
    producer_pressure_cases.grant(context, primary, 24593, 'special')
    complete(context, receive, primary)
    final = json.loads(adapter.get(context, '/output/stream_file', receive)['body'])
    model.validate_file(final, True)
    context.setdefault('output_observations', {})['stream_file'] = final


def early_final(context, receive):
    holder = upload(context, 'early_final_recovery', False)
    active = json.loads(adapter.get(context, '/status/early_final_recovery', receive)['body'])
    expected = model.record('early_final_recovery', True, 'after')
    expected.update(bytes=0, sha256=model.EMPTY_HASH, chunks=0, max_span=0, ends=0, metadata_end=0, active=True)
    model.validate_item(active, expected)
    refusal = upload(context, 'early_final_order', True)
    checkpoint(context, receive, refusal, 0, model.EMPTY_HASH)
    producer_pressure_cases.body_status(context, receive, 'early_final_order')
    producer_pressure_cases.grant(context, refusal, 8, 'special')
    checkpoint(context, receive, refusal, 8, hashlib.sha256(b'early-fi').hexdigest())
    producer_pressure_cases.body_status(context, receive, 'early_final_order')
    producer_pressure_cases.grant(context, refusal, 9, 'special')
    complete(context, receive, refusal)
    adapter.send_data(context, holder, model.payload_span(32, 0, 32), True)
    model.validate_item(json.loads(adapter.finish(context, holder, receive)['body']), model.record('early_final_recovery', True, 'after'))


def run(context, receive):
    producer_pressure_cases.configure(context, receive)
    adapter.health(context, receive)
    if context['stage']['case'] == 'stream_file':
        stream_file(context, receive)
    else:
        early_final(context, receive)
    adapter.health(context, receive)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
