#!/usr/bin/env python3
"""Retain source and public GitHub license facts without inferring a grant."""
import hashlib
import json
from driver import BASE, run

repo = BASE / 'repos' / 'h1spec.git'
base = 'f0a5650a20c575fbea0f7179a3a9cfa50f20ba6e'
pin = '999ba9e8f318b1c0ebbff1278b98bc5833f1af18'
run('h1spec_ancestor_tree', ['git','-C',str(repo),'ls-tree','-r',base])
run('h1spec_full_history_files', ['git','-C',str(repo),'log','--all','--reverse','--format=commit %H%n%B','--name-status'])
run('h1spec_current_license_text_search', ['git','-C',str(repo),'grep','-n','-i','-E','license|copyright|permission is hereby',pin,'--'],allowed=(0,1))
run('h1spec_ancestor_license_text_search', ['git','-C',str(repo),'grep','-n','-i','-E','license|copyright|permission is hereby',base,'--'],allowed=(0,1))
run('h1spec_history_license_text_changes', ['git','-C',str(repo),'log','--all','--reverse','--format=commit %H%n%B','--regexp-ignore-case','-G','license|copyright|permission is hereby'])
endpoints = [
 ('h1spec_fork_license_api', 'https://api.github.com/repos/farbenbuilds/h1spec/license?ref='+pin),
 ('h1spec_upstream_license_api', 'https://api.github.com/repos/uNetworking/h1spec/license?ref='+base),
 ('h1spec_upstream_metadata_api', 'https://api.github.com/repos/uNetworking/h1spec'),
]
responses = []
for label, url in endpoints:
 body = BASE / 'raw' / (label + '.body.json')
 status = run(label, ['curl','--silent','--show-error','--location','--output',str(body),'--write-out','%{http_code}\n',url]).strip()
 responses.append({'url':url,'http_status':int(status),'body':str(body.relative_to(BASE)),'sha256':hashlib.sha256(body.read_bytes()).hexdigest()})
manifest_path=BASE/'manifest.json'
manifest=json.loads(manifest_path.read_text())
manifest['h1spec_license_investigation']={
 'pin':pin,'ancestor':base,
 'source_fact':'No license file or matching license/copyright/grant statement in either retained tree; no such changes in the 22-commit reachable history.',
 'root_attribution':'Captured THIRD_PARTY_NOTICES.md says MIT; captured pinned sources do not substantiate that attribution.',
 'api_responses':responses,
 'boundary':'A missing recognizable GitHub license is not a legal conclusion about permissions. No license text or license grant is invented.',
 'proposed_notice_wording':'License unverified: the pinned h1spec source contains no license notice; maintainer confirmation required.',
 'restoration':'Before the 2.2.0 release, the maintainer supplies verifiable permission/license evidence for the pinned source and corrects the notice, or resolves the dependency inclusion policy. Do not contact upstream from this agent.'}
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
