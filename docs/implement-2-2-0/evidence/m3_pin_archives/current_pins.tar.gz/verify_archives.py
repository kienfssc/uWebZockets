#!/usr/bin/env python3
"""Verify complete pin histories and reconstruction using only retained bundles."""
import hashlib
import json
from pathlib import Path
from driver import BASE, run


def git(repository, *arguments):
    return ['git', '-C', str(repository), *arguments]


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        while chunk := source.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def verify(dependency):
    name = dependency['name']
    pin = dependency['pin']
    repository = BASE / 'repos' / (name + '.git')
    restored = BASE / 'restored' / (name + '.git')
    bundle = BASE / 'bundles' / (name + '.bundle')
    shallow = run(name + '_source_shallow', git(repository, 'rev-parse', '--is-shallow-repository')).strip()
    assert shallow == 'false', (name, shallow)
    run(name + '_source_fsck', git(repository, 'fsck', '--full', '--strict'))
    actual = run(name + '_source_pin', git(repository, 'rev-parse', 'refs/archive/current-pin^{commit}')).strip()
    assert actual == pin, (name, actual)
    tree = run(name + '_source_tree', git(repository, 'rev-parse', pin + '^{tree}')).strip()
    commits = int(run(name + '_source_commit_count', git(repository, 'rev-list', '--count', pin)).strip())
    run(name + '_source_commit', git(repository, 'show', '--no-patch', '--format=fuller', pin))
    nodes = run(name + '_source_nodes', git(repository, 'ls-tree', '-r', pin))
    links = []
    licenses = []
    for line in nodes.splitlines():
        entry, path = line.split('\t', 1)
        mode, kind, identity = entry.split()
        if mode == '160000':
            links.append({'path': path, 'commit': identity})
        leaf = Path(path).name.lower()
        if kind == 'blob' and (leaf.startswith('license') or leaf.startswith('copying') or leaf in ('notice', 'copyright')):
            label = name + '_license_' + str(len(licenses))
            run(label, git(repository, 'show', pin + ':' + path))
            destination = BASE / 'licenses' / name / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes((BASE / 'raw' / (label + '.stdout')).read_bytes())
            licenses.append({'path': path, 'git_blob': identity, 'sha256': sha256(destination), 'archive_path': str(destination.relative_to(BASE))})
    if any(line.endswith('\t.gitmodules') for line in nodes.splitlines()):
        run(name + '_gitmodules', git(repository, 'show', pin + ':.gitmodules'))
    if 'upstream_base' in dependency:
        run(name + '_base_ancestor', git(repository, 'merge-base', '--is-ancestor', dependency['upstream_base'], pin))
        run(name + '_downstream_commits', git(repository, 'log', '--reverse', '--format=commit %H%n%B', dependency['upstream_base'] + '..' + pin))
    refs = ['refs/archive/current-pin']
    if dependency.get('lsquic_gitlink', pin) != pin:
        refs.append('refs/archive/lsquic-child')
        run(name + '_codec_ancestor', git(repository, 'merge-base', '--is-ancestor', dependency['lsquic_gitlink'], pin))
    run(name + '_bundle_create', git(repository, 'bundle', 'create', str(bundle), *refs))
    run(name + '_bundle_heads', ['git', 'bundle', 'list-heads', str(bundle)])
    run(name + '_restore_init', ['git', 'init', '--bare', str(restored)])
    run(name + '_bundle_verify_empty', git(restored, 'bundle', 'verify', str(bundle)))
    run(name + '_restore_fetch', git(restored, 'fetch', '--no-tags', str(bundle), *[ref + ':' + ref for ref in refs]))
    restored_shallow = run(name + '_restore_shallow', git(restored, 'rev-parse', '--is-shallow-repository')).strip()
    restored_pin = run(name + '_restored_pin', git(restored, 'rev-parse', 'refs/archive/current-pin^{commit}')).strip()
    restored_tree = run(name + '_restored_tree', git(restored, 'rev-parse', pin + '^{tree}')).strip()
    restored_commits = int(run(name + '_restored_commit_count', git(restored, 'rev-list', '--count', pin)).strip())
    assert (restored_shallow, restored_pin, restored_tree, restored_commits) == ('false', pin, tree, commits)
    run(name + '_restore_fsck', git(restored, 'fsck', '--full', '--strict'))
    if len(refs) > 1:
        restored_child = run(name + '_restored_child', git(restored, 'rev-parse', 'refs/archive/lsquic-child^{commit}')).strip()
        assert restored_child == dependency['lsquic_gitlink']
    dependency.update(tree=tree, history_commit_count=commits, shallow=False, archive_refs=refs,
        gitlinks=links, licenses=licenses, bundle={'path':str(bundle.relative_to(BASE)), 'bytes':bundle.stat().st_size,'sha256':sha256(bundle)},
        local_reconstruction={'empty_repository_bundle_verify_exit':0,'fetch_exit':0,'fsck_exit':0,'pin_matches':True,'tree_matches':True,'commit_count_matches':True,'network_used':False})
    return dependency


def main():
    manifest_path = BASE / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    for dependency in manifest['dependencies'] + manifest['children']:
        verify(dependency)
        manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    links = {item['path']: item['commit'] for item in next(item for item in manifest['dependencies'] if item['name'] == 'lsquic')['gitlinks']}
    for child in manifest['children']:
        assert links[child['lsquic_path']] == child['lsquic_gitlink']
        assert child['gitlinks'] == [], 'Nested codec gitlinks need explicit preservation'
    manifest['nested_codec_gitlinks'] = 'None at retained codec pins; both lsquic children explicitly preserved.'
    manifest['verification'] = 'All 5 complete-history bundles verified in initially empty local repositories, restored without network, and fsck checked. This is one machine.'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')


if __name__ == '__main__':
    main()
