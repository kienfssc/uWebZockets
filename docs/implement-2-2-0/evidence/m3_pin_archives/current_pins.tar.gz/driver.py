#!/usr/bin/env python3
"""Retain exact commands and terminal results for current-pin Git preservation."""
import datetime
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent


def run(label, arguments, allowed=(0,)):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stdout = BASE / 'raw' / (label + '.stdout')
    stderr = BASE / 'raw' / (label + '.stderr')
    with stdout.open('wb') as output, stderr.open('wb') as errors:
        result = subprocess.run(arguments, stdout=output, stderr=errors, check=False)
    record = {'argv': arguments, 'cwd': str(BASE), 'started_utc': started,
              'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'exit': result.returncode, 'stdout': stdout.name, 'stderr': stderr.name}
    (BASE / 'raw' / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(label + ' exit ' + str(result.returncode), flush=True)
    if result.returncode not in allowed:
        raise SystemExit(result.returncode)
    return stdout.read_text()


def acquire(name):
    dependency = next(item for item in json.loads((BASE / 'manifest.json').read_text())['dependencies'] + json.loads((BASE / 'manifest.json').read_text())['children'] if item['name'] == name)
    repository = BASE / 'repos' / (name + '.git')
    run(name + '_init', ['git', 'init', '--bare', str(repository)])
    run(name + '_fetch_pin', ['git', '-C', str(repository), 'fetch', '--no-tags', dependency['url'], dependency['pin'] + ':refs/archive/current-pin'])
    if 'lsquic_gitlink' in dependency:
        if dependency['lsquic_gitlink'] != dependency['pin']:
            run(name + '_fetch_child', ['git', '-C', str(repository), 'fetch', '--no-tags', dependency['url'], dependency['lsquic_gitlink'] + ':refs/archive/lsquic-child'])
        return
    run(name + '_remote_fork_refs', ['git', 'ls-remote', dependency['url'], 'refs/heads/' + dependency['integration_branch'], 'refs/heads/' + dependency['mirror_branch']])
    run(name + '_remote_upstream_ref', ['git', 'ls-remote', dependency['upstream_url'], 'refs/heads/' + dependency['upstream_branch']])


if __name__ == '__main__':
    acquire(sys.argv[1])
