#!/usr/bin/env python3
"""Reconstruct pinned working trees from the adjacent bundles, without network."""
import json
from pathlib import Path
import subprocess
import sys


def run(arguments):
    print(json.dumps(arguments), flush=True)
    subprocess.run(arguments, check=True)


def identity(repository, revision):
    return subprocess.check_output(['git', '-C', str(repository), 'rev-parse', revision], text=True).strip()


def restore(base, destination):
    manifest = json.loads((base / 'manifest.json').read_text())
    destination.mkdir(exist_ok=False)
    for dependency in manifest['dependencies'] + manifest['children']:
        repository = destination / dependency['name']
        bundle = base / dependency['bundle']['path']
        run(['git', 'init', str(repository)])
        run(['git', '-C', str(repository), 'fetch', '--no-tags', str(bundle), *[ref + ':' + ref for ref in dependency['archive_refs']]])
        run(['git', '-C', str(repository), 'checkout', '--detach', dependency['pin']])
        assert identity(repository, 'HEAD') == dependency['pin']
        assert identity(repository, 'HEAD^{tree}') == dependency['tree']
    lsquic = destination / 'lsquic'
    for child in manifest['children']:
        name = child['lsquic_path']
        bundle = base / child['bundle']['path']
        run(['git', '-C', str(lsquic), 'config', 'submodule.' + name + '.url', str(bundle)])
    run(['git', '-c', 'protocol.file.allow=always', '-C', str(lsquic), 'submodule', 'update', '--init', '--recursive'])
    for child in manifest['children']:
        assert identity(lsquic / child['lsquic_path'], 'HEAD') == child['lsquic_gitlink']
    for dependency in manifest['dependencies'] + manifest['children']:
        repository = destination / dependency['name']
        result = subprocess.check_output(['git', '-C', str(repository), 'status', '--porcelain'], text=True)
        assert result == '', (repository, result)
    print('Exact current-pin working trees and lsquic gitlinks reconstructed from local bundles; all tracked working trees clean.', flush=True)


if __name__ == '__main__':
    restore(Path(__file__).resolve().parent, Path(sys.argv[1]).resolve())
