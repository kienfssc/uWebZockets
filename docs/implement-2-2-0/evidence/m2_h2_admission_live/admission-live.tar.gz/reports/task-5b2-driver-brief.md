# Task5b2 next preparation step: driver and combined review package

Read first: original task-5b2-brief.md and architecture remain binding. The
fixture step is complete as compile-only preparation; parent task still needs
the client driver, complete freeze, independent review and separately authorized
live acceptance. This step finishes the driver and then the combined source
package if its checks are complete. No native runtime is authorized.

Keep ownership under admission/ only, plus reports. You are not alone; preserve
others and prior work; no subagents, production edits, commits/refs/pushes/fetches,
network installs or external model CLI. Local graphify/read-only inspection,
source editing, syntax/AST/format and actual pure codec/data checks are allowed.
No fake socket/status/callback/completion, fixture/client/server/socket/cert/
candidate native execution, full native tests, stopped experiments or new native
fault/cancellation schedule/race/resource/leak/invalid-fd/kernel-error probes.

Concrete fixture contract: admission/fixture-contract.md. Final profile SHA
96a6c4873181c7e1da375b3a98160979fcf81d5e7cad04c7a2ef2f695fad2bb2.
Retained fixture-debug-v2 and fixture-release-v2 compile0/emptylogs, binaries
/tmp/uwz-task5b2-debug-v2/profile SHA
c7ba1bd7cb695c1136dec6c2729f692cb71db0fdddcf46e5acdb60af4a743773;
/tmp/uwz-task5b2-release-v2/profile SHA
c72fbf846db238a8a25a5b8a8a4d048dd7f3891c9605b5c346fcf7e33d2539df.
Use these actual binaries without rebuilding if profile/recipe/inputs remain
identical. Original fixture inventory9483a4a6dda5e23007a11ec1e3dd205ae62d4775161bffde469658e99fd04b2b
and wire-only partial history must stay recoverable. If an actual test-only
fixture inconsistency requires edits, preserve preimages and explain/recompile
affected fixture sources in both modes; do not silently change the contract.

Implement explicit-gated run_live.py plus a focused admission-case module if
needed to keep process orchestration and case policy readable. Integrate the
existing raw_observer.py and wire.py instead of creating duplicate parsers.
Retain the approved core/pause process identity, bounds and independent cleanup
invariants. Remove copied unused EXPECTED100M constant from NEW driver code.

Bind/check the actual executing runner path/hash and every loaded custom module
(wire, raw observer, case module, original helper) before use, including module
__file__ after loading. A source tree inventory alone is insufficient if Python
can select a different working-copy module. Exact fixed interpreter/-B/-S and
client/helper PYTHONPATH remain required. Custom imports must be inert; no setup,
socket, certificate command or candidate binary execution at import or --help.

Implement all13 cases and their self-contained recovery groups from the exact
architecture ledger, supported unique subsets ending shutdown_idle. No old core
or pause cases are rerun. Unsupported/unimplemented IDs fail, not skip. Full
selection has22 named body records andM22/A19/B18/E16/C2/F1/384acceptedbytes,
two body_too_large cancellations,zero active/errors. All32 records (including
spares/unselected cases) must be validated and survive through deinit. Expectations
come from the independent ledger/payload, not the fixture's reported totals.

For each stream freeze expected final status/body/hash/info/reset policy. All
healthy streams forbid rawRST. The six refused primaries leave input open and
require their specified413/503,emptybody,no100, then exactlyone rawNO_ERROR0
after complete finalEND_STREAM. Rejectearly/duplicate/wrongcode/wrongstream/
healthy/retired resets. Handle actual h2 StreamReset consistently without double
counting raw frames or dropping evidence when library ignores closed resets.
Keep bounded records/exceptions through required terminal and same-connection
healthy/recovery barriers, then restore default rejection. No globalRST waiver.

Ready/pausedContinue must actually observe one informational status100 BEFORE
the driver sends positiveDATA; no guessed sleep or sending early. Informational
metadata remains bounded and never substitutes for final X-Middleware header.
Every final200/413/503 carries exactlyone x-middleware:retained. Wait for actual
same-connection status predicates on observed-limit accepted32 and pausedContinue
accepted0/chunks0/noend. No finalHEADERS/end before valid resume on paused body.
Quota2 recovery needs TWO simultaneously active recovered requests, not one;
failed begin is quota-one /limit with no cancel, then same-route recovery.

Do not confuse body-head middlewareM with buffered_middleware. The latter
increments on health/status/metrics/resume requests themselves. Before shutdown,
collect all32 record snapshots, then collect aggregate /metrics LAST. Do not make
more buffered requests afterward: the final aggregate including buffered count
must match post-deinit aggregate exactly. Compare per-case semantic counters
without mistakenly treating expected diagnostic buffered increments as mutation.
Snapshot expectations for unused records are explicit zero/empty/noactive/none,
not merely accepting their initial server values as a golden reference.

Retain initial health only after direct owned PID/start/nonce/listener/certificate
identity and TLS1.3/h2 checks. Endpoint127.0.0.1:28443; fresh private/tmp run dir;
15s readiness/30s each complete case/900s overall/15s graceful absolute deadlines;
no retry/fallback. Bounded reads/generated spans8192, responsebody<4096, headers
32/4096, infos16/16384, response records<=8, bounded event/frame/results state,
continuous combined-output65536. Independent socket/childsignal/reap/keydelete/
log/pipe cleanup; forced or failed cleanup cannot become success. Record actual
responses, accepted/hash/lifecycle outcomes, case recovery and terminal markers.

Keep existing purewire check outcomes; rerun only if changed code/integration
justifies it. Add meaningful actual codec/data checks for changed verifier logic,
module-binding or ledger selection where useful, without simulating native I/O.
Do not claim a behavioralred against an old unsupported scope. No full-case
runtime proof follows from pure checks or successful compilation.

When complete, freeze the combined test-only package under a new/tmp path and
create review-manifest.json clearly marked source-review-ready. Bind all frozen
files, exact libraries/bindings/tool/interpreter/SSL-loader/helper/binary inputs,
complete production/client/override/zslay/custom-source inventories, original
actual build commands/results/logs and unchanged source/client digests. Retain
before/after input identity and actual mode/binary receipts. Prior manifests,
source snapshots, partial reports and logs remain immutable/recoverable.

Write task-5b2-driver-report.md with exact changes/commands/rawoutcomes/hashes and
parent current status. Preserve the previous parent report then clearly append
the new combined status to task-5b2-report.md. Source self-review must check all
13 cases,32 records, six refusal policies, two simultaneous quota recoveries,
counter/header/Continue ordering, import/identity/cleanup paths and no unused
code. Return DONE for combined StageA only when every source/build/binding piece
exists; otherwise give a specific concrete remaining blocker and completed
bounded substep. Root handles independent review and any later exact native run.
