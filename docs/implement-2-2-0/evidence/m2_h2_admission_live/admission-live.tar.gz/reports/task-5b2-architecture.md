# Task5b2 source-backed admission ledger

Root adopts architect_h2_live_plan's narrow read-only preflight. Same immutable
fc69/c223/config/client inputs; no source/runtime change follows from planning.
P32/H32 are the existing helper's32-byte payload and independent SHA. M counts
middleware calls for body-route heads only, not buffered health/status/control.
A/B/E/C/F are begin attempts/successful bindings/ends/cancels/failed begins.

| Case | Primary and recovery requests | M;A/B/E/C/F |
| --- | --- | --- |
| empty_headers | /empty, HEADERS+EOF, no length;200/0/emptySHA/0chunks | 1;1/1/1/0/0 |
| empty_data | /empty openhead, emptyDATA+EOF; same result | 1;1/1/1/0/0 |
| empty_declared | /empty length0, HEADERS+EOF; same result | 1;1/1/1/0/0 |
| limit_declared | /limit length32, P32+EOF;200/32/H32 | 1;1/1/1/0/0 |
| limit_undeclared | /limit no length,P32+EOF; same result | 1;1/1/1/0/0 |
| limit_declared_reject | /limit length33+Expect, open/noDATA:413/empty/no100/noA. Then same-route recovery length32/P32/EOF:200/32/H32 | 2;1/1/1/0/0 |
| limit_observed_reject | /limit no length,P32, sameconn status accepted32, literalx withoutEOF:413/empty,accepted32/H32,Cbody_too_large/noE. Same-route length32/P32/EOF recovery | 2;2/2/1/1/0 |
| zero_declared_reject | /empty length1+Expect/noDATA:413/empty/no100/noA. Same-route emptyHEADERS+EOF recovery | 2;1/1/1/0/0 |
| zero_observed_reject | /empty no length,literalx withoutEOF:413/empty,accepted0,Cbody_too_large/noE. Same-route emptyHEADERS+EOF recovery | 2;2/2/1/1/0 |
| continue_ready | /limit length32+Expect, wait100 beforeP32/EOF; exactlyone100 then200/32/H32 | 1;1/1/1/0/0 |
| continue_paused | /limit length32+Expect, beginpaused;wait100,sendP32/EOF,status0accepted/0chunks/0E,publicresume then200/32/H32,one100overall | 1;1/1/1/0/0 |
| quota_refuse | /upload two ready length32 holders/noDATA, thirdlength1+Expect:503/empty/no100/noA. Finish bothP32/EOF. Admit TWO simultaneous recoveryheads before either completes, thenP32/EOF both. active2->0->2->0 | 5;4/4/4/0/0 |
| begin_failure_rollback | quotaONE /limit length32+Expect applicationbeginerror:503/empty/no100/A1/F1/noB/E/C. Same-route normal length32/P32/EOF recovery | 2;2/1/1/0/1 |

All13:22requestrecords,M22,A19,B18,E16,C2,F1,accepted384bytes (twelveP32),
bothcancelreasons body_too_large,active0. Each selectable case includes its
whole primary/holder/recovery sequence and uses distinct fixed tags. Quota2
needs two simultaneous recoveries to detect one leaked reservation; failed
begin deliberately uses quota1 so recovery proves rollback directly.

32fixed records suffice; preserve them separately from2reusable sinkslots and
throughdeinit. Statusbelow4096, no recordconsumption by bufferedroutes, overflow
fails. Perrecord holds case/role/route/copiedtag,M/A/B/E/C/F,accepted/chunks/span,
hash,active/paused/terminal,cancelreason,headerchecks/errorflags.

Global authorized headers_only middleware appends exactly X-Middleware: retained.
Source body_admission49-62,68-80: match/policy; toleratefullquota initially;
markbodyincomplete and runmiddleware; declaredlimit/ingress/headercapacity;
secondquota check/reserve/begin. Therefore EVERY22bodyhead runsmiddleware once,
including declared/quota/failedbegin refusals. Buffered requests may increase a
separate global counter; do not compare it withM22.

Every final200/413/503 contains exactlyone x-middleware:retained. Declared/quota
refusal use currentResponse headers (http2_upload124-145); failedbegin rollsback
and refuses sameResponse(154-158); observedcap cancellation restores retained
headers(83-93); successend restores freshResponse headers(194-220). No middleware
rerun on resume/observedcap. Continue onlyafterbindingaccept(server1580-1590);
literal100HEADERS does not consume finalheaders(server1637-1650), evenbeginpaused.
These expectations concern validPOST heads, notearlydata/QUERY/malformed/capoverflow.

Each stream has explicit expectation: healthy200/bytes/hash/EOS/noRST, info0except
the twoContinue variants(infoexactlyone,status100,beforeDATA). AllSIXrefusedprimary
streams require final413or503/empty/info0 then exactlyone rawRSTNO_ERROR0 AFTER
complete finalEND_STREAM frame. Inputstaysopen as above. Source server2086-2092
ordersreset afterfinal; observedcap uses413ratherthanINTERNAL_ERROR(1689-1715).

Raw frame order is independent of libraryevents because h2mayignoreclosedstream
resets. Rejectearly/duplicate/wrongcode/wrongstream resets, keephealthy strictnoRST,
and restore defaultrejection after retiringrefusalexception. Keepbounded records
through sameconnection healthy/recoverybarriers. Case completes onlyafterexpected
final/reset AND same-route recovery; absolute30s/case, no sleeps. Normal final
run/deinit/exit0/reaped remainsrequired. Rest5b/5c/fullmilestonesstayopen.
