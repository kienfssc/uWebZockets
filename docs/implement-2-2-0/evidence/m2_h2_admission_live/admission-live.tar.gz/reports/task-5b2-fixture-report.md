# Task 5b2 fixture preparation

Scoped fixture step: DONE for source and compile-only preparation; parent task remains incomplete. The actual configured HTTPS App, three real route limits/quotas, fixed 32 records, two sink slots, retained-header middleware, metrics/status/resume, and post-deinit output are in `.uwz-work/evidence/h2-streaming/integration-owned/admission/profile.zig`. The exact tag map, fields and lifetime contract are in `fixture-contract.md`. The driver, full source review, frozen combined manifest, live acceptance and milestone gates remain outstanding.

The final fixture source SHA-256 is `96a6c4873181c7e1da375b3a98160979fcf81d5e7cad04c7a2ef2f695fad2bb2`. The scoped `fixture-preparation-inventory.json` SHA-256 is `9483a4a6dda5e23007a11ec1e3dd205ae62d4775161bffde469658e99fd04b2b`; it binds source snapshots, recipe, complete source inventories, logs, receipts, outputs and the earlier partial manifest. It is not a full review-ready manifest.

The compile recipe uses Zig 0.16.0 `build-exe`, `-j2`, the original C binding and six static libraries, fixed fc69 production tree and c223 override; exact argv, input hashes and pre/post snapshots are retained in the corresponding `.command.json` and `.json` receipts. Commands and raw terminal results:

```
python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/admission/prepare.py --optimization Debug --output /tmp/uwz-task5b2-debug-v1 --cache-root /tmp/uwz-task5a-debug --record fixture-debug-v1
Exit status: 0
python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/admission/prepare.py --optimization Debug --output /tmp/uwz-task5b2-debug-v2 --cache-root /tmp/uwz-task5a-debug --record fixture-debug-v2
Exit status: 0
python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/admission/prepare.py --optimization ReleaseSafe --output /tmp/uwz-task5b2-release-v2 --cache-root /tmp/uwz-task5a-release --record fixture-release-v2
Exit status: 0
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check .uwz-work/evidence/h2-streaming/integration-owned/admission/profile.zig
(exit 0, no output)
```

The first successful Debug source snapshot is retained before adding aggregate metrics; both final-mode receipts bind the identical final source. Debug binary `/tmp/uwz-task5b2-debug-v2/profile` SHA-256 `c7ba1bd7cb695c1136dec6c2729f692cb71db0fdddcf46e5acdb60af4a743773`; ReleaseSafe binary `/tmp/uwz-task5b2-release-v2/profile` SHA-256 `c72fbf846db238a8a25a5b8a8a4d048dd7f3891c9605b5c346fcf7e33d2539df`. All three compile logs are empty and each receipt reports `inputs_unchanged: true`. No compile failed. The prior-stage pre-check and post-compile audit found zero mismatches in the retained manifest trees and files; counts are 1031 production, 93 override, 42 client, 6/6/5 prior source trees, and 14 zslay files. No production edits occurred.

Self-review: records and slots have distinct lifetime; status finalizes a hash copy; chunk consumes and hashes the offered input; application begin failure acquires no fixture slot; public resume copies its token before invoking it; the middleware appends directly to the response and no end callback fabricates the header. Compiler acceptance does not prove runtime behavior or satisfy independent review. The fixture has not run: no server, client, socket, certificate, native fault probe, full test, or platform/physical gate was executed. Later driver and review must check every selected/unselected record, actual body/hash, final middleware header, refusal/reset ordering, 100 before DATA, quota recovery and post-deinit equality.
