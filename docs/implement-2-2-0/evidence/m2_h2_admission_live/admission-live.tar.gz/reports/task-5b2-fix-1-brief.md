# Task5b2 fix round1: flatten two four-level branches

Read this first with the original brief and current driver report. Same parent
implementer owns the fix; all original ownership/safety constraints apply.

Independent protocol review SPEC/QUALITY PASS, no findings. Process/identity/
bounds/cleanup/snapshot review has no actionable correctness finding, but one
required quality P2 groups two exact convention violations:

- Frozen v1 profile.zig:61 nests path-if -> captured-tag-if -> tag_index-if ->
  index<22-if, four levels on matched body middleware requests.
- Frozen v1 cases.py:103 nests case branch -> route-if -> while -> state-if,
  four levels during observed-limit accepted-prefix polling.

Both violate original StageA brief and CODING_CONVENTION section7.6. Extract
guarded body-head accounting and a focused accepted-prefix polling helper or
use equivalent early returns. Preserve every exact counter/header/byte/control/
status/reset/recovery/selection assertion. No new feature or broad refactor.
Root confirms both actual source sites and accepts this quality finding.

Preserve original combined frozen v1 and manifest50aecbdeed20e1bcb07e0c7e90f00a6eea57882ef4662eb7f3363c07bb06757f,
all partial/fixture reports, source snapshots, binaries, recipes and logs. Prefer
new admission/fix1/ working sources and distinct/tmp fixed frozen package so
old manifest-bound working source paths remain byte-identical. Preserve report
preimages before appending fixes. Do not overwrite existing build records.

Because profile source changes, COMPILE the exact corrected fixture in both
Debug and ReleaseSafe with fixed Zig/-j2 and original immutable production/
override/bindings/libs. Use distinct output/record names and save complete
before/after source/input/binary identities. Do not relabel old binaries as
results for a changed profile. Library/layout/profile capacities remain unchanged.

Cover the amended cases module with the existing meaningful pure ledger checks;
syntax/AST/profile formatting and explicit changed-control-depth inspection are
required. Rerun codec checks only if their code/integration changes; no broad
unrelated test rerun. This is a semantics-preserving control-flow correction:
do not fabricate a behaviorred or add tests mirroring implementation. State
source-only/runtime limits honestly. Preserve existing pure evidence.

No fixture/client/server/socket/certificate/candidate native execution, binary
--help, full native tests, stopped experiments, new fault/cancellation schedule/
race/resource/leak/invalid-fd/kernel-error/injected completion/panic probes.
No production edits, commits/refs/pushes/network downloads/subagents/external CLI.
Local readonly graphify, source edits, actual pure data checks and compile-only
work remain allowed. Heavy outputs/caches/tmp; shared compiler caches valid.

Append the fix report with exact covering file names/commands/raw outcomes and
source/binary/manifest hashes to task-5b2-driver-report.md (preserve preimage);
summarize parent progress without destroying history. Create a full new review
manifest binding corrected frozen sources, both actual builds and unchanged
external inputs/trees. Supply exact v1-to-fix diffs. Return concise status/report/
new manifest and concerns; Root handles scoped re-review before any live release.
