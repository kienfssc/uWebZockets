# Task5b2 next preparation step: fixture and compile-only builds

Read first: this is a smaller continuation of the original task5b2, not reduced
acceptance. Original task-5b2-brief.md and task-5b2-architecture.md remain binding.
The partial wire/observer and pure checks are progress, not a review-ready task.
No environmental blocker was reported; the original combined preparation was
too large for the first turn. Preserve it and finish the next bounded piece.

Own the same new admission directory only. You are not alone; preserve all Root,
other-agent and prior evidence. No subagents, commits, refs, pushes, fetches,
network installs, external model CLI or production changes. Graphify before new
code searches; known frozen production and prior fixture paths may be read.

This step implements ONLY the actual public configured-App fixture and its
compile recipe/receipts, plus an explicit fixture contract for the subsequent
client-driver step. Do not spend this step reworking the completed standalone
wire observer or writing all13 client cases. Do not call the parent task done.

Implement in admission/profile.zig, with one focused fixture-state Zig module
if it earns a concrete storage/lifetime invariant. Reuse the known prepare.py
recipe; fixed Zig0.16, -j2, Debug and ReleaseSafe COMPILE ONLY. Keep heavy binary,
cache and snapshot output under/tmp; existing content-addressed caches may be
shared. Preserve every failed compile and its exact source/input identities.

Use immutable fc69 production/c223 override/original bindings/libs/client/helper
and the exact original eight-connection profile. Use public Server.preset(...)
.build_https, route_body, headers_only middleware and owning-loop get_context
status/resume routes. Do not implement body limits/quota in fixture callbacks:
the real BodyRoute limits must enforce them. Chunk hashes every byte actually
offered/accepted, so an incorrectly delivered offending byte makes the test fail.

Provide the original three route definitions (upload100000000/quota2,
limit32/quota1, empty0/quota1), two reusable sink slots, fixed32-result capacity,
distinct tags for the22 architecture ledger entries and persistent per-record
M/A/B/E/C/F, actual bytes/hash/chunks/span/state/cancelreason/error fields.
Keep records separate from slots and valid through App deinit. Named records
cover all primary/holder/recovery requests; unused selected-case records must
remain observable as untouched. Document treatment of spare capacity explicitly.

Middleware runs once per body head, including the six refused primaries; append
exact X-Middleware: retained through the real Response. Count M separately from
buffered status/health/control middleware traffic. Never synthesize the final
header in end to hide a transport retention failure. The cancellation callback
records actual body_too_large reasons and terminal counters. The one deliberate
application begin failure is on quota-one /limit; record its attempt/failure and
roll back any fixture-side partial reservation, with no accepted binding/cancel.
Only continue_paused binds paused initially. Ordinary others are ready.

Status reports the persistent record with a finalized COPY of hash state. Resume
copies the public token before calling it on the owning loop and accesses only
stable records and its own fresh Response afterward. No callback Request,
StreamingRequest, Response, header-array view or input span is retained. Do not
fabricate a native callback or mutate Session/owner/token internals.

Keep public health, bounded per-record status (<4096), normal setup/listen on
127.0.0.1:28443, existing three cert/key/nonce environment values, shutdown signal
watcher before run, capacity and owned readiness nonce markers. After run/deinit,
emit bounded persistent record data and actual aggregate counters, with errors
and active slots explicit. Fullselection eventually expects22records/M22/A19/
B18/E16/C2/F1/384bytes, not hard-coded observations in the fixture. The client
will derive expectations from the selected cases; the fixture always reports
actual counters. Full record output must stay within65536 bytes.

NO execution of fixture/client/server/socket/certificate/native code, even binary
--help. No full tests, native fault/cancellation schedule/race/resource/leak/
invalid-fd/kernel-error/injected completion/panic probes. Pure formatting, syntax,
AST and compile-only work are allowed. Do not rerun old passing checks unless
their code changes. No Root production pin/adoption or live authorization occurs.

Write admission/fixture-contract.md describing exact routes, tag-to-case/role
map, JSON fields, pause/failure tag policy, middleware counters and post-deinit
markers, so the next driver step has a concrete contract. Preserve the original
partial-manifest/report preimages and bind new fixture sources, both actual
compile commands/results/logs/binaries and before/after inputs in a clearly
scoped fixture preparation inventory (not full review-ready manifest).

Write task-5b2-fixture-report.md with commands/raw results/source/binary hashes
and concerns; append parent progress to task-5b2-report.md without destroying
the incomplete wire-only history. Return scoped fixture-step DONE or concrete
NEEDS_CONTEXT/BLOCKED, with overall parent still incomplete until driver/freeze/
review. Do not stop with another generic partial status if a smaller authorized
action remains; finish this bounded fixture/build step or state the exact blocker.
