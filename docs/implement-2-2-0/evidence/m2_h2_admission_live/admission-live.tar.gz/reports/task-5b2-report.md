# Task 5b2 Stage A: incomplete preparation

Status: INCOMPLETE. This is not a frozen review-ready package and does not authorize execution. Only standalone wire and raw-frame observation plus pure codec checks were prepared. The required application fixture, stable 32-record ledger, 13 selectable cases, process runner, compilation, full input/source binding, and independent review remain outstanding. The nine previously proved IDs and all later 5b/5c cases have not been rerun or reproved here. No production code was changed.

Partial artifacts live under `.uwz-work/evidence/h2-streaming/integration-owned/admission/`. `partial-manifest.json` has SHA-256 `5cd23f37d4c18863c5078ced5aec64c357a95b4e2371c8559aeff23901188f6f`. It is an inventory of incomplete work, not a review manifest. `prior-input-inventory.json` is an exact copy of the prior review manifest, SHA-256 `ca20660a9356b4452bd4a4cede8d4ff4b4851e6ae49d41780d4c6c5d415ed86f`. All listed trees and individual inputs matched before and after; the after result is `input-after.log`: production tree 1031, override 93, client 42, prior frozen trees 6/6/5, zslay 14, zero mismatches.

The partial `raw_observer.py` bounds each input at 8192 bytes and streams at eight, parses frame headers and reset payload incrementally, and rejects early, duplicate, wrong-code, wrong-stream, healthy, and retired-stream resets. `wire.py` checks decoded response status, exactly one retained middleware header, informational status/count, bounded response bytes and raw reset consistency. It is not yet integrated with a runner. In particular, runner-level proof of 100 before request DATA, bounded trailing barriers, event/reset integration in the live driver, request accounting, exact body/hash checks, lifecycle/cleanup invariants, and post-deinit equality are absent. Self-review does not substitute for independent source review.

Pure checks (no optimization mode applies; no fixture, socket, certificate, or native executable ran):

```
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/admission/pure_raw_checks.py
split final and NO_ERROR reset: accepted
early: rejected: reset before final end
duplicate: rejected: duplicate reset
wrong code: rejected: wrong reset code
wrong stream: rejected: reset on unregistered stream
healthy: rejected: reset on healthy stream
retired exception: rejected: reset on unregistered stream
```

```
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/admission/pure_codec_checks.py
split informational and final: accepted
wrong final: rejected: wrong final status
unexpected informational: rejected: extra informational
missing informational: rejected: missing informational
missing middleware: rejected: middleware header
```

Both commands exited 0. Python `ast.parse` accepted all four new Python files. Both outputs are retained in `pure-raw.log` and `pure-codec.log`. Debug and ReleaseSafe compile-only commands were not run because the fixture does not exist. No native, physical, platform, full local matrix, or milestone gate is claimed. The architecture's full expected selection remains 22 records, M22/A19/B18/E16/C2/F1 and 384 accepted bytes; no actual ledger values were measured.

## Fixture preparation continuation

The configured-App fixture and compile-only preparation are now recorded separately in `task-5b2-fixture-report.md`; its source/receipt inventory SHA-256 is `9483a4a6dda5e23007a11ec1e3dd205ae62d4775161bffde469658e99fd04b2b`. Debug and ReleaseSafe builds succeeded without executing either binary. The parent task remains incomplete: the case driver, combined freeze, independent review and authorized live verification are still required. The original wire-only history above and its partial manifest remain unchanged.

## Combined Stage A continuation

The case driver and combined frozen source package are prepared for independent review. See `task-5b2-driver-report.md`; the review manifest SHA-256 is `50aecbdeed20e1bcb07e0c7e90f00a6eea57882ef4662eb7f3363c07bb06757f`. Pure ledger, actual codec and module-binding checks passed; the prior Debug and ReleaseSafe compile-only binaries were verified byte-for-byte. Independent review and separately authorized live acceptance remain outstanding; no milestone or native behavior is claimed as passed.

## Round 1 quality fix

The two control-depth findings were corrected and both corrected fixture modes compiled successfully. See the round 1 section of `task-5b2-driver-report.md`; the new manifest SHA-256 is `b5553efdd08b8cc95f66eb03e00108614dd537811df50f32877010484785baef`. Scoped re-review and separately authorized live acceptance remain outstanding.
