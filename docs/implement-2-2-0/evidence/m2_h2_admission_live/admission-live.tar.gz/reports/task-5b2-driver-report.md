# Task 5b2 driver and combined Stage A

Status: Stage A source preparation complete; **independent review and separately authorized live execution remain outstanding**. The frozen test-only package is `/tmp/uwz-task5b2-combined-frozen-v1`. Its [review manifest](../../..//.uwz-work/evidence/h2-streaming/integration-owned/admission/review-manifest.json) SHA-256 is `50aecbdeed20e1bcb07e0c7e90f00a6eea57882ef4662eb7f3363c07bb06757f`. `ready-for-independent-review` describes source readiness only, not review approval or runtime success. The prior partial and fixture preparation manifests, logs, reports, and binary/source snapshots are preserved.

`run_live.py` retains the explicitly gated process, TLS, identity, output-bound, deadlines, and independent cleanup structure from the reviewed pause runner. It verifies the actual executing runner path/hash and explicitly loads the frozen `raw_observer.py`, `wire.py`, `cases.py`, and original helper by exact path/hash; it checks each loaded module path and the raw observer object used by wire. `cases.py` implements the 13 ledger groups and `shutdown_idle`, rejects unsupported IDs and duplicates, selects independent per-tag expectations, checks all 32 records including the ten untouched spares, and retains refusal records through recovery and same-connection health barriers. After the 32 final status requests, `/metrics` is the final buffered request; every post-deinit record and the aggregate must match those snapshots. The runner compares each successful response record against its terminal status, checks the two simultaneous quota recoveries, waits for 100 before DATA, and verifies both observed-limit and paused barriers. Input and output remain bounded by the existing 8192-byte read/generated-span, 8 response record, 32/4096 header, 16/16384 informational, sub-4096 body, 65536 combined output, and 15/30/900/15-second deadline contracts.

Source self-review checked all 13 groups and six refusal expectations, the all-32 snapshot and unused-record assertions, per-stream expected status/info/reset, raw reset retirement, middleware/header checks, per-case health and recovery, simultaneous quota recovery, 100-before-DATA, stable-token resume, no buffered requests after final metrics, module path/hash checks, output bounds and cleanup. The bounded trailing barrier detects resets received through the subsequent healthy/recovery exchange; it cannot promise future unread frames. Review by another engineer remains necessary.

The final profile and both existing compile-only outputs remain byte-identical to the fixture step: source `96a6c4873181c7e1da375b3a98160979fcf81d5e7cad04c7a2ef2f695fad2bb2`, Debug binary `c7ba1bd7cb695c1136dec6c2729f692cb71db0fdddcf46e5acdb60af4a743773`, ReleaseSafe binary `c72fbf846db238a8a25a5b8a8a4d048dd7f3891c9605b5c346fcf7e33d2539df`. No recompilation occurred. The combined manifest binds both actual compile commands, results, empty logs, source snapshots and input inventories, all prior full production/client/override/zslay inventories, the fixed interpreter, TLS tools/libraries, original binding/six static libraries and custom sources. `freeze_combined.py` verified all before/after bindings and reported:

```
prior inputs and full trees: unchanged
Debug and ReleaseSafe recipes, inputs, logs and binaries: matched
frozen source files: 12
review manifest sha256: 50aecbdeed20e1bcb07e0c7e90f00a6eea57882ef4662eb7f3363c07bb06757f
```

Exact frozen pure commands use `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S` followed by the respective `/tmp/uwz-task5b2-combined-frozen-v1/` script:

```
pure_ledger_checks.py
full ledger M/A/B/E/C/F/bytes: [22, 19, 18, 16, 2, 1, 384]
13 individual subsets and ten spare records: accepted
offending-byte mutation: rejected: record limit_observed_reject field accepted differs
unsupported case: rejected

pure_integration_checks.py
split 413 END_STREAM and NO_ERROR reset: accepted
reset after retirement: rejected: reset on unregistered stream

pure_binding_checks.py
exact custom module path and hash: accepted
wrong module hash: rejected: executing source hash differs
wrong module path: rejected: executing source path differs
```

Each exited 0; outputs are retained as `frozen-ledger.log`, `frozen-integration.log`, and `frozen-binding.log`. Python AST parsing accepted all admission Python files. An inert frozen runner import followed by `check_manifest`, `load_bound` for raw/wire/cases/helper and object identity checks exited 0 with `frozen manifest and executing module identities: matched`. Earlier unchanged pure raw/codec checks and their outputs remain retained. These checks do not simulate socket, status, callback, or completion behavior.

No fixture/client/server/socket/certificate/native executable ran. No full test, physical, platform, protocol compliance or milestone gate is claimed. The parent milestone remains open pending independent review and a precise later owned runtime authorization.

## Round 1 quality fix

The two required control-depth findings are fixed in the separate `admission/fix1/` working copy. `account_body_head` uses guard returns before incrementing the same middleware counter; `wait_accepted_prefix` preserves the same status, pending, accepted-prefix and deadline checks. No case oracle or transport observer was changed. Exact v1-to-fix diffs are retained as `admission/fix1/profile.diff` and `admission/fix1/cases.diff`, SHA-256 `c089341f64191db4fd14c29377fe001eef231f3a3be3e2ac9f9e2844523ca846` and `82ab6f9a3c34083324ee3140f51d73284af51da628be265015e74aa0b0fe9947`. Original report preimages and the v1 source, binary, receipts and manifest remain intact. Corrected source hashes: profile `a9f7149c122939a5a404b20b76733818968379443c4138503112b4cda92f1aa8`; cases `3f4698e51a6b20ed92463a8988852bd8fe781c8ebeea547b03c519a99fceb363`.

Compile-only commands and raw results:

```
python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/admission/fix1/prepare.py --optimization Debug --output /tmp/uwz-task5b2-fix1-debug --cache-root /tmp/uwz-task5a-debug --record fixture-debug-fix1
Exit status: 0
python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/admission/fix1/prepare.py --optimization ReleaseSafe --output /tmp/uwz-task5b2-fix1-release --cache-root /tmp/uwz-task5a-release --record fixture-release-fix1
Exit status: 0
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check .uwz-work/evidence/h2-streaming/integration-owned/admission/fix1/profile.zig
(exit 0, no output)
```

Each compile log is empty, each receipt reports unchanged inputs, and the full exact Zig argv plus before/after tree inventories are retained in `fix1/fixture-debug-fix1*` and `fix1/fixture-release-fix1*`. Debug binary SHA-256 `219190edca37c3d9456d7ad107bf9d35d876a48f77afefb841eaae74b804c1d2`; ReleaseSafe binary SHA-256 `6e172b88be7eeed1a6269d1d866d6fde8e561042fa9f6b9daded5df08eeb0059`.

The existing meaningful ledger check, run with `/home/codespace/.python/current/bin/python3 -B -S` against `fix1/pure_ledger_checks.py` and again against the frozen copy, exited 0 and printed:

```
full ledger M/A/B/E/C/F/bytes: [22, 19, 18, 16, 2, 1, 384]
13 individual subsets and ten spare records: accepted
offending-byte mutation: rejected: record limit_observed_reject field accepted differs
unsupported case: rejected
```

All fix1 Python files parsed with `ast.parse`. Explicit depth inspection reported `wait_accepted_prefix` depth 2 and `execute` depth 3 with Python `elif` normalized as a peer branch; the Zig guard helper and middleware branch each have depth 1. The first exploratory AST traversal reported 7 because it counted chained `elif` AST nodes as nested blocks; its output is retained as `depth-initial.log`, and `depth-check.log` records the normalized inspection. No regression red was fabricated and unchanged wire checks were not rerun.

`fix1/freeze_fix1.py` verified the v1 manifest and all its bound inputs unchanged, both new build receipts and actual binaries, and created `/tmp/uwz-task5b2-fix1-frozen`. The new `fix1/review-manifest.json` SHA-256 is `b5553efdd08b8cc95f66eb03e00108614dd537811df50f32877010484785baef`; a subsequent inert import and full manifest/module-path binding check exited 0 with `fix1 manifest and loaded module identities: matched`. This is ready for scoped re-review, not live approval. No fixture, client, server, socket, certificate or native executable ran, and no full test or protocol gate is claimed.
