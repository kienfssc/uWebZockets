# Task5b2 StageB: owned admission/limits/Continue/quota run

Both independent fix1 re-reviews pass before Root's final audit of122inputs,
nine fulltrees and both actual corrected Debug/RS builds. AuditSHA
92cc14ff911df3094cb9acfb3f24dacbf7c4dc343983f555489ea021cecbe392.
Root precise authorizationSHA25c85504364c591e43277c6485bc2d0f72272029557ad66b95081f3fcc724710
is recorded in admission/fix1/stage-b-authorization.json before execution.

Exact command from /workspaces/uWebZockets:

```sh
env PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5b2-fix1-frozen/run_live.py --run --manifest /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/admission/fix1/review-manifest.json --manifest-sha256 b5553efdd08b8cc95f66eb03e00108614dd537811df50f32877010484785baef --output /tmp/uwz-h2-admission-owned-2026-10-28-r1 --cases empty_headers empty_data empty_declared limit_declared limit_undeclared limit_declared_reject limit_observed_reject zero_declared_reject zero_observed_reject continue_ready continue_paused quota_refuse begin_failure_rollback shutdown_idle
```

Session3690/finalchunkfbc18e/exit0/emptyoutput, no retry or restart. OwnedTLS1.3/h2,
PID/start/nonce/listener/certificate identity, normalSIGTERM/deinit/exit0/reaped,
no forcedcleanup/errors, key removed. Root verifies PID/key absence and repeats
only readonlyinputaudit, yielding byte-identical preflight afterward.

All13 admission IDs plus idle pass. Raw32records and metrics showM22/A19/B18/
E16/C2/F1/accepted384/errors0/active0. Bothcancels body_too_large; limitobserved
accepts32/H32 andzeroobserved accepts0/emptySHA, excludingoffendingx. EachContinue
has one100beforepositiveDATA and no repeated100onresume. Sixprimaries have
413/503 emptybody then one rawNOERROR0 afterfinalEOS; all healthy streamsnoRST.
All22finalbodyresponses retainX-Middleware exactlyonce. Same-route recovery and
two simultaneouslyactivequota2 recoveries pass through actual client assertions.

All32postdeinit rows and finalmetrics equal snapshots. Bufferedmiddleware54
plus bodyheads22 equals76 finalresponses, allended; rawtracealso6reset events/
2informational/70DATA events. WU15 is an observation, not credit-exhaustion proof.
Serverlog11359B under65536bound; key/binaryneverpublished. RawresultSHA
ba7fb2b177531e11802443dffb06b6f36301c8e2b99668bdec1282ecde3e4932;
RootresultauditSHAd48d8c7fad36e2471490adb7c17348af276fff920a7d657a9ffb8b427c65a319.
Copied rawfiles/execution/audit underadmission/stage-b.

Root isolatedASTrefresh11files/129nodes/281edges/10communities exits0 withoutAPI;
main graph unchanged. OneLinuxReleaseSafe application validation run is not
physical/exceptionalcleanup/nativefault/fullquality/platform/M2 proof. No active
publiccancel, kernel/resource/schedulingprobe or stoppedexperiment was requested.
Remaining5b3/5b4/5c/H3/multipart/genuineearlydata/adoption/fullmilestonesstayopen.
