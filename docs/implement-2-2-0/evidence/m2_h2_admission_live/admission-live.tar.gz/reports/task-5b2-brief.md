# Task5b2 StageA: prepare limits/Continue/quota/recovery coverage

Read this first: binding exact requirements for this assignment. Read scoped
task-5b2-architecture.md for the complete13-row request ledger and actual source
ordering references. Do not load/reimplement the entire full plan or old cases.

Own ONLY new .uwz-work/evidence/h2-streaming/integration-owned/admission/ sources,
build/review/pure-check evidence and this task's report. Root HEAD
a6ba97bbd69a6f661b2bba042c5cc9f3a1d7327a is clean/pushed. Core+pause/control
proofs are complete as scoped checkpoints; preserve every prior input/source/
report/manifest/log/binary and public doc. You are not alone: no others' edits,
reverts/subagents/commits/refs/pushes/fetches/downloads/external modelCLI.

Production remains immutable /tmp/uwz-task4d-fix1-frozen,1031files,
fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de.
Use exact reviewed c22393file override, originalr2Cbindings/sixstaticlibs,
42fileclient0f85bd19 and helper07a5201 unchanged. Verify inputs before use; no
completed prerequisite restoration/rebuild/retest while its actual inputs exist.

Same actual configured HTTPS App/route_body/get_context/publiccontrols. Profile:
connections8/streamingtrue/requestline512/header4096/count80/H1body256/H2body4096/
encodedheader8192/responseheader4096/count32/captures24/writequeue65536;
unrelatedfeatures/devlogoff. Previous requeststride5888/H2stride281200/
slab4098304/router884352 remain unchanged; no type/capacity/default relaxation.

Register body definitions /upload/:tag limit100000000/quota2, /limit/:tag
limit32/quota1, /empty/:tag limit0/quota1. Two reusable caller sinkslots;
32fixed persistent requestrecords with distinct known bounded tags, separate
fromslots. Records survive reuse/deinit; no perbody heapallocation or accumulating
body. Overflowfails. No retained callback Request/StreamingRequest/Response,
metadata viewarrays or chunk slices. Copy neededtags/controls/diagnostics into
stable caller storage; status finalizes only a COPY of active hash.

Support unique selectable subsets ending shutdown_idle of these exact IDs:
empty_headers,empty_data,empty_declared,limit_declared,limit_undeclared,
limit_declared_reject,limit_observed_reject,zero_declared_reject,
zero_observed_reject,continue_ready,continue_paused,quota_refuse,
begin_failure_rollback,shutdown_idle. Each case executes its whole ledger group,
including same-route recovery. Unselected records remain untouched; selected
expectations sum exact percase values, not fixedfullorder. Unsupported IDsfail,
never skip. Preserve prior9uniqueproved IDs separately and all remaining5b/5c
IDs as explicit planned/unimplemented; this source does not reprove oldcases.

The architecture table is the exact sequence/oracle. P32 comes from unchanged
helper.payload_block(32,...), independent clientSHA
7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5;
emptySHAe3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855.
Sink computes actual accepted-prefix hash, never expectedconstants. Observed
cap sends P32 then verifies accepted32 through sameconnstatus BEFORE literalx,
withoutEOF; offending byte must not be accepted/hashed. Zero route firstx also
withoutEOF mustcancelwithoutacceptance. Bothreasons body_too_large/noend.

Declaredlimit/zero refused heads useExpect100-continue and openinput/noDATA.
They receive413/no100/no beginattempt. Quota headlength1+Expect receives503/
no100/noattempt while TWO ready holders(length32/noDATA) remainactive. Complete
holders then admit TWO simultaneous recoveryheads before finishingeither;
active2->0->2->0. One recovery is insufficient forquota2. Failedapplicationbegin
on quotaONE/limit length32+Expect returns503/no100/attempt1/failure1/noB/E/C;
fixture rollsbackits partialstate and same-route healthyrecovery succeeds.
Applicationbeginerror and routequota/bodylimit refusals are ordinary API/input
cases, not native cancellation/scheduling/kernel/resource fault probes.

Continue variants length32+Expect: wait exactlyone informational status100 BEFORE
sendingpositiveDATA. Ready completes200/P32; beginpaused receives100whilestill
paused, P32/EOF then sameconnstatus provesaccepted0/chunks0/end0 before public
resume and200/P32. No extra100onresume. No DATA-credit-blocked100claim.

One bounded global authorized headers_onlymiddleware appends exactly
X-Middleware: retained. Record body-head M separately from buffered health/
status/control calls. It runs ONCE for EVERYbodyhead including declared/quota/
beginfailure refusals. Every final200/413/503 must contain that header exactly
once, including observed-limit cancellation; no middleware rerun afterpause/
cancel. Info100musthaveexactstatus100 and mustnotconsume finalmiddlewareheader.
Sourceordering and restoration refs are in architecture; do not guess Request
fields or assert refusedheads bypassmiddleware. Use public accessors.

All13 fullselection:22requestrecords,M22,A19,B18,E16,C2,F1,
accepted384bytes(twelveP32),cancelreasonsbothbody_too_large,active0/errors0.
Selected-subsets use exact ledger-derivedtotals and unused initialrecords.
Postdeinit results must equal predeinit results, not only aggregateactiveflags.
Healthyprogress aftereachcase; idle shutdown only whenstreams/bindingsinactive.

Extend NEW scopedwire/observer rather than edit old reviewed code: explicit
per-stream expected finalstatus/bodylimit/info/resetpolicy. Healthy streams still
forbid ALLrawRST. AllSIXrefusedprimaries require exactlyone rawRSTNO_ERROR0 AFTER
their complete finalEND_STREAM frame; rejectearly/duplicate/wrongcode/wrongstream.
Observe raw9byteheaders/order/RSTpayload with boundedstate independently of h2
events because librarymayignoreclosedresets. Keep records until proper terminal
and recovery/healthy sameconnbarrier; retiringexception restoresdefaultreject.
Do not globallypermit/ignore resets or merely count informational events. Handle
actual StreamReset events consistently with rawobservation withoutdoublecount.
No promise about futureunreadframes; bounded trailingbarrierstatedhonestly.

Preparation MAY run actual pure codec/observer checks with pinnedh2/hyperframe
bytes, no socket: valid expected final+NOERROR accepted; early/duplicate/wrongcode/
wrongstream/healthy resets rejected; final/info expectations; splitheaders/payload
checks meaningful for newboundedrawstate. Preserve genuine failedchecks. Do not
manufacture regressionred by running unsupported oldcases or fake status/socket/
callback/completion; oldpositive-onlywire rejection was intentional, not a bug.

Keep approved process/identity/deadline/cleanup invariants: explicit--run;
exactexecutingrunner/modulepath+hash; Python-B-S/fixedinterpreter/precise
client+helperPYTHONPATH; frozen fullsource/input inventories; own direct PID/start/
nonce/listenerinode beforehealth; TLS1.3/h2 and ownedephemeralcertfingerprint;
127.0.0.1:28443 only; freshprivate/tmp output;15ready/30eachcase/900total/
15graceful absolute deadlines; no retry/fallback. Continuouscombinedoutput65536,
boundedreads/generatedspans8192, responseheaders32/4096, informational16/16384,
responsebody<4096 and bounded stream/event/frame/resultstate. Account for full
postdeinit32record output underlogbound. Independentcleanup/reaping/keydelete;
forced/errorsnever success. Reuse invariants, no genericframework or hiddenstate.
Remove copied unused EXPECTED100M constant from NEW source during this edit;
old retained artifacts remain immutable. Keep modules focused and nesting<=3.

StageA ONLY sourceediting, fixedZig0.16 Debug/ReleaseSafe COMPILE(-j2), profilefmt,
AST/syntax/isolatedgraph and meaningful actualpuredata/codec checks. No fixture/
client/server/socket/certificate/native execution, includingbinary--help; no full
centralruntime, stopped experiments, deniedsocketcases or new native cancellation
schedule/race/fault/resource/leak/invalidfd/kernelerror/injectedcompletion/panic
probes. No productionfixes: reportdefects toowner. Laterindependentsourcereview
and Rootexactordinaryownedauthorization are required before ANYliveacceptance.

Use new/tmp frozen/source/output locations, preserve allintermediate versions,
commands/logs/source/binarybindings. Heavycache/binaries/IR/graphs/tmp; shared
content-addressed compiler cachesallowed. Bind actualbothmodes outputs/recipes,
originalbindings/libs/tools/executables and completed/full inventories; no passed
claim for unrunquality/platform/physical/fullmilestonegates. Ifsource/helperdefs
missing, reportconcretegap rather than silentlyrelaxing requirements.

Report .superpowers/sdd/h2_streaming_plan/task-5b2-report.md with status,
changedpaths/hashes, exactcommands/rawoutcomes, before/afterinputidentity,
supported/plannedcases/recordledger, capacities/bounds and gaps. Self-review
sourcebeforefreeze. Return conciseDONE/etc,reportpath,compile/purechecksummary,
manifestidentity andconcerns. No commits/subagents/runtime authorization.
