"""Freeze reviewed inputs and compile-only preparation, without native execution."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
FROZEN = Path('/tmp/uwz-task5b2-combined-frozen-v1')
NAMES = ('profile.zig', 'prepare.py', 'run_live.py', 'cases.py', 'wire.py', 'raw_observer.py',
         'pure_raw_checks.py', 'pure_codec_checks.py', 'pure_integration_checks.py',
         'pure_ledger_checks.py', 'pure_binding_checks.py', 'fixture-contract.md')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inventory(root):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file()}


def main():
    prior_path = HERE / 'prior-input-inventory.json'
    assert digest(prior_path) == 'ca20660a9356b4452bd4a4cede8d4ff4b4851e6ae49d41780d4c6c5d415ed86f'
    assert digest(HERE / 'fixture-preparation-inventory.json') == '9483a4a6dda5e23007a11ec1e3dd205ae62d4775161bffde469658e99fd04b2b'
    manifest = json.loads(prior_path.read_text())
    for root, wanted in manifest['trees'].items():
        assert inventory(Path(root)) == wanted, root
    for path, wanted in manifest['inputs'].items():
        assert digest(path) == wanted, path
    assert digest(HERE / 'profile.zig') == '96a6c4873181c7e1da375b3a98160979fcf81d5e7cad04c7a2ef2f695fad2bb2'
    for mode, binary in (('debug', '/tmp/uwz-task5b2-debug-v2/profile'), ('release', '/tmp/uwz-task5b2-release-v2/profile')):
        label = 'fixture-' + mode + '-v2'
        record = json.loads((HERE / (label + '.json')).read_text())
        command = json.loads((HERE / (label + '.command.json')).read_text())
        assert record['exit_status'] == 0 and record['inputs_unchanged'] and not (HERE / (label + '.log')).read_bytes()
        assert record['argv'] == command['argv'] and record['input_sha256'] == record['input_after']
        assert record['source_tree_sha256'] == record['source_after_sha256']
        assert record['fixture_before'] == record['fixture_after']
        assert record['fixture_after']['profile.zig'] == digest(HERE / 'profile.zig')
        assert record['fixture_after']['prepare.py'] == digest(HERE / 'prepare.py')
        assert digest(binary) == record['binary_sha256']
        manifest['inputs'][binary] = digest(binary)
        for suffix in ('.json', '.command.json', '.log', '-source-inputs.json', '-source-after.json'):
            path = HERE / (label + suffix)
            manifest['inputs'][str(path)] = digest(path)
    assert not FROZEN.exists()
    FROZEN.mkdir(mode=0o700)
    for name in NAMES:
        shutil.copyfile(HERE / name, FROZEN / name)
    files = inventory(FROZEN)
    assert len(files) == len(NAMES)
    manifest['trees'][str(FROZEN)] = files
    manifest['tree_counts'][str(FROZEN)] = len(files)
    for name, value in files.items(): manifest['inputs'][str(FROZEN / name)] = value
    extras = ('fixture-preparation-inventory.json', 'partial-manifest.json', 'fixture-input-after.json',
              'pure-raw.log', 'pure-codec.log', 'pure-integration.log', 'pure-ledger.log', 'pure-binding.log', 'freeze_combined.py')
    for name in extras: manifest['inputs'][str(HERE / name)] = digest(HERE / name)
    paths = ('/opt/conda/lib/libssl.so.3', '/opt/conda/lib/libcrypto.so.3',
             '/lib/x86_64-linux-gnu/libssl.so.3', '/lib/x86_64-linux-gnu/libcrypto.so.3',
             '/lib/x86_64-linux-gnu/libc.so.6', '/lib/x86_64-linux-gnu/libm.so.6',
             '/lib/x86_64-linux-gnu/libpthread.so.0',
             '/home/codespace/.python/current/lib/python3.14/lib-dynload/_ssl.cpython-314-x86_64-linux-gnu.so')
    for path in paths: manifest['inputs'][path] = digest(path)
    manifest.update(state='ready-for-independent-review', runner=str(FROZEN / 'run_live.py'),
                    wire=str(FROZEN / 'wire.py'), raw=str(FROZEN / 'raw_observer.py'),
                    cases=str(FROZEN / 'cases.py'), binary='/tmp/uwz-task5b2-release-v2/profile',
                    previous_manifest_sha256=digest(prior_path),
                    fixture_preparation_inventory_sha256=digest(HERE / 'fixture-preparation-inventory.json'))
    output = HERE / 'review-manifest.json'
    assert not output.exists()
    output.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    print('prior inputs and full trees: unchanged')
    print('Debug and ReleaseSafe recipes, inputs, logs and binaries: matched')
    print('frozen source files:', len(files))
    print('review manifest sha256:', digest(output))


if __name__ == '__main__':
    main()
