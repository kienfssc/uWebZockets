# Admission fixture contract (compile-only preparation)

The configured HTTPS App uses the eight-connection profile from the parent brief. POST `/upload/:tag` is registered with a real `BodyRoute` limit of 100000000 bytes and quota 2; `/limit/:tag` uses 32 and 1; `/empty/:tag` uses 0 and 1. The fixture does not implement route limits or quota in callbacks. Two slots bind at most two requests; the 32 records have independent persistent storage. Tags are fixed constants and no request, response, metadata view, or input chunk is retained. Spare indices 22–31 are observable through status and post-deinit output, but a body request bearing a spare tag fails closed and records a fixture error.

| Case | Tags, in ledger order |
| --- | --- |
| empty_headers | empty_headers |
| empty_data | empty_data |
| empty_declared | empty_declared |
| limit_declared | limit_declared |
| limit_undeclared | limit_undeclared |
| limit_declared_reject | limit_declared_reject, limit_declared_recovery |
| limit_observed_reject | limit_observed_reject, limit_observed_recovery |
| zero_declared_reject | zero_declared_reject, zero_declared_recovery |
| zero_observed_reject | zero_observed_reject, zero_observed_recovery |
| continue_ready | continue_ready |
| continue_paused | continue_paused |
| quota_refuse | quota_holder_one, quota_holder_two, quota_refuse, quota_recovery_one, quota_recovery_two |
| begin_failure_rollback | begin_failure, begin_recovery |

Only `continue_paused` binds paused. `begin_failure` deliberately returns an application error before acquiring a fixture slot or retaining a token, recording one attempt and failure; it is intended for `/limit`. Other valid tags bind ready. Each chunk hashes and consumes every byte actually delivered; the fixture does not truncate an offending byte. Cancellation records the actual enum reason. Status finalizes a copy of the SHA-256 state and never changes the ongoing hash.

A single global middleware appends `X-Middleware: retained` on the actual response, increments the matched body tag's `middleware` count, and counts other requests separately in `buffered_middleware`. It does not inject or reconstruct the final response header in end. Buffered routes are GET `/health` (`ok`), `/status/:tag` (per-record JSON), `/metrics` (aggregate JSON), and `/resume/:tag` (copies the public control token and resumes on the owning loop; `ok` on success). Response errors increment fixture errors.

Per-record JSON fields: `tag`, `middleware`, `attempts`, `begin`, `end`, `cancel`, `failure`, `accepted`, `sha256`, `chunks`, `max_span`, `active`, `paused`, `reason` (`none` or the actual cancellation enum), `errors`. Aggregate JSON fields: `middleware`, `attempts`, `begin`, `end`, `cancel`, `failure`, `accepted`, `active`, `errors`, `buffered_middleware`, `slot0_active`, `slot1_active`. Record and aggregate formatting use 1024-byte buffers; status is therefore below 4096. Full selection's expected aggregate is M22/A19/B18/E16/C2/F1/accepted384; the fixture derives values from records, never hard-codes that expectation. Untouched records retain zero counters, inactive state, `none`, and the empty hash.

Setup consumes `H2_PROFILE_CERT`, `H2_PROFILE_KEY`, and nonempty `H2_PROFILE_NONCE` of at most 64 bytes; listens only at 127.0.0.1:28443; installs shutdown signal handling before run; emits `H2_CAPACITY`, `H2_READY <nonce>`, then after run and App deinit 32 `H2_RECORD <nonce> <JSON>` and `H2_DEINIT <nonce> <aggregate JSON>` lines. Each formatted JSON is at most 1024 bytes, so these lines with bounded nonce fit the 65536-byte combined-output allowance; other output must still be monitored by the later runner. The driver must snapshot every record before shutdown and compare all post-deinit records, including spare and unselected records, and check aggregate counters and both slots. Runtime behavior is not verified by compiling.
