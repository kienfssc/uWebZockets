"""Check exact module path and digest binding without starting a process."""
import importlib.util
import pathlib
import sys


def main():
    root = pathlib.Path(__file__).resolve().parent
    runner_path = root / 'run_live.py'
    spec = importlib.util.spec_from_file_location('admission_runner_check', runner_path)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    raw_path = str(root / 'raw_observer.py')
    wire_path = str(root / 'wire.py')
    case_path = str(root / 'cases.py')
    inputs = {p: runner.digest(p) for p in (raw_path, wire_path, case_path)}
    raw = runner.load_bound('raw_observer', raw_path, inputs)
    sys.modules['raw_observer'] = raw
    wire = runner.load_bound('admission_wire_check', wire_path, inputs)
    cases = runner.load_bound('admission_cases_check', case_path, inputs)
    assert wire.raw_observer is raw and len(cases.CASES) == 14
    print('exact custom module path and hash: accepted')
    bad = dict(inputs)
    bad[raw_path] = '0' * 64
    try:
        runner.load_bound('bad_raw', raw_path, bad)
    except RuntimeError as error:
        print('wrong module hash: rejected:', error)
    else:
        raise AssertionError('wrong hash accepted')
    try:
        runner.checked_path(wire_path, raw_path, inputs)
    except RuntimeError as error:
        print('wrong module path: rejected:', error)
    else:
        raise AssertionError('wrong path accepted')


if __name__ == '__main__':
    main()
