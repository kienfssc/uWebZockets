"""Freeze the scoped control-flow correction with complete input bindings."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / 'review-manifest.json'
FROZEN = Path('/tmp/uwz-task5b2-fix1-frozen')
NAMES = ('profile.zig', 'prepare.py', 'run_live.py', 'cases.py', 'wire.py', 'raw_observer.py',
         'pure_raw_checks.py', 'pure_codec_checks.py', 'pure_integration_checks.py',
         'pure_ledger_checks.py', 'pure_binding_checks.py', 'fixture-contract.md')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inventory(root):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file()}


def main():
    assert digest(PRIOR) == '50aecbdeed20e1bcb07e0c7e90f00a6eea57882ef4662eb7f3363c07bb06757f'
    manifest = json.loads(PRIOR.read_text())
    for root, expected in manifest['trees'].items():
        assert inventory(Path(root)) == expected, root
    for path, expected in manifest['inputs'].items():
        assert digest(path) == expected, path
    old = Path('/tmp/uwz-task5b2-combined-frozen-v1')
    for name in NAMES:
        if name not in ('profile.zig', 'cases.py'):
            assert digest(HERE / name) == digest(old / name), name
    assert digest(HERE / 'profile.zig') == digest(Path('/tmp/uwz-task5b2-fix1-source-v1/profile.zig'))
    assert digest(HERE / 'cases.py') == digest(Path('/tmp/uwz-task5b2-fix1-source-v1/cases.py'))
    for mode, binary in (('debug', '/tmp/uwz-task5b2-fix1-debug/profile'), ('release', '/tmp/uwz-task5b2-fix1-release/profile')):
        label = 'fixture-' + mode + '-fix1'
        record = json.loads((HERE / (label + '.json')).read_text())
        command = json.loads((HERE / (label + '.command.json')).read_text())
        assert record['exit_status'] == 0 and record['inputs_unchanged'] and not (HERE / (label + '.log')).read_bytes()
        assert record['argv'] == command['argv'] and record['input_sha256'] == record['input_after']
        assert record['source_tree_sha256'] == record['source_after_sha256']
        assert record['fixture_before'] == record['fixture_after']
        assert record['fixture_after']['profile.zig'] == digest(HERE / 'profile.zig')
        assert record['fixture_after']['prepare.py'] == digest(HERE / 'prepare.py')
        assert digest(binary) == record['binary_sha256']
        manifest['inputs'][binary] = digest(binary)
        for suffix in ('.json', '.command.json', '.log', '-source-inputs.json', '-source-after.json'):
            path = HERE / (label + suffix)
            manifest['inputs'][str(path)] = digest(path)
    assert not FROZEN.exists()
    FROZEN.mkdir(mode=0o700)
    for name in NAMES: shutil.copyfile(HERE / name, FROZEN / name)
    files = inventory(FROZEN)
    assert len(files) == len(NAMES)
    manifest['trees'][str(FROZEN)] = files
    manifest['tree_counts'][str(FROZEN)] = len(files)
    for name, value in files.items(): manifest['inputs'][str(FROZEN / name)] = value
    for name in ('profile.diff', 'cases.diff', 'pure-ledger.log', 'depth-check.log', 'depth-initial.log',
                 'driver-report-preimage.md', 'parent-report-preimage.md', 'freeze_fix1.py'):
        manifest['inputs'][str(HERE / name)] = digest(HERE / name)
    manifest['inputs'][str(PRIOR)] = digest(PRIOR)
    manifest.update(state='ready-for-independent-review', runner=str(FROZEN / 'run_live.py'),
                    wire=str(FROZEN / 'wire.py'), raw=str(FROZEN / 'raw_observer.py'),
                    cases=str(FROZEN / 'cases.py'), binary='/tmp/uwz-task5b2-fix1-release/profile',
                    prior_review_manifest_sha256=digest(PRIOR))
    out = HERE / 'review-manifest.json'
    assert not out.exists()
    out.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    print('v1 manifest and all bound inputs: unchanged')
    print('both corrected compile receipts and binaries: matched')
    print('frozen source files:', len(files))
    print('review manifest sha256:', digest(out))


if __name__ == '__main__':
    main()
