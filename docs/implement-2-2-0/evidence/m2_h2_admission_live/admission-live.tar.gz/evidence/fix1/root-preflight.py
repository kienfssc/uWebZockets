"""Read-only audit of exact reviewed inputs and actual corrected fixture builds."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
MANIFEST_SHA = 'b5553efdd08b8cc95f66eb03e00108614dd537811df50f32877010484785baef'


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as source:
        while block := source.read(1048576):
            value.update(block)
    return value.hexdigest()


def main():
    path = HERE / 'review-manifest.json'
    assert digest(path) == MANIFEST_SHA
    manifest = json.loads(path.read_text())
    assert manifest['runner'] == '/tmp/uwz-task5b2-fix1-frozen/run_live.py'
    assert manifest['binary'] == '/tmp/uwz-task5b2-fix1-release/profile'
    assert manifest['state'] == 'ready-for-independent-review'
    assert digest(PARENT / 'review-manifest.json') == manifest['prior_review_manifest_sha256']
    assert digest(PARENT / 'prior-input-inventory.json') == manifest['previous_manifest_sha256']
    trees = []
    for root, expected in manifest['trees'].items():
        actual = {str(p.relative_to(root)): digest(p) for p in sorted(Path(root).rglob('*')) if p.is_file()}
        assert actual == expected, root
        tree_digest = hashlib.sha256(json.dumps(list(actual.items())).encode()).hexdigest()
        trees.append({'root': root, 'files': len(actual), 'sha256': tree_digest})
        if root == '/tmp/uwz-task4d-fix1-frozen':
            assert tree_digest == manifest['source_tree_digest']
        if root == '/tmp/uwz-h2-client-tooling/packages':
            assert tree_digest == manifest['client_tree_digest']
    for name, expected in manifest['inputs'].items():
        assert digest(name) == expected, name
    frozen = Path(manifest['runner']).parent
    builds = []
    for stem, mode, binary in (
        ('fixture-debug-fix1', 'Debug', '/tmp/uwz-task5b2-fix1-debug/profile'),
        ('fixture-release-fix1', 'ReleaseSafe', manifest['binary']),
    ):
        command_path = HERE / (stem + '.command.json')
        record_path = HERE / (stem + '.json')
        command = json.loads(command_path.read_text())
        record = json.loads(record_path.read_text())
        assert record['exit_status'] == 0 and record['inputs_unchanged']
        assert record['optimization'] == command['optimization'] == mode
        assert record['argv'] == command['argv']
        assert record['source_tree_sha256'] == record['source_after_sha256'] == manifest['source_tree_digest']
        assert record['input_sha256'] == record['input_after'] == command['input_sha256']
        for name, expected in record['input_sha256'].items():
            assert digest(name) == expected, name
        for name, expected in record['fixture_before'].items():
            assert digest(frozen / name) == expected, name
        assert record['fixture_before'] == record['fixture_after']
        assert record['override_before'] == record['override_after']
        assert digest(binary) == record['binary_sha256']
        assert (HERE / (stem + '.log')).read_bytes() == b''
        builds.append({'mode': mode, 'binary': binary, 'sha256': digest(binary),
                       'command_sha256': digest(command_path), 'record_sha256': digest(record_path)})
    names = ['profile.diff', 'cases.diff', 'frozen-ledger.log', 'depth-check.log',
             'review-process.md', 'review-protocol.md']
    evidence = {name: digest(HERE / name) for name in names}
    report = {'checks_passed': True, 'manifest_sha256': MANIFEST_SHA,
              'input_files': len(manifest['inputs']), 'trees': trees, 'builds': builds,
              'evidence_sha256': evidence, 'runner_sha256': digest(manifest['runner']),
              'scope': 'Reviewed input identities and actual compile receipts only; no runtime or new test execution.'}
    (HERE / 'root-preflight-audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'checks_passed': True, 'inputs': report['input_files'],
                      'tree_counts': [x['files'] for x in trees],
                      'build_modes': [x['mode'] for x in builds],
                      'audit_sha256': digest(HERE / 'root-preflight-audit.json')}))


if __name__ == '__main__':
    main()
