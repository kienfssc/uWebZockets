# Task 5b2 driver and combined Stage A

Status: Stage A source preparation complete; **independent review and separately authorized live execution remain outstanding**. The frozen test-only package is `/tmp/uwz-task5b2-combined-frozen-v1`. Its [review manifest](../../..//.uwz-work/evidence/h2-streaming/integration-owned/admission/review-manifest.json) SHA-256 is `50aecbdeed20e1bcb07e0c7e90f00a6eea57882ef4662eb7f3363c07bb06757f`. `ready-for-independent-review` describes source readiness only, not review approval or runtime success. The prior partial and fixture preparation manifests, logs, reports, and binary/source snapshots are preserved.

`run_live.py` retains the explicitly gated process, TLS, identity, output-bound, deadlines, and independent cleanup structure from the reviewed pause runner. It verifies the actual executing runner path/hash and explicitly loads the frozen `raw_observer.py`, `wire.py`, `cases.py`, and original helper by exact path/hash; it checks each loaded module path and the raw observer object used by wire. `cases.py` implements the 13 ledger groups and `shutdown_idle`, rejects unsupported IDs and duplicates, selects independent per-tag expectations, checks all 32 records including the ten untouched spares, and retains refusal records through recovery and same-connection health barriers. After the 32 final status requests, `/metrics` is the final buffered request; every post-deinit record and the aggregate must match those snapshots. The runner compares each successful response record against its terminal status, checks the two simultaneous quota recoveries, waits for 100 before DATA, and verifies both observed-limit and paused barriers. Input and output remain bounded by the existing 8192-byte read/generated-span, 8 response record, 32/4096 header, 16/16384 informational, sub-4096 body, 65536 combined output, and 15/30/900/15-second deadline contracts.

Source self-review checked all 13 groups and six refusal expectations, the all-32 snapshot and unused-record assertions, per-stream expected status/info/reset, raw reset retirement, middleware/header checks, per-case health and recovery, simultaneous quota recovery, 100-before-DATA, stable-token resume, no buffered requests after final metrics, module path/hash checks, output bounds and cleanup. The bounded trailing barrier detects resets received through the subsequent healthy/recovery exchange; it cannot promise future unread frames. Review by another engineer remains necessary.

The final profile and both existing compile-only outputs remain byte-identical to the fixture step: source `96a6c4873181c7e1da375b3a98160979fcf81d5e7cad04c7a2ef2f695fad2bb2`, Debug binary `c7ba1bd7cb695c1136dec6c2729f692cb71db0fdddcf46e5acdb60af4a743773`, ReleaseSafe binary `c72fbf846db238a8a25a5b8a8a4d048dd7f3891c9605b5c346fcf7e33d2539df`. No recompilation occurred. The combined manifest binds both actual compile commands, results, empty logs, source snapshots and input inventories, all prior full production/client/override/zslay inventories, the fixed interpreter, TLS tools/libraries, original binding/six static libraries and custom sources. `freeze_combined.py` verified all before/after bindings and reported:

```
prior inputs and full trees: unchanged
Debug and ReleaseSafe recipes, inputs, logs and binaries: matched
frozen source files: 12
review manifest sha256: 50aecbdeed20e1bcb07e0c7e90f00a6eea57882ef4662eb7f3363c07bb06757f
```

Exact frozen pure commands use `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S` followed by the respective `/tmp/uwz-task5b2-combined-frozen-v1/` script:

```
pure_ledger_checks.py
full ledger M/A/B/E/C/F/bytes: [22, 19, 18, 16, 2, 1, 384]
13 individual subsets and ten spare records: accepted
offending-byte mutation: rejected: record limit_observed_reject field accepted differs
unsupported case: rejected

pure_integration_checks.py
split 413 END_STREAM and NO_ERROR reset: accepted
reset after retirement: rejected: reset on unregistered stream

pure_binding_checks.py
exact custom module path and hash: accepted
wrong module hash: rejected: executing source hash differs
wrong module path: rejected: executing source path differs
```

Each exited 0; outputs are retained as `frozen-ledger.log`, `frozen-integration.log`, and `frozen-binding.log`. Python AST parsing accepted all admission Python files. An inert frozen runner import followed by `check_manifest`, `load_bound` for raw/wire/cases/helper and object identity checks exited 0 with `frozen manifest and executing module identities: matched`. Earlier unchanged pure raw/codec checks and their outputs remain retained. These checks do not simulate socket, status, callback, or completion behavior.

No fixture/client/server/socket/certificate/native executable ran. No full test, physical, platform, protocol compliance or milestone gate is claimed. The parent milestone remains open pending independent review and a precise later owned runtime authorization.
