"""Pure, independent ledger checks; no transport or fixture execution."""
import hashlib
import cases


def main():
    empty = hashlib.sha256(b'').hexdigest()
    p32 = '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5'
    selected = cases.selected_tags(cases.CASES)
    assert len(cases.TAGS) == 32 and len(set(cases.TAGS)) == 32 and len(selected) == 22
    rows = [cases.expected(tag, selected, empty, p32) for tag in cases.TAGS]
    totals = [sum(row[key] for row in rows) for key in ('middleware', 'attempts', 'begin', 'end', 'cancel', 'failure', 'accepted')]
    assert totals == [22, 19, 18, 16, 2, 1, 384], totals
    print('full ledger M/A/B/E/C/F/bytes:', totals)
    per_case = [(1,1,1,1,0,0), (1,1,1,1,0,0), (1,1,1,1,0,0), (1,1,1,1,0,0), (1,1,1,1,0,0), (2,1,1,1,0,0), (2,2,2,1,1,0), (2,1,1,1,0,0), (2,2,2,1,1,0), (1,1,1,1,0,0), (1,1,1,1,0,0), (5,4,4,4,0,0), (2,2,1,1,0,1)]
    for case, wanted in zip(cases.CASES[:-1], per_case, strict=True):
        subset = cases.selected_tags((case, 'shutdown_idle'))
        assert subset == set(cases.GROUPS[case])
        assert not subset.intersection(cases.TAGS[22:])
        selected_rows = [cases.expected(tag, subset, empty, p32) for tag in cases.TAGS]
        actual = tuple(sum(row[key] for row in selected_rows) for key in ('middleware', 'attempts', 'begin', 'end', 'cancel', 'failure'))
        assert actual == wanted, (case, actual, wanted)
    print('13 individual subsets and ten spare records: accepted')
    good = cases.expected('limit_observed_reject', selected, empty, p32)
    good.update(chunks=1, max_span=32)
    cases.verify_record(good, cases.expected('limit_observed_reject', selected, empty, p32))
    good['accepted'] = 33
    try:
        cases.verify_record(good, cases.expected('limit_observed_reject', selected, empty, p32))
    except ValueError as error:
        print('offending-byte mutation: rejected:', error)
    else:
        raise AssertionError('offending byte accepted')
    try:
        cases.selected_tags(('unimplemented', 'shutdown_idle'))
    except KeyError:
        print('unsupported case: rejected')
    else:
        raise AssertionError('unsupported case accepted')


if __name__ == '__main__':
    main()
