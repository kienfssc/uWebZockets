"""Exercise real h2 decoding and raw reset observation together without transport."""
import h2.config
import h2.connection
from hyperframe.frame import RstStreamFrame
import raw_observer
import wire


def main():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    client.initiate_connection()
    server.initiate_connection()
    server.receive_data(client.data_to_send())
    client.receive_data(server.data_to_send())
    client.send_headers(1, [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/')])
    server.receive_data(client.data_to_send())
    records, trace, raw = {}, {}, raw_observer.new_state()
    wire.register(records, raw, 1, 0, 413, 0, True)
    server.send_headers(1, [(':status', '413'), ('x-middleware', 'retained')], end_stream=True)
    reset = RstStreamFrame(1)
    reset.error_code = 0
    data = server.data_to_send() + reset.serialize()
    for byte in data:
        wire.accept(client, bytes([byte]), records, raw, trace)
    wire.complete(records, raw, 1)
    assert records[1]['ended'] and raw['streams'][1]['reset']
    print('split 413 END_STREAM and NO_ERROR reset: accepted')
    wire.retire(records, raw, 1)
    try:
        wire.accept(client, reset.serialize(), records, raw, trace)
    except ValueError as error:
        print('reset after retirement: rejected:', error)
    else:
        raise AssertionError('retired reset accepted')


if __name__ == '__main__':
    main()
