const before = @import("before");
const after = @import("after");

comptime {
    same_layout(before.UDP.State, after.UDP.State);
    same_layout(before.Dynamic.UDP.State, after.Dynamic.UDP.State);
    same_layout(before.Completion, after.Completion);
    same_layout(before.Dynamic.Completion, after.Dynamic.Completion);
}

fn same_layout(comptime Old: type, comptime New: type) void {
    if (@sizeOf(Old) != @sizeOf(New)) @compileError("size changed");
    if (@alignOf(Old) != @alignOf(New)) @compileError("alignment changed");
}

fn Consumer(comptime api: type) type {
    return struct {
        const ReadCallback = *const fn (?*void, *api.Loop, *api.Completion, *api.UDP.State, @import("std").Io.net.IpAddress, api.UDP, api.ReadBuffer, api.ReadError!usize) api.CallbackAction;

        fn callback(_: ?*void, _: *api.Loop, _: *api.Completion, _: *api.UDP.State, _: @import("std").Io.net.IpAddress, _: api.UDP, _: api.ReadBuffer, _: api.ReadError!usize) api.CallbackAction {
            return .disarm;
        }

        fn read(socket: *const api.UDP, loop: *api.Loop, completion: *api.Completion, state: *api.UDP.State, buffer: *[32]u8) void {
            const cb: ReadCallback = callback;
            socket.read(loop, completion, state, .{ .slice = buffer }, void, null, cb);
        }
    };
}

export fn before_read(socket: *const before.UDP, loop: *before.Loop, completion: *before.Completion, state: *before.UDP.State, buffer: *[32]u8) void {
    Consumer(before).read(socket, loop, completion, state, buffer);
}
export fn after_read(socket: *const after.UDP, loop: *after.Loop, completion: *after.Completion, state: *after.UDP.State, buffer: *[32]u8) void {
    Consumer(after).read(socket, loop, completion, state, buffer);
}
export fn before_dynamic_read(socket: *const before.Dynamic.UDP, loop: *before.Dynamic.Loop, completion: *before.Dynamic.Completion, state: *before.Dynamic.UDP.State, buffer: *[32]u8) void {
    Consumer(before.Dynamic).read(socket, loop, completion, state, buffer);
}
export fn after_dynamic_read(socket: *const after.Dynamic.UDP, loop: *after.Dynamic.Loop, completion: *after.Dynamic.Completion, state: *after.Dynamic.UDP.State, buffer: *[32]u8) void {
    Consumer(after.Dynamic).read(socket, loop, completion, state, buffer);
}
