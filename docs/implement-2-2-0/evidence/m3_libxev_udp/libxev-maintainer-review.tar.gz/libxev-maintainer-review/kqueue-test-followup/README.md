# Test-only kqueue contract followup

Local append commit `c546997cfb1bb30babdd467aaf86a2437d9d57da` has parent
`1b6c8ee4521e8073c066ef1265730d54a9b70a98` and tree `c538d2d66a688732bdbd417a2aef0207370cacb7`.
The original peer-fix commit, original branch and immutable artifacts remain
preserved. Production UDP watcher and epoll bytes are unchanged by this append.

The original new test and its review incorrectly treated kqueue cancellation
like epoll abandonment. Source tracing confirms that kqueue schedules deletion,
synthesizes Canceled and dispatches the target callback; an already-queued result
is preserved. This two-line append moves kqueue into the existing one-callback,
Canceled-result and deterministic-error-peer assertion branch. Epoll remains in
the zero-read-callback branch.

Fresh independent reviewer `/root/m3_bounded_source_review` found no actionable
issues in the hash-matched two-line patch. UDP ReleaseSafe tests compile for
arm64 macOS, x86_64 FreeBSD and x86_64 Windows GNU; formatter passed. Exact argv,
source hashes, logs and statuses are retained here. No extra runtime tests were
executed, and native foreign behavior remains unverified. Do not describe the
original foreign fixture as runtime-validated.

`candidate.json` records artifact hashes. `libxev-peer-corrected.bundle` verifies
and records complete history. This is a local review candidate only, with no
published branch, new authoritative pin, root manifest change or remote mutation.
The separate epoll queued-cancel audit is not part of this append.
