# Local maintained-libxev UDP candidate

This draft is local only. It is based on the maintained `uwz/zig-0.16` commit
`c49f6dfb83038c146232472c063e4b2681d098d8`. No root source, manifest, package
cache source, vendor source, overlay, upstream contribution, remote branch,
pull request, or published pin was changed. The earlier stopped standalone
fault/crash experiment remains stopped and was not reconstructed or rerun.

## Contract and scope

A successful UDP read preserves the received peer address. An error callback,
including a canceled receive where the backend delivers a callback, receives
`std.Io.net.IpAddress{ .ip4 = .unspecified(0) }` (IPv4 0.0.0.0:0), independently
of socket family. That sentinel has no datagram identity. The original read
error and callback signature are unchanged. No sockaddr bytes are read on
an error result. All three concrete wrappers are guarded: sendmsg/recvmsg
(io_uring and epoll), sendto/recvfrom (kqueue), and IOCP recvfrom. Dynamic UDP
already forwards the typed address and error from its selected concrete backend.
No state or completion field was added, removed, or changed.

Readiness backends epoll and kqueue intentionally disarm canceled fd reads
without the target read callback; the candidate preserves that behavior.
The new cancellation test initially expected a callback for epoll. The source
review corrected that test assumption; the failing 35/36 log remains retained.
Linux backends currently map a valid empty UDP datagram to `error.EOF`; the
candidate preserves that mapping. A valid empty datagram tests the error-peer
contract in addition to a pending-read cancellation, without invalid descriptors,
resource exhaustion, injected completion results, or deliberate crash behavior.

## Red and ordinary lifecycle evidence

The existing ordinary root transport regression failed at the pinned watcher
peer conversion with exit 134. The original raw log, source hashes, and finding
are retained under `red/`. This is the accepted red evidence; the old-pin crash
was not rerun. The exact retained centralized startup/immediate-shutdown case
passes against the candidate using legitimate direct module substitution,
with both epoll and io_uring selected and asserted by the transport owner.
The retained required test plus separate successful datagram each pass (2/2 per
backend). The complete focused application suite passes 14/14 in Debug and
ReleaseSafe on explicitly selected io_uring. Its final commands, logs, statuses,
and full-SHA bindings are copied under `green/transport/`; final test and core
source copies are under `green/application-final/`. The original executable
artifacts remain at the transport evidence paths and are SHA256-bound by
`green/transport/manifest-final.json`.
The separate datagram case supplements that required regression.

## Verification on the frozen review tree

- Native Debug UDP: 36/36 passed (`native-udp-r2.log`).
- Full native Debug fork suite: 147 passed, 4 existing skips, 151 total
  (`native-full-debug.log`); the final run from initially absent local/global
  caches also passed (`native-full-debug-cold.log`). No existing fork test was changed.
- Native ReleaseSafe UDP: 36/36 passed (`native-udp-release-safe.log`).
- UDP ReleaseSafe tests compile for arm64 macOS, x86_64 Windows GNU, and
  x86_64 FreeBSD (`udp-test-compile-*.log`); these are compile-only results.
- The same explicitly typed callback consumer compiles against the original pin
  and candidate on x86_64 Linux GNU, arm64 macOS, x86_64 Windows GNU, and
  x86_64 FreeBSD. Comptime checks compare size and alignment of static and
  dynamic UDP state and completions. Output objects and exact argv are retained.
- Formatter and staged diff whitespace checks passed for changed fork files.
- The initial sandboxed UDP run was denied io_uring/socket access; that raw log
  is retained separately. Subsequent authorized runs use real localhost sockets.

## Separate source-bound IPv6 finding

`src/backend/kqueue.zig:1692-1693` and `src/backend/iocp.zig:1336-1337` in the
parent store recvfrom peer output in `posix.sockaddr`, with its size as the
provided capacity. A full IPv6 sockaddr is larger. The unchanged success
conversion subsequently attempts to interpret IPv6 peer storage. This is a
pre-existing source-bound peer-capacity problem, not a validated runtime
finding in this work. No deliberate failure experiment was run for it.

The candidate does not change storage/layout to address that separate problem.
New tests exercise IPv4/IPv6 error-peer semantics and native Linux successful
IPv4/IPv6 peers. Foreign successful-peer tests assert IPv4 only, with the reason
explicit in source; no existing test was skipped or weakened. This work claims
no macOS, Windows, or FreeBSD IPv6 successful-peer runtime coverage or fix.
That gap needs separate bounded review and native platform verification before
any broader IPv6 claim or layout change.

## Separate source-bound epoll cleanup caveat

UDP.read sets `flags.dup` for epoll. Its `fd_maybe_dup` creates the duplicate
(`src/backend/epoll.zig:1127-1131`). Normal dispatch disarm closes that duplicate
(`:489-509`), while `stop_completion` deregisters the fd and marks the operation
dead without an equivalent duplicate close (`:870-925`). This is a pre-existing
source-bound potential cleanup gap, outside the peer-decoding fix. No descriptor
count experiment or validated fd-leak claim was made. The current cancellation
checks prove completion drain and user-owned socket close, not absence of every
backend-owned descriptor leak. It needs separate triage and bounded review.

## Provenance and supply-chain review

Before choosing the base, the live maintained integration tip was fetched and
compared with the parent pin: identical, so the additional integration range is
empty. Maintained `main` and upstream `main` both resolve to
`451a2bc03644c2b70fb28a808313d12989bfa8e3`. Their common ancestor with integration
is Zig-0.16-compatible `9ce8e8e6ff89e583258a7f8e7adeeeaeae8611bf`. The integration
range is recorded in `source-review-2.log`; no upstream merge was proposed or
built. Full hashes and observations are retained in `provenance.json` and
`source-review-*.log`.

The entire candidate delta is one UDP watcher file plus one new test file.
Build scripts, workflows, manifests, submodules, binaries, licenses, TLS, and
network syscall policy are unchanged. The production delta adds error-result
branches and a deterministic typed value; it allocates no memory, performs no
extra I/O, and does not change storage ownership, successful receive decoding,
or completion ordering. Tests use owned localhost sockets and close them.
No performance improvement, benchmark result, sanitizer coverage, or foreign
runtime coverage is claimed.

Read-only branch-protection API queries for maintained `main` and
`uwz/zig-0.16` returned HTTP 403 (`Resource not accessible by integration`).
The current credential cannot independently confirm protection. Raw JSON,
stderr, exit status, and commands are retained. Maintainer confirmation of
active mirror/integration protection remains required before publication.
No mirror sync or remote mutation was attempted.

## Proposed ledger entry

`XEV-006` is unused in the current project ledger and is a proposal only.

- Area: UDP receive error peer.
- Upstream reference: None (downstream ordinary startup/shutdown regression).
- Invariant: Failed receive callbacks never interpret uninitialized peer storage;
  they retain the original read error and receive documented IPv4 0.0.0.0:0.
- Test evidence: ordinary transport startup/immediate shutdown exit 134 at parent,
  exit 0 on local candidate; fork cancellation/empty-datagram error-peer and
  successful-peer cases; native suites and cross-target callback/layout checks.
- Retirement criterion: the integration base contains equivalent guarded peer
  decoding and a defined compatible error-peer callback contract.

A fresh independent read-only review found no actionable issues; its runtime and
evidence limits are retained in `independent-review.md`. The unchanged reviewed
tree is committed locally as `1b6c8ee4521e8073c066ef1265730d54a9b70a98`.
Publication, integration-branch review, all four root dependency surfaces,
license/migration/changelog entries, and root integration gates remain later
maintainer work. There is no active new pin and no publication claim.
