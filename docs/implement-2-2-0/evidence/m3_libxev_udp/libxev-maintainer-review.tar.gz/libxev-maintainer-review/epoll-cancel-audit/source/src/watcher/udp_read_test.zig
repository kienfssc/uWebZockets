const std = @import("std");
const builtin = @import("builtin");
const xev = @import("../main.zig");
const xev_posix = @import("../posix.zig");
const net = xev_posix.net;

test "UDP: io_uring canceled read and successful peer" {
    if (builtin.os.tag != .linux) return;
    try read_cases(xev.IO_Uring);
}

test "UDP: epoll canceled read and successful peer" {
    if (builtin.os.tag != .linux) return;
    try read_cases(xev.Epoll);
}

test "UDP: kqueue canceled read and successful peer" {
    switch (builtin.os.tag) {
        .macos, .ios, .visionos, .freebsd => try read_cases(xev.Kqueue),
        else => {},
    }
}

test "UDP: IOCP canceled read and successful peer" {
    if (builtin.os.tag != .windows) return;
    try read_cases(xev.IOCP);
}

fn read_cases(comptime api: type) !void {
    inline for (.{ "127.0.0.1", "::1" }) |ip| {
        const address = try std.Io.net.IpAddress.parse(ip, 0);
        try canceled_read(api, address);
        // recvfrom backends currently provide only sockaddr-sized peer storage.
        if (builtin.os.tag == .linux or address == .ip4) try datagram_read(api, address, "peer");
        // Linux backends currently report a valid empty datagram as EOF.
        if (builtin.os.tag == .linux) try datagram_read(api, address, "");
    }
}

fn ReadObservation(comptime api: type) type {
    return struct {
        calls: usize = 0,
        peer: ?std.Io.net.IpAddress = null,
        result: ?(api.ReadError!usize) = null,

        fn callback(
            userdata: ?*@This(),
            _: *api.Loop,
            _: *api.Completion,
            _: *api.UDP.State,
            peer: std.Io.net.IpAddress,
            _: api.UDP,
            _: api.ReadBuffer,
            result: api.ReadError!usize,
        ) api.CallbackAction {
            const observation = userdata.?;
            observation.calls += 1;
            observation.peer = peer;
            observation.result = result;
            return .disarm;
        }
    };
}

fn canceled_read(comptime api: type, address: std.Io.net.IpAddress) !void {
    var loop = try api.Loop.init(.{});
    defer loop.deinit();
    const socket = try api.UDP.init(address);
    defer close_socket(socket.fd);
    try socket.bind(address);

    var completion: api.Completion = undefined;
    var state: api.UDP.State = undefined;
    var buffer: [32]u8 = undefined;
    var observation: ReadObservation(api) = .{};
    socket.read(&loop, &completion, &state, .{ .slice = &buffer }, ReadObservation(api), &observation, ReadObservation(api).callback);
    // Submit the ordinary pending read before requesting cancellation on IOCP.
    try loop.run(.no_wait);
    try std.testing.expectEqual(@as(usize, 0), observation.calls);

    var cancel_completion: api.Completion = .{ .op = .{ .cancel = .{ .c = &completion } } };
    loop.add(&cancel_completion);
    try loop.run(.until_done);
    switch (api.backend) {
        // Readiness backends remove the pending fd operation without a callback.
        .epoll, .kqueue => {
            try std.testing.expectEqual(@as(usize, 0), observation.calls);
            try std.testing.expect(observation.result == null);
            try std.testing.expect(observation.peer == null);
        },
        else => {
            try std.testing.expectEqual(@as(usize, 1), observation.calls);
            try std.testing.expectError(error.Canceled, observation.result.?);
            try std.testing.expectEqualDeep(std.Io.net.IpAddress{ .ip4 = .unspecified(0) }, observation.peer.?);
        },
    }
    try std.testing.expectEqual(.dead, completion.state());
    try std.testing.expectEqual(.dead, cancel_completion.state());
}

fn datagram_read(comptime api: type, address: std.Io.net.IpAddress, payload: []const u8) !void {
    var loop = try api.Loop.init(.{});
    defer loop.deinit();
    const server = try api.UDP.init(address);
    defer close_socket(server.fd);
    try server.bind(address);
    const client = try api.UDP.init(address);
    defer close_socket(client.fd);
    try client.bind(address);
    const server_address = try socket_address(server.fd, address);
    const client_address = try socket_address(client.fd, address);

    var completion: api.Completion = undefined;
    var state: api.UDP.State = undefined;
    var buffer: [32]u8 = undefined;
    var observation: ReadObservation(api) = .{};
    server.read(&loop, &completion, &state, .{ .slice = &buffer }, ReadObservation(api), &observation, ReadObservation(api).callback);

    var write_completion: api.Completion = undefined;
    var write_state: api.UDP.State = undefined;
    var write_result: ?(api.WriteError!usize) = null;
    client.write(&loop, &write_completion, &write_state, server_address, .{ .slice = payload }, ?(api.WriteError!usize), &write_result, (struct {
        fn callback(userdata: ?*?(api.WriteError!usize), _: *api.Loop, _: *api.Completion, _: *api.UDP.State, _: api.UDP, _: api.WriteBuffer, result: api.WriteError!usize) api.CallbackAction {
            userdata.?.* = result;
            return .disarm;
        }
    }).callback);

    try loop.run(.until_done);
    try std.testing.expectEqual(payload.len, try write_result.?);
    try std.testing.expectEqual(@as(usize, 1), observation.calls);
    if (payload.len == 0) {
        try std.testing.expectError(error.EOF, observation.result.?);
        try std.testing.expectEqualDeep(std.Io.net.IpAddress{ .ip4 = .unspecified(0) }, observation.peer.?);
    } else {
        try std.testing.expectEqual(payload.len, try observation.result.?);
        try std.testing.expectEqualSlices(u8, payload, buffer[0..payload.len]);
        try std.testing.expectEqualDeep(client_address, observation.peer.?);
    }
    try std.testing.expectEqual(.dead, completion.state());
    try std.testing.expectEqual(.dead, write_completion.state());
}

const Socket = if (builtin.os.tag == .windows) @import("../windows.zig").HANDLE else std.posix.socket_t;

fn close_socket(socket: Socket) void {
    if (builtin.os.tag == .windows) {
        const windows = @import("../windows.zig");
        std.debug.assert(windows.ws2_32.closesocket(@ptrCast(socket)) == 0);
        return;
    }
    xev_posix.close(socket);
}

fn socket_address(socket: Socket, address: std.Io.net.IpAddress) !std.Io.net.IpAddress {
    var storage = net.Address.fromIpAddress(address);
    if (builtin.os.tag == .windows) {
        const windows = @import("../windows.zig");
        var length: i32 = @intCast(storage.getOsSockLen());
        if (windows.ws2_32.getsockname(@ptrCast(socket), &storage.any, &length) != 0) return error.GetSockNameFailed;
    } else {
        var length = storage.getOsSockLen();
        try xev_posix.getsockname(socket, &storage.any, &length);
    }
    return storage.toIpAddress();
}
