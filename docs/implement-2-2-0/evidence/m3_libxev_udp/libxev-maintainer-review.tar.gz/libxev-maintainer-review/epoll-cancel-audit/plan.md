# Source-only epoll queued-cancel audit and bounded plan

Status: proposed; no epoll implementation or test execution authorized yet.
Source commit: `1b6c8ee4521e8073c066ef1265730d54a9b70a98`.
Source tree: `ac7368e905ab34da6432a7e6e2d124e4045f00c1`.
Exact source bytes and hashes are retained in `source/` and
`source-manifest.json`. The reviewed peer candidate and immutable artifacts are
unchanged. This is a source counterexample analysis, not an executed failure.
The stopped standalone experiment was not reconstructed or rerun.

## Finding and narrow remedy

`Loop.start` handles `.cancel` by checking the canceller's `.adding` state
(`epoll.zig:570-584`), then unconditionally calls `stop_completion(target)`.
That state says nothing about the target. An ordinary timer callback can queue
cancel(B) (`:416-439`), after which the same tick can dispatch ready B
(`:474-518`). B becomes private `.dead` before its callback (`:491`); a disarming
callback returns, the saved registration is deleted, any saved duplicate is
closed, and the active count is decremented (`:489-512`). The next tick processes
the queued cancel (`:371-394`) and currently attempts another CTL_DEL on B's
stale descriptor (`:870-879`). No syscall is required to establish this source
counterexample.

Recommend a private **dead-target decision before stop_completion**. For a
private `.dead` non-timer target return existing `error.NotFound` through the
normal cancel result path; do not read its fd or mutate the target. For a
private `.dead` timer return successful acknowledgement directly, without
calling stop_completion. The timer exception preserves the existing
`epoll: canceling a completed operation` test (`:2075-2133`), which explicitly
expects success after timer expiration (`:2121`). A universal dead->NotFound
change would break that existing contract and test. No AlreadyCompleted error
exists or is needed: `CancelError` already contains NotFound (`:1373-1375`).

The optional private helper proposed for source review is the actual production
decision, e.g. a typed `dead_cancel_result(Completion.State, OperationType)`
returning `?(CancelError!void)`: null for every non-dead state, success for a dead
timer, NotFound for other dead targets. The cancel branch uses this helper
before fd access. It reads only the defined state and operation tag of a retained
completion, never result storage, fd payloads, queue links or registration data.
No public signature, error tag, structure field, storage size or queue phase is
changed. This helper earns its boundary by centralizing the private-state
predicate used by production and the permitted pure tests.

This is deliberately **not** a generic adding/deleting/thread-pool cancellation
repair. Its acceptance contract is the source-proven ordinary non-thread-pool
fd watcher path where B was queued before its cancellation, is retained without
repurposing through ACK, and has no explicit delete pending. Root must confirm
these H1 preconditions separately before using this narrow remedy for retirement.

## State and queue distinctions

| Target condition when cancel starts | Existing representation | Narrow decision / obligation |
| --- | --- | --- |
| Queued for initial submission | private `.adding`; active count 0; submission node still owned by queue | Leave unchanged, no generic correctness claim. No successful retirement ACK may be inferred just from public `.active`. An immediate mark-dead ACK would still leave a queue pointer to drain. |
| Registered non-thread-pool fd watcher | private `.active`, fd operation, `threadpool=false`; active count owns 1 | Existing stop removes registration and decrements once, marks dead, abandons the target callback. Canceller is a separate queued completion. |
| Kernel readiness fetched into current `events[]`, callback not dispatched | private `.active`; original registration still exists | There is no epoll completion/result queue for this path. Queuing cancel does not remove or overwrite an already-fetched callback. Cancel starts only at a later submission phase, after the previous tick's batch has drained. |
| Already-dispatched fd target returning `.disarm` | private `.dead`; the previous tick's frame has completed DEL/duplicate close/count decrement before next cancel starts | Return NotFound without stop/DEL, target callback, target mutation, duplicate close, or target count change. |
| Prior target callback returned `.rearm` | private `.active`; same registration remains | Not a dead target; leave existing registered cancellation path. The already-delivered callback remains delivered exactly once. |
| Explicit delete pending | private `.deleting`; state no longer records prior active/adding distinction; deletion queue still owns pointer | Leave unchanged, no generic retirement claim. There are separate membership/count obligations; widening this fix to delete would need its own design. |
| Running or completed-but-MPSC-queued worker task | private `.active`, `threadpool=true`; `task_result` is only valid after worker completion | Not an epoll registration. The narrow dead guard does not claim to cancel this. Existing cancel checks the canceller's threadpool bit rather than the target's (`:571`), so generic worker cancellation remains separately unsafe/unproven. Do not inspect task_result to guess readiness. |
| Expired/dispatched timer | private `.dead`; heap ownership already removed and active count already decremented (`:421-428`) | Preserve success ACK, no second heap removal or target callback/count change. |

`Completion.state()` collapses `.adding`, `.deleting` and private `.active` into
public `.active` (`:996-1001`); it is not a registration test. Even private
`.active` alone is insufficient because `thread_schedule` sets it and increments
active for worker work (`:527-540`). Its worker can queue a result while keeping
that state (`:545-555`), and dispatch pops it and decrements before invoking the
callback (`:441-458`).

## Callback, ACK and active-count proof for the reported path

1. The submission queue is snapshotted before timers/events (`:371-374`). A timer
   callback's newly added cancel is in `self.submissions`, not the current local
   snapshot. `add` does not increment active (`:182-199`).
2. The ready target can still dispatch in the same tick. The target's state is
   dead before its callback, but registration/dup cleanup uses saved locals after
   it returns (`:489-512`). Nested `tick`/run is rejected (`:340-343`), so the
   pending cancel cannot start inside that cleanup interval.
3. A disarming target's active count is decremented exactly once by that frame.
   The queued cancel keeps `done()` false via pending submissions even if active
   becomes zero (`:159-162`).
4. Next tick's cancel sees the target's private dead state. The proposed result
   reaches the existing `res_` path (`:839-856`): the canceller is marked dead and
   its callback runs once. Neither target nor canceller adds/subtracts active on
   this result-only path. No stale target descriptor is read or deleted.
5. NotFound **does not suppress or satisfy a pending target callback**. The guard
   applies only to already-dead targets. Ready-but-undispatched fd targets and
   queued worker results remain non-dead, so the guard returns null and does not
   rewrite/drop their result or callback. In the reported disarm path the target
   callback has already run before NotFound. Root must retain its separate target
   callback flag and ACK-frame flag; NotFound alone must not clear a still-true
   target-callback lifetime flag. Any such combination remains held/unproven.
6. B's storage, operation tag and callback state must remain valid and not be
   repurposed until cancellation ACK. Root already requires that pin. Callback
   Action.disarm's general permission to free memory (`loop.zig:75-82`) cannot
   release an object still borrowed by an outstanding cancel. ACK callback entry
   also does not retire the ACK callback's own frame; its caller-owned frame pin
   remains separate until return.

The reported duplicate descriptor is closed by normal disarm before this stale
cancel would start, and the guard never closes it again. Existing successful
cancellation of an active duplicated operation deregisters but does not close
that duplicate; that separately recorded cleanup gap is unchanged. No runtime
leak evidence or complete physical-close claim follows from this plan.

## Minimal edit scope and verification proposal

After root accepts this bounded plan:

1. Change only `src/backend/epoll.zig`: add the private typed decision helper,
   call it before target stop/fd access, and add a concise contract comment.
   Keep adding/deleting/threadpool paths outside the claim; do not change queues,
   registration accounting, descriptors, root flags or package sources.
2. Add pure tests of that **actual helper** in the same fork file: dead fd ->
   NotFound; dead timer -> success; active/adding/deleting -> no early decision,
   including the active row that represents a result waiting for dispatch. These
   tests use plain enum values, no loop, fd, syscall, injected result, allocation,
   resource exhaustion, native race setup or deliberately failing execution.
3. Review the bounded diff and source proof independently before execution.
4. Run only approved pure tests and unchanged existing healthy fork suites,
   plus compile/source-compatibility checks. Preserve the completed-timer test
   unchanged. No new targeted cancellation/interleaving/fault/crash test is
   proposed or authorized. No old-pin crash run, overlay, root pin or remote
   mutation occurs.

The remaining H1 physical-close proof stays held until root reconciles this
contract and the separate ownership/retirement obligations.

## Separate peer-test contract correction

The prior peer-candidate test incorrectly grouped kqueue cancellation with epoll
abandonment. On kqueue, active registered cancellation schedules a deleting
submission (`kqueue.zig:938-954`); submit synthesizes Canceled and queues the
target result (`:204-212`); normal completion dispatch delivers that target once
(`:435-459`). A result already queued is retained by `stop_completion` (`:940-944`).
The acknowledged source contract therefore requires one Canceled target callback
for the normal pending kqueue read, retaining the deterministic error peer.

Root has separately authorized a test-only append correction. It will remove
kqueue from the zero-callback branch of `udp_read_test.zig:84-95`, keep epoll
unchanged, and undergo bounded re-review/foreign compilation. This audit does
not rewrite peer commit 1b6 or claim foreign native validation.
