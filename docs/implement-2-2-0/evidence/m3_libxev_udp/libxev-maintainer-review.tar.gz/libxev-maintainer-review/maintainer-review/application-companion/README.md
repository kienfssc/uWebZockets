# Recorded application outcomes companion

This directory contains the finalized transport manifest (SHA256
19addc6e9b3a47b91dc884db90597ab92bd94e0fa961c89c522d242c52f23b52), every
file named by its artifact_sha256 map, and its fourteen final application source
snapshots. All referenced bytes were checked against that manifest before copy.
The two source entries historically referenced through the application clone
are supplied at their exact relative manifest paths from the frozen snapshot.
No binary was executed while preparing this companion.

The manifest's epoll/io_uring UDP pair logs each report two passes and print the
asserted backend for both the retained ordinary immediate-shutdown regression
and the separate successful-datagram case. Full focused Debug and ReleaseSafe
logs each report fourteen passes. These outcomes bind original peer candidate
1b6c8ee4521e8073c066ef1265730d54a9b70a98 and its frozen production sources.
They do not execute the later epoll stale-cancel counterexample or prove an H1
physical-close implementation. Native foreign runtime remains unverified.

The original ordinary R2 exit-134 log/status and exact failing source binding are
retained separately under ../../red/. Historical green manifests remain
unchanged under ../../green/. Their artifact keys resolve to this companion;
source-path-map.json records original locations and the explicit package map.
The original peer fork source archive and full tracked-source manifest are
included here too. The top-level package inventory hashes all companion files.
