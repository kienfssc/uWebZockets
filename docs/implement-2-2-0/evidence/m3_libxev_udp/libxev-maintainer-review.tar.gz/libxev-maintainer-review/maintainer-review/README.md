# Local maintained-libxev review package

Final local candidate: `7b7b1f14518d9504b15590d123ec494b8fadb2e3`.
Tree: `0ae835a79eaea49f8ff086e64d777152c454b928`.
Maintained integration parent: `c49f6dfb83038c146232472c063e4b2681d098d8`.
No candidate is published or authoritative. Root manifests and package sources
remain unchanged. This package supports maintainer review and a manual append
through the maintained fork's protected integration process.

## Commit chain and scope

1. `1b6c8ee4521e8073c066ef1265730d54a9b70a98`: guard all three UDP receive
   wrappers before peer decoding on error. Preserve the original read error,
   callback signatures and layouts; define the error peer as IPv4 0.0.0.0:0.
   Successful peer decoding is unchanged.
2. `c546997cfb1bb30babdd467aaf86a2437d9d57da`: two-line test-only correction.
   The original new test and review contract wrongly grouped kqueue cancellation
   with epoll abandonment. Kqueue delivers the queued Canceled target callback;
   the correction puts it in the existing callback/result/error-peer assertions.
   Production source is unchanged by this append. Original commit, branch,
   review, raw evidence and artifact archive remain preserved as historical
   evidence. Do not describe the original foreign fixture as runtime-validated.
3. `7b7b1f14518d9504b15590d123ec494b8fadb2e3`: private typed dead-cancel decision and two pure enum
   tests in epoll.zig. A retained ordinary non-timer target already dead when a
   queued cancel starts returns existing NotFound before stale fd access. A dead
   timer still acknowledges success, preserving its unchanged existing test.
   Active/adding/deleting behavior, public error tags, callback signatures,
   layouts, queue phases and duplicate cleanup are unchanged.

`combined.patch` carries all three auditable append commits. The complete-history
bundle is `../epoll-dead-cancel-candidate/libxev-peer-deadguard.bundle` and records
all candidate branches plus the maintained parent. Individual patches, source
archives and reviewed source manifests are retained in their evidence folders.
`candidate.json` maps production hashes at the maintained parent, original peer
fix, corrected peer fix and final candidate.

## Review and verification

The peer patch received independent review and normal application verification.
The retained ordinary startup/immediate-shutdown test first failed at the old pin
with exit 134; its original log and exact source bindings remain retained. It
was not rerun. Against the peer production fix, the required regression and
separate healthy datagram case passed 2/2 on asserted epoll and 2/2 on io_uring.
Focused application suites passed 14/14 in Debug and ReleaseSafe on io_uring.
Those runs bind peer production bytes; they do not verify a new physical-close
algorithm or execute the source-only epoll race counterexample.

Fresh bounded reviewer `/root/m3_bounded_source_review` found no actionable
issues in the exact two-line kqueue correction and epoll source plan, then in
the exact epoll implementation patch and typed contract before execution. The
prior reviewer contract mistake is explicit in the test followup's review record.
Historical pre-verification metadata correctly records the state at that time;
this final summary and candidate.json describe the completed local append.

All approved final checks pass:

- The two actual pure decision-helper tests pass. Zig's filtered command also
  includes 26 existing anonymous discovery tests, for 28/28 total.
- Unchanged healthy fork suites pass in Debug and ReleaseSafe: 149 passes,
  four existing skips, 153 total each. Build steps ran serially with -j2.
- Existing typed callback and state/completion layout consumers compile against
  original pin and final candidate for native Linux, arm64 macOS, x86_64 Windows
  GNU and x86_64 FreeBSD.
- Existing UDP tests compile in ReleaseSafe for macOS, Windows and FreeBSD.
  These are foreign compile results, not native foreign runtime coverage.
- Formatting and staged whitespace checks pass. Each final run's before/after
  source hashes match the independently reviewed tree. The working tree is clean
  and the complete-history bundle verifies.

Exact commands, raw logs, statuses and source hashes are under
`../epoll-dead-cancel-candidate/verification/`. Reviews, contracts and source
archives are in that parent directory and the other candidate folders. Original
failure and passing ordinary application evidence are under `../red/` and
`../green/`. Historical sandbox and test-assumption failures remain preserved.

## Self-contained recorded application outcomes

`recorded-outcomes.json` identifies the original ordinary R2 exit-134 log,
status and frozen source binding under `red/`, and the candidate rerun artifacts.
`application-companion/` contains every artifact named by the finalized transport
manifest, including matching binaries, commands, logs, statuses and fourteen
application source snapshots. Its inventory was validated before copy; no rerun
or binary execution occurred during packaging. Both asserted-backend UDP pair
runs report 2/2. Historical manifests are preserved unchanged, with an explicit
path map into the companion. This evidence records healthy peer-fix behavior;
it does not execute the later stale-cancel race or prove physical close.

## Remaining caveats

The epoll counterexample is source-bound: a timer can queue cancellation, the
same tick can dispatch and disarm the ready target, and the next tick previously
attempted a stale descriptor deletion before ACK. No native race/crash repro was
executed. Verification uses the actual pure helper and unchanged healthy suites.
No new targeted native cancellation/interleaving/fault/race/crash/leak probe,
invalid fd, resource exhaustion or injected result was added or run. The stopped
earlier standalone experiment remains stopped.

The remedy covers ordinary retained non-threadpool watchers. Target memory and
operation tag must remain valid without repurposing through ACK. NotFound never
drops or satisfies a pending target callback; H1 must retain separate target
callback and ACK-frame lifetime flags through their respective returns. Public
state.active is not a registration test. Generic adding/deleting/threadpool
cancellation remains outside this change.

Separate source-noted gaps remain: successful epoll cancellation may retain its
duplicate descriptor, and kqueue/IOCP peer storage has insufficient capacity for
a full IPv6 peer. No runtime leak evidence, foreign IPv6 success fix, complete
generic cancellation proof or H1 physical-close proof is claimed. The physical
close algorithm remains held pending its own design and verification. Native
foreign runtime and root integration/release gates remain required before
broader claims or adoption.

## Provenance and maintainer handoff

Before the original base choice, maintained uwz/zig-0.16 matched parent
c49f6dfb83038c146232472c063e4b2681d098d8. Maintained main and upstream main both
resolved to 451a2bc03644c2b70fb28a808313d12989bfa8e3; the compatible ancestor is
9ce8e8e6ff89e583258a7f8e7adeeeaeae8611bf. These are timestamped observations,
not a guarantee that remote tips cannot move. No mirror was built or pinned,
no upstream contribution was made and no remote mutation occurred.

Protection queries for maintained main and uwz/zig-0.16 returned HTTP 403 with
this credential. A maintainer must confirm required protections and current
integration ancestry before publishing through the protected sync/PR process.
Do not pin an unpublished local commit. Root adoption must update all four
dependency views, canonical ledger, migration/changelog and required gates
together. Proposed IDs are XEV-006 for peer handling (with its test correction)
and XEV-007 for the bounded dead-target decision; no canonical row was edited.
