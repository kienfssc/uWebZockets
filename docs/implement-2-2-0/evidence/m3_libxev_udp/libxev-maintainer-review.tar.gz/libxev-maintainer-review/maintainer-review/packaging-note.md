The first production-hash inventory attempt requested the new UDP test file at
parent c49f6dfb83038c146232472c063e4b2681d098d8, where that file does not exist.
Git returned status 128 for that historical path and the packaging script
stopped. No source or test failure occurred. The corrected inventory separates
production files from the new fixture and records null for the absent parent
fixture. Approved verification results and candidate source bytes are unchanged.
