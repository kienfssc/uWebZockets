# Required UDP immediate-shutdown regression: pinned error-peer conversion

One ordinary owned startup/shutdown test failed with exit 134 in
`focus-runtime.log`; the original test and exact source inputs are frozen under
`unexpected-udp-shutdown/`. It is retained as the required centralized regression
`loop handle transport: UDP startup immediate shutdown drains`. It has not been
rerun after the failure. The distinct success-datagram test is additional
coverage and does not satisfy or replace this regression.

The stopped earlier standalone cancellation fault/crash experiment remains
stopped. This was not that experiment: the test used the public transport
init/start_on_loop/shutdown/run sequence, real owned sockets, fixed inline state,
no fault injection, private fields, resource exhaustion or deliberate crash.

## Source binding and observed evidence

Application base: `00c85640de26823f02a9c5d1fb82ccecb832aea4`.
libxev pin: `c49f6dfb83038c146232472c063e4b2681d098d8`.
Frozen hashes: `unexpected-udp-shutdown/sources.json`.

The native run selected io_uring. Its stack reaches
`watcher/udp.zig:555`, `posix.zig:71`, through `io_uring.Completion.invoke`.
The panic is the unreachable branch of converting a sockaddr whose family is
neither AF_INET nor AF_INET6. The run did not record the CQE numeric result;
the exact cancellation/close error is therefore not asserted from the log.
No IoFailureFence failure path ran: this is a watcher callback panic, not a
returned public loop.run/submit error.

## Source cause and baseline comparison

In pinned `watcher/udp.zig`, UDPSendMsg.State.recv.addr_buffer defaults to
undefined (`:421`). UDP.read resets its operation to undefined and reconstructs
the receive state without initializing addr_buffer (`:508-525`). It passes that
storage to recvmsg, which supplies a peer address on a successful datagram read.
The completion wrapper unconditionally converts addr_buffer to IpAddress when
constructing callback arguments (`:555`), before delivering the result error
(`:558`). Error completions do not establish a valid peer-address family.
`posix.zig:59-71` requires a valid IP family and otherwise reaches unreachable.
io_uring converts negative read results, including cancellation, into a normal
ReadError (`io_uring.zig:711`, `:833`) before entering that wrapper.

R2's UDP diff only factors the unchanged start body into start_bound, retains
an optional LoopHandle, and guards the existing submit-before-cancel call site.
It changes no read/cancel/close order, callback or read-state setup. Legacy
baseline start(raw) and new start_on_loop(handle) both reach the same unchanged
watcher read implementation before the same shutdown sequence. On io_uring
there is no submit-before-cancel branch in this shutdown path, so the new
guarded submit method cannot cause this conversion. No baseline crash execution
was needed or performed for this source comparison.

The address-conversion-on-error is thus a pre-existing pinned dependency defect
exposed by a valid ordinary lifecycle test. The new wrapper association does
not introduce the unsafe conversion. This statement is source-bound; it does
not claim a baseline runtime result or validated fd leak.

## Required next action and acceptance boundary

There is no valid public transport-state initialization fix: UDP.read overwrites
the supplied opaque State internally. Preinitializing a fake address in transport
storage, editing private watcher/backend state, omitting the regression, or
waiting for a successful datagram would not fix its error path. No such change
is proposed.

The maintained libxev fork needs an explicit compatible error-peer contract and
a wrapper change that never interprets uninitialized peer storage on a failed
receive. Root must route and review that dependency change under the maintained
fork policy, update all authoritative pins together, and then rerun the ordinary
required regression and platform gates. This author made no dependency source,
pin, overlay or fetch-tree changes. Until that happens, R2's full healthy
startup/shutdown acceptance remains unsatisfied; separate passing tests cannot
be reported as a passing full R2 suite.
