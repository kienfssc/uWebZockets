# Epoll dead-target cancellation review contract

This uncommitted candidate is based on corrected peer candidate
`c546997cfb1bb30babdd467aaf86a2437d9d57da`, tree `c538d2d66a688732bdbd417a2aef0207370cacb7`.
The frozen review tree is `0ae835a79eaea49f8ff086e64d777152c454b928`.
The source-only plan accepted by root is
`../epoll-cancel-audit/plan.md` (SHA256
`9f952798fca15cfdc61cde9887fb9b1e3cf9e0a47872f1501f363c06458b6ea1`).

## Exact changed behavior

The actual private typed helper is:

`dead_cancel_result(Completion.State, OperationType) ?(CancelError!void)`.

| Private target state and operation | Helper result | Production effect |
| --- | --- | --- |
| dead, timer | present successful result | Acknowledge completed timer directly, preserving the unchanged completed-timer test; no target stop or callback. |
| dead, ordinary non-timer operation | present existing NotFound error | Deliver cancel acknowledgement without reading fd storage, invoking stop_completion, touching target state/callback, deleting registration, closing duplicate or changing target active count. |
| active, adding or deleting | null | No early decision; existing behavior is unchanged. |

The cancel path retains its existing canceller threadpool check and prohibition
on cancelling a cancellation. It invokes this helper after that validation and
before target stop/fd access. It still uses the existing synchronous result
path to mark the canceller dead and deliver its callback exactly once. No
public signature, error tag, field, storage layout, queue, registration
accounting or target descriptor behavior is changed outside the dead decision.

Two new tests call this actual helper with plain enum values. They check dead
read/poll/recvmsg NotFound, dead timer success, and null decisions for
active/adding/deleting read and timer states. They do not create loops, sockets,
fd values, results, native interleavings or deliberately failing executions.
No test has been compiled or executed for this candidate. Only source formatter
and staged whitespace checks have run. Root requires independent review before
any test execution or candidate commit.

## Bounded lifetime and state contract

The claim covers ordinary retained non-threadpool fd watchers, queued before
their cancel, with no repurposing or pending explicit delete before ACK. The
target's memory and operation tag remain valid through ACK. A ready target may
still dispatch in the same tick after cancel is queued; the cancel cannot
start until the next submission phase. If the callback returned disarm, its
saved registration/duplicate/count cleanup has finished before that phase.
The new decision therefore avoids the stale second deletion without another
target callback or count decrement.

An active target, including a ready event awaiting dispatch or a worker result
awaiting its callback, does not hit the dead guard. NotFound never drops a
queued callback or independently satisfies a pending target-callback lifetime
flag. H1 must retain separate target-callback and ACK-frame flags, including
the ACK callback frame until return. The guard's null result must not be read
as a generic cancellation proof for active/adding/deleting/threadpool work.
Public state.active is not a registration test.

Adding, deleting and threadpool cancellation design gaps remain outside this
change. The separately source-noted duplicate-fd cleanup gap is unchanged.
This candidate does not prove generic cancellation, descriptor-leak freedom,
or the full H1 physical-close algorithm. That algorithm remains held.

## Preservation and review boundary

Original peer candidate 1b6, its original branch, archive, bundle, raw evidence
and mistaken reviewer contract record remain preserved. Corrected test-only
append c546 has separate evidence and compile-only foreign claims. The epoll
candidate changes only `src/backend/epoll.zig` and remains uncommitted on a third
local branch. It has no root source, dependency pin, package-source edit,
overlay, remote publication or upstream mutation.

The source counterexample is not an executed failure. The earlier stopped
standalone cancellation fault/crash experiment remains stopped. No new targeted
native cancellation/interleaving/fault/race/crash test, invalid descriptor,
resource exhaustion or injected result is authorized or proposed.
