# Fresh V4 source review, 2026-10-27

Reviewer /root/review_h1_retirement_v4, read-only.

P1: POSIX stream close uses the thread pool. epoll thread_perform publishes c,
then reads c.task_loop (immutable7b7:578; reviewed294:644); Darwin kqueue:1004
has the same problem. The consumer can release/reuse the close completion before
that read. Capture loop/queue first and never access completion/task/node after
publication. ThreadPool.run has no later task access; R2 joins the pool before
loop deinit. Root and architect accept the bounded source correction.

P2: epoll recv duplicates before ADD (reviewed294:835-841); failed ADD dispatches
the target dead (935-952) without closing its new duplicate. Cancellation's
registered-active cleanup cannot repair that dead target. Require actual new-
duplicate rollback on failed ADD before permitting the normal close/reuse proof.
Root and architect accept the shared acquisition-to-ADD transaction.

No source changed, builds/tests/probes ran, or native timing was measured during
review. V4 remains historical; V5 is conditional on separately reviewed backend
corrections and another fresh design review. No native fault experiment follows.
