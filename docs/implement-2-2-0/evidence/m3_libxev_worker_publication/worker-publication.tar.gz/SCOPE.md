# Reviewed worker-publication candidate

Local append179f22bc539548e024407b76d4aa39c54342e5b4, parentb2afbafa6900d147ea0dea56e33b612b18f278d4,
treeafb88b35febd1d2e0de8d2802d1f3e2f8adceb38, changes only two worker functions.
Required metadata is captured before publication. Result writes precede push;
no completion/task/node is accessed afterward. Wakeup failures use scoped warnings.
Captured loop lifetime relies on the separately reviewed R2 pool-join-before-loop-deinit contract.
No state, API, layout, allocation, test or wakeup retry was introduced.

Independent source review finds no actionable findings. Existing healthy Debug
and ReleaseSafe each155pass/4skip/159total; Darwin/FreeBSD UDP graphs compile only.
The complete-history bundle restores exact commit/tree into an empty repository
with strict fsck. Retained source and raw checks are not a native race proof.
R3V5 inputs are conditional proposals, not accepted or implemented lifetime code.
Registration rollback, general H1 retirement and maintained adoption remain open.
No stopped experiment, native fault/race/cancellation/leak probe or foreign run occurred.
