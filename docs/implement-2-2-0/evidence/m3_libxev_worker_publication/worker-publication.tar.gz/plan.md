# Accepted bounded worker-publication correction

Architect /root/architect_iocp_cancel_result, read-only followup, 2026-10-27.
Root accepts the two-function correction after saving the independently reviewed
IOCP candidate. Capture loop and epoll queue before publication; result writes
precede push. Thereafter do not access completion, task or node storage. Preserve
loop wakeup order/no retry. Existing empty catches must receive a defensible
best-effort rationale or scoped diagnostics. No state, API, layout or abstraction.

MPSC push finishes node access at publication; ThreadPool.run does not touch the
task after callback return. R2 joins the pool before loop destruction, keeping
the captured loop valid. This establishes storage reuse, not worker return.

Acceptance: exact scoped source diff, independent source review, unchanged
healthy Debug/ReleaseSafe suites, compile-only Darwin and non-Darwin kqueue UDP
graphs, frozen hashes and raw commands. Do not add an artificial pure policy
test for local pointer captures. No native race/fault/cancellation/leak experiment.

Separate prerequisite after this candidate is saved: new-duplicate rollback on
failed epoll ADD using a stack acquisition record and a real shared ADD helper;
actual pure take/ownership tests, no kernel-error injection. R3V5 remains pending.
Maintained publication, fork protections and root adoption remain separate gates.
