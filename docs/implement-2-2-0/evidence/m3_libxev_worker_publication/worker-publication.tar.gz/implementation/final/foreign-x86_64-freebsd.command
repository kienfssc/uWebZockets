cwd: /workspaces/uWebZockets/.uwz-work/drafts/libxev-udp-fix
command: env ZIG_GLOBAL_CACHE_DIR=/workspaces/uWebZockets/.uwz-work/evidence/libxev-udp-fix/cache-global /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig test src/main.zig -OReleaseSafe --test-filter UDP: -target x86_64-freebsd -fno-emit-bin --cache-dir .zig-cache -lc
