cwd: /workspaces/uWebZockets/.uwz-work/drafts/libxev-udp-fix
command: git diff --check
