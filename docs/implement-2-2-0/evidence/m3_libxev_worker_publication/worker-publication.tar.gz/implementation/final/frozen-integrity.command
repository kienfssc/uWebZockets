cwd: /workspaces/uWebZockets/.uwz-work/drafts/libxev-udp-fix
command: sha256sum --check /workspaces/uWebZockets/.uwz-work/evidence/worker-publication/implementation/final/frozen-source.sha256
