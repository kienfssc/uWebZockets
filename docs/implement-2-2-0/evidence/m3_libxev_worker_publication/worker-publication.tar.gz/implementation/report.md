# Worker completion publication repair

The two owned source functions are frozen for independent review. No staging,
commits, refs, publication, dependency pins, root source, or root documentation
were changed.

## Scope and source identity

Clone: `/workspaces/uWebZockets/.uwz-work/drafts/libxev-udp-fix`.
Base commit: `b2afbafa6900d147ea0dea56e33b612b18f278d4`.
Base tree: `512dbee775106f1a84d14715a0ce4cf85f47dceb`.
The initial clone status was clean.

Only `src/backend/epoll.zig::Loop.thread_perform` and
`src/backend/kqueue.zig::Loop.thread_perform` changed:

- Epoll captures both `c.task_loop` and `c.task_completions` before performing
  the operation and publishing its result. Publication uses the captured
  queue. The subsequent wakeup uses the captured loop.
- Kqueue captures `c.task_loop` before performing and publishing. Publication
  and the existing Darwin-only wakeup use the captured loop. The non-Darwin
  branch still performs no wakeup.
- Both previous empty wakeup error handlers now emit scoped warnings. Wakeup
  attempts, ordering, retry behavior, and return behavior are preserved. The
  diagnostic does not claim that a lost wakeup is harmless or undo publication.

There is no completion, task, or node access after the queue `push` in either
callback. No wrapper, state field, interface, layout, allocation, or test was
added. Operation/result writes still precede publication. This is the bounded
capture correction approved in the architect contract, with source review and
unchanged healthy verification rather than an artificial interleaving test.

| Source | Base SHA256 | Frozen SHA256 |
| --- | --- | --- |
| `src/backend/epoll.zig` | `6c0423ad7161c435f30b84fefd57853246657a4bd21accdaceedf6689e966bc9` | `9632deefd24f4f3b9c2b36b41a87f4519e0fdb635d37fa3ca88566c0563ff6e6` |
| `src/backend/kqueue.zig` | `e9d1928433c34b25f96c2f1f1f141b807d7928e3e33bec2386c12773bcddaaae` | `5ab8d1cf8b6a834e5884f8f5ece53b11b04fb136e46ee3be72a4bde865f44650` |

Complete diff: `final/complete.diff`, SHA256
`625433066c0218fa832be9b57d2ebf3220474c05b0b246f63328e8239ee7c82b`.
Before/after full source snapshots are under `base/` and `final/`.
The source manifests also retain hashes for the unchanged IOCP repair,
ThreadPool, MPSC queue, main test root, build file, C exports and C header.

## Source proof and lifetime assumption

The MPSC queue's final `push` statement publishes through a release atomic
store (`src/queue_mpsc.zig:44`). Its consumer may then deliver the callback
and release or reuse the completion before the worker function returns.
Consequently, capturing the loop after `push` is already too late.

Both callbacks now acquire all completion-owned metadata before that boundary
and only use the independent loop pointer afterward. `ThreadPool.Thread.run`
does not dereference its task after the callback returns
(`src/ThreadPool.zig:378-385`). Neither support file changed.

The captured loop must outlive all pool workers. The root-supplied R2 contract
joins the pool before loop deinitialization; this slice relies on that
separately reviewed lifetime contract and does not implement or verify R2.

## Validation actually run

All validation ran in the clone using the exact Zig 0.16.0 executable
`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`.
Build-system commands used `-j2`. The existing clone `.zig-cache` and existing
global cache were reused; no toolchain or build script was introduced.

Each record below has raw `.command`, `.log`, and `.status` files under
`final/`. Logs with no output are retained as empty files with exit status 0.

| Record | Command | Outcome |
| --- | --- | --- |
| `fmt` | `zig fmt src/backend/epoll.zig src/backend/kqueue.zig` | Exit 0; no formatter changes |
| `healthy-debug-unrestricted` | `zig build test -j2 --summary all` | Exit 0; 155 pass, 4 existing skips, 159 total |
| `healthy-release-safe-unrestricted` | `zig build test -Doptimize=ReleaseSafe -j2 --summary all` | Exit 0; 155 pass, 4 existing skips, 159 total |
| `foreign-aarch64-macos` | Darwin compile-only command below | Exit 0; no execution |
| `foreign-x86_64-freebsd` | Non-Darwin kqueue compile-only command below | Exit 0; no execution |
| `fmt-check` | `zig fmt --check src/backend/epoll.zig src/backend/kqueue.zig` | Exit 0 |
| `whitespace` | `git diff --check` | Exit 0 |

The healthy suite was unchanged, including the existing IOCP pure classifier
tests. Normal local socket/backend access was requested through the execution
approval mechanism, consistent with the earlier sandbox EPERM evidence. This
slice did not repeat the known restricted-sandbox run, and therefore has no
new sandbox-failure record to mix with the passing runs.

Exact runtime verification commands:

```sh
ZIG_GLOBAL_CACHE_DIR=/workspaces/uWebZockets/.uwz-work/evidence/libxev-udp-fix/cache-global /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build test -j2 --summary all
ZIG_GLOBAL_CACHE_DIR=/workspaces/uWebZockets/.uwz-work/evidence/libxev-udp-fix/cache-global /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build test -Doptimize=ReleaseSafe -j2 --summary all
```

The prior Darwin and FreeBSD compilation records were inspected first and
copied to `base/prior-foreign-*.command.json`. The same compile-only UDP test
graph pattern was used with the established shared caches:

```sh
ZIG_GLOBAL_CACHE_DIR=/workspaces/uWebZockets/.uwz-work/evidence/libxev-udp-fix/cache-global /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig test src/main.zig -OReleaseSafe --test-filter 'UDP:' -target aarch64-macos -fno-emit-bin --cache-dir .zig-cache -lc
ZIG_GLOBAL_CACHE_DIR=/workspaces/uWebZockets/.uwz-work/evidence/libxev-udp-fix/cache-global /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig test src/main.zig -OReleaseSafe --test-filter 'UDP:' -target x86_64-freebsd -fno-emit-bin --cache-dir .zig-cache -lc
```

## Remaining limits

No native foreign execution, race reproduction, new cancellation/interleaving
probe, crash/leak experiment, registration-failure injection, or native fault
test was created or run. The checks above establish normal healthy behavior
and foreign source compilation, not a runtime proof of every interleaving.
Registration rollback and wakeup redesign remain outside scope. Independent
source review is required before any candidate commit. Root retains graph
refresh, integration, root quality gates, publication and pin decisions.
