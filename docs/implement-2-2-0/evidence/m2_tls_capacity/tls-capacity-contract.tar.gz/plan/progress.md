# TLS H1 execution ledger

Plan: .uwz-work/evidence/h1-tls/h1_tls_plan.md.
Root BASE36bf44a; executable baseline acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b.

## Pre-flight scan

| Task pair or self | Shared file/interface | Finding and ruling |
| --- | --- | --- |
| 1 / 2 | tcp_upload/TCP and public fixture | Task2 consumes frozen reviewed Task1 source; no runtime from a moving copy. Root owns combined copy, test imports and actual run. |
| 1 / 2 | metadata and ordinary lifecycle fixtures | Existing plaintext Task3b acceptance precedes reuse in TLS fixtures; implementation itself may proceed in its independent copy. |
| 1 self | ciphertext count versus literal ADR | Architect and independent crypto review prove separate BIO/plaintext bounds; Root explicitly amends ADR before code. No silent reinterpretation or new buffer. |
| 1 self | pure tests versus real SSL/native effects | Caller-owned capacity facts are legitimate pure tests. Real SSL objects/completions are never fabricated; actual TLS effects require owned clients later. |
| 1 self | native lifetime versus TLS activation | Existing accepted pins/ACK/two-stage retirement/claim-close remain. No new discriminator/state/layout or whole V6 redesign. |
| 2 self | runtime tests versus stopped experiment | Ordinary protocol/API/owned shutdown only; no native fault, scheduling, race or injected-completion probes. |
| All | root pins/publication and delivery | Explicit c223 override only. No production adoption until maintained/final gates; Root commits/pushes each verified checkpoint to authorized fork. |

Ruling: Source-backed narrow ciphertext exception is explicitly accepted and
documented in ADR0008 after independent crypto plan approval. Keep positive H1
plaintext/readiness gate separate from encrypted byte count; same BIO and sole
inbound producer preserve the sampled reservation. Implementation review must
verify both actual submission/rearm sites and every TLS drain entry.
Ruling: project AGENTS permits independent tasks in separate copies. Task1 TLS
implementation does not edit the acff baseline being used by plaintext Task3b.
Root owns ADR/docs/shared test registration. No worktree/ref/pin mutation.
Ruling: exact manifest-bound component patches are review artifacts; root Git
diffs contain recovery checkpoints until actual maintained adoption. Preserve
source snapshots durably, not hashes alone. Root is sole committer/pusher.

- [ ] Task1 concrete TLS extraction/activation and independent review.
- [ ] Task2 accepted fixture reuse, combined runtime/review/final evidence.

Plaintext Task3b producer coverage fix round1 is independent and remains open.
No TLS implementation, execution or success is claimed yet.
