## Task 1: Concrete TLS extraction and driver activation

Owner transport_io with crypto_tls guidance. Own only src/core/tcp.zig,
src/core/tcp_upload.zig and existing src/tests/http1_upload_driver_tests.zig in
NEW /tmp copy. Existing test_support export is sufficient. No tests/main edit.

Read the above sources/specs and specialist instructions. Implement actual
plaintext/BIO capacity policies, bounded TLS extraction and real H1 admission,
resume/output-progress continuation and EOF/error mapping. Use genuinely pure
caller-owned policy tests for arithmetic/pause/full/tiny/protocol decisions;
do not fabricate SSL pointers, native completions or execution hooks. Missing
declaration compilation alone is not a behavioral red; preserve actual red/green
for changed policy. Keep all accepted plaintext driver tests and public behavior.

Serialize source edits and compilation; freeze before every check. Preserve
pre/post exact source/override/inputs/compiler/binary/env bindings. Run scoped
fmt/conventions/version, selected CPU Debug+RS, unchanged healthy App/TLS suites
and full central native/macOS/Windows compile. Do not execute the entire isolated
native central suite containing out-of-scope historical fault cases. Source
audit no library allocations/layout changes. Freeze exact patch/snapshots/report
for independent spec+quality+crypto review. No native TLS upload run in component.

