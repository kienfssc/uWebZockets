const std = @import("std");
const candidate = @import("http/parser.zig");
const oracle = @import("http/h1_baseline_oracle.zig");

fn compare_parser(a: candidate.HttpParser, b: oracle.HttpParser) !void {
    inline for (std.meta.fields(candidate.HttpParser)) |field| {
        try std.testing.expectEqual(@offsetOf(candidate.HttpParser, field.name), @offsetOf(oracle.HttpParser, field.name));
        if (comptime std.mem.eql(u8, field.name, "state")) {
            try std.testing.expectEqual(@intFromEnum(b.state), @intFromEnum(a.state));
        } else if (comptime std.mem.eql(u8, field.name, "extra_header_names") or std.mem.eql(u8, field.name, "extra_header_values")) {
            try std.testing.expectEqual(@field(b, field.name).len, @field(a, field.name).len);
            for (@field(b, field.name)[0..b.extra_header_count], @field(a, field.name)[0..a.extra_header_count]) |bs, as| {
                try std.testing.expectEqualStrings(bs, as);
            }
        } else {
            try std.testing.expectEqual(@field(b, field.name), @field(a, field.name));
        }
    }
}

fn compare_request(a: candidate.Request, b: candidate.Request) !void {
    inline for (.{ "method", "target", "path", "protocol", "query", "body" }) |name| {
        try std.testing.expectEqualStrings(@field(b, name), @field(a, name));
    }
    try std.testing.expectEqual(b.header_count, a.header_count);
    try std.testing.expectEqual(b.extra_header_count, a.extra_header_count);
    for (a.header_names[0..a.header_count], a.header_values[0..a.header_count], b.header_names[0..b.header_count], b.header_values[0..b.header_count]) |an, av, bn, bv| {
        try std.testing.expectEqualStrings(bn, an);
        try std.testing.expectEqualStrings(bv, av);
    }
    if (a.extra_header_names) |names| {
        try std.testing.expect(b.extra_header_names != null);
        try std.testing.expectEqual(b.extra_header_names.?.len, names.len);
        for (names[0..a.extra_header_count], a.extra_header_values.?[0..a.extra_header_count], b.extra_header_names.?[0..b.extra_header_count], b.extra_header_values.?[0..b.extra_header_count]) |an, av, bn, bv| {
            try std.testing.expectEqualStrings(bn, an);
            try std.testing.expectEqualStrings(bv, av);
        }
    } else try std.testing.expect(b.extra_header_names == null);
}

fn run_case(input: []const u8, split: usize, every_byte: bool, head: bool, configured: usize) !void {
    var ac: [32768]u8 = undefined;
    var bc: [32768]u8 = undefined;
    @memcpy(ac[0..input.len], input);
    @memcpy(bc[0..input.len], input);
    var ap = candidate.HttpParser{};
    var bp = oracle.HttpParser{};
    var ar = candidate.Request{};
    var br = candidate.Request{};
    var an: [4][]const u8 = undefined;
    var av: [4][]const u8 = undefined;
    var bn: [4][]const u8 = undefined;
    var bv: [4][]const u8 = undefined;
    if (configured == 1) {
        ap.max_body_size = 3;
        bp.max_body_size = 3;
    }
    if (configured == 2) {
        ap.content_length = 2;
        bp.content_length = 2;
        ap.body_start = 1;
        bp.body_start = 1;
        ap.body_length = 7;
        bp.body_length = 7;
        ap.chunk_length = 9;
        bp.chunk_length = 9;
    }
    if (configured == 3) {
        ap.extra_header_names = &an;
        ap.extra_header_values = &av;
        bp.extra_header_names = &bn;
        bp.extra_header_values = &bv;
    }
    var end: usize = if (every_byte) 0 else split;
    var head_done = false;
    while (true) {
        const expected = oracle.consume(&bp, &br, bc[0..end]);
        var actual: usize = undefined;
        if (head and !head_done and @intFromEnum(ap.state) <= @intFromEnum(candidate.ParserState.headers)) {
            const result = candidate.consume_head(&ap, &ar, ac[0..end]);
            actual = result.consumed;
            if (result.ready != null) {
                head_done = true;
                if (candidate.commit_head(&ap, &ar, result)) actual = candidate.consume(&ap, &ar, ac[0..end]) else actual = end;
            } else if (result.buffered_failure != null) {
                _ = candidate.commit_head(&ap, &ar, result);
            }
        } else actual = candidate.consume(&ap, &ar, ac[0..end]);
        try std.testing.expectEqual(expected, actual);
        try compare_parser(ap, bp);
        try compare_request(ar, br);
        try std.testing.expectEqualSlices(u8, bc[0..input.len], ac[0..input.len]);
        if (end == input.len) break;
        end = if (every_byte) end + 1 else input.len;
    }
}

test "differential: immutable buffered parser compatibility at every split" {
    const cases = [_][]const u8{
        "GET /?q HTTP/1.1\r\nHost: a\r\n\r\nPIPE",
        "POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 4\r\n\r\ndataPIPE",
        "POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 0\r\n\r\nPIPE",
        "POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n4;x=y\r\ndata\r\n1\r\nx\r\n0\r\nX: v\r\nY:\r\n\r\nPIPE",
        "POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n4;bad\n\r\ndata\r\n0\r\n\r\n",
        "POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n4\rXdata\r\n0\r\n\r\n",
        "POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n4\r\ndata\rX0\r\n\r\n",
        "POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n0\r\nHost: b\r\n\r\n",
        "POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n100000000\r\n",
        "POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 4294967296\r\nMalformed\r\n\r\n",
        "POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 4294967296\r\nTransfer-Encoding: chunked\r\n\r\n",
        "POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 20000\r\nMalformed\r\n\r\n",
        "POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 20000\r\nTransfer-Encoding: chunked\r\n\r\n",
        "POST / HTTP/1.1\r\nContent-Length: 20000\r\n\r\n",
        "POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 20000\r\n\r\n",
        "POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 18446744073709551616\r\n\r\n",
    };
    for (cases) |input| {
        for (0..4) |configured| {
            for ([_]bool{ false, true }) |head| {
                for (0..input.len + 1) |split| try run_case(input, split, false, head, configured);
                try run_case(input, 0, true, head, configured);
            }
        }
    }
}

test "differential: header count and length bounds retain legacy error checkpoints" {
    var input: [4096]u8 = undefined;
    for ([_][]const u8{ "", "Content-Length: 20000\r\n", "Content-Length: 4294967296\r\n" }) |length_field| {
        for ([_]usize{ 62, 63, 64, 67, 68 }) |count| {
            var writer = std.Io.Writer.fixed(&input);
            try writer.writeAll("POST / HTTP/1.1\r\nHost: a\r\n");
            try writer.writeAll(length_field);
            for (0..count) |_| try writer.writeAll("X: v\r\n");
            try writer.writeAll("\r\ndataPIPE");
            const text = input[0..writer.end];
            for (0..4) |configured| {
                for ([_]bool{ false, true }) |head| {
                    for (0..text.len + 1) |split| try run_case(text, split, false, head, configured);
                    try run_case(text, 0, true, head, configured);
                }
            }
        }
    }
}

test "differential: long buffered extension has no new streaming line ceiling" {
    var input: [19000]u8 = undefined;
    const prefix = "POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n1;";
    @memcpy(input[0..prefix.len], prefix);
    @memset(input[prefix.len..18000], 'x');
    const suffix = "\r\nx\r\n0\r\n\r\nPIPE";
    @memcpy(input[18000..][0..suffix.len], suffix);
    const text = input[0 .. 18000 + suffix.len];
    for ([_]bool{ false, true }) |head| {
        for ([_]usize{ 0, 1, prefix.len - 1, prefix.len, 8192, 16384, 18000, 18001, 18002, text.len }) |split| try run_case(text, split, false, head, 0);
        try run_case(text, 0, true, head, 0);
    }
}

test "differential: deterministic byte mutations preserve parser state and compaction" {
    const seeds = [_][]const u8{
        "POST /u?q HTTP/1.1\r\nHost: a\r\nContent-Length: 4\r\n\r\ndataPIPE",
        "POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n4;ok\r\ndata\r\n0\r\nX: v\r\n\r\nPIPE",
    };
    var input: [256]u8 = undefined;
    for (seeds) |seed| {
        for (0..seed.len) |position| {
            for ([_]u8{ 0, '\r', '\n', ';', ':', ' ', '9', 127, 255 }) |byte| {
                @memcpy(input[0..seed.len], seed);
                input[position] = byte;
                for ([_]bool{ false, true }) |head| {
                    try run_case(input[0..seed.len], position, false, head, 0);
                    try run_case(input[0..seed.len], 0, true, head, 0);
                }
            }
        }
    }
}
