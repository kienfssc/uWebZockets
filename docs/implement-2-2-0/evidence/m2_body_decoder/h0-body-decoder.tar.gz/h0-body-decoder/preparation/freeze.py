from pathlib import Path
import subprocess,hashlib,json,shutil
root=Path('/workspaces/uWebZockets/.uwz-work/evidence/h1-decoder')
files=['src/http/parser.zig','src/http/body_decoder.zig','src/fuzz/http_body.zig','src/tests/http_body_decoder_tests.zig','src/tests/main.zig','src/tests/fuzz_main.zig','src/test_support.zig','src/fuzz_support.zig','fuzz/http_framing.zig','fuzz/smoke_http.zig']
parts=[subprocess.check_output(['git','diff','--binary','--',*files])]
for file in files:
 if subprocess.run(['git','ls-files','--error-unmatch',file],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
  result=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',file],stdout=subprocess.PIPE)
  if result.returncode!=1:raise SystemExit('new file diff failed '+file)
  parts.append(result.stdout)
patch=b''.join(parts);(root/'h0.patch').write_bytes(patch)
manifest={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'zig':'/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig','patch_sha256':hashlib.sha256(patch).hexdigest(),'source_sha256':{f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files},'oracle_sha256':hashlib.sha256(Path('src/http/h1_baseline_oracle.zig').read_bytes()).hexdigest(),'raw_statuses':{p.name:p.read_text().strip() for p in sorted(root.glob('*.status'))}}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for f in files:
 dest=root/'sources'/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
for f in ['src/h1_decoder_differential.zig','src/h1_decoder_focus.zig','src/h1_decoder_layout_probe.zig']:
 shutil.copyfile(f,root/Path(f).name)
print('patch_sha256',manifest['patch_sha256'])
