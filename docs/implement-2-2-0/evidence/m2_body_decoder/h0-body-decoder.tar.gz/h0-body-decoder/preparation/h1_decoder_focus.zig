test {
    _ = @import("tests/http_body_decoder_tests.zig");
}
