const std = @import("std");
const candidate = @import("http/parser.zig");
const baseline = @import("http/h1_baseline_oracle.zig");
comptime {
    if (@sizeOf(candidate.HttpParser) != @sizeOf(baseline.HttpParser)) @compileError("HttpParser size changed");
    if (@alignOf(candidate.HttpParser) != @alignOf(baseline.HttpParser)) @compileError("HttpParser alignment changed");
    for (std.meta.fields(candidate.HttpParser)) |field| {
        if (@offsetOf(candidate.HttpParser, field.name) != @offsetOf(baseline.HttpParser, field.name)) @compileError("HttpParser offset changed: " ++ field.name);
    }
}
export fn parser_layout_size() usize {
    return @sizeOf(candidate.HttpParser);
}
