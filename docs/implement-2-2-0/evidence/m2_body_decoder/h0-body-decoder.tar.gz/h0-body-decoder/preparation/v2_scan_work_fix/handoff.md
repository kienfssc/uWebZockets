# H0 v2: streaming scan-work overflow fix

The original H0 `h0.patch`, `manifest.json`, source copies and review artifact are
unchanged. `fix.patch` applies against that exact freeze; `h0-v2.patch` is the
combined replacement patch against 00c8564. Use either original H0 plus fix, or
combined v2, never both. Manifest binds both patch hashes and all 10 source hashes.
Only body_decoder.zig and focused decoder tests differ from H0.

## Finding and correction

The review's P2 is reproduced: bounded ingress does not bound cumulative lifetime
delimiter work. Streaming reused a usize scan_work counter with unchecked adds,
so a sufficiently long legal request could trap on 32-bit or eventually 64-bit.
No multi-gigabyte request was executed to establish this; the arithmetic finding
was static, and deterministic tests seed only that diagnostic counter near its
maximum before processing actual legal framing and payload.

All eight delimiter-accounting sites now use record_scan_work. Streaming uses
saturating addition, including searches without a delimiter and trailer scans.
The field documents that it remains cumulative across discard_prefix and saturates
at maxInt(usize). Saturation is diagnostic; it never alters framing acceptance,
logical body counters, capacity limits, consumed offsets or error precedence.
The search increments themselves are bounded by the current physical input slice.

Buffered projection retains the original exact usize addition. HttpParser fields,
layout, scalar semantics, reset and all Request/OwnedRequest APIs remain unchanged.
No limits or assertions were reduced. Saturation was chosen instead of a finite
logical-width counter because an arbitrarily long request can exceed any finite
lifetime diagnostic total while continuously reclaiming bounded ingress.

Two tests exercise a legal chunk, accept_payload, discard_prefix, final chunk,
validated trailer and pipeline retention with scan_work initialized near maximum.
The second splits chunk-size, extension and trailer input to cover both found-
delimiter and incomplete-search paths. No enormous allocation/input is needed.

## Executed evidence

- red-native: expected failure, status 1, integer overflow at original line 142.
- red32-escalated: expected failure, status 134 (ABRT), same overflow in actual
  x86 Linux test binary. Source hashes before correction are recorded separately.
- focused-native and focused32-escalated: all 21 tests pass (20 cases plus launcher).
- differential-native and differential32-escalated: all 4 immutable-baseline groups
  pass, including per-call fields/views/consumption/scan_work/compaction parity.
- focused deterministic Smith corpus, existing HTTP LLVM smoke, instrumented HTTP
  LLVM object and counter-section check all pass.
- formatting, conventions, release metadata, patch application check and Graphify
  update pass. Graph output remains ignored and draft-local.

Raw logs and statuses are retained, including expected red failures. 32-bit binaries
were compiled with Zig 0.16.0 and executed outside the sandbox because its syscall
filter causes SIGSYS, as established by the original H0 evidence. No surrogate or
emulator replaced actual 32-bit execution.

## Integration

Re-review this two-file correction before integration. Root retains broad native,
sanitizer, full fuzz, h1spec, target and package gates; none was duplicated here.
This fix changes diagnostic behavior only on the new streaming decoder and proves
unchanged buffered behavior against the immutable oracle. It does not establish
transport streaming, multi-gigabyte execution or complete M2 compliance.

The original commands remain in ../commands.txt. V2 repeats those focused commands
with logs in this directory and final 32-bit binaries
/tmp/h1-decoder-v2-focused32 and /tmp/h1-decoder-v2-differential32. The pre-fix 32-bit
binary is /tmp/h1-decoder-scan-work-red32; regenerable binaries are not relied on
for persistent source/evidence ownership.
