from pathlib import Path
p=Path('src/http/parser.zig')
s=p.read_text()
s=s.replace('const simd = @import("../core/simd.zig");','const simd = @import("../core/simd.zig");\nconst body_decoder = @import("body_decoder.zig");\nconst fetch = @import("fetch.zig");')
a=s.index('fn is_hexadecimal('); b=s.index('/// Routeable path',a); s=s[:a]+s[b:]
a=s.index('/// Parses bytes into `req`')
s=s[:a]+'''/// Structurally admitted head; its views borrow the caller's header arrays and input.
/// Keep both pinned through streaming admission and the resulting response lifetime.
pub const HeadReady = struct {
    framing: body_decoder.Framing,
    header_end: usize,
    headers: fetch.HeadersView,
};

/// Earliest legacy failure checkpoint, before later provisional fields can mask it.
pub const BufferedHeadFailure = struct {
    state: ParserState,
    content_length: usize,
    header_count: usize,
    extra_header_count: usize,
};

/// A ready head precedes body policy and payload, even when all bytes arrived together.
/// A failed structural scan still carries an earlier machine-width rejection, if any.
pub const HeadResult = struct {
    consumed: usize = 0,
    ready: ?HeadReady = null,
    buffered_failure: ?BufferedHeadFailure = null,
};

/// Parses only through initial headers, admitting logical u64 lengths provisionally.
/// Select streaming only after ready; buffered fallback must call commit_head on errors too.
/// Do not scan a completed head twice or resume consume before committing buffered policy.
pub fn consume_head(parser: *HttpParser, req: *Request, buffer: []u8) HeadResult {
    var result = HeadResult{};
    result.consumed = consume_internal(parser, req, buffer, &result);
    return result;
}

fn buffered_checkpoint(parser: *const HttpParser, req: *const Request, state: ParserState) BufferedHeadFailure {
    return .{
        .state = state,
        .content_length = parser.content_length,
        .header_count = req.header_count,
        .extra_header_count = parser.extra_header_count,
    };
}

/// Applies the unchanged buffered policy, committing overflow views only after acceptance.
pub fn commit_head(parser: *HttpParser, req: *Request, result: HeadResult) bool {
    if (result.buffered_failure) |failure| {
        parser.state = failure.state;
        parser.content_length = failure.content_length;
        req.header_count = failure.header_count;
        parser.extra_header_count = failure.extra_header_count;
        return false;
    }
    const head = result.ready orelse return false;
    commit_buffered_head(parser, req, head.header_end, head.framing == .chunked);
    return true;
}

fn commit_buffered_head(parser: *HttpParser, req: *Request, header_end: usize, chunked: bool) void {
    req.extra_header_names = parser.extra_header_names[0..parser.extra_header_count];
    req.extra_header_values = parser.extra_header_values[0..parser.extra_header_count];
    req.extra_header_count = parser.extra_header_count;
    if (chunked) {
        enter_state(parser, .chunk_size, header_end);
        parser.body_start = parser.mark;
        parser.body_length = 0;
        return;
    }
    enter_state(parser, if (parser.content_length > 0) .body else .done, header_end);
}

/// Parses bytes into `req` and returns the prefix consumed by this request.
/// Request slices borrow buffer; chunked bodies compact in place until dispatch completes.
pub fn consume(parser: *HttpParser, req: *Request, buffer: []u8) usize {
    return consume_internal(parser, req, buffer, null);
}

fn consume_internal(parser: *HttpParser, req: *Request, buffer: []u8, head_result: ?*HeadResult) usize {
''' + s[a:].split('pub fn consume(parser: *HttpParser, req: *Request, buffer: []u8) usize {\n',1)[1]
s=s.replace('var cl_too_large = false;', 'var cl_too_large = false;\n                    var logical_length: u64 = 0;')
a=s.index('                                if (std.fmt.parseInt(usize, value, 10))');b=s.index('\n                            }',a)
s=s[:a]+'''                                if (head_result) |result| {
                                    logical_length = std.fmt.parseInt(u64, value, 10) catch {
                                        parser.state = .error_invalid;
                                        return buffer.len;
                                    };
                                    if (logical_length > std.math.maxInt(usize)) {
                                        result.buffered_failure = buffered_checkpoint(parser, req, .error_invalid);
                                    } else if (logical_length > parser.max_body_size) {
                                        cl_too_large = true;
                                    } else {
                                        parser.content_length = @intCast(logical_length);
                                    }
                                } else if (std.fmt.parseInt(usize, value, 10)) |len| {
                                    if (len > parser.max_body_size) {
                                        cl_too_large = true;
                                    } else {
                                        parser.content_length = len;
                                    }
                                } else |_| {
                                    parser.state = .error_invalid;
                                    return buffer.len;
                                }''' + s[b:]
a=s.index('                    if (cl_too_large)');b=s.index('\n                } else {\n                    parser.scan_work',a)
s=s[:a]+'''                    if (head_result) |result| {
                        if (cl_too_large and result.buffered_failure == null) {
                            result.buffered_failure = buffered_checkpoint(parser, req, .error_too_large);
                        }
                        // RFC 9112 section 6.3: framing is structural; body storage policy follows routing.
                        result.ready = .{
                            .framing = if (has_te) .chunked else if (has_cl) .{ .content_length = logical_length } else .none,
                            .header_end = end + 4,
                            .headers = fetch.HeadersView.init_with_extra(
                                req.header_names[0..req.header_count],
                                req.header_values[0..req.header_count],
                                parser.extra_header_names[0..parser.extra_header_count],
                                parser.extra_header_values[0..parser.extra_header_count],
                            ),
                        };
                        return end + 4;
                    }
                    if (cl_too_large) {
                        parser.state = .error_too_large;
                        return buffer.len;
                    }
                    commit_buffered_head(parser, req, end + 4, has_te);
                    if (parser.state == .done) return parser.mark;
                    continue;''' + s[b:]
a=s.index('            .body => {');b=s.index('            .done, .error_invalid',a)
s=s[:a]+'''            .body, .chunk_size, .chunk_ext, .chunk_data, .chunk_crlf, .chunk_trailer => {
                return collect_body(parser, req, buffer);
            },
''' + s[b:]
a=s.index('fn valid_trailers(');b=s.index('/// Resets parser',a)
s=s[:a]+'''fn decoder_state(state: ParserState) body_decoder.State {
    return switch (state) {
        .body => .body,
        .chunk_size => .chunk_size,
        .chunk_ext => .chunk_ext,
        .chunk_data => .chunk_data,
        .chunk_crlf => .chunk_crlf,
        .chunk_trailer => .chunk_trailer,
        else => unreachable, // Only body states enter the collector.
    };
}

fn project_decoder(parser: *const HttpParser) body_decoder.BodyDecoder {
    return .{
        .state = decoder_state(parser.state),
        .limits = .{ .max_body_bytes = parser.max_body_size, .max_header_bytes = parser.max_header_bytes, .buffered = true },
        .mark = parser.mark,
        .scan = parser.scan,
        .scan_work = parser.scan_work,
        .chunk_length = parser.chunk_length,
        .body_length = parser.body_length,
        .remaining = if (parser.state == .body) parser.content_length else parser.chunk_length,
    };
}

fn store_decoder(parser: *HttpParser, decoder: *const body_decoder.BodyDecoder) void {
    parser.state = switch (decoder.state) {
        .body => .body,
        .chunk_size => .chunk_size,
        .chunk_ext => .chunk_ext,
        .chunk_data => .chunk_data,
        .chunk_crlf => .chunk_crlf,
        .chunk_trailer => .chunk_trailer,
        .done => .done,
        .error_invalid => .error_invalid,
        .error_too_large => .error_too_large,
    };
    parser.mark = decoder.mark;
    parser.scan = decoder.scan;
    parser.scan_work = decoder.scan_work;
    parser.chunk_length = @intCast(decoder.chunk_length);
    // Fixed-body completion never changed the legacy decoded-chunk counter.
    if (parser.body_start != 0) parser.body_length = @intCast(decoder.body_length);
}

fn collect_body(parser: *HttpParser, req: *Request, buffer: []u8) usize {
    var decoder = project_decoder(parser);
    const fixed = parser.state == .body;
    const body_start = parser.mark;
    while (decoder.mark < buffer.len) {
        switch (body_decoder.next(&decoder, buffer)) {
            .data => |bytes| {
                if (!fixed) {
                    const start = parser.body_start + @as(usize, @intCast(decoder.body_length));
                    std.mem.copyForwards(u8, buffer[start..][0..bytes.len], bytes);
                }
                // The decoder offered exactly this borrowed prefix.
                body_decoder.accept_payload(&decoder, bytes.len) catch unreachable;
                if (fixed) {
                    req.body = buffer[body_start..decoder.mark];
                    store_decoder(parser, &decoder);
                    return parser.mark;
                }
            },
            .end => {
                req.body = buffer[parser.body_start..][0..@intCast(decoder.body_length)];
                store_decoder(parser, &decoder);
                return parser.mark;
            },
            .need_more, .invalid, .too_large => {
                store_decoder(parser, &decoder);
                return buffer.len;
            },
        }
    }
    store_decoder(parser, &decoder);
    return parser.mark;
}

''' + s[b:]
p.write_text(s)
