# H0 HTTP/1 head and decoder seam

Draft: `/workspaces/uWebZockets/.uwz-work/drafts/m2-h1-decoder`.
Base: `00c8564` (full commit and exact source/patch hashes in manifest.json).
Integration artifact: `h0.patch`; frozen owned source copies under `sources/`.
No changes or commits were made in the original worktree.

## Contract

`consume_head` shares the existing method/target/protocol/header scan and returns
`HeadResult.ready` before body-cap policy, body consumption or compaction, even
for a complete same-read request. `HeadReady` contains u64 `Framing`, header_end
and a pure HeadersView. The head borrows input plus Request/parser header arrays;
all must remain pinned through the response lifetime. Overflow Request views
remain uncommitted until `commit_head` selects buffering. Do not rescan a ready
head; choose streaming using its separate caller-owned BodyDecoder or commit it
once for buffering. A structural failure is never a streaming admission.

The actual baseline records oversized Content-Length during field scan, then
validates later fields, Host and TE+CL before returning 413. A usize conversion
overflow instead fails immediately. A provisional wide scan retains that earliest
buffered checkpoint (state, scalar content length and header counts) even when
later structural validation fails. Buffered fallback calls commit_head for both
success and failure; no complete Request copy or persistent parser field is added.
Request/OwnedRequest and their inferred error sets remain untouched.

One pure BodyDecoder parses fixed/chunked framing and offers nonempty borrowed
payload. Only accept_payload advances payload bytes. discard_prefix rebases
retained caller input, including cumulative size/extension-line accounting.
Logical lengths/counts use u64 independently from physical usize offsets.
Streaming validates/discards trailers incrementally (64 fields, configured total
and per-line bounds); the buffered collector uses the same decoder through a
stack projection with original whole-fixed/current-chunk and whole-trailer timing.
Buffered extension lines retain their original policy, including valid >16 KiB
lines. All 14 HttpParser fields, order, layout, offsets and reset remain unchanged.

Framing sources checked: RFC 9112 sections 6.3, 7.1, 7.1.1, 7.1.2; forbidden
trailer categories RFC 9110 section 6.5.1. Existing extension byte validation and
buffered Expect behavior are preserved. Streaming admission/Expect417/100 timing
belongs to later transport work, with no new live capability claimed by H0.

## Evidence

Logs have matching `.status` files (0 success). Initial `red.log` fails because
body_decoder.zig did not exist. `green-initial.log` proves first API cases green.
`focused-final.log` and `focused32-final-escalated.log`: 19 tests including runner
root (18 ordinary cases), all pass. Initial in-sandbox 32-bit runner failed with
SIGSYS (`focused32.log`); exact same binary/argv outside sandbox passed, then the
final-source 32-bit runner passed as well. No emulation/substitute harness used.

`differential-expanded.log` and `differential32-escalated.log`: 4 groups pass against
`baseline-parser.zig`, an exact immutable snapshot of committed 00c8564 parser
(SHA256 50509956e383abcd9237092b78a516623b5addec568956ccfc22b68dc1c6fe2a).
It is a verification-only oracle, excluded from patch and ordinary central tests.
Harness `h1_decoder_differential.zig` checks all 14 fields, request slices/counts/
views, states, consumed prefixes, scan_work and whole input compaction bytes after
each split call. Inputs cover fixed/chunked bodies, caps, framing conflicts, later
malformed fields, machine width, header-count bounds, custom preconfigured parser
scalars and overflow storage; every split and bytewise delivery, an 18 KiB valid
extension, and deterministic byte mutations. This is bounded evidence, not a proof
for every possible caller-corrupted state or byte sequence.

`layout-*.status`: size/alignment/all offsets match immutable parser on x86 Linux,
x86_64 Linux/macOS/Windows and aarch64 Linux/macOS (compile only). Native/32-bit
differential also checks layout at runtime. `smith-focused.log` passes the new
central deterministic Smith corpus. `llvm-http-smoke.log` runs the existing HTTP
framing target with new bounded seeds through the shared decoder/head exercise.
`llvm-http-object` and `llvm-coverage-final` logs record instrumentation build/check.
An earlier `llvm-coverage.log` ran before object compilation finished and reported
missing object; final check passed once the object existed.

Formatting, convention and release-version checks are recorded. Earlier
`conventions.log` initially lacked rg in clone PATH; explicit tool PATH resolved it.
Graphify update passed and affects ignored draft graph output only. It warned
that parallel extraction was unavailable, then completed sequentially; 25 code
files yielded no symbols. No graph-output correctness claim follows.
No allocator, I/O, callback or retained input pointer exists in the new decoder.
No throughput or latency improvement is claimed; scan_work compatibility is tested.

## Reproduction

Use Zig 0.16.0 at
`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`.
Focused launcher and oracle harness are verification-only; copy them to `src/`
in a scratch clone, and put exact `baseline-parser.zig` at
`src/http/h1_baseline_oracle.zig` before running. Commands are in commands.txt.
32-bit test binaries need execution outside this environment's syscall sandbox.

## Remaining integration gates

Root owns broad `zig build test --summary all`, sanitizer/target/package checks,
full deterministic fuzz and OSS-Fuzz suite, h1spec ReleaseSafe build plus Deno
runner, independent review and integrated source-hash binding. These were not run
in this author clone to avoid duplicate native dependency matrices. No protocol
compliance or full milestone-completion claim follows from focused results.

Shared integration hunks are src/tests/main.zig, src/test_support.zig,
src/fuzz_support.zig and src/tests/fuzz_main.zig. Serialize with other authors.
Production ownership files parser/body_decoder and focused tests are otherwise
independent. Never include verification-only oracle/launcher files or zig-pkg
symlink in the production patch.
