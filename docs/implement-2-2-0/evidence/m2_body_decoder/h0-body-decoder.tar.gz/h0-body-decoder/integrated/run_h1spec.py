import json,os,socket,subprocess,time,signal,hashlib
from pathlib import Path
root=Path('/workspaces/uWebZockets'); out=root/'.uwz-work/evidence/h1-decoder-integrated'; server=root/'zig-out/bin/h1spec'; deno=root/'.uwz-work/tools/deno'
record={'server_argv':[str(server)],'client_argv':[str(deno),'run','--allow-net=127.0.0.1:8000','http_test.ts','127.0.0.1','8000'],'cwd':str(root/'vendor/h1spec'),'server_sha256':hashlib.sha256(server.read_bytes()).hexdigest(),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
probe=socket.socket(); probe.bind(('127.0.0.1',8000)); probe.close()
proc=None
try:
 with (out/'h1spec-server.stdout').open('wb') as so,(out/'h1spec-server.stderr').open('wb') as se:
  proc=subprocess.Popen([str(server)],cwd=root,stdout=so,stderr=se)
  record['owned_server_pid']=proc.pid
  for i in range(100):
   if proc.poll() is not None:raise RuntimeError('Owned server exited before readiness')
   try:
    with socket.create_connection(('127.0.0.1',8000),timeout=.1):pass
    record['readiness']='owned process alive and local connection accepted';break
   except OSError:time.sleep(.05)
  else:raise RuntimeError('Owned server readiness timeout')
  with (out/'h1spec.stdout').open('wb') as co,(out/'h1spec.stderr').open('wb') as ce:
   r=subprocess.run(record['client_argv'],cwd=root/'vendor/h1spec',stdout=co,stderr=ce,timeout=180)
  record['exit_status']=r.returncode
finally:
 if proc is not None:
  if proc.poll() is None:
   proc.send_signal(signal.SIGTERM)
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:proc.kill();proc.wait();record['cleanup_escalated_to_kill']=True
  record['owned_server_cleanup_returncode']=proc.returncode
 record['ended_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 (out/'h1spec.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(record.get('exit_status',1))
