from pathlib import Path
import datetime, hashlib, json, os, shlex, subprocess, sys, time
repo=Path('/workspaces/uWebZockets/.uwz-work/drafts/libxev-udp-fix')
e=Path('/workspaces/uWebZockets/.uwz-work/evidence/epoll-registration-rollback/implementation')
label=sys.argv[1]
argv=sys.argv[2:]
assert len(argv)>0
names=subprocess.check_output(['git','ls-files','*.zig','include/xev.h'],cwd=repo,text=True).splitlines()
for name in ['src/backend/epoll_registration.zig','src/tests/epoll_registration_tests.zig']:
 if (repo/name).exists() and name not in names:names.append(name)
def hashes():return {name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in sorted(names)}
before=hashes()
env=os.environ.copy()
env['ZIG_GLOBAL_CACHE_DIR']='/workspaces/uWebZockets/.uwz-work/evidence/libxev-udp-fix/cache-global'
start=time.monotonic()
p=subprocess.run(argv,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
after=hashes()
record={'argv':argv,'cwd':str(repo),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':before,'after_source_sha256':after,'source_unchanged':before==after,'exit_status':p.returncode,'elapsed_seconds':time.monotonic()-start,'ZIG_GLOBAL_CACHE_DIR':env['ZIG_GLOBAL_CACHE_DIR']}
(e/(label+'.command')).write_text(shlex.join(argv)+'\n')
(e/(label+'.log')).write_bytes(p.stdout)
(e/(label+'.status')).write_text(str(p.returncode)+'\n')
(e/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'record':label,'exit_status':p.returncode,'source_unchanged':before==after,'elapsed_seconds':record['elapsed_seconds']}))
if p.stdout:print(p.stdout.decode(errors='replace')[-2500:])
assert before==after
sys.exit(p.returncode)
