	.intel_syntax noprefix
	.file	"root"
	.type	.Labi_contract.completion_next,@object
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.Labi_contract.completion_next:
	.quad	176
	.size	.Labi_contract.completion_next, 8

	.type	.Labi_contract.completion_flags,@object
	.p2align	3, 0x0
.Labi_contract.completion_flags:
	.quad	168
	.size	.Labi_contract.completion_flags, 8

	.type	.Labi_contract.completion_task_result,@object
	.p2align	3, 0x0
.Labi_contract.completion_task_result:
	.quad	144
	.size	.Labi_contract.completion_task_result, 8

	.type	.Labi_contract.completion_task_completions,@object
	.p2align	3, 0x0
.Labi_contract.completion_task_completions:
	.quad	136
	.size	.Labi_contract.completion_task_completions, 8

	.type	.Labi_contract.completion_task_loop,@object
	.p2align	3, 0x0
.Labi_contract.completion_task_loop:
	.quad	128
	.size	.Labi_contract.completion_task_loop, 8

	.type	.Labi_contract.completion_task,@object
	.p2align	3, 0x0
.Labi_contract.completion_task:
	.quad	112
	.size	.Labi_contract.completion_task, 8

	.type	.Labi_contract.completion_callback,@object
	.p2align	3, 0x0
.Labi_contract.completion_callback:
	.quad	104
	.size	.Labi_contract.completion_callback, 8

	.type	.Labi_contract.completion_userdata,@object
	.p2align	3, 0x0
.Labi_contract.completion_userdata:
	.quad	96
	.size	.Labi_contract.completion_userdata, 8

	.type	.Labi_contract.completion_op,@object
	.p2align	3, 0x0
.Labi_contract.completion_op:
	.quad	0
	.size	.Labi_contract.completion_op, 8

	.type	.Labi_contract.completion_size,@object
	.p2align	3, 0x0
.Labi_contract.completion_size:
	.quad	184
	.size	.Labi_contract.completion_size, 8

	.type	.Labi_contract.result_alignment,@object
	.p2align	3, 0x0
.Labi_contract.result_alignment:
	.quad	8
	.size	.Labi_contract.result_alignment, 8

	.type	.Labi_contract.result_size,@object
	.p2align	3, 0x0
.Labi_contract.result_size:
	.quad	24
	.size	.Labi_contract.result_size, 8

	.globl	completion_next
completion_next = .Labi_contract.completion_next
	.size	completion_next, 8
	.globl	completion_flags
completion_flags = .Labi_contract.completion_flags
	.size	completion_flags, 8
	.globl	completion_task_result
completion_task_result = .Labi_contract.completion_task_result
	.size	completion_task_result, 8
	.globl	completion_task_completions
completion_task_completions = .Labi_contract.completion_task_completions
	.size	completion_task_completions, 8
	.globl	completion_task_loop
completion_task_loop = .Labi_contract.completion_task_loop
	.size	completion_task_loop, 8
	.globl	completion_task
completion_task = .Labi_contract.completion_task
	.size	completion_task, 8
	.globl	completion_callback
completion_callback = .Labi_contract.completion_callback
	.size	completion_callback, 8
	.globl	completion_userdata
completion_userdata = .Labi_contract.completion_userdata
	.size	completion_userdata, 8
	.globl	completion_op
completion_op = .Labi_contract.completion_op
	.size	completion_op, 8
	.globl	completion_alignment
completion_alignment = .Labi_contract.result_alignment
	.size	completion_alignment, 8
	.globl	completion_size
completion_size = .Labi_contract.completion_size
	.size	completion_size, 8
	.globl	result_alignment
result_alignment = .Labi_contract.result_alignment
	.size	result_alignment, 8
	.globl	result_size
result_size = .Labi_contract.result_size
	.size	result_size, 8
	.section	".note.GNU-stack","",@progbits
