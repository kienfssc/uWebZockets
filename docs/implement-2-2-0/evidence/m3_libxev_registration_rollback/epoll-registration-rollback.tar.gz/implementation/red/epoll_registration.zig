/// Internal stack ownership for one Linux descriptor acquisition.
pub const FdAcquisition = struct {
    fd: i32,
    newly_duplicated: bool,
};

/// Transfers a new duplicate to rollback and invalidates the caller's cache.
pub fn take_new_duplicate(_: *FdAcquisition, _: *i32) ?i32 {
    return null;
}
