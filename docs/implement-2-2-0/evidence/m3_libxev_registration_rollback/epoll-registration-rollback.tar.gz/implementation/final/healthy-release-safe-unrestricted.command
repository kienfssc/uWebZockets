/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build test -Doptimize=ReleaseSafe -j2 --summary all
