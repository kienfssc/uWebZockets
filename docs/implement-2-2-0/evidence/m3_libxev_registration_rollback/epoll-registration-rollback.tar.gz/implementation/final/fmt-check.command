/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check src/backend/epoll.zig src/backend/epoll_registration.zig src/tests/epoll_registration_tests.zig src/main.zig
