/// Internal stack ownership for one Linux descriptor acquisition.
pub const FdAcquisition = struct {
    fd: i32,
    newly_duplicated: bool,
};

/// Transfers a new duplicate to rollback and invalidates the caller's cache.
pub fn take_new_duplicate(acquisition: *FdAcquisition, cached_dup_fd: *i32) ?i32 {
    if (!acquisition.newly_duplicated) return null;
    acquisition.newly_duplicated = false;
    cached_dup_fd.* = 0;
    return acquisition.fd;
}
