git diff --check
