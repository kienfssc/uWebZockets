/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build test '-Dtest-filter=epoll registration rollback' -Doptimize=ReleaseSafe -j2 --summary all
