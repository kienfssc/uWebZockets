const std = @import("std");
const builtin = @import("builtin");
const registration = @import("../backend/epoll_registration.zig");

test "epoll registration rollback takes newly acquired descriptors once" {
    for ([_]i32{ 0, 37 }) |fd| {
        var acquisition: registration.FdAcquisition = .{ .fd = fd, .newly_duplicated = true };
        var cache = fd;
        try std.testing.expectEqual(@as(?i32, fd), registration.take_new_duplicate(&acquisition, &cache));
        try std.testing.expectEqual(@as(i32, 0), cache);
        try std.testing.expect(!acquisition.newly_duplicated);
        try std.testing.expectEqual(fd, acquisition.fd);
        try std.testing.expect(registration.take_new_duplicate(&acquisition, &cache) == null);
    }
}

test "epoll registration rollback leaves original and cached descriptors untouched" {
    for ([_]i32{ 0, 91 }) |fd| {
        for ([_]i32{ 0, 37 }) |cached| {
            var acquisition: registration.FdAcquisition = .{ .fd = fd, .newly_duplicated = false };
            var cache = cached;
            try std.testing.expect(registration.take_new_duplicate(&acquisition, &cache) == null);
            try std.testing.expectEqual(cached, cache);
            try std.testing.expectEqual(fd, acquisition.fd);
            try std.testing.expect(!acquisition.newly_duplicated);
        }
    }
}

test "epoll registration rollback does not access an unowned undefined cache" {
    var acquisition: registration.FdAcquisition = .{ .fd = 91, .newly_duplicated = false };
    var cache: i32 = undefined;
    try std.testing.expect(registration.take_new_duplicate(&acquisition, &cache) == null);
    try std.testing.expectEqual(@as(i32, 91), acquisition.fd);
    try std.testing.expect(!acquisition.newly_duplicated);
}

test "epoll registration rollback preserves the original operation and dup request" {
    if (comptime builtin.os.tag != .linux) return;
    const epoll = @import("../backend/epoll.zig");
    for ([_]i32{ 0, 37 }) |fd| {
        var completion: epoll.Completion = .{ .op = .{ .recv = undefined } };
        completion.op.recv.fd = 91;
        completion.flags.dup = true;
        completion.flags.dup_fd = fd;
        var acquisition: registration.FdAcquisition = .{ .fd = fd, .newly_duplicated = true };
        var invalidated_cache: i32 = undefined;
        const taken = registration.take_new_duplicate(&acquisition, &invalidated_cache) orelse
            return error.ExpectedNewDuplicate;
        completion.flags.dup_fd = invalidated_cache;
        try std.testing.expectEqual(fd, taken);
        try std.testing.expectEqual(@as(i32, 0), completion.flags.dup_fd);
        try std.testing.expectEqual(@as(i32, 91), completion.op.recv.fd);
        try std.testing.expect(completion.flags.dup);
        try std.testing.expectEqual(epoll.OperationType.recv, @as(epoll.OperationType, completion.op));
    }
}
