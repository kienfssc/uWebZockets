# New epoll duplicate rollback after failed ADD

The four source files are frozen for independent review. No staging, commits,
refs, publication, root source, dependency pins or root reports were changed.

## Scope and identity

Clone: `/workspaces/uWebZockets/.uwz-work/drafts/libxev-udp-fix`.
Base commit: `179f22bc539548e024407b76d4aa39c54342e5b4`, tree
`afb88b35febd1d2e0de8d2802d1f3e2f8adceb38`.
Initial branch `draft/uwz-epoll-registration-rollback` was clean.

Changed files:

| Source | Frozen SHA256 |
| --- | --- |
| `src/backend/epoll.zig` | `2de7833299ff9ec882f6c7fd8905b9bdd5f460bfa335aefc6e7540df4dffec35` |
| `src/backend/epoll_registration.zig` | `c03525e0366ed84ade7a41cc01917dc2d895439b4780e9a778b3f1226589df74` |
| `src/tests/epoll_registration_tests.zig` | `1cacdc09b56a25ed4448175fd7aa20ce77152687b7e5c40e18bee51e775ed649` |
| `src/main.zig` | `8010cadc2515ee6cb033743ba94038b5848f5f3f1c1aac73d50ee357ef28d887` |

`final/complete.diff` includes tracked changes and both new files, SHA256
`89825cbdf040ed3f995e6ff21530dd70bd2f0f2acaacbc887e033fdaea48bec7`.
The source snapshots and manifests under `base/`, `red/` and `final/` bind the
before, extracted-old-policy and final forms. `final/frozen-source.sha256`
is the final four-file identity. Support hashes match the base, including
IOCP, kqueue, ThreadPool, MPSC queue, API, build graph, C exports and header.

## Actual production transaction

`fd_maybe_dup` now returns a named stack acquisition rather than a bare fd:

- Duplication not requested: original fd, `newly_duplicated = false`.
- Existing positive cached duplicate: cached fd, false.
- New successful duplicate, including fd zero: returned fd, true.
- Duplication failure: the same `DupFailed` error, without an acquisition or
  subsequent cache read.

All eleven registration branches call the actual `register_fd` helper:
accept, connect, read, pread, write, pwrite, send, recv, sendmsg, recvmsg and
poll. Connect retains its acquisition across `connect` into the existing
WouldBlock path. The helper's errdefer takes only a newly acquired duplicate,
invalidates the completion's cached fd, closes the taken fd, then returns the
original typed ADD error. It neither calls DEL nor changes start's result
selection, state transition, active count or callback handling.

`epoll_registration.zig` contains the actual named acquisition and pure take
function used by that errdefer. It is an internal module, not an added library
API. The take clears ownership once and writes zero to its cache destination;
unowned calls leave the destination untouched. The original operation fd and
dup-request flag are not changed.

`Completion.flags` is packed, so its fd field cannot be passed as an ordinary
`*i32`. Root accepted the bounded stack output: the pure function writes a local
cache destination, and only its non-null branch copies that output to the
packed field before close. No uninitialized output is read on unowned paths,
and acquisition failure never enters this helper. Existing packed types,
Completion/Result fields and public errors remain unchanged.

Existing positive-cache selection and immediate connect success/non-WouldBlock
outcomes remain outside this bounded correction. It does not claim generic
adding/deleting/worker cancellation safety or full transport retirement.

## Failing-first and final checks

The red function faithfully extracts the previous lack of rollback: it returns
null for all acquisitions. It was wired into the real shared ADD helper before
the new pure tests ran. This is **extracted-old-policy red**, not execution of
a failing kernel ADD or a runtime leak reproduction. That Debug run compiled
and ran 30 tests: 28 passed, and the two new owned-duplicate expectations failed.
The two unowned-decision cases passed. Only the pure take body changed for green.

Four named pure tests cover fd zero and a positive fd, take-once behavior,
original/cached non-ownership, an undefined cache destination on an unowned
path, and original operation/dup-request preservation using caller-owned
Completion data. No new test calls dup, close, epoll_ctl or native callbacks.
The filter also includes 26 existing discovery/declaration tests.

Every executed command has `.command`, `.log`, `.status` and source-bound `.json`
records. The recorder verifies the tracked Zig/header source plus both new
source files before and after each command. All final records report unchanged
source. All commands use the exact compiler
`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig` in the clone,
its existing `.zig-cache`, and
`ZIG_GLOBAL_CACHE_DIR=/workspaces/uWebZockets/.uwz-work/evidence/libxev-udp-fix/cache-global`.

| Record | Actual check | Outcome |
| --- | --- | --- |
| `base/abi-compile` | Linux x64 ReleaseSafe layout exports before edits | Exit 0 |
| `red/policy-debug` | Focused filter against extracted old policy | Exit 1; 28 pass, 2 expected failures |
| `final/fmt` | Formatter on all four source files | Exit 0; no changes |
| `final/policy-debug` | Focused Debug filter | Exit 0; 30/30 |
| `final/policy-release-safe` | Focused ReleaseSafe filter | Exit 0; 30/30 |
| `final/healthy-debug-unrestricted` | Unchanged healthy Debug suite | Exit 0; 159 pass, 4 existing skips, 163 total |
| `final/healthy-release-safe-unrestricted` | Unchanged healthy ReleaseSafe suite | Exit 0; 159 pass, 4 existing skips, 163 total |
| `final/abi-compile` | Same Linux x64 layout exports after edits | Exit 0 |
| `final/abi-compare` | `cmp` before/after layout assembly | Exit 0; byte-identical |
| `final/abi-values` | Alias-aware extraction and comparison of all 13 values | Exit 0 |
| `final/foreign-windows-pure-compile` | Windows compile-only focused graph | Exit 0; no execution |
| `final/fmt-check`, `final/whitespace` | Scoped formatter/whitespace checks | Exit 0 |

The healthy suite increased from 155 passes and four existing skips to 159
passes and the same four skips. Both runs requested normal OS access using the
execution approval mechanism. No known restricted-sandbox run was repeated or
mixed into the successful results.

The first ABI summary extractor incorrectly searched exported labels directly;
Zig emits local constants plus exported aliases. Its empty-result failure is
recorded in `final/abi-values-parser-initial.txt`. The corrected retained
`resolve_abi.py` follows aliases and compares all thirteen values. No source or
compiled output changed to repair that evidence parser. Byte-for-byte assembly
comparison had already passed. On Linux x64, Result remains 24 bytes/alignment8,
Completion184/alignment8, with every measured field offset unchanged.

## Exact verification commands

These are the inner commands retained by the recorder; all ran in the clone:

```sh
zig build test '-Dtest-filter=epoll registration rollback' -j2 --summary all
zig build test '-Dtest-filter=epoll registration rollback' -Doptimize=ReleaseSafe -j2 --summary all
zig build test -j2 --summary all
zig build test -Doptimize=ReleaseSafe -j2 --summary all
zig test src/main.zig -OReleaseSafe --test-filter 'epoll registration rollback' -target x86_64-windows-gnu -fno-emit-bin --cache-dir .zig-cache
```

The ABI compiler command, before and after, is preserved verbatim in its
respective `.command` record. It uses `zig build-obj -target x86_64-linux-gnu
-OReleaseSafe -fstrip --dep xev -Mroot=<abi_contract.zig> -Mxev=src/main.zig -lc
-fno-emit-bin -femit-asm=<phase/abi_contract.s>`. The exported field contract is
retained as `abi_contract.zig`.

## Limits and remaining ownership

The actual failing EPOLL_CTL_ADD branch and rollback close are established by
source argument, not a native failure experiment. Pure tests verify the real
ownership decision, not kernel execution or measured descriptor leakage.
No native registration-failure injection, resource exhaustion, invalid fd,
cancellation/interleaving/race/crash/leak experiment or completion injection
was constructed or run. No stopped experiment was reconstructed. No foreign
executable ran.

Independent review is still required. Root owns graph refresh, combined
integration, project gates, recovery bundles, maintained-fork publication,
ledger/pin decisions and the next R3 design review. This isolated candidate
changes neither maintained refs nor the application's current dependency pin.
