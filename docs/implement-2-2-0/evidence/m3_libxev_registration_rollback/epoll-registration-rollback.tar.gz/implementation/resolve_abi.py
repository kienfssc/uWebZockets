from pathlib import Path
import json,re
base=Path('/workspaces/uWebZockets/.uwz-work/evidence/epoll-registration-rollback/implementation')
def resolve(path):
    assembly=path.read_text()
    constants={name:int(value) for name,value in re.findall(r'^(\.Labi_contract\.\w+):\n\s*\.quad\s+(\d+)',assembly,re.M)}
    exports=dict(re.findall(r'^(\w+) = (\.Labi_contract\.\w+)$',assembly,re.M))
    values={name:constants[alias] for name,alias in exports.items()}
    assert len(values)==13,values
    return values
before=resolve(base/'base/abi_contract.s')
after=resolve(base/'final/abi_contract.s')
assert before==after
(base/'final/abi-values.json').write_text(json.dumps(after,indent=2)+'\n')
print(json.dumps(after,indent=2))
