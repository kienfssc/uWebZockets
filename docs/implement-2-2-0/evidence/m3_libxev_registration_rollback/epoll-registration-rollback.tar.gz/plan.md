# Accepted registration rollback contract

Architect /root/architect_iocp_cancel_result, root accepted 2026-10-27.
After saving the reviewed worker append, retain a named stack acquisition for
all eleven registerable operations. Original/cached paths are unowned; successful
new dup including0 is owned. Dup failure returns existing DupFailed with no
record or cache read. Connect carries acquisition through WouldBlock; immediate
connect outcomes and old cached-fd semantics remain outside this correction.

One actual ADD helper owns errdefer rollback. The actual pure take transfers a
new duplicate once, invalidates cache, and leaves unowned cache untouched. Close
only that fd and preserve exact ADD error, original operation fd, dup request,
result tags/callbacks/state/active count. Do not DEL a failed ADD. No persistent
state, public errors, Completion/Result layout or build dependency may change.

Packed cache field cannot receive an ordinary pointer. Root accepts a local
output read only in the non-null owned branch, then assigned to packed dup_fd
before close. Pure tests must exercise this actual production decision, not a
copy. Source proof covers the native failing-kernel branch; no native failure,
resource-exhaustion, invalid-fd, race/leak/cancellation/interleaving experiment.

Acceptance: exact four-file source, behavioral policy red/green clearly labeled
as extracted old policy, pure tests plus unchanged healthy suites, layout/source
integrity, independent review, and a recovery bundle. Maintained publication,
protection, ancestry, ledger and all-four-pin root adoption remain separate.
