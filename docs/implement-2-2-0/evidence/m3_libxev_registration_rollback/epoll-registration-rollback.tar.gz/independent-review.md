# Independent registration rollback review, 2026-10-27

Reviewer /root/review_iocp_cancel_result, read-only. No actionable findings in
the frozen four-file diff. Verified base/tree, four source hashes, diff hash,
all eleven ADD call sites and final evidence. New duplicates including0 are
cleared from packed cache before close on ADD failure; original/cached fds
untouched; connect retains acquisition across WouldBlock. Original errors,
callbacks, counters, layouts and public errors are preserved.

Evidence supports30/30 focused each mode,159pass/4skip healthy each, identical
Linux x64 layout assembly and Windows focused compilation. Reviewer ran no
builds/tests/probes. Pure tests exercise the real production ownership decision,
not a failing kernel ADD or native descriptor-cleanup measurement. Immediate
connect outcomes, old cache semantics, general retirement and root publication/
integration remain outside approval. No stopped experiment was reconstructed.

Root accepts this bounded candidate and its packed-cache stack output. No
persistent state or API/layout changed; the actual shared ADD helper owns the
rollback invariant. Public adoption still requires canonical maintained-fork
publication, protection, ancestry, ledger and all-four-pin integration gates.
