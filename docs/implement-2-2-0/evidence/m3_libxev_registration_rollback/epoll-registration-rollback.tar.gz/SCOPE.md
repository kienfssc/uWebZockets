# Reviewed failed-registration new-duplicate rollback

Local appendc223bd886c6a51d2cd60def39dd9a68d701fea73, parent179f22bc539548e024407b76d4aa39c54342e5b4,
tree86c6944f53dc009d7503a9ab0bc873aef3cd7b79. Four files change actual epoll
acquisition/ADD rollback, its pure internal decision and centralized tests.
All eleven registerable operations carry ownership; connect retains it across
WouldBlock. Only a newly acquired duplicate is taken once, cache invalidated
before close, and the exact ADD error preserved. Original/cached descriptors,
operation fd, dup-request flag, callbacks, counters and layouts remain unchanged.

Independent source review finds no actionable findings. Extracted-old-policy
red28pass/2expectedfailures; final focused30/30 each mode, healthy159pass/4skip
163total each. Linux x64 layout assembly identical; Windows focused compilation
only. The complete-history bundle restores exact commit/tree and strict fsck.
Raw parser-summary mistake is retained; alias-aware corrected extraction binds
all13 values. No source or compiled output changed to repair evidence parsing.

This is not native execution of a failing ADD or descriptor-leak measurement.
No stopped experiment/native fault/cancellation/interleaving/race/leak probe ran.
Immediate connect outcomes, old cache semantics, general lifetime, maintained
publication and root pin adoption remain outside this bounded correction.
