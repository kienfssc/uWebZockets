from pathlib import Path
import hashlib,json,subprocess
root=Path('/workspaces/uWebZockets')
repo=root/'.uwz-work/drafts/libxev-udp-fix'
e=root/'.uwz-work/evidence/epoll-registration-rollback'
f=e/'implementation/final'
base='179f22bc539548e024407b76d4aa39c54342e5b4'
(e/'independent-review.md').write_text('''# Independent registration rollback review, 2026-10-27

Reviewer /root/review_iocp_cancel_result, read-only. No actionable findings in
the frozen four-file diff. Verified base/tree, four source hashes, diff hash,
all eleven ADD call sites and final evidence. New duplicates including0 are
cleared from packed cache before close on ADD failure; original/cached fds
untouched; connect retains acquisition across WouldBlock. Original errors,
callbacks, counters, layouts and public errors are preserved.

Evidence supports30/30 focused each mode,159pass/4skip healthy each, identical
Linux x64 layout assembly and Windows focused compilation. Reviewer ran no
builds/tests/probes. Pure tests exercise the real production ownership decision,
not a failing kernel ADD or native descriptor-cleanup measurement. Immediate
connect outcomes, old cache semantics, general retirement and root publication/
integration remain outside approval. No stopped experiment was reconstructed.

Root accepts this bounded candidate and its packed-cache stack output. No
persistent state or API/layout changed; the actual shared ADD helper owns the
rollback invariant. Public adoption still requires canonical maintained-fork
publication, protection, ancestry, ledger and all-four-pin integration gates.
''')
def run(argv,cwd=repo):
 p=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(str(argv)+': '+p.stdout.decode(errors='replace'))
 return p.stdout
assert run(['git','rev-parse','HEAD']).decode().strip()==base
files=[]
for line in (f/'frozen-source.sha256').read_text().splitlines():
 digest,name=line.split(None,1)
 assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
 files.append(name)
assert set(files)=={'src/backend/epoll.zig','src/backend/epoll_registration.zig','src/tests/epoll_registration_tests.zig','src/main.zig'}
for name in ('policy-debug','policy-release-safe','healthy-debug-unrestricted','healthy-release-safe-unrestricted','abi-compile','abi-compare','abi-values','foreign-windows-pure-compile','fmt-check','whitespace'):
 assert (f/(name+'.status')).read_text().strip()=='0',name
assert (e/'implementation/red/policy-debug.status').read_text().strip()=='1'
assert not run(['git','diff','--cached','--name-only'])
run(['git','diff','--check'])
run(['git','add','--',*files])
assert set(run(['git','diff','--cached','--name-only']).decode().splitlines())==set(files)
(e/'staged.diff').write_bytes(run(['git','diff','--cached','--binary']))
(e/'commit.log').write_bytes(run(['git','commit','-m','uwz(epoll): roll back new duplicates after failed registration']))
commit=run(['git','rev-parse','HEAD']).decode().strip()
tree=run(['git','rev-parse','HEAD^{tree}']).decode().strip()
assert run(['git','rev-parse','HEAD^']).decode().strip()==base
assert not run(['git','status','--porcelain'])
bundle=e/'epoll-registration-rollback.bundle'
(e/'bundle-create.log').write_bytes(run(['git','bundle','create',str(bundle),'HEAD']))
source=e/'source.tar.gz'
source.write_bytes(run(['git','archive','--format=tar.gz','HEAD']))
restore=Path('/tmp/uwz-epoll-registration-bundle-verify')
assert not restore.exists()
restore.mkdir()
run(['git','init','--bare',str(restore)],cwd=root)
for n,cmd in enumerate([['git','bundle','verify',str(bundle)],['git','fetch',str(bundle),'HEAD:refs/heads/candidate'],['git','fsck','--strict','--full']]):
 (e/f'bundle-verify-{n}.log').write_bytes(run(cmd,cwd=restore))
assert run(['git','rev-parse','candidate'],cwd=restore).decode().strip()==commit
assert run(['git','rev-parse','candidate^{tree}'],cwd=restore).decode().strip()==tree
result={'candidate':commit,'parent':base,'tree':tree,'local_branch':'draft/uwz-epoll-registration-rollback',
 'maintained_publication':False,'root_pin_changed':False,'review_agent':'/root/review_iocp_cancel_result',
 'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'bundle_bytes':bundle.stat().st_size,
 'source_archive_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'restored_empty_repository':str(restore),'strict_fsck_exit':0,
 'verification':{'focused_Debug':30,'focused_ReleaseSafe':30,'new_named_tests':4,'healthy_Debug':{'passed':159,'skipped':4,'total':163},'healthy_ReleaseSafe':{'passed':159,'skipped':4,'total':163},'Linux_x64_layout_assembly_identical':True,'Windows_focused_compile_only':True},
 'invariant':'A newly acquired duplicate is taken once and cache invalidated before close on failed ADD; original/cached fds and exact ADD error preserved',
 'retirement':'Drop downstream append only after upstream provides equivalent acquisition rollback',
 'scope':'Only new-duplicate acquisition followed by failed ADD; no kernel-failure execution, old cache/immediate connect outcomes or general lifetime claim'}
(e/'candidate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
