# M1 official static-profile evidence boundary

Re-declaration draft prepared 2026-10-26 UTC for root integration after final
source/gate review. No official validation, benchmark, activation, external
repository change, result publication, or performance measurement was performed
by this audit. No original repository files were edited and no builds ran.

Local coverage update supplied by root after this raw-source audit: the narrow
WOFF2 MIME fix is committed at db92019 with 752 native tests passing; the
independently reviewed fc0587 interop gate proves five 100 MiB downloads (four
curl protocols plus aioquic). These remain separate local correctness results.
Their exact-source archives govern their scope. The immutable external source
and retrieval times below remain the original 2026-10-26 snapshot, and no
official activation or performance evidence is inferred from those local runs.

## Exact external source and retained raw evidence

Repository: https://github.com/MDA2AV/HttpArena

Immutable inspected revision: `d92ece0b27c595cfae0434eb71568e9f7b5bd001`.

The complete [official recursive tree](https://api.github.com/repos/MDA2AV/HttpArena/git/trees/d92ece0b27c595cfae0434eb71568e9f7b5bd001?recursive=1)
was fetched HTTP 200 at 2026-10-26T17:46:10.643779+00:00 through
17:46:11.353065+00:00. It contains 7,668 entries with `truncated: false`.
Its 1,890,879 exact response bytes have SHA-256
`b6f74e436747c381a93da93cab9c4635d86079a45c786ccdfbf9e7f755fe57dd`.
The earlier `/tmp/uwz-httparena-tree.json` contains a filtered 121-path view;
it was not used to infer the existence or absence of static contracts.

Scratch raw artifact root: `/tmp/uwz-httparena-static-boundary/`.

- `official-full-tree.json` and `.fetch.json`: full body, URL, HTTP status,
  retrieval UTC, headers, size, and SHA-256.
- `manifest.json`: the nine profile documents, exact adapter files, validator,
  profile/benchmark drivers, request rotation/URI lists, static generator, and
  client Dockerfiles. Each raw GitHub file returned HTTP 200 and its Git blob
  SHA-1 was independently recomputed and matched the full tree entry. Per-file
  URLs, UTC intervals, statuses, sizes, and SHA-256 values are retained.
- `adapter-three-file-manifest.json`: focused original main/meta/zon evidence.
- `assets-tree-manifest.json`: all 20 official identity paths and available
  sidecar sizes/Git object identities, derived from the full tree and fetched
  URI list. Asset payloads were not individually downloaded by this audit.
- `prior-normalization-comparison.json`: the old main/meta/zon/validate scratch
  files equal the exact new raw bytes plus one terminal newline. This explains
  their different SHA-256 values without inventing an external source change.
- `primary/manifest.json`, `iana-font-woff2.txt`, and `rfc8081.txt`: primary
  font MIME evidence, also fetched HTTP 200 with URL/UTC/SHA-256 metadata.

Focused raw adapter SHA-256 values:

| Exact path at external revision | SHA-256 |
| --- | --- |
| frameworks/uwebzockets/src/main.zig | a4678ad9d7c4edf71bd9a6be313bc22c7ddc663137a6e9e47e1ef2b31b535aa3 |
| frameworks/uwebzockets/meta.json | 1d81c2ea75b74fde83b3c8395b2bd27c682d0eb2119246cd8b01566c5f52c662 |
| frameworks/uwebzockets/build.zig.zon | dca2109cac7656b4609ac901a2ce90e2ed372bc48733246c27e0d37c398ac78d |

## Actual profile contracts

Primary immutable contracts:

- [static-tls implementation](https://github.com/MDA2AV/HttpArena/blob/d92ece0b27c595cfae0434eb71568e9f7b5bd001/site/content/docs/test-profiles/h1/static-tls/implementation.md),
  [validation](https://github.com/MDA2AV/HttpArena/blob/d92ece0b27c595cfae0434eb71568e9f7b5bd001/site/content/docs/test-profiles/h1/static-tls/validation.md).
- [static-h2 implementation](https://github.com/MDA2AV/HttpArena/blob/d92ece0b27c595cfae0434eb71568e9f7b5bd001/site/content/docs/test-profiles/h2/static-h2/implementation.md),
  [validation](https://github.com/MDA2AV/HttpArena/blob/d92ece0b27c595cfae0434eb71568e9f7b5bd001/site/content/docs/test-profiles/h2/static-h2/validation.md).
- [static-h3 implementation](https://github.com/MDA2AV/HttpArena/blob/d92ece0b27c595cfae0434eb71568e9f7b5bd001/site/content/docs/test-profiles/h3/static-h3/implementation.md),
  [validation](https://github.com/MDA2AV/HttpArena/blob/d92ece0b27c595cfae0434eb71568e9f7b5bd001/site/content/docs/test-profiles/h3/static-h3/validation.md).

| Profile | Listener / load generator | Default load shape |
| --- | --- | --- |
| static-tls | HTTPS TCP 8081, HTTP/1.1, wrk + requests/static-rotate.lua | 1,024 connections, pipeline 1, 64 generator threads |
| static-h2 | HTTPS TCP 8443, h2load + requests/static-h2-uris.txt | 256 and 1,024 connections, -m 32, 64 generator threads |
| static-h3 | QUIC UDP 8443, h2load-h3 --alpn-list=h3, same URI list | 64 connections, -m 64, 64 generator threads |

All three default to 5-second samples, three runs with the best selected. The
profile CPU set is `0-31,64-95`; retain the actual selected host/CPU allocation
and any harness overrides. These are contract parameters, not results.
Server-advertised concurrency/capacity remains part of the measured configuration;
do not silently increase library defaults to match a client's requested -m.

The route is `GET /static/*`, rooted in the mounted `/data/static` directory.
All benchmark requests ask for `br;q=1, gzip;q=0.8`. On-disk gzip/Brotli is
allowed through the library's documented static handler; compression is optional.
Entry-built maps, preloaded body buffers, manual mmap caches, or synthetic
responses are disallowed for the Standard entry. Files and selected variants
must follow disk replacement and retain the original file's MIME type.

The 20 assets are reset.css, layout.css, theme.css, components.css, utilities.css,
analytics.js, helpers.js, app.js, vendor.js, router.js, header.html, footer.html,
regular.woff2, bold.woff2, logo.svg, icon-sprite.svg, hero.webp, thumb1.webp,
thumb2.webp, and manifest.json. The exact pinned identity total is 1,271,603
bytes; 15 text files each have gzip and Brotli twins, while the two fonts and
three WebP files have no twins. Assets range from 2,883 to 307,200 bytes.
Use exact mounted files/Git identities rather than the approximate size prose:
the H2/H3 prose has older size estimates than the actual pinned data tree.

The harness mounts `/certs/server.crt` and `/certs/server.key`; real TLS must
present that mounted certificate and negotiate TLS 1.3 with an AEAD cipher.
Do not replace it with the library's ephemeral development certificate.

## Exact validator coverage and its limits

The retained [validator](https://github.com/MDA2AV/HttpArena/blob/d92ece0b27c595cfae0434eb71568e9f7b5bd001/scripts/validate.sh)
reads subscribed names from meta.json and rejects unknown names. Static mounts
are supplied even before subscription. Subscribing selects the required TLS
and TCP/UDP port publication; Docker EXPOSE alone does not start a listener.

- static-tls, lines 2017-2095: mounted-certificate/TLS/AEAD/ALPN posture;
  forced HTTP/1.1 negotiation; CSS/JS/JSON MIME checks; all 20 uncompressed
  lengths; curl --compressed size checks when a coding is present; missing-file
  404; and identity/variant disk-replacement probes. Compression absence is a
  skip, not a compression pass.
- Disk probes, lines 519-616: replace hero.webp or app.js plus existing twins
  with same-length different bytes, then require changed response hashes and
  restoration. The Standard/experimental default tolerance is two seconds.
  The encoded variant probe hashes raw bytes; it does not decode its deliberately
  randomized replacement sidecars.
- static-h2, lines 2101-2129: TLS posture, HTTP/2 readiness, three MIME checks,
  nonempty reset.css, and missing-file 404. Its own section does not verify
  all 20 lengths or coding correctness. Legacy-protocol/weak-cipher quality
  probing occurs in other subscribed TLS sections, not this section itself.
- static-h3, lines 2140-2177: four requests to /static/reset.css over QUIC must
  produce four 2xx responses using the h2load-h3 image. Missing image is an
  explicit skip. H3 content types, exact bytes, and 404 are not checked there;
  the profile documentation points to H2 checks for entries serving both.

There are no static-profile ETag/304, range/If-Range/416, duplicate encoding-field,
late-refusal, or complete qvalue-selection assertions in these sections. The
weighted benchmark header is a workload input, not a full negotiation proof.
An official validator pass therefore cannot be relabeled as coverage of all
M1 representation semantics.

## Current adapter gaps and two explicit compatibility decisions

At the inspected [adapter](https://github.com/MDA2AV/HttpArena/tree/d92ece0b27c595cfae0434eb71568e9f7b5bd001/frameworks/uwebzockets):

- routes() registers baseline/pipeline/JSON/WebSocket routes but no static mount.
- meta.json subscribes to none of static-tls, static-h2, or static-h3.
- build.zig.zon pins v1.8.0 at
  `d94b4e546000455f2ca680d07cb61d032034d5ec`, not the reviewed M1 source.
- tlsMode uses App(5120).init_https on TCP 8081. h3Mode uses
  App(2048).init_http3 but opens only UDP 8443; static-h2 also needs TCP 8443.
- Docker uses Zig 0.16.0 and a ReleaseFast musl build. The existing local
  ReleaseSafe Nix consumer is not evidence that the adapter image was rebuilt.

1. **ALPN documentation/validator mismatch remains open for official activation.**
   static-tls implementation lines 14/38 explicitly require an HTTP/1.1-only
   ALPN policy. The public library's normal init_https/TlsContext.init policy
   selects h2 then HTTP/1.1; the external adapter already uses that constructor
   on 8081. Validator tls_posture_probe offers only HTTP/1.1 and accepts that
   selection (or none), and its profile negotiation check forces HTTP/1.1.
   Thus a passing validator cannot prove the stricter documentation wording.
   Preserve the normal public TLS policy; do not add an ALPN interface or
   mutate raw BoringSSL internals for this benchmark. An authorized maintainer
   must resolve/accept the official contract interpretation before claiming
   complete profile conformance.
2. **WOFF2 MIME was a concrete library compatibility gap resolved by root's
   narrow local M1 polish.** The official H3 contract lines 18-19 requires correct
   Content-Type across the listed assets and line 37 names both WOFF2 files.
   [IANA](https://www.iana.org/assignments/media-types/font/woff2) and
   [RFC 8081 section 4.4.6](https://www.rfc-editor.org/rfc/rfc8081.html#section-4.4.6)
   register font/woff2 for .woff2, with no required/optional parameters.
   The contract does not spell out that literal media type: the mapping is
   inferred from its named font assets and the authoritative registration.
   The original inspected static mime_type fell back to application/octet-stream
   for that extension. The official validator checks only CSS/JS/JSON, so it
   would not detect this gap. Root reports the isolated .woff2 mapping and
   centralized regression at db92019, with 752 native tests passing. Matching
   sanitizer/target evidence remains owned by the final-source gate record.
   This audit did not implement or run that patch; no full official-contract
   conformance claim is made.

Some TLS static documents link to a legacy h1/static contract absent from the
complete tree. Do not infer a replacement contract from the earlier filtered
tree or silently treat approximate prose as exact assets. Retain the actual
three contracts, driver code, and request/data manifests above.

## Concrete future adapter recipe using the public library

This is an unexecuted authorized-maintainer recipe, not a patch or activation.

1. Make the reviewed original-repository source available at an immutable full
   40-hex commit or release without creating a fork. Update the external
   adapter's Zig URL and actual Zig fetch hash together; preserve Zig 0.16.0
   and do not invent a package hash or patch zig-pkg/vendor sources.
2. Add the existing public mount during each App/worker's route setup:

   ```zig
   _ = try app.static("/static", "/data/static", .{ .precompressed = true });
   ```

   Handler allocation is startup-only and worker-local. Let the library own
   confinement, coding selection, validators/ranges, descriptor transfer, and
   source MIME. Do not read the mounted directory into adapter-owned caches.
   Record actual source/sidecar mtimes and selected codings; never pretend a
   stale sidecar is fresh by altering metadata merely to obtain compression.
3. Keep TLS 8081 and its mounted credentials. In h3Mode, register all routes
   before startup and use the same stable public init_http3 App for TCP 8443
   and UDP 8443 via listen and listen_udp, with the existing owned cleanup on
   failure. This supplies h2 and h3 with separate protocol contexts. It does
   not create a new cross-protocol atomic startup guarantee. Preserve existing
   unrelated endpoints and budgets; report actual negotiated stream limits.
4. Add exactly the three static names to meta.json.tests. Preserve Standard
   classification and existing profile subscriptions. Resolve the ALPN
   interpretation and verify the narrow WOFF2 fix first.
5. In an owned local checkout of the pinned external harness, rebuild its
   adapter image and run `./scripts/validate.sh uwebzockets`. Retain the command,
   complete stdout/stderr, exact source/pins/image identities, counts, and
   separate skip/failure statuses. Ensure h2load-h3 exists so QUIC checks run;
   zero failures with skipped H3 is not H3 validation. Preserve data restoration.
6. Only an authorized official operator on the designated host runs all three
   saved profiles and archives official generated results under the plan's
   evidence contract:

   ```sh
   ./scripts/benchmark.sh uwebzockets static-tls --save
   ./scripts/benchmark.sh uwebzockets static-h2 --save
   ./scripts/benchmark.sh uwebzockets static-h3 --save
   ```

   The pinned driver defaults SAVE_RESULTS=false; without --save it explicitly
   reports a dry run and does not save results or capture the result's Docker
   logs. Retain complete stdout/stderr and all raw samples in addition to the
   saved generated output. These are future authorized-maintainer actions;
   no command was run here. Do not manually fill result JSON, publish local
   substitutes, or use a shared-runner sample as quiet-host data.

Record actual generator binaries/versions, container digests, TLS settings,
CPU topology/affinity/SMT/quota, kernel/backend, optimizer, worker/connection/
stream capacities, warmup, all samples, spread/medians, CPU/RSS, latency and
raw output. The official driver chooses best-of-three; preserve that official
statistic and separately retain the plan's sample/median evidence. The pinned
H3 Dockerfile still clones nghttp3/ngtcp2 without immutable refs and uses tags
for other components, so its source commit alone does not pin built client
bits. Capture actual resolved commits/image digest; do not substitute the local
pinned curl/aioquic versions for official h2load/wrk identities.
External load-generator build tools remain the external harness's requirements;
they must not become requirements of the native Zig library build.

## Relationship to the public local consumer

`tests/static_interop` already uses public App/static/listener/run/shutdown
interfaces. Its `/files` route enables precompressed and `/identity` preserves
the default. It uses owned generated fixtures and App(8), not the official
20-asset mount, official route prefix, full load shape, or adapter image.

Its contract covers 104,857,600-byte exact transfers over plaintext H1, TLS H1,
TLS H2, and live H3; reuse; incremental byte/hash checks; valid gzip/Brotli
decode; source MIME; HEAD; distinct coding ETags; identity/encoded 304; encoded
ranges and If-Range; 416 selected lengths; refusal and duplicate encoding fields.
Live aioquic adds H3 large-file/sibling/reuse proof. Pinned curl/ngtcp2/nghttp3/
aioquic identities, bounded comparison slices, qlogs, and shutdown evidence are
part of that consumer's own artifact contract.

Root reports the independently reviewed fc0587 static gate completed with five
100 MiB downloads (four curl protocols plus aioquic), 84 small checks, sibling
and reuse proof, and clean shutdown. This audit did not rerun or independently
audit that live result. Root's final exact-source archive must supply its
canonical link; the earlier tracked harness/build-only manifest alone is not
that live proof. The db92019 MIME checkpoint has 752 native passes per root;
matching final-source sanitizer/target results must retain their own identity.
Earlier frozen results remain evidence for their checkpoint. None of these
local results activates or measures an official HttpArena profile.

## Dated re-declaration and restoration ownership

Re-declare official static-tls, static-h2, and static-h3 activation/performance
evidence on 2026-10-26, separately from implemented local static correctness.
The original plan permits explicit re-declarations with raw evidence, linked
reasons, owner/date, and a restoration criterion; it does not permit silently
dropping the evidence requirement.

Blocking evidence: the immutable adapter lacks the route/subscriptions and
reviewed pin; retained permissions observed 2026-10-26T13:04:13Z are pull=true,
push=false (admin/maintain/triage=false), recorded in the existing 8gbit
provenance. Root reports original-repository push 403 persists, so the reviewed
source is not yet fetchable there. No official run, approved designated-host
artifact, or complete adapter validation is available to this audit. No write
probe was attempted. Keep the ALPN interpretation explicit and finish matching
final-source verification for the committed narrow MIME fix; re-declaration
is not a substitute for local implementation or its required evidence.

Owner: root integrator and verification, with the original-repository and
HttpArena maintainers controlling publication/adapter/official-run authority.
http_protocol owns MIME/representation correctness; crypto_tls reviews any
ALPN interpretation; dx_router reviews the public adapter/lifecycle setup.

Restore only after all of the following are recorded:

1. Exact reviewed original source is publicly fetchable with its actual Zig
   hash; required local MIME/native/sanitizer/target gates match that source.
2. An authorized external maintainer applies/reviews the public-only adapter
   route/listener/subscription/pin change and resolves contract interpretation.
3. Official validation runs all required sections without substituting skipped
   H3 or compression for proved capability; raw commands/statuses are retained.
4. The designated official host runs all three profiles with complete immutable
   source, image/client, host/configuration, correctness, and sample artifacts.

This restores only the specific external evidence claim. Root still owns M1's
remaining canonical gates, independent review, final archive, and milestone
decision. No GitHub fork, issue, PR, remote write, external result edit, or
performance claim is authorized or performed by this preparation.
