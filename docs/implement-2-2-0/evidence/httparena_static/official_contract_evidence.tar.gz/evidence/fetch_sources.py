import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import sys
import urllib.error
import urllib.request


ROOT = Path('/tmp/uwz-httparena-static-boundary')
COMMIT = 'd92ece0b27c595cfae0434eb71568e9f7b5bd001'
TREE = json.loads((ROOT / 'official-full-tree.json').read_text())
ENTRIES = {entry['path']: entry for entry in TREE['tree']}
PATHS = [path for path in ENTRIES if path.startswith('site/content/docs/test-profiles/') and any('/' + profile + '/' in path for profile in ['static-h2', 'static-h3', 'static-tls']) and ENTRIES[path]['type'] == 'blob']
PATHS += [
    'frameworks/uwebzockets/src/main.zig',
    'frameworks/uwebzockets/meta.json',
    'frameworks/uwebzockets/build.zig.zon',
    'frameworks/uwebzockets/build.zig',
    'frameworks/uwebzockets/Dockerfile',
    'scripts/validate.sh',
    'scripts/lib/profiles.sh',
    'scripts/generate_static.py',
    'scripts/benchmark.sh',
]
if len(sys.argv) > 1:
    PATHS = sys.argv[1:]


def fetch(path):
    url = f'https://raw.githubusercontent.com/MDA2AV/HttpArena/{COMMIT}/{path}'
    record = {'path': path, 'url': url, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'expected_git_blob_sha1': ENTRIES[path]['sha']}
    request = urllib.request.Request(url, headers={'User-Agent': 'uwz-read-only-source-audit'})
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            body, status, headers = response.read(), response.status, dict(response.headers)
    except urllib.error.HTTPError as response:
        body, status, headers = response.read(), response.code, dict(response.headers)
    except urllib.error.URLError as error:
        body, status, headers = str(error).encode(), None, {}
    target = ROOT / 'raw' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(body)
    actual_blob = hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    record.update({'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'http_status': status, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest(), 'actual_git_blob_sha1': actual_blob, 'git_blob_verified': actual_blob == ENTRIES[path]['sha'], 'headers': headers})
    return record


with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    records = list(executor.map(fetch, PATHS))
previous = json.loads((ROOT / 'manifest.json').read_text())['artifacts'] if (ROOT / 'manifest.json').exists() else []
merged = {record['path']: record for record in previous}
merged.update({record['path']: record for record in records})
manifest = {'external_repository': 'https://github.com/MDA2AV/HttpArena', 'external_commit': COMMIT, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'tree': json.loads((ROOT / 'official-full-tree.fetch.json').read_text()), 'tree_entries': len(TREE['tree']), 'tree_truncated': TREE['truncated'], 'artifacts': list(merged.values())}
(ROOT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
for record in records:
    print(record['http_status'], 'verified=' + str(record['git_blob_verified']), record['path'], record['sha256'])
if any(record['http_status'] != 200 or not record['git_blob_verified'] for record in records):
    raise SystemExit(1)
