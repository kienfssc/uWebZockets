from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,re,tarfile
root=Path('/workspaces/uWebZockets')
e=root/'.uwz-work/evidence/h2-body-refusal/v6'
draft=root/'.uwz-work/drafts/m2-h2-body-refusal'
dest=root/'docs/implement-2-2-0/evidence/m2_h2_refusal_reset'
dest.mkdir(parents=True,exist_ok=True)
bindings={'src/http2/server.zig':'409ab150d27df52c86fde9742daca1b59c822cd214a3c72a6d19889064a50205','src/tests/body_h2_refusal_tests.zig':'5e4de2c3841444dc89b23be6c5f66abaede297328d063739f652c5243de806b2'}
for name,digest in bindings.items():
 assert hashlib.sha256((draft/name).read_bytes()).hexdigest()==digest,name
summary=json.loads((e/'summary.json').read_text())
for name,item in summary['checks'].items():
 assert item['source_stable'],name
 expected=1 if name=='reset-write-red' else -31 if name=='width-x86-linux-musl-run-sandbox' else 0
 assert item['exit_status']==expected,name
assert summary['linux32_compile_run_binary_identical'] and summary['native_compile_run_binary_identical']
scope='''# Reviewed H2 reset-writer error correction

Reconstruct the earlier m2_transport_preparation App/H2 draft and apply the
m2_h2_refusal checkpoint (SHA256 af0afe5e2e220a75701a6d6e0ef6165970c9582c2862dd1958e46e09ea804c17),
then replace exactly the two files in this archive's overlay/src/ at matching
source paths. Other v5 sources remain unchanged. This is still an isolated
component, not a combined production tree or a complete upload driver.

Fresh review found that clearing a stream during final-response/reset emission
could reset response_started before OutputTooSmall reached the recovery catch.
The old catch retried and hid that writer error. Recovery now requires the
same original active stream with an unstarted response; other errors propagate.
The new actual bounded memory-writer regression fails before this guard and
passes afterward, asserting one reset-write attempt and retained reset intent.

Independent re-review resolves P2 with no new actionable findings. Focused15
and unchanged protocol69 pass each Debug/ReleaseSafe; native/Linux32 width
executables run seven cases each. Initial Linux32 SIGSYS and missing-rg failures
remain separate. No tests/gates were weakened. Live v5 evidence is historical;
no v6 live-client check or combined/full production gate ran. No native fault,
cancellation/interleaving/race/leak/kernel-error probe was constructed or run.
'''
review='''# Independent H2 review and correction, 2026-10-27

Reviewer /root/review_h2_refusal_final, read-only.
Initial frozen v5 review confirmed hashes/results and found one P2: final
HEADERS -> finish_local -> send_reset clears stream/response_started before
RST writer error, so catch can retry and hide OutputTooSmall. No other findings.

V6 re-review: P2 resolved, no new actionable findings. Guard re-finds the
original active stream before reading state, preserving reset-writer errors
after slot removal. Actual regression verifies one reset-write attempt.
Frozen source and behavioral red/green match. Focused15/15, unchanged69/69
both modes, native/Linux32 seven-case execution verified. Linux32 sandbox
SIGSYS retained separately; normal-OS run uses identical binary. Formatting,
conventions/version pass. Reviewer ran no builds/tests/probes. V6 live checks
and combined production integration remain unrun.

Root accepts the bounded isolated correction. No interfaces, layouts, persistent
state, allocation, framing, flow-credit or reset-queue algorithm changed.
'''
retained={'SCOPE.md':scope.encode(),'independent-review.md':review.encode(), 'package_v6.py':Path(__file__).read_bytes()}
omitted={}
for p in sorted(e.rglob('*')):
 if not p.is_file():continue
 name=p.relative_to(e).as_posix()
 data=p.read_bytes()
 if p.name.startswith('bin-') or data.startswith(b'\x7fELF'):
  omitted[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  continue
 assert not p.is_symlink(),name
 retained['evidence/'+name]=data
for name in bindings:retained['overlay/'+name]=(draft/name).read_bytes()
retained['omitted-binaries.json']=(json.dumps(omitted,indent=2)+'\n').encode()
values=[v.encode() for k,v in os.environ.items() if re.search(r'(?:TOKEN|SECRET|PASSWORD|CREDENTIAL|API_KEY)$',k) and len(v)>=20]
pattern=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})')
for name,data in retained.items():
 assert not any(v in data for v in values),name
 assert not pattern.search(data),name
inventory={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in retained.items()}
retained['inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
archive=dest/'h2-reset-writer-correction.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(retained.items()):
    info=tarfile.TarInfo(name); info.mode=0o644; info.size=len(data); info.mtime=0
    tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():
  name=PurePosixPath(member.name)
  assert member.isfile() and not name.is_absolute() and '..' not in name.parts
  assert tar.extractfile(member).read()==retained[member.name]
manifest={'date':'2026-10-27','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'safe_regular_members':len(retained),'inventory_entries':len(inventory),'base_checkpoint_sha256':'af0afe5e2e220a75701a6d6e0ef6165970c9582c2862dd1958e46e09ea804c17','source_sha256':bindings,'reviewer':'/root/review_h2_refusal_final','verdict':'P2 resolved; no new actionable findings','scope':'Isolated H2 refusal error correction; no live v6 or combined integration claim','omitted_derived_binaries':omitted,'credential_scan':'All retained bytes checked against credential values and GitHub token patterns','files':inventory}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('archive_sha256','archive_bytes','safe_regular_members','inventory_entries')},indent=2))
