from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

out = Path(__file__).resolve().parent
label, kind, mode = sys.argv[1:4]
source_record = json.loads((out.parent / 'v2/expanded-Debug.command.json').read_text())
draft = Path(source_record['cwd'])
paths = [
    'src/http2/server.zig',
    'src/tests/body_h2_refusal_tests.zig',
    'src/http2/connection.zig',
    'src/core/tcp.zig',
    'src/tests/http2_server_tests.zig',
    'src/tests/body_h2_width_tests.zig',
    'src/h2_width_support.zig',
]

def hashes():
    return {path: hashlib.sha256((draft / path).read_bytes()).hexdigest() for path in paths}

if kind in ('focused', 'legacy'):
    module = 'src/tests/body_h2_refusal_tests.zig' if kind == 'focused' else 'src/tests/http2_server_tests.zig'
    argv = [
        '-O' + mode if arg == '-ODebug' else
        '-Mroot=' + module if arg.startswith('-Mroot=') else
        '-femit-bin=' + str(out / ('bin-' + label)) if arg.startswith('-femit-bin=') else arg
        for arg in source_record['argv']
    ]
    argv.append('-j2')
    if len(sys.argv) == 5:
        argv.extend(['--test-filter', sys.argv[4]])
elif kind == 'width':
    width_record = json.loads((out.parent / 'v4' / ('width-' + mode + '-compile.json')).read_text())
    argv = [
        '-femit-bin=' + str(out / ('bin-width-' + mode)) if arg.startswith('-femit-bin=') else arg
        for arg in width_record['argv']
    ]
    argv.append('-j2')
elif kind == 'width-run':
    argv = [str(out / ('bin-width-' + mode))]
else:
    raise SystemExit('unknown check kind: ' + kind)

record = {'argv': argv, 'cwd': str(draft), 'source_before': hashes()}
(out / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
with (out / (label + '.log')).open('wb') as log:
    result = subprocess.run(argv, cwd=draft, stdout=log, stderr=subprocess.STDOUT)
record.update(exit_status=result.returncode, elapsed_seconds=time.monotonic() - started, source_after=hashes())
binary = Path(argv[0]) if kind == 'width-run' else next((Path(arg.split('=', 1)[1]) for arg in argv if arg.startswith('-femit-bin=')), None)
if binary is not None and binary.is_file():
    record['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
(out / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print((out / (label + '.log')).read_text(), end='')
print('Exit status:', result.returncode)
raise SystemExit(result.returncode)
