cwd: /workspaces/uWebZockets/.uwz-work/drafts/m2-h2-body-refusal
command: /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check src/http2/server.zig src/tests/body_h2_refusal_tests.zig
