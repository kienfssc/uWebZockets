# H2 refusal P2: preserve reset writer failures

The two owned source files are frozen for independent re-review. No staging,
commits, ref changes, publication, dependency pins, root production changes,
other draft changes, or libxev clone changes were performed for this slice.

## Change and source identity

Draft: `/workspaces/uWebZockets/.uwz-work/drafts/m2-h2-body-refusal`.
The preimages match the independently reviewed v5 source hashes exactly.
This directory inherits the root Git worktree; Git status is not its source
delta. `final/complete.diff` is a direct labeled diff against the retained
two-file preimage, not a root Git diff.

| Source | v5 preimage SHA256 | Frozen v6 SHA256 |
| --- | --- | --- |
| `src/http2/server.zig` | `b00ec88570364a09074e3d9bb16ccabbb989ec1876516ba2e57bb9a874d655bf` | `409ab150d27df52c86fde9742daca1b59c822cd214a3c72a6d19889064a50205` |
| `src/tests/body_h2_refusal_tests.zig` | `71573008cc795577d0c5cf5c1abab57cbf9eebcf0d16315f4f1b87698831edff` | `5e4de2c3841444dc89b23be6c5f66abaede297328d063739f652c5243de806b2` |

Diff SHA256: `31775c7ce58b1dd161ac4d22a95a126bc3a46e219bd3ebedf8eb0edd5690f33c`.
Snapshots and manifests are retained in `preimage/`, `red/`, and `final/`.
The manifests also bind unchanged connection, TCP callback, 69-case protocol,
width test, and width-support source files.

The production change is limited to the header-refusal `send_response` catch
at `src/http2/server.zig:1306`. Capacity recovery now requires all of:

1. The original error is `ResponseHeadersTooLarge` or `OutputTooSmall`.
2. The original stream ID can still be found as an active stream.
3. The active stream is still in the same slot, and its response has not started.

Otherwise the original error propagates. Existing pre-generation capacity
failure still takes the same stream-local INTERNAL_ERROR reset path. No
production interface, persistent state, helper, layout, allocation, framing,
output ordering, flow-credit or reset-queue algorithm changed.

## Why the guard is safe after close/reset

`send_reset` can release the stream slot and call `clear_stream` before
attempting the queued RST write. `clear_stream` resets `response_started` to
false, so that flag alone cannot identify a pre-generation failure.

The new guard calls `streams.find(stream_id)` before reading response state.
`find` iterates the fixed `active` and `stream_ids` arrays and only returns an
active matching index (`connection.zig:189-193`). The returned index is bounded
by the same `max_streams` used for `response_started: [max_streams]bool`
(`server.zig:539`). Missing, reset, or closed streams return the original error
without any response-state read. If a different slot is returned, short-circuit
`or` returns the error before reading its response state. The catch never
indexes `response_started` with the stale original slot.

## Behavioral failing-first test

The new test uses the existing bounded in-memory Fixture and ordinary
caller-owned write ring. Its synthetic writer accepts final HEADERS, then
returns `OutputTooSmall` on the first RST write only. It would accept a second
RST write, making the old retry-and-hide behavior observable.

Before the production fix, the test executed and failed with
`expected error.OutputTooSmall, found void`: 0 passed, 1 failed, exit 1.
This was an actual behavior failure in the production catch, not a compile or
declaration failure. `reset-write-red.json` records the unchanged v5 server
hash and the new test hash before and after execution; `red/` retains both
sources.

After the minimal guard repair, the same named test passed. It asserts:

- `OutputTooSmall` propagates to the caller.
- The writer receives exactly one RST attempt.
- Output contains the accepted 503 final HEADERS and no RST bytes.
- The existing reset intent remains queued, and the original stream is removed.
- No application sink effect occurs.

The existing hard-HEADERS-write failure and both pre-generation capacity
recovery tests remain present and pass. There are now 15 focused tests.

## Commands actually run and outcomes

`verify.py` follows the v5 command pattern and records full compiler argv,
working directory, elapsed time, actual exit status, source hashes before and
after each run, and emitted/executed binary hashes. It starts from the existing
`v2/expanded-Debug.command.json` module graph and `v4/width-*-compile.json`
width graph; all compiler invocations use the exact Zig 0.16.0 compiler
`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`, `-j2`,
and existing caches. No native dependency/toolchain rebuild was added.

| Record | Exact driver invocation suffix after `python3 .../v6/verify.py` | Outcome |
| --- | --- | --- |
| `reset-write-red` | `reset-write-red focused Debug 'refusal propagates reset writer errors after final headers'` | Exit 1; expected behavioral failure |
| `reset-write-green` | `reset-write-green focused Debug 'refusal propagates reset writer errors after final headers'` | Exit 0; 1/1 |
| `focused-Debug-final` | `focused-Debug-final focused Debug` | Exit 0; 15/15 |
| `focused-ReleaseSafe-final` | `focused-ReleaseSafe-final focused ReleaseSafe` | Exit 0; 15/15 |
| `legacy-http2-Debug-socket-access` | `legacy-http2-Debug-socket-access legacy Debug` | Exit 0; unchanged 69/69 |
| `legacy-http2-ReleaseSafe-socket-access` | `legacy-http2-ReleaseSafe-socket-access legacy ReleaseSafe` | Exit 0; unchanged 69/69 |
| `width-native-compile` | `width-native-compile width native` | Exit 0; newly compiled v6 binary |
| `width-native-run` | `width-native-run width-run native` | Exit 0; 1 named test, 7 cases, actual execution |
| `width-x86-linux-musl-compile` | `width-x86-linux-musl-compile width x86-linux-musl` | Exit 0; newly compiled v6 Linux32 binary |
| `width-x86-linux-musl-run-sandbox` | Original label `width-x86-linux-musl-run width-run x86-linux-musl` | Child status -31 / SIGSYS before test output |
| `width-x86-linux-musl-run-normal-os` | `width-x86-linux-musl-run-normal-os width-run x86-linux-musl` | Exit 0; same binary, 1 named test, 7 cases, actual execution |

Both unchanged protocol modes used approved normal local-socket access.
The first Linux32 execution was restricted; its raw record is retained
separately. Running the same already compiled pure-memory binary with normal
OS access succeeded. No new syscall or native diagnostic probe was created.

Additional checks have raw `.command`, `.log`, and `.status` records:

- `fmt`: `zig fmt src/http2/server.zig src/tests/body_h2_refusal_tests.zig`, exit 0;
  no formatter changes.
- `fmt-check`: the same two paths with `zig fmt --check`, exit 0.
- `conventions-no-rg`: unchanged `sh scripts/check_conventions.sh`, exit 1;
  the draft shell could not find `rg`.
- `conventions`: unchanged convention script with the existing workspace
  Codex `rg` directory added to PATH, exit 0. The exact environment is in
  `conventions.command`; no script or rule changed.
- `release`: `sh scripts/check_release_version.sh`, exit 0; metadata matches 2.1.6.
- `frozen-integrity`: `sha256sum --check final/frozen-source.sha256`, exit 0.

## Remaining limits

Independent re-review is still required before root archives or publishes this
draft. This slice did not repeat the live client check or perform an unrelated
full root build. No new native cancellation, fault, interleaving, race, leak,
crash, or kernel-error probe was constructed or run. The new writer failure is
bounded synthetic memory behavior only. Root retains integration, graph refresh,
archiving, commits, publication and dependency-pin decisions.
