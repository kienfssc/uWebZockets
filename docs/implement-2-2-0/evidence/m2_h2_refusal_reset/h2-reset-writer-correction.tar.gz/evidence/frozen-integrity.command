cwd: /workspaces/uWebZockets/.uwz-work/drafts/m2-h2-body-refusal
command: sha256sum --check /workspaces/uWebZockets/.uwz-work/evidence/h2-body-refusal/v6/final/frozen-source.sha256
