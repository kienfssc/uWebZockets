cwd: /workspaces/uWebZockets/.uwz-work/drafts/m2-h2-body-refusal
command: sh scripts/check_conventions.sh
