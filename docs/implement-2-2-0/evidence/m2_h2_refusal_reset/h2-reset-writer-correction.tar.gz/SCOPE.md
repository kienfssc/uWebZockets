# Reviewed H2 reset-writer error correction

Reconstruct the earlier m2_transport_preparation App/H2 draft and apply the
m2_h2_refusal checkpoint (SHA256 af0afe5e2e220a75701a6d6e0ef6165970c9582c2862dd1958e46e09ea804c17),
then replace exactly the two files in this archive's overlay/src/ at matching
source paths. Other v5 sources remain unchanged. This is still an isolated
component, not a combined production tree or a complete upload driver.

Fresh review found that clearing a stream during final-response/reset emission
could reset response_started before OutputTooSmall reached the recovery catch.
The old catch retried and hid that writer error. Recovery now requires the
same original active stream with an unstarted response; other errors propagate.
The new actual bounded memory-writer regression fails before this guard and
passes afterward, asserting one reset-write attempt and retained reset intent.

Independent re-review resolves P2 with no new actionable findings. Focused15
and unchanged protocol69 pass each Debug/ReleaseSafe; native/Linux32 width
executables run seven cases each. Initial Linux32 SIGSYS and missing-rg failures
remain separate. No tests/gates were weakened. Live v5 evidence is historical;
no v6 live-client check or combined/full production gate ran. No native fault,
cancellation/interleaving/race/leak/kernel-error probe was constructed or run.
