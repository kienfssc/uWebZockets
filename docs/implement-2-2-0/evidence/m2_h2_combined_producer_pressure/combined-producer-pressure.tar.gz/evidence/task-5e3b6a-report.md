# Task5e3b6a producer reuse and response pressure

Three concrete combined schedules are implemented: `producer_reuse`, `output_pressure_window`, and `output_pressure_ready`. This is **34/40 source schedules**, subject to Root's independent review. It is pure, in-memory public-codec preparation; supplied body records and producer diagnostics are synthetic model-derived inputs. No native callback, fixture execution, post-deinit comparison, runtime closure, or combined40 acceptance is claimed.

The unchanged all40/2.2.0 milestones remain required. The six unimplemented selections are `shutdown_idle`, `disconnect`, `reuse`, `stream_file`, `early_final_order`, and `shutdown_active`; each still rejects before caller effects. The original nine B6 cases remain in the full milestone scope: this unit implements three of them.

## Authorities and ownership

The requirements are `task-5e3b6a-brief.md`, its release addendum and original pending-cases brief, plus the parent clarification to retain final diagnostics and the relative B binding. The baseline is the reviewed/pushed `f3919fe407953c75693144cbae0f81b5b6c16983`, whose public application-error manifest supplied the exact27-module map. The initial audit matched every live module to that map before saving `evidence/b6a/before-source/` and `before-map.json`.

Only the owned combined-case modules, their local `evidence/b6a/`, and this report were changed. There were no agents, external model CLI, Git operations, product/core/model/fixture/dependency/public edits, native builds, old live/runtime/constructor/close entrypoints, sockets, SSLContext operations, real clocks, process ownership, transfer, kernel/descriptor, scheduling, fault, race, panic, or leak experiments. Negative controls below are serialized synthetic input changes only.

The authoritative source-only family references were the authenticated output contracts `/tmp/uwz-task5d1-round3-current/contracts.py`; current `/tmp/uwz-task5d3-runtime-v5/{cases,diagnostics,records,post,case_adapter}.py`; and `/tmp/uwz-task5d2-fix2-final-snapshot/{profile,output}.zig`. The v5 schedules fix primary3 versus5 and the exact status/output/B-binding request order. The source fixture releases the body slot before starting output, captures the binding index/generation and request metadata separately, and increments the reused slot generation. The current model/catalogue schemas and canonical wire supersede all legacy aliases and direct ledger operations. No old family entrypoint was invoked.

Immutable execution inputs:

- Model/catalogue: `/tmp/uwz-task5e1-contract-v3`.
- Core: `/tmp/uwz-task5e3a-snapshot-v9/source`, all26 files unchanged.
- Compiled-only fixture source: `/tmp/uwz-task5e2-Fix1Final2/fixture`, all25 files unchanged; no fixture operation was run.
- Helper: `.uwz-work/evidence/h2-streaming/integration-client/h2_client.py`, SHA256 `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`.
- Interpreter: `/home/codespace/.python/current/bin/python3`, SHA256 `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`. Every direct Python invocation used `-B -S`; optimized tests additionally used `-O`.
- Codec root: `/tmp/uwz-h2-client-tooling/packages`, exactly42 ordered retained rows, including licenses, metadata and type markers. Default-JSON aggregate SHA256 is `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`, calculated as `hashlib.sha256(json.dumps(rows).encode()).hexdigest()` without changing row order or separators.

`evidence/b6a/immutable-inputs.json` preserves the complete inherited row map and ordered42 codec rows. The final audit rehashed all118 file rows, checked every length, resolved aliases, and rejected extra/missing non-cache codec paths. There are **119 retained identity rows / 114 unique entries**: **118 file rows / 113 unique resolved files**, plus the codec aggregate. These are retained rows, not119 distinct files. No identity was edited to accommodate a mismatch.

The exact prescribed Graphify prefix ran before the first source search/read:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "combined-cases adapter cases serialized pressure producer tests" --budget 650
```

It exited0 and returned a coarse650-token subgraph. The brief already located the relevant source paths. The final `graphify update .` used the same prefix, exited0, and reported no relevant graph changes; these ignored harness paths are outside its detected changes. Its raw stdout/stderr/exit are retained in `evidence/b6a/graphify-update.*`.

## Changed files and used APIs

All29 directly owned source modules are under `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`.

- Added `producer_pressure_cases.py`: concrete two-ACK setup, canonical grants, body/output barriers, held/prefix checks, reuse generation validation, paired ready completion, and final diagnostic retention.
- Added `test_producer_pressure.py`: independent serialization decoder, finite synthetic peer, bounded producer generator, shared application across fresh codecs, exact counters/debt, retained outputs/binding, final67+metrics, and focused negative controls.
- Changed `adapter.py`: configure `expected_acks=2` for catalogue output cases; bind `producer_reuse` primary to stream3; dispatch the three schedules; extend the actually used `start` signature with `mode` and `expected_sha256`; issue canonical once-only auxiliary grants for small streams only when the output schedule has initialized its canonical grant policy and stream initial window is0; omit `body` from hash-only `finish` results after `wire.complete` verifies length/hash/END. Existing small-body, cancellation, peer-reset, refusal and application-failure policies retain their defaults.
- Changed `cases.py`: implemented selection31->34 and accurate34-case module description.
- Changed `test_imports.py`: include the two new modules in the exact inventory and real inert-import proof.
- Changed `test_pause.py`, `test_admission.py`, `test_continue_quota.py`, `test_metadata_concurrency.py`: authorized explicit unsupported inventory9->6, retaining all rejection loops. Metadata/concurrency output now says6.

There are **2 added, 7 changed, 20 byte-identical, 0 removed** modules against B5d. `evidence/b6a/snapshot.json` has every29 hash and the exact comparison; `before-source/`, `final-source/`, and `source.diff` preserve the reviewable bytes. No existing schedule was rewritten.

The actual used immutable seams are `wire.update_settings`, `new_grants`, `grant`, `start_request`, `send_data`, `accept`, `drain`, `complete`, `retire`, `enter_final`, and `finish_final`, with bound raw observer, request ledger, response ledger and output stage. Used model functions are `request_contract`, `payload_span`, `digest`, `record`, `validate_item`, `validate_producer`, `validate_progress`, and `validate_reuse_binding`; tests additionally use the output/binding pre/post validators solely to prove caller-owned snapshot survival through synthetic final collection.

The invariant-bearing constructors/checks add exact metadata, special role/hash, earned grants, held/prefix/completion and sibling guarantees. They add no alternate parser, second expected-state model, forwarding-only adapter, automatic consumption/refund, direct credit surgery, capacity change or budget/deadline relaxation. Every action/read/drain/final boundary checks fresh caller-supplied integer time using the inherited case/whole deadlines. There is no real-time read.

After all required validation, final diagnostics remain in `context['output_observations'][case]`; the validated B diagnostic remains in `context['output_binding']`. They contain the actual supplied/parsed values, including relative generation, with no extra observation requests. The caller's shared test application carries these maps across fresh connection contexts and through final collection. These retained inputs are ready for a later authorized post-deinit comparison; this unit does not perform that native comparison.

## Exact schedules and bounds

| Case | J | C | R | Primary | Initial stream window | Special stream grants |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| producer_reuse | 9 | 8 | 64 | 3 | 0 | 16777313 |
| output_pressure_window | 8 | 7 | 33 | 5 | 0 | 8192,16769121 |
| output_pressure_ready | 6 | 5 | 33 | 5 | 33554432 | none |

All cases consume exactly the already-initiated helper codec startup, accept the canonical peer initial SETTINGS and first ACK, send exactly one output SETTINGS update, and require the second actual parsed ACK before any grant/request. The connection bootstrap is exactly once, stream0, purpose`bootstrap`, amount`33554432-credit.connection` (33554432-65535 in these tests). Every auxiliary small stream under initial0 gets its single65535 purpose`auxiliary` grant; ready receives no per-stream grants. The canonical policy, not a second allowance model, validates these actions.

Producer responses have exactly16777313 bytes and SHA256 `e5b7e8c5bbad59c7bc86f18236a37661571e972f65c707d7dc1902386ec5e91d`. Bodies are generated in canonical spans<=8192; the client retains only count/hash and bounded small observations. No whole producer response or per-frame/read history is stored. The synthetic peer counts2049 positive DATA frames, incrementally hashes their bytes, and returns serialized reads<=8192. Exact unchanged catalogue budgets are retained in `evidence/b6a/contracts.json`.

`producer_reuse`: initial health1, producerA3 canonical32+END, complete body status5, held offset0 output7 and no-DATA/END/reset checkpoint; next uploadB9 canonical32+END and complete persistent body record; held A output11 and monotonic diagnostics/checkpoint; B binding13 with the same binding index and generation exactly A+1 while A's retained identity stays fixed; exact special grant; hash-only completion; final producer output15 with after_reuse and monotonic progress; health17. No absolute slot/generation or private body-token generation is assumed.

`output_pressure_window`: health1, open echo3, producer5 canonical32+END, complete body status7, held0 output9 and checkpoint, send sibling`s`+END and verify its echo before granting producer credit, grant8192, validate exact prefix length/hash and no END/reset, observe held8192 output11 and monotonic progress, grant remaining16769121, hash-only completion, final output13 and progress, health15. Neither DATA nor END is earned early.

`output_pressure_ready`: health1, open echo3, producer5 canonical32+END, then sibling`s`+END. Wait for both actual terminal responses using the same parser/stage before completing/retiring either. Verify the echo and hash-only producer, then complete body status7, final producer output9, health11. Both interleaved echo and echo-after-producer-END permutations are exercised; neither response is fabricated or dropped to finish its sibling.

There are no resets/informationals in these cases. Both outgoing upload frames are independently decoded and checked for exact request headers/multiplicity/order/query/content-length/x-case, actual stream IDs, canonical32 or sibling1 payload/hash, and one DATA+END apiece. Exact carried request debts are connection64/aggregate-stream64 for reuse, and33/33 for each pressure case. Final collection preserves that debt and uses the existing inherited final budget; it reads exactly67 statuses plus one metrics response once.

## Actual RED and intermediate history

The serialized test was authored and retained as `evidence/b6a/initial-test.py` before any implementation or selection edit. Every attempt has exact `.command`, raw `.stdout`, `.stderr`, and `.exit` receipts. Attempt snapshots are retained for every failed test version; first adapter/schedule versions are retained separately.

The common exact environment is:

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

The initial and attempt1-7 Python invocation was:

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_producer_pressure.py
```

1. `initial-red`: exit1, empty stdout; traceback ends `ValueError: case schedule not implemented`. This proves selection rejection only. It is explicitly **not behavioral RED**, missing-file RED, native failure, or an immutable-core defect.
2. Added the concrete schedules and minimal adapter/selection support. `attempt-1`: exit1, `RuntimeError: auxiliary grant differs`. The initial synthetic peer incorrectly required the small B response to exist when its initial stream grant arrived, although the grant correctly precedes B's DATA.
3. Corrected the synthetic peer to track bounded auxiliary stream identities, queue an existing response on grant, or permit a granted upload's future response. A textual replacement left the duplicate-check condition inverted. `attempt-2`: exit1, the same `auxiliary grant differs` at initial health. Corrected that test condition. Attempt1's original peer also had an empty-tail enqueue for a final frame shorter than8192; this was fixed during the peer correction before it was reached. It produced no separate observed failure.
4. `attempt-3`: exit1, `RuntimeError: finite synthetic read limit exceeded`. The peer split each8201-byte DATA frame into two separate reads, exceeding its unchanged2400-call test bound. The peer was corrected to fill each bounded read across adjacent frame boundaries; its limit remained2400, and no catalogue/capacity/deadline/count limit moved.
5. `attempt-4`: all three positive schedules and alternate slot/generation completed, then exit1 because the wrong expected message was assigned to the window prefix corruption. Actual rejection was `ValueError: producer checkpoint differs`, which is earlier and more specific than final hash completion. Corrected the expectation to that named invariant.
6. `attempt-5`: positive schedules and initial negatives ran, then exit1 with public `h2.exceptions.FlowControlError: Flow control window shrunk below 0` on early DATA. The test had caught only ValueError/RuntimeError and expected a response-ledger phrase. Added the exact public exception type/message; no codec or policy was changed.
7. `attempt-6`: exit0, empty stderr, the original36 synthetic negatives passed. Final-output/B-binding retention and positive snapshot survival were added per the parent clarification; ready echo-after-END was covered as a separate positive permutation.
8. `attempt-7`: exit0, empty stderr, additional output-status, missing-END, prefix-END, and missing-sibling controls passed. Valid-shape monotonic counter decreases and deterministic deadline/backward-time controls were then added. All final36 normal/-O regressions passed after those last test edits.

No intermediate failure is suppressed or relabeled as a production defect. The test-only corrections are disclosed rather than claimed as behavioral RED. No mutation/reversion of implemented code was used to manufacture a failing-test claim. No immutable API gap was encountered.

## Final verification

After the last module edit, the exact normal and optimized invocations below ran for each of the18 test names. Each receipt records the exported PYTHONPATH and exact invocation, separate raw stdout/stderr, and the true exit code; `evidence/b6a/final-commands.json` indexes all36.

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/TEST.py
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/TEST.py
```

`TEST` is each of `test_adapter`, `test_admission`, `test_application_error`, `test_async`, `test_continue_quota`, `test_control_reset`, `test_credit`, `test_final`, `test_imports`, `test_large`, `test_metadata_concurrency`, `test_negative`, `test_pause`, `test_producer_pressure`, `test_ready`, `test_selection`, `test_shared`, and `test_time`. **36 exits0, all stderr empty.** Normal and `-O` refer to Python optimization; no Zig optimization/build mode applies. The required project/native/sanitizer/protocol/platform matrix was not run because this release explicitly permits only pure in-memory codec preparation, and no product source changed.

The new suite prints five positive executions and44 exact synthetic negative rejections per mode, with identical normal/-O stdout. The first three positives share all persistent application records and retained output/binding snapshots across three fresh codecs, ending in final67+metrics. A slot0/generation41 reuse run proves the absence of absolute slot/generation assumptions, and an extra ready permutation delivers the echo after producer END.

Negative sensitivity covers body/output digest, wrong status, missing END, both inherited deadline and monotonic-time enforcement during output reads, missing second ACK, untouched-record contamination, pre-grant DATA, held/prefix END, retained identity, held-state algebra, valid-shape decreasing counters, missing ready sibling, wrong relative B generation/index, missing after-reuse callback evidence, and unhealthy sibling echo. The actual public codec rejects early DATA before the manual ledger sees it. These are synthetic schedule/codec sensitivity checks, not native fixture/callback proof or additional pre-fix RED.

Both actual import runs printed:

```text
AST and inert import checks passed
```

That test checks exact29-module inventory, one main guard per module, no authored classes/custom exceptions or assert-based proof, and actual silent/inert imports under empty and foreign argv with rejecting file/socket/SSLContext/process/clock/console doubles. The snapshot audit also checks control depth<=3 across all29; new schedule depth1 and new test depth3. Metadata checks are guarded inline Python, not a new reusable executable helper module.

The reproducible final metadata command is:

```sh
sh .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6a/final-audit.command
```

Its embedded interpreter is the same pinned Python with `-B -S`. It rechecks all immutable rows, ordered42 codecs, exact29 current hashes against saved final copies/B5d, all36 exits/stderr, final34/6 and67-record inventories, identical49-line normal/-O new-test output and unchanged source during snapshot. Exact raw output is retained below and in `final-audit.stdout`; exit0, empty stderr.

## Self-review and remaining facts

Self-review checked correctness, ownership, tests, documentation and gate integrity in that order. The two-ACK configuration belongs to the existing stage contract; configuration issues one canonical SETTINGS action and waits on actual parsed ACK state. Auxiliary grants go through the same canonical policy as special/bootstrap grants. Parser-complete checkpoints require exact prefix count/hash and forbid END/reset. Ready waits for both actual responses; hash-only finish uses immutable `wire.complete` before returning a body-free result. Final diagnostic retention happens only after producer and relative-progress validation. Existing small/reset/refusal/application paths pass their unchanged normal/-O regressions.

There is no unresolved immutable API defect or actionable concern found within this slice. Root's independent source/review acceptance and public/Git delivery remain pending. No quality threshold, deadline, count, native fixture assumption or source identity was lowered. Only the explicitly authorized unsupported inventory changed9->6, with rejection loops preserved.

All40 source/default/subset aggregation, strict disconnect replacement/close ownership, lifecycle/shutdown schedules, the other output schedules, runtime adapter preparation, separately authorized sequential two-child native all40 acceptance, adoption, and the unchanged full2.2.0 project/platform/compliance gates remain required. The supplied diagnostic maps and their final-collection survival are not native metadata-retention or post-deinit evidence.

## Raw final audit stdout

```text
29 modules: 2 added, 7 changed, 20 unchanged, 0 removed against released B5d
119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate
42 ordered codec identities and default-json aggregate match; no extra or missing codec files
36 final normal/-O commands exit0 with empty stderr; all-module AST and actual inert empty/foreign argv imports pass
maximum control depth=3; new schedule=1; new test=3
34 source schedules; six rejected unsupported selections; final collection67 records plus metrics
new test: five positive executions and44 exact synthetic negative rejections per mode
remaining selections: shutdown_idle, disconnect, reuse, stream_file, early_final_order, shutdown_active
```

## Raw new-suite stdout (normal; optimized is identical)

```text
producer_reuse passed: J=9 C=8 R=64 output=16777313
output_pressure_window passed: J=8 C=7 R=33 output=16777313
output_pressure_ready passed: J=6 C=5 R=33 output=16777313
producer_reuse passed: J=9 C=8 R=64 output=16777313
output_pressure_ready passed: J=6 C=5 R=33 output=16777313
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: producer checkpoint differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
identity rejected: producer identity changed
counter rejected: producer held state
monotonic rejected: producer counter decreased
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
identity rejected: producer identity changed
counter rejected: producer held state
monotonic rejected: producer counter decreased
prefix_end rejected: invalid terminal
missing_sibling rejected: missing finite synthetic response
binding_generation rejected: relative reuse binding
binding_slot rejected: relative reuse binding
after_reuse rejected: reuse callback missing
sibling rejected: sibling echo differs
sibling rejected: sibling echo differs
```
