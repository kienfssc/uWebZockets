# Task5e3b6a: producer reuse and response-pressure schedules

Released after B5d source/publication review and immediate push of commit
f3919fe407953c75693144cbae0f81b5b6c16983. The accepted27-module map is
docs/implement-2-2-0/evidence/m2_h2_combined_application_errors/manifest.json
and task-5e3b5d-root-final-audit.json; committed bytes/push are verified by
task-5e3b5d-root-commit-audit.json. Accepted31/40 source cases, no native acceptance.
Read task-5e3b-release-addendum.md and
task-5e3b-cases-pending-brief.md for unchanged all40/global interfaces and limits.
This unit implements producer_reuse,output_pressure_window,output_pressure_ready.
All nine original B6 cases and native/full milestones remain required.

Own concrete output schedule/tests, minimal actually-used adapter/cases/import
changes, evidence/b6a and task-5e3b6a-report.md. Preserve existing schedules and
proof. Root authorizes explicit unsupported assertions9->6 with every rejection
loop retained and accurate34-case description. Root owns public/Git. You are
not alone; preserve others' edits. No agents or external model CLI.

## Exact source and existing interfaces

Authoritative source-only references authenticated in task-5e3b-input-audit.json:
/tmp/uwz-task5d1-round3-current/contracts.py;
/tmp/uwz-task5d3-runtime-v5/cases.py,diagnostics.py,records.py,post.py;
/tmp/uwz-task5d2-fix2-final-snapshot/profile.zig,output.zig.
The other19 runtime source files, especially case_adapter.py and protocol.py,
are read-only references authenticated by the recovered v5 runtime manifest.
Never invoke any old live/native/runtime/constructor/close entrypoint. Current
model/catalogue/fixture schema and canonical wire supersede legacy aliases and
direct old-ledger operations. No second model or old history-list framework.

| Case | Heads J | Small C | Request flow R |
| --- | ---: | ---: | ---: |
| producer_reuse | 9 | 8 | 64 |
| output_pressure_window | 8 | 7 | 33 |
| output_pressure_ready | 6 | 5 | 33 |

Four new persistent body records, separate output diagnostics and generation
proof must survive shared app/fresh connections/final67+metrics with untouched
records. Preserve start/end health and exact source internal action order.
Producer response length16777313 and SHA256
e5b7e8c5bbad59c7bc86f18236a37661571e972f65c707d7dc1902386ec5e91d.
Use current model constants/generator and exact diagnostic validators, never a
whole retained response or a second expected-state model.

Located v9wire seams: startup consumes exactly the already-initiated codec;
update_settings(stage,initial_window), new_grants(stage), grant(...,purpose),
start_request(...role,mode,expected_sha256...), complete/retire and drain.
Output settings require a second real ACK. Window-controlled cases set stream
initial0; ready sets33554432. The exact once-only connection bootstrap uses
purpose bootstrap/stream0/amount33554432-credit.connection. Each auxiliary small
stream under initial0 gets its one65535 auxiliary grant. Special grants are
producer_reuse16777313 or pressure_window8192 then16769121, through canonical
grant policy only. Ready has no special stream grant. Pair all SETTINGS/grants/
DATA/reads/retirement with both ledgers/parser/stage, flush before observations.
No duplicate auto-consumption/refund or direct credit/state surgery.
output_stage.new_stage requires expected_acks2 for these cases; adapter.open_case
currently supplies1. Extend that actual case configuration through the existing
stage contract, not a core mutation or invented startup workaround.

adapter.start currently fixes small_body/expected_sha256None and finish always
returns body. Minimal actually-used role-special/hash_only/expected-digest
support is required: hash-only results must omit body and validate length/hash/
END via wire.complete. Keep existing small/reset/refusal behavior unchanged.
producer_reuse primary is stream3 after initialhealth; next upload is stream9
after body/output observations. Other cases open echo3 then producer5 after
health1. Preserve actual source request order, no role-derived ID inference.

## Concrete schedules

producer_reuse: start producerA, send canonical32+END, validate complete body
status, observe producer offset0 held; checkpoint no output/END/reset. Start B
and complete canonical32 upload/record while A stays held. Observe A still0 and
monotonic diagnostics, then B binding diagnostic. Require same binding_index as
A and generation exactly A+1, while retained A identity remains unchanged.
Grant A its exact total, finish hash-only output, validate final producer with
after_reuse and monotonic counters, then health. Never assume absolute slot or
generation; body-token generation remains private.

pressure_window: open echo then primary; send32+END, complete body status,
producer0 held diagnostic and no-output checkpoint. Send sibling b's'+END and
verify healthy echo before special grants. Grant8192, require exact prefix
length/hash with noEND/reset, observe producer8192 still held and monotonic
diagnostics. Grant remaining16769121, finish exact hash-only producer, final
diagnostic/progress, health. No early DATA or end before earned grants.

pressure_ready: open echo then primary; send canonical32+END then sibling
b's'+END. Wait for both actual responses with one parser/stage, finish echo and
hash-only producer without losing either or fabricating a peer success. Then
complete body status, final producer diagnostic, health. Preserve exact ready
window behavior and no accidental per-stream grant sequence.

## Proof and handoff

Begin actual serialized tests before implementation; preserve initial test,
actual RED scope/all intermediate failures. Selection/API-only RED stays
qualified; no missing-file or mutation-as-RED claims. Independently decode exact
request headers/order/END, settings/ACK/grants and totals, request payload/hash,
bounded response spans/incremental count/hash, held/prefix/end ordering, relative
generation and sibling isolation. Model-derived diagnostics remain supplied
synthetic inputs, not native callback or independent fixture evidence. Target
negative controls at named invariants and qualify their scope.

Preserve fresh caller integer time/inherited deadlines at each action/read/
drain/final boundary, all exact J/C/R/settings/grant/work caps and final debt.
No whole body, per-frame/read histories or capacity/deadline/count relaxation.
Report any smallest actual immutable API defect and continue independent cases;
no omitted requirements or fake successful unsupported handlers.

After final edits capture relevant normal/O raw stdout/stderr/exit/commands,
changed-seam regressions and all-module main-guard/AST/actual silent-inert
empty/foreign-argv rejecting-effect import proof. Snapshot every module/hash
against released B5d. No authored classes/custom exceptions/assert proof,
hidden mutable globals/dead code/deep nesting. Exact pinned Python -B -S for
all invocations and graphify prefix before first source read/search.

Use the retained ordered42codec rows (including non-Python files), aggregate
SHA256(json.dumps(rows).encode()) default JSON format. Distinguish119 retained
identity rows from114 unique entries when the same authority set is used.
No native/build/server/socket/SSLContext/TLS-close/real-clock/process ownership/
transfer/descriptor/kernel/fault/cancel/scheduling/race/panic/leak experiment,
old live entrypoint, product/model/core/fixture/dependency/Git/public edit or
other agent. Pure in-memory public-codec tests only. Full report includes exact
contracts/APIs/files/commands/raw results/history/identities/self-review and
remaining facts; return concise DONE/report/tests/real concerns. Root reviews.
