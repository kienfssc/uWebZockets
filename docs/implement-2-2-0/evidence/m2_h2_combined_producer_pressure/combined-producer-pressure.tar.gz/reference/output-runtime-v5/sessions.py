"""Sequence one fresh connection per selected case and final status stage."""
import contracts
import orchestration


def run(selection, overall, clock, connect):
    contracts.expected_records(selection)
    if not selection:
        raise ValueError('empty selection')
    evidence = []
    binding = None
    final = None
    outputs = {}
    for index, case in enumerate(selection):
        now = clock()
        deadline = min(overall, now + 30)
        if now >= deadline:
            raise ValueError('overall deadline expired')
        connection = connect(case, deadline)
        error = None
        try:
            state, api = orchestration.setup(connection['codec'], case, connection['write'], connection['read'])
            result = orchestration.run_case(case, state, api)
            if case in ('producer_reuse', 'output_pressure_window', 'output_pressure_ready', 'stream_file'):
                outputs[case] = state['output_observations'][case]
            if case == 'producer_reuse':
                binding = result
            stage_stats = {name: state['stage'][name] for name in ('bytes', 'reads', 'auxiliary', 'acks')}
            if index == len(selection) - 1:
                if clock() >= deadline:
                    raise ValueError('last case deadline expired')
                final = orchestration.collect_final(state, api, selection)
                final['stage'] = {name: state['stage'][name] for name in ('bytes', 'reads', 'budget', 'auxiliary')}
            debt = state['request']['connection_debt']
            stream_debt = sum(item['debt'] for item in state['request']['streams'].values())
            evidence.append({'case': case, 'connection_debt': debt, 'stream_debt': stream_debt,
                             'checkpoints': state['checkpoints'], 'events': state['events'], 'stage': stage_stats,
                             'completions': state['completions'],
                             'body_observations': state['body_history'], 'output_observations': state['output_history']})
        except BaseException as exc:
            error = exc
            raise
        finally:
            try:
                connection['close']()
            except BaseException as cleanup_error:
                if error is None:
                    raise
                error.add_note('connection cleanup failed: ' + repr(cleanup_error))
    return {'cases': evidence, 'final': final, 'binding': binding, 'outputs': outputs}
