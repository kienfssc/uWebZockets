"""Ordinary host operations; all external effects are invoked by the caller."""
import hashlib
import os
from pathlib import Path
import signal
import ssl
import subprocess
import threading
import capture
import identity
import owned_io


def process_start(pid):
    return identity.start_id(Path('/proc', str(pid), 'stat').read_text())


def listeners(pid):
    links = []
    for entry in Path('/proc', str(pid), 'fd').iterdir():
        try:
            links.append(os.readlink(entry))
        except FileNotFoundError:
            # The child can close a descriptor during enumeration.
            continue
    return identity.match_listeners(Path('/proc/net/tcp').read_text(), links)


def owned(child, expected_start, listener):
    identity.require_owned(child['process'].poll(), process_start(child['pid']), expected_start,
                           listeners(child['pid']), listener)


def operations(clock):
    def certificate(argv, env, deadline):
        return subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
                              env=env, timeout=owned_io.remaining(deadline, clock))

    def digest(path):
        return hashlib.sha256(ssl.PEM_cert_to_DER_cert(Path(path).read_text())).hexdigest()

    def spawn(argv, env):
        process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
        return {'pid': process.pid, 'process': process}

    def collector(child):
        state = capture.new()
        pipe = child['process'].stdout
        if pipe is None:
            raise ValueError('missing fixture output pipe')
        thread = threading.Thread(target=capture.collect, args=(lambda: os.read(pipe.fileno(), 8192), state), daemon=True)
        thread.start()
        return {'state': state, 'thread': thread, 'pipe': pipe}

    def ready(child, start, collector_state, nonce, capacity, deadline):
        listener = capture.wait_ready(collector_state['state'], nonce, capacity, deadline, clock,
                                      child['process'].poll, lambda: listeners(child['pid']))
        owned(child, start, listener)
        return listener

    def wait(child, deadline):
        return child['process'].wait(timeout=owned_io.remaining(deadline, clock))

    def join(collector_state, deadline):
        thread = collector_state['thread']
        thread.join(timeout=owned_io.remaining(deadline, clock))
        if thread.is_alive():
            raise ValueError('output collector did not finish')
        collector_state['pipe'].close()

    return {'directory': lambda path, mode: os.mkdir(path, mode), 'certificate': certificate,
            'chmod': os.chmod, 'digest': digest, 'spawn': spawn, 'start': process_start,
            'collector': collector, 'ready': ready, 'owned': owned,
            'signal': lambda child: os.kill(child['pid'], signal.SIGTERM), 'wait': wait, 'join': join,
            'snapshot': lambda collector_state: capture.snapshot(collector_state['state']),
            'snapshot_raw': lambda collector_state: capture.inspect(collector_state['state']),
            'poll': lambda child: child['process'].poll(), 'kill': lambda child: child['process'].kill(),
            'close_pipe': lambda child: child['process'].stdout.close(),
            'unlink': lambda path: Path(path).unlink(missing_ok=True), 'absent': lambda path: not Path(path).exists()}
