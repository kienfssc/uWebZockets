"""Pair public H2 actions with the reviewed framing and credit observers."""
import h2.settings
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def require(condition, message):
    if not condition:
        raise ValueError(message)


def new(codec, kind, primary, write):
    return {'codec': codec, 'write': write, 'raw': raw_observer.new_state(),
            'request': request_credit.new_state(), 'response': response_credit.new_state(),
            'stage': output_stage.new_stage(kind, primary, 2), 'records': {}, 'events': {}}


def flush(state):
    while True:
        pending = state['codec'].data_to_send(amount=8192)
        if not pending:
            return
        require(len(pending) <= 8192, 'outgoing bound')
        state['write'](pending)


def initiate(state):
    state['codec'].initiate_connection()
    request_credit.client_settings_sent(state['request'])
    response_credit.settings_sent(state['response'], 65535, initial=True)
    flush(state)


def settings(state, initial):
    state['codec'].update_settings({h2.settings.SettingCodes.INITIAL_WINDOW_SIZE: initial})
    request_credit.client_settings_sent(state['request'])
    response_credit.settings_sent(state['response'], initial)
    flush(state)


def start(state, method, path, headers, end, limit, status, *, mode='small_body', digest=None,
          policy='healthy'):
    codec = state['codec']
    stream = codec.get_next_available_stream_id()
    request_credit.open_stream(state['request'], stream)
    response_credit.open_stream(state['response'], stream)
    output_stage.register(state['stage'], stream, primary=stream == state['stage']['primary'])
    wire.register(state['records'], state['raw'], stream, limit, status, 0, policy,
                  mode=mode, credit_policy='manual', expected_sha256=digest)
    codec.send_headers(stream, [(':method', method), (':scheme', 'https'),
                                (':authority', 'localhost'), (':path', path)] + headers, end_stream=end)
    if end:
        request_credit.end_request(state['request'], stream)
    flush(state)
    return stream


def send_data(state, stream, data, end):
    require(type(data) is bytes and len(data) <= 8192 and type(end) is bool, 'invalid request data')
    state['codec'].send_data(stream, data, end_stream=end)
    request_credit.send_data(state['request'], stream, len(data), len(data))
    if end:
        request_credit.end_request(state['request'], stream)
    flush(state)


def grant(state, stream, amount):
    state['codec'].increment_flow_control_window(amount, stream_id=stream or None)
    response_credit.grant(state['response'], stream, amount)
    flush(state)


def accept(state, data):
    wire.accept(state['codec'], data, state['records'], state['raw'], state['events'],
                credit=state['response'], request=state['request'], stage=state['stage'])
    eligible = [stream for stream, item in state['request']['streams'].items()
                if not request_credit.closed(item)]
    request_credit.compare_public(state['request'], state['codec'], eligible)
    response_credit.compare_public(state['response'], state['codec'],
                                   [stream for stream in state['response']['streams'] if stream in eligible])
    flush(state)


def complete(state, stream):
    wire.complete(state['records'], state['raw'], stream)
    record = state['records'][stream]
    result = {'headers': record['headers'], 'bytes': record['bytes'], 'sha256': record['hash'].hexdigest(),
              'informationals': record['informationals'], 'end': record['ended'],
              'reset': state['raw']['streams'][stream]['reset'], 'reset_event': record['reset_event']}
    if record['mode'] == 'small_body':
        result['body'] = bytes(record['body'])
    wire.retire(state['records'], state['raw'], stream)
    request_credit.retire(state['request'], stream)
    response_credit.retire(state['response'], stream)
    output_stage.retire(state['stage'], stream)
    return result
