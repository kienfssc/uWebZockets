"""Map case actions onto bounded public-codec and observer operations."""
import contracts
import protocol
import records


def require(condition, message):
    if not condition:
        raise ValueError(message)


def boundary(state):
    raw = state['raw']
    return not raw['header'] and raw['frame'] is None and raw['remaining'] == 0


def terminal(state, stream):
    record = state['records'][stream]
    observed = state['raw']['streams'][stream]
    return record['ended'] and (record['policy'] != 'refusal_after_final' or observed['reset'])


def wait(state, read, predicate):
    while not predicate() or not boundary(state):
        data = read()
        require(type(data) is bytes and 0 < len(data) <= 8192, 'invalid receive')
        protocol.accept(state, data)


def api(state, read):
    state['output_observations'] = {}
    state['output_history'] = []
    state['body_history'] = []
    state['checkpoints'] = []
    state['completions'] = []
    def grant_aux(stream):
        if state['response']['initial'] == 0:
            protocol.grant(state, stream, 65535)

    def start_get(path, limit=4095):
        stream = protocol.start(state, 'GET', path, [], True, limit, 200)
        grant_aux(stream)
        return stream

    def start_echo(expected):
        stream = protocol.start(state, 'POST', '/echo', [('content-length', '1')], False, 1, 200)
        require(stream == expected, 'echo stream identity')
        grant_aux(stream)
        return stream

    def start_upload(tag, expected, *, mode):
        require(tag in contracts.TAGS[:7] and mode in ('small', 'producer', 'file', 'early'), 'upload identity')
        path = '/limit/' + tag + '?case=' + tag
        headers = [('content-length', '32'), ('x-case', tag)]
        if mode == 'early':
            headers.append(('expect', '100-continue'))
        limit, status, digest, policy = {
            'small': (4095, 200, None, 'healthy'),
            'producer': (contracts.TOTAL, 200, contracts.PRODUCER_HASH, 'healthy'),
            'file': (contracts.FILE_LENGTH, 200, contracts.RANGE_HASH, 'healthy'),
            'early': (17, 403, contracts.EARLY_HASH, 'refusal_after_final'),
        }[mode]
        stream = protocol.start(state, 'POST', path, headers, False, limit, status,
                                mode='small_body' if mode == 'small' else 'hash_only', digest=digest, policy=policy)
        require(stream == expected, 'upload stream identity')
        if mode == 'small':
            grant_aux(stream)
        return stream

    def retire(stream):
        value = protocol.complete(state, stream)
        evidence = {'stream': stream, **value}
        if 'body' in evidence:
            evidence['body_hex'] = evidence.pop('body').hex()
        require(len(state['completions']) < 74, 'completion evidence count bound')
        state['completions'].append(evidence)
        return value

    def finish(stream):
        wait(state, read, lambda: terminal(state, stream))
        return retire(stream)

    def finish_pair(first, second):
        wait(state, read, lambda: terminal(state, first) and terminal(state, second))
        return retire(first), retire(second)

    def checkpoint(stream, size):
        record = state['records'][stream]
        wait(state, read, lambda: record['headers'] is not None and record['bytes'] >= size)
        value = {'stream': stream, 'bytes': record['bytes'], 'sha256': record['hash'].hexdigest(),
                 'end': record['ended'], 'reset': state['raw']['streams'][stream]['reset']}
        require(len(state['checkpoints']) < 8, 'checkpoint count bound')
        state['checkpoints'].append(value.copy())
        return value

    def headers(stream):
        record = state['records'][stream]
        wait(state, read, lambda: record['headers'] is not None)
        value = {'status': int(record['status']), 'informationals': record['informationals'],
                 'bytes': record['bytes'], 'end': record['ended'], 'reset': state['raw']['streams'][stream]['reset']}
        require(len(state['checkpoints']) < 8, 'checkpoint count bound')
        state['checkpoints'].append({'stream': stream, **value})
        return value

    def request(path, limit=4095):
        return finish(start_get(path, limit))['body']

    def output_status(tag):
        item = records.parse_json(request('/output/' + tag))
        require(len(state['output_history']) < 8, 'output observation count bound')
        state['output_observations'][tag] = item
        state['output_history'].append(item)
        return item

    def body_status(tag):
        item = records.parse_json(request('/status/' + tag))
        require(len(state['body_history']) < 8, 'body observation count bound')
        state['body_history'].append(item)
        return item

    def health():
        require(request('/health', 2) == b'ok', 'health differs')

    return {'start_get': start_get, 'start_echo': start_echo, 'start_upload': start_upload,
            'send': lambda stream, data, end: protocol.send_data(state, stream, data, end),
            'grant': lambda stream, amount: protocol.grant(state, stream, amount),
            'finish': finish, 'finish_pair': finish_pair, 'checkpoint': checkpoint, 'headers': headers,
            'body_status': body_status,
            'output_status': output_status, 'health': health}
