"""Deadline-bound operations on an already owned TLS connection."""


def remaining(deadline, clock):
    value = deadline - clock()
    if value <= 0:
        raise ValueError('absolute deadline expired')
    return value


def write(sock, data, deadline, clock):
    if type(data) is not bytes or not data or len(data) > 8192:
        raise ValueError('invalid send bound')
    sock.settimeout(remaining(deadline, clock))
    sock.sendall(data)


def read(sock, deadline, clock):
    sock.settimeout(remaining(deadline, clock))
    data = sock.recv(8192)
    if type(data) is not bytes or not data or len(data) > 8192:
        raise ValueError('invalid receive or premature EOF')
    return data
