"""Run the prescribed connection stages over caller-owned transport callbacks."""
import contracts
import cases
import case_adapter
import output_stage
import protocol
import records


CASE_INFO = {'output_pressure_window': ('producer', 5, 0, cases.output_pressure_window),
             'output_pressure_ready': ('producer', 5, 33554432, cases.output_pressure_ready),
             'producer_reuse': ('producer', 3, 0, cases.producer_reuse),
             'stream_file': ('file', 5, 0, cases.stream_file),
             'early_final_order': ('early', 7, 0, cases.early_final_order)}


def setup(codec, case, write, read):
    if case not in CASE_INFO:
        raise ValueError('invalid case')
    kind, primary, window, _ = CASE_INFO[case]
    state = protocol.new(codec, kind, primary, write)
    protocol.initiate(state)
    case_adapter.wait(state, read, lambda: state['response']['initial_acked'] and
                      state['stage']['initial_settings'] == 1 and state['response']['pending'] is None)
    api = case_adapter.api(state, read)
    api['health']()
    if state['stage']['high_water'] != 1:
        raise ValueError('initial health stream differs')
    protocol.settings(state, window)
    case_adapter.wait(state, read, lambda: state['response']['pending'] is None)
    increment = 33554432 - state['response']['connection']
    if increment <= 0:
        raise ValueError('invalid connection credit')
    protocol.grant(state, 0, increment)
    return state, api


CASE_COUNTS = {'output_pressure_window': (7, 33), 'output_pressure_ready': (5, 33),
               'producer_reuse': (8, 64), 'stream_file': (6, 33), 'early_final_order': (6, 32)}


def run_case(case, state, api):
    if case not in CASE_INFO:
        raise ValueError('invalid case')
    result = CASE_INFO[case][3](api)
    auxiliary, sent = CASE_COUNTS[case]
    if (state['stage']['auxiliary'] != auxiliary or state['request']['sent'] != sent or
            state['request']['client_settings'] != 2 or state['stage']['acks'] != 2 or
            not state['stage']['primary_complete'] or state['stage']['active'] or state['records'] or
            state['response']['streams'] or state['response']['pending'] is not None or
            not case_adapter.boundary(state) or state['raw']['streams']):
        raise ValueError('case accounting or retirement differs')
    return result


def collect_final(state, api, selection):
    if state['records']:
        raise ValueError('unretired response records')
    output_stage.enter_final(state['stage'], state['raw'], state['request'], state['response'])
    items = []
    for tag in contracts.TAGS:
        items.append(records.parse_json(api['finish'](api['start_get']('/status/' + tag))['body']))
    totals = records.parse_json(api['finish'](api['start_get']('/metrics'))['body'])
    records.validate(selection, items)
    records.validate_totals(selection, totals)
    output_stage.finish_final(state['stage'], state['raw'])
    return {'records': items, 'totals': totals}
