# Task5c1: prepare public HTTP/2 cancel/reset acceptance

Read this first: these are the requirements and exact values. This is the first
ordered lifecycle slice of task-5-plan.md and task-5c-lifecycle-architecture.md,
whose existing architecture is adopted. Implement only cancel_ready,
cancel_paused and peer_reset plus their independent recoveries and idle cleanup.
All other nine-case lifecycle plan requirements, five output cases and eventual
combined matrix remain binding future work; unsupported selection must fail.

## Ownership and phase

Own .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/,
/tmp/uwz-task5c1-* and task-5c1-report.md in this plan workspace. You are not
alone: preserve other agents' changes. Do not edit Root product source, pins,
docs, prior fixtures/evidence or common client/tools. Do not commit or push;
Root publishes reviewed evidence and immediately pushes every Root commit.
No subagents or external model CLI. Report actual commands/output/identities,
self-review, changed files and concerns, then return a short status/report path.

StageA allows source preparation, Python AST/codec checks and actual compile-
only Debug/ReleaseSafe fixture builds. It does NOT allow running any native
fixture/test/server/client/constructor, sockets, certificate generation or live
selfcheck. Root separately reviews frozen source and releases any future run.
Keep the stopped native cancellation/fault experiment stopped; do not reconstruct
it, add native schedules/interleavings/races, injected OS/kernel/resource/fd/
registration/completion errors, panic/leak/crash probes or denied socket cases.
Use no socket option changes, backend changes or forced outcomes. Only later
reviewed ordinary public owning-loop API and valid peer protocol are in scope.

## Inputs and binding

Root starts from 0f057ba (metadata checkpoint, pushed fork). Product candidate
is the unchanged1031-file /tmp/uwz-task4d-fix1-frozen,
SHAfc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de.
Reviewed libxev override /tmp/uwz-reviewed-libxev-c223-loop-callbacks is93files
atc223bd886c6a51d2cd60def39dd9a68d701fea73. Keep original
.uwz-work/evidence/h1-transport/r2/c-native.zig and all six existing static
libraries/actual linkage in body-app/focused-final-ReleaseSafe.command.json.
Compiler /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig.
Use -j2 and /tmp compiler caches/outputs; workspace has limited disk space.

The current metadata fixture /tmp/uwz-task5b4-fix1-frozen and persistent
integration-owned/metadata/fix1 provide the reviewed preparation/ownership
pattern. Adapt in NEW owned files; remove inapplicable fixture scaffolding in
the new copy. Retain originals untouched. Current closure must bind actual new
frozen sources, actual new Debug/ReleaseSafe build input maps and executables,
compiler, six archives, binding/override, runtime client/interpreter/stdlib/
loader/OpenSSL/helper and environments. No historical binary-path union. Keep
actual compile failures and corrections. Freeze all source before final
compiles; revalidate before/after inventories and current validator acceptance
plus rejection of a mutated input map. Do not claim exact historical rebuild.

Pinned offline42-file Python tools /tmp/uwz-h2-client-tooling/packages digest
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473;
unchanged integration-client/h2_client.py digest
07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00.
Absolute Python /home/codespace/.python/current/bin/python3 -B -S;
future execution env-i LC_ALL=C.UTF-8 with exact PYTHONPATH only. No installs.
Importing a prepared runner must remain inert; an explicit run flag, reviewed
manifest hash, selected supported cases and fresh output directory are required.

## Fixed capacities and process/observation contract

Use Server.preset(...).build_https and exact task-5-plan.md profile unchanged:
max_connections8, streamingtrue, reqline512, requestheaders4096/count80,
H1body256,H2body4096, encodedH2headers8192,responseheaders4096/count32,
captures24,writequeue65536, unrelated optional features off. Native8streams,
receivepayload73728, two reusable application sink slots. Adopt NO production
capacity increase. This isolated slice needs only6 histories: keep32 fixed
test records with26 untouched spares; defer proposed128 combined ledger.
Keep individual stable record/owned expectations independently of sink slots;
no retained callback Request/StreamingRequest/Response/view-array/chunk pointer.
Copy BodyControls; public cancel may retire the binding inline.

Future owned loopback127.0.0.1:28443/localhost TLS1.3+h2; ownership PID/start/
nonce/listener/cert checked before health. Fixed ready15/case30/whole900/
graceful15-second absolute deadlines, no retry/fallback. Continuous combined
output65536, response records8, send/read spans8192, status body<4096, final
headers32/4096, info16/16384, explicit frame/event bounds unchanged. All32
records and final metrics are read before SIGTERM, metrics LAST with no later
requests. Require matching postdeinit records/metrics/normalexit0/reaped/keygone;
forced cleanup fails. Idle shutdown is only the isolated baseline, not the
later shutdown_active proof. Retain bounded case-barrier observations in results
so an independent auditor can inspect actual accepted/phase counters.

## Independent primary/recovery expectations

P32=bytes1through10 followed by literal final-upload-sentinel! (32total).
H32=7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5.
H7 hashes P32[0..7], bytes1through7, NOT another generator's seven-byte payload:
32bbe378a25091502b2baf9f7258c19444e7a43ee4593b08030acd790bd66e6a.

Use quota-one /limit/:tag, limit32, CL32, distinct literal bounded tag/query/
header metadata, independent expected values. Before each primary open buffered
POST/echo sibling CL1 without DATA/EOF. It reserves no sink binding. All barriers
before operation and termination observation use that case's SAME connection.

- cancel_ready: send first7P32 withoutEOF, observe accepted7/ready, invoke copied
  public cancel through owning-loop control route. Control response200/ok,
  exactly one incoming target CANCEL8, accepted7/H7/BEC1/0/1/cancelled, no final
  target HTTP response. Later stale resume/cancel return BodyControlExpired
  with no mutation or duplicate terminal.
- cancel_paused: send P32 withoutEOF, sink accepts7 then pauses with25queued.
  Observe accepted7/paused before copied public cancel. Same CANCEL8/H7/BEC/
  cancelled/stale rules; unaccepted suffix is never hashed or delivered.
- peer_reset: beginpaused, send P32 withoutEOF; observe accepted0/chunks0/end0
  before ordinary client reset_stream(CANCEL). Actual server callback record
  must show BEC1/0/1/reset, zero/emptySHA, no successful response. Client-local
  closure is not server proof. Do not require server RST echo.

After each primary terminal: complete buffered sibling with byte s+EOF, require
200/exact s/no reset. Reclaim genuine connection DATA credit before independent
same-route P32 recovery: targets7,32,32 respectively, cumulative refund<=sentflow
and public connection window agrees. Do not require a packet-specific delta,
WINDOW_UPDATE count, or refund on a closed stream. Independently admit recovery
tag<primary>_recovery, receive32/H32/200/BEC1/1/0 and one middleware header. This
must work when the primary is selected alone. Check old controls after reuse.

Exactly6 body histories: attempts6/B6/E3/C3/failedbegin0/enderrors0,110 accepted
logical bytes, zero active/errors. Middleware runs once per valid body head;
buffered/control/status requests have separate accounting. Six body histories
are three primaries plus three recoveries, not six selectable case IDs.

## Observer and meaningful pure verification

Extend the NEW package observer for explicit per-case terminal policy:
publiccancel expects incoming exact target RST8 without requiring prior final
HTTP response; peerreset expects outgoing valid RST plus server callback proof.
Healthy/control/recovery streams forbid resets. Preserve refusal-after-final
policy for later combined integration instead of globally weakening it.
Reject DATA/HEADERS after terminal end/reset and unexpected payload frames on
retired IDs. Mark end only after complete frame payload; handle fragmented and
coalesced input and never discard trailing bytes at a successful barrier.
Do not demand an H2 high-level RST event if the codec suppresses a closed-stream
event; raw bytes are ordering oracle and actual server record is callback oracle.
Keep bounded storage/explicit limits and normal valid flow-accounting semantics.

Write focused OFFLINE tests using pinned codec-encoded frames for accepted
reset-only and refusal-after-final order, wrongstream/code, missing/duplicate/
postterminal reset, DATA/HEADERS-after-end/reset, fragmented/coalesced input,
full payload before end and bounds. Establish meaningful failure before the
new observer behavior, then pass; report harness-only coverage, never native
product behavior. Python AST and Zig format/actualcompile checks finish StageA.
No model of desired product behavior replaces the eventual real public API run.

Use graphify query before first new search; raw reads only for already located
paths/lines or cited architecture references. Apply AGENTS/CODING_CONVENTION,
verification instructions and narrow skills. No weakened gates/unused code/
new markers or anonymous known public types. If actual product contracts cannot
meet an expectation, report the exact source conflict instead of changing
source or broadening allowed results. Final report task-5c1-report.md must give
all changed files, exact commands/raw outcomes, hashes, frozen10-or-explicit-new
module inventory, compile and pure-check scope, self-review and remaining work.
