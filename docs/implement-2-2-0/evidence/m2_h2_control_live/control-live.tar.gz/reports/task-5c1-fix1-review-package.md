# Task5c1 fix1 scoped diff from reviewed v3 to v4

P2 primary credit must precede sibling DATA. Actual fixture/build receipts unchanged.
--- /tmp/uwz-task5c1-runtime-v3/cases.py
+++ /tmp/uwz-task5c1-runtime-v4/cases.py
@@ -53,20 +53,20 @@
     api['pending'](primary)
     if case == 'peer_reset':
         operation = api['peer_reset'](primary)
     else:
         operation = api['control']('cancel', case, 'ok')
     terminal = api['status'](case)
     require((terminal['begin'], terminal['end'], terminal['cancel'], terminal['accepted'], terminal['reason'], terminal['active']) ==
             (1, 0, 1, expected_bytes, 'reset' if case == 'peer_reset' else 'cancelled', False), 'server terminal barrier differs')
     terminal_wire = api['finish_terminal'](primary)
     stale_before = [api['control'](name, case, 'BodyControlExpired') for name in ('resume', 'cancel')]
+    credit = api['reclaim'](7 if case == 'cancel_ready' else 32)
     sibling_response = api['finish_sibling'](sibling)
-    credit = api['reclaim'](7 if case == 'cancel_ready' else 32)
     recovery = api['start'](case + '_recovery', 'healthy')
     api['send'](recovery, 32, True)
     response = api['finish_recovery'](recovery)
     verify_record(response, expected(case + '_recovery', {case + '_recovery'}))
     stale_after = [api['control'](name, case, 'BodyControlExpired') for name in ('resume', 'cancel')]
     return {'before': before, 'operation': operation, 'terminal': terminal, 'terminal_wire': terminal_wire,
             'stale_before': stale_before, 'sibling': sibling_response, 'credit': credit,
             'recovery': response, 'stale_after': stale_after}
--- /tmp/uwz-task5c1-runtime-v3/flow_ledger.py
+++ /tmp/uwz-task5c1-runtime-v4/flow_ledger.py
@@ -72,10 +72,17 @@
                 raise ValueError('invalid stream refund')
 
 
 def check_public(ledger: FlowLedger, connection_window: int, stream_windows: dict[int, int]) -> None:
     if connection_window != ledger.connection:
         raise ValueError('connection window differs')
     for stream_id, public_window in stream_windows.items():
         stream = ledger.streams[stream_id]
         if not stream.open or public_window != min(ledger.connection, stream.window):
             raise ValueError('stream minimum differs or stream closed')
+
+
+def primary_refund_complete(ledger: FlowLedger, target: int, public_window: int) -> bool:
+    if target not in (7, 32) or ledger.sent != target or ledger.refunded > ledger.sent:
+        raise ValueError('primary-only flow differs')
+    check_public(ledger, public_window, {})
+    return ledger.refunded == target
--- /tmp/uwz-task5c1-runtime-v3/run_live.py
+++ /tmp/uwz-task5c1-runtime-v4/run_live.py
@@ -404,30 +404,34 @@
                 require(pending == expected.serialize(), 'outgoing reset bytes differ')
                 raw_module.mark_peer_reset(raw_state, stream, 8)
                 trace['ledger'].streams[stream].open = False
                 sock.settimeout(remaining(deadline))
                 sock.sendall(pending)
                 return {'outgoing_reset_hex': pending.hex(), 'stream': stream, 'code': 8}
             def finish_terminal(stream):
                 trace['ledger'].streams[stream].open = False
                 return complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture)
             def finish_sibling(stream):
+                ledger = trace['ledger']
+                sent_before, refunded_before = ledger.sent, ledger.refunded
                 send_bytes(stream, b's', True)
                 item = complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture)
                 require(item['body'] == 's' and item['bytes'] == 1, 'sibling response differs')
+                require(ledger.sent == sent_before + 1 and refunded_before <= ledger.refunded <= ledger.sent, 'sibling flow differs')
+                item['flow'] = {'sent_before': sent_before, 'sent_after': ledger.sent,
+                                'refunded_before': refunded_before, 'refunded_after': ledger.refunded,
+                                'connection_window': ledger.connection, 'public_window': protocol.outbound_flow_control_window}
                 return item
             def reclaim(target):
                 ledger = trace['ledger']
-                while ledger.refunded < target:
+                while not flow.primary_refund_complete(ledger, target, protocol.outbound_flow_control_window):
                     receive(sock, protocol, records, raw_state, trace, deadline, wire, capture)
-                require(ledger.refunded <= ledger.sent, 'refund exceeds sent flow')
-                flow.check_public(ledger, protocol.outbound_flow_control_window, {})
                 return {'target': target, 'sent': ledger.sent, 'refunded': ledger.refunded,
                         'connection_window': ledger.connection, 'public_window': protocol.outbound_flow_control_window}
             def finish_recovery(stream):
                 item = complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture)
                 return json.loads(item['body'])
             def pending(stream):
                 require(records[stream]['headers'] is None and not records[stream]['ended'] and not raw_state['streams'][stream]['reset'], 'unexpected early target terminal')
             api = {'start': begin, 'sibling': sibling, 'send': send,
                    'status': lambda tag: status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture),
                    'control': do_control, 'peer_reset': do_peer_reset, 'finish_terminal': finish_terminal,
--- /tmp/uwz-task5c1-runtime-v3/test_credit_case.py
+++ /tmp/uwz-task5c1-runtime-v4/test_credit_case.py
@@ -0,0 +1,100 @@
+"""Offline regression for actual case order and the caller-owned flow ledger."""
+import unittest
+
+import cases
+import flow_ledger as flow
+
+
+class CaseHarness:
+    def __init__(self, case, refunded):
+        self.case = case
+        self.refunded = refunded
+        self.ledger = flow.FlowLedger()
+        self.next_stream = 1
+        self.terminal = False
+        self.recovery = False
+        self.sibling_sent = False
+
+    def open(self):
+        stream = self.next_stream
+        self.next_stream += 2
+        flow.open_stream(self.ledger, stream)
+        return stream
+
+    def sibling(self):
+        return self.open()
+
+    def start(self, tag, policy):
+        self.recovery = tag.endswith('_recovery')
+        return self.open()
+
+    def send(self, stream, count, end):
+        flow.send_data(self.ledger, stream, count, None, 16384, end)
+
+    def status(self, tag):
+        peer = self.case == 'peer_reset'
+        return {'begin': 1, 'accepted': 0 if peer else 7, 'end': 0,
+                'cancel': int(self.terminal), 'paused': not self.terminal and self.case != 'cancel_ready',
+                'chunks': 0 if peer else 1, 'reason': 'reset' if peer else 'cancelled',
+                'active': not self.terminal}
+
+    def pending(self, stream):
+        return None
+
+    def control(self, operation, tag, expected):
+        if expected == 'ok':
+            self.terminal = True
+        return expected
+
+    def peer_reset(self, stream):
+        self.terminal = True
+        return {'code': 8}
+
+    def finish_terminal(self, stream):
+        self.ledger.streams[stream].open = False
+        flow.receive_batch(self.ledger, [(0, self.refunded)])
+        return {'reset': True}
+
+    def finish_sibling(self, stream):
+        flow.send_data(self.ledger, stream, 1, None, 16384, True)
+        flow.receive_batch(self.ledger, [(0, 1)])
+        self.sibling_sent = True
+        return {'body': 's'}
+
+    def reclaim(self, target):
+        if not flow.primary_refund_complete(self.ledger, target, self.ledger.connection):
+            raise ValueError('primary refund incomplete')
+        return {'target': target, 'sent': self.ledger.sent, 'refunded': self.ledger.refunded}
+
+    def finish_recovery(self, stream):
+        result = cases.expected(self.case + '_recovery', {self.case + '_recovery'})
+        result.update(chunks=1, max_span=32)
+        return result
+
+    def api(self):
+        return {name: getattr(self, name) for name in ('start', 'sibling', 'send', 'status', 'control',
+                'peer_reset', 'finish_terminal', 'finish_sibling', 'reclaim', 'finish_recovery', 'pending')}
+
+
+class CreditCaseTests(unittest.TestCase):
+    def test_partial_primary_cannot_be_masked_by_sibling(self):
+        for case, target in (('cancel_ready', 7), ('cancel_paused', 32), ('peer_reset', 32)):
+            with self.subTest(case=case):
+                harness = CaseHarness(case, target - 1)
+                with self.assertRaisesRegex(ValueError, 'primary refund incomplete'):
+                    cases.execute(harness.api(), case)
+                self.assertFalse(harness.sibling_sent)
+
+    def test_complete_primary_before_sibling_and_recovery(self):
+        for case, target in (('cancel_ready', 7), ('cancel_paused', 32), ('peer_reset', 32)):
+            with self.subTest(case=case):
+                harness = CaseHarness(case, target)
+                result = cases.execute(harness.api(), case)
+                self.assertEqual(result['credit'], {'target': target, 'sent': target, 'refunded': target})
+                self.assertTrue(harness.sibling_sent)
+                self.assertEqual(harness.ledger.sent, target + 33)
+                self.assertEqual(harness.ledger.refunded, target + 1)
+
+
+if __name__ == '__main__':
+    unittest.main()

# Actual current freeze recipe

"""Freeze current runtime modules and bind current fixture build receipts."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspaces/uWebZockets')
BASE = HERE.parent / 'metadata/fix1/manifest.json'
FROZEN = Path('/tmp/uwz-task5c1-runtime-v4')
MANIFEST = HERE / 'manifest-v4.json'
NAMES = ('run_live.py', 'cases.py', 'wire.py', 'raw_observer.py', 'flow_ledger.py', 'validate_builds.py', 'test_observer.py', 'test_credit_case.py')


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        while data := stream.read(1048576):
            h.update(data)
    return h.hexdigest()


def inventory(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    if FROZEN.exists() or MANIFEST.exists():
        raise ValueError('snapshot or manifest exists')
    base = json.loads(BASE.read_text())
    keep = [p for p in base['trees'] if not p.startswith('/tmp/uwz-task5b4')]
    trees = {}
    for root in keep:
        current = inventory(Path(root))
        if current != base['trees'][root]:
            raise ValueError('reviewed tree differs: ' + root)
        trees[root] = current
    FROZEN.mkdir(mode=0o700)
    for name in NAMES:
        shutil.copyfile(HERE / name, FROZEN / name)
        (FROZEN / name).chmod(0o444)
    FROZEN.chmod(0o555)
    trees[str(FROZEN)] = inventory(FROZEN)
    trees['/tmp/uwz-task5c1-fixture-v1'] = inventory(Path('/tmp/uwz-task5c1-fixture-v1'))
    retained = ('/home/codespace/.python/current/', '/lib/', '/lib64/', '/opt/conda/')
    inputs = {p: h for p, h in base['inputs'].items() if p.startswith(retained)}
    helper = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'
    inputs[helper] = '07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00'
    receipts = [str(HERE / ('fixture-' + mode + '-v1.json')) for mode in ('debug', 'release')]
    for receipt_path in receipts:
        receipt = json.loads(Path(receipt_path).read_text())
        inputs.update(receipt['input_before'])
        inputs[receipt_path] = digest(receipt_path)
        for name in (receipt['stdout'], receipt['stderr']):
            path = str(HERE / name)
            inputs[path] = digest(path)
        output = next(v.split('=', 1)[1] for v in receipt['argv'] if v.startswith('-femit-bin='))
        inputs[output] = receipt['binary_sha256']
    for name in NAMES:
        inputs[str(FROZEN / name)] = digest(FROZEN / name)
        inputs[str(HERE / name)] = digest(HERE / name)
    for name in ('profile.zig', 'compile_fixture.py', 'freeze_runtime.py'):
        inputs[str(HERE / name)] = digest(HERE / name)
    for path, value in inputs.items():
        if digest(path) != value:
            raise ValueError('input differs: ' + path)
    approved = json.loads((HERE.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
    validator = load('validate_builds', FROZEN / 'validate_builds.py')
    manifest = {'state': 'ready-for-independent-review', 'scope': 'intermediate fixture builds and current runtime sources; no live execution',
                'trees': trees, 'tree_counts': {p: len(v) for p, v in trees.items()}, 'inputs': inputs,
                'build_input_receipts': receipts, 'approved_archives': {p: approved[p] for p in validator.ARCHIVES},
                'binary': '/tmp/uwz-task5c1-fixture-release-v1/profile', 'helper': helper,
                'environment': {'LC_ALL': 'C.UTF-8', 'PYTHONPATH': '/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'},
                'python': '/home/codespace/.python/current/bin/python3', 'python_flags': ['-B', '-S']}
    for key, name in (('runner', 'run_live.py'), ('cases', 'cases.py'), ('wire', 'wire.py'), ('raw', 'raw_observer.py'), ('flow', 'flow_ledger.py'), ('validator', 'validate_builds.py')):
        manifest[key] = str(FROZEN / name)
    validator.validate(manifest, inputs)
    MANIFEST.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    print('frozen runtime files:', len(trees[str(FROZEN)]))
    print('tree counts:', manifest['tree_counts'])
    print('direct inputs:', len(inputs))
    print('manifest sha256:', digest(MANIFEST))


if __name__ == '__main__':
    main()
