# Task5c1 owned public control run

Currentv5 ordinary Linux ReleaseSafe TLS1.3/h2 run passes cancel_ready,
cancel_paused,peer_reset,shutdown_idle. Root independently audits actual result
9303144e0d6477379723b8d2fc1a161c8a3cd293722d195ae3f40508c0e609b2:
six admissions/B6/E3/C3/F0/enderrors0,110accepted,active/errors0. All32records
including26spares and metrics match afterdeinit. Fourfreshownedconnections,
normalSIGTERMexit0/reaped/noforce/keyremoved, log14682B<65536.

Exact current released command (host require_escalated approved):

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-runtime-v5/run_live.py --run --manifest /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/manifest-v5.json --manifest-sha256 d74acb0bf0586bdcace73bb772c376ea39e4ea7036da826828a59ee321882f18 --output /tmp/uwz-h2-lifecycle-control-owned-2026-10-29-r2 --cases cancel_ready cancel_paused peer_reset shutdown_idle
```

Authorization20ab50c8bd950941b638de69dc79eee329ae4215b36f0e3dec6f73148bed9d56;
session68190/finalchunk58fa66/exit0/emptyoutput. Nativechild92531/start954919,
fixtureReleaseeeba98819132a39b72480f43c0b7b3b244fed883cb7580d5ba63e1b4d15bdc2b,
profilefbb931e4f3e870c62280f38e90cf6499203d8cffc7d9d6c2e071ef2d917b1579.
Rootbefore/afterpreflight identicalffb47bc3b00ca0d0eb7cf766d6d4bb69cb4d8a4e589391433552afce20765e84,
2433inputs/7trees/6archives. Sourcefc69/c223/originalbinding/client/helper and
nativeprofile/buildreceipts unchanged throughoutruntimefixes. Separatefrozen
fixture1/runtime9; no historicalbinaryunion/recompile claim.

Observedpubliccancelready7/H7/BEC1/0/1/cancelled; paused7/H7/25unacceptedqueued/
1/0/1/cancelled; peerRST8beginpaused0/chunks0/emptySHA/1/0/1/reset. Public
cancel control200/ok, raw policyassertsoneincomingCANCEL8 forfirsttwo, no final
HTTPprimaryresponse; peer hasoutgoingRST8 and actualservercancelrecord without
requiredserverRSTecho. Copiedstalecontrolsbefore/afterreuse2resume+2cancel each,
nootherterminalmutation. Buffered1byte siblings200/exacts; eachsame-route32/H32
recovery1/1/0, exactmetadata/middleware. Primaryrefundsnapshots7/32/32 complete
BEFOREsiblingDATA. Separatesibling1byteaccounting. Actualflow170sent/170refunded.
BodyM6+bufferedM60 account66requestheads; do not fabricate aggregateeventcounts
fromidleconnection which omitsevents. Callbacksegmentation observations are not
packet/callback-size promises. Finalrecords/status precede metrics LAST.

Two distinctattempts retained. First releasedv4manifest31072fb2... underauth
01efbc4c...; session10367/finala9de73/exit1. It recordedthreecase/connection
sequences thenFileNotFound beforeidle/final32snapshot/deinit. Actualfailedpath/
originaltracebacknotretained. Raw335904aabbb7e6106c87b16ce76903744becf7641c49925f53aaa39a49188418,
cleanupforcedtrue/-9/reaped/noerrors; hostread-onlyPID87847/keyabsent. This
remainsfailed, not a zero-failure history or a separate fullcase acceptance.

Reviewround1 fixesindependentprimarycreditoracle (old sibling1couldmask6/31).
Actualcases/ledgerofflineRED6subcasefailures/GREENall3. Round2 sourceinvestigation
confirmslistenerenumeration assumesvolatilefdentriesstable; pureactualhelper
REDvanishedentry/formatter failure, GREEN7listener+2credit+8observer. Onlyvanished
enumeratedreadlink tolerated; exactlistener/PID/start/nonce/cert guards andother
I/O errorsremainstrict. Futurefilename/stage/boundedtraceback retained. This
doesnotproveoriginalunretainedfailedpath. Bothscopedre-reviewsSPEC/QUALITY/FIX
PASS. No nativefault/realFDmanipulation/schedule/probe orautomaticretry. Separate
new exactRootrelease precedessecondrun. Stoppedexperimentsstaystopped.

Rootindependent hostresultauditor verifiesall32rows/spares, literalP32/H7/H32,
barriers/terminal/credit/stale/sibling/recovery, finalmetrics/postlogs, TLS/cert,
actual170flow, PID/keyabsence andpreflightidentity. Its source andactualrecord
are retained withrawresults. Currentcaseinventory29proved/11remaining; full
combined, remaininglife/output/H3/multipart/genuineearlydata/fullquality/
platform/compliance/physical/performance/provenance/adoption/originalmilestones
remainopen. No RSS/leak/generalnative-safety inference.
