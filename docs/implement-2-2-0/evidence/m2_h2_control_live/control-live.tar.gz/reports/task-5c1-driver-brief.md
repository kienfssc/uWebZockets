# Task5c1 remaining preparation: driver and current closure

Continue the SAME original task from task-5c1-brief.md. The original observer/
offline tests and actual fixture pass are retained. Root read the appended
fixture report and audited both actual receipts, before/after input maps,
binary hashes and empty compiler outputs. Native execution remains prohibited.
The successful source-only fixture pass does not complete StageA.

Now finish the independent Python lifecycle cases/process runner, current
runtime input closure, validator and final preparation report. Own the same new
lifecycle-control/ and /tmp/uwz-task5c1-* paths only; no prior source/evidence,
Root product/pins/docs/refs changes, commits/push, subagents or native activity.
All original acceptance/capacity/process/ownership/stop-boundary requirements
remain binding. There is no need to implement other lifecycle or output cases.

Use your reported actual fixture contracts:
POST/limit/<tag>?case=<tag>, x-case:<tag>, CL32; status/control/metrics routes
and complete record/metrics JSON as specified in task-5c1-report.md. Recovery
responses are bounded record JSON, consistent with earlier fixtures: require
200 and exact independently expected accepted32/H32/BEC/metadata/terminal fields;
do not mistake the upload's32-byte count for response wire length. Require one
normal middleware header. Keep all32 final records and metrics LAST, then
postdeinit equality with exact nonce markers. Preserve bounded intermediate
barrier records for independent audit. Require actual server callback record
for peerreset, real connection-credit reclamation, healthy sibling and each
independent same-route recovery, stale controls before/after reuse, exact reset
policies and all expected totals from the original brief.

Root found a concrete observer integration bound: final snapshot alone needs
32status requests plus metrics and ordinary health, exceeding the newly added
32-entry retired set. Reconcile this during driver integration without growing
retained history. Prefer monotonic client stream IDs/high-water tracking plus
the at-most8 active records, so retired payload/reset rejection needs no
per-completed-stream collection. Add a meaningful offline legal>32sequential-
response regression that fails before the correction, plus old-ID postterminal
rejection. Keep all explicit existing frame/read/active limits and previous
regressions. Report why this changes harness history bookkeeping, not a product
capacity or claimed native behavior. Do not wait until a native run deadlocks.

Ruling: the fixture compilation and Python runtime sources have separate
immutable snapshots. Keep the unchanged compiled fixture at
/tmp/uwz-task5c1-fixture-v1 and both actual successful receipts/binaries. Freeze
driver/modules separately. The final current closure must bind both actual
native before/after build-input maps and all final runtime sources/interpreter/
stdlib/loader/tools/client/helper/environment. Do not pretend Python sources
existed at compile time or add old historical binaries. Recompile only if
actual native source/build inputs change. This preserves exact current identity
while avoiding an unrelated duplicate native compilation. Document actual
frozen tree/file counts explicitly; no fixed10-file or6-tree count is assumed.

Keep process lifecycle from the reviewed metadata runner, with explicit run
flag/reviewed current manifest hash/case selection/fresh output directory, inert
import and no automatic retries. No native/server/client/constructor/socket/
certificate/live-selfcheck execution now. Offline codec/AST/import/identity
checks are allowed only when inert. Demonstrate validator acceptance and
mutated-map rejection against ACTUAL final inputs and both native receipts.
Preserve all exact commands/results/failures/hashes in the appended original
task-5c1-report.md and return DONE only when the full StageA source/closure is
ready for Root's independent review. No fixture/observer self-review substitutes
for that later review. Report concrete contract conflicts instead of broadening
expected outcomes or stopping because the remaining task is substantial.
