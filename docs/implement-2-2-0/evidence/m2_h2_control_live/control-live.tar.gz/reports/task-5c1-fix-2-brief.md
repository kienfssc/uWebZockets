# Task5c1 fix round2/5: listener enumeration and failure evidence

Read the original briefs/report and current reviewed runtime-v4. Root released
exactly one ordinary owned host attempt; it is now terminal and FAILED. Do not
rerun it. Raw evidence is lifecycle-control/stage-b-attempt1/ (execution,
result.json, server.log, publiccertificate); original/tmpdirectory remains.
ResultSHA335904aabbb7e6106c87b16ce76903744becf7641c49925f53aaa39a49188418.
All three primary case sequences have records and connection entries. Failure
occurred before idle connection completion/final32records/metrics/deinit:
FileNotFoundError(2,'No such file or directory'). Cleanup correctly records
forcedtrue,exit-9,reapedtrue,noerrors. Host read-only check confirms PID87847
and key absent. No full case/milestone success follows. The caught repr omitted
filename and original traceback, so the exact original failed path is unproved.

Root investigated the executed source: after the third connection closes, the
runner checks child identity and owned_listener before opening idle connection.
owned_listener at run_live.py137-146 enumerates /proc/<pid>/fd then readlinks
every entry with no handling for an entry disappearing. A normal just-closed
connection can invalidate that directory snapshot; the helper has a concrete
source defect irrespective of the lost original path. Compare source/retained
evidence before fixing; do not claim the unretained syscall/path as established.

Own the same lifecycle-control/ and /tmp/uwz-task5c1-* preparation files only.
You are not alone. Preserve all original/frozen/current/failed evidence and
actual successful native compile receipts. NO native executable/constructor/
client/server/socket/certificate/live selfcheck or retry. Do NOT create, close,
alter or race a real fd, inject kernel/OS/resource errors, schedule native
interleavings or reconstruct any stopped/denied experiment. No production/pin/
docs/refs edits, commits/push, subagents or external model CLI.

Use an OFFLINE pure test of the ACTUAL ownership helper with synthetic caller-
provided enumeration/read results or pure test doubles only. Demonstrate the
concrete disappearing non-listener entry failure before correction. Then make
the narrow enumeration correction: tolerate only a vanished enumerated entry
while still requiring the exact owned LISTEN inode/127.0.0.1:28443/state0A and
all PID/start/nonce/certificate checks. Missing listener, missing child directory,
wrong inode/endpoint, permission errors and unrelated I/O errors must fail;
do not silently swallow broad exceptions. Add corresponding negative coverage.
Keep ownership truth separate from transient unrelated descriptors.

Retain original exception type/message plus filename and traceback or precise
stage in future failure output so an unanticipated failure can be diagnosed
without new native probes. Cover that formatting offline; exclude private key
contents or credentials. Do not add an automatic retry or weaken assertions.
This is a confirmed helper regression and diagnostic correction, not permission
to reproduce the original native failure or claim it was definitely readlink.

Freeze a NEW runtime/new current manifest; preserve oldv4 and failed attempt.
Actual fixture/native inputs should remain unchanged: keep both actual build
receipts and do not recompile unchanged native code. Revalidate current closure,
actual mutated-map rejection, AST and focused tests covering amended code;
preserve primary-credit/observer invariants. Retain exact RED/GREEN commands,
actual outputs/status, source/hash/current input/tree/module counts and self-
review in the original task-5c1-report.md. Return short status. Root will read
the evidence and request scoped independent re-review. No further native run
is authorized until a separate exact Root release after those gates.
