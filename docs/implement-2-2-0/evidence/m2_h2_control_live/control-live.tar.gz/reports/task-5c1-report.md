# Task 5c1: partial offline observer preparation

Status: incomplete. This is not a StageA release and must not be run against a server. Only the independent raw observer and codec regression tests were prepared. No fixture, case driver, build closure, manifest, executable, compile, native execution, network access, certificate generation, or live selfcheck was performed. There is no frozen source inventory or build identity for this slice. All lifecycle acceptance, independent review, and the remaining planned matrix are outstanding.

Changed files (new, under the assigned ownership):

- `.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/raw_observer.py`: `99e754d15ed60642df7c9b1254692c281138cd6e5bfc75bf14f8d9505ff63e98`.
- `.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/test_observer.py`: `6c3afabc1415c8a8e20382e21cb559eead7f9dd71f8f0841911bead3626d4982`.
- This report.

The observer copy derives from `/tmp/uwz-task5b4-fix1-frozen/raw_observer.py`; the original was not modified. It distinguishes healthy, incoming public CANCEL, outgoing peer reset, and refusal-after-final policies, bounds frame and retained stream history, and marks end only on complete frame payload. The peer-reset mark is only a local observation and cannot establish the required server callback. Integration must require the server record separately.

Regression red command (original observer, before changing it):

```sh
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/test_observer.py > /tmp/uwz-task5c1-red.log 2>&1
```

The log is `/tmp/uwz-task5c1-red.log`, SHA256 `118d80e790954a0bd6377536dcd0a9793c52431a7db3e979f4fa77bc4f5166d0`. Its raw summary was:

```text
Ran 6 tests in 0.005s

FAILED (failures=2, errors=5)
```

Failures were post-end DATA/HEADERS accepted and reset-only cancellation rejected as `reset before final end`; additional errors included old boolean policy semantics. The shell command printed the log after running the test and thus its final shell exit code was that of `cat`, not the test. The failure output itself is retained. An attempted rewrite initially failed with `Permission denied` because the copied source was read-only; the following rerun retained the old failures. The owned copy was made writable and the correction applied.

Final offline command:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/test_observer.py
```

Raw output and exit status:

```text
.......
----------------------------------------------------------------------
Ran 7 tests in 0.002s

OK
exit 0
```

Tests use installed pinned-path hyperframe codec frame serialization. They cover reset-only and refusal-after-final order, wrong stream/code, missing and duplicate reset, payload after end/reset and after retirement, fragmented/coalesced frames, end only after full payload, peer reset local marking, and read/frame/active stream bounds. They verify this Python harness only, not production HTTP/2 behavior or actual credit accounting. Python executable SHA256 `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`; package tree identity was not revalidated in this partial preparation.

AST check:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control /home/codespace/.python/current/bin/python3 -B -S -c 'import ast,pathlib; paths=(".uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/raw_observer.py", ".uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/test_observer.py"); [ast.parse(pathlib.Path(p).read_text(), filename=p) for p in paths]; print("AST OK: 2 files")'
```

Raw output: `AST OK: 2 files`; exit 0.

Self-review: this standalone observer has not been integrated with the wire driver, independently reviewed, or frozen. The 32-entry retirement bound must be reconciled with the eventual combined matrix, and the frame bound must be checked against that driver's actual negotiated settings. No assertion here verifies a server callback, same-connection barrier, recovery, flow credit, process lifecycle, immutable input closure, or the required six histories. Fixture and case implementation, exact input bindings and inventory, Debug and ReleaseSafe compile-only builds, mutated-map rejection, remaining offline edge cases, full report and independent review remain required. No project-wide matrix was run; no product correctness claim is made.

## Fixture-only continuation

This section supersedes the earlier statement that no fixture or compile had been prepared. It is still an intermediate preparation, not a completed StageA closure or runtime proof. The new files are `lifecycle-control/profile.zig` (SHA256 `fbb931e4f3e870c62280f38e90cf6499203d8cffc7d9d6c2e071ef2d917b1579`), `compile_fixture.py` (`588e9a4c0377e02146048af74dfd824192f4da4d710cf364f7c8223e3e149731`), and the two `fixture-{debug,release}-v1.json`, `.stdout`, `.stderr` receipts. The read-only snapshot `/tmp/uwz-task5c1-fixture-v1` contains exactly `profile.zig` at the same hash. It contains no runner or final closure.

The fixture uses the exact configured profile from the brief and `/limit/:tag` has `max_body_bytes=32`, `max_active=1`. The first six stable records are `cancel_ready`, `cancel_ready_recovery`, `cancel_paused`, `cancel_paused_recovery`, `peer_reset`, `peer_reset_recovery`; the other 26 are `spare_00` through `spare_25`. Two slots hold only a record pointer, owner and index. Record-owned copied controls remain available after terminalization and slot reuse; callback-local request, response, view, and chunk pointers are not retained. `cancel_ready` accepts offered input ready; `cancel_paused` accepts at most the first seven bytes then pauses; `peer_reset` begins paused; recoveries accept ready input. The fixture records observed data rather than fabricating outcomes.

Route contract for the future independent driver:

- `POST /limit/<tag>?case=<tag>`, header `x-case: <tag>`, `content-length: 32`: middleware and begin check the expected tag, path, target, query, and headers; end checks them again. The valid recovery response body is the record JSON below. All responses receive `X-Middleware: retained` when middleware succeeds.
- `POST /echo`: buffered exact-byte echo; a sibling can send headers with length one before its DATA. `GET /health` returns `ok`.
- `GET /status/<tag>` returns a JSON object with `tag`, `middleware`, `attempts`, `begin`, `end`, `cancel`, `failure`, `end_errors`, `accepted`, `sha256`, `chunks`, `max_span`, `active`, `paused`, `reason`, `metadata_middleware`, `metadata_begin`, `metadata_end`, `stale_resume`, `stale_cancel`, `errors`. Hash is of the accepted prefix; the initial hash is empty SHA256. `reason` is the public cancellation enum name or `none`.
- `GET /control/cancel/<tag>` invokes the copied public cancel on an active request and returns `ok` on success. Once terminal, `/control/resume/<tag>` and `/control/cancel/<tag>` return `BodyControlExpired` only for that actual error and increment the respective observation counter. Counters do not change accepted bytes, terminal cause, or readiness. An unexpected result increments fixture errors and is not a successful response contract.
- `GET /metrics` returns aggregate `middleware`, `attempts`, `begin`, `end`, `cancel`, `failure`, `end_errors`, `accepted`, `active`, `errors`, `buffered_middleware`, `slot0_active`, `slot1_active`. For all three primaries and recoveries, the future driver must require attempts/begin/end/cancel 6/6/3/3, accepted 110, failure/end_errors/active/errors zero; the independent subset expectations remain necessary. All 32 individual records must be retrieved before metrics as the last request. After public deinit the fixture logs `H2_RECORD <nonce> <record JSON>` for all 32 and `H2_DEINIT <nonce> <metrics JSON>` for comparison. Idle termination is not active-shutdown evidence.

Compile-only commands (wrapper invokes the exact argv in each receipt; it sets compiler environment to exactly `LC_ALL=C.UTF-8`, cwd `/tmp/uwz-task4d-fix1-frozen`):

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/compile_fixture.py /tmp/uwz-task5c1-fixture-v1 debug fixture-debug-v1
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/compile_fixture.py /tmp/uwz-task5c1-fixture-v1 release fixture-release-v1
```

Raw wrapper outputs:

```text
mode: debug exit: 0 stdout bytes: 0 stderr bytes: 0 unchanged: True binary sha256: d5eaf7881adb5b458ab7299a0212b7bce68a0987575559ceedb3181b82b4dbd8
mode: release exit: 0 stdout bytes: 0 stderr bytes: 0 unchanged: True binary sha256: eeba98819132a39b72480f43c0b7b3b244fed883cb7580d5ba63e1b4d15bdc2b
```

Both wrapper exits were 0. Empty actual compiler stdout and stderr are retained separately. The machine-readable receipts `fixture-debug-v1.json` (SHA256 `ec945c6606890acb3710a50f7a720f1ef3845f4925a3571c3bfbac98a640a343`) and `fixture-release-v1.json` (`367cc9d5c7927683e2c0c396e89fb9b37b94c104d86314efd33885cd163e3643`) retain exact argv, environment, 13 input hashes before and after, and full before/after maps of all 1031 candidate and 93 override files. Candidate combined digest matched `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`; override matched the existing immutable c223 inventory. Both use original c-native, six reviewed archives, `-j2`, and distinct temporary caches and binaries. Compiler SHA256 is `2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c`. No claim is made that these binaries reproduce any historical build.

Exact compiler argv follows, separately retained in the receipts:

```text
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build-exe -ODebug --dep uWebZockets -Mroot=/tmp/uwz-task5c1-fixture-v1/profile.zig -ODebug --dep c --dep xev --dep zslay -MuWebZockets=/tmp/uwz-task4d-fix1-frozen/src/root.zig -Mc=/workspaces/uWebZockets/.uwz-work/evidence/h1-transport/r2/c-native.zig --dep xev_impl -Mxev=/tmp/uwz-task4d-fix1-frozen/src/core/xev.zig -Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig -Mzslay=/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy/src/root.zig -lc++ -lc /workspaces/uWebZockets/zig-out/lib/libuWebZockets.a /workspaces/uWebZockets/zig-out/lib/libssl.a /workspaces/uWebZockets/zig-out/lib/libcrypto.a /workspaces/uWebZockets/zig-out/lib/liblsquic.a /workspaces/uWebZockets/zig-out/lib/libdeflate.a /workspaces/uWebZockets/zig-out/lib/libz.a -j2 --cache-dir /tmp/uwz-task5c1-fixture-debug-v1/cache --global-cache-dir /tmp/uwz-task5c1-fixture-debug-v1/global -femit-bin=/tmp/uwz-task5c1-fixture-debug-v1/profile
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build-exe -OReleaseSafe --dep uWebZockets -Mroot=/tmp/uwz-task5c1-fixture-v1/profile.zig -OReleaseSafe --dep c --dep xev --dep zslay -MuWebZockets=/tmp/uwz-task4d-fix1-frozen/src/root.zig -Mc=/workspaces/uWebZockets/.uwz-work/evidence/h1-transport/r2/c-native.zig --dep xev_impl -Mxev=/tmp/uwz-task4d-fix1-frozen/src/core/xev.zig -Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig -Mzslay=/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy/src/root.zig -lc++ -lc /workspaces/uWebZockets/zig-out/lib/libuWebZockets.a /workspaces/uWebZockets/zig-out/lib/libssl.a /workspaces/uWebZockets/zig-out/lib/libcrypto.a /workspaces/uWebZockets/zig-out/lib/liblsquic.a /workspaces/uWebZockets/zig-out/lib/libdeflate.a /workspaces/uWebZockets/zig-out/lib/libz.a -j2 --cache-dir /tmp/uwz-task5c1-fixture-release-v1/cache --global-cache-dir /tmp/uwz-task5c1-fixture-release-v1/global -femit-bin=/tmp/uwz-task5c1-fixture-release-v1/profile
```

`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/profile.zig` exited 0 with no output. No failed Zig compilation occurred. The unchanged offline observer tests were not repeated.

Self-review and remaining work: compiles establish type/link compatibility only; they do not establish callback order, cancellation, true connection credit, middleware delivery, output bounds under real execution, or any lifecycle acceptance. The future driver must bind all expected hashes and exact case-specific barriers, prevent unsupported selections, check all histories and postdeinit output, prove ordinary sibling/recovery and credit behavior, and preserve process ownership/deadlines. The driver, complete runtime identity/environment/loader/client closure, frozen multi-module inventory, current validator and mutated-input rejection, independent review, and separate Root runtime authorization remain outstanding. The compile receipt records source and direct build inputs, not the complete future runtime closure. No executable, native constructor, socket, certificate, or server/client was run in this pass.

## Driver and current StageA closure

This section supersedes the earlier incomplete-driver status. The source preparation is ready for independent review; it is not an authorization for or evidence of native execution. No native executable, server, client, constructor, socket, certificate generation, or live selfcheck was run. Root must independently review the final sources and issue a separate exact runtime release before any such action. Later lifecycle cases, output cases and the combined matrix remain outstanding.

The final driver in `lifecycle-control/run_live.py` selects only `cancel_ready`, `cancel_paused`, `peer_reset`, and optional last `shutdown_idle`. Each primary has its own fresh TLS/H2 connection, headers-only buffered sibling, preterminal same-connection status barrier, terminal operation and actual server record barrier, exact target reset policy, stale controls before and after same-route recovery, completed exact sibling, real connection-credit observation, and independent 32-byte recovery. Its bounded result retains both barrier records, operation and raw terminal observations, stale-control responses, sibling response, credit/window values and recovery JSON. It verifies the literal payload and both H7/H32, final 32 record fields, aggregate sums and separate buffered-middleware accounting; post-deinit records and metrics must equal that final snapshot. Normal idle termination, exact child identity and listener checks, key deletion, bounded output and absolute deadlines remain in the runner. Selection alone does not establish the acceptance outcome.

The retired-stream observer previously stored 32 retired IDs, insufficient for the 32 status responses plus metrics and health. It now retains only the monotonic client stream high-water mark and at most eight active records. Retired and unknown payload/reset frames still fail; stream IDs must increase and be odd. Frame/read limits remain 16384/8192. This is harness bookkeeping, not a production capacity change.

Regression red command, against the former observer before the high-water correction:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/test_observer.py > /tmp/uwz-task5c1-retired-red.log 2>&1
```

Raw outcome: exit 1; `Ran 8 tests in 0.002s`, `FAILED (errors=1)`, with `ValueError: retired stream bound` at the 33rd retirement. The complete log is `/tmp/uwz-task5c1-retired-red.log`, SHA256 `2d035688d4f93a72a8ec100d4b7d72255d96a297a2ee6b432930c144ec096c7d`.

Final offline checks against the actual frozen runtime snapshot:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/tmp/uwz-task5c1-runtime-v2 /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-runtime-v2/test_observer.py
env -i LC_ALL=C.UTF-8 /home/codespace/.python/current/bin/python3 -B -S -c 'import ast,pathlib; root=pathlib.Path("/tmp/uwz-task5c1-runtime-v2"); paths=sorted(root.glob("*.py")); [ast.parse(p.read_text(),filename=str(p)) for p in paths]; print("AST OK:",len(paths),"files")'
```

Raw output, both exit 0:

```text
........
----------------------------------------------------------------------
Ran 8 tests in 0.001s

OK
AST OK: 7 files
```

The sequential-response regression covers 40 legal responses and old-ID payload, reset and re-registration rejection. The other seven cover raw reset policies, invalid stream/code, duplicate and missing reset, postterminal payload, fragmented/coalesced input, full payload before end, peer local reset marking, and bounds. These are offline harness tests, not observations of product behavior.

The final current manifest is `lifecycle-control/manifest-v2.json`, SHA256 `54ecafa790a1901fb02efd05ee36c374a064a487ab077106dea84de9fbebe686`. It binds 2429 direct inputs and seven independently inventoried trees: Zig stdlib 19542 files, pinned client packages 42, reviewed override 93, frozen candidate 1031, zslay package 14, actual fixture snapshot 1, and separate final runtime snapshot 7. It binds both actual build receipts and executables above, all direct compiler/build inputs and approved archives, runtime source, helper, Python/interpreter/stdlib, loader/libraries, OpenSSL and config, and the exact execution environment and Python flags. The 42 package files were compared individually to the previously reviewed inventory; helper SHA256 matches `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`. It does not union earlier historical fixture binaries. The intermediate `manifest.json` and `/tmp/uwz-task5c1-runtime-v1` were superseded after self-review found missing retained case observations; the actual fixture source and both successful builds did not change or require recompilation.

Final frozen runtime inventory and SHA256:

```text
cf216701792180775d73c75e77233806d490e18d3c00106ce538025adbc8c7cc  cases.py
f71787b310255802111876b66eb31ee1a5d341001ea5289e8745dd224465feff  flow_ledger.py
101b520b3ce1e4604f25f5c35522c3fe29214e87b382622e4e58b4bbdae791cc  raw_observer.py
dcedc88e902c4a864b32369a197fcabf5d597d25c3b639a8c82e66ab4e407ba6  run_live.py
602c33433063a192271872d931f5563f08abd155d9d46169f0f58ad61eca83a3  test_observer.py
29d692dc59e4ce79ed56dee1281dfc943b3bff8103b229703c170d806ac2e12e  validate_builds.py
8b475356879807924b7b27a62a36813e1e5ce0c69b5cf98d38b37359cc7a23fe  wire.py
```

Runtime freeze command:

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/freeze_runtime.py
```

Raw output: `frozen runtime files: 7`, the seven tree counts above, `direct inputs: 2429`, `manifest sha256: 54ecafa790a1901fb02efd05ee36c374a064a487ab077106dea84de9fbebe686`; exit 0. The recipe's final SHA256 is `1dd119fa096e17e727a8c440e14bcc4fbde45c91f0cc3d97d93e3c751f806fc9`.

The following inert check loads the final runner without invoking `main`, validates all current tree/input identities and both actual build receipts, then changes the `libssl.a` hash only in a copy of the actual manifest input map and requires rejection. The exact check source is `/tmp/uwz-task5c1-check-v2.py`, SHA256 `ef910be535e614abdf837780c769e9e40f04f23d87dfa53212aec874f82fabff`.

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-check-v2.py
```

Raw output and exit:

```text
inert runner and current manifest accepted: 2429 inputs, 7 trees
actual input map mutation rejected: current build input differs: /workspaces/uWebZockets/zig-out/lib/libssl.a
manifest sha256: 54ecafa790a1901fb02efd05ee36c374a064a487ab077106dea84de9fbebe686
exit 0
```

Self-review: the driver is separate from the application sink and checks server callback records rather than assuming a client-local reset proves delivery; reset-only and refusal-after-final policies remain distinct. Connection refunds are checked against sent flow and the codec's public connection window without a required packet-specific delta. The success result requires normal deinit, exit and reaping, and key removal; forced cleanup fails. Compile-only proof and offline codec tests do not establish live timing, protocol, flow, process or performance behavior. Independent review must check the frozen sources, case expectations, receipt linkage and unexecuted process path before any release. The remaining full project matrix and all unimplemented lifecycle/output/combined cases are not claimed complete.

### Final shutdown-deadline correction and v3 identity

The v2 closure above is superseded. Self-review found that the collector join used the whole-run deadline after the child wait, rather than sharing the 15-second graceful deadline. The runner now creates one `graceful_deadline` before SIGTERM and uses it for both child wait and output-collector join. No fixture or build input changed. The final runtime snapshot is `/tmp/uwz-task5c1-runtime-v3`; the authoritative current manifest is `lifecycle-control/manifest-v3.json`, SHA256 `6ae8873550f6d3911ea67e8fc35f956318b97d58211325f0c9a9b7e531bd291c`. Tree and input counts remain seven and 2429, respectively, with the v3 runtime tree replacing v2. The six runtime module hashes other than `run_live.py` are unchanged from the v2 inventory above; v3 `run_live.py` SHA256 is `339ffe8228ee722a68a4eea69272390cd19be671d04bcb9d751c91ea8f233cde`. The final `freeze_runtime.py` SHA256 is `d68a626e8c2300b08f583cdebeb87a930adba3967fd28ca9f1f358125f661d90`.

The same freeze command above produced `frozen runtime files: 7`, identical tree counts except `/tmp/uwz-task5c1-runtime-v3`, `direct inputs: 2429`, and `manifest sha256: 6ae8873550f6d3911ea67e8fc35f956318b97d58211325f0c9a9b7e531bd291c`; exit 0. The unchanged observer tests were not repeated after this runner-only correction. The final snapshot AST check used:

```sh
env -i LC_ALL=C.UTF-8 /home/codespace/.python/current/bin/python3 -B -S -c 'import ast,pathlib; root=pathlib.Path("/tmp/uwz-task5c1-runtime-v3"); paths=sorted(root.glob("*.py")); [ast.parse(p.read_text(),filename=str(p)) for p in paths]; print("AST OK:",len(paths),"files")'
```

Raw output `AST OK: 7 files`; exit 0. The final inert acceptance and actual-map mutation check used the v3-adjusted `/tmp/uwz-task5c1-check-v3.py`, SHA256 `afd95a5a0883928153ea787a2d3de173e453291c5361abaf0671defcdb283e4c`:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-check-v3.py
```

Raw output:

```text
inert runner and current manifest accepted: 2429 inputs, 7 trees
actual input map mutation rejected: current build input differs: /workspaces/uWebZockets/zig-out/lib/libssl.a
manifest sha256: 6ae8873550f6d3911ea67e8fc35f956318b97d58211325f0c9a9b7e531bd291c
```

Exit 0. All source, review and runtime limitations stated above still apply; v3 is preparation for independent review only.

## Fix round 1: primary-only credit barrier

This section supersedes v3 as the current source/closure. The independent review found that sibling DATA could add one refunded byte before the primary threshold was checked. `cases.execute` now calls `reclaim` before `finish_sibling`. The actual `flow_ledger.primary_refund_complete` requires the only DATA sent so far to equal the primary target (7 or 32), verifies the public connection window, and requires the entire target refund. The case retains that primary-only snapshot. Afterward the runner completes the sibling and records its separate sent/refunded before-and-after counters and public/ledger connection windows, then performs the same recovery as before. No capacities or primary/recovery expectations changed.

The covering `test_credit_case.py` calls the actual `cases.execute` and uses the actual caller-owned `flow_ledger`; its I/O callbacks are pure test doubles. For each of the three cases, partial primary 6/31 plus a potential sibling refund of 1 must fail before sibling DATA, while a full 7/32 primary refund must succeed before sibling and recovery. This is a harness/accounting regression, not a native product test.

RED was run before changing the case order, against v3 behavior:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/test_credit_case.py > /tmp/uwz-task5c1-credit-red.log 2>&1
```

Exit 1; raw summary `Ran 2 tests in 0.004s`, `FAILED (failures=6)`. Three partial-refund subcases failed because `ValueError not raised`; three full-refund subcases exposed snapshots of 8 instead of 7 and 33 instead of 32. Full raw log SHA256 `0e3466ea81c6a152c94e6c6cdcfaa85b5ae58f67055680fdaf009e9771202c07` at `/tmp/uwz-task5c1-credit-red.log`.

The corrected, separately frozen runtime is `/tmp/uwz-task5c1-runtime-v4`. The current manifest is `lifecycle-control/manifest-v4.json`, SHA256 `31072fb2b434443a69d5fce9ca005532c1990ab25f2f3f6caeeb1cad1f5fa3ba`. The old v3 snapshot and manifest remain preserved. The same `freeze_runtime.py` command documented above exited 0 and printed `frozen runtime files: 8`, `direct inputs: 2431`, seven trees with respective counts 19542, 42, 93, 1031, 14, 8, and 1, and the manifest hash above. `freeze_runtime.py` SHA256 is `b96d46aecac473ba867eed8f71d718558008f39a2a305f45018c034289c5490a`. Actual unchanged Debug and ReleaseSafe build receipts, fixture snapshot, binaries, and before/after maps remain bound; no duplicate compilation was performed.

The eight frozen runtime files and SHA256 values are:

```text
63cf5977e0c116da6f6f7cc938eca3f04efd3b24b92c1c3189d2bfc72be74a4a  cases.py
325b1f6898e725873d6865983bc15e90438182ffccaae7f4495d6714c6cafcd6  flow_ledger.py
101b520b3ce1e4604f25f5c35522c3fe29214e87b382622e4e58b4bbdae791cc  raw_observer.py
54c50ae7e658a87033bc005916632bdf8347208b2a1c27d2b1521e56410f1de3  run_live.py
8a25acb27280bb0c0da2456b7047c0119680f9b0fc54628624a2dca4cc59817c  test_credit_case.py
602c33433063a192271872d931f5563f08abd155d9d46169f0f58ad61eca83a3  test_observer.py
29d692dc59e4ce79ed56dee1281dfc943b3bff8103b229703c170d806ac2e12e  validate_builds.py
8b475356879807924b7b27a62a36813e1e5ce0c69b5cf98d38b37359cc7a23fe  wire.py
```

GREEN and existing offline regression commands:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/tmp/uwz-task5c1-runtime-v4 /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-runtime-v4/test_credit_case.py
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/tmp/uwz-task5c1-runtime-v4 /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-runtime-v4/test_observer.py
env -i LC_ALL=C.UTF-8 /home/codespace/.python/current/bin/python3 -B -S -c 'import ast,pathlib; root=pathlib.Path("/tmp/uwz-task5c1-runtime-v4"); paths=sorted(root.glob("*.py")); [ast.parse(p.read_text(),filename=str(p)) for p in paths]; print("AST OK:",len(paths),"files")'
```

Raw output, each exit 0:

```text
..
----------------------------------------------------------------------
Ran 2 tests in 0.001s

OK
........
----------------------------------------------------------------------
Ran 8 tests in 0.004s

OK
AST OK: 8 files
```

Current validation used `/tmp/uwz-task5c1-check-v4.py`, SHA256 `a95077477dc95d19176b7b6bf3028f929df243f4a4b41029eb3049140ed7d187`:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-check-v4.py
```

Raw output and exit:

```text
inert runner and current manifest accepted: 2431 inputs, 7 trees
actual input map mutation rejected: current build input differs: /workspaces/uWebZockets/zig-out/lib/libssl.a
manifest sha256: 31072fb2b434443a69d5fce9ca005532c1990ab25f2f3f6caeeb1cad1f5fa3ba
exit 0
```

Self-review: the pre-sibling oracle now enforces primary-only sent flow before it can pass, so a later sibling refund cannot mask a short primary refund. No source change claims native behavior; a missing real refund remains a deadline failure. No socket, native executable, server, client, certificate, constructor or live selfcheck was run. Scoped independent re-review and a separate Root runtime release remain required.

For reproducible red inputs, the original pre-correction test was reconstructed at `/tmp/uwz-task5c1-credit-red-test.py` (SHA256 `9965ffc074b512d8ceb66fb6440562f5ec57e72e4f63ed2663f11435110c9233`). The immutable v3 case and ledger reproduced the same six failures:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/tmp/uwz-task5c1-runtime-v3 /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-credit-red-test.py > /tmp/uwz-task5c1-credit-red-repro.log 2>&1
```

Exit 1; raw summary `Ran 2 tests in 0.003s`, `FAILED (failures=6)`; complete output is retained at `/tmp/uwz-task5c1-credit-red-repro.log`.

## Fix round 2: listener enumeration and future failure diagnostics

The previously released host attempt is terminal **FAILED**, not a lifecycle acceptance. Its preserved `stage-b-attempt1/result.json` SHA256 is `335904aabbb7e6106c87b16ce76903744becf7641c49925f53aaa39a49188418`. Read-only inspection showed `error: FileNotFoundError(2, 'No such file or directory')`, `success: False`, cleanup `{'forced': True, 'exit_code': -9, 'reaped': True, 'errors': []}`, and three case records and three connection entries. The original result lacks the failing filename and traceback; its actual failed path is unproved. No retry was performed.

The actual `owned_listener` helper enumerated child FD entries then read every link without allowing an entry to vanish. It now catches only `FileNotFoundError` raised by `readlink` for an already enumerated entry and continues examining other entries. Child-directory iteration and listener-table errors propagate; matching still requires the owned inode and exact `127.0.0.1:28443` LISTEN state, with the existing unique listener, child PID/start, nonce, and certificate checks unchanged. A missing matching listener still fails. No broad I/O error is swallowed, no retry was added, and no production/capacity change was made.

For future failures the runner retains its original `error` repr and adds a `failure` object containing exception `type`, `message`, `filename`, bounded traceback, and stage. Stages distinguish certificate, launch, readiness, each case connection/execution, final status and shutdown. These diagnostics do not read or emit private-key contents. This change cannot recover the unretained original path and does not assert that the failed host attempt was caused by `readlink`.

The synthetic-only `test_listener.py` calls the actual ownership helper with caller-provided directory, link and listener-table doubles. No real descriptors, sockets, processes, kernel errors, or native interleavings are manipulated. It covers a disappeared non-listener alongside an owned listener; missing child directory; no listener, wrong inode, endpoint, state, or multiple listeners; permission/other link I/O and listener-table errors; and the actual failure formatter's type, filename, traceback and stage.

Initial red command against the then-current source:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/test_listener.py > /tmp/uwz-task5c1-listener-red.log 2>&1
```

Exit 1; `Ran 5 tests in 0.003s`, `FAILED (errors=3)`; log SHA256 `67d4969ecb0aab5a88be780d1eb409312e0c22fc79d12c6b4235810313c6d973`. One error was a synthetic fixture mistake: its empty listener table contained an extra blank row, unlike `/proc/net/tcp`. The fixture was corrected without changing the assertion or production code. The corrected original test was saved as `/tmp/uwz-task5c1-listener-red-test.py` (SHA256 `68b2eba45cfbdb91eaca2ad4dfc99783587149abbb93dad88e90e78cda2ae515`) and reproduced against the immutable v4 runner:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/tmp/uwz-task5c1-runtime-v4 /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-listener-red-test.py > /tmp/uwz-task5c1-listener-red-repro.log 2>&1
```

Exit 1; raw summary `Ran 5 tests in 0.002s`, `FAILED (errors=2)`: the disappeared entry raised `FileNotFoundError`, and the new diagnostic formatter was absent. Full log SHA256 `e8769d40096dc2145f0cc0a661adc3c2a6f07300148470fe9216587bb7a68765`. Two additional negative tests for ambiguous listeners and listener-table permission errors were then added.

The final separately frozen runtime is `/tmp/uwz-task5c1-runtime-v5`; the current manifest is `lifecycle-control/manifest-v5.json`, SHA256 `d74acb0bf0586bdcace73bb772c376ea39e4ea7036da826828a59ee321882f18`. The previous v4 snapshot, manifest, and failed attempt remain retained. The freeze command documented above exited 0 with `frozen runtime files: 9`, `direct inputs: 2433`, and seven tree counts 19542, 42, 93, 1031, 14, 9, and 1. The actual fixture snapshot, Debug/ReleaseSafe binaries and before/after receipts remain unchanged; no new native build was needed. Current `freeze_runtime.py` SHA256 is `4fbc1e165e1044b9a5978bca33d0e84786f67e71a2e76c3019f581bdc56ae2b7`.

The current nine-file runtime inventory is identical to v4 except the amended `run_live.py` SHA256 `29c538ba5973524bb838fad6e8492f42f55351443f03f5cc07da4eaa93487835` and added `test_listener.py` SHA256 `3a4d722f7b0ecdd3178e565c3515ff51c985bdcc4ce11f937201f8852c07fb5a`; the seven unchanged file hashes are listed in the v4 section. Exact commands against the frozen v5 snapshot:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/tmp/uwz-task5c1-runtime-v5 /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-runtime-v5/test_listener.py
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/tmp/uwz-task5c1-runtime-v5 /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-runtime-v5/test_credit_case.py
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/tmp/uwz-task5c1-runtime-v5 /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-runtime-v5/test_observer.py
env -i LC_ALL=C.UTF-8 /home/codespace/.python/current/bin/python3 -B -S -c 'import ast,pathlib; root=pathlib.Path("/tmp/uwz-task5c1-runtime-v5"); paths=sorted(root.glob("*.py")); [ast.parse(p.read_text(),filename=str(p)) for p in paths]; print("AST OK:",len(paths),"files")'
```

Raw output, each exit 0:

```text
.......
----------------------------------------------------------------------
Ran 7 tests in 0.002s

OK
..
----------------------------------------------------------------------
Ran 2 tests in 0.007s

OK
........
----------------------------------------------------------------------
Ran 8 tests in 0.005s

OK
AST OK: 9 files
```

The final inert validation and actual-map mutation check uses `/tmp/uwz-task5c1-check-v5.py` (SHA256 `f3f84c83437709d41de658e2880a1a45f274a2b7133915afa8ffbf4b18f3a99d`):

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c1-check-v5.py
```

Raw output and exit:

```text
inert runner and current manifest accepted: 2433 inputs, 7 trees
actual input map mutation rejected: current build input differs: /workspaces/uWebZockets/zig-out/lib/libssl.a
manifest sha256: d74acb0bf0586bdcace73bb772c376ea39e4ea7036da826828a59ee321882f18
exit 0
```

Self-review: only a transient readlink disappearance is tolerated; ownership checks and other errors remain strict. This focused correction is supported by pure synthetic coverage, not live evidence. The previous attempt remains failed, with no final 32 records, final metrics, deinit or success. Scoped independent re-review and a separate Root release are required before any further native execution.
