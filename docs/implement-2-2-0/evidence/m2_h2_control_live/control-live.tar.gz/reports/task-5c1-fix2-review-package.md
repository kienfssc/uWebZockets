# Task5c1 fix2 scoped diff, reviewed v4 to v5
--- /tmp/uwz-task5c1-runtime-v4/run_live.py
+++ /tmp/uwz-task5c1-runtime-v5/run_live.py
@@ -5,20 +5,21 @@
 import json
 import os
 from pathlib import Path
 import signal
 import socket
 import ssl
 import subprocess
 import sys
 import threading
 import time
+import traceback
 
 HERE = Path(__file__).resolve().parent
 PORT = 28443
 PYTHON = '/home/codespace/.python/current/bin/python3'
 PACKAGES = '/tmp/uwz-h2-client-tooling/packages'
 HELPER = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'
 OPENSSL = '/opt/conda/bin/openssl'
 CASES = ('cancel_ready', 'cancel_paused', 'peer_reset', 'shutdown_idle')
 
 
@@ -67,20 +68,27 @@
     checked_path(path, path, inputs)
     spec = importlib.util.spec_from_file_location(name, path)
     require(spec is not None and spec.loader is not None, 'module loader unavailable')
     module = importlib.util.module_from_spec(spec)
     sys.modules[name] = module
     spec.loader.exec_module(module)
     checked_path(module.__file__, path, inputs)
     return module
 
 
+
+def failure_details(exc, stage):
+    return {'type': type(exc).__name__, 'message': str(exc),
+            'filename': getattr(exc, 'filename', None), 'stage': stage,
+            'traceback': ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))[-16384:]}
+
+
 def new_capture():
     return {'lock': threading.Lock(), 'bytes': bytearray(), 'overflow': False, 'error': None}
 
 
 def capture_fragment(capture, data):
     with capture['lock']:
         room = 65536 - len(capture['bytes'])
         capture['bytes'].extend(data[:room])
         if len(data) > room:
             capture['overflow'] = True
@@ -130,21 +138,24 @@
 
 def child_start(pid):
     # comm can contain spaces or parentheses; the final ')' ends that field.
     text = Path('/proc', str(pid), 'stat').read_text()
     return text[text.rfind(')') + 2:].split()[19]
 
 
 def owned_listener(pid):
     inodes = set()
     for entry in Path('/proc', str(pid), 'fd').iterdir():
-        target = os.readlink(entry)
+        try:
+            target = os.readlink(entry)
+        except FileNotFoundError:
+            continue
         if target.startswith('socket:['):
             inodes.add(target[8:-1])
     rows = Path('/proc/net/tcp').read_text().splitlines()[1:]
     return [row.split()[9] for row in rows if row.split()[1] == '0100007F:6F1B'
             and row.split()[3] == '0A' and row.split()[9] in inodes]
 
 
 def wait_marker(child, capture, nonce, deadline):
     marker = ('H2_READY ' + nonce).encode()
     while True:
@@ -299,58 +310,64 @@
     run_dir.mkdir(mode=0o700)
     cert, key, log = run_dir / 'certificate.pem', run_dir / 'private-key.pem', run_dir / 'server.log'
     nonce = os.urandom(16).hex()
     result = {'nonce': nonce, 'cases': {}, 'success': False, 'cleanup': {},
               'python': sys.executable, 'python_path': sys.path, 'openssl': OPENSSL,
               'profile': manifest['binary'], 'manifest_sha256': args.manifest_sha256}
     child = None
     sock = None
     start_id = None
     error = None
+    failure = None
+    stage = 'setup'
     capture = new_capture()
     collector = None
     try:
+        stage = 'certificate'
         command = [OPENSSL, 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
                    '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost',
                    '-keyout', str(key), '-out', str(cert)]
         result['certificate_command'] = command
         certificate_env = {'OPENSSL_CONF': '/opt/conda/ssl/openssl.cnf'}
         result['certificate_environment'] = certificate_env
         subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True,
                        env=certificate_env, timeout=remaining(overall))
         os.chmod(key, 0o600)
         cert_der = ssl.PEM_cert_to_DER_cert(cert.read_text())
         result['certificate_sha256'] = hashlib.sha256(cert_der).hexdigest()
         env = {'H2_PROFILE_CERT': str(cert), 'H2_PROFILE_KEY': str(key), 'H2_PROFILE_NONCE': nonce}
         result['child_argv'] = [manifest['binary']]
         result['child_environment'] = env.copy()
+        stage = 'launch'
         child = subprocess.Popen([manifest['binary']], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
         collector = threading.Thread(target=drain_capture, args=(child.stdout, capture), daemon=True)
         collector.start()
         start_id = child_start(child.pid)
         result['child'] = {'pid': child.pid, 'start': start_id, 'binary_sha256': digest(manifest['binary'])}
         deadline = min(overall, time.monotonic() + 15)
+        stage = 'readiness'
         result['listener_inode'] = wait_marker(child, capture, nonce, deadline)
         ready_output = capture_snapshot(capture)[0].decode('utf-8')
         capacity = [line for line in ready_output.splitlines() if 'H2_CAPACITY ' in line]
         require(len(capacity) == 1 and 'slab=4098304' in capacity[0], 'fixture capacity differs')
         result['capacity'] = capacity[0]
         require(child_start(child.pid) == start_id and child.poll() is None, 'owned child changed')
         context = ssl.create_default_context(cafile=str(cert))
         context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_3
         context.set_alpn_protocols(['h2'])
         p32 = helper.payload_block(32, 0, 32)
         require(p32 == bytes(range(1, 11)) + b'final-upload-sentinel!', 'payload literal differs')
         require(hashlib.sha256(p32).hexdigest() == cases.H32 and hashlib.sha256(p32[:7]).hexdigest() == cases.H7, 'payload digest differs')
         result['connections'] = []
         connection_cases = args.cases
         for case in connection_cases:
+            stage = 'case:' + case + ':connect'
             if sock is not None:
                 require(not records and not raw_state['streams'], 'records remain on previous connection')
                 sock.close()
                 sock = None
             deadline = min(overall, time.monotonic() + 30)
             require(child.poll() is None and child_start(child.pid) == start_id, 'owned child changed')
             require(owned_listener(child.pid) == [result['listener_inode']], 'owned listener changed')
             raw = socket.create_connection(('127.0.0.1', PORT), timeout=remaining(deadline))
             try:
                 raw.settimeout(remaining(deadline))
@@ -430,42 +447,45 @@
             def finish_recovery(stream):
                 item = complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture)
                 return json.loads(item['body'])
             def pending(stream):
                 require(records[stream]['headers'] is None and not records[stream]['ended'] and not raw_state['streams'][stream]['reset'], 'unexpected early target terminal')
             api = {'start': begin, 'sibling': sibling, 'send': send,
                    'status': lambda tag: status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture),
                    'control': do_control, 'peer_reset': do_peer_reset, 'finish_terminal': finish_terminal,
                    'finish_sibling': finish_sibling, 'reclaim': reclaim, 'finish_recovery': finish_recovery,
                    'pending': pending}
+            stage = 'case:' + case + ':execute'
             result['cases'][case] = cases.execute(api, case)
             require(not records and not raw_state['streams'], 'response records remain after case')
             require(trace['ledger'].sent == (40 if case == 'cancel_ready' else 65), 'case flow total differs')
             result['connections'].append({'case': case, 'tls': sock.version(), 'alpn': sock.selected_alpn_protocol(),
                                           'events': trace['events'], 'snapshots': trace['snapshots'],
                                           'sent_flow': trace['ledger'].sent, 'refunded_flow': trace['ledger'].refunded})
+        stage = 'final_status'
         deadline = min(overall, time.monotonic() + 30)
         final = {tag: status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture) for tag in cases.TAGS}
         aggregate = metrics(sock, protocol, records, raw_state, trace, deadline, wire, capture)
         selected = cases.selected_tags(args.cases)
         for tag in cases.TAGS:
             cases.verify_record(final[tag], cases.expected(tag, selected))
         for field in ('middleware', 'attempts', 'begin', 'end', 'cancel', 'failure', 'end_errors', 'accepted', 'errors'):
             require(aggregate[field] == sum(record[field] for record in final.values()), 'aggregate ' + field + ' differs')
         expected_buffered = len(args.cases) + 33 + sum(7 + (case != 'peer_reset') for case in args.cases if case in cases.PRIMARIES)
         require(aggregate['buffered_middleware'] == expected_buffered, 'buffered middleware count differs')
         require(aggregate['active'] == 0 and not aggregate['slot0_active'] and not aggregate['slot1_active'], 'active fixture')
         result['final_status'] = final
         result['final_metrics'] = aggregate
         sock.close()
         sock = None
         require(child_start(child.pid) == start_id and child.poll() is None, 'child identity changed')
+        stage = 'shutdown'
         graceful_deadline = min(overall, time.monotonic() + 15)
         os.kill(child.pid, signal.SIGTERM)
         exit_code = child.wait(timeout=remaining(graceful_deadline))
         result['cleanup'] = {'signal': 'SIGTERM', 'exit_code': exit_code, 'reaped': True, 'forced': False}
         require(exit_code == 0, 'owned server exit differs')
         collector.join(timeout=remaining(graceful_deadline))
         require(not collector.is_alive(), 'server output collector did not finish')
         check_capture(capture)
         text = capture_snapshot(capture)[0].decode('utf-8')
         post = {}
@@ -478,20 +498,21 @@
                 post[item['tag']] = item
             marker = 'H2_DEINIT ' + nonce + ' '
             if marker in line:
                 require(post_metrics is None, 'duplicate post-deinit aggregate')
                 post_metrics = json.loads(line.split(marker, 1)[1])
         require(post == final and post_metrics == aggregate, 'post-deinit state differs')
         result['cases']['shutdown_idle'] = {'exit_code': exit_code, 'post_deinit': True}
         result['success'] = True
     except BaseException as exc:
         error = repr(exc)
+        failure = failure_details(exc, stage)
     finally:
         def close_socket():
             if sock is not None:
                 sock.close()
 
         def signal_child():
             if child is None or child.poll() is not None:
                 return
             require(start_id is None or child_start(child.pid) == start_id, 'child identity changed during cleanup')
             result['cleanup']['forced'] = True
@@ -520,20 +541,21 @@
             if child is not None and child.stdout is not None:
                 child.stdout.close()
 
         errors = cleanup_actions((('socket', close_socket), ('child_signal', signal_child),
                                   ('child_wait', wait_child), ('key', delete_key), ('log', save_log),
                                   ('pipe', close_pipe)))
         if errors or result['cleanup'].get('forced', False):
             result['success'] = False
         result['cleanup']['errors'] = errors
         result['error'] = error
+        result['failure'] = failure
         (run_dir / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
     require(result['success'], 'owned run failed: ' + str(error))
 
 
 def main():
     parser = argparse.ArgumentParser()
     parser.add_argument('--run', action='store_true', required=True)
     parser.add_argument('--manifest', type=Path, required=True)
     parser.add_argument('--manifest-sha256', required=True)
     parser.add_argument('--output', required=True)
--- /tmp/uwz-task5c1-runtime-v4/test_listener.py
+++ /tmp/uwz-task5c1-runtime-v5/test_listener.py
@@ -0,0 +1,96 @@
+"""Offline synthetic filesystem tests for the actual ownership helper."""
+import unittest
+from unittest.mock import patch
+
+import run_live
+
+
+class FakePath:
+    def __init__(self, entries, rows, directory_error=None):
+        self.entries = entries
+        self.rows = rows
+        self.directory_error = directory_error
+
+    def __call__(self, *parts):
+        return FakeNode(self, parts)
+
+
+class FakeNode:
+    def __init__(self, owner, parts):
+        self.owner = owner
+        self.parts = parts
+
+    def iterdir(self):
+        if self.owner.directory_error:
+            raise self.owner.directory_error
+        return iter(self.owner.entries)
+
+    def read_text(self):
+        if isinstance(self.owner.rows, BaseException):
+            raise self.owner.rows
+        return 'header\n' + ''.join(item + '\n' for item in self.owner.rows)
+
+
+def row(inode, endpoint='0100007F:6F1B', state='0A'):
+    return '0: %s 00000000:0000 %s 0 0 0 0 0 %s' % (endpoint, state, inode)
+
+
+def evaluate(entries, targets, rows, directory_error=None):
+    paths = FakePath(entries, rows, directory_error)
+
+    def readlink(entry):
+        value = targets[entry]
+        if isinstance(value, BaseException):
+            raise value
+        return value
+
+    with patch.object(run_live, 'Path', paths), patch.object(run_live.os, 'readlink', readlink):
+        result = run_live.owned_listener(17)
+        run_live.require(len(result) == 1, 'owned loopback listener not uniquely identified')
+        return result
+
+
+class ListenerTests(unittest.TestCase):
+    def test_disappearing_enumerated_nonlistener(self):
+        self.assertEqual(evaluate(['gone', 'listener'], {'gone': FileNotFoundError(2, 'gone', 'gone'),
+                         'listener': 'socket:[42]'}, [row('42')]), ['42'])
+
+    def test_missing_listener_wrong_inode_endpoint_or_state(self):
+        for rows in ([], [row('43')], [row('42', endpoint='0200007F:6F1B')], [row('42', state='01')]):
+            with self.subTest(rows=rows):
+                with self.assertRaisesRegex(RuntimeError, 'listener not uniquely'):
+                    evaluate(['listener'], {'listener': 'socket:[42]'}, rows)
+
+    def test_multiple_owned_listeners_fail(self):
+        with self.assertRaisesRegex(RuntimeError, 'listener not uniquely'):
+            evaluate(['first', 'second'], {'first': 'socket:[42]', 'second': 'socket:[43]'}, [row('42'), row('43')])
+
+    def test_listener_table_error_propagates(self):
+        with self.assertRaises(PermissionError):
+            evaluate(['listener'], {'listener': 'socket:[42]'}, PermissionError(13, 'denied', '/proc/net/tcp'))
+
+    def test_missing_child_directory_propagates(self):
+        with self.assertRaises(FileNotFoundError):
+            evaluate([], {}, [row('42')], FileNotFoundError(2, 'missing child', '/proc/17/fd'))
+
+    def test_permission_and_other_io_errors_propagate(self):
+        for exc in (PermissionError(13, 'denied', 'entry'), OSError(5, 'io', 'entry')):
+            with self.subTest(error=exc):
+                with self.assertRaises(type(exc)):
+                    evaluate(['bad', 'listener'], {'bad': exc, 'listener': 'socket:[42]'}, [row('42')])
+
+    def test_failure_details_retain_type_filename_traceback_and_stage(self):
+        try:
+            raise FileNotFoundError(2, 'missing', '/synthetic/path')
+        except FileNotFoundError as exc:
+            detail = run_live.failure_details(exc, 'case:peer_reset:connect')
+        self.assertEqual(detail['type'], 'FileNotFoundError')
+        self.assertEqual(detail['filename'], '/synthetic/path')
+        self.assertIn('missing', detail['message'])
+        self.assertEqual(detail['stage'], 'case:peer_reset:connect')
+        self.assertIn('FileNotFoundError', detail['traceback'])
+        self.assertIn('test_failure_details', detail['traceback'])
+
+
+if __name__ == '__main__':
+    unittest.main()

# Actual new freeze recipe
"""Freeze current runtime modules and bind current fixture build receipts."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspaces/uWebZockets')
BASE = HERE.parent / 'metadata/fix1/manifest.json'
FROZEN = Path('/tmp/uwz-task5c1-runtime-v5')
MANIFEST = HERE / 'manifest-v5.json'
NAMES = ('run_live.py', 'cases.py', 'wire.py', 'raw_observer.py', 'flow_ledger.py', 'validate_builds.py', 'test_observer.py', 'test_credit_case.py', 'test_listener.py')


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        while data := stream.read(1048576):
            h.update(data)
    return h.hexdigest()


def inventory(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    if FROZEN.exists() or MANIFEST.exists():
        raise ValueError('snapshot or manifest exists')
    base = json.loads(BASE.read_text())
    keep = [p for p in base['trees'] if not p.startswith('/tmp/uwz-task5b4')]
    trees = {}
    for root in keep:
        current = inventory(Path(root))
        if current != base['trees'][root]:
            raise ValueError('reviewed tree differs: ' + root)
        trees[root] = current
    FROZEN.mkdir(mode=0o700)
    for name in NAMES:
        shutil.copyfile(HERE / name, FROZEN / name)
        (FROZEN / name).chmod(0o444)
    FROZEN.chmod(0o555)
    trees[str(FROZEN)] = inventory(FROZEN)
    trees['/tmp/uwz-task5c1-fixture-v1'] = inventory(Path('/tmp/uwz-task5c1-fixture-v1'))
    retained = ('/home/codespace/.python/current/', '/lib/', '/lib64/', '/opt/conda/')
    inputs = {p: h for p, h in base['inputs'].items() if p.startswith(retained)}
    helper = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'
    inputs[helper] = '07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00'
    receipts = [str(HERE / ('fixture-' + mode + '-v1.json')) for mode in ('debug', 'release')]
    for receipt_path in receipts:
        receipt = json.loads(Path(receipt_path).read_text())
        inputs.update(receipt['input_before'])
        inputs[receipt_path] = digest(receipt_path)
        for name in (receipt['stdout'], receipt['stderr']):
            path = str(HERE / name)
            inputs[path] = digest(path)
        output = next(v.split('=', 1)[1] for v in receipt['argv'] if v.startswith('-femit-bin='))
        inputs[output] = receipt['binary_sha256']
    for name in NAMES:
        inputs[str(FROZEN / name)] = digest(FROZEN / name)
        inputs[str(HERE / name)] = digest(HERE / name)
    for name in ('profile.zig', 'compile_fixture.py', 'freeze_runtime.py'):
        inputs[str(HERE / name)] = digest(HERE / name)
    for path, value in inputs.items():
        if digest(path) != value:
            raise ValueError('input differs: ' + path)
    approved = json.loads((HERE.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
    validator = load('validate_builds', FROZEN / 'validate_builds.py')
    manifest = {'state': 'ready-for-independent-review', 'scope': 'intermediate fixture builds and current runtime sources; no live execution',
                'trees': trees, 'tree_counts': {p: len(v) for p, v in trees.items()}, 'inputs': inputs,
                'build_input_receipts': receipts, 'approved_archives': {p: approved[p] for p in validator.ARCHIVES},
                'binary': '/tmp/uwz-task5c1-fixture-release-v1/profile', 'helper': helper,
                'environment': {'LC_ALL': 'C.UTF-8', 'PYTHONPATH': '/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'},
                'python': '/home/codespace/.python/current/bin/python3', 'python_flags': ['-B', '-S']}
    for key, name in (('runner', 'run_live.py'), ('cases', 'cases.py'), ('wire', 'wire.py'), ('raw', 'raw_observer.py'), ('flow', 'flow_ledger.py'), ('validator', 'validate_builds.py')):
        manifest[key] = str(FROZEN / name)
    validator.validate(manifest, inputs)
    MANIFEST.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    print('frozen runtime files:', len(trees[str(FROZEN)]))
    print('tree counts:', manifest['tree_counts'])
    print('direct inputs:', len(inputs))
    print('manifest sha256:', digest(MANIFEST))


if __name__ == '__main__':
    main()
