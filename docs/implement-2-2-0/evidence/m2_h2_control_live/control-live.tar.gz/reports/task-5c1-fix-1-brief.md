# Task5c1 fix round1/5

Resume the same implementation. Read the original brief, current v3 report and
task-5c1-review.md. Root read the actual source at both cited locations and
accepts the finding. Current v3 package/manifest/frozen snapshots and actual
compile receipts remain preserved. This is source preparation only; no native
release, constructors, clients/servers/sockets/certificates or live checks.
You are not alone; no product/pin/docs/previous evidence/refs changes, commits,
push or subagents. Same lifecycle-control/ and /tmp/uwz-task5c1-* ownership.

Open finding verbatim:

P2 — Sibling credit can mask unreclaimed primary credit. cases.py:63 completes
the sibling's one-byte upload before checking the primary's7/32-byte reclamation
target. run_live.py:420 compares that target against cumulative connection
refunds, including the sibling. If cancel_ready refunds only six primary bytes
and the sibling refunds one, the target passes; the public-window comparison
and subsequent recovery also pass with one primary byte still missing. The
equivalent31+1 scenario affects the other primaries. Observe the primary target
while the sibling remains headers-only, then finish the sibling and retain its
separate accounting. Add an offline regression rejecting this partial-primary-
refund scenario.

Ruling: preserve the adopted architecture's explicit credit-before-sibling-DATA
sequence. Original brief prose listed sibling completion first ambiguously;
its binding reclamation requirement and the adopted architecture require an
independent primary oracle. This correction strengthens that oracle without
changing any primary/recovery expected bytes/counters/codes or production cap.

Fix actual cases.execute ordering so full primary7/32 connection-credit refund
is observed before sending sibling DATA. Retain an explicit primary-only credit
snapshot and subsequent separate sibling accounting. Recovery remains later.
Add a focused offline regression that exercises the actual case/credit path
with partial primary6/31 plus sibling1 and fails before the correction; include
the corresponding complete-primary success. Do not replace the requested
behavioral regression with AST/source-string assertions or a detached toy sum.
You may use pure caller-owned codec/accounting/test doubles; no native outcome
injection. Cover every affected primary and preserve existing offline coverage.
Name the covering test file(s) and retain exact RED/GREEN commands/output/status.

Freeze corrected runtime into a NEW snapshot/new current manifest; old v3 is
historical. Revalidate actual corrected current inputs/trees, both unchanged
native receipts and mutated actual input rejection. Actual fixture/native build
inputs should remain unchanged; no duplicate compile is needed unless changed.
Report actual new module/tree/input counts if the regression adds a file. Keep
all fixed active/history/frame/read/output/deadline bounds and previous tests.
Append the fix report with exact changes, tests, commands/raw results, hashes
and self-review to task-5c1-report.md. Return short status. Root then generates
the scoped diff from reviewed v3 and returns it to the original reviewer.
