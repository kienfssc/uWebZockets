P2: ADDRESSED. SPEC: PASS. QUALITY: PASS. FIX: PASS for scoped StageA.

Primary credit is fully observed before sibling DATA. Shared check requires
primary-only sent flow and complete7/32refund; sibling accounting is separate.
Offline regression exercises actual cases/ledger for all3primaries. No new
actionable findings or structural issues. Package,manifest-v4/eightmodules
match reported identities. Retained evidence only; no checks/tests/build/native
reruns. Preparation approval only, no live behavior/runtime authorization.
