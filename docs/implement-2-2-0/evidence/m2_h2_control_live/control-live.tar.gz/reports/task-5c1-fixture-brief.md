# Task5c1 next preparation pass: actual fixture

The observer-only partial report is accepted as unfinished work, not StageA
completion. Continue the SAME task/ownership from task-5c1-brief.md and keep its
full acceptance intact. To reduce the working set, this immediate pass owns
only the Zig configured-App fixture and actual Debug/ReleaseSafe compile-only
proof. Python lifecycle cases/process driver/final frozen closure follow in a
separate pass with the same implementer, before independent StageA review.

Keep the new observer/tests already written; do not restart them or repeat their
unchanged checks. Implement the exact three primaries and three recovery tags,
six histories/two reusable bindings/32fixed result records, expected110accepted/
B6E3C3, and all control/metadata/hash/terminal/metrics/postdeinit semantics in
the original brief. Use its unchanged profile and original source/override/
bindings/six libraries. No native activity, source/pin edits, previous artifact
changes, commits, push or subagents. You are not alone.

Use the reviewed metadata fixture ONLY as a local source pattern; remove
inapplicable metadata/credit/case scaffolding in your NEW fixture. Keep explicit
named types, independent owned expectations and persistent records, copied
owning-loop controls, shallow flow and no retained borrowed callback pointers.
Expose sufficient bounded status/control responses for the subsequent Python
driver, and document exact route/JSON contracts in your report. Keep all32
records and final metrics comparable after deinit within65536 output cap.

Prepare persistent source and a separate immutable fixture snapshot under
/tmp/uwz-task5c1-*. Retain exact compiler argv, environment, input maps and
stdout/stderr/exit statuses for actual Debug/ReleaseSafe builds, using-j2 and
/tmp caches/outputs. This is intermediate fixture compile evidence; do not call
it the final runtime closure before the remaining driver sources are frozen.
No source changes follow final successful compile without a covering rebuild.

Append exact changes/commands/results/hashes, route/status contract, self-review
and remaining driver/closure work to task-5c1-report.md; return short status.
Do not stop merely because work is substantial; finish this bounded fixture
pass or identify a concrete contract/context blocker for Root to resolve.
