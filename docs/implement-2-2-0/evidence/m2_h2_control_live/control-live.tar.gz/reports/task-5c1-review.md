SPEC: CHANGES REQUIRED. QUALITY: CHANGES REQUIRED.

P2 — Sibling credit can mask unreclaimed primary credit. cases.py:63 completes
the sibling's one-byte upload before checking the primary's7/32-byte reclamation
target. run_live.py:420 compares that target against cumulative connection
refunds, including the sibling. If cancel_ready refunds only six primary bytes
and the sibling refunds one, the target passes; the public-window comparison
and subsequent recovery also pass with one primary byte still missing. The
equivalent31+1 scenario affects the other primaries. Observe the primary target
while the sibling remains headers-only, then finish the sibling and retain its
separate accounting. Add an offline regression rejecting this partial-primary-
refund scenario.

No additional actionable structural findings under the requested maintainability
lens. No file exceeds1000lines; fixture, expectations, wire observation, credit
accounting and identity validation have separate ownership.

Read-only source/evidence review: package, manifest, fixture, seven runtime
modules and both receipt hashes match supplied identities; compiler output files
are empty. No tests, validators, inventories, builds or native activity rerun.
Retained results establish preparation only; live behavior and broader gates
remain unverified.
