"""Offline regression for actual case order and the caller-owned flow ledger."""
import unittest

import cases
import flow_ledger as flow


class CaseHarness:
    def __init__(self, case, refunded):
        self.case = case
        self.refunded = refunded
        self.ledger = flow.FlowLedger()
        self.next_stream = 1
        self.terminal = False
        self.recovery = False
        self.sibling_sent = False

    def open(self):
        stream = self.next_stream
        self.next_stream += 2
        flow.open_stream(self.ledger, stream)
        return stream

    def sibling(self):
        return self.open()

    def start(self, tag, policy):
        self.recovery = tag.endswith('_recovery')
        return self.open()

    def send(self, stream, count, end):
        flow.send_data(self.ledger, stream, count, None, 16384, end)

    def status(self, tag):
        peer = self.case == 'peer_reset'
        return {'begin': 1, 'accepted': 0 if peer else 7, 'end': 0,
                'cancel': int(self.terminal), 'paused': not self.terminal and self.case != 'cancel_ready',
                'chunks': 0 if peer else 1, 'reason': 'reset' if peer else 'cancelled',
                'active': not self.terminal}

    def pending(self, stream):
        return None

    def control(self, operation, tag, expected):
        if expected == 'ok':
            self.terminal = True
        return expected

    def peer_reset(self, stream):
        self.terminal = True
        return {'code': 8}

    def finish_terminal(self, stream):
        self.ledger.streams[stream].open = False
        flow.receive_batch(self.ledger, [(0, self.refunded)])
        return {'reset': True}

    def finish_sibling(self, stream):
        flow.send_data(self.ledger, stream, 1, None, 16384, True)
        flow.receive_batch(self.ledger, [(0, 1)])
        self.sibling_sent = True
        return {'body': 's'}

    def reclaim(self, target):
        if not flow.primary_refund_complete(self.ledger, target, self.ledger.connection):
            raise ValueError('primary refund incomplete')
        return {'target': target, 'sent': self.ledger.sent, 'refunded': self.ledger.refunded}

    def finish_recovery(self, stream):
        result = cases.expected(self.case + '_recovery', {self.case + '_recovery'})
        result.update(chunks=1, max_span=32)
        return result

    def api(self):
        return {name: getattr(self, name) for name in ('start', 'sibling', 'send', 'status', 'control',
                'peer_reset', 'finish_terminal', 'finish_sibling', 'reclaim', 'finish_recovery', 'pending')}


class CreditCaseTests(unittest.TestCase):
    def test_partial_primary_cannot_be_masked_by_sibling(self):
        for case, target in (('cancel_ready', 7), ('cancel_paused', 32), ('peer_reset', 32)):
            with self.subTest(case=case):
                harness = CaseHarness(case, target - 1)
                with self.assertRaisesRegex(ValueError, 'primary refund incomplete'):
                    cases.execute(harness.api(), case)
                self.assertFalse(harness.sibling_sent)

    def test_complete_primary_before_sibling_and_recovery(self):
        for case, target in (('cancel_ready', 7), ('cancel_paused', 32), ('peer_reset', 32)):
            with self.subTest(case=case):
                harness = CaseHarness(case, target)
                result = cases.execute(harness.api(), case)
                self.assertEqual(result['credit'], {'target': target, 'sent': target, 'refunded': target})
                self.assertTrue(harness.sibling_sent)
                self.assertEqual(harness.ledger.sent, target + 33)
                self.assertEqual(harness.ledger.refunded, target + 1)


if __name__ == '__main__':
    unittest.main()
