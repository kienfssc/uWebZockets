"""Offline frame-policy tests using the pinned hyperframe codec."""
import unittest

from hyperframe.frame import DataFrame, HeadersFrame, RstStreamFrame
import raw_observer as observer


def frame(kind, stream=1, code=8, end=False, payload=b''):
    item = kind(stream)
    if kind is RstStreamFrame:
        item.error_code = code
    else:
        item.data = payload
        if end:
            item.flags.add('END_STREAM')
    return item.serialize()


class ObserverTests(unittest.TestCase):
    def state(self, policy='healthy'):
        state = observer.new_state()
        observer.register(state, 1, policy)
        return state

    def test_public_cancel_fragmented_and_coalesced(self):
        state = self.state('public_cancel')
        raw = frame(RstStreamFrame) + frame(DataFrame, stream=3, payload=b'x')
        observer.register(state, 3, 'healthy')
        for part in (raw[:2], raw[2:11], raw[11:]):
            observer.observe(state, part)
        self.assertTrue(state['streams'][1]['reset'])
        self.assertIsNone(state['frame'])
        observer.retire(state, 1)

    def test_refusal_after_final(self):
        state = self.state('refusal_after_final')
        observer.observe(state, frame(DataFrame, end=True, payload=b'x') + frame(RstStreamFrame, code=0))
        observer.retire(state, 1)
        state = self.state('refusal_after_final')
        with self.assertRaises(ValueError):
            observer.observe(state, frame(RstStreamFrame, code=0))

    def test_wrong_reset_and_duplicates(self):
        for raw in (frame(RstStreamFrame, stream=3), frame(RstStreamFrame, code=2),
                    frame(RstStreamFrame) * 2):
            with self.subTest(raw=raw):
                with self.assertRaises(ValueError):
                    observer.observe(self.state('public_cancel'), raw)
        state = self.state('public_cancel')
        with self.assertRaises(ValueError):
            observer.retire(state, 1)
        observer.observe(state, frame(RstStreamFrame))
        observer.retire(state, 1)
        with self.assertRaises(ValueError):
            observer.observe(state, frame(RstStreamFrame))

    def test_payload_after_terminal(self):
        for terminal, policy in ((frame(DataFrame, end=True), 'healthy'),
                                 (frame(RstStreamFrame), 'public_cancel')):
            for kind in (DataFrame, HeadersFrame):
                with self.subTest(policy=policy, kind=kind):
                    state = self.state(policy)
                    observer.observe(state, terminal)
                    with self.assertRaises(ValueError):
                        observer.observe(state, frame(kind, payload=b'x'))

    def test_end_only_after_payload(self):
        state = self.state()
        raw = frame(DataFrame, end=True, payload=b'abc')
        observer.observe(state, raw[:-1])
        self.assertFalse(state['streams'][1]['end'])
        observer.observe(state, raw[-1:])
        self.assertTrue(state['streams'][1]['end'])

    def test_peer_reset_is_local_observation_only(self):
        state = self.state('peer_reset')
        with self.assertRaises(ValueError):
            observer.retire(state, 1)
        observer.mark_peer_reset(state, 1, 8)
        with self.assertRaises(ValueError):
            observer.observe(state, frame(RstStreamFrame))
        observer.retire(state, 1)
        with self.assertRaises(ValueError):
            observer.observe(state, frame(DataFrame, payload=b'x'))

    def test_more_than_32_sequential_responses_and_old_id(self):
        state = observer.new_state()
        for stream in range(1, 81, 2):
            observer.register(state, stream, 'healthy')
            observer.observe(state, frame(DataFrame, stream=stream, end=True))
            observer.retire(state, stream)
        with self.assertRaises(ValueError):
            observer.observe(state, frame(DataFrame, stream=1, payload=b'x'))
        with self.assertRaises(ValueError):
            observer.observe(state, frame(RstStreamFrame, stream=1))
        with self.assertRaises(ValueError):
            observer.register(state, 1, 'healthy')

    def test_bounds(self):
        state = self.state()
        with self.assertRaises(ValueError):
            observer.observe(state, b'x' * (observer.READ_BOUND + 1))
        with self.assertRaises(ValueError):
            observer.observe(observer.new_state(), b'\x00\x40\x01\x00\x00\x00\x00\x00\x01')
        for stream in range(3, 16, 2):
            observer.register(state, stream, 'healthy')
        with self.assertRaises(ValueError):
            observer.register(state, 17, 'healthy')


if __name__ == '__main__':
    unittest.main()
