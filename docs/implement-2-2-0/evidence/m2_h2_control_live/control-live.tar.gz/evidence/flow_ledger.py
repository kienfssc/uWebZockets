"""Caller-owned HTTP/2 outbound credit accounting; no transport effects."""
from dataclasses import dataclass, field

INITIAL = 65535
MAX_STREAMS = 8


@dataclass
class StreamCredit:
    window: int
    sent: int = 0
    refunded: int = 0
    open: bool = True


@dataclass
class FlowLedger:
    connection: int = INITIAL
    initial_stream: int = INITIAL
    sent: int = 0
    refunded: int = 0
    streams: dict[int, StreamCredit] = field(default_factory=dict)
    unchanged_settings: bool = True


def open_stream(ledger: FlowLedger, stream_id: int) -> None:
    if stream_id in ledger.streams or len(ledger.streams) >= MAX_STREAMS:
        raise ValueError('duplicate stream or stream capacity exceeded')
    ledger.streams[stream_id] = StreamCredit(ledger.initial_stream)


def send_data(ledger: FlowLedger, stream_id: int, payload: int, padding: int | None, max_frame: int, finished: bool = False) -> int:
    stream = ledger.streams[stream_id]
    if not stream.open or payload < 0 or padding is not None and not 0 <= padding <= 255:
        raise ValueError('invalid DATA request')
    flow = payload + (padding + 1 if padding is not None else 0)
    if flow > min(ledger.connection, stream.window, max_frame):
        raise ValueError('DATA exceeds public credit or frame limit')
    ledger.connection -= flow
    ledger.sent += flow
    stream.window -= flow
    stream.sent += flow
    stream.open = not finished
    return flow


def receive_batch(ledger: FlowLedger, updates: list[tuple[int, int]], new_initial: int | None = None) -> None:
    if new_initial is not None:
        if not 0 <= new_initial <= 2147483647:
            raise ValueError('invalid initial window')
        change = new_initial - ledger.initial_stream
        ledger.initial_stream = new_initial
        ledger.unchanged_settings = ledger.unchanged_settings and change == 0
        for stream in ledger.streams.values():
            if stream.open:
                stream.window += change
    for stream_id, delta in updates:
        if delta <= 0:
            raise ValueError('invalid window update')
        if stream_id == 0:
            ledger.connection += delta
            ledger.refunded += delta
        else:
            stream = ledger.streams[stream_id]
            stream.window += delta
            stream.refunded += delta
    if ledger.unchanged_settings:
        if not 0 <= ledger.connection <= INITIAL or ledger.refunded > ledger.sent:
            raise ValueError('invalid connection refund')
        for stream in ledger.streams.values():
            if stream.refunded > stream.sent or stream.open and not 0 <= stream.window <= INITIAL:
                raise ValueError('invalid stream refund')


def check_public(ledger: FlowLedger, connection_window: int, stream_windows: dict[int, int]) -> None:
    if connection_window != ledger.connection:
        raise ValueError('connection window differs')
    for stream_id, public_window in stream_windows.items():
        stream = ledger.streams[stream_id]
        if not stream.open or public_window != min(ledger.connection, stream.window):
            raise ValueError('stream minimum differs or stream closed')


def primary_refund_complete(ledger: FlowLedger, target: int, public_window: int) -> bool:
    if target not in (7, 32) or ledger.sent != target or ledger.refunded > ledger.sent:
        raise ValueError('primary-only flow differs')
    check_public(ledger, public_window, {})
    return ledger.refunded == target
