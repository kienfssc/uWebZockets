"""Bounded HTTP/2 response event and raw reset observation."""
import hashlib
import h2.events
import raw_observer

READ_BOUND = 8192
STREAM_LIMIT = 8
HEADER_FIELDS = 32
HEADER_BYTES = 4096
INFO_COUNT = 16
INFO_BYTES = 16384
EVENT_LIMIT = 64


def require(condition, message):
    if not condition:
        raise ValueError(message)


def register(records, raw, stream_id, body_limit, final_status, info_count, policy):
    require(len(records) < STREAM_LIMIT and stream_id not in records, 'stream record bound')
    require(0 <= body_limit < 4096 and info_count in (0, 1), 'invalid expectation')
    raw_observer.register(raw, stream_id, policy)
    records[stream_id] = {'headers': None, 'informationals': 0, 'info_bytes': 0,
                          'bytes': 0, 'hash': hashlib.sha256(), 'body': bytearray(),
                          'limit': body_limit, 'ended': False, 'reset_event': False,
                          'status': str(final_status), 'expected_info': info_count,
                          'policy': policy}


def checked_headers(headers):
    require(len(headers) <= HEADER_FIELDS, 'header field count bound')
    size = sum(len(k.encode('utf-8')) + len(v.encode('utf-8')) + 32 for k, v in headers)
    require(size <= HEADER_BYTES, 'header byte bound')
    return size


def accept(protocol, data, records, raw, trace):
    require(len(data) <= READ_BOUND, 'read exceeds bound')
    raw_observer.observe(raw, data)
    events = protocol.receive_data(data)
    for event in events:
        name = type(event).__name__
        require(name in trace or len(trace) < EVENT_LIMIT, 'event type bound')
        trace[name] = trace.get(name, 0) + 1
        if isinstance(event, h2.events.ConnectionTerminated):
            raise ValueError('HTTP/2 connection terminated')
        if not isinstance(event, (h2.events.InformationalResponseReceived, h2.events.ResponseReceived,
                                  h2.events.TrailersReceived, h2.events.DataReceived,
                                  h2.events.StreamEnded, h2.events.StreamReset)):
            continue
        require(event.stream_id in records, 'unregistered response stream')
        record = records[event.stream_id]
        if isinstance(event, h2.events.InformationalResponseReceived):
            size = checked_headers(event.headers)
            require(record['informationals'] < INFO_COUNT and record['info_bytes'] + size <= INFO_BYTES,
                    'informational bound')
            require(record['headers'] is None and [v for k, v in event.headers if k == ':status'] == ['100'] and not any(k == 'x-middleware' for k, _ in event.headers), 'unexpected informational')
            record['informationals'] += 1
            record['info_bytes'] += size
            require(record['informationals'] <= record['expected_info'], 'extra informational')
        elif isinstance(event, h2.events.ResponseReceived):
            checked_headers(event.headers)
            require(record['headers'] is None, 'duplicate response headers')
            require([v for k, v in event.headers if k == ':status'] == [record['status']], 'wrong final status')
            require([v for k, v in event.headers if k == 'x-middleware'] == ['retained'], 'middleware header')
            record['headers'] = list(event.headers)
        elif isinstance(event, h2.events.TrailersReceived):
            raise ValueError('unexpected trailers')
        elif isinstance(event, h2.events.DataReceived):
            require(not record['ended'] and record['bytes'] + len(event.data) <= record['limit'], 'response body bound')
            record['bytes'] += len(event.data)
            record['hash'].update(event.data)
            record['body'].extend(event.data)
            protocol.acknowledge_received_data(event.flow_controlled_length, event.stream_id)
        elif isinstance(event, h2.events.StreamEnded):
            require(not record['ended'], 'duplicate end')
            record['ended'] = True
        elif isinstance(event, h2.events.StreamReset):
            require(record['policy'] in ('public_cancel', 'refusal_after_final') and raw['streams'][event.stream_id]['reset'], 'unexpected reset event')
            code = 8 if record['policy'] == 'public_cancel' else 0
            require(not record['reset_event'] and int(event.error_code) == code, 'invalid reset event')
            record['reset_event'] = True

    return events


def complete(records, raw, stream_id):
    record = records[stream_id]
    policy = record['policy']
    if policy in ('healthy', 'refusal_after_final'):
        require(record['headers'] is not None and record['ended'], 'missing final')
    else:
        require(record['headers'] is None and not record['ended'], 'unexpected final')
    require(record['informationals'] == record['expected_info'], 'missing informational')
    require(raw['streams'][stream_id]['reset'] == (policy in ('public_cancel', 'refusal_after_final')), 'missing reset')
    if policy == 'peer_reset':
        require(raw['streams'][stream_id]['peer_reset'], 'missing outgoing reset')


def retire(records, raw, stream_id):
    complete(records, raw, stream_id)
    raw_observer.retire(raw, stream_id)
    del records[stream_id]
