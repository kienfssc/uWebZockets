"""Freeze current runtime modules and bind current fixture build receipts."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspaces/uWebZockets')
BASE = HERE.parent / 'metadata/fix1/manifest.json'
FROZEN = Path('/tmp/uwz-task5c1-runtime-v5')
MANIFEST = HERE / 'manifest-v5.json'
NAMES = ('run_live.py', 'cases.py', 'wire.py', 'raw_observer.py', 'flow_ledger.py', 'validate_builds.py', 'test_observer.py', 'test_credit_case.py', 'test_listener.py')


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        while data := stream.read(1048576):
            h.update(data)
    return h.hexdigest()


def inventory(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    if FROZEN.exists() or MANIFEST.exists():
        raise ValueError('snapshot or manifest exists')
    base = json.loads(BASE.read_text())
    keep = [p for p in base['trees'] if not p.startswith('/tmp/uwz-task5b4')]
    trees = {}
    for root in keep:
        current = inventory(Path(root))
        if current != base['trees'][root]:
            raise ValueError('reviewed tree differs: ' + root)
        trees[root] = current
    FROZEN.mkdir(mode=0o700)
    for name in NAMES:
        shutil.copyfile(HERE / name, FROZEN / name)
        (FROZEN / name).chmod(0o444)
    FROZEN.chmod(0o555)
    trees[str(FROZEN)] = inventory(FROZEN)
    trees['/tmp/uwz-task5c1-fixture-v1'] = inventory(Path('/tmp/uwz-task5c1-fixture-v1'))
    retained = ('/home/codespace/.python/current/', '/lib/', '/lib64/', '/opt/conda/')
    inputs = {p: h for p, h in base['inputs'].items() if p.startswith(retained)}
    helper = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'
    inputs[helper] = '07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00'
    receipts = [str(HERE / ('fixture-' + mode + '-v1.json')) for mode in ('debug', 'release')]
    for receipt_path in receipts:
        receipt = json.loads(Path(receipt_path).read_text())
        inputs.update(receipt['input_before'])
        inputs[receipt_path] = digest(receipt_path)
        for name in (receipt['stdout'], receipt['stderr']):
            path = str(HERE / name)
            inputs[path] = digest(path)
        output = next(v.split('=', 1)[1] for v in receipt['argv'] if v.startswith('-femit-bin='))
        inputs[output] = receipt['binary_sha256']
    for name in NAMES:
        inputs[str(FROZEN / name)] = digest(FROZEN / name)
        inputs[str(HERE / name)] = digest(HERE / name)
    for name in ('profile.zig', 'compile_fixture.py', 'freeze_runtime.py'):
        inputs[str(HERE / name)] = digest(HERE / name)
    for path, value in inputs.items():
        if digest(path) != value:
            raise ValueError('input differs: ' + path)
    approved = json.loads((HERE.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
    validator = load('validate_builds', FROZEN / 'validate_builds.py')
    manifest = {'state': 'ready-for-independent-review', 'scope': 'intermediate fixture builds and current runtime sources; no live execution',
                'trees': trees, 'tree_counts': {p: len(v) for p, v in trees.items()}, 'inputs': inputs,
                'build_input_receipts': receipts, 'approved_archives': {p: approved[p] for p in validator.ARCHIVES},
                'binary': '/tmp/uwz-task5c1-fixture-release-v1/profile', 'helper': helper,
                'environment': {'LC_ALL': 'C.UTF-8', 'PYTHONPATH': '/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'},
                'python': '/home/codespace/.python/current/bin/python3', 'python_flags': ['-B', '-S']}
    for key, name in (('runner', 'run_live.py'), ('cases', 'cases.py'), ('wire', 'wire.py'), ('raw', 'raw_observer.py'), ('flow', 'flow_ledger.py'), ('validator', 'validate_builds.py')):
        manifest[key] = str(FROZEN / name)
    validator.validate(manifest, inputs)
    MANIFEST.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    print('frozen runtime files:', len(trees[str(FROZEN)]))
    print('tree counts:', manifest['tree_counts'])
    print('direct inputs:', len(inputs))
    print('manifest sha256:', digest(MANIFEST))


if __name__ == '__main__':
    main()
