"""Independent audit of retained ordinary public-control run evidence."""
import hashlib
import json
import ssl
from pathlib import Path


root = Path('/workspaces/uWebZockets')
base = root / '.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control'
raw = base / 'stage-b/result.json'
result = json.loads(raw.read_text())
assert result['success'] and result['error'] is None and result['failure'] is None
assert result['manifest_sha256'] == 'd74acb0bf0586bdcace73bb772c376ea39e4ea7036da826828a59ee321882f18'
assert result['child']['binary_sha256'] == 'eeba98819132a39b72480f43c0b7b3b244fed883cb7580d5ba63e1b4d15bdc2b'
assert result['cleanup'] == {'signal': 'SIGTERM', 'exit_code': 0, 'reaped': True, 'forced': False, 'errors': []}
primaries = ('cancel_ready', 'cancel_paused', 'peer_reset')
assert list(result['cases']) == [*primaries, 'shutdown_idle']
assert result['cases']['shutdown_idle'] == {'exit_code': 0, 'post_deinit': True}
p32 = bytes(range(1, 11)) + b'final-upload-sentinel!'
h32 = hashlib.sha256(p32).hexdigest()
h7 = hashlib.sha256(p32[:7]).hexdigest()
empty = hashlib.sha256(b'').hexdigest()
for name in primaries:
    case = result['cases'][name]
    accepted = 0 if name == 'peer_reset' else 7
    target = 7 if name == 'cancel_ready' else 32
    before, terminal = case['before'], case['terminal']
    assert (before['begin'], before['end'], before['cancel'], before['accepted'], before['paused']) == (1, 0, 0, accepted, name != 'cancel_ready')
    assert (terminal['begin'], terminal['end'], terminal['cancel'], terminal['accepted'], terminal['active'], terminal['paused']) == (1, 0, 1, accepted, False, False)
    assert terminal['reason'] == ('reset' if name == 'peer_reset' else 'cancelled')
    assert terminal['sha256'] == (empty if accepted == 0 else h7)
    if name == 'peer_reset':
        assert before['chunks'] == 0 and terminal['chunks'] == 0
        assert case['operation']['code'] == 8
    else:
        assert case['operation']['body'] == 'ok'
    wire = case['terminal_wire']
    assert wire['headers'] is None and wire['bytes'] == 0 and wire['informationals'] == 0
    assert wire['raw_reset'] == (name != 'peer_reset')
    credit = case['credit']
    assert credit == {'target': target, 'sent': target, 'refunded': target, 'connection_window': 65535, 'public_window': 65535}
    sibling = case['sibling']
    assert sibling['body'] == 's' and sibling['bytes'] == 1 and not sibling['raw_reset']
    flow = sibling['flow']
    assert flow['sent_before'] == target and flow['sent_after'] == target + 1
    assert flow['refunded_before'] == target and target <= flow['refunded_after'] <= target + 1
    for phase in ('stale_before', 'stale_after'):
        assert len(case[phase]) == 2
        assert all(item['body'] == 'BodyControlExpired' and not item['raw_reset'] for item in case[phase])
    recovery = case['recovery']
    assert (recovery['accepted'], recovery['sha256'], recovery['begin'], recovery['end'], recovery['cancel']) == (32, h32, 1, 1, 0)
statuses = result['final_status']
assert len(statuses) == 32
admitted = {tag for name in primaries for tag in (name, name + '_recovery')}
assert set(statuses) == admitted | {'spare_' + str(i).zfill(2) for i in range(26)}
for tag, row in statuses.items():
    assert row['tag'] == tag and not row['active'] and not row['paused'] and row['errors'] == 0
    if tag not in admitted:
        assert all(row[k] == 0 for k in ('middleware', 'attempts', 'begin', 'end', 'cancel', 'failure', 'end_errors', 'accepted', 'chunks', 'max_span', 'metadata_middleware', 'metadata_begin', 'metadata_end', 'stale_resume', 'stale_cancel'))
        assert row['sha256'] == empty and row['reason'] == 'none'
        continue
    recovery = tag.endswith('_recovery')
    accepted = 32 if recovery else 0 if tag == 'peer_reset' else 7
    assert (row['middleware'], row['attempts'], row['begin'], row['end'], row['cancel'], row['failure'], row['end_errors'], row['accepted']) == (1, 1, 1, int(recovery), int(not recovery), 0, 0, accepted)
    assert row['sha256'] == (h32 if recovery else empty if accepted == 0 else h7)
    assert row['metadata_middleware'] == row['metadata_begin'] == 1
    assert row['metadata_end'] == int(recovery)
    assert row['stale_resume'] == row['stale_cancel'] == (0 if recovery else 2)
metrics = result['final_metrics']
assert metrics == {'middleware': 6, 'attempts': 6, 'begin': 6, 'end': 3, 'cancel': 3, 'failure': 0, 'end_errors': 0, 'accepted': 110, 'active': 0, 'errors': 0, 'buffered_middleware': 60, 'slot0_active': False, 'slot1_active': False}
log = (base / 'stage-b/server.log').read_text()
rows, summaries = {}, []
for line in log.splitlines():
    marker = 'H2_RECORD ' + result['nonce'] + ' '
    if marker in line:
        row = json.loads(line.split(marker, 1)[1])
        assert row['tag'] not in rows
        rows[row['tag']] = row
    marker = 'H2_DEINIT ' + result['nonce'] + ' '
    if marker in line:
        summaries.append(json.loads(line.split(marker, 1)[1]))
assert rows == statuses and summaries == [metrics]
assert len(log.encode()) == 14682 and len(log.encode()) < 65536
connections = result['connections']
assert len(connections) == 4 and all(c['tls'] == 'TLSv1.3' and c['alpn'] == 'h2' for c in connections)
assert [c['case'] for c in connections] == [*primaries, 'shutdown_idle']
sent = sum(c['sent_flow'] for c in connections if 'sent_flow' in c)
refunded = sum(c['refunded_flow'] for c in connections if 'refunded_flow' in c)
assert sent == 170 and 0 <= refunded <= sent
der = ssl.PEM_cert_to_DER_cert((base / 'stage-b/certificate.pem').read_text())
assert hashlib.sha256(der).hexdigest() == result['certificate_sha256']
assert not Path('/proc', str(result['child']['pid'])).exists()
assert not Path('/tmp/uwz-h2-lifecycle-control-owned-2026-10-29-r2/private-key.pem').exists()
preflight = root / '.superpowers/sdd/h2_streaming_plan/task-5c1-root-preflight-v5.json'
assert hashlib.sha256(preflight.read_bytes()).hexdigest() == 'ffb47bc3b00ca0d0eb7cf766d6d4bb69cb4d8a4e589391433552afce20765e84'
audit = {'checks_passed': True, 'result_sha256': hashlib.sha256(raw.read_bytes()).hexdigest(),
         'cases_passed': [*primaries, 'shutdown_idle'], 'totals': metrics,
         'post_deinit_records_match': 32, 'post_deinit_metrics_match': True,
         'primary_credit_targets': [7, 32, 32], 'client_data_flow_sent': sent,
         'client_data_flow_refunded': refunded, 'fresh_tls_connections': 4,
         'child_exit_zero_reaped': True, 'host_pid_absent': True, 'key_absent': True,
         'server_log_bytes': len(log.encode()), 'postrun_preflight_identical': True,
         'scope': 'Ordinary owned protocol/application assertions; no full matrix, physical lifetime, performance or production adoption claim.'}
output = base / 'stage-b/root-result-audit.json'
output.write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit, indent=2))
