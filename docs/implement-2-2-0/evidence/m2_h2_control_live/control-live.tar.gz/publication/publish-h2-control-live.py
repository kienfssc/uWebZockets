"""Publish the reviewed public-control fixture and both owned run outcomes."""
import gzip
import importlib.util
import json
from pathlib import Path


def main():
    root = Path('/workspaces/uWebZockets')
    evidence = root / '.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control'
    workspace = root / '.superpowers/sdd/h2_streaming_plan'
    common_path = root / '.uwz-work/tools/publish-h2-admission-live.py'
    spec = importlib.util.spec_from_file_location('publication_common', common_path)
    assert spec is not None and spec.loader is not None
    common = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(common)
    audit = json.loads((evidence / 'stage-b/root-result-audit.json').read_text())
    first = json.loads((evidence / 'stage-b-attempt1/result.json').read_text())
    assert audit['checks_passed'] and audit['post_deinit_records_match'] == 32
    assert audit['post_deinit_metrics_match'] and audit['child_exit_zero_reaped']
    assert audit['host_pid_absent'] and audit['key_absent'] and audit['postrun_preflight_identical']
    assert not first['success'] and first['cleanup']['forced'] and first['cleanup']['reaped']
    assert first['cleanup']['exit_code'] == -9
    members = {}
    for path in sorted(evidence.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            common.add_file(members, 'evidence/' + path.relative_to(evidence).as_posix(), path)
    for path in sorted(Path('/tmp/uwz-task5c1-fixture-v1').iterdir()):
        common.add_file(members, 'source/fixture-v1/' + path.name, path)
    for version in range(1, 6):
        for path in sorted(Path('/tmp/uwz-task5c1-runtime-v' + str(version)).iterdir()):
            common.add_file(members, 'source/runtime-v' + str(version) + '/' + path.name, path)
    for pattern in ('task-5c1-*.md', 'task-5c1-*.json'):
        for path in sorted(workspace.glob(pattern)):
            common.add_file(members, 'reports/' + path.name, path)
    for path in sorted((workspace / 'task-5c1-retained').iterdir()):
        common.add_file(members, 'retained/' + path.name, path)
    for name in ('task-5-plan.md', 'task-5c-lifecycle-architecture.md'):
        common.add_file(members, 'reports/' + name, workspace / name)
    common.add_file(members, 'reports/component.md', root / 'docs/implement-2-2-0/m2_h2_control_live.md')
    inputs = {'h2_client.py': '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py',
              'c-native.zig': '.uwz-work/evidence/h1-transport/r2/c-native.zig',
              'immutable-libxev-input.json': '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json',
              'focused-final-ReleaseSafe.command.json': '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json'}
    for name, path in inputs.items():
        common.add_file(members, 'inputs/' + name, root / path)
    tools = root / '.uwz-work/tools'
    for name in ('audit-h2-lifecycle-control.py', 'audit-h2-lifecycle-control-v3.py',
                 'audit-h2-lifecycle-control-v4.py', 'audit-h2-control-result.py',
                 'publish-h2-control-live.py', 'publish-h2-admission-live.py',
                 'audit-h2-control-publication.py'):
        common.add_file(members, 'publication/' + name, tools / name)
    for name, data in members.items():
        data.decode('utf-8')
        assert not data.startswith(b'\0asm'), name
    inventory = [{'path': name, 'bytes': len(data), 'sha256': common.digest(data)} for name, data in sorted(members.items())]
    members['inventory.json'] = (json.dumps({'scope': 'Publication bytes. Current executed subject is fixture-v1 plus runtime-v5. Older sources and failed attempt remain historical.', 'files': inventory}, indent=2) + '\n').encode()
    output = root / 'docs/implement-2-2-0/evidence/m2_h2_control_live'
    output.mkdir(parents=True, exist_ok=True)
    archive = output / 'control-live.tar.gz'
    archive.write_bytes(gzip.compress(common.tar_bytes(members), mtime=0))
    prior = json.loads((root / 'docs/implement-2-2-0/evidence/m2_h2_metadata_live/manifest.json').read_text())
    proved = sorted(set(prior['all_verified_case_ids'] + audit['cases_passed']))
    remaining = [name for name in prior['planned_unimplemented'] if name not in audit['cases_passed']]
    assert len(proved) == 29 and len(remaining) == 11 and not set(proved) & set(remaining)
    manifest = {'scope': 'Owned Linux ReleaseSafe TLS1.3/h2 ready/paused cancellation, peer reset, independent recovery and idle teardown. Full milestone/adoption open.',
        'archive': archive.name, 'archive_sha256': common.digest(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
        'safe_regular_members': len(members), 'inventory_entries': len(inventory),
        'source_digest': 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de', 'source_files': 1031,
        'source_checkpoint': '../m2_h2_native_tcp/README.md', 'source_delta_checkpoint': '../m2_h2_metadata_live/README.md',
        'profile_sha256': 'fbb931e4f3e870c62280f38e90cf6499203d8cffc7d9d6c2e071ef2d917b1579',
        'binary_sha256': 'eeba98819132a39b72480f43c0b7b3b244fed883cb7580d5ba63e1b4d15bdc2b',
        'review_manifest_sha256': common.digest((evidence / 'manifest-v5.json').read_bytes()),
        'preflight_sha256': common.digest((evidence / 'root-preflight-v5.json').read_bytes()),
        'authorization_sha256': common.digest((evidence / 'stage-b-authorization-r2.json').read_bytes()),
        'result_sha256': audit['result_sha256'], 'root_result_audit_sha256': common.digest((evidence / 'stage-b/root-result-audit.json').read_bytes()),
        'cases_passed': audit['cases_passed'], 'all_verified_case_ids': proved, 'planned_unimplemented': remaining,
        'totals': audit['totals'], 'primary_credit_targets': audit['primary_credit_targets'],
        'client_data_flow_sent': 170, 'client_data_flow_refunded': 170,
        'post_deinit_records_equal': 32, 'post_deinit_metrics_equal': True, 'fresh_tls_connections': 4,
        'server_log_bytes': 14682, 'exit_status': 0, 'runtime_mode': 'ReleaseSafe',
        'owned_attempts': 2, 'completed_successful_runs': 1, 'automatic_retries': 0,
        'prior_failure': {'result_sha256': common.digest((evidence / 'stage-b-attempt1/result.json').read_bytes()),
                          'completed_case_records': list(first['cases']), 'success': False,
                          'error': first['error'], 'exact_failed_path': 'unproved; original filename/traceback unretained',
                          'cleanup': first['cleanup']},
        'child_exit_zero_reaped': True, 'private_key_removed': True, 'postrun_preflight_identical': True,
        'remaining': ['11 further H2 IDs and combined matrix', 'H3/multipart/genuine early data',
                      'Full quality/platform/compliance/physical gates', 'Maintained publication, production adoption and original milestones']}
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (output / 'README.md').write_text(f'''# Owned HTTP/2 control evidence

The [archive](control-live.tar.gz) contains actual fixture and runtime sources,
all retained versions, exact compiler recipes/receipts, full input maps,
offline regressions and failures, initial/scoped reviews, Root identity audits,
both exact authorizations and both owned outcomes, public certificates, raw
logs/results and the independent successful-result audit. All {len(members)}
members are safe regular files; {len(inventory)} inventory entries bind them.
No private key, compiled executable or Python cache is included.

Archive SHA-256: `{manifest['archive_sha256']}` ({manifest['archive_bytes']} bytes).
See [manifest](manifest.json) and [component report](../../m2_h2_control_live.md).

Ready/paused public cancellation and ordinary peer reset plus idle shutdown
pass on the current source. Six admissions, three ends, three cancels,
110 accepted bytes, zero failed begin/end/active/errors. Three independent
same-route recoveries, stale controls and healthy buffered siblings pass.
Primary connection refunds of 7/32/32 bytes are observed before sibling DATA;
separate sibling accounting prevents credit masking. Actual DATA: 170 bytes
sent and refunded. All 32 records and final metrics match after deinit. Four
fresh TLS1.3/h2 connections, normal SIGTERM exit zero, reaping and key removal
pass; the log is 14,682 bytes below the 65,536-byte cap.

The first v4 attempt completed three case sequences but FileNotFoundError interrupted
idle/final verification; forced cleanup correctly records failure. The exact
original path was not retained. Source investigation found a volatile FD-entry
enumeration defect. Only a vanished enumerated readlink is now tolerated;
listener/PID/start/nonce/certificate guards and other errors stay strict.
Synthetic actual-helper tests prove that correction, not the lost original
path. Future failures retain filename/stage/traceback. The independently reviewed
v5 passes in a separately authorized second attempt. Both outcomes remain;
this is not a zero-failure history or an automatic retry.

Current subject is source/fixture-v1 plus source/runtime-v5; native builds did
not change across runtime fixes. Manifest SHA: `{manifest['review_manifest_sha256']}`
binds 2,433 inputs and seven trees, both actual build maps, original binding/six archives,
compiler/stdlib, client/interpreter/loader/TLS tools/helper and frozen sources.
Before/after Root audits match. Initial review also fixed sibling credit masking
with actual case/ledger RED/GREEN coverage; source re-reviews pass. Offline
seven listener, two credit and eight observer tests establish harness preparation.
Actual owned results establish the scoped protocol/application observations.

The unchanged 1031-file [native candidate](../m2_h2_native_tcp/README.md) and
reviewed c223 override remain the source basis. The
[metadata archive](../m2_h2_metadata_live/README.md) retains complete changed
candidate src bytes against Root30f27ab, and the
[pinned client](../m2_h2_client/README.md) restores offline packages. Archive
delivery does not adopt candidate code or unpublished dependency pins.

29 independent H2 IDs are proved; 11 and the full combined matrix remain. Application errors,
disconnect/reuse/active shutdown, output/producer/file, H3/multipart/genuine
earlydata and wider quality/platform/compliance/physical/provenance/release
requirements remain open. No performance/RSS/leak/general native-safety claim
or stopped-experiment/denied-socket-case reconstruction follows.
''')
    print(json.dumps({k: manifest[k] for k in ('archive_sha256', 'archive_bytes', 'safe_regular_members', 'inventory_entries', 'result_sha256')}, indent=2))


if __name__ == '__main__':
    main()
