"""Read-only current fixture/runtime identity audit; executes no fixture code."""
import hashlib
import json
from pathlib import Path


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(65536):
            result.update(block)
    return result.hexdigest()


def covered(manifest, path, expected):
    if manifest['inputs'].get(str(path)) == expected:
        return True
    for root, files in manifest['trees'].items():
        if path.is_relative_to(root):
            return files.get(path.relative_to(root).as_posix()) == expected
    return False


root = Path('/workspaces/uWebZockets')
base = root / '.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control'
path = base / 'manifest-v5.json'
manifest_sha = digest(path)
assert manifest_sha == 'd74acb0bf0586bdcace73bb772c376ea39e4ea7036da826828a59ee321882f18'
manifest = json.loads(path.read_text())
for name, expected in manifest['inputs'].items():
    assert digest(Path(name)) == expected, name
trees = []
for location, expected in manifest['trees'].items():
    actual = {p.relative_to(location).as_posix(): digest(p)
              for p in sorted(Path(location).rglob('*')) if p.is_file()}
    assert actual == expected, location
    assert len(actual) == manifest['tree_counts'][location]
    trees.append({'path': location, 'files': len(actual)})
source = '/tmp/uwz-task4d-fix1-frozen'
override = '/tmp/uwz-reviewed-libxev-c223-loop-callbacks'
fixture = Path('/tmp/uwz-task5c1-fixture-v1')
runtime = Path('/tmp/uwz-task5c1-runtime-v5')
assert len(manifest['trees'][source]) == 1031
assert len(manifest['trees'][override]) == 93
assert len(manifest['trees'][str(fixture)]) == 1
assert len(manifest['trees'][str(runtime)]) == 9
files = manifest['trees'][source]
pairs = [(p.as_posix(), files[p.as_posix()]) for p in sorted(Path(name) for name in files)]
source_sha = hashlib.sha256(json.dumps(pairs).encode()).hexdigest()
assert source_sha == 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de'
assert digest(fixture / 'profile.zig') == 'fbb931e4f3e870c62280f38e90cf6499203d8cffc7d9d6c2e071ef2d917b1579'
builds = []
archives = {}
for receipt_path, mode in zip(manifest['build_input_receipts'], ('Debug', 'ReleaseSafe'), strict=True):
    receipt = json.loads(Path(receipt_path).read_text())
    assert receipt['optimization'] == mode and receipt['exit_status'] == 0 and receipt['unchanged']
    for prefix in ('input', 'source', 'override', 'snapshot'):
        assert receipt[prefix + '_before'] == receipt[prefix + '_after']
    assert receipt['source_after'] == manifest['trees'][source]
    assert receipt['override_after'] == manifest['trees'][override]
    assert receipt['snapshot_after'] == manifest['trees'][str(fixture)]
    for name, expected in receipt['input_after'].items():
        assert digest(Path(name)) == expected and covered(manifest, Path(name), expected), name
        if name.endswith('.a'):
            archives[name] = expected
    binary = Path(next(arg.split('=', 1)[1] for arg in receipt['argv'] if arg.startswith('-femit-bin=')))
    assert digest(binary) == receipt['binary_sha256'] and covered(manifest, binary, receipt['binary_sha256'])
    assert not (base / receipt['stdout']).read_bytes() and not (base / receipt['stderr']).read_bytes()
    builds.append({'mode': mode, 'binary': str(binary), 'sha256': receipt['binary_sha256']})
assert len(archives) == 6 and archives == manifest['approved_archives']
assert {name for name in manifest['inputs'] if name.startswith('/tmp/uwz-task') and name.endswith('/profile')} == {b['binary'] for b in builds}
assert manifest['binary'] == builds[1]['binary']
assert manifest['runner'] == str(runtime / 'run_live.py')
assert digest(path) == manifest_sha
result = {'checks_passed': True, 'manifest_sha256': manifest_sha,
          'inputs_checked': len(manifest['inputs']), 'trees_checked': trees,
          'builds': builds, 'archives_checked': len(archives),
          'profile_sha256': digest(fixture / 'profile.zig'),
          'source_digest': source_sha, 'source_files': 1031,
          'native_execution': False}
output = root / '.superpowers/sdd/h2_streaming_plan/task-5c1-root-preflight-v5.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'checks_passed': True, 'inputs': len(manifest['inputs']),
                  'trees': len(trees), 'archives': len(archives), 'audit_sha256': digest(output)}))
