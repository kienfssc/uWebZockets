"""Check publication bytes and their linkage to actual retained sources/results."""
import hashlib
import json
import re
import tarfile
from pathlib import Path, PurePosixPath


root = Path('/workspaces/uWebZockets')
base = root / 'docs/implement-2-2-0/evidence/m2_h2_control_live'
manifest = json.loads((base / 'manifest.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
archive = base / manifest['archive']
assert sha(archive.read_bytes()) == manifest['archive_sha256']
assert archive.stat().st_size == manifest['archive_bytes']
with tarfile.open(archive, 'r:gz') as reader:
    entries = reader.getmembers()
    assert len(entries) == manifest['safe_regular_members'] == len({e.name for e in entries})
    data = {}
    for entry in entries:
        name = PurePosixPath(entry.name)
        assert entry.isfile() and entry.mode == 0o644 and not name.is_absolute()
        assert '..' not in name.parts and '__pycache__' not in name.parts
        payload = reader.extractfile(entry).read()
        payload.decode('utf-8')
        assert not payload.startswith((b'\x7fELF', b'\0asm'))
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[0-9A-Z]{16}', payload)
        data[entry.name] = payload
inventory = json.loads(data['inventory.json'])['files']
assert len(inventory) == manifest['inventory_entries']
assert {row['path'] for row in inventory} == set(data) - {'inventory.json'}
for row in inventory:
    assert row['bytes'] == len(data[row['path']]) and row['sha256'] == sha(data[row['path']])
assert sha(data['evidence/manifest-v5.json']) == manifest['review_manifest_sha256'] == 'd74acb0bf0586bdcace73bb772c376ea39e4ea7036da826828a59ee321882f18'
assert sha(data['evidence/stage-b/result.json']) == manifest['result_sha256'] == '9303144e0d6477379723b8d2fc1a161c8a3cd293722d195ae3f40508c0e609b2'
assert sha(data['evidence/stage-b-attempt1/result.json']) == manifest['prior_failure']['result_sha256'] == '335904aabbb7e6106c87b16ce76903744becf7641c49925f53aaa39a49188418'
actual = json.loads(data['evidence/stage-b/root-result-audit.json'])
assert actual['checks_passed'] and actual['totals'] == manifest['totals']
assert actual['post_deinit_records_match'] == 32 and actual['post_deinit_metrics_match']
assert sha(data['evidence/stage-b/root-result-audit.json']) == manifest['root_result_audit_sha256']
assert len(manifest['all_verified_case_ids']) == 29 and len(manifest['planned_unimplemented']) == 11
assert not set(manifest['all_verified_case_ids']) & set(manifest['planned_unimplemented'])
assert manifest['owned_attempts'] == 2 and manifest['completed_successful_runs'] == 1
assert manifest['prior_failure']['cleanup']['forced'] and not manifest['prior_failure']['success']
for label, location in [('fixture-v1', '/tmp/uwz-task5c1-fixture-v1'),
                         *[('runtime-v' + str(i), '/tmp/uwz-task5c1-runtime-v' + str(i)) for i in range(1, 6)]]:
    prefix = 'source/' + label + '/'
    names = {name[len(prefix):] for name in data if name.startswith(prefix)}
    assert names == {p.name for p in Path(location).iterdir()}
    for name in names:
        assert data[prefix + name] == (Path(location) / name).read_bytes()
result = {'checks_passed': True, 'archive_sha256': manifest['archive_sha256'],
          'safe_regular_members': len(entries), 'inventory_entries': len(inventory),
          'raw_result_sha256': manifest['result_sha256'], 'failed_result_retained': True,
          'frozen_source_versions_verified': 6, 'scope': 'Publication integrity only; no native rerun.'}
output = root / '.superpowers/sdd/h2_streaming_plan/control-publication-audit.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
