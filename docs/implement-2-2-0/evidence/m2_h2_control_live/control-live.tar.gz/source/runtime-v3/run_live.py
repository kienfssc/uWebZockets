"""Explicitly gated ordinary owned H2 fixture runner; importing is inert."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import ssl
import subprocess
import sys
import threading
import time

HERE = Path(__file__).resolve().parent
PORT = 28443
PYTHON = '/home/codespace/.python/current/bin/python3'
PACKAGES = '/tmp/uwz-h2-client-tooling/packages'
HELPER = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'
OPENSSL = '/opt/conda/bin/openssl'
CASES = ('cancel_ready', 'cancel_paused', 'peer_reset', 'shutdown_idle')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    value = hashlib.sha256()
    with open(path, 'rb') as source:
        while block := source.read(8192):
            value.update(block)
    return value.hexdigest()


def check_manifest(path, expected):
    require(digest(path) == expected, 'review manifest identity differs')
    manifest = json.loads(path.read_text())
    for root, expected_files in manifest['trees'].items():
        actual = {str(p.relative_to(root)) for p in Path(root).rglob('*') if p.is_file()}
        require(actual == set(expected_files), 'tree inventory differs: ' + root)
        for name, value in expected_files.items():
            require(digest(Path(root) / name) == value, 'tree input identity differs: ' + name)
    for name, value in manifest['inputs'].items():
        require(digest(name) == value, 'input identity differs: ' + name)
    require(manifest['state'] == 'ready-for-independent-review', 'manifest not review ready')
    checked_path(__file__, manifest['runner'], manifest['inputs'])
    checked_path(manifest['wire'], manifest['wire'], manifest['inputs'])
    checked_path(manifest['raw'], manifest['raw'], manifest['inputs'])
    checked_path(manifest['cases'], manifest['cases'], manifest['inputs'])
    checked_path(manifest['flow'], manifest['flow'], manifest['inputs'])
    checked_path(manifest['helper'], manifest['helper'], manifest['inputs'])
    validator = load_bound('validate_builds', manifest['validator'], manifest['inputs'])
    validator.validate(manifest, manifest['inputs'])
    return manifest


def checked_path(actual, expected, inputs):
    require(Path(actual).absolute() == Path(expected).absolute(), 'executing source path differs')
    require(Path(actual).resolve() == Path(expected).absolute(), 'source path resolves elsewhere')
    require(expected in inputs and digest(actual) == inputs[expected], 'executing source hash differs')


def load_bound(name, path, inputs):
    checked_path(path, path, inputs)
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, 'module loader unavailable')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    checked_path(module.__file__, path, inputs)
    return module


def new_capture():
    return {'lock': threading.Lock(), 'bytes': bytearray(), 'overflow': False, 'error': None}


def capture_fragment(capture, data):
    with capture['lock']:
        room = 65536 - len(capture['bytes'])
        capture['bytes'].extend(data[:room])
        if len(data) > room:
            capture['overflow'] = True


def capture_snapshot(capture):
    with capture['lock']:
        return bytes(capture['bytes']), capture['overflow'], capture['error']


def check_capture(capture):
    _, overflow, error = capture_snapshot(capture)
    require(not overflow, 'server output exceeds 65536 bytes')
    require(error is None, 'server output collector failed: ' + str(error))


def drain_capture(pipe, capture):
    try:
        while data := os.read(pipe.fileno(), 8192):
            capture_fragment(capture, data)
    except BaseException as exc:
        with capture['lock']:
            capture['error'] = repr(exc)
    finally:
        try:
            pipe.close()
        except BaseException as exc:
            with capture['lock']:
                capture['error'] = repr(exc)


def cleanup_actions(actions):
    errors = []
    for name, action in actions:
        try:
            action()
        except BaseException as exc:
            errors.append({'action': name, 'error': repr(exc)})
    return errors


def remaining(deadline):
    seconds = deadline - time.monotonic()
    require(seconds > 0, 'absolute deadline expired')
    return seconds


def child_start(pid):
    # comm can contain spaces or parentheses; the final ')' ends that field.
    text = Path('/proc', str(pid), 'stat').read_text()
    return text[text.rfind(')') + 2:].split()[19]


def owned_listener(pid):
    inodes = set()
    for entry in Path('/proc', str(pid), 'fd').iterdir():
        target = os.readlink(entry)
        if target.startswith('socket:['):
            inodes.add(target[8:-1])
    rows = Path('/proc/net/tcp').read_text().splitlines()[1:]
    return [row.split()[9] for row in rows if row.split()[1] == '0100007F:6F1B'
            and row.split()[3] == '0A' and row.split()[9] in inodes]


def wait_marker(child, capture, nonce, deadline):
    marker = ('H2_READY ' + nonce).encode()
    while True:
        check_capture(capture)
        require(child.poll() is None, 'child exited before readiness')
        data, _, _ = capture_snapshot(capture)
        if marker in data:
            listeners = owned_listener(child.pid)
            require(len(listeners) == 1, 'owned loopback listener not uniquely identified')
            return listeners[0]
        time.sleep(min(0.05, remaining(deadline)))


def flush(sock, protocol, deadline, capture):
    check_capture(capture)
    pending = protocol.data_to_send()
    if pending:
        sock.settimeout(remaining(deadline))
        sock.sendall(pending)


def encoded_headers_size(pending, stream):
    from hyperframe.frame import Frame, HeadersFrame, ContinuationFrame
    offset = 0
    total = 0
    ended = False
    while offset < len(pending):
        require(len(pending) - offset >= 9, 'truncated generated frame header')
        frame, length = Frame.parse_frame_header(memoryview(pending)[offset:offset + 9])
        offset += 9
        require(offset + length <= len(pending), 'truncated generated frame payload')
        frame.parse_body(memoryview(pending)[offset:offset + length])
        offset += length
        require(isinstance(frame, (HeadersFrame, ContinuationFrame)) and frame.stream_id == stream and not ended, 'unexpected generated header frame')
        total += len(frame.data)
        require(total <= 8192, 'encoded header block exceeds bound')
        ended = 'END_HEADERS' in frame.flags
    require(ended, 'missing generated END_HEADERS')
    return total


def flush_headers(sock, protocol, deadline, capture, stream):
    check_capture(capture)
    pending = protocol.data_to_send()
    total = encoded_headers_size(pending, stream)
    sock.settimeout(remaining(deadline))
    sock.sendall(pending)
    return total


def receive(sock, protocol, records, raw, trace, deadline, wire, capture):
    check_capture(capture)
    sock.settimeout(remaining(deadline))
    data = sock.recv(8192)
    require(data, 'TLS EOF before response completion')
    events = wire.accept(protocol, data, records, raw, trace['events'])
    import h2.events
    import h2.settings
    updates = [(event.stream_id, event.delta) for event in events if isinstance(event, h2.events.WindowUpdated)]
    initial = None
    for event in events:
        if isinstance(event, h2.events.RemoteSettingsChanged):
            changed = event.changed_settings.get(h2.settings.SettingCodes.INITIAL_WINDOW_SIZE)
            if changed is not None:
                initial = changed.new_value
                require(initial == 65535, 'peer stream initial window changed')
    ledger = trace['ledger']
    for stream_id, entry in ledger.streams.items():
        observed = raw['streams'].get(stream_id)
        if observed is not None and observed['reset']:
            entry.open = False
    trace['flow'].receive_batch(ledger, updates, initial)
    windows = {stream_id: protocol.local_flow_control_window(stream_id)
               for stream_id, item in ledger.streams.items() if item.open}
    trace['flow'].check_public(ledger, protocol.outbound_flow_control_window, windows)
    require(len(trace['snapshots']) < 4096, 'flow snapshot bound exceeded')
    trace['snapshots'].append({'connection': ledger.connection, 'sent': ledger.sent,
                               'refunded': ledger.refunded, 'windows': windows, 'updates': updates})
    flush(sock, protocol, deadline, capture)


def start(protocol, records, raw, method, path, headers, end_stream, limit, wire, status=200, info=0, policy='healthy'):
    stream = protocol.get_next_available_stream_id()
    wire.register(records, raw, stream, limit, status, info, policy)
    protocol.send_headers(stream, [(':method', method), (':scheme', 'https'),
                                  (':authority', 'localhost'), (':path', path)] + headers,
                          end_stream=end_stream)
    return stream


def complete(sock, protocol, records, raw, trace, stream, deadline, wire, capture, keep=False):
    flush(sock, protocol, deadline, capture)
    record = records[stream]
    def finished():
        policy = record['policy']
        raw_record = raw['streams'][stream]
        terminal = (record['ended'] if policy == 'healthy' else
                    raw_record['reset'] if policy == 'public_cancel' else
                    raw_record['peer_reset'] if policy == 'peer_reset' else
                    record['ended'] and raw_record['reset'])
        return terminal and not raw['header'] and raw['frame'] is None
    while not finished():
        receive(sock, protocol, records, raw, trace, deadline, wire, capture)
    wire.complete(records, raw, stream)
    result = {'headers': record['headers'], 'bytes': record['bytes'],
              'sha256': record['hash'].hexdigest(), 'body': bytes(record['body']).decode('utf-8'),
              'informationals': record['informationals'], 'raw_reset': raw['streams'][stream]['reset'],
              'reset_event': record['reset_event']}
    if not keep:
        wire.retire(records, raw, stream)
    return result


def request(sock, protocol, records, raw, trace, path, deadline, wire, capture, limit=1024):
    stream = start(protocol, records, raw, 'GET', path, [], True, limit, wire)
    return complete(sock, protocol, records, raw, trace, stream, deadline, wire, capture)


def status(sock, protocol, records, raw, trace, tag, deadline, wire, capture):
    response = request(sock, protocol, records, raw, trace, '/status/' + tag, deadline, wire, capture)
    return json.loads(response['body'])


def metrics(sock, protocol, records, raw, trace, deadline, wire, capture):
    response = request(sock, protocol, records, raw, trace, '/metrics', deadline, wire, capture)
    return json.loads(response['body'])


def health(sock, protocol, records, raw, trace, deadline, wire, capture):
    response = request(sock, protocol, records, raw, trace, '/health', deadline, wire, capture, 2)
    require(response['body'] == 'ok', 'health differs')
    return response


def run(args, manifest):
    helper = load_bound('h2_client', manifest['helper'], manifest['inputs'])
    raw_module = load_bound('raw_observer', manifest['raw'], manifest['inputs'])
    sys.modules['raw_observer'] = raw_module
    wire = load_bound('admission_wire', manifest['wire'], manifest['inputs'])
    require(wire.raw_observer is raw_module, 'raw observer binding differs')
    cases = load_bound('credit_cases', manifest['cases'], manifest['inputs'])
    flow = load_bound('credit_flow', manifest['flow'], manifest['inputs'])
    require(cases.CASES == CASES, 'case catalogue differs')
    import h2
    import hpack
    import hyperframe
    for module in (h2, hpack, hyperframe):
        require(Path(module.__file__).resolve().is_relative_to(Path(PACKAGES)), 'client module origin differs')
    require(Path(helper.__file__).resolve() == Path(HELPER) / 'h2_client.py', 'helper origin differs')
    overall = time.monotonic() + 900
    run_dir = Path(args.output).resolve()
    run_dir.mkdir(mode=0o700)
    cert, key, log = run_dir / 'certificate.pem', run_dir / 'private-key.pem', run_dir / 'server.log'
    nonce = os.urandom(16).hex()
    result = {'nonce': nonce, 'cases': {}, 'success': False, 'cleanup': {},
              'python': sys.executable, 'python_path': sys.path, 'openssl': OPENSSL,
              'profile': manifest['binary'], 'manifest_sha256': args.manifest_sha256}
    child = None
    sock = None
    start_id = None
    error = None
    capture = new_capture()
    collector = None
    try:
        command = [OPENSSL, 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
                   '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost',
                   '-keyout', str(key), '-out', str(cert)]
        result['certificate_command'] = command
        certificate_env = {'OPENSSL_CONF': '/opt/conda/ssl/openssl.cnf'}
        result['certificate_environment'] = certificate_env
        subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True,
                       env=certificate_env, timeout=remaining(overall))
        os.chmod(key, 0o600)
        cert_der = ssl.PEM_cert_to_DER_cert(cert.read_text())
        result['certificate_sha256'] = hashlib.sha256(cert_der).hexdigest()
        env = {'H2_PROFILE_CERT': str(cert), 'H2_PROFILE_KEY': str(key), 'H2_PROFILE_NONCE': nonce}
        result['child_argv'] = [manifest['binary']]
        result['child_environment'] = env.copy()
        child = subprocess.Popen([manifest['binary']], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
        collector = threading.Thread(target=drain_capture, args=(child.stdout, capture), daemon=True)
        collector.start()
        start_id = child_start(child.pid)
        result['child'] = {'pid': child.pid, 'start': start_id, 'binary_sha256': digest(manifest['binary'])}
        deadline = min(overall, time.monotonic() + 15)
        result['listener_inode'] = wait_marker(child, capture, nonce, deadline)
        ready_output = capture_snapshot(capture)[0].decode('utf-8')
        capacity = [line for line in ready_output.splitlines() if 'H2_CAPACITY ' in line]
        require(len(capacity) == 1 and 'slab=4098304' in capacity[0], 'fixture capacity differs')
        result['capacity'] = capacity[0]
        require(child_start(child.pid) == start_id and child.poll() is None, 'owned child changed')
        context = ssl.create_default_context(cafile=str(cert))
        context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_3
        context.set_alpn_protocols(['h2'])
        p32 = helper.payload_block(32, 0, 32)
        require(p32 == bytes(range(1, 11)) + b'final-upload-sentinel!', 'payload literal differs')
        require(hashlib.sha256(p32).hexdigest() == cases.H32 and hashlib.sha256(p32[:7]).hexdigest() == cases.H7, 'payload digest differs')
        result['connections'] = []
        connection_cases = args.cases
        for case in connection_cases:
            if sock is not None:
                require(not records and not raw_state['streams'], 'records remain on previous connection')
                sock.close()
                sock = None
            deadline = min(overall, time.monotonic() + 30)
            require(child.poll() is None and child_start(child.pid) == start_id, 'owned child changed')
            require(owned_listener(child.pid) == [result['listener_inode']], 'owned listener changed')
            raw = socket.create_connection(('127.0.0.1', PORT), timeout=remaining(deadline))
            try:
                raw.settimeout(remaining(deadline))
                sock = context.wrap_socket(raw, server_hostname='localhost', suppress_ragged_eofs=False)
            except BaseException:
                raw.close()
                raise
            require(sock.version() == 'TLSv1.3' and sock.selected_alpn_protocol() == 'h2', 'TLS/ALPN differs')
            require(hashlib.sha256(sock.getpeercert(binary_form=True)).hexdigest() == result['certificate_sha256'], 'peer certificate identity differs')
            require(child.poll() is None and child_start(child.pid) == start_id, 'owned child died')
            protocol, records, raw_state = helper.new_protocol(), {}, raw_module.new_state()
            trace = {'events': {}, 'ledger': flow.FlowLedger(), 'flow': flow, 'snapshots': []}
            flush(sock, protocol, deadline, capture)
            health(sock, protocol, records, raw_state, trace, deadline, wire, capture)
            require(protocol.remote_settings.initial_window_size == 65535, 'initial stream window differs')
            if case == 'shutdown_idle':
                result['connections'].append({'case': case, 'tls': sock.version(), 'alpn': sock.selected_alpn_protocol(), 'snapshots': trace['snapshots']})
                continue
            def begin(tag, policy):
                path = '/limit/' + tag + '?case=' + tag
                stream = start(protocol, records, raw_state, 'POST', path,
                               [('content-length', '32'), ('x-case', tag)], False,
                               1024 if policy == 'healthy' else 0, wire, policy=policy)
                flow.open_stream(trace['ledger'], stream)
                flush_headers(sock, protocol, deadline, capture, stream)
                return stream
            def sibling():
                stream = start(protocol, records, raw_state, 'POST', '/echo', [('content-length', '1')], False, 1, wire)
                flow.open_stream(trace['ledger'], stream)
                flush_headers(sock, protocol, deadline, capture, stream)
                return stream
            def send_bytes(stream, data, end_stream):
                require(len(data) <= 8192, 'data bound')
                ledger = trace['ledger']
                flow.check_public(ledger, protocol.outbound_flow_control_window, {stream: protocol.local_flow_control_window(stream)})
                flow.send_data(ledger, stream, len(data), None, protocol.max_outbound_frame_size, end_stream)
                protocol.send_data(stream, data, end_stream=end_stream)
                flush(sock, protocol, deadline, capture)
            def send(stream, length, end_stream):
                send_bytes(stream, p32[:length], end_stream)
            def do_control(operation, tag, expected):
                item = request(sock, protocol, records, raw_state, trace, '/control/' + operation + '/' + tag, deadline, wire, capture, 64)
                require(item['body'] == expected, 'control response differs')
                return item
            def do_peer_reset(stream):
                from hyperframe.frame import RstStreamFrame
                protocol.reset_stream(stream, error_code=8)
                expected = RstStreamFrame(stream)
                expected.error_code = 8
                pending = protocol.data_to_send()
                require(pending == expected.serialize(), 'outgoing reset bytes differ')
                raw_module.mark_peer_reset(raw_state, stream, 8)
                trace['ledger'].streams[stream].open = False
                sock.settimeout(remaining(deadline))
                sock.sendall(pending)
                return {'outgoing_reset_hex': pending.hex(), 'stream': stream, 'code': 8}
            def finish_terminal(stream):
                trace['ledger'].streams[stream].open = False
                return complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture)
            def finish_sibling(stream):
                send_bytes(stream, b's', True)
                item = complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture)
                require(item['body'] == 's' and item['bytes'] == 1, 'sibling response differs')
                return item
            def reclaim(target):
                ledger = trace['ledger']
                while ledger.refunded < target:
                    receive(sock, protocol, records, raw_state, trace, deadline, wire, capture)
                require(ledger.refunded <= ledger.sent, 'refund exceeds sent flow')
                flow.check_public(ledger, protocol.outbound_flow_control_window, {})
                return {'target': target, 'sent': ledger.sent, 'refunded': ledger.refunded,
                        'connection_window': ledger.connection, 'public_window': protocol.outbound_flow_control_window}
            def finish_recovery(stream):
                item = complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture)
                return json.loads(item['body'])
            def pending(stream):
                require(records[stream]['headers'] is None and not records[stream]['ended'] and not raw_state['streams'][stream]['reset'], 'unexpected early target terminal')
            api = {'start': begin, 'sibling': sibling, 'send': send,
                   'status': lambda tag: status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture),
                   'control': do_control, 'peer_reset': do_peer_reset, 'finish_terminal': finish_terminal,
                   'finish_sibling': finish_sibling, 'reclaim': reclaim, 'finish_recovery': finish_recovery,
                   'pending': pending}
            result['cases'][case] = cases.execute(api, case)
            require(not records and not raw_state['streams'], 'response records remain after case')
            require(trace['ledger'].sent == (40 if case == 'cancel_ready' else 65), 'case flow total differs')
            result['connections'].append({'case': case, 'tls': sock.version(), 'alpn': sock.selected_alpn_protocol(),
                                          'events': trace['events'], 'snapshots': trace['snapshots'],
                                          'sent_flow': trace['ledger'].sent, 'refunded_flow': trace['ledger'].refunded})
        deadline = min(overall, time.monotonic() + 30)
        final = {tag: status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture) for tag in cases.TAGS}
        aggregate = metrics(sock, protocol, records, raw_state, trace, deadline, wire, capture)
        selected = cases.selected_tags(args.cases)
        for tag in cases.TAGS:
            cases.verify_record(final[tag], cases.expected(tag, selected))
        for field in ('middleware', 'attempts', 'begin', 'end', 'cancel', 'failure', 'end_errors', 'accepted', 'errors'):
            require(aggregate[field] == sum(record[field] for record in final.values()), 'aggregate ' + field + ' differs')
        expected_buffered = len(args.cases) + 33 + sum(7 + (case != 'peer_reset') for case in args.cases if case in cases.PRIMARIES)
        require(aggregate['buffered_middleware'] == expected_buffered, 'buffered middleware count differs')
        require(aggregate['active'] == 0 and not aggregate['slot0_active'] and not aggregate['slot1_active'], 'active fixture')
        result['final_status'] = final
        result['final_metrics'] = aggregate
        sock.close()
        sock = None
        require(child_start(child.pid) == start_id and child.poll() is None, 'child identity changed')
        graceful_deadline = min(overall, time.monotonic() + 15)
        os.kill(child.pid, signal.SIGTERM)
        exit_code = child.wait(timeout=remaining(graceful_deadline))
        result['cleanup'] = {'signal': 'SIGTERM', 'exit_code': exit_code, 'reaped': True, 'forced': False}
        require(exit_code == 0, 'owned server exit differs')
        collector.join(timeout=remaining(graceful_deadline))
        require(not collector.is_alive(), 'server output collector did not finish')
        check_capture(capture)
        text = capture_snapshot(capture)[0].decode('utf-8')
        post = {}
        post_metrics = None
        for line in text.splitlines():
            marker = 'H2_RECORD ' + nonce + ' '
            if marker in line:
                item = json.loads(line.split(marker, 1)[1])
                require(item['tag'] not in post, 'duplicate post-deinit tag')
                post[item['tag']] = item
            marker = 'H2_DEINIT ' + nonce + ' '
            if marker in line:
                require(post_metrics is None, 'duplicate post-deinit aggregate')
                post_metrics = json.loads(line.split(marker, 1)[1])
        require(post == final and post_metrics == aggregate, 'post-deinit state differs')
        result['cases']['shutdown_idle'] = {'exit_code': exit_code, 'post_deinit': True}
        result['success'] = True
    except BaseException as exc:
        error = repr(exc)
    finally:
        def close_socket():
            if sock is not None:
                sock.close()

        def signal_child():
            if child is None or child.poll() is not None:
                return
            require(start_id is None or child_start(child.pid) == start_id, 'child identity changed during cleanup')
            result['cleanup']['forced'] = True
            child.kill()

        def wait_child():
            if child is None:
                return
            child.wait(timeout=15)
            result['cleanup']['exit_code'] = child.returncode
            result['cleanup']['reaped'] = True

        def delete_key():
            key.unlink(missing_ok=True)
            require(not key.exists(), 'private key remains')

        def save_log():
            if collector is not None:
                collector.join(timeout=15)
            data, overflow, collector_error = capture_snapshot(capture)
            log.write_bytes(data)
            require(collector is None or not collector.is_alive(), 'server output collector did not finish')
            require(not overflow and collector_error is None, 'server output collection failed or overflowed')

        def close_pipe():
            if child is not None and child.stdout is not None:
                child.stdout.close()

        errors = cleanup_actions((('socket', close_socket), ('child_signal', signal_child),
                                  ('child_wait', wait_child), ('key', delete_key), ('log', save_log),
                                  ('pipe', close_pipe)))
        if errors or result['cleanup'].get('forced', False):
            result['success'] = False
        result['cleanup']['errors'] = errors
        result['error'] = error
        (run_dir / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    require(result['success'], 'owned run failed: ' + str(error))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true', required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--cases', nargs='+', choices=CASES, required=True)
    args = parser.parse_args()
    require(dict(os.environ) == {'PYTHONPATH': PACKAGES + ':' + HELPER, 'LC_ALL': 'C.UTF-8'},
            'runner environment must contain only the pinned locale and PYTHONPATH')
    require(sys.executable == PYTHON and sys.dont_write_bytecode and sys.flags.no_site and os.environ.get('PYTHONPATH') == PACKAGES + ':' + HELPER,
            'Python interpreter or PYTHONPATH differs')
    require(len(set(args.cases)) == len(args.cases) and ('shutdown_idle' not in args.cases or args.cases[-1] == 'shutdown_idle'), 'invalid case order')
    output = Path(args.output)
    require(output.is_absolute() and output.resolve().is_relative_to(Path('/tmp')) and output.resolve() != Path('/tmp'), 'output must be new /tmp path')
    require(not output.exists(), 'output already exists')
    manifest = check_manifest(args.manifest, args.manifest_sha256)
    run(args, manifest)


if __name__ == '__main__':
    main()
