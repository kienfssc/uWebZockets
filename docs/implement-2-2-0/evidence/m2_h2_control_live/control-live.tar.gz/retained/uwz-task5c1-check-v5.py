import hashlib
import importlib.util
import json
import sys
from pathlib import Path

path = Path('/tmp/uwz-task5c1-runtime-v5/run_live.py')
spec = importlib.util.spec_from_file_location('inert_runner', path)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
manifest_path = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-control/manifest-v5.json')
hash_value = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
manifest = runner.check_manifest(manifest_path, hash_value)
print('inert runner and current manifest accepted:', len(manifest['inputs']), 'inputs,', len(manifest['trees']), 'trees')
validator = sys.modules['validate_builds']
changed = dict(manifest['inputs'])
key = '/workspaces/uWebZockets/zig-out/lib/libssl.a'
changed[key] = '0' * 64
try:
    validator.validate(manifest, changed)
except ValueError as exc:
    print('actual input map mutation rejected:', str(exc))
else:
    raise AssertionError('mutated input map accepted')
print('manifest sha256:', hash_value)
