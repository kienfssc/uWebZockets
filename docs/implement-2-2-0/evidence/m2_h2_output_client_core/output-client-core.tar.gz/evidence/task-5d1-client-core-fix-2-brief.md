# Task5d1 overall fix round2/5: reset-driven full closure

Same original Task5d1 implementer. This is the second overall fix round (observer
closed-reset-event fix was round1); do not reset the counter for source passes.
Read original budget-refund brief and client-core review. Same sole ownership/
pure-only boundary/report append. Preserve frozen11-file client-core-review-v1,
previous approved freezes and public14cec16/archive. No fixture/runner/build/
native/OS/resource/fault or dependency/ref operations, subagents/commits/push.

Open finding verbatim:

P2 — Mark incoming resets as full closure before processing subsequent refunds.
raw_observer.py109-112 only sets response_end on RST_STREAM. If request END has
not been sent, request_credit.closed remains false. For an unfinished upload
receiving final response END, NO_ERROR reset, then a valid outstanding stream
WINDOW_UPDATE, the observer predicts a WindowUpdated event while the pinned
codec has entered CLOSED and suppresses it. wire.accept consequently fails with
WINDOW_UPDATE event sequence differs. Record reset closure at the complete raw
reset frame, preserving debt, and cover refunds both later in that read and
after retirement.

Root confirms actual code/source and accepts this real defect. Incoming reset
closes both directions at full-frame completion; do not clear owed refunds,
change raw reset code/order validation or create an exception for mismatches.
The existing outgoing-only lifecycle function may be factored or reused only if
the result correctly represents both incoming and outgoing observations without
invented IO/actions. Preserve logical/public-query eligibility and retirement.

Cover actual pinned pure codec unfinished upload (positive DATA but no request
END), final response END/reset, known valid refund after reset in the same read,
remaining refund after response retirement in a later read; exact event absence
and retained debt/closed eligibility. Capture actual RED before fix and GREEN.
Add the focused integration coverage missing from reviewer evidence: at least
one valid output-stage sequence through actual wire.accept with both ledgers and
real pinned H2 codec, from valid source-shaped30-byte initial server SETTINGS
and recorded client settings ACK through headers/body/end/retirement. Use public
protocol/codec serialization, no private H2 fields/OS objects. Candidate emits
five settings IDs1,2,3,6,8 (server.zig1930-1943); it does not explicitly advertise
INITIAL_WINDOW_SIZE, so default65535 applies. A public pure H2 server may emit a
different default SETTINGS shape; source-shaped frame serialization is allowed
and must be reported as protocol-byte evidence, never native server proof.

Cover changed test_client_core.py plus affected wire/receive suites normal and
selected optimized; no unchanged contracts rerun. AST/inert changed imports,
report exact commands/raw outputs/failures/current hashes and self-review. Root
reads evidence before same reviewer's scoped fix re-review. All11 current source
and final preparation/input binding remain review-gated; five native cases and
actual fullcombined40 stay required.
