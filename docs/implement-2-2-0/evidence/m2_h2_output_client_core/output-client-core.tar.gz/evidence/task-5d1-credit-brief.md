# Task5d1 next pass: independent response receive-credit ledger

Read this first only after Root releases this pass. Keep all original Task5d1
acceptance and stop boundaries. This adds actual callable credit observation to
the hash-only wire observer; stage budgets/request-refund ordering/strict frame
policy remain a subsequent required pass. No fixture, runner, native release,
claim that any output case passed, or full Task5d1 completion.

Same sole implementer and ownership: NEW output-streaming files, owned
/tmp/uwz-task5d1-* and append task-5d1-report.md. Preserve others' work and all
prior source/evidence. No product/docs/pin/ref mutation, commit, push, subagent
or external model CLI. Root has read actual report/results before dispatch.

Use exact restored42-file /tmp/uwz-h2-client-tooling/packages and Python
/home/codespace/.python/current/bin/python3 -B -S. Only pure protocol state/
bytes/codecs/test doubles, AST/inert imports; pure H2Connection allowed only for
offline codecs. No SSLContext/socket/live helper/process/server/native/fixture/
Zig build/resource/kernel/FD/registration/completion/error/fault probes. Generic
skills cannot authorize stopped native work. Imports inert, checks under -O.

## Distinct receive-credit state

Existing runtime flow_ledger.py is the opposite direction (client request
send); do not relabel or substitute it. Add a named caller-owned pure response
ledger module with explicit bounded state and mutations. Native request receive
window, 73728 storage, eight native streams, write queue and two bindings do not
change. No private H2 field or window-manager access/mutation.

Track initial connection credit65535, acknowledged client initial stream
window65535, per-stream receive windows and logical/flow bytes, explicit granted
increments and bounded pending local setting. Eight active stream states max,
monotonic valid odd stream IDs; retire closed response state without unbounded
history. Keep aggregate counters only. Validate strict integer types (bool is
not an int), no negative lengths, unknown IDs, duplicate/reused IDs, overflow,
invalid increments. Settings initial window is0..2147483647 and updates are
1..2147483647 while resulting windows obey signed protocol bounds. A window
reduction may create a valid negative stream window; nonzero DATA cannot exceed
either current credit. Zero-length DATA consumes no credit. Hash logical bytes,
debit event.flow_controlled_length including pad-length byte/padding.

Expose pure actions recording actual client SETTINGS sent, SETTINGS ACK applied,
stream opening, actual explicit connection/stream WINDOW_UPDATE grants, DATA
received, response closure/retirement and public window comparison. No action
performs transport I/O or mutates the H2 protocol object. Actual public driver
calls later must be paired with these observations, not simulated by ledger.
Support one outstanding SETTINGS at a time: initial client SETTINGS/ACK first,
then custom INITIAL_WINDOW_SIZE/ACK. Never assume settings active at send time.
Use SettingsAcknowledged.changed_settings to verify original/new values against
recorded proposal and apply its delta once to appropriate existing stream
windows. Unexpected/duplicate/unmatched ACK fails. Initial65535 ACK may have no
changed INITIAL_WINDOW_SIZE entry because it equals protocol defaults.

Wire integration must consume actual SettingsAcknowledged and DataReceived
events once when the optional explicit ledger is supplied. It must enforce
manual credit for every observed body in that mode, including small JSON, so
there are no unrecorded autoacks. Preserve default legacy API/call behavior and
all reviewed mode/reset/close semantics. Do not wrap/duplicate the observer
implementation. Explain the explicit API the later runner will use.

Cross-check public protocol.inbound_flow_control_window against connection
receive ledger and protocol.remote_flow_control_window(id) against min(conn,
stream receive credit), only for streams still publicly queryable. The latter
is a minimum, never a raw stream-window getter. Independent caller lifecycle
must decide query eligibility; do not read private H2 state, infer full closure
from a request-only send flag, or swallow arbitrary exceptions as closure.
The fully-closed stream/event rules in task-5d-credit-order.md guide lifecycle;
request END and response END are distinct. Skip queries only for proved fully
closed streams. Retained response state must still reject DATA after END.

Required future ordinary driver schedule supported by these APIs: health first
recorded from initial connection65535, then acknowledged stream0; target0 while
auxiliary streams explicitly granted65535 each after separately flushed
HEADERS; connection raised from actual remaining ledger credit to W33554432.
Grant target8192 then remainingN-8192; early body8 then9; separate fresh ample
connection acknowledged initialW. No unrecorded autoack/refill or server request
window enlargement. This pass proves pure accounting, not those native cases.

## Meaningful evidence

Use actual pinned H2 codec to prove initial/custom ACK activation, zero then
explicit grants, independent connection/stream exhaustion,8+9 and8192 staged
credit, minimum crosschecks, padded DATA logical versus flow counts, closed
response handling and unchanged legacy default behavior. Pure malformed-data
tests for over-credit, wrong IDs, invalid increments/settings/ACK, double debit,
public window mismatch and strict types. Include valid negative window after
reduction and zero-length DATA accounting. No packet timing or native claim.

Capture a real behavioral RED/GREEN on amended actual observer/ledger, covering
ordinary and selected -O tests, AST/inert imports. Rerun observer tests only
because this pass changes its event path; unchanged contracts need no rerun.
Report exact commands/raw results/failures, original/new hashes and bounded
state, API, self-review and remaining source-derived budget/refund/frame-stage
work in task-5d1-report.md. Do not claim full Task5d1 or any actual output case.
