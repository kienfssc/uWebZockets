# Client-core initial independent review

Reviewer /root/review_h2_output_client_core, Astra/high, read-only.
SPEC: CHANGES REQUIRED. QUALITY: no additional structural findings.

P2 — Mark incoming resets as full closure before processing subsequent refunds.
Frozen raw_observer.py109 only sets response_end on RST_STREAM. If request END
has not been sent, request_credit.closed remains false. For an unfinished upload
receiving final response END, NO_ERROR reset, then a valid outstanding stream
WINDOW_UPDATE, observer predicts WindowUpdated while pinned codec is CLOSED and
suppresses it. wire.accept fails WINDOW_UPDATE event sequence differs. Record
reset closure at the complete raw reset frame, preserving debt, and cover refunds
later in that read and after retirement.

Tests currently end the request before refunds and miss reset-driven closure.
Strict stage tests do not exercise wire.accept with both ledgers and real codec
together. No checks rerun/edits/native activity. Current binding/fixture/runner/
five native output cases/combined/full gates remain open.
