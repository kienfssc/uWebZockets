# Client-core scoped fix re-review

Reviewer /root/review_h2_output_client_core. P2: ADDRESSED.
SPEC: PASS. QUALITY: PASS for scoped fix; no new actionable findings.
Complete incoming reset now marks both directions closed while preserving debt.
Real codec covers same-read refund, debt through retirement/later refund, closed
query rejection. Strict-stage test invokes wire.accept with both ledgers.
Actual RED/GREEN report inspected, no reruns. Current-input binding/fixture/
runner/native/five output cases/combined/full gates remain open.
