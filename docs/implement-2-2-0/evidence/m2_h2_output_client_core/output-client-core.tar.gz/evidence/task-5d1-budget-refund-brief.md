# Task5d1 final client-core pass: raw refunds and bounded output stages

Read this first after Root release. Same Task5d1 implementer/ownership: only NEW
output-streaming directory, owned /tmp/uwz-task5d1-* and same report append. You
are not alone; preserve all previous artifacts and others' edits. No product,
public docs/archive, pins/refs, commits/push, subagents/external model CLI. Read
task-5d-budget-io.md and task-5d-credit-order.md: exact adopted source requirements.
Original contract/observer/credit briefs still bind. Do not implement file I/O,
fixture, runner, Zig build or native activity here. Those later gates remain.

Source basis: independently reviewed observer v2 and response ledger v1; freeze
at /tmp/uwz-task5d1-credit-review-v1,8files7408dfc495d9671bdb062d18a5e9695d0ea02341d3d88283dd0f57321b0dac71.
Current owned files match this subject. First observer6files are already public
checkpoint14cec1650050b0e87a72e21f43967a105944d074; never change that frozen
version/archive. Pinned42purecodec/tmp/uwz-h2-client-tooling/packages0f85 remains
unchanged. Python /home/codespace/.python/current/bin/python3 -B -S; only pure
data/protocol codecs and inert doubles/AST/imports. No live/native helper,
SSL/socket/process/FD/resource/kernel/registration/completion/error/fault probes,
certificates or actual runner/checker invocation. No stopped experiment.

## Incoming request-refund authority and lifecycle

Add actual bounded caller-owned request-send debt accounting and raw integration,
separate from response_credit. Existing flow_ledger is opposite to response
receive, but its request-open flag is NOT fully-closed state. Preserve distinct
caller request END/reset and complete incoming response END/reset. Track local
public send DATA with actual logical+padding flow length and outgoing settings/
END/reset actions for later driver pairing. No mutation of H2/private fields.
Connection starts65535; server's known initial request-stream window remains
65535. SETTINGS/window changes inconsistent with source schedule fail explicitly.
Enforce case schedule R<=65 total request flow bytes and bounded known positive
DATA identities, <=8 active records; use explicit derived bound for retained
positive-debt IDs rather than every retired GET. No unbounded response history.

For complete incoming WINDOW_UPDATE: exact payload4, stream/reserved/flags
valid, incrementpositive and <=remaining known specific connection/stream debt.
Raw frame debits debt and credits request ledger once. Preserve debt across
response retirement/stage switches, reject unknown/zero/excess refunds; residual
closed debt may remain and is reported, not forcibly awaited/refunded. Closed
stream updates do not permit payload/reset/duplicate END on retired responses.

At each frame's position predict public WindowUpdated: connection exactlyone;
known not-fully-closed stream exactlyone; fullyclosed known stream none. The
pinned codec suppresses updates in both retained and removed CLOSED streams.
Compare ordered occurrence sequence including equal duplicates against exactly
returned public WindowUpdated events. Do not count events as refunds again.
Atmost631 WINDOW_UPDATE frames can complete per8192-byte read including a prior
partial frame; bound only this transient per-read sequence, no cross-read
history. Partial updates cause no refund or event obligation before completion.
Update before final END in one read emits an event; update after full closure
does not. Do not use end-of-read state to classify all frames.

Cross-check request public outbound_flow_control_window with connection ledger,
local_flow_control_window(id) with min(conn,stream) only while known not fully
closed. Response public inbound/remote checks retain their separate meaning.
No exception swallowing/private stream objects. Keep raw final/reset policy
validation and all previous response-mode semantics/caps.

## Actual stage work and strict output frame policy

Expose pure, bounded stage APIs that later driver pairs with actual public
actions and every received decrypted byte. Integrate them with the real raw/wire
observer as an explicit optional output-stage mode. Default legacy mode and its
4096 runner receive-call limit stay unchanged; do not edit run_live.py.

Exact maximum case-stage budgets: producer18243676, file1693852,
early-final1447948 decrypted H2 bytes. Derived H4105, small45064, A<=32 auxiliary
responses, R<=65 request flow bytes, S<=2 client SETTINGS ACKs, Z<=1 allowed
policy reset, initial server SETTINGS39/control1760. Full formulas in budget
note. Real five schedules do not gain permission for arbitrary extra requests.
All health/status/control/echo/reuse-next count as auxiliary; primary is explicit.

Track bytes and nonempty receives before processing, <=8192 each, aggregate
counters only. Each nonempty read contributes>=1byte; count bound follows wire
bytes, not arbitrary4096 reads for these new output stages. No wall-clock reset,
sleep, quiet-period assumption, automatic retry, fallback or threshold widening.
The source-specific strict mode permits only declared initial SETTINGS/ACKs,
HEADERS, unpadded DATA, valid known request refunds and allowed reset. No PING,
CONTINUATION/extension/push, INFO, trailers, extra settings, invalid flags/streams
or wrong frame size. General response-ledger padding tests still run in legacy
mode; actual candidate server emits unpadded DATA. HEADERS encoded block<=4096,
one server initial SETTINGS30payload+9, ACK0payload+9, WU4+9, raw DATA<=16384.
Producer primary<=2050 DATA frames (2049 atomic successes plus terminal), early
primary<=2 for explicit8+9 schedule; file conservative<=24594; small auxiliary
<=4096 DATA frames. Exact logical length/hash and existing semantic checks still
apply; spare wire budget never permits invalid traffic.

Final collection is exactly32statuses+metrics (33 auxiliary small responses),
no new request DATA/SETTINGS/PING/reset. Enter only after prior response
obligations/settings complete at a complete raw-frame boundary. Carry request
debt/parser/clock. Byte budget1487112+13*(actual remaining connection debt+sum
remaining stream debts), at most1488802 forR65. Every later refund still consumes
known debt; final stage does not require all closed debt to vanish. Do not reset
mid-frame/read or count a byte twice. A pre-run snapshot, if used later, is a
separately enumerated stage, not free extra traffic.

## Pure evidence and report

Actual pinned codec tests for ordered equal WU occurrences, before/after END in
one read, valid closed-stream suppression and late known refunds after response
retirement; partial frame credit only at completion, zero/unknown/excess/duplicate
refund rejection, conn/public minima and opposite-direction isolation. Keep
strict state fixed and prove limits with bounded actual frame bytes/caller data,
not fictitious native effects. Budget boundary and one-byte-over cases plus
33-response collection with residual known debt, no new DATA, invalid categories/
flags/frame sizes/extra ACKs. No retaining full large body or per-read history.

Capture meaningful actual behavioral RED/GREEN, covering affected codec/wire/
credit tests normal and selected optimized, AST/inert imports of every added/
changed module. Don't rerun unchanged contracts. Report exact APIs, commands/raw
outcomes/failures, source hashes/file count/bounds/self-review and remaining
freeze/current-input binding/preparation review gates. Return scoped DONE only
when this client core is callable and covered; no actual five-case/native/full
Task5d1 or original milestone completion claim. Root reviews before any next
fixture/runner release and independently verifies actual final current sources.
