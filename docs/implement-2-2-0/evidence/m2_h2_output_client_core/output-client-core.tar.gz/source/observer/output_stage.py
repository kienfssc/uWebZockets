"""Source-derived per-stage decrypted-byte and frame contracts."""
BUDGETS = {'producer': 18243676, 'file': 1693852, 'early': 1447948}
DATA_LIMIT = {'producer': 2050, 'file': 24594, 'early': 2}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def new_stage(kind, primary, expected_acks):
    require(kind in BUDGETS and type(primary) is int and 0 < primary <= 2147483647 and primary & 1 and
            type(expected_acks) is int and 0 <= expected_acks <= 2, 'invalid stage')
    return {'kind': kind, 'primary': primary, 'budget': BUDGETS[kind], 'bytes': 0, 'reads': 0,
            'active': {}, 'auxiliary': 0, 'initial_settings': 0, 'acks': 0, 'expected_acks': expected_acks,
            'resets': 0, 'final': False, 'high_water': 0, 'primary_complete': False}


def register(stage, stream_id, primary=False):
    require(type(stream_id) is int and stream_id > stage['high_water'] and stream_id <= 2147483647 and
            stream_id & 1 and type(primary) is bool and len(stage['active']) < 8, 'invalid stage registration')
    require(primary == (not stage['final'] and stream_id == stage['primary']), 'invalid primary')
    if not primary:
        stage['auxiliary'] += 1
        require(stage['auxiliary'] <= (33 if stage['final'] else 32), 'auxiliary bound')
    stage['active'][stream_id] = {'headers': False, 'data': 0, 'primary': primary, 'terminal': False}
    stage['high_water'] = stream_id


def retire(stage, stream_id):
    require(stream_id in stage['active'], 'unknown stage stream')
    record = stage['active'][stream_id]
    require(record['terminal'], 'stage response incomplete')
    if record['primary']:
        stage['primary_complete'] = True
    del stage['active'][stream_id]


def enter_final(stage, raw, request, response_credit):
    require(not stage['final'] and stage['primary_complete'] and not stage['active'] and not raw['streams'] and
            not raw['header'] and raw['frame'] is None and raw['remaining'] == 0 and
            response_credit['initial_acked'] and response_credit['pending'] is None and stage['acks'] == stage['expected_acks'] and
            stage['initial_settings'] == 1, 'invalid final boundary')
    debt = request['connection_debt'] + sum(item['debt'] for item in request['streams'].values())
    require(debt <= 130, 'invalid carried debt')
    stage['kind'] = 'final'
    stage['budget'] = 1487112 + 13 * debt
    stage['bytes'] = 0
    stage['reads'] = 0
    stage['auxiliary'] = 0
    stage['final'] = True
    request['final'] = True


def read(stage, data):
    require(type(data) is bytes and len(data) <= 8192, 'invalid read')
    if data:
        stage['bytes'] += len(data)
        stage['reads'] += 1
        require(stage['bytes'] <= stage['budget'], 'stage byte budget exceeded')


def frame(stage, length, kind, flags, stream_id, reserved):
    require(not reserved, 'reserved stream bit')
    if kind == 4:
        require(not stage['final'] and stream_id == 0, 'invalid settings')
        if flags == 0:
            require(length == 30 and stage['initial_settings'] == 0, 'invalid initial settings')
            stage['initial_settings'] += 1
        else:
            require(flags == 1 and length == 0 and stage['initial_settings'] == 1 and stage['acks'] < stage['expected_acks'], 'invalid settings ACK')
            stage['acks'] += 1
        return
    require(stage['initial_settings'] == 1, 'missing initial settings')
    if kind == 8:
        require(flags == 0 and length == 4, 'invalid WINDOW_UPDATE')
        return
    if kind == 3:
        require(not stage['final'] and flags == 0 and length == 4 and stream_id in stage['active'] and
                stage['resets'] < 1, 'invalid reset')
        stage['resets'] += 1
        return
    require(kind in (0, 1) and stream_id in stage['active'], 'invalid output frame')
    record = stage['active'][stream_id]
    if kind == 1:
        require(flags in (4, 5) and length <= 4096 and not record['headers'], 'invalid HEADERS')
        record['headers'] = True
        return
    require(flags in (0, 1) and record['headers'] and length <= 16384, 'invalid DATA')
    record['data'] += 1
    limit = DATA_LIMIT[stage['kind']] if record['primary'] else 4096
    require(record['data'] <= limit, 'DATA frame count exceeded')


def finish_final(stage, raw):
    require(stage['final'] and stage['auxiliary'] == 33 and not stage['active'] and not raw['streams'] and
            not raw['header'] and raw['frame'] is None and raw['remaining'] == 0, 'incomplete final collection')


def finished(stage, kind, flags, stream_id):
    if kind in (0, 1) and flags & 1 or kind == 3:
        stage['active'][stream_id]['terminal'] = True
