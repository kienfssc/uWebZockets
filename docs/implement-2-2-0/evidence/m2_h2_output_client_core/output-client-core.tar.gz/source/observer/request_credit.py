"""Bounded request-send debt; callers pair actions with public codec calls."""
MAX_REQUEST_FLOW = 65
MAX_WINDOW = 2147483647
INITIAL = 65535


def require(condition, message):
    if not condition:
        raise ValueError(message)


def number(value, low, high):
    require(type(value) is int and low <= value <= high, 'invalid integer')


def new_state():
    return {'connection': INITIAL, 'connection_debt': 0, 'sent': 0, 'high_water': 0,
            'streams': {}, 'settings_seen': False, 'client_settings': 0, 'final': False}


def open_stream(state, stream_id):
    number(stream_id, 1, MAX_WINDOW)
    active = sum(not closed(x) for x in state['streams'].values())
    require(stream_id & 1 and stream_id > state['high_water'] and active < 8 and len(state['streams']) < 73, 'invalid stream opening')
    state['streams'][stream_id] = {'window': INITIAL, 'debt': 0, 'request_end': False,
                                   'response_end': False, 'reset': False, 'retired': False}
    state['high_water'] = stream_id


def stream(state, stream_id):
    number(stream_id, 1, MAX_WINDOW)
    require(stream_id in state['streams'], 'unknown stream')
    return state['streams'][stream_id]


def send_data(state, stream_id, logical, flow):
    number(logical, 0, MAX_REQUEST_FLOW)
    number(flow, 0, MAX_REQUEST_FLOW)
    record = stream(state, stream_id)
    require(not state['final'] and not record['request_end'] and not record['reset'] and
            not record['retired'] and logical <= flow and state['sent'] + flow <= MAX_REQUEST_FLOW and
            flow <= state['connection'] and flow <= record['window'], 'invalid request DATA')
    state['sent'] += flow
    state['connection'] -= flow
    state['connection_debt'] += flow
    record['window'] -= flow
    record['debt'] += flow


def end_request(state, stream_id):
    record = stream(state, stream_id)
    require(not record['request_end'] and not record['reset'], 'invalid request end')
    record['request_end'] = True
    if record['retired'] and record['response_end'] and record['debt'] == 0:
        del state['streams'][stream_id]


def reset_request(state, stream_id):
    record = stream(state, stream_id)
    require(not state['final'] and not record['reset'], 'invalid request reset')
    record['reset'] = True
    record['request_end'] = True
    record['response_end'] = True
    if record['retired'] and record['debt'] == 0:
        del state['streams'][stream_id]


def incoming_reset(state, stream_id):
    record = stream(state, stream_id)
    require(not record['reset'], 'duplicate incoming reset')
    record['reset'] = True
    record['request_end'] = True
    record['response_end'] = True


def end_response(state, stream_id):
    record = stream(state, stream_id)
    require(not record['response_end'], 'duplicate response terminal')
    record['response_end'] = True


def closed(record):
    return record['reset'] or (record['request_end'] and record['response_end'])


def retire(state, stream_id):
    record = stream(state, stream_id)
    require(record['response_end'] and not record['retired'], 'invalid retirement')
    record['retired'] = True
    if closed(record) and record['debt'] == 0:
        del state['streams'][stream_id]


def refund(state, stream_id, increment):
    number(stream_id, 0, MAX_WINDOW)
    number(increment, 1, MAX_WINDOW)
    if stream_id == 0:
        require(increment <= state['connection_debt'] and state['connection'] + increment <= MAX_WINDOW, 'invalid connection refund')
        state['connection_debt'] -= increment
        state['connection'] += increment
        return True
    record = stream(state, stream_id)
    require(increment <= record['debt'], 'invalid stream refund')
    emits = not closed(record)
    record['debt'] -= increment
    if emits:
        require(record['window'] + increment <= MAX_WINDOW, 'stream credit overflow')
        record['window'] += increment
    if record['retired'] and closed(record) and record['debt'] == 0:
        del state['streams'][stream_id]
    return emits


def compare_public(state, protocol, query_streams):
    require(type(query_streams) in (list, tuple), 'invalid query list')
    value = protocol.outbound_flow_control_window
    require(type(value) is int and value == state['connection'], 'connection credit differs')
    seen = set()
    for stream_id in query_streams:
        record = stream(state, stream_id)
        require(stream_id not in seen and not closed(record), 'invalid stream query')
        seen.add(stream_id)
        value = protocol.local_flow_control_window(stream_id)
        require(type(value) is int and value == min(state['connection'], record['window']), 'stream credit differs')


def server_initial_settings(state, initial_window):
    number(initial_window, 0, MAX_WINDOW)
    require(not state['final'] and not state['settings_seen'] and initial_window == INITIAL, 'unexpected server settings')
    state['settings_seen'] = True


def client_settings_sent(state):
    require(not state['final'] and state['client_settings'] < 2, 'invalid outgoing settings')
    state['client_settings'] += 1
