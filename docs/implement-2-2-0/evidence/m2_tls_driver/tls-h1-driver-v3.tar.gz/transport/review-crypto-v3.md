# TLS component crypto review v3

Verdict: no actionable crypto/TLS findings in the reviewed component. Suitable
for Root's next combined integration and ordinary TLS upload validation; this
is not TLS upload runtime acceptance or release approval.

Reviewed baseline `acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b`
and candidate `2498622e3a120c6fd0cfee575ad1223b3961ce9e22cbeb9ba39b3d1d59be2cf7`.
Read the actual v3 patch and candidate TCP/upload implementations, Task1 report,
accepted capacity/retry review and previously checked pinned BoringSSL contracts.
Patch SHA-256 independently read as
`09ffeac7196065c87a0badc96023c18680b0fda1625f21fab9028dad7cb59a7a`.
Only this report was written. No compilation, runtime probe, source mutation,
dependency operation, or native scheduling experiment was performed.

## Concrete source conclusions

- `tcp.zig:1617` receive_capacity samples network_bio write guarantee for enabled
  TLS, independently of positive selected-H1 plaintext readiness. Both actual
  fresh arm and completed-receive retarget use it immediately before arming.
  `on_upload_read_complete` checks the actual submitted slice length before
  slicing connection storage. Completion does not reapply pause to reject an
  already reserved receive. `process_tls_data:440` is the sole inbound writer,
  retains its borrow, and fails closed on an enabled partial BIO write. The
  existing deferred deinit/retirement contract preserves the reservation BIO.
- `drain_tls_plaintext:503` recomputes read_capacity before every SSL_read and
  stops at zero. `tcp_upload.zig:39-63` preserves protocol bypasses while H1
  pause, dispatch, file, producer and async ownership suppress extraction.
  Ciphertext can enter the reserved BIO after pause without further plaintext
  delivery. The three TLS admission exclusions were removed together.
- Resume progresses retained driver bytes before entering the real TLS drain;
  neither resume nor native-write continuation uses SSL_pending. Normal async
  completion still processes retained pipeline bytes before retained TLS input.
  ALPN selection/no-ALPN H1 and actual SSL_in_early_data policy remain intact.
  No context/version, ALPN, early-data configuration, key, certificate, BIO-size
  or record-size change appears in the patch.
- A positive valid native write completion offers one gated selected-H1 drain
  opportunity. It does not depend on SSL_want, and WANT_READ stops. Local
  WANT_WRITE retry requires actual outbound BIO removal; its failed-read branch
  introduces no input or application callback. This satisfies the pinned finite
  flight/retained-message/KeyUpdate argument recorded in the plan review.
- On zero removal, needs_write_completion invokes arm_write before batch
  cleanup. Active sends retain their event; frame/retirement gates record
  write_resume_pending. write_batch_action preserves this native-arm intent
  through enclosing batches. upload_tail captures the intent and calls
  arm_write directly, permitting the existing gate to republish it until native
  retirement drains. The reviewed code does not replace that required event
  with a synchronous final flush.
- TLS close-notify claims peer_closed before generic graceful-close cancellation;
  fatal BIO/handshake/read/flush paths select source_failure. BodyState first
  cause and terminal ownership retain exactly-once cleanup. Close-notify cannot
  be inspected while plaintext extraction is paused; ordinary resume is needed
  to observe it, as required by the accepted pause contract.
- New process/drain entry points own or inherit delivery protection. Deferred
  cleanup order ends the batch before final finish_borrow. Read/write native
  callback pins remain active through nested calls. Physical SSL/BIO destruction
  still requires claim_close after delivery, callbacks, ACKs and retirement drain;
  the physical-close tail has no subsequent SSL access. Owner-null calls retain
  the legacy path and are not routed through enabled plaintext caps.

## Evidence and remaining acceptance

The Task1 report records 27/27 driver tests in Debug and ReleaseSafe, 31 unchanged
App cases, three unchanged healthy TLS cases, central native/macOS/Windows
semantic compilation, and formatting/conventions/version/source audits. Those
checks were not rerun here. The driver capacity tests use real caller facts;
they do not establish native BIO reserve/completion timing or live TLS uploads.

Required next evidence remains ordinary enabled TLS upload clients for records
larger than ingress, retained-BIO explicit resume without new input, final-byte
pause, actual output-progress continuation, terminal causes/quota once, early-data
refusal, and buffered/no-ALPN/H2/WebSocket coexistence. Combined sanitizer and
C-boundary checks, full project gates, and native Windows runtime acceptance
remain open. No allocation-wide, performance, native scheduling, or global
liveness conclusion follows from this component review.
