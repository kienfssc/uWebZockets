# Global Constraints and accepted architecture

- Read AGENTS.md and CODING_CONVENTION.md. Zig0.16, named explicit flat types,
  pure policy first, shallow flow, no new allocation on library input/delivery
  paths. Preserve all existing limits, assertions, APIs and default behavior.
- Specs: 2.2.0-TODO.md M2; docs/adr/0008-request-body-streaming.md; accepted
  .uwz-work/evidence/h1-transport/r3/h1-head-driver-seam.md,
  native-lifetime-minimum-contract.md and submit-callback-source-audit.md.
  The narrow ciphertext-capacity clarification below must be independently
  accepted and documented; do not silently contradict ADR0008's literal text.
- Frozen executable baseline: /tmp/uwz-m2-h1-plaintext-combined,1023regular
  inputs,digest acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b.
  Reviewed App and real tcp_upload driver; corrected21/21 owned clients,
  combined62/62 Debug+RS and three unchanged healthy buffered TLS tests pass.
  RootHEAD36bf44a saves recovery/evidence; no production adoption yet.
- Work in NEW /tmp/uwz-m2-h1-tls-transport only; no hardlinks/symlinks/caches
  copied. Do not edit baseline, other copies, Root source/config/docs/exports,
  test root, refs or pins. Root serializes shared integration and commits/pushes.
  You are not alone; never revert others. No subagents or publication.
- Durable source snapshots/preimages/patches/reports and every actual command,
  status, raw log and input/compiler/binary/environment identity stay under
  .uwz-work/evidence/h1-tls/transport. Large artifacts/cache/IR stay /tmp.
  Workspace free space is limited; /tmp may vanish across continuations.
- Compiler /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig -j2.
  Existing explicit compile recipes: .uwz-work/evidence/h1-plaintext/combined/driver.py.
  Override only immutable93 libxev files at
  /tmp/uwz-reviewed-libxev-c223-loop-callbacks,commit
  c223bd886c6a51d2cd60def39dd9a68d701fea73,tree
  86c6944f53dc009d7503a9ab0bc873aef3cd7b79; source manifest
  .uwz-work/evidence/loop-callbacks/immutable-libxev-input.json.
  Original C bindings: .uwz-work/evidence/h1-transport/r2/c-{native,aarch64-macos,x86_64-windows-gnu}.zig.
  Existing native static libraries in zig-out/lib. No fetch/new build requirements.
- BoringSSL pinned official source at
  zig-pkg/N-V-__8AAA5Ieg5843crc8uXWdNhmmfStwJqA-9TknJSx3_n,
  commit d3bf4795ad5b79d646cddf2fec687da5b9b502db. Use local headers/source.
  No vendor edits. Keep TLS1.3, ALPN h2 then http/1.1, safe-method early data,
  mTLS early-data disabling, record16KiB/BIO32KiB and output backpressure.
- Before new codebase search: env PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify
  /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query QUESTION --budget 800.
  Supplied paths located; isolated source not indexed. Refresh graph after edits.
- The stopped cancellation experiment stays stopped. No cancellation schedules,
  interleaving/race/crash/leak/registration-error/invalid-fd/resource-exhaustion/
  kernel-error/injected-completion/panic probes. Do not fabricate native callbacks
  or SSL objects. Allowed: actual pure operations with caller facts, unchanged
  healthy suites, foreign compile and Root-released owned ordinary TLS clients.
- User confirmed community BSD activation refusal. Linux/macOS eligibility and
  cross compilation do not prove native runtime. Windows release gate remains.
  Maintained publication/protection/four-zon adoption and full gates stay open.

## Source-backed architecture and bounded specification clarification

Use the existing tcp_upload H1 driver for raw and decrypted plaintext. No second
collector, stored field, new protocol discriminator or generic continuation.
Deleting this driver would duplicate admission/framing/progress/terminal and
metadata ownership in two transports. Crypto effects remain in tcp.zig.

Baseline tcp.zig1177/1216/1244 excludes TLS from upload delivery, admission and
physical exhaustion;507 calls SSL_read with8192. tcp_upload.zig27 bypasses H1
capacity when ssl exists. Remove these exclusions coherently with bounded
extraction. route_decrypted_data528 and handshake ALPN469 retain H2/WS selection.

Plaintext extraction: selected enabled H1 uses min(8192,free_ingress), including
existing raw-detect probe accounting where applicable. Paused/full/suspended
upload submits no new plaintext extraction. Never call SSL_read with0; recompute
after callbacks. Pinned ssl.h253 guarantees at most requested plaintext;
ssl.h265 documents zero-length ambiguity.

Root-accepted explicit exception to ADR0008's literal socket-read cap: encrypted
receive readiness is gated by positive H1 plaintext capacity, no pause and no
response owner; its byte count is min(8192,BIO_ctrl_get_write_guarantee(network_bio)).
SSL_read retains the exact plaintext cap. The existing32KiB BIO retains ciphertext;
no spill buffer or extra allocation. This avoids forcing tiny ciphertext receives
while collecting a full TLS record for a small plaintext window. BIO readable
pending bytes are outbound ciphertext, not inbound capacity (bio.h225/652).

Root ruling: architect source proof and independent crypto review in
review-plan-capacity.md approve this narrow exception. ADR0008 now records it
explicitly before implementation. Concrete code and runtime remain unapproved.

Reservation proof: compute BIO guarantee immediately before actual submit/rearm;
preserve that BIO until receive retirement. Existing one active receive1593 and
one inbound writer process_tls_data440 mean no competing producer consumes this
reservation. Other TLS operations consume inbound data. An already submitted
receive may complete after a sink pauses: accept only its reserved ciphertext,
perform no paused SSL_read and do not rearm. Deferred TLS destruction3037 remains.

Before ALPN selection, handshake receives use BIO capacity without an unselected
H1 window. Handshake completion477-484 selects http2 or http; no ALPN selects http
without plaintext prior-knowledge probing. Selected H2/WS bypass H1-window rules,
retaining BIO and normal close/dispatch guards. Raw detect keeps its probe bytes.

Resume: process retained H1 payload/framing first, then bounded TLS extraction,
then existing final tail/receive gate, under the inherited delivery borrow.
Do not gate legitimate extraction solely on SSL_pending: ssl.h280/294 excludes
ciphertext still in BIO. Drain until real WANT_*, pause, response owner or close.
Final-byte pause may end on resume with no further socket data. Producer completion
resume_async_dispatch1541 already processes retained pipeline bytes then TLS.

Keep native frame/ACK/two fresh retirement phases/one-shot close unchanged.
Every new TLS entry retains the operation borrow across SSL_read, sink callbacks,
output flushing and batch cleanup. Re-read state after callbacks; final owned
borrow release is the final connection action. WANT_WRITE requires narrowly
gated continuation from real output progress (write completion2154 currently
flushes output/handshake but not explicitly H1 extraction); never spin or recurse
unconditionally from every tail. WANT_READ waits for legitimate input.

Root/crypto clarification: a single gated TLS drive after each actual positive
native ciphertext-write completion is legitimate output progress; it need not
claim a persistent SSL_read WANT_WRITE state. It may reach WANT_READ once.
Forbid repeated immediate WANT_READ attempts without new input/output/resume
progress. SSL_want tracks the most recent operation and cannot retain read-retry
intent across intervening SSL writes/handshakes. No new flag is approved.
Local fully synchronous WANT_WRITE retries still need a finite-work or actual
future-event proof; one BIO pending reduction alone is not that proof.

Native EOF/reset mapping2920 stays. TLS close-notify on incomplete body selects
peer_closed exactly once; fatal TLS/BIO failure selects source_failure. Current
zero-return516 uses generic close_after_flush and needs correct body cancellation
before close. Preserve accepted-prefix accounting, metadata/response lifetime,
file/producer/async owner guard and end-error's no-second-cancel rule. Actual
SSL_in_early_data governs replay policy (ssl.h4568), not handshake_done alone.

