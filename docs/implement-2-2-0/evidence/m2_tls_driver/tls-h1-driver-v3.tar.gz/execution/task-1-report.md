# TLS H1 Task 1 — v3 component review checkpoint

Status: implemented in the independent source copy, READY_FOR_REVIEW; all assigned component checks finished. No new native TLS upload clients or native fault/timing experiments were run. No production adoption, TLS upload runtime acceptance or milestone completion is claimed.

## Exact source and ownership

Baseline `/tmp/uwz-m2-h1-plaintext-combined`: **1,023** regular files, digest `acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b`. Every file was hash-verified before an independent byte copy; no symlinks, hardlinks, caches or baseline mutation.

Candidate `/tmp/uwz-m2-h1-tls-transport`: v3 digest `2498622e3a120c6fd0cfee575ad1223b3961ce9e22cbeb9ba39b3d1d59be2cf7`. Durable evidence root `.uwz-work/evidence/h1-tls/transport/` contains `v3-manifest.json`, read-only `snapshots/v3/` complete changed-file replacements, baseline `preimages/`, and `v3.patch` (SHA-256 `09ffeac7196065c87a0badc96023c18680b0fda1625f21fab9028dad7cb59a7a`). Only these three files changed:

- `src/core/tcp.zig`
- `src/core/tcp_upload.zig`
- `src/tests/http1_upload_driver_tests.zig`

The current Root ADR0008 ciphertext exception was read before implementation; baseline prose was not treated as superseding that amendment. App/config/root exports/test_support/test registration, cold storage, common BodyState/decoder/parser, protocol enum, TLS context and native dependency sources/pins remain untouched. No stored field or completion was added. The named `PlaintextWindow` is transient caller input to a pure policy, not connection storage.

## Concrete behavior

The existing H0 and retained-tail driver now serves decrypted H1 bytes as well as raw H1 bytes; all three TLS exclusions were removed coherently with bounded SSL extraction. `read_capacity` derives the current enabled plaintext window and pause/response-owner facts. Selected H1 SSL_read uses min(8192, free ingress) and never receives zero. Capacity is recomputed after every successful read/dispatch. Raw detection preserves probe accounting; handshake detect and selected H2/WebSocket bypass H1 window limits. ALPN selection and actual SSL_in_early_data rejection remain unchanged.

Fresh enabled socket submission and completed-receive retarget/rearm both call the same actual receive sampler immediately before arming. TLS uses min(8192, BIO_ctrl_get_write_guarantee(network_bio)); selected H1 additionally requires positive plaintext capacity/readiness. The callback checks returned length against its actual submitted ReadBuffer slice before taking a connection buffer slice. It does not resample readiness to reject a previously reserved receive. `process_tls_data` accepts that ciphertext into the sole inbound BIO writer even after pause, requires the enabled BIO write to accept its entire requested piece, and performs no paused plaintext extraction. No spill buffer or allocator was introduced.

BodyControl resume processes retained payload/framing first, then drains real retained SSL/BIO input without SSL_pending gating, then enters the existing final tail. Async/producer response completion retains its existing buffered pipeline-before-TLS sequence. File, producer, async and dispatch suspension all block H1 extraction. Final-byte pause can complete without another network read.

TLS close-notify first requests actual `.peer_closed` terminal ownership before generic graceful close. Fatal SSL/BIO processing or output flush errors use `.source_failure`; no completed body acquires a second cancel. Native EOF/reset mapping is unchanged. Every newly entered TLS processing/drain operation owns or inherits the existing delivery borrow; batch cleanup and output flush finish before the final owned borrow release. Existing frame/ACK/two-stage retirement/claim-close/TLS-deinit/pool-release ordering stays in force.

## Retry and wakeup proof

There is **no SSL_want dependency and no stored read-retry flag**. Root/crypto approved one readiness-gated selected-H1 drain opportunity after each actual positive native ciphertext-write completion. The callback already rejects zero/invalid completion lengths. The opportunity rechecks closing, protocol, handshake and complete H1 readiness facts; WANT_READ stops immediately. This does not claim what a previous SSL operation wanted.

Inside one selected-H1 drain, an actual SSL_ERROR_WANT_WRITE retries only if `flush_tls_out` removes outbound BIO bytes. That failed-read branch admits no fresh ciphertext, invokes no application callback and does not reset protocol state. Its finite-work argument is the pinned BoringSSL source, not a claim that BIO pending is globally monotonic:

- `ssl/s3_both.cc:204–255`: finite pending flight is bounded by UINT32_MAX, advances pending_flight_offset on BIO writes and is then released.
- `ssl/ssl_lib.cc:833–910`: SSL_read progresses its handshake or consumes retained records/post-handshake messages.
- `ssl/tls13_both.cc:680–712,747–754`: pending KeyUpdate output coalesces and consecutive incoming KeyUpdates are bounded to 32.

Successful plaintext goes back through the normal recomputed capacity/callback gates. No arbitrary iteration cap can discard a required wakeup. WANT_READ is never immediately retried without new input, explicit resume or a later real output event.

If a WANT_WRITE flush makes zero progress, the existing fixed BIO pair has pending output and `flush_tls_out` cannot move it because the bounded output ring is full. The local `needs_write_completion` fact makes drain cleanup call the existing `arm_write` before ending the batch. An already active send supplies the event; otherwise arm_write either submits the queued nonempty ring or records its existing native-arm work in `write_resume_pending` while a frame/retirement gate owns the completion.

The actual pure `write_batch_action` keeps nested batches held and makes outer cleanup honor a pending native arm instead of direct synchronous flushing. This prevents enclosing batch cleanup from emptying the ring and erasing the only output event. `upload_tail` captures that pending-arm decision, clears the pending-work flag and calls `arm_write` directly for it (rather than the batch-suppressed start_write). The actual gate either arms or republishes the pending arm until retirement ends. It never fabricates a ready callback. With no pending arm, normal synchronous batching remains selected.

Metadata reset cannot strand this blocked read: a failed SSL_read returns no application bytes, so it cannot itself complete a request and establish pending_request_consumed. A response owner already suspends extraction before SSL_read. Reset requires response completion and all canonical borrows drained; if later real input/output/resume instead succeeds and establishes a completed response, that legitimate drive already supplied the retry opportunity. Closing cancels the need for further read work. These are bounded source arguments for the declared no-loop-reentry/stable-owner contracts, not native schedule evidence.

## TDD and currently completed checks

`driver.py` records exact compiler argv, command status/raw output, source before/after, compiler/module/static archive hashes, immutable 93-file c223 override hashes and output binary identity. Sources were not changed during compilation/execution. Large binaries/caches stay under the task's `/tmp` paths. Pinned BoringSSL and original C bindings are unchanged.

The extracted predecessor policies remained consumed by actual production read/receive sites. Frozen `capacity-red` (`0869b934608f2f3c77603974573620d2561c9b20313017caf9b5654bb726fe45`) compiled successfully, then **19 passed / 4 failed**: TLS tiny/plaintext pause bounds and BIO guarantee/handshake bounds. This is a behavioral red using caller facts, without fake SSL objects or native completions. Fixed `capacity-green` passed **25/25**. Additional width/protocol tests and the actual batch decision tests are coverage, not falsely claimed independent failing-first cases.

The first full-effects v1 compilation failed on an obsolete `_ = buffer` after the callback began using the actual buffer parameter. That compiler failure and exact source are preserved. v2 removes that discard; no test or gate was weakened.

Final v3 results: driver **27/27 Debug** and **27/27 ReleaseSafe**; unchanged App **31/31 ReleaseSafe**; unchanged healthy TLS **3/3 ReleaseSafe**. Full central semantic compilation passed for native, aarch64-macos and x86_64-windows-gnu. No whole isolated central native suite was executed. fmt --check, conventions and release-version checks passed. Graphify AST update passed in an independent identical source copy (parallel extraction unavailable; successful sequential fallback). `final-v3-audit.json` verifies all 1,023 source files, unchanged canonical modules and exact TCP stored-field text; no allocator identifiers in the driver. Manual diff review found no added allocation call in TCP.

Formatting preparation `fmt-v3.json` intentionally changed source before freezing v3; it is a formatter operation, not immutable test evidence. Final `fmt-check-v3.json` checks the exact frozen source without mutation. Every final compile/runtime/conventions/version check has matching before/after source digest `2498622e...`; their compiler/input/override identities are retained in the respective JSON files. Healthy App/TLS execution used the previously authorized unsandboxed io_uring environment. That is ordinary protocol coverage, not enabled TLS upload evidence.

Exact commands, statuses and raw output are preserved per label below. The command launcher prefix is `python3 .uwz-work/evidence/h1-tls/transport/driver.py`; full expanded compiler argv and binary hashes reside in each matching JSON record.

| Launcher arguments | Result |
| --- | --- |
| `test driver-v3-debug src/tests/http1_upload_driver_tests.zig Debug` then `run driver-v3-debug` | compile 0; 27/27 |
| `test driver-v3-safe src/tests/http1_upload_driver_tests.zig ReleaseSafe` then `run driver-v3-safe` | compile 0; 27/27 |
| `central central-v3-native native` | 0; semantic only |
| `central central-v3-macos aarch64-macos` | 0; semantic only |
| `central central-v3-windows x86_64-windows-gnu` | 0; semantic only |
| `test app-v3-safe src/tests/body_app_tests.zig ReleaseSafe` then `run app-v3-safe ordinary` | compile 0; 31/31 |
| `test healthy-tls-v3-safe src/tests/main.zig ReleaseSafe 'tls echo:'` then `run healthy-tls-v3-safe ordinary` | compile 0; 3/3 |
| `command fmt-check-v3 /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check src builds examples tests fuzz` | 0 |
| `command conventions-v3 sh scripts/check_conventions.sh` | 0 |
| `command version-v3 sh scripts/check_release_version.sh` | 0; metadata matches 2.1.6 |

`python3 .uwz-work/evidence/h1-tls/transport/graph_check_v3.py` and `audit_v3.py` both exited 0. Graph output is under `/tmp/uwz-m2-h1-tls-transport-artifacts/graph-source-v3/graphify-out`; command, input identity and raw log are durable.

## Remaining boundaries

Root must obtain independent concrete transport/spec/quality/crypto review before using this source for new owned TLS upload clients. Those clients must prove tiny ingress versus TLS records, retained BIO resume/no-new-input completion, actual output progress, close-notify and terminal/quota behavior, early-data refusal, and H2/WebSocket/no-ALPN selection. Pure policy and source arguments do not substitute for that runtime evidence. Existing healthy TLS cases exercise unchanged buffered behavior only.

No allocator-wide, throughput, native-Windows, global-liveness or full-project-gate claim is made. Maintained c223 publication/adoption/protections/four-zon updates, combined sanitizer/C-boundary checks and full project release gates remain Root-owned and open.
