# TLS H1 capacity plan review

Source-only crypto review of `h1_tls_plan.md` against combined baseline
`acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b`
at `/tmp/uwz-m2-h1-plaintext-combined`. BoringSSL source:
`d3bf4795ad5b79d646cddf2fec687da5b9b502db`, package
`zig-pkg/N-V-__8AAA5Ieg5843crc8uXWdNhmmfStwJqA-9TknJSx3_n`.
No implementation, build, runtime experiment, dependency change, or probe was
performed. This reviews the plan; it does not approve an unseen implementation.

## Decision

No actionable conflict in the proposed narrow capacity exception. Approve its
explicit documentation before implementation, subject to the requirements below.
ADR 0008 currently literally caps both socket reads and SSL_read by free ingress
at lines 252-257. The exception must replace/qualify that language explicitly for
enabled TLS H1 ciphertext only. Raw plaintext retains the original cap.

The ciphertext count may exceed current plaintext free space because it is
retained in the existing bounded BIO. The plaintext result still cannot exceed
the independently computed free ingress. This preserves the original reason for
the bound: no unretained plaintext suffix after a sink pauses.

## Source basis

- `include/openssl/bio.h:652` defines the next-write guarantee for a BIO pair.
  `crypto/bio/pair.cc:183` writes into that BIO's own buffer; `:312` returns
  `size-len` (zero for closed/unpaired BIOs). `:109` reads the peer's buffer.
  Thus SSL consumption of network input can increase its available capacity;
  outbound SSL writes and network-side reads use the opposite buffer.
- `bio.h:225` pending bytes mean readable bytes. On network_bio those are
  outbound ciphertext, so pending is not inbound free space.
- `ssl.h:253` bounds SSL_read's successful plaintext result by its argument;
  `:265` prohibits treating a zero-length call as an EOF discriminator.
  `:280` and `:294` do not make pending APIs a test for ciphertext retained in
  network_bio.
- `ssl.h:4568` states that accepted server early data can make SSL_do_handshake
  complete before the handshake is confirmed. Baseline tcp.zig:1948 uses actual
  SSL_in_early_data; its is_tls_handshake_done flag alone is insufficient.
- Baseline tcp.zig:440 is the sole network_bio writer in this transport;
  init/deinit at :398/:429 own its replacement/destruction. Existing active
  receive, callback, ACK and retirement ownership must remain the reservation
  lifetime. No new competing writer or BIO replacement is authorized.

## Required implementation review gates

1. Separate readiness from byte count. For selected enabled H1, positive
   plaintext capacity, non-paused delivery, and no response owner are required
   for a new ciphertext receive. Then use min(8192, current network BIO write
   guarantee), refusing zero. Sample at both actual fresh submission and actual
   completed-receive retarget/rearm, after the last state-changing callback.
   One receive and one inbound writer must remain true. Do not resample on
   completion and reject previously reserved input merely because H1 paused.
2. A submitted receive may finish after pause. Retain its ciphertext within the
   reservation, but neither extract plaintext nor rearm while paused/full or
   response-owned. Preserve SSL/BIO through receive retirement. A BIO failure
   or impossible completion length fails closed; never spill, discard a suffix,
   or turn a partial BIO write into accepted complete input.
3. Compute min(8192, current plaintext free ingress) immediately before every
   enabled selected-H1 SSL_read. Never call with zero. Recompute following each
   dispatch/sink/control callback. Retained H1 payload/framing progresses before
   further SSL extraction. Resume must reach retained BIO/SSL input without
   depending on another socket event or a positive SSL_pending result.
4. Before handshake/ALPN selection use only the BIO receive bound. After
   selection, http1 and no-ALPN use H1 gates; H2 and WebSocket retain their
   protocol paths. Preserve raw detect probe accounting and default owner-null
   behavior. Remove the three TLS admission/delivery/exhaustion exclusions
   coherently with bounded extraction, rather than enabling admission alone.
5. Preserve existing early_data_forbids at admission before streaming callbacks,
   including GET/HEAD/OPTIONS only, using SSL_in_early_data. Do not infer replay
   safety from is_tls_handshake_done or ALPN selection. No TLS context, mTLS,
   QUIC early-data, or ALPN policy change belongs in this slice.
6. SSL_ERROR_ZERO_RETURN during an incomplete upload must claim peer_closed
   before generic graceful-close cancellation can select cancelled. Fatal
   SSL/BIO errors must claim source_failure. Native EOF/reset retain their
   existing reasons. Preserve the first reason and terminal/quota exactly-once
   rules; a completed body/end error must not gain a second cancel callback.
   Paused TLS input cannot reveal a close-notify until legitimate extraction
   resumes; do not bypass pause to inspect application records.
7. WANT_READ waits for legitimate input. WANT_WRITE requires a bounded retry
   from actual output progress, retaining H1 pause/response/close gates. Baseline
   write completion flushes output and drives handshakes but does not explicitly
   resume H1 extraction. Do not solve that gap with unconditional tail recursion
   or an SSL_read loop that retries WANT_WRITE without progress.
8. Each new TLS entry must own or inherit delivery/native callback protection
   through SSL calls, user callbacks, output flush and final batch cleanup.
   No access follows final owned finish_borrow/upload_tail. Keep claim_close,
   ACKs, both fresh retirement boundaries and deferred deinit_tls unchanged.
   Re-review the concrete diff for post-close accesses and output retry paths.

## Evidence required after implementation

Pure policy reds/greens must cover the independent cipher/plain capacities,
tiny/full windows, zero guarantee, pause, response ownership and protocol
selection. Actual ordinary TLS clients must establish records larger than small
ingress, retained-data resume without new input, final-byte pause, output-progress
continuation, early-data rejection before streaming callbacks, and incomplete
close-notify/terminal reasons. Keep healthy buffered/no-ALPN/H2/WS coverage and
the accepted plaintext suites. Root's reported 21 ordinary plaintext and three
unchanged TLS passes do not demonstrate TLS uploads. The implementation review,
combined runtime evidence, sanitizer/C-boundary checks and full project gates
remain required; cross compilation does not establish native Windows behavior.

## Follow-up: no-state WANT_WRITE continuation

`SSL_want` is not a durable read-specific retry flag. Pinned
`include/openssl/ssl_deprecated.h:445` explicitly describes the most recent
operation. `ssl/ssl_lib.cc:2867` returns shared rwstate; `:75` resets it to NONE,
and SSL_write (`:950`) and SSL_do_handshake (`:719`) perform that reset.
Capturing at write-completion entry before flush/handshake is necessary but
does not itself prove no intervening operation overwrote a read's WANT_WRITE.

The baseline selected-H1 path can support this approach only with a concrete
exclusion proof: while read WANT_WRITE awaits output, no asynchronous response,
stream/file producer, sink/control path, or other SSL writer may overwrite the
state without itself performing the legitimate H1 retry or transferring to a
response owner whose completion resumes extraction. The actual callback guard
must exclude all response owners, not merely a paused body. Baseline end-batch
flush uses ciphertext writes rather than SSL_write, so that flush alone does
not overwrite rwstate; H1 does not invoke the WebSocket drain callback. Body
resume must itself drain TLS under its borrow. Closed connections need no
retry. No blanket approval of arbitrary interleaved SSL writes is implied.

Snapshotting the retry fact locally before write-completion TLS work avoids
that callback's own overwrites. Retry after real output progress only when
still selected enabled H1 and eligible; a WANT_WRITE from a different operation
must not be advertised as a saved read operation. Do not retry WANT_READ just
because output progressed.

Within one drain, a strictly decreasing outbound BIO pending count across a
flush proves useful local movement, but is not by itself a global termination
measure: the next SSL_read can refill that BIO. Approval therefore requires
either an explicit finite per-turn retry bound with a non-stranding scheduled
continuation, or a source-backed finite-work argument over the pending TLS
flight/control work and fixed retained input, with no recursive delivery or
fresh input in that retry subloop. Successful plaintext reads must return to
the ordinary recomputed H1 capacity/pause gates. A flush that cannot reduce
pending must stop immediately; it must leave a real output-progress wakeup
when retry remains necessary. In particular, a synchronous final batch flush
must not empty the ring and erase the only wakeup after a stopped WANT_WRITE.

These are implementation prerequisites, not a demonstrated failure in code
that has not yet been written. No new stored field is approved by this review.

## Follow-up A: output progress as an opportunity

Approve one readiness-gated selected enabled-H1 drain opportunity per actual
positive native ciphertext-write completion, without consulting SSL_want or
claiming a persistent read retry. A real output-progress event is a bounded
opportunity to process retained TLS input, even if the previous read returned
WANT_READ. If it returns WANT_READ again, stop. Qualify the earlier requirement
accordingly: no repeated immediate WANT_READ retry without new input, explicit
resume, or actual output progress. This is event-driven work, not readiness
polling. Preserve pause, positive plaintext capacity, all response owners,
close/protocol selection and operation-lifetime gates. No stored retry flag is
needed for A.

Additional pinned source supports a finite-work argument for local synchronous
WANT_WRITE retries: `ssl/s3_both.cc:204-255` flushes a finite pending flight
(rejecting lengths above UINT32_MAX), advances pending_flight_offset for each
successful BIO write, then releases that flight. `ssl/ssl_lib.cc:833-910` either
progresses the current handshake, consumes a buffered post-handshake message
with next_message, opens retained records, or returns. TLS 1.3 post-handshake
KeyUpdate output is coalesced while pending (`tls13_both.cc:680-712`) and
consecutive incoming KeyUpdates are capped at 32 (`:38-41`, `:747-754`).

Thus, for the pinned TLS-1.3 server path, local retry is supportable when each
WANT_WRITE retry follows actual removal of outbound BIO bytes, no fresh input
is admitted inside that retry subloop, no application callback creates new work
inside the failed-read retry branch, and protocol flight state is not reset.
The current finite flight advances, or finite already-retained input advances
to another finite flight; it cannot manufacture an unbounded sequence of new
peer messages. Successful plaintext returns to the ordinary capacity and
callback gates. This is the finite-work argument; BIO pending alone remains
non-monotonic across SSL_read calls. Review the actual implementation against
these premises. On zero flush progress, stop and retain the actual output
wakeup; do not strand the operation by an arbitrary retry cap. A drain ending
on WANT_READ needs no further output-driven retry within that same call.
