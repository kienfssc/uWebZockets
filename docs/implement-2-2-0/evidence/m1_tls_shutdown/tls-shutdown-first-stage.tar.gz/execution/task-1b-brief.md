# Task 1b: graceful TLS close-notify retry

Read current globals, accepted native lifetime contract and
.uwz-work/evidence/h1-tls/transport/tls-eof-contract.md.
The v3 streaming component is independently approved; this is a separate,
inherited shutdown defect required by strict successful TLS client closure.

Create NEW /tmp/uwz-m2-h1-tls-close from frozen v3
/tmp/uwz-m2-h1-tls-transport,1023files,digest
2498622e3a120c6fd0cfee575ad1223b3961ce9e22cbeb9ba39b3d1d59be2cf7.
Preserve v3 untouched. Own only src/core/tcp.zig and existing
src/tests/http1_upload_driver_tests.zig in the new copy. Durable source,
preimages, patches and actual checks go in .uwz-work/evidence/h1-tls/close;
append report at .superpowers/sdd/h1_tls_plan/task-1b-report.md.
No other source/docs/exports/config/ref/pin edits; no agents/commits/fetch.
You are not alone; keep source edits and compilation serialized.

Existing begin_tls_shutdown publishes tls_shutdown_started before SSL_shutdown;
WANT_WRITE is tolerated but never retried. Keep graceful intent through real
output progress, retry first-stage shutdown under existing lifetime protection,
and permit graceful physical close only after first-stage success and BIO/ring
drain. Do not wait for the reciprocal peer alert. Preserve direct intentional
abort semantics for failed begin/end error and real native failures.

Do not infer alert success from local handshake_done: pinned SSL_shutdown may
return1 without an alert while SSL_in_init, including accepted early data.
Inspect actual state. If complete early-data handling requires broader protocol
or stored-state changes, report the concrete requirement before adding them.
No new field/layout/phase is approved; prefer existing graceful intent and TLS
state when sound, with explicit proof of what the existing flag means.

Use actual pure policy operations/caller facts and unchanged healthy suites;
ordinary TLS runtime belongs to Root after independent scoped review. Real
owned memory-BIO API sessions may establish crypto backpressure if needed;
never fabricate SSL objects, inject native results/completions, or run the
stopped experiment. No new native fault/schedule/interleaving/race/crash/leak/
invalid-fd/resource/kernel/registration/panic probes. Reuse original bindings,
c223 override and -j2. Preserve actual reds honestly, full input/source/binary
bindings, scoped checks and eligible compilation. All big artifacts stay /tmp.

Return the frozen diff, covering checks/commands/raw output and limitations for
independent transport/crypto review. No closure or TLS upload acceptance claim
from source/pure tests alone. Strict successful client EOF must not be weakened.
