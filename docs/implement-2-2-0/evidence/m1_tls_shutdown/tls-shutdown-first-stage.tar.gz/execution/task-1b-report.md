# Task 1b: inherited TLS graceful-close correction

Status: v1 READY_FOR_REVIEW; assigned component checks complete. No new native clients, memory-BIO sessions or fault/schedule probes were run. No authenticated TLS EOF runtime claim is made.

## Exact inputs and scope

Independent byte copy `/tmp/uwz-m2-h1-tls-close` starts from approved transport v3 `/tmp/uwz-m2-h1-tls-transport`, 1,023 files, digest `2498622e3a120c6fd0cfee575ad1223b3961ce9e22cbeb9ba39b3d1d59be2cf7`. Every file was hash checked before copying; no symlinks/hardlinks/cache copied. The approved predecessor remains untouched.

Candidate v1 source digest: `b5cf3e793dde126c903abeed8586201274309dfad72fd6252ea54e9411e9aad8`.
Patch SHA-256: `751f35a26135e3b750ee4966b3090efb4bed72682f6fe4a0e97a152d43e989a5`.
Durable evidence: `.uwz-work/evidence/h1-tls/close/{v1-manifest.json,v1.patch,snapshots/v1,preimages}`. Only `src/core/tcp.zig` and `src/tests/http1_upload_driver_tests.zig` changed. No field/layout/API error-set/crypto context/dependency/parser/storage/App changes.

## Behavior and gates

`close_when_drained` is graceful intent, published before shutdown/output processing. The existing `tls_shutdown_started` now means first shutdown stage COMPLETED, with an explicit field comment. `begin_tls_shutdown` sets it only on nonnegative SSL_shutdown result, and never calls SSL_shutdown again after success; it does not enter the peer-alert waiting stage. WANT_WRITE leaves the first stage pending. Other errors abort through the existing private close boundary; no public Response error set grows.

Actual SSL_in_init is checked before shutdown. Root explicitly approved aborting incomplete/early-data handshakes in this bounded fix, because pinned SSL_shutdown can return 1 without emitting an alert there. Replay admission stays unchanged. Authenticated graceful closure for accepted early-data responses remains unimplemented and unverified; it would require broader handshake intake/continuation while graceful intent suppresses ordinary reads. This candidate does not silently label that abort successful EOF.

Each actual positive native write completion first advances the real ring and flushes BIO output, then retries the pending first-stage operation under its existing native frame/delivery borrow. Zero/error native completions retain intentional abort behavior. Native EOF and direct begin/end-error aborts are unchanged.

Both graceful physical-close sites consume the ACTUAL pure `graceful_close_ready`: TLS requires first-stage completion and empty outbound BIO, and both TLS/plaintext require an empty ring and no active write. There is no peer-alert input in this policy. Missing BIO remains an error from existing flush processing before a normal gate can close.

## Pending application output and no-new-wakeup proof

The only application SSL_write site is `write_tls_parts`. It completes each caller-buffer write before returning success, retrying WANT_WRITE with that same input, or takes its existing failure/abort path. There is no retained application SSL_write continuation to resume after the close alert. Graceful intent rejects new application writes. Already accepted application ciphertext retains FIFO order ahead of the alert in BIO/ring.

Pinned BoringSSL `ssl/s3_pkt.cc:133-152` enforces the pending-write retry contract and flushes existing write_buffer before reporting completion. `:161-211` flushes/serializes pending handshake data and prepends the pending flight before sealing the new alert record. `:219-232` returns success only after flushing that record. `:336-397` schedules/retries alert_dispatch, and `ssl_lib.cc:1017-1085` retries it across SSL_shutdown calls. Thus first-stage success also accounts for internal TLS output preceding the alert; external BIO/ring drainage completes its ownership. No private BoringSSL state access or inferred SSL_want ownership is used. A first-stage memory-BIO write can block only on output; unexpected WANT_READ is fatal here rather than creating an input wait that close intent cannot satisfy.

TLS graceful `end_write_batch` chooses actual native arm instead of synchronous flushing, including after nested batch holds. This matters because unchanged `tcp_file.try_direct_flush` otherwise closes immediately when its ring empties under close intent, without considering a pending alert/BIO. The TCP-only gate prevents reaching that direct-close path while TLS graceful intent exists; plaintext and ordinary keepalive batching keep their original choice.

Actual remaining direct-flush sites were audited:

- `tcp_file.enqueue_plain_parts` capacity fallback is unreachable from shutdown BIO draining: `flush_tls_out` limits each copy to current free ring space, and no application callback occurs between that bound and enqueue. A full ring stops the BIO loop.
- `write_tls_parts` capacity fallback cannot begin a new application write after intent, because `tcp_file.write_data_parts` rejects `close_when_drained`; graceful close is not invoked in the synchronous SSL_write loop.
- `try_direct_send` rejects TLS unconditionally.
- `start_write` only gates batch depth then calls real `arm_write`; it cannot synchronously consume ciphertext. `upload_tail` chooses real arm for saved pending work or start_write otherwise. Neither calls direct flush.
- `close_after_flush` explicitly arms TLS output after its incomplete close gate, even inside a batch. `arm_write` retains the existing native frame/cancel/retirement gates and pending-work flag. Already active output supplies the wakeup; otherwise queued output becomes a real send or remains pending until the existing retirement tail can arm it. The native completion retries shutdown after positive progress. No synthetic callback or new stored flag exists.

WANT_WRITE on the fixed memory BIO leaves outbound bytes in BIO or ring; a successful flush cannot remove them from both without an actual queued/native transfer. While graceful intent is active, batch cleanup cannot synchronously erase that last event. Every retry either completes the alert, retains bounded output for a later actual completion, or aborts on error. No arbitrary retry loop/cap or additional allocation was added.

## TDD and checks

`close-red` digest `8f61560105669c0b1404bd6deb6e2f24c1e270157175d5229a1bc8a4e591b227` extracts the actual predecessor ring-only close rule into the production-consumed predicate. It compiles and executes **28 passed / 2 failed**, proving missing first-stage and BIO ownership gates. The two failures are actual caller-fact tests, not declaration failure or fabricated SSL/native state. The remaining added test covers completed stage, queued/inflight output and plaintext compatibility. Existing 27 driver tests remain intact.

`driver.py` captures full compiler argv, source/input/compiler/archive/override/binary identities, environment, exit status and raw output. Original native/foreign bindings, immutable 93-file c223 override, pinned BoringSSL and existing native archives are reused; each compiler invocation uses -j2. All source changes precede frozen checks. Formatter preparation is an intentional pre-freeze mutation, not immutable test evidence.

Final frozen-v1 results: **30/30 Debug, 30/30 ReleaseSafe, unchanged App 31/31, unchanged healthy TLS 3/3**. Full central semantic compilation passed for native, aarch64-macos and x86_64-windows-gnu. fmt --check, conventions, release version (2.1.6), graph refresh and source audit all passed. No full isolated native central suite was executed.

Launcher prefix: `python3 .uwz-work/evidence/h1-tls/close/driver.py`. Each corresponding JSON/log preserves expanded exact argv/status/raw output and source/input/binary hashes:

| Arguments | Outcome |
| --- | --- |
| `test close-red src/tests/http1_upload_driver_tests.zig Debug`; `run close-red` | compile 0; run 1, 28 pass / 2 fail |
| `test close-v1-debug src/tests/http1_upload_driver_tests.zig Debug`; `run close-v1-debug` | compile/run 0, 30/30 |
| `test close-v1-safe src/tests/http1_upload_driver_tests.zig ReleaseSafe`; `run close-v1-safe` | compile/run 0, 30/30 |
| `central central-v1-native native` | 0, semantic only |
| `central central-v1-macos aarch64-macos` | 0, semantic only |
| `central central-v1-windows x86_64-windows-gnu` | 0, semantic only |
| `test app-v1-safe src/tests/body_app_tests.zig ReleaseSafe`; `run app-v1-safe ordinary` | compile/run 0, 31/31 |
| `test healthy-tls-v1-safe src/tests/main.zig ReleaseSafe 'tls echo:'`; `run healthy-tls-v1-safe ordinary` | compile/run 0, 3/3 |
| `command fmt-check-v1 /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check src builds examples tests fuzz` | 0 |
| `command conventions-v1 sh scripts/check_conventions.sh` | 0 |
| `command version-v1 sh scripts/check_release_version.sh` | 0 |

`python3 .uwz-work/evidence/h1-tls/close/graph_check_v1.py` and `audit_v1.py` both exited 0. Graphify refreshed an independent exact source copy under `/tmp/uwz-m2-h1-tls-close-artifacts/graph-source-v1`; sequential fallback succeeded after parallel extraction was unavailable. Final audit verifies 1,023 files, unchanged canonical modules including tcp_upload, and identical TCP stored fields after stripping comments (the flag comment is the only field-block change). Manual diff review found no added allocator call. Approved predecessor v3 was re-hashed unchanged. All final compiler/runtime checks retained source digest `b5cf3e79...` before and after; only pre-freeze formatter preparation changed source intentionally. Healthy App/TLS runtime used the already authorized unsandboxed io_uring environment.

## Limits

Independent scoped transport/crypto review must precede Root's ordinary TLS upload/strict EOF clients. Pure tests and unchanged healthy clients cannot establish output-pressure shutdown behavior or authenticated EOF for new enabled clients. Accepted early-data graceful EOF remains outside this fix. Native timing, broader fault/liveness, release/sanitizer/native-Windows and maintained dependency adoption gates remain open and Root-owned.
