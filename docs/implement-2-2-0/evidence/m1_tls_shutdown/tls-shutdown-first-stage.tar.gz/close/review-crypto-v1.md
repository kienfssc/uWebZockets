# Scoped TLS close correction review v1

Verdict: the concrete source addresses the inherited missing-close-notify retry
finding. No new actionable crypto/TLS or lifetime finding identified in this
scoped diff. Ready for Root's strict ordinary TLS EOF/runtime validation; no
authenticated EOF runtime claim follows from this review.

Reviewed BASE `2498622e3a120c6fd0cfee575ad1223b3961ce9e22cbeb9ba39b3d1d59be2cf7`
to HEAD `b5cf3e793dde126c903abeed8586201274309dfad72fd6252ea54e9411e9aad8`
in `/tmp/uwz-m2-h1-tls-close`, Task1b brief/report, actual patch/source and
pinned BoringSSL ssl_lib.cc/s3_pkt.cc. Independently read patch SHA-256
`751f35a26135e3b750ee4966b3090efb4bed72682f6fe4a0e97a152d43e989a5`.
Only this report was written; no builds, runtime/probes, source edits or
dependency/ref operations were performed.

## Finding disposition

begin_tls_shutdown now commits tls_shutdown_started only after nonnegative
SSL_shutdown. WANT_WRITE leaves first-stage work pending; positive native output
completion flushes external ciphertext and re-enters the pending first stage.
The completed flag prevents a later second-stage reciprocal-alert wait. Actual
SSL_in_init rejects the pinned silent-success case before SSL_shutdown, using
Root's explicitly approved abort policy for incomplete/early-data handshakes.
Unexpected WANT_READ or other shutdown errors abort rather than waiting for an
input event that graceful intent suppresses.

Both normal TCP graceful-close sites require actual first-stage success, empty
outbound BIO, empty ring and no active send. Plaintext retains ring/inflight
semantics. Graceful intent is established before processing shutdown output,
preventing new application writes. Successful write_tls_parts completes caller
input before returning, so the scoped normal-success path does not switch a
pending caller-buffer SSL_write into an alert write.

Pinned ssl_lib.cc:1017-1085 retries alert_dispatch on successive SSL_shutdown
calls. s3_pkt.cc:133-152 requires consistent pending writes and completes the
internal write buffer; :161-232 orders finite handshake output before the alert
and reports alert write success after internal flushing; :336-397 retains and
retries alert_dispatch. The new flag records that first-stage completion rather
than merely intent. External BIO/ring gates then preserve the remaining bytes.

The TCP-only batch change prevents TLS graceful intent reaching tcp_file's
ring-only synchronous direct-close tail. Shutdown flush bounds each enqueue by
actual ring free space, so its enqueue capacity fallback cannot independently
invoke that direct flush. close_after_flush explicitly arms queued TLS output;
existing active sends or write_resume_pending/retirement tails preserve the next
real completion. Neither start_write nor upload_tail directly drains ciphertext
synchronously. This closes the reviewed missing-retry/wakeup gap without a new
field or fabricated event.

The close_after_flush delivery borrow and native write callback frame remain
held across shutdown retries, BIO flushes, batch handling and close gates.
Deferred claim_close still owns SSL/BIO destruction after delivery, frame, ACK
and retirement obligations drain. No new access follows a potentially final
owned close tail in the changed code. Direct failed-begin/end-error abort paths
and their terminal/quota ownership remain unchanged.

## Evidence and explicit limits

Task1b records an actual policy red (28 pass, two fail), 30/30 Debug and
ReleaseSafe, unchanged App 31/31 and healthy TLS 3/3, three-target semantic
compilation and formatting/conventions/version/source checks. Those checks were
not rerun here and do not establish output-pressure close-notify execution.

Root still needs strict ordinary TLS clients with suppress_ragged_eofs=False,
including successful normal/output-pressure graceful closure and enabled upload
completion. Intentional output aborts remain separate terminal outcomes.
Authenticated graceful EOF for accepted early-data responses remains unsupported
by the approved policy; no handshake intake/continuation or replay-policy change
was added. Combined sanitizers/full project gates and native Windows runtime
acceptance remain outstanding. No native timing/global-liveness claim is made.
