# Task5e3b2 completion before independent review

Root read the entire initial report, actual pause_cases.py/test_pause.py,
adapter/cases/import diff and retained proof. Read handling-reports as needed;
this is a concrete narrower completion of reported proof gaps, not a repeated
unchanged assignment. Preserve the existing implemented schedules.

## Source-backed identity ruling

The initial brief's instruction to derive token identity/generation from an
observed pause record cannot be implemented against the immutable fixture.
formatting.zig:5..22 emits tag/callback/terminal data, with no token/index/
generation. pause.zig:111..137 resolves the path's tag to its internally retained
record.token; begin43..75 owns slot generation and token assignment. Root has
read these exact sources. The binding contract is authenticated tag routing
and record validation, plus unchanged other records during stale controls.
Never invent/expose a client token generation, assume generation1 or mutate
the fixture. This ruling corrects the brief's unsupported requirement; it
does not relax model validation or the later producer-binding generation proof.

Prove a mismatched observed pause tag is rejected before a control request
is serialized, and retain actual control/tag/path ordering and unchanged
other-record checks. A focused pure negative is sufficient; no native proof.

## Complete the bounded serialization proof

Check each actual emitted DATA frame immediately against a bounded ordinal
contract, without a retained frame history:
partial_pause emits (8192,END=false) then (4097,END=true);
final_pause emits (32,true); begin_pause_empty emits (0,true);
control_one and control_two each emit (32,true). Preserve independent exact
payload digest, stream association, frame/END counts and paused checkpoint
ordering. Check decoded request header multiplicity as well as values, rather
than discarding duplicates into a dict. Preserve all specified request counts.
Qualify any deliberate wrong-size/END sensitivity control honestly, never as
a pre-implementation RED. Do not invent a behavior change just to create a RED.

The existing selection RED is genuine pre-change rejection of a newly
supported API selection. Preserve and describe that narrow behavior. It is
not a pre-change serialized schedule proof; the report must not call it one.
New independent proofs may pass first run. The existing premature-response
negative remains important concrete path coverage.

Correct cases.py's stale four-case module description while touching it.
No adapter/core/model/fixture behavior or bounds should change for these proof
additions. If a real source defect is found, report the failing pure call and
capture genuine RED/GREEN; do not bypass the seam.

## Capture unambiguous final proof and source

Existing aggregate text logs preserve stdout/failure history but do not retain
separate per-command exits/stderr. For the final amended source, capture each
of these relevant commands once in normal and optimized modes, using the same
pinned environment/-B -S: test_pause, test_selection, test_adapter, test_ready,
test_async, test_negative, test_time, test_large, test_shared, test_imports.
Each command needs distinct durable stdout, stderr and exit files under new
evidence/b2/completion/. Keep old logs/snapshot unchanged and qualified.
These20 checks cover the amended dispatch/primary/held seams and new proof;
this recapture addresses missing outcome evidence, not a broad native rerun.

Snapshot all14 directly owned modules after the last edit, with a current
hash map and comparison to B1 showing the exact changed/new modules. Update
the complete report with commands/raw outcomes, actual new negative behavior,
source identity, this ruling and remaining facts. Do not overwrite earlier
history or claim native FIFO/callback execution. All original ownership,
no-native/no-agents/no-Git limits remain unchanged. No uncovered reusable
helper/recorder; keep main guards and actual inert/AST coverage current.

Return DONE or exact remaining concerns only after this concrete completion.
Root audits source/outcomes then dispatches fresh independent review.
