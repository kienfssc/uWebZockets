# Task5e3b2: four pause and control schedules

This is the next source/pure-codec implementation unit of the unchanged
Task5e3b all40 plan. B1 is reviewed/published/pushed at
9a4d44613a728727808518767c9d1b61d06ca37a. Its explicit-hook adapter and four
public/large schedules are earned reusable code, not a framework to rewrite.
Read task-5e3b-release-addendum.md and its linked original brief for binding
global interfaces, no-native restrictions and all40/default acceptance.

## Ownership and immutable inputs

Own the new b2 schedules/tests and the minimal necessary changes to adapter.py,
cases.py and test_imports.py in the existing combined-cases directory. Preserve
all B1 behavior/proof and earlier snapshots. Own evidence/b2/ there and this
plan's task-5e3b2-report.md. No public delivery/Git edits; Root owns publication.
You are not alone; do not revert or edit others' work. No agents or external
model CLI. One implementation owner at a time.

Use the exact model/catalogue in /tmp/uwz-task5e1-contract-v3 and v9 core in
/tmp/uwz-task5e3a-snapshot-v9/source unchanged. Current B1 source identities are
in task-5e3b1-root-fix-1-audit.json and its committed public manifest. The
combined fixture source-only routes/schemas are in
/tmp/uwz-task5e2-Fix1Final2/fixture. Retained final pause/control contracts are
.uwz-work/evidence/h2-streaming/integration-owned/pause-control/fix1/profile.zig
and run_live.py; their authenticated hashes are in task-5e3b-input-audit.json.
Read those as source only. Do not execute their native/old live entrypoints.
Keep task-5e-barrier-source-handoff.md and accepted combined architecture;
do not repeat architecture/source mapping as a substitute for implementation.

## Required schedules and exact model counts

Implement these four IDs, matching their actual final fixture endpoints,
methods, query fields, headers, payloads, response/reset expectations and action
order. Import the existing validators and payload generator; no second model.

| Case | Heads J | Small C | Request flow R | Persistent tags |
| --- | ---: | ---: | ---: | --- |
| partial_pause | 7 | 7 | 12289 | partial_pause |
| final_pause | 6 | 6 | 32 | final_pause |
| begin_pause_empty | 6 | 6 | 0 | begin_pause_empty |
| control_rules | 20 | 20 | 64 | control_one, control_two |

- Partial pause sends the first8192 bytes, observes accepted7/paused, sends
  the remaining4097 with END, observes the same paused record through the
  finite same-connection barrier, then resumes and verifies FIFO completion.
- Final pause accepts all32 bytes with END but must not invoke end/emit final
  response before the explicit resume. Prove the paused observation and final
  completion through the same canonical connection path.
- Begin pause uses HEADERS followed by an empty DATA with END. Prove begun/
  paused with no chunk/end callback before resume, then exact empty completion.
- Control rules completes the two32-byte records and preserves the source's
  callback-active, not-paused, expired/stale-control error/status contracts,
  metadata/identity checks and successful control transitions. Derive token
  identity from the observed record; never assume an initial generation of1.
  Retain all specified20 requests and their exact source order.

Use the approved wire seam exactly once for every serialized action and
observation. No alternate parser, direct codec bypass, replayed aggregate
refund, speculative API, model/core/fixture mutation, new budget/deadline or
fake successful unsupported handler. Keep fresh caller-owned integer time at
the existing action/read/drain/final boundaries and inherited deadlines.
Flush preceding actions before one authoritative same-connection observation;
fail on mismatch, no retry/poll loop. Required pauses must explicitly reject
END/completion before resume, not merely compare a final successful record.
Keep records, DATA spans and capture bounded; no per-frame/read history.

Extend explicit dispatch to the earned eight-case subset only. Remaining32
unsupported IDs must fail before actions. The full40 default, aggregate final
acceptance and native matrix remain later required work; do not silently treat
this subset as full success. Cover a valid selected-before sequence sharing a
synthetic app across fresh connection contexts so prior metrics are retained.

## Proof and handoff

Use focused behavior-first RED/GREEN with pinned Python3.14.2 -B -S, public
in-memory codecs and caller-owned pure hooks. Capture the actual new-behavior
RED(s), intermediate failures and final normal/-O covering outcomes durably
under evidence/b2. Never classify missing files or deliberate mutations as
behavioral pre-fix RED. Re-run only tests affected by the new/changed seams;
include relevant B1 regression coverage if adapter/cases changes affect it.
Keep test_imports inventory current and actually prove every authored helper
silent/inert with empty/foreign argv and rejecting effect doubles. No classes,
inheritance/custom exception classes/assert proof statements, hidden mutable
globals, dead code, or nesting beyond3 control-flow levels.

No actual clock, native build/server, socket, SSLContext, TLS/close, subprocess
ownership, transfer, descriptor, kernel, fault/cancel/scheduling/race/panic/leak
experiment is released. Pure serialized control requests/synthetic responses
are within scope; stopped native experiments remain stopped. If an actual
immutable seam prevents a required behavior, report the smallest failing pure
call and continue independent cases without bypassing or weakening it.

Retain a small immutable final source snapshot/hash inventory. Write the full
report with changed APIs/files, exact source bindings, commands/raw outcomes,
new-behavior failures, final identities, self-review and precise remaining
facts. Append a short parent-report note; parent stays incomplete. Return only
DONE/concerns/report location/short verification summary. Root independently
reviews before publication or the next implementation unit.
