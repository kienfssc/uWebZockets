"""Independent vectors and hostile inputs for the pure combined contract."""
import copy
import hashlib
import catalogue
import model


def check(condition, message):
    if not condition:
        raise ValueError(message)


def rejects(call):
    try:
        call()
    except ValueError:
        return
    raise ValueError('invalid model input accepted')


def observed(expected):
    rows = copy.deepcopy(expected)
    for item in rows.values():
        if item['bytes']:
            item['chunks'] = max((item['bytes'] + 8191) // 8192,2 if item['chunk_errors'] or item['invalid_progress'] else 1)
            item['max_span'] = min(item['bytes'], 8192)
        if 'callback_checks' in item:
            item['callback_checks'] = 2 * (item['begins'] + item['chunks'])
    return rows


def core_cases():
    payload = bytes(range(251))+bytes(range(6))
    echo = dict(body=payload,bytes=257,sha256='a2c6cad2ffa699b14538231fef914f45d30440389e6f8d79091efba836165a2b',headers=((':status','200'),),ended=True,reset=None,trailers=None,informationals=0)
    model.validate_output_response('ready_buffered',echo)
    ready = model.core_request('ready_buffered')
    check(ready==dict(method='POST',path='/echo',headers=(('content-length','257'),),body=payload,end_stream=False,data_end_stream=True,response_limit=257), 'buffered request contract')
    check(hashlib.sha256(payload).hexdigest()==echo['sha256'], 'independent echo digest')
    for key, value in (('body',payload[:-1]+b'x'),('sha256','0'*64),('bytes',256),('bytes',True),('ended',False),('reset',0),('trailers',()),('informationals',1),('headers',((':status','200'),(':status','200'))),('headers',((':status','500'),))):
        rejects(lambda: model.validate_core_response('ready_buffered',dict(echo,**{key:value})))
    delayed = dict(body=b'delayed-ok',bytes=10,sha256='5235430cff06281ef23fabd775a3493bf34fd508219d31ed270ac65ac631ce52',headers=((':status','200'),('Content-Type','text/plain')),ended=True,reset=None,trailers=None,informationals=0)
    model.validate_output_response('async_delayed',delayed)
    check(model.core_request('async_delayed')==dict(method='GET',path='/delayed',headers=(),body=b'',end_stream=True,data_end_stream=None,response_limit=10), 'delayed request contract')
    for key, value in (('body',b'wrong-body'),('sha256','f'*64),('bytes',9),('headers',((':status','200'),)),('headers',((':status','200'),('content-type','application/json'))),('headers',((':status','200'),('content-type','text/plain'),('Content-Type','text/plain'))),('headers',((':status','200'),('content-type','text/plain'),(':status','200'))),('informationals',True),('ended',False)):
        rejects(lambda: model.validate_core_response('async_delayed',dict(delayed,**{key:value})))
    model.validate_core_response('async_delayed',dict(delayed,headers=delayed['headers']+(('x-middleware','retained'),)))
    before = dict(begin=3,end=2,cancel=1,active=0)
    for case in ('ready_buffered','async_delayed'):
        model.validate_core_sink(case,before,dict(before))
        for field in ('begin','end','cancel','active'):
            rejects(lambda: model.validate_core_sink(case,before,dict(before,**{field:before[field]+1})))
        rejects(lambda: model.validate_core_sink(case,dict(before,active=True),dict(before,active=True)))
    rejects(lambda: model.core_request('large_declared'))
    rejects(lambda: model.validate_core_sink('unknown',before,before))
    rejects(lambda: model.validate_core_response('async_delayed',dict(delayed,extra=1)))


def binding_cases():
    producer = dict.fromkeys(model.PRODUCER_NUMBERS,0)
    producer.update(tag='producer_reuse',armed=True,done=False,sha256=model.EMPTY_HASH,binding_index=1,binding_generation=0)
    binding = dict(tag='producer_reuse_next',binding_index=1,binding_generation=1)
    rejects(lambda: model.validate_reuse_binding(producer,binding))
    producer['binding_generation'] = 7
    binding['binding_generation'] = 8
    model.validate_binding_pre_post(('producer_reuse',),binding,dict(binding),producer)
    model.validate_binding_pre_post((),None,model.default_binding(),None)
    model.validate_binding_pre_post(('shutdown_idle',),None,model.default_binding(),None)
    model.validate_binding_pre_post(('stream_file',),None,model.default_binding(),None)
    rejects(lambda: model.validate_output_pre_post((),model.default_outputs(),model.default_outputs(),binding_before=None,binding_after=binding))
    check(model.default_binding()==dict(tag='producer_reuse_next',binding_index=0,binding_generation=0), 'named binding default')
    for after in (dict(binding),dict(model.default_binding(),binding_index=1),dict(model.default_binding(),binding_generation=1),dict(model.default_binding(),binding_index=False)):
        rejects(lambda: model.validate_binding_pre_post(('shutdown_idle',),None,after,None))
    rejects(lambda: model.validate_binding_pre_post((),model.default_binding(),model.default_binding(),None))
    rejects(lambda: model.validate_binding_pre_post(('producer_reuse',),binding,dict(binding,binding_generation=9),producer))
    rejects(lambda: model.validate_binding_pre_post(('producer_reuse',),dict(binding,binding_generation=7),dict(binding,binding_generation=7),producer))
    rejects(lambda: model.validate_binding_pre_post(('producer_reuse',),None,binding,producer))
    rejects(lambda: model.validate_binding_pre_post(('producer_reuse',),binding,binding,None))
    rejects(lambda: model.validate_binding_pre_post(('producer_reuse',),binding,dict(binding,binding_index=True),producer))
    rejects(lambda: model.validate_reuse_binding(dict(producer,binding_index=2),dict(binding,binding_index=2)))
    rejects(lambda: model.validate_binding_pre_post((),None,dict(model.default_binding(),tag='other'),None))


def main():
    binding_cases()
    core_cases()
    rows = model.records(catalogue.CASES, 'after')
    check(len(rows) == 67, 'all persistent records')
    check(model.totals(rows) == (67, 62, 61, 52, 9, 200091500, 0), 'independent full vector')
    before = model.records(catalogue.CASES, 'before')
    check(model.totals(before) == (67, 62, 61, 52, 8, 200091500, 1), 'pre-shutdown vector')
    check(before['shutdown_active']['paused'] and before['shutdown_active']['reason'] is None, 'live paused shutdown')
    check(rows['shutdown_active']['reason'] == 'shutdown', 'shutdown cause')
    check(rows['disconnect']['reason'] == 'peer_closed', 'clean EOF cause')
    check(rows['peer_reset']['reason'] == 'reset' and rows['peer_reset']['bytes'] == 0, 'paused reset')
    check(rows['begin_failure']['attempts'] == 1 and rows['begin_failure']['begins'] == 0 and rows['begin_failure']['cancels'] == 0, 'failed begin rollback')
    check(rows['end_error']['ends'] == 1 and rows['end_error']['end_errors'] == 1 and rows['end_error']['cancels'] == 0, 'end invocation is terminal')
    check(rows['sink_error']['chunk_errors'] == 1 and rows['invalid_progress']['invalid_progress'] == 1, 'distinct errors')
    check(rows['sink_error']['sha256'] == '32bbe378a25091502b2baf9f7258c19444e7a43ee4593b08030acd790bd66e6a', 'accepted prefix hash')
    check(rows['limit_observed_reject']['bytes'] == 32 and rows['limit_observed_reject']['reason'] == 'body_too_large', 'observed limit')
    check(rows['limit_declared_reject']['attempts'] == 0, 'declaration rejected before begin')
    check(rows['early_final_order']['middleware'] == 1 and rows['early_final_order']['attempts'] == 0, 'middleware early final')
    check([rows['reuse_' + str(n)]['stale_resume'] for n in range(9)] == [8,7,6,5,4,3,2,1,0], 'stale generations')
    for selection in ((), ('shutdown_idle',), ('cancel_paused',), ('empty_headers','limit_declared'), ('shutdown_active',)):
        expected = model.records(selection, 'after')
        model.validate_records(selection, 'after', observed(expected))
        touched = {tag for case in selection for tag in catalogue.TAGS[case]}
        for tag, item in expected.items():
            if tag not in touched:
                check(item['bytes'] == 0 and item['attempts'] == 0 and item['chunks'] == 0 and item['max_span'] == 0, 'unused exact defaults')
    partial = model.records(('metadata_helpers','begin_failure_rollback'), 'after')
    check(model.totals(partial) == (3,3,2,2,0,64,0), 'independent partial vector')
    check(partial['metadata_helpers']['helpers_begin'] == 1 and partial['metadata_helpers']['helpers_end'] == 1, 'helper diagnostics retained')
    model.validate_records(catalogue.CASES, 'after', observed(rows))
    bad = observed(rows)
    for field, value in (('bytes', True), ('sha256', 'a' * 64), ('reason', 'none'), ('chunks', 0), ('max_span',8193), ('chunks',model.U64 + 1)):
        changed = copy.deepcopy(bad)
        changed['sink_error'][field] = value
        rejects(lambda: model.validate_records(catalogue.CASES, 'after', changed))
    changed = copy.deepcopy(bad)
    changed['limit_declared'].update(chunks=1,max_span=1)
    rejects(lambda: model.validate_records(catalogue.CASES,'after',changed))
    changed = copy.deepcopy(bad)
    changed['sink_error']['chunks'] = 1
    rejects(lambda: model.validate_records(catalogue.CASES,'after',changed))
    changed = copy.deepcopy(bad)
    changed['metadata_helpers']['helpers_end'] = 0
    rejects(lambda: model.validate_records(catalogue.CASES, 'after', changed))
    changed = copy.deepcopy(bad)
    changed['partial_pause']['callback_checks'] += 1
    rejects(lambda: model.validate_records(catalogue.CASES, 'after', changed))
    changed = copy.deepcopy(bad)
    changed['empty_headers']['extra'] = 1
    rejects(lambda: model.validate_records(catalogue.CASES, 'after', changed))
    rejects(lambda: model.records(('unknown',), 'after'))
    rejects(lambda: model.records((), 'later'))
    rejects(lambda: model.records(('shutdown_active', 'empty_data'), 'after'))
    rejects(lambda: model.records(('empty_data','empty_data'), 'before'))
    legacy = {'tag':'begin_failure','middleware':1,'attempts':1,'begin':0,'end':0,'cancel':0,'failure':1,'accepted':0,'sha256':model.EMPTY_HASH,'active':False,'paused':False,'reason':'none','errors':0,'chunks':0,'max_span':0}
    normalized = model.normalize_legacy('admission', legacy)
    check(normalized['bytes'] == 0 and normalized['begins'] == 0 and normalized['reason'] is None, 'explicit legacy normalization')
    model.validate_legacy(('begin_failure_rollback',), 'after', 'admission', legacy)
    rejects(lambda: model.normalize_legacy('admission',dict(legacy,attempts=True)))
    rejects(lambda: model.normalize_legacy('admission',dict(legacy,reason=None)))
    legacy['bytes'] = 0
    rejects(lambda: model.normalize_legacy('admission', legacy))
    check(model.request_contract('large_declared')['declared'] == 100000000 and model.request_contract('large_undeclared')['declared'] is None, 'declaration preserved')
    check(model.request_contract('limit_observed_recovery')['declared']==32, 'observed rejection recovery declaration')
    check(model.request_contract('limit_declared_reject')['declared'] == 33, 'refused declaration')
    check(model.request_contract('metadata_helpers')['header_entries'][-2:]==(('x-h62','v62'),('host','localhost')), 'initial metadata header values')
    check(model.request_contract('metadata_helpers')['capture_entries'][-1]==('p16','a16'), 'spill capture value')
    check(model.request_contract('metadata_helpers')['headers'] == 66 and model.request_contract('metadata_helpers')['captures'] == 17, 'overflow metadata')
    model.validate_checkpoint('partial_pause', observed(model.records(('partial_pause',),'after'))['partial_pause'], 'complete')
    check(model.checkpoint('partial_pause','paused')['bytes'] == 7, 'pause accepts prefix')
    check(model.checkpoint('final_pause','paused')['bytes'] == 32 and model.checkpoint('final_pause','paused')['ends'] == 0, 'EOF held until resume')
    check(model.checkpoint('begin_pause_empty','paused')['chunks'] == 0, 'empty begin pause')
    pattern = bytes(range(1,252))
    expected_payload = (pattern * 100)[:12289-len(model.SENTINEL)] + model.SENTINEL
    check(model.digest(12289, 0, 12289) == hashlib.sha256(expected_payload).hexdigest(), 'second payload algorithm')
    check(model.digest(100000000,0,100000000) == '190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2', 'large bounded digest')
    check(model.digest(16777313,0,16777313) == 'e5b7e8c5bbad59c7bc86f18236a37661571e972f65c707d7dc1902386ec5e91d', 'producer hash')
    check(model.digest(24659,37,24593) == '8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac', 'file range hash')
    rejects(lambda: model.payload_span(32,0,8193))
    rejects(lambda: model.digest(32,0,33))
    rejects(lambda: model.digest(True,0,0))
    check(catalogue.budgets(catalogue.CASES)['receive_bytes'] == 5288609050, 'whole checked receive bound')
    for case, ceiling in (('large_declared',2600225368),('reuse',17537432),('producer_reuse',17162101),('stream_file',521343),('shutdown_idle',3109464)):
        check(catalogue.case_budget(case)['receive_bytes'] == ceiling, 'literal case receive ceiling: '+case)
    check(catalogue.final_budget(64) == 3065184 and catalogue.final_budget(131070) == 4768262, 'remaining debt final bounds')
    check(catalogue.budgets(('large_declared',))['receive_bytes'] == 2600225368 + 4768262, 'partial terminal debt scope')
    check(catalogue.budgets(('shutdown_active',))['final_collections'] == 1, 'no double final')
    check(catalogue.case_budget('large_declared')['timeout_seconds'] == 180 and catalogue.case_budget('reuse')['timeout_seconds'] == 30, 'deadlines')
    check(catalogue.case_budget('disconnect')['legacy_receive_cap'] == 4096, 'legacy cap preserved')
    rejects(lambda: catalogue.final_budget(131071))
    rejects(lambda: catalogue.receive_bound(1,1,1,1,1,1,True))
    rejects(lambda: catalogue.receive_bound(1,0,1,1,-1,0,0))
    rejects(lambda: catalogue.final_budget(True))
    check(catalogue.case_budget('receive_credit')['receive_calls']==4096, 'receive cap survives work ceiling')
    check(catalogue.budgets(('producer_reuse',))['final_remaining_debt']==128, 'two-stream late debt')
    check(catalogue.budgets(('disconnect',))['final_remaining_debt']==64, 'replacement debt excludes original connection')
    rejects(lambda: catalogue.receive_bound(model.U64,1,1,1,1,1,1))
    producer = dict(tag='producer_reuse',armed=True,done=True,offset=16777313,sha256=model.PRODUCER_HASH,invocations=2,attempts=2050,writes=2049,blocked=1,pending=1,terminal_attempts=1,terminals=1,checks=2,after_reuse=1,errors=0,binding_index=1,binding_generation=17)
    model.validate_producer(producer,16777313,after_reuse=True)
    model.validate_reuse_binding(producer,dict(tag='producer_reuse_next',binding_index=1,binding_generation=18))
    rejects(lambda: model.validate_reuse_binding(producer,dict(tag='producer_reuse_next',binding_index=1,binding_generation=2)))
    damaged = dict(producer,checks=1)
    rejects(lambda: model.validate_producer(damaged,16777313))
    file = dict(tag='stream_file',reads=7,requested=24593,returned=24593,read_errors=0,close_calls=1,closed_files=1,invalid_spans=0,min_offset=37,max_end=24630,arms=1,arm_errors=0,transferred=True,caller_owned=False)
    model.validate_file(file,True)
    rejects(lambda: model.validate_file(dict(file,close_calls=2),True))
    model.validate_outputs((),model.default_outputs())
    model.validate_output_pre_post((),model.default_outputs(),model.default_outputs(),binding_before=None,binding_after=model.default_binding())
    outputs = dict(model.default_outputs(),producer_reuse=producer)
    model.validate_output_pre_post(('producer_reuse',),outputs,copy.deepcopy(outputs),binding_before=dict(tag='producer_reuse_next',binding_index=1,binding_generation=18),binding_after=dict(tag='producer_reuse_next',binding_index=1,binding_generation=18))
    changed_outputs = dict(outputs,producer_reuse=dict(producer,after_reuse=2))
    rejects(lambda: model.validate_output_pre_post(('producer_reuse',),outputs,changed_outputs,binding_before=dict(tag='producer_reuse_next',binding_index=1,binding_generation=18),binding_after=dict(tag='producer_reuse_next',binding_index=1,binding_generation=18)))
    rejects(lambda: model.validate_outputs((),dict(model.default_outputs(),stream_file=file)))
    family_vectors = dict(core=(2,2,2,2,0,200000000,0),pause=(5,5,5,5,0,12385,0),admission=(22,19,18,16,2,384,0),credit=(6,5,5,5,0,77921,0),metadata=(1,1,1,1,0,32,0),cancellation=(6,6,6,3,3,110,0),application=(6,6,6,4,2,142,0),lifecycle=(12,12,12,10,2,334,0),output=(7,6,6,6,0,192,0))
    for family, vector in family_vectors.items():
        check(model.totals({tag:item for tag,item in rows.items() if model.SPECS[tag][0]==family})==vector, 'family vector '+family)
    for case in catalogue.CASES:
        selected = model.records((case,),'after')
        model.validate_records((case,),'after',observed(selected))
        check(sum(item['middleware'] for item in selected.values())==len(catalogue.TAGS[case]), 'one-case mapping '+case)
    old = bad['reuse_0']
    current = bad['reuse_8']
    changed = dict(old,stale_resume=old['stale_resume']+1)
    model.validate_stale_control('resume','BodyControlExpired',old,changed,current,current)
    rejects(lambda: model.validate_stale_control('resume','BodyControlExpired',old,dict(changed,bytes=31),current,current))
    rejects(lambda: model.validate_stale_control('resume','ok',old,changed,current,current))
    rejects(lambda: model.validate_stale_control('resume','BodyControlExpired',old,changed,current,dict(current,sha256=model.EMPTY_HASH)))
    model.validate_unchanged_control('BodyNotPaused','BodyNotPaused',bad['control_one'],bad['control_one'])
    rejects(lambda: model.validate_unchanged_control('BodyControlExpired','BodyNotPaused',bad['control_one'],bad['control_one']))
    rejects(lambda: model.digest(100000001,0,0))
    rejects(lambda: model.totals({'a':dict(rows['large_declared'],bytes=model.U64),'b':rows['large_declared']}))
    before_rows = observed(before)
    model.validate_pre_post(catalogue.CASES,before_rows,bad)
    rejects(lambda: model.validate_pre_post(catalogue.CASES,bad,bad))
    metrics = model.metrics(catalogue.CASES,'before')
    check(metrics['buffered_middleware']==666 and metrics['attempts']==62 and metrics['failures']==1 and metrics['active']==1, 'main metrics')
    model.validate_metrics(catalogue.CASES,'before',dict(metrics,slot0_active=False,slot1_active=True))
    rejects(lambda: model.validate_metrics(catalogue.CASES,'before',dict(metrics,slot0_active=True,slot1_active=True)))
    post_metrics = model.metrics(catalogue.CASES,'after')
    model.validate_metrics(catalogue.CASES,'after',dict(post_metrics,slot0_active=False,slot1_active=False))
    rejects(lambda: model.validate_metrics(catalogue.CASES,'after',dict(post_metrics,slot0_active=False,slot1_active=True)))
    check(model.metrics(('shutdown_idle',),'after')['buffered_middleware']==69, 'idle metrics')
    check(catalogue.child_plan(catalogue.CASES)==(('shutdown_idle',),catalogue.CASES[1:]), 'fresh two-child plan')
    check(catalogue.case_budget('begin_pause_empty')['zero_data_frames']==1, 'enumerated empty DATA')
    check(model.EARLY_RESPONSE['bytes']==17 and model.EARLY_RESPONSE['sha256']=='d826bcf95ee8850cecb39accdeb84b32336a0415411938da42da7edcac891da7', 'early separate digest')
    model.validate_output_response('stream_file',dict(bytes=24593,sha256='8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac',end=True,reset=False,content_length=24593))
    rejects(lambda: model.validate_output_response('early_final_order',dict(model.EARLY_RESPONSE,reset=False)))
    print('model checks passed: records, transitions, schemas, hashes, budgets, family evidence')


if __name__ == '__main__':
    main()
