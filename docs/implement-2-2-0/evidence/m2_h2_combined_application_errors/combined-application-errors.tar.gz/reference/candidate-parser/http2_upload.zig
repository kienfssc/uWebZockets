const std = @import("std");
const body = @import("../http/request_body.zig");
const StreamingRequest = @import("../http/streaming_request.zig").StreamingRequest;
const Request = @import("../http/request.zig").Request;
const Response = @import("../http/response.zig").Response;
const server = @import("../http2/server.zig");
const admission = @import("../router/body_admission.zig");
const radix = @import("../router/radix.zig");

/// Borrows include admission and terminal calls, not just accepted chunks.
pub const CallbackPhase = enum { none, begin, chunk, end, cancel, admission };

/// Caller-owned upload bindings; effect adapters supply fresh Responses and controls.
pub fn upload_driver(comptime max_streams: usize) type {
    return struct {
        const Self = @This();
        const Session = server.server_session(max_streams);
        pub const Slot = struct {
            body: body.BodyState = .{},
            owner: *Self,
            definition: ?*const body.BodyRoute = null,
            stream_id: u32 = 0,
            record_index: u16 = 0,
            index: u16,
            pending_header_length: u16 = 0,
            callback_phase: CallbackPhase = .none,
        };

        session: *Session,
        context: *anyopaque,
        admission_target: admission.Target,
        capture_names: [][]const u8,
        capture_values: [][]const u8,
        slots: [max_streams]Slot = undefined,

        /// Bind only at the owner's stable address; capture matrices stay borrowed.
        pub fn bind(self: *Self) void {
            for (&self.slots, 0..) |*slot, index| slot.* = .{ .owner = self, .index = @intCast(index) };
        }

        /// Slot ownership only; callers must separately prove Session and transport quiescence.
        pub fn is_drained(self: *const Self) bool {
            for (&self.slots) |*slot| {
                if (slot.body.phase != .inactive or slot.body.reserved or slot.body.binding != null or
                    slot.body.target != null or slot.callback_phase != .none) return false;
            }
            return true;
        }

        /// Clears request state while retaining token generations and stable associations.
        pub fn reset_drained(self: *Self) error{BodyStateBusy}!void {
            if (!self.is_drained()) return error.BodyStateBusy;
            for (&self.slots) |*slot| {
                const generation = slot.body.generation;
                const owner = slot.owner;
                const index = slot.index;
                slot.* = .{ .owner = owner, .index = index, .body = .{ .generation = generation } };
            }
        }

        /// Read-only selection keeps structural parsing in Session.
        pub fn selects(self: *const Self, request: *const Request) bool {
            if (request.protocol.len != 0) return false;
            const method = radix.HttpMethod.parse(request.method);
            if (method == .options and std.mem.eql(u8, request.path, "*")) return false;
            const route = self.admission_target.router.match(request.path, method) orelse return false;
            return route.body_match != null;
        }

        /// Each event borrows its Response and control target only through return.
        /// BodyState retains the accepted target, never a Response or callback factory.
        pub fn event(self: *Self, input: server.BodyEvent, response: *Response, target: body.BodyControlTarget) !server.BodyEventResult {
            switch (input) {
                .head => |head| return .{ .head = try self.begin(head, response, target) },
                .data => |data| return .{ .data = try self.chunk(data) },
                .end => |end| {
                    const slot = try self.find_slot(end.stream_index, end.stream_id);
                    const terminal = try slot.body.take_end(true, 0);
                    try self.finish_terminal(slot, terminal, response);
                    if (self.session.connection.streams.find(end.stream_id) != null and
                        !response.is_complete() and !self.session.response_started[slot.index]) return error.IncompleteResponse;
                },
                .closed => |closed| {
                    const slot = &self.slots[closed.stream_index];
                    if (slot.stream_id != closed.stream_id) return .done;
                    if (slot.body.request_cancel(closed.reason)) |terminal| try self.finish_terminal(slot, terminal, response);
                    if (closed.final_body_too_large and
                        self.session.connection.streams.find(closed.stream_id) != null and
                        !self.session.response_started[slot.index])
                    {
                        self.restore_headers(slot, response);
                        try refuse(response, .body_too_large);
                    }
                },
            }
            return .done;
        }

        fn begin(self: *Self, head: server.BodyHeadEvent, response: *Response, target: body.BodyControlTarget) !server.BodyHeadResult {
            const slot = &self.slots[head.stream_index];
            if (slot.body.phase != .inactive or slot.body.reserved) return error.BodyStateBusy;
            slot.stream_id = head.stream_id;
            slot.pending_header_length = 0;
            const stride = self.capture_names.len / max_streams;
            const capture_start = @as(usize, head.stream_index) * stride;
            const captures_valid = self.capture_names.len == self.capture_values.len and
                self.capture_names.len % max_streams == 0 and
                stride >= self.admission_target.router.max_route_params -| 16;
            const input = admission.Input{
                .request = head.request,
                .method = radix.HttpMethod.parse(head.request.method),
                .headers = .{ .names = if (head.request.extra_header_names) |names| names[0..head.request.extra_header_count] else &.{}, .values = if (head.request.extra_header_values) |values| values[0..head.request.extra_header_count] else &.{} },
                .captures = if (captures_valid) .{ .names = self.capture_names[capture_start..][0..stride], .values = self.capture_values[capture_start..][0..stride] } else .{ .names = &.{}, .values = &.{} },
                .declared = head.declared,
                .ingress_available = captures_valid and self.session.body_ingress_available(),
                .pending_header_capacity = @min(response.pending_headers.len, self.session.response_header_stride),
                .early_data_forbidden = head.early_data_forbidden,
                .upgrade_intent = false,
            };
            slot.callback_phase = .admission;
            const decision = self.admission_target.resolve(self.admission_target.context, &input, response);
            slot.callback_phase = .none;
            if (self.session.connection.streams.find(head.stream_id) == null) return .final;
            const selected = switch (decision) {
                .stream => |selected| selected,
                .final => return .final,
                .buffered => return error.InvalidBodySelection,
                .reject => |reason| {
                    // Unretainable middleware headers cannot accompany a bounded refusal.
                    if (response.pending_header_length > input.pending_header_capacity) response.pending_header_length = 0;
                    try refuse(response, reason);
                    return .final;
                },
            };
            if (head.request.get_header("expect") != null) {
                const expectation = head.request.get_unique_header("expect") orelse "";
                if (!std.ascii.eqlIgnoreCase(expectation, "100-continue")) {
                    try response.end("417 Expectation Failed", "");
                    return .final;
                }
            }
            const control = admission.reserve_and_arm(self.admission_target.router, selected, &slot.body, target, head.declared) catch |err| {
                if (err == error.BodyAdmissionMissing) return err;
                try refuse(response, if (err == error.BodyTooLarge) .body_too_large else .unavailable);
                return .final;
            };
            slot.definition = selected.definition;
            slot.record_index = selected.record_index;
            slot.pending_header_length = @intCast(response.pending_header_length);
            const offset = @as(usize, slot.index) * self.session.response_header_stride;
            @memcpy(self.session.response_header_storage[offset..][0..slot.pending_header_length], response.pending_headers[0..slot.pending_header_length]);
            const view = StreamingRequest.from_request(head.request);
            slot.callback_phase = .begin;
            const binding = selected.definition.sink.begin(selected.definition.sink.context, &view, control) catch {
                slot.callback_phase = .none;
                if (slot.body.reject_begin()) try self.admission_target.router.release_body_route(slot.record_index);
                if (self.session.connection.streams.find(head.stream_id) != null) try refuse(response, .unavailable);
                return .final;
            };
            slot.callback_phase = .none;
            if (slot.body.accept_begin(binding)) |terminal| try self.finish_terminal(slot, terminal, response);
            return .{ .accepted = binding.readiness };
        }

        fn chunk(self: *Self, data: server.BodyDataEvent) !body.BodyProgress {
            const slot = try self.find_slot(data.stream_index, data.stream_id);
            if (data.fresh) try slot.body.observe(data.bytes.len);
            if (!data.delivery_allowed or slot.body.readiness == .paused) return .{ .consumed = 0, .readiness = .paused };
            try slot.body.start_chunk(data.bytes.len);
            slot.callback_phase = .chunk;
            const progress = slot.definition.?.sink.chunk(slot.body.binding.?.context, data.bytes) catch |err| {
                slot.callback_phase = .none;
                // The Session will send closed after this borrow unwinds.
                slot.body.phase = .active;
                slot.body.offered = 0;
                return err;
            };
            slot.callback_phase = .none;
            _ = slot.body.accept_chunk(progress) catch |err| {
                slot.body.phase = .active;
                slot.body.offered = 0;
                return err;
            };
            return progress;
        }

        fn find_slot(self: *Self, index: u16, stream_id: u32) !*Slot {
            if (index >= max_streams) return error.StreamClosed;
            const slot = &self.slots[index];
            if (slot.stream_id != stream_id) return error.StreamClosed;
            return slot;
        }

        fn restore_headers(self: *Self, slot: *const Slot, response: *Response) void {
            // Keep raw fields separate from the encoded block that replaces their storage.
            const offset = @as(usize, slot.index) * self.session.response_header_stride;
            @memcpy(response.pending_headers[0..slot.pending_header_length], self.session.response_header_storage[offset..][0..slot.pending_header_length]);
            response.pending_header_length = slot.pending_header_length;
        }

        fn finish_terminal(self: *Self, slot: *Slot, action: body.BodyTerminal, response: *Response) !void {
            const sink = slot.definition.?.sink;
            var failure: ?anyerror = null;
            switch (action) {
                .cancel => |cancel| {
                    slot.callback_phase = .cancel;
                    sink.cancel(cancel.binding.context, cancel.reason);
                },
                .end => |binding| {
                    slot.callback_phase = .end;
                    self.restore_headers(slot, response);
                    response.request_body_complete = true;
                    const view = StreamingRequest.from_request(&self.session.requests[slot.index]);
                    sink.end(binding.context, &view, response) catch |err| {
                        failure = err;
                    };
                },
            }
            slot.callback_phase = .none;
            if (slot.body.finish_terminal()) try self.admission_target.router.release_body_route(slot.record_index);
            if (failure) |err| return err;
        }
    };
}

fn refuse(response: *Response, reason: admission.AdmissionRefusal) !void {
    const status: []const u8 = switch (reason) {
        .too_early => "425 Too Early",
        .invalid_query => "400 Bad Request",
        .body_too_large => "413 Content Too Large",
        .unavailable => "503 Service Unavailable",
    };
    try response.end(status, "");
}
