"""Independent bounded lifecycle case expectations; import is inert."""
CASES = ('cancel_ready', 'cancel_paused', 'peer_reset', 'shutdown_idle')
PRIMARIES = CASES[:3]
TAGS = tuple(value for primary in PRIMARIES for value in (primary, primary + '_recovery')) + tuple('spare_%02d' % i for i in range(26))
H32 = '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5'
H7 = '32bbe378a25091502b2baf9f7258c19444e7a43ee4593b08030acd790bd66e6a'
EMPTY = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def selected_tags(selection):
    return {tag for case in selection if case in PRIMARIES for tag in (case, case + '_recovery')}


def expected(tag, selected):
    touched = tag in selected
    recovery = touched and tag.endswith('_recovery')
    primary = touched and not recovery
    peer = tag == 'peer_reset' and primary
    return {'tag': tag, 'middleware': int(touched), 'attempts': int(touched), 'begin': int(touched),
            'end': int(recovery), 'cancel': int(primary), 'failure': 0, 'end_errors': 0,
            'accepted': 32 if recovery else 7 if primary and not peer else 0,
            'sha256': H32 if recovery else H7 if primary and not peer else EMPTY,
            'active': False, 'paused': False, 'reason': 'reset' if peer else 'cancelled' if primary else 'none',
            'metadata_middleware': int(touched), 'metadata_begin': int(touched), 'metadata_end': int(recovery),
            'stale_resume': 2 if primary else 0, 'stale_cancel': 2 if primary else 0, 'errors': 0}


def verify_record(actual, expected_record):
    require(set(actual) == set(expected_record) | {'chunks', 'max_span'}, 'record fields differ')
    for key, value in expected_record.items():
        require(actual[key] == value, 'record %s field %s differs' % (expected_record['tag'], key))
    chunks, span = actual['chunks'], actual['max_span']
    require(type(chunks) is int and type(span) is int and chunks >= 0 and 0 <= span <= 8192, 'chunk bounds')
    require((chunks == 0 and span == 0) if not actual['accepted'] else (chunks > 0 and span > 0), 'chunk evidence')


def execute(api, case):
    require(case in PRIMARIES, 'unsupported case')
    sibling = api['sibling']()
    primary = api['start'](case, 'peer_reset' if case == 'peer_reset' else 'public_cancel')
    api['send'](primary, 7 if case == 'cancel_ready' else 32, False)
    before = api['status'](case)
    expected_bytes = 0 if case == 'peer_reset' else 7
    require((before['begin'], before['accepted'], before['end'], before['cancel'], before['paused']) ==
            (1, expected_bytes, 0, 0, case != 'cancel_ready'), 'preterminal barrier differs')
    if case == 'peer_reset':
        require(before['chunks'] == 0, 'paused peer received chunks')
    api['pending'](primary)
    if case == 'peer_reset':
        operation = api['peer_reset'](primary)
    else:
        operation = api['control']('cancel', case, 'ok')
    terminal = api['status'](case)
    require((terminal['begin'], terminal['end'], terminal['cancel'], terminal['accepted'], terminal['reason'], terminal['active']) ==
            (1, 0, 1, expected_bytes, 'reset' if case == 'peer_reset' else 'cancelled', False), 'server terminal barrier differs')
    terminal_wire = api['finish_terminal'](primary)
    stale_before = [api['control'](name, case, 'BodyControlExpired') for name in ('resume', 'cancel')]
    credit = api['reclaim'](7 if case == 'cancel_ready' else 32)
    sibling_response = api['finish_sibling'](sibling)
    recovery = api['start'](case + '_recovery', 'healthy')
    api['send'](recovery, 32, True)
    response = api['finish_recovery'](recovery)
    verify_record(response, expected(case + '_recovery', {case + '_recovery'}))
    stale_after = [api['control'](name, case, 'BodyControlExpired') for name in ('resume', 'cancel')]
    return {'before': before, 'operation': operation, 'terminal': terminal, 'terminal_wire': terminal_wire,
            'stale_before': stale_before, 'sibling': sibling_response, 'credit': credit,
            'recovery': response, 'stale_after': stale_after}
