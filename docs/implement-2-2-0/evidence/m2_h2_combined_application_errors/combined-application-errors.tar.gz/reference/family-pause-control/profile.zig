const std = @import("std");
const uz = @import("uWebZockets");
const Hash = std.crypto.hash.sha2.Sha256;
const config: uz.ServerConfig = .{
    .max_connections = 8,
    .stream_request_bodies = true,
    .max_request_line_size = 512,
    .max_header_size = 4096,
    .max_header_count = 80,
    .max_body_size = 256,
    .max_h2_body_size = 4096,
    .max_h2_header_block_size = 8192,
    .max_h2_response_header_size = 4096,
    .max_h2_response_header_count = 32,
    .max_route_params = 24,
    .write_queue_size = 65536,
    .enable_dev_log = false,
};
const tags = [_][]const u8{ "partial_pause", "final_pause", "begin_pause_empty", "control_one", "control_two" };
const Record = struct {
    token: ?uz.BodyControl = null,
    hash: Hash = Hash.init(.{}),
    bytes: u64 = 0,
    chunks: u32 = 0,
    max_span: usize = 0,
    attempts: u32 = 0,
    begins: u32 = 0,
    ends: u32 = 0,
    cancels: u32 = 0,
    callback_checks: u32 = 0,
    terminal_checks: u32 = 0,
    errors: u32 = 0,
    active: bool = false,
    paused: bool = false,
};
const Slot = struct { record: ?*Record = null, owner: *State = undefined, index: usize = 0 };
const State = struct { slots: [2]Slot = [_]Slot{.{}} ** 2, records: [5]Record = [_]Record{.{}} ** 5, attempts: u32 = 0, failed: u32 = 0, errors: u32 = 0 };

fn tag_index(tag: []const u8) ?usize {
    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
    return null;
}
fn callback_check(record: *Record, expected: anyerror, terminal: bool) void {
    const token = record.token orelse {
        record.errors += 1;
        return;
    };
    token.@"resume"() catch |err| {
        if (err != expected) record.errors += 1;
        if (terminal) {
            record.terminal_checks += 1;
        } else {
            record.callback_checks += 1;
        }
        check_cancel(record, token, expected, terminal);
        return;
    };
    record.errors += 1;
    check_cancel(record, token, expected, terminal);
}
fn check_cancel(record: *Record, token: uz.BodyControl, expected: anyerror, terminal: bool) void {
    token.cancel() catch |err| {
        if (err != expected) record.errors += 1;
        if (terminal) {
            record.terminal_checks += 1;
        } else {
            record.callback_checks += 1;
        }
        return;
    };
    record.errors += 1;
}
fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const state: *State = @ptrCast(@alignCast(context));
    state.attempts += 1;
    const tag = request.params.get("tag") orelse {
        state.failed += 1;
        return error.MissingTag;
    };
    const index = tag_index(tag) orelse {
        state.failed += 1;
        return error.InvalidTag;
    };
    const record = &state.records[index];
    record.attempts += 1;
    if (record.begins != 0) {
        state.failed += 1;
        return error.DuplicateTag;
    }
    for (&state.slots) |*slot| {
        if (slot.record != null) continue;
        slot.* = .{ .owner = state, .record = record, .index = index };
        record.token = token;
        record.begins += 1;
        record.active = true;
        record.paused = index == 2;
        callback_check(record, error.BodyCallbackActive, false);
        return .{ .context = slot, .readiness = if (record.paused) .paused else .ready };
    }
    state.failed += 1;
    return error.NoFixtureSlot;
}
fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    callback_check(record, error.BodyCallbackActive, false);
    record.max_span = @max(record.max_span, input.len);
    record.chunks += 1;
    const accepted = if (slot.index == 0 and record.bytes < 7) @min(input.len, 7 - @as(usize, @intCast(record.bytes))) else input.len;
    record.hash.update(input[0..accepted]);
    record.bytes += accepted;
    record.paused = (slot.index == 0 and record.bytes == 7) or (slot.index == 1 and record.bytes == 32);
    return .{ .consumed = accepted, .readiness = if (record.paused) .paused else .ready };
}
fn format_record(record: *const Record, tag: []const u8, output: []u8) ![]const u8 {
    var copy = record.hash;
    var digest: [Hash.digest_length]u8 = undefined;
    copy.final(&digest);
    const hex = std.fmt.bytesToHex(digest, .lower);
    return std.fmt.bufPrint(output, "{{\"tag\":\"{s}\",\"accepted\":{d},\"sha256\":\"{s}\",\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"callback_checks\":{d},\"terminal_checks\":{d},\"errors\":{d}}}", .{ tag, record.bytes, hex, record.attempts, record.begins, record.ends, record.cancels, record.chunks, record.max_span, record.active, record.paused, record.callback_checks, record.terminal_checks, record.errors });
}
fn end(context: *anyopaque, _: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    callback_check(record, error.BodyControlExpired, true);
    record.ends += 1;
    record.active = false;
    record.paused = false;
    slot.record = null;
    var output: [1024]u8 = undefined;
    try response.text(try format_record(record, tags[slot.index], &output));
}
fn cancel(context: *anyopaque, _: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse {
        slot.owner.errors += 1;
        return;
    };
    callback_check(record, error.BodyControlExpired, true);
    record.cancels += 1;
    record.active = false;
    record.paused = false;
    slot.record = null;
}
fn health(_: *uz.Request, response: *uz.Response) void {
    response.text("ok") catch |err| std.log.err("health: {}", .{err});
}
fn status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        std.log.err("missing status tag", .{});
        return;
    };
    const index = tag_index(tag) orelse {
        std.log.err("invalid status tag", .{});
        return;
    };
    var output: [1024]u8 = undefined;
    const body = format_record(&state.records[index], tag, &output) catch |err| {
        std.log.err("status formatting: {}", .{err});
        return;
    };
    response.text(body) catch |err| std.log.err("status: {}", .{err});
}
fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        std.log.err("missing control tag", .{});
        return;
    };
    const index = tag_index(tag) orelse {
        std.log.err("invalid control tag", .{});
        return;
    };
    const token = state.records[index].token orelse {
        std.log.err("missing control token", .{});
        return;
    };
    const action = request.get_param("action") orelse {
        std.log.err("missing control action", .{});
        return;
    };
    const outcome = if (std.mem.eql(u8, action, "resume")) blk: {
        token.@"resume"() catch |err| break :blk @errorName(err);
        break :blk "ok";
    } else if (std.mem.eql(u8, action, "cancel")) blk: {
        token.cancel() catch |err| break :blk @errorName(err);
        break :blk "ok";
    } else "invalid";
    if (std.mem.eql(u8, outcome, "ok")) state.records[index].paused = false;
    response.text(outcome) catch |err| std.log.err("control: {}", .{err});
}
pub fn main(init: std.process.Init) !void {
    const certificate = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_CERT") orelse return error.MissingCertificate);
    const key = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_KEY") orelse return error.MissingKey);
    const nonce = init.environ_map.get("H2_PROFILE_NONCE") orelse return error.MissingNonce;
    var state: State = .{};
    var definition: uz.BodyRoute = .{ .sink = .{ .context = &state, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel }, .limits = .{ .max_body_bytes = 100000000, .max_active = 2 }, .middleware_policy = .headers_only };
    {
        var server = try uz.Server.preset(init.io, config).build_https(init.arena.allocator(), certificate, key);
        defer server.deinit();
        _ = try server.route_body(.post, "/upload/:tag", &definition);
        _ = try server.get("/health", health);
        _ = try server.get_context("/status/:tag", &state, status);
        _ = try server.get_context("/control/:action/:tag", &state, control);
        std.log.info("H2_CAPACITY config={f} request_stride={d} h2_bytes={d} h2_stride={d} slab={d} router={d}", .{ std.json.fmt(config, .{}), try config.request_buffer_stride(), try config.h2_session_bytes(), try config.h2_session_stride(), try config.slab_bytes(), try config.router_storage_bytes() });
        try server.listen("127.0.0.1", 28443);
        try server.catch_shutdown_signals();
        std.log.info("H2_READY {s}", .{nonce});
        try server.run();
    }
    for (&state.records, 0..) |*record, i| {
        var output: [1024]u8 = undefined;
        std.log.info("H2_RECORD {s} {s}", .{ nonce, try format_record(record, tags[i], &output) });
    }
    std.log.info("H2_DEINIT {s} attempts={d} failed={d} errors={d} active={any}", .{ nonce, state.attempts, state.failed, state.errors, [_]bool{ state.slots[0].record != null, state.slots[1].record != null } });
}
