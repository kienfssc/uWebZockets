"""Deterministic admission ledger and request sequences; import has no I/O."""
CASES = ('empty_headers', 'empty_data', 'empty_declared', 'limit_declared', 'limit_undeclared',
         'limit_declared_reject', 'limit_observed_reject', 'zero_declared_reject',
         'zero_observed_reject', 'continue_ready', 'continue_paused', 'quota_refuse',
         'begin_failure_rollback', 'shutdown_idle')
TAGS = ('empty_headers', 'empty_data', 'empty_declared', 'limit_declared', 'limit_undeclared',
        'limit_declared_reject', 'limit_declared_recovery', 'limit_observed_reject',
        'limit_observed_recovery', 'zero_declared_reject', 'zero_declared_recovery',
        'zero_observed_reject', 'zero_observed_recovery', 'continue_ready', 'continue_paused',
        'quota_holder_one', 'quota_holder_two', 'quota_refuse', 'quota_recovery_one',
        'quota_recovery_two', 'begin_failure', 'begin_recovery', 'spare_00', 'spare_01',
        'spare_02', 'spare_03', 'spare_04', 'spare_05', 'spare_06', 'spare_07', 'spare_08', 'spare_09')
GROUPS = {
    'empty_headers': ('empty_headers',), 'empty_data': ('empty_data',), 'empty_declared': ('empty_declared',),
    'limit_declared': ('limit_declared',), 'limit_undeclared': ('limit_undeclared',),
    'limit_declared_reject': ('limit_declared_reject', 'limit_declared_recovery'),
    'limit_observed_reject': ('limit_observed_reject', 'limit_observed_recovery'),
    'zero_declared_reject': ('zero_declared_reject', 'zero_declared_recovery'),
    'zero_observed_reject': ('zero_observed_reject', 'zero_observed_recovery'),
    'continue_ready': ('continue_ready',), 'continue_paused': ('continue_paused',),
    'quota_refuse': ('quota_holder_one', 'quota_holder_two', 'quota_refuse', 'quota_recovery_one', 'quota_recovery_two'),
    'begin_failure_rollback': ('begin_failure', 'begin_recovery'),
}
REFUSED = frozenset(('limit_declared_reject', 'limit_observed_reject', 'zero_declared_reject',
                     'zero_observed_reject', 'quota_refuse', 'begin_failure'))
CANCELLED = frozenset(('limit_observed_reject', 'zero_observed_reject'))
EMPTY = frozenset(('empty_headers', 'empty_data', 'empty_declared', 'zero_declared_recovery',
                   'zero_observed_recovery', 'zero_observed_reject'))


def expected(tag, selected, hash_empty, hash_32):
    touched = tag in selected
    refused = touched and tag in REFUSED
    cancelled = touched and tag in CANCELLED
    failed = touched and tag == 'begin_failure'
    accepted = 32 if touched and (not refused and tag not in EMPTY or tag == 'limit_observed_reject') else 0
    attempt = touched and (not refused or cancelled or failed)
    begin = attempt and not failed
    return {'tag': tag, 'middleware': int(touched), 'attempts': int(attempt), 'begin': int(begin),
            'end': int(begin and not cancelled), 'cancel': int(cancelled), 'failure': int(failed),
            'accepted': accepted, 'sha256': hash_32 if accepted else hash_empty, 'active': False,
            'paused': False, 'reason': 'body_too_large' if cancelled else 'none', 'errors': 0}


def selected_tags(selected_cases):
    return {tag for case in selected_cases if case != 'shutdown_idle' for tag in GROUPS[case]}


def verify_record(actual, expected_record):
    for key, value in expected_record.items():
        if actual.get(key) != value:
            raise ValueError('record ' + expected_record['tag'] + ' field ' + key + ' differs')
    if set(actual) != set(expected_record) | {'chunks', 'max_span'}:
        raise ValueError('record fields differ')
    chunks, span = actual['chunks'], actual['max_span']
    if not isinstance(chunks, int) or not isinstance(span, int) or chunks < 0 or span < 0 or span > 8192:
        raise ValueError('invalid chunk statistics')
    if expected_record['accepted'] == 0 and (chunks != 0 or span != 0):
        raise ValueError('unexpected empty record chunk')
    if expected_record['accepted'] > 0 and not (0 < span <= expected_record['accepted'] and chunks > 0):
        raise ValueError('missing accepted chunk')


def wait_accepted_prefix(api, case, stream):
    while True:
        observed = api['status'](case)
        api['pending'](stream)
        if observed['accepted'] == 32 and observed['end'] == 0: return
        if observed['accepted'] > 32 or observed['end'] != 0 or observed['cancel'] != 0: raise ValueError('accepted-prefix barrier differs')
        api['remaining']()


def execute(api, case):
    p32 = api['p32']
    start, finish, send = api['start'], api['finish'], api['send']
    status, metrics, resume = api['status'], api['metrics'], api['resume']
    retained = []
    def wait_active(count):
        while True:
            current = metrics()
            if current['active'] == count: return
            api['remaining']()

    if case in ('empty_headers', 'empty_data', 'empty_declared'):
        stream = start('empty', case, 200, case != 'empty_data', 0 if case == 'empty_declared' else None)
        if case == 'empty_data': send(stream, b'', True)
        finish(stream)
    elif case in ('limit_declared', 'limit_undeclared'):
        stream = start('limit', case, 200, False, 32 if case == 'limit_declared' else None)
        send(stream, p32, True)
        finish(stream)
    elif case in ('limit_declared_reject', 'zero_declared_reject', 'begin_failure_rollback'):
        route = 'empty' if case == 'zero_declared_reject' else 'limit'
        tag = {'begin_failure_rollback': 'begin_failure'}.get(case, case)
        length = 1 if route == 'empty' else (32 if tag == 'begin_failure' else 33)
        stream = start(route, tag, 503 if tag == 'begin_failure' else 413, False, length, expect=True, reset=True)
        finish(stream, keep=True)
        retained.append(stream)
        recovery = {'begin_failure_rollback': 'begin_recovery', 'zero_declared_reject': 'zero_declared_recovery',
                    'limit_declared_reject': 'limit_declared_recovery'}[case]
        good = start(route, recovery, 200, route == 'empty', None if route == 'empty' else 32)
        if route != 'empty': send(good, p32, True)
        finish(good)
    elif case in ('limit_observed_reject', 'zero_observed_reject'):
        route = 'limit' if case == 'limit_observed_reject' else 'empty'
        stream = start(route, case, 413, False, None, reset=True)
        if route == 'limit':
            send(stream, p32, False)
            wait_accepted_prefix(api, case, stream)
        send(stream, b'x', False)
        finish(stream, keep=True)
        retained.append(stream)
        recovery = 'limit_observed_recovery' if route == 'limit' else 'zero_observed_recovery'
        good = start(route, recovery, 200, route == 'empty', None if route == 'empty' else 32)
        if route == 'limit': send(good, p32, True)
        finish(good)
    elif case in ('continue_ready', 'continue_paused'):
        stream = start('limit', case, 200, False, 32, expect=True, info=1)
        api['wait_info'](stream)
        send(stream, p32, True)
        if case == 'continue_paused':
            observed = status(case)
            if observed['accepted'] != 0 or observed['chunks'] != 0 or observed['end'] != 0 or not observed['paused']:
                raise ValueError('paused barrier differs')
            api['pending'](stream)
            resume(case)
        finish(stream)
    elif case == 'quota_refuse':
        holders = [start('upload', tag, 200, False, 32) for tag in ('quota_holder_one', 'quota_holder_two')]
        wait_active(2)
        refused = start('upload', 'quota_refuse', 503, False, 1, expect=True, reset=True)
        finish(refused, keep=True)
        retained.append(refused)
        for stream in holders: send(stream, p32, True)
        for stream in holders: finish(stream)
        wait_active(0)
        recoveries = [start('upload', tag, 200, False, 32) for tag in ('quota_recovery_one', 'quota_recovery_two')]
        wait_active(2)
        for stream in recoveries: send(stream, p32, True)
        for stream in recoveries: finish(stream)
        wait_active(0)
    else:
        raise ValueError('unsupported case')
    api['health']()
    for stream in retained: api['retire'](stream)
