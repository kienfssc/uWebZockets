const std = @import("std");
const uz = @import("uWebZockets");
const Hash = std.crypto.hash.sha2.Sha256;
const config: uz.ServerConfig = .{
    .max_connections = 8,
    .stream_request_bodies = true,
    .max_request_line_size = 512,
    .max_header_size = 4096,
    .max_header_count = 80,
    .max_body_size = 256,
    .max_h2_body_size = 4096,
    .max_h2_header_block_size = 8192,
    .max_h2_response_header_size = 4096,
    .max_h2_response_header_count = 32,
    .max_route_params = 24,
    .write_queue_size = 65536,
    .enable_dev_log = false,
};
const tags = [_][]const u8{
    "empty_headers",          "empty_data",              "empty_declared",         "limit_declared",          "limit_undeclared",
    "limit_declared_reject",  "limit_declared_recovery", "limit_observed_reject",  "limit_observed_recovery", "zero_declared_reject",
    "zero_declared_recovery", "zero_observed_reject",    "zero_observed_recovery", "continue_ready",          "continue_paused",
    "quota_holder_one",       "quota_holder_two",        "quota_refuse",           "quota_recovery_one",      "quota_recovery_two",
    "begin_failure",          "begin_recovery",          "spare_00",               "spare_01",                "spare_02",
    "spare_03",               "spare_04",                "spare_05",               "spare_06",                "spare_07",
    "spare_08",               "spare_09",
};
const Record = struct {
    token: ?uz.BodyControl = null,
    hash: Hash = Hash.init(.{}),
    bytes: u64 = 0,
    chunks: u32 = 0,
    max_span: usize = 0,
    middleware: u32 = 0,
    attempts: u32 = 0,
    begins: u32 = 0,
    ends: u32 = 0,
    cancels: u32 = 0,
    failures: u32 = 0,
    errors: u32 = 0,
    active: bool = false,
    paused: bool = false,
    reason: ?uz.BodyCancelReason = null,
};
const Slot = struct { record: ?*Record = null, owner: *State = undefined, index: usize = 0 };
const State = struct {
    slots: [2]Slot = [_]Slot{.{}} ** 2,
    records: [32]Record = [_]Record{.{}} ** 32,
    buffered_middleware: u32 = 0,
    errors: u32 = 0,
};
fn tag_index(tag: []const u8) ?usize {
    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
    return null;
}
fn account_body_head(state: *State, request: *const uz.Request) void {
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    if (index >= 22) {
        state.errors += 1;
        return;
    }
    state.records[index].middleware += 1;
}
fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
    const state: *State = @ptrCast(@alignCast(context));
    if (std.mem.startsWith(u8, request.path, "/upload/") or std.mem.startsWith(u8, request.path, "/limit/") or std.mem.startsWith(u8, request.path, "/empty/")) {
        account_body_head(state, request);
    } else state.buffered_middleware += 1;
    response.append_header("X-Middleware", "retained") catch {
        state.errors += 1;
        return .stop;
    };
    return .continue_dispatch;
}
fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.params.get("tag") orelse {
        state.errors += 1;
        return error.MissingTag;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return error.InvalidTag;
    };
    if (index >= 22) {
        state.errors += 1;
        return error.SpareTag;
    }
    const record = &state.records[index];
    record.attempts += 1;
    if (record.attempts != 1 or record.middleware != 1) {
        record.errors += 1;
        record.failures += 1;
        return error.DuplicateTag;
    }
    if (index == 20) {
        record.failures += 1;
        return error.DeliberateBeginFailure;
    }
    for (&state.slots) |*slot| {
        if (slot.record != null) continue;
        slot.* = .{ .owner = state, .record = record, .index = index };
        record.token = token;
        record.begins += 1;
        record.active = true;
        record.paused = index == 14;
        return .{ .context = slot, .readiness = if (record.paused) .paused else .ready };
    }
    record.failures += 1;
    record.errors += 1;
    return error.NoFixtureSlot;
}
fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.max_span = @max(record.max_span, input.len);
    record.chunks += 1;
    record.hash.update(input);
    record.bytes += input.len;
    return .{ .consumed = input.len, .readiness = .ready };
}
fn format_record(record: *const Record, tag: []const u8, output: []u8) ![]const u8 {
    var copy = record.hash;
    var digest: [Hash.digest_length]u8 = undefined;
    copy.final(&digest);
    const hex = std.fmt.bytesToHex(digest, .lower);
    const reason = if (record.reason) |value| @tagName(value) else "none";
    return std.fmt.bufPrint(output, "{{\"tag\":\"{s}\",\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"accepted\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":\"{s}\",\"errors\":{d}}}", .{ tag, record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.errors });
}
fn end(context: *anyopaque, _: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.ends += 1;
    record.active = false;
    record.paused = false;
    record.token = null;
    slot.record = null;
    var output: [1024]u8 = undefined;
    try response.text(try format_record(record, tags[slot.index], &output));
}
fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse {
        slot.owner.errors += 1;
        return;
    };
    record.cancels += 1;
    record.reason = reason;
    record.active = false;
    record.paused = false;
    record.token = null;
    slot.record = null;
}
fn health(_: *uz.Request, response: *uz.Response) void {
    response.text("ok") catch |err| std.log.err("health: {}", .{err});
}
fn status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    var output: [1024]u8 = undefined;
    const body = format_record(&state.records[index], tags[index], &output) catch {
        state.errors += 1;
        return;
    };
    response.text(body) catch {
        state.errors += 1;
    };
}
const Totals = struct {
    middleware: u64 = 0,
    attempts: u64 = 0,
    begins: u64 = 0,
    ends: u64 = 0,
    cancels: u64 = 0,
    failures: u64 = 0,
    accepted: u64 = 0,
    active: u32 = 0,
    errors: u64 = 0,
};
fn totals(state: *const State) Totals {
    var result: Totals = .{ .errors = state.errors };
    for (state.records) |record| {
        result.middleware += record.middleware;
        result.attempts += record.attempts;
        result.begins += record.begins;
        result.ends += record.ends;
        result.cancels += record.cancels;
        result.failures += record.failures;
        result.accepted += record.bytes;
        result.errors += record.errors;
        result.active += @intFromBool(record.active);
    }
    return result;
}
fn format_totals(state: *const State, output: []u8) ![]const u8 {
    const t = totals(state);
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"accepted\":{d},\"active\":{d},\"errors\":{d},\"buffered_middleware\":{d},\"slot0_active\":{any},\"slot1_active\":{any}}}", .{ t.middleware, t.attempts, t.begins, t.ends, t.cancels, t.failures, t.accepted, t.active, t.errors, state.buffered_middleware, state.slots[0].record != null, state.slots[1].record != null });
}
fn metrics(context: *anyopaque, _: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    var output: [1024]u8 = undefined;
    const body = format_totals(state, &output) catch {
        state.errors += 1;
        return;
    };
    response.text(body) catch {
        state.errors += 1;
    };
}
fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    const token = state.records[index].token orelse {
        state.errors += 1;
        return;
    };
    if (!state.records[index].paused) {
        state.errors += 1;
        return;
    }
    state.records[index].paused = false;
    token.@"resume"() catch {
        state.errors += 1;
        response.text("error") catch {
            state.errors += 1;
        };
        return;
    };
    response.text("ok") catch {
        state.errors += 1;
    };
}
pub fn main(init: std.process.Init) !void {
    const certificate = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_CERT") orelse return error.MissingCertificate);
    const key = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_KEY") orelse return error.MissingKey);
    const nonce = init.environ_map.get("H2_PROFILE_NONCE") orelse return error.MissingNonce;
    if (nonce.len == 0 or nonce.len > 64) return error.InvalidNonce;
    var state: State = .{};
    const sink: uz.BodySink = .{ .context = &state, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel };
    var upload: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 100000000, .max_active = 2 }, .middleware_policy = .headers_only };
    var limit: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 32, .max_active = 1 }, .middleware_policy = .headers_only };
    var empty: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 0, .max_active = 1 }, .middleware_policy = .headers_only };
    {
        var server = try uz.Server.preset(init.io, config).build_https(init.arena.allocator(), certificate, key);
        defer server.deinit();
        _ = try server.use(&state, middleware);
        _ = try server.route_body(.post, "/upload/:tag", &upload);
        _ = try server.route_body(.post, "/limit/:tag", &limit);
        _ = try server.route_body(.post, "/empty/:tag", &empty);
        _ = try server.get("/health", health);
        _ = try server.get_context("/status/:tag", &state, status);
        _ = try server.get_context("/metrics", &state, metrics);
        _ = try server.get_context("/resume/:tag", &state, control);
        std.log.info("H2_CAPACITY config={f} request_stride={d} h2_bytes={d} h2_stride={d} slab={d} router={d}", .{ std.json.fmt(config, .{}), try config.request_buffer_stride(), try config.h2_session_bytes(), try config.h2_session_stride(), try config.slab_bytes(), try config.router_storage_bytes() });
        try server.listen("127.0.0.1", 28443);
        try server.catch_shutdown_signals();
        std.log.info("H2_READY {s}", .{nonce});
        try server.run();
    }
    for (&state.records, 0..) |*record, i| {
        var output: [1024]u8 = undefined;
        std.log.info("H2_RECORD {s} {s}", .{ nonce, try format_record(record, tags[i], &output) });
    }
    var output: [1024]u8 = undefined;
    std.log.info("H2_DEINIT {s} {s}", .{ nonce, try format_totals(&state, &output) });
}
