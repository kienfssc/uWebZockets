const std = @import("std");
const uz = @import("uWebZockets");

pub const State = struct {
    base: std.Io = undefined,
    vtable: std.Io.VTable = undefined,
    file: ?std.Io.File = null,
    buffer: [8192]u8 = undefined,
    reads: u64 = 0,
    requested: u64 = 0,
    returned: u64 = 0,
    read_errors: u64 = 0,
    close_calls: u64 = 0,
    closed_files: u64 = 0,
    invalid_spans: u64 = 0,
    min_offset: u64 = 24630,
    max_end: u64 = 0,
    arms: u64 = 0,
    arm_errors: u64 = 0,
    transferred: bool = false,
};
pub fn setup(state: *State, io: std.Io, path: []const u8) !void {
    state.base = io;
    state.vtable = io.vtable.*;
    state.vtable.fileReadPositional = read;
    state.vtable.fileClose = close;
    const file = try std.Io.Dir.createFileAbsolute(io, path, .{ .read = true, .exclusive = true });
    state.file = file;
    var offset: usize = 0;
    while (offset < 24659) {
        const n = @min(state.buffer.len, 24659 - offset);
        for (state.buffer[0..n], 0..) |*byte, i| {
            const pos = offset + i;
            const sentinel = "final-upload-sentinel!";
            byte.* = if (pos >= 24659 - sentinel.len) sentinel[pos - (24659 - sentinel.len)] else @intCast(1 + pos % 251);
        }
        try file.writePositionalAll(io, state.buffer[0..n], offset);
        offset += n;
    }
}
fn read(userdata: ?*anyopaque, file: std.Io.File, data: []const []u8, offset: u64) std.Io.File.ReadPositionalError!usize {
    const state: *State = @ptrCast(@alignCast(userdata.?));
    var requested: usize = 0;
    for (data) |slice| requested += slice.len;
    state.reads += 1;
    state.requested += requested;
    state.min_offset = @min(state.min_offset, offset);
    const end = std.math.add(u64, offset, requested) catch std.math.maxInt(u64);
    state.max_end = @max(state.max_end, end);
    if (requested > 8192 or offset < 37 or end > 24630) state.invalid_spans += 1;
    const count = state.base.vtable.fileReadPositional(state.base.userdata, file, data, offset) catch |err| {
        state.read_errors += 1;
        return err;
    };
    state.returned += count;
    return count;
}
fn close(userdata: ?*anyopaque, files: []const std.Io.File) void {
    const state: *State = @ptrCast(@alignCast(userdata.?));
    state.close_calls += 1;
    state.closed_files += files.len;
    state.base.vtable.fileClose(state.base.userdata, files);
}
pub fn arm(state: *State, response: *uz.Response) !void {
    const file = state.file orelse return error.MissingFile;
    state.arms += 1;
    response.stream_file("200 OK", "Content-Type: application/octet-stream\r\n", .{
        .io = .{ .userdata = state, .vtable = &state.vtable },
        .file = file,
        .buffer = &state.buffer,
        .offset = 37,
        .length = 24593,
    }) catch |err| {
        state.arm_errors += 1;
        return err;
    };
    state.file = null;
    state.transferred = true;
}
pub fn cleanup(state: *State) void {
    if (state.file) |file| file.close(state.base);
    state.file = null;
}
pub fn format(state: *const State, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"tag\":\"stream_file\",\"reads\":{d},\"requested\":{d},\"returned\":{d},\"read_errors\":{d},\"close_calls\":{d},\"closed_files\":{d},\"invalid_spans\":{d},\"min_offset\":{d},\"max_end\":{d},\"arms\":{d},\"arm_errors\":{d},\"transferred\":{any},\"caller_owned\":{any}}}", .{ state.reads, state.requested, state.returned, state.read_errors, state.close_calls, state.closed_files, state.invalid_spans, state.min_offset, state.max_end, state.arms, state.arm_errors, state.transferred, state.file != null });
}
