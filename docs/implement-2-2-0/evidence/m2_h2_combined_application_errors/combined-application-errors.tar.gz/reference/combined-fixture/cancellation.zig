const std = @import("std");
const uz = @import("uWebZockets");
const shared = @import("shared.zig");
const Slot = shared.Slot;
const State = shared.State;
const format_record = @import("formatting.zig").format_record;
pub const tags = [_][]const u8{ "cancel_ready", "cancel_ready_recovery", "cancel_paused", "cancel_paused_recovery", "peer_reset", "peer_reset_recovery" };
pub fn tag_index(tag: []const u8) ?usize {
    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
    return null;
}
fn equal(actual: ?[]const u8, expected: []const u8) bool {
    return if (actual) |value| std.mem.eql(u8, value, expected) else false;
}
fn metadata_matches(request: *const uz.StreamingRequest, index: usize) bool {
    var path_storage: [128]u8 = undefined;
    var query_storage: [128]u8 = undefined;
    var target_storage: [256]u8 = undefined;
    const path = std.fmt.bufPrint(&path_storage, "/limit/{s}", .{tags[index]}) catch return false;
    const query = std.fmt.bufPrint(&query_storage, "case={s}", .{tags[index]}) catch return false;
    const target = std.fmt.bufPrint(&target_storage, "{s}?{s}", .{ path, query }) catch return false;
    return std.mem.eql(u8, request.method, "POST") and std.mem.eql(u8, request.path, path) and
        std.mem.eql(u8, request.query, query) and std.mem.eql(u8, request.target, target) and
        equal(request.params.get("tag"), tags[index]) and equal(request.headers.get("x-case"), tags[index]) and
        equal(request.headers.get("content-length"), "32");
}
pub fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
    const state: *State = @ptrCast(@alignCast(context));
    if (std.mem.startsWith(u8, request.path, "/limit/")) {
        const tag = request.get_param("tag") orelse {
            state.errors += 1;
            return .stop;
        };
        const index = tag_index(tag) orelse {
            state.errors += 1;
            return .stop;
        };
        if (index >= 6) {
            state.errors += 1;
            return .stop;
        }
        const record = &state.records[index];
        record.middleware += 1;
        if (metadata_matches(&uz.StreamingRequest.from_request(request), index)) {
            record.metadata_middleware += 1;
        } else record.errors += 1;
    } else state.buffered_middleware += 1;
    response.append_header("X-Middleware", "retained") catch {
        state.errors += 1;
        return .stop;
    };
    return .continue_dispatch;
}
pub fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.params.get("tag") orelse return error.MissingTag;
    const index = tag_index(tag) orelse return error.InvalidTag;
    if (index >= 6) return error.SpareTag;
    const record = &state.records[index];
    record.attempts += 1;
    if (record.attempts != 1 or record.middleware != 1 or !metadata_matches(request, index)) {
        record.errors += 1;
        record.failures += 1;
        return error.InvalidRequest;
    }
    record.metadata_begin += 1;
    for (state.slots) |*slot| {
        if (slot.record != null) continue;
        slot.generation += 1;
        slot.owner = state;
        slot.record = record;
        slot.index = index;
        record.token = token;
        record.begins += 1;
        record.active = true;
        record.paused = index == 4;
        return .{ .context = slot, .readiness = if (record.paused) .paused else .ready };
    }
    record.failures += 1;
    record.errors += 1;
    return error.NoFixtureSlot;
}
pub fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.max_span = @max(record.max_span, input.len);
    record.chunks += 1;
    const consumed = if (slot.index == 2) @min(input.len, 7 - @as(usize, @intCast(record.bytes))) else input.len;
    record.hash.update(input[0..consumed]);
    record.bytes += consumed;
    record.paused = slot.index == 2 and record.bytes == 7;
    return .{ .consumed = consumed, .readiness = if (record.paused) .paused else .ready };
}
pub fn end(context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.ends += 1;
    if (!metadata_matches(request, slot.index)) {
        record.errors += 1;
        record.end_errors += 1;
        record.active = false;
        record.paused = false;
        slot.record = null;
        return error.MetadataMismatch;
    }
    record.metadata_end += 1;
    record.active = false;
    record.paused = false;
    slot.record = null;
    var output: [1024]u8 = undefined;
    const body = format_record(record, tags[slot.index], &output) catch |err| {
        record.end_errors += 1;
        return err;
    };
    response.text(body) catch |err| {
        record.end_errors += 1;
        return err;
    };
}
pub fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse {
        slot.owner.errors += 1;
        return;
    };
    record.cancels += 1;
    record.reason = reason;
    record.active = false;
    record.paused = false;
    slot.record = null;
}
pub fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    const record = &state.records[index];
    const token = record.token orelse {
        state.errors += 1;
        return;
    };
    const operation = request.get_param("op") orelse {
        state.errors += 1;
        return;
    };
    if (std.mem.eql(u8, operation, "cancel") and record.active) {
        token.cancel() catch {
            state.errors += 1;
            return;
        };
        response.text("ok") catch {
            state.errors += 1;
        };
        return;
    }
    if (record.active) {
        state.errors += 1;
        return;
    }
    if (std.mem.eql(u8, operation, "resume")) {
        if (token.@"resume"()) |_| {
            state.errors += 1;
            return;
        } else |err| {
            if (err != error.BodyControlExpired) {
                state.errors += 1;
                return;
            }
        }
        record.stale_resume += 1;
    } else if (std.mem.eql(u8, operation, "cancel")) {
        if (token.cancel()) |_| {
            state.errors += 1;
            return;
        } else |err| {
            if (err != error.BodyControlExpired) {
                state.errors += 1;
                return;
            }
        }
        record.stale_cancel += 1;
    } else {
        state.errors += 1;
        return;
    }
    response.text("BodyControlExpired") catch {
        state.errors += 1;
    };
}
