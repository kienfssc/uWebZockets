const std = @import("std");
const uz = @import("uWebZockets");
const shared = @import("shared.zig");
const Record = shared.Record;
const Slot = shared.Slot;
const State = shared.State;
const format_record = @import("formatting.zig").format_record;
pub const tags = [_][]const u8{ "partial_pause", "final_pause", "begin_pause_empty", "control_one", "control_two" };
pub fn tag_index(tag: []const u8) ?usize {
    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
    return null;
}
fn callback_check(record: *Record, expected: anyerror, terminal: bool) void {
    const token = record.token orelse {
        record.errors += 1;
        return;
    };
    token.@"resume"() catch |err| {
        if (err != expected) record.errors += 1;
        if (terminal) {
            record.terminal_checks += 1;
        } else {
            record.callback_checks += 1;
        }
        check_cancel(record, token, expected, terminal);
        return;
    };
    record.errors += 1;
    check_cancel(record, token, expected, terminal);
}
fn check_cancel(record: *Record, token: uz.BodyControl, expected: anyerror, terminal: bool) void {
    token.cancel() catch |err| {
        if (err != expected) record.errors += 1;
        if (terminal) {
            record.terminal_checks += 1;
        } else {
            record.callback_checks += 1;
        }
        return;
    };
    record.errors += 1;
}
pub fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const state: *State = @ptrCast(@alignCast(context));
    state.attempts += 1;
    const tag = request.params.get("tag") orelse {
        state.failed += 1;
        return error.MissingTag;
    };
    const index = tag_index(tag) orelse {
        state.failed += 1;
        return error.InvalidTag;
    };
    const record = &state.records[index];
    record.attempts += 1;
    if (record.begins != 0) {
        state.failed += 1;
        return error.DuplicateTag;
    }
    for (state.slots) |*slot| {
        if (slot.record != null) continue;
        slot.generation += 1;
        slot.owner = state;
        slot.record = record;
        slot.index = index;
        record.token = token;
        record.begins += 1;
        record.active = true;
        record.paused = index == 2;
        callback_check(record, error.BodyCallbackActive, false);
        return .{ .context = slot, .readiness = if (record.paused) .paused else .ready };
    }
    state.failed += 1;
    return error.NoFixtureSlot;
}
pub fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    callback_check(record, error.BodyCallbackActive, false);
    record.max_span = @max(record.max_span, input.len);
    record.chunks += 1;
    const accepted = if (slot.index == 0 and record.bytes < 7) @min(input.len, 7 - @as(usize, @intCast(record.bytes))) else input.len;
    record.hash.update(input[0..accepted]);
    record.bytes += accepted;
    record.paused = (slot.index == 0 and record.bytes == 7) or (slot.index == 1 and record.bytes == 32);
    return .{ .consumed = accepted, .readiness = if (record.paused) .paused else .ready };
}
pub fn end(context: *anyopaque, _: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    callback_check(record, error.BodyControlExpired, true);
    record.ends += 1;
    record.active = false;
    record.paused = false;
    slot.record = null;
    var output: [1024]u8 = undefined;
    try response.text(try format_record(record, tags[slot.index], &output));
}
pub fn cancel(context: *anyopaque, _: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse {
        slot.owner.errors += 1;
        return;
    };
    callback_check(record, error.BodyControlExpired, true);
    record.cancels += 1;
    record.active = false;
    record.paused = false;
    slot.record = null;
}
pub fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        std.log.err("missing control tag", .{});
        return;
    };
    const index = tag_index(tag) orelse {
        std.log.err("invalid control tag", .{});
        return;
    };
    const token = state.records[index].token orelse {
        std.log.err("missing control token", .{});
        return;
    };
    const action = request.get_param("op") orelse {
        std.log.err("missing control action", .{});
        return;
    };
    const outcome = if (std.mem.eql(u8, action, "resume")) blk: {
        token.@"resume"() catch |err| break :blk @errorName(err);
        break :blk "ok";
    } else if (std.mem.eql(u8, action, "cancel")) blk: {
        token.cancel() catch |err| break :blk @errorName(err);
        break :blk "ok";
    } else "invalid";
    if (std.mem.eql(u8, outcome, "ok")) state.records[index].paused = false;
    response.text(outcome) catch |err| std.log.err("control: {}", .{err});
}
