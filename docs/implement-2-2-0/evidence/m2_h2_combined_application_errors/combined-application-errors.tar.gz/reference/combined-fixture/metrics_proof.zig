const std = @import("std");
const formatting = @import("formatting.zig");
const shared = @import("shared.zig");

fn check(records: []const shared.Record, buffered: u64, slot0: bool, expected: []const u8) void {
    const totals = formatting.sum_records(records, .{ .buffered_middleware = buffered, .slot0_active = slot0 });
    var buffer: [1024]u8 = undefined;
    const actual = formatting.format_totals(totals, &buffer) catch @compileError("metrics formatter failed");
    if (!std.mem.eql(u8, actual, expected)) @compileError("metrics differ from approved model");
}

pub fn prove() void {
    @setEvalBranchQuota(2000000);
    const idle = [_]shared.Record{.{}};
    check(&idle, 69, false, "{\"middleware\":0,\"attempts\":0,\"begins\":0,\"ends\":0,\"cancels\":0,\"failures\":0,\"end_errors\":0,\"chunk_errors\":0,\"invalid_progress\":0,\"errors\":0,\"bytes\":0,\"active\":0,\"paused\":0,\"buffered_middleware\":69,\"slot0_active\":false,\"slot1_active\":false}");
    const terminal = [_]shared.Record{
        .{ .middleware = 1, .attempts = 1, .begins = 1, .cancels = 1, .chunk_errors = 1, .bytes = 7 },
        .{ .middleware = 1, .attempts = 1, .begins = 1, .ends = 1, .bytes = 32 },
    };
    check(&terminal, 77, false, "{\"middleware\":2,\"attempts\":2,\"begins\":2,\"ends\":1,\"cancels\":1,\"failures\":0,\"end_errors\":0,\"chunk_errors\":1,\"invalid_progress\":0,\"errors\":0,\"bytes\":39,\"active\":0,\"paused\":0,\"buffered_middleware\":77,\"slot0_active\":false,\"slot1_active\":false}");
    const active = [_]shared.Record{.{ .middleware = 1, .attempts = 1, .begins = 1, .bytes = 7, .active = true, .paused = true }};
    check(&active, 70, true, "{\"middleware\":1,\"attempts\":1,\"begins\":1,\"ends\":0,\"cancels\":0,\"failures\":0,\"end_errors\":0,\"chunk_errors\":0,\"invalid_progress\":0,\"errors\":0,\"bytes\":7,\"active\":1,\"paused\":1,\"buffered_middleware\":70,\"slot0_active\":true,\"slot1_active\":false}");
    const shutdown = [_]shared.Record{.{ .middleware = 1, .attempts = 1, .begins = 1, .cancels = 1, .bytes = 7 }};
    check(&shutdown, 70, false, "{\"middleware\":1,\"attempts\":1,\"begins\":1,\"ends\":0,\"cancels\":1,\"failures\":0,\"end_errors\":0,\"chunk_errors\":0,\"invalid_progress\":0,\"errors\":0,\"bytes\":7,\"active\":0,\"paused\":0,\"buffered_middleware\":70,\"slot0_active\":false,\"slot1_active\":false}");
}
comptime {
    prove();
}
pub fn main() void {}
