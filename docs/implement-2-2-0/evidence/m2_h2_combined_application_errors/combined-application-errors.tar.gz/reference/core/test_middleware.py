"""Async completion makes no middleware-header guarantee."""
import h2_client
import hpack
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def check():
    protocol = h2_client.new_protocol()
    protocol.data_to_send(amount=8192)
    response = response_credit.new_state()
    response_credit.settings_sent(response, 65535, initial=True)
    request = request_credit.new_state(request_credit.new_case('async_delayed'))
    raw, records, trace = raw_observer.new_state(), {}, {}
    stage = output_stage.new_stage(output_stage.new_case('async_delayed'), 1, 1, 10, 100)
    wire.bind_connection(stage, protocol, raw, request, response, records)
    request_credit.client_settings_sent(request)
    payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                       ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    startup = len(payload).to_bytes(3, 'big') + b'\4\0\0\0\0\0' + payload + b'\0\0\0\4\1\0\0\0\0'
    wire.accept(protocol, startup, records, raw, trace, credit=response, request=request, stage=stage)
    protocol.data_to_send(amount=8192)
    protocol.send_headers(1, [(':method', 'GET'), (':scheme', 'https'),
                              (':authority', 'localhost'), (':path', '/delayed')], end_stream=True)
    request_credit.open_stream(request, 1)
    request_credit.end_request(request, 1)
    response_credit.open_stream(response, 1)
    output_stage.register(stage, 1, 'small', primary=True)
    wire.register(records, raw, 1, 0, 200, 0, 'healthy', stage=stage, credit_policy='manual', middleware_policy='optional')
    protocol.data_to_send(amount=8192)
    block = hpack.Encoder().encode([(':status', '200')])
    packet = len(block).to_bytes(3, 'big') + b'\x01\x05\0\0\0\x01' + block
    wire.accept(protocol, packet, records, raw, trace, credit=response, request=request, stage=stage)
    wire.complete(records, raw, 1)
    print('async middleware policy checks passed')


if __name__ == '__main__':
    check()
