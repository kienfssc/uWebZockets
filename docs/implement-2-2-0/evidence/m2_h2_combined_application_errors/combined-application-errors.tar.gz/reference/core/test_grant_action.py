"""Actual public grants are paired to finite output case policy."""
import h2_client
import output_stage
import model
import raw_observer
import request_credit
import response_credit
import wire


def check():
    protocol = h2_client.new_protocol()
    ledger = response_credit.new_state()
    request = request_credit.new_state(request_credit.new_case('output_pressure_window'))
    stage = output_stage.new_stage(output_stage.new_case('output_pressure_window'), 1, 2, 10, 100)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, ledger, records)
    wire.startup(stage)
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in pairs)
    ack = b'\0\0\0\4\1\0\0\0\0'
    server = len(payload).to_bytes(3, 'big') + b'\4\0\0\0\0\0' + payload
    wire.accept(protocol, server + ack, records, raw, trace, credit=ledger, request=request, stage=stage)
    wire.drain(stage)
    wire.update_settings(stage, 0)
    wire.drain(stage)
    wire.accept(protocol, ack, records, raw, trace, credit=ledger, request=request, stage=stage)
    stream, chunks = wire.start_request(stage, 'GET', 'localhost', '/limit/output_pressure_window', (), True,
                                        role='special', primary=True, held=True, body_limit=16777313,
                                        final_status=200, info_count=0, policy='healthy', mode='hash_only',
                                        expected_sha256=model.PRODUCER_HASH, middleware_policy='required')
    if stream != 1 or not chunks:
        raise RuntimeError('special request differs')
    policy = wire.new_grants(stage)
    wire.grant(protocol, ledger, policy, stage, 1, 8192, 'special')
    if ledger['stream_granted'] != 8192 or len(protocol.data_to_send(amount=8192)) != 13:
        raise RuntimeError('grant action differs')
    try:
        wire.grant(protocol, ledger, policy, stage, 1, 1, 'special')
    except ValueError:
        if ledger['stream_granted'] != 8192 or protocol.data_to_send(amount=8192):
            raise RuntimeError('rejected grant mutated state')
    else:
        raise RuntimeError('incorrect special grant accepted')
    print('bounded codec grant checks passed')


if __name__ == '__main__':
    check()
