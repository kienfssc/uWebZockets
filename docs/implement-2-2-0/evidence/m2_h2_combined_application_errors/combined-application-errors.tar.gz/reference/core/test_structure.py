"""Check authored Python structure and inert imports with rejecting I/O doubles."""
import ast
import contextlib
import pathlib
import socket
import ssl
import sys
from unittest import mock


def check():
    folder = pathlib.Path(__file__).resolve().parent
    paths = sorted(folder.glob('*.py'))
    if not paths:
        raise ValueError('missing sources')
    for path in paths:
        source = path.read_text()
        tree = ast.parse(source, filename=str(path))
        if any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)):
            raise ValueError('class or assertion in ' + path.name)
        if path.name.startswith('test_') and not any(
                isinstance(node, ast.If) and isinstance(node.test, ast.Compare) and
                isinstance(node.test.left, ast.Name) and node.test.left.id == '__name__'
                for node in tree.body):
            raise ValueError('missing main guard in ' + path.name)
        code = compile(source, str(path), 'exec')
        for argv in ([], ['foreign', '--unknown']):
            writer = mock.Mock()
            writer.write.side_effect = RuntimeError('unexpected output')
            namespace = {'__name__': 'inert_' + path.stem, '__file__': str(path)}
            with mock.patch.object(sys, 'argv', argv), mock.patch.object(socket, 'socket', side_effect=RuntimeError('socket')), \
                    mock.patch.object(ssl, 'create_default_context', side_effect=RuntimeError('TLS')), \
                    contextlib.redirect_stdout(writer), contextlib.redirect_stderr(writer):
                exec(code, namespace)
    print('AST and inert imports passed for %d files' % len(paths))


if __name__ == '__main__':
    check()
