"""Padded DATA and request trailers use the paired action seam."""
import h2_client
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def make(case):
    protocol = h2_client.new_protocol()
    request = request_credit.new_state(request_credit.new_case(case))
    credit = response_credit.new_state()
    stage = output_stage.new_stage(output_stage.new_case(case), 1, 1, 10, 100)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, credit, records)
    wire.startup(stage)
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in pairs)
    settings = len(payload).to_bytes(3, 'big') + b'\4\0\0\0\0\0' + payload + b'\0\0\0\4\1\0\0\0\0'
    wire.accept(protocol, settings, records, raw, trace, credit=credit, request=request, stage=stage)
    wire.drain(stage)
    stream, chunks = wire.start_request(stage, 'POST', 'localhost', '/upload/x', (), False,
                                        role='small', primary=True, held=case == 'queued_trailers_padding', body_limit=0, final_status=200,
                                        info_count=0, policy='healthy', mode='small_body', expected_sha256=None,
                                        middleware_policy='required')
    if stream != 1 or not chunks:
        raise RuntimeError('request action differs')
    return protocol, request, stage, records


def check():
    protocol, request, stage, records = make('queued_trailers_padding')
    wire.send_data(protocol, records, request, 1, b'x', stage=stage, end_stream=False, pad_length=7)
    wire.drain(stage)
    chunks = wire.send_trailers(stage, 1, (('x-trailer', 'proof'),))
    if request['sent'] != 9 or not request['streams'][1]['request_end'] or not chunks:
        raise RuntimeError('padded trailer accounting differs')
    try:
        wire.send_trailers(stage, 1, (('x-trailer', 'proof'),))
    except ValueError as error:
        if str(error) != 'invalid trailer action':
            raise
    else:
        raise RuntimeError('duplicate trailers accepted')
    protocol, request, stage, records = make('ready_buffered')
    try:
        wire.send_trailers(stage, 1, (('x-trailer', 'proof'),))
    except ValueError as error:
        if str(error) != 'invalid trailer action':
            raise
    else:
        raise RuntimeError('trailers allowed for wrong case')
    protocol, request, stage, records = make('empty_data')
    wire.send_data(protocol, records, request, 1, b'', stage=stage, end_stream=True, pad_length=None)
    empty = wire.drain(stage)
    if empty != b'\0\0\0\0\1\0\0\0\1' or request['case']['zero_frames'] != 1:
        raise RuntimeError('empty DATA serialization differs')
    try:
        wire.send_data(protocol, records, request, 1, b'', stage=stage, end_stream=True, pad_length=None)
    except ValueError:
        if request['case']['zero_frames'] != 1:
            raise RuntimeError('rejected empty DATA mutated case')
    else:
        raise RuntimeError('duplicate empty DATA accepted')
    print('padded trailer action checks passed')


if __name__ == '__main__':
    check()
