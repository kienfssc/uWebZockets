"""Bounded HTTP/2 response event and raw reset observation."""
import hashlib
import catalogue
import model
import re
from types import MappingProxyType
import h2.events
import h2.settings
import output_stage
import raw_observer
import request_credit
import response_credit

READ_BOUND = 8192
STREAM_LIMIT = 8
HEADER_FIELDS = 32
HEADER_BYTES = 4096
INFO_COUNT = 16
INFO_BYTES = 16384
EVENT_LIMIT = 64


def require(condition, message):
    if not condition:
        raise ValueError(message)



def bind_connection(stage, protocol, raw, request, credit, records):
    require(stage['binding'] is None and not raw['bound'] and not request['bound'] and not credit['bound'] and
            request['case']['case'] == stage['case'] and
            (stage['case_state']['request_case'] is None or stage['case_state']['request_case'] is request['case']) and
            all(previous is not protocol for previous in stage['case_state']['codecs']), 'invalid connection binding')
    stage['binding'] = {'protocol': protocol, 'raw': raw, 'request': request, 'credit': credit, 'records': records}
    stage['case_state']['request_case'] = request['case']
    stage['case_state']['codecs'].append(protocol)
    raw['bound'] = True
    request['bound'] = True
    credit['bound'] = True


def require_binding(stage, protocol, raw, request, credit):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and binding['protocol'] is protocol and binding['raw'] is raw and
            binding['request'] is request and binding['credit'] is credit, 'connection binding differs')


def startup(stage):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and binding['request']['client_settings'] == 0 and
            not binding['credit']['initial_acked'] and binding['credit']['pending'] is None,
            'invalid startup order')
    data = binding['protocol'].data_to_send(amount=8192)
    try:
        require(len(data) == 75 and data[:24] == b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' and
                data[24:33] == b'\x00\x00\x2a\x04\x00\x00\x00\x00\x00', 'startup serialization differs')
        settings = tuple((int.from_bytes(data[offset:offset + 2], 'big'),
                          int.from_bytes(data[offset + 2:offset + 6], 'big')) for offset in range(33, 75, 6))
        require(settings == ((1, 4096), (2, 1), (4, 65535), (5, 16384), (8, 0), (3, 100), (6, 65536)),
                'startup settings differ')
        request_credit.client_settings_sent(binding['request'])
        response_credit.settings_sent(binding['credit'], 65535, initial=True)
        return data

    except Exception:
        stage['failed'] = True
        stage['blocked_outbound'] = data
        raise


def update_settings(stage, initial_window):
    binding = stage['binding']
    expected = 33554432 if stage['case'] == 'output_pressure_ready' else 0
    require(binding is not None and not stage['failed'] and stage['case'] in catalogue.OUTPUT_CASES and
            type(initial_window) is int and initial_window == expected and stage['expected_acks'] == 2 and
            binding['request']['client_settings'] == 1 and binding['credit']['initial_acked'] and
            binding['credit']['pending'] is None and not stage['signaled'], 'invalid settings action')
    try:
        binding['protocol'].update_settings({h2.settings.SettingCodes.INITIAL_WINDOW_SIZE: initial_window})
        request_credit.client_settings_sent(binding['request'])
        response_credit.settings_sent(binding['credit'], initial_window)
    except Exception:
        stage['failed'] = True
        raise


def register(records, raw, stream_id, body_limit, final_status, info_count, policy, *, stage,
             mode="small_body", credit_policy, expected_sha256=None, middleware_policy="required"):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and binding['raw'] is raw and binding['records'] is records and
            stream_id in stage['active'] and not stage['signaled'], 'unregistered stage stream')
    stage_record = stage['active'][stream_id]
    roles = {'small': ('healthy', 'refusal_after_final'), 'special': ('healthy', 'refusal_after_final'),
             'reset': ('public_cancel', 'peer_reset', 'application_failure'),
             'transport': ('clean_disconnect', 'owned_shutdown')}
    require(policy in roles[stage_record['role']], 'invalid staged response policy')
    expected_info = stage['limits']['informationals'] if stage_record['primary'] else 0
    require(info_count == expected_info, 'invalid staged informational count')
    require(middleware_policy != 'optional' or (stage['case'] == 'async_delayed' and stage_record['primary']),
            'invalid optional middleware policy')
    require(len(records) < STREAM_LIMIT and stream_id not in records, 'stream record bound')
    require(type(stream_id) is int and type(body_limit) is int and type(info_count) is int,
            'invalid integer expectation')
    require(type(final_status) in (str, int) and re.fullmatch(r'[1-5][0-9]{2}', str(final_status)) is not None,
            'invalid status')
    require(type(mode) is str and mode in ('small_body', 'hash_only') and
            credit_policy == 'manual', 'invalid mode or credit policy')
    require(middleware_policy in ('required', 'optional'), 'invalid middleware policy')
    require(info_count in (0, 1) and 0 <= body_limit <= 16777313, 'invalid expectation')
    if stage_record['role'] == 'small':
        require(body_limit < 4096, 'small response bound')
    if stage_record['role'] == 'special':
        require(mode == 'hash_only' and str(final_status) == ('403' if stage['case'] == 'early_final_order' else '200') and
                policy == ('refusal_after_final' if stage['case'] == 'early_final_order' else 'healthy'),
                'invalid special response policy')
        expected = {'bytes': body_limit, 'sha256': expected_sha256, 'end': True,
                    'reset': stage['case'] == 'early_final_order'}
        if stage['case'] == 'stream_file':
            expected['content_length'] = body_limit
        model.validate_output_response(stage['case'], expected)
    if mode == 'small_body':
        require(body_limit < 4096 and expected_sha256 is None, 'invalid small body expectation')
    else:
        require(type(expected_sha256) is str and re.fullmatch(r'[0-9a-f]{64}', expected_sha256) is not None,
                'invalid expected digest')
        require(policy in ('healthy', 'refusal_after_final'), 'hash-only requires a final response')
    if policy in raw_observer.CLOSE_POLICIES:
        require(body_limit == 0 and info_count == 0, 'invalid close expectation')
    raw_observer.register(raw, stream_id, policy)
    records[stream_id] = {'headers': None, 'informationals': 0, 'info_bytes': 0,
                          'bytes': 0, 'hash': hashlib.sha256(), 'body': bytearray(),
                          'limit': body_limit, 'ended': False, 'reset_event': False,
                          'status': str(final_status), 'expected_info': info_count,
                          'policy': policy, 'mode': mode, 'credit_policy': credit_policy,
                          'expected_sha256': expected_sha256, 'middleware_policy': middleware_policy}


def checked_headers(headers):
    require(len(headers) <= HEADER_FIELDS, 'header field count bound')
    size = sum(len(k.encode('utf-8')) + len(v.encode('utf-8')) + 32 for k, v in headers)
    require(size <= HEADER_BYTES, 'header byte bound')
    return size



def accept(protocol, data, records, raw, trace, *, credit, request, stage):
    require_binding(stage, protocol, raw, request, credit)
    require(stage['binding']['records'] is records and type(data) is bytes and 0 < len(data) <= READ_BOUND,
            'invalid bound read')
    try:
        return _accept(protocol, data, records, raw, trace, credit=credit, request=request, stage=stage)
    except Exception:
        stage['failed'] = True
        raise

def _accept(protocol, data, records, raw, trace, *, credit, request, stage):
    require_binding(stage, protocol, raw, request, credit)
    require(stage['binding']['records'] is records, 'connection binding differs')
    require(all(record['credit_policy'] == 'manual' for record in records.values()), 'credit ledger requires manual mode')
    require(type(data) is bytes and len(data) <= READ_BOUND, 'read exceeds bound')
    expected_updates = raw_observer.observe(raw, data, request=request, stage=stage)
    events = protocol.receive_data(data)
    actual_updates = [(event.stream_id, event.delta) for event in events if isinstance(event, h2.events.WindowUpdated)]
    require(actual_updates == expected_updates, 'WINDOW_UPDATE event sequence differs')
    for event in events:
        name = type(event).__name__
        require(name in trace or len(trace) < EVENT_LIMIT, 'event type bound')
        trace[name] = trace.get(name, 0) + 1
        if isinstance(event, h2.events.SettingsAcknowledged) and credit is not None:
            response_credit.settings_acknowledged(credit, event)
        if isinstance(event, h2.events.ConnectionTerminated):
            raise ValueError('HTTP/2 connection terminated')
        if not isinstance(event, (h2.events.InformationalResponseReceived, h2.events.ResponseReceived,
                                  h2.events.TrailersReceived, h2.events.DataReceived,
                                  h2.events.StreamEnded, h2.events.StreamReset)):
            continue
        require(event.stream_id in records, 'unregistered response stream')
        record = records[event.stream_id]
        if isinstance(event, h2.events.InformationalResponseReceived):
            size = checked_headers(event.headers)
            require(record['informationals'] < INFO_COUNT and record['info_bytes'] + size <= INFO_BYTES,
                    'informational bound')
            require(record['headers'] is None and not record['ended'] and not record['reset_event'] and [v for k, v in event.headers if k == ':status'] == ['100'] and not any(k == 'x-middleware' for k, _ in event.headers), 'unexpected informational')
            record['informationals'] += 1
            record['info_bytes'] += size
            require(record['informationals'] <= record['expected_info'], 'extra informational')
        elif isinstance(event, h2.events.ResponseReceived):
            checked_headers(event.headers)
            require(record['headers'] is None and not record['ended'] and not record['reset_event'], 'duplicate response headers')
            require([v for k, v in event.headers if k == ':status'] == [record['status']], 'wrong final status')
            middleware = [v for k, v in event.headers if k == 'x-middleware']
            require(middleware == ['retained'] or (record['middleware_policy'] == 'optional' and not middleware), 'middleware header')
            record['headers'] = list(event.headers)
        elif isinstance(event, h2.events.TrailersReceived):
            raise ValueError('unexpected trailers')
        elif isinstance(event, h2.events.DataReceived):
            require(record['headers'] is not None and not record['ended'] and not record['reset_event'], 'DATA outside final response')
            require(record['bytes'] + len(event.data) <= record['limit'], 'response body bound')
            if credit is not None:
                response_credit.receive(credit, event.stream_id, len(event.data), event.flow_controlled_length)
            record['bytes'] += len(event.data)
            record['hash'].update(event.data)
            if record['mode'] == 'small_body':
                record['body'].extend(event.data)
        elif isinstance(event, h2.events.StreamEnded):
            require(record['headers'] is not None and not record['ended'] and not record['reset_event'], 'invalid end')
            if credit is not None:
                response_credit.end_response(credit, event.stream_id)
            record['ended'] = True
        elif isinstance(event, h2.events.StreamReset):
            require(record['policy'] in ('public_cancel', 'refusal_after_final', 'application_failure') and raw['streams'][event.stream_id]['reset'], 'unexpected reset event')
            code = {'public_cancel': 8, 'refusal_after_final': 0, 'application_failure': 2}[record['policy']]
            require(not record['reset_event'] and int(event.error_code) == code, 'invalid reset event')
            record['reset_event'] = True
            if credit is not None:
                inbound = response_credit.stream(credit, event.stream_id)
                if inbound['ended']:
                    require(record['policy'] == 'refusal_after_final' and inbound['terminal'] == 'end',
                            'reset after response terminal')
                else:
                    response_credit.terminal(credit, event.stream_id, 'incoming_reset')

    return events





SPECIAL_GRANTS = MappingProxyType({'producer_reuse': (16777313,),
                                   'output_pressure_window': (8192, 16777313 - 8192),
                                   'stream_file': (24593,), 'early_final_order': (8, 9)})


def new_grants(stage):
    require(stage['binding'] is not None and stage['grants'] is None, 'invalid grant policy creation')
    result = {'case': stage['case'], 'bootstrap': False, 'connection_replenished': 0,
              'auxiliary': set(), 'special': {}, 'primary': None}
    stage['grants'] = result
    return result


def grant(protocol, credit, grants, stage, stream_id, amount, purpose):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and binding['protocol'] is protocol and binding['credit'] is credit, 'connection binding differs')
    require(stage['grants'] is grants and grants['case'] == stage['case'] and not stage['signaled'] and
            (stream_id == 0 or (stream_id in stage['active'] and stream_id in binding['records'])) and
            credit['initial_acked'] and credit['pending'] is None,
            'invalid grant case or settings')
    response_credit.validate_grant(credit, stream_id, amount)
    record = None if stream_id == 0 else response_credit.stream(credit, stream_id)
    if purpose == 'bootstrap':
        require(stream_id == 0 and stage['case'] in catalogue.OUTPUT_CASES and not grants['bootstrap'] and
                grants['connection_replenished'] == 0 and credit['connection_granted'] == 0 and
                credit['connection'] == 65535 - credit['flow_bytes'] and
                amount == 33554432 - credit['connection'], 'invalid bootstrap grant')
    elif purpose == 'auxiliary':
        require(stream_id in stage['active'] and stage['active'][stream_id]['role'] == 'small' and
                credit['initial'] == 0 and amount == 65535 and stream_id not in grants['auxiliary'],
                'invalid auxiliary grant')
    elif purpose == 'special':
        sequence = SPECIAL_GRANTS.get(stage['case'], ())
        index = grants['special'].get(stream_id, 0)
        require(stream_id in stage['active'] and stage['active'][stream_id]['role'] == 'special' and
                grants['primary'] in (None, stream_id) and index < len(sequence) and amount == sequence[index] and
                (index == 0 or record['flow_bytes'] >= sum(sequence[:index])), 'invalid special grant')
    elif purpose == 'replenish':
        if stream_id == 0:
            require(grants['connection_replenished'] + amount <= credit['flow_bytes'], 'unearned connection grant')
        else:
            raise ValueError('invalid stream replenishment')
    else:
        raise ValueError('invalid grant purpose')
    try:
        protocol.increment_flow_control_window(amount, stream_id=stream_id or None)
        response_credit.grant(credit, stream_id, amount)
        if purpose == 'bootstrap':
            grants['bootstrap'] = True
            grants['connection_replenished'] = credit['flow_bytes']
        elif purpose == 'auxiliary':
            grants['auxiliary'].add(stream_id)
        elif purpose == 'special':
            grants['primary'] = stream_id
            grants['special'][stream_id] = grants['special'].get(stream_id, 0) + 1
            if grants['special'][stream_id] == len(SPECIAL_GRANTS[stage['case']]):
                stage['active'][stream_id]['held'] = False
        else:
            grants['connection_replenished'] += amount
        response_credit.compare_public(credit, protocol, [] if stream_id == 0 else [stream_id])

    except Exception:
        stage['failed'] = True
        raise


def drain(stage):
    binding = stage['binding']
    require(binding is not None and not stage['failed'], 'invalid outbound drain')
    data = binding['protocol'].data_to_send(amount=8192)
    require(type(data) is bytes and len(data) <= 8192, 'outbound drain bound')
    return data

def start_request(stage, method, authority, path, extra_headers, end_stream, *, role, primary, held,
                  body_limit, final_status, info_count, policy, mode, expected_sha256, middleware_policy):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and type(method) is str and type(authority) is str and
            type(path) is str and type(extra_headers) in (tuple, list) and type(end_stream) is bool and
            len(extra_headers) <= 76, 'invalid request action')
    fields = [(':method', method), (':scheme', 'https'), (':authority', authority), (':path', path)]
    for item in extra_headers:
        require(type(item) in (tuple, list) and len(item) == 2 and all(type(value) is str for value in item),
                'invalid request header')
        fields.append(tuple(item))
    require(sum(len(name.encode('utf-8')) + len(value.encode('utf-8')) + 32 for name, value in fields) <= 8192,
            'request header bound')
    protocol, raw = binding['protocol'], binding['raw']
    request, credit, records = binding['request'], binding['credit'], binding['records']
    stream_id = protocol.get_next_available_stream_id()
    trial_stage = dict(stage)
    trial_stage['case_state'] = dict(stage['case_state'])
    trial_stage['active'] = dict(stage['active'])
    trial_stage['final_paths'] = set(stage['final_paths'])
    trial_raw = dict(raw)
    trial_raw['streams'] = dict(raw['streams'])
    trial_request = dict(request)
    trial_request['streams'] = dict(request['streams'])
    trial_credit = dict(credit)
    trial_credit['streams'] = dict(credit['streams'])
    trial_records = dict(records)
    trial_stage['binding'] = dict(binding, raw=trial_raw, records=trial_records)
    output_stage.register(trial_stage, stream_id, role, primary=primary, held=held,
                          path=path if stage['final'] else None)
    request_credit.open_stream(trial_request, stream_id)
    response_credit.open_stream(trial_credit, stream_id)
    register(trial_records, trial_raw, stream_id, body_limit, final_status, info_count, policy,
             stage=trial_stage, mode=mode, credit_policy='manual', expected_sha256=expected_sha256,
             middleware_policy=middleware_policy)
    if end_stream:
        request_credit.end_request(trial_request, stream_id)
    chunks = _serialize_headers(stage, stream_id, fields, end_stream)
    output_stage.register(stage, stream_id, role, primary=primary, held=held,
                          path=path if stage['final'] else None)
    request_credit.open_stream(request, stream_id)
    response_credit.open_stream(credit, stream_id)
    register(records, raw, stream_id, body_limit, final_status, info_count, policy, stage=stage,
             mode=mode, credit_policy='manual', expected_sha256=expected_sha256, middleware_policy=middleware_policy)
    if end_stream:
        request_credit.end_request(request, stream_id)
    return stream_id, chunks


def _serialize_headers(stage, stream_id, fields, end_stream):
    protocol = stage['binding']['protocol']
    pending = protocol.data_to_send(amount=8192)
    if pending:
        stage['failed'] = True
        stage['blocked_outbound'] = pending
        raise ValueError('pending outbound bytes before request')
    try:
        protocol.send_headers(stream_id, fields, end_stream=end_stream)
        first = protocol.data_to_send(amount=8192)
        second = protocol.data_to_send(amount=8192) if len(first) == 8192 else b''
        encoded = first + second
        require(len(encoded) >= 9 and encoded[3] == 1 and encoded[4] in (4, 5) and
                int.from_bytes(encoded[5:9], 'big') == stream_id and
                int.from_bytes(encoded[:3], 'big') <= 8192 and
                len(encoded) == 9 + int.from_bytes(encoded[:3], 'big') and
                (encoded[4] & 1 != 0) == end_stream, 'request HEADERS serialization differs')
    except Exception:
        stage['failed'] = True
        raise
    return (first,) if not second else (first, second)


def send_trailers(stage, stream_id, headers):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and not stage['signaled'] and
            stage['limits']['trailers_allowed'] and stream_id in stage['active'] and
            stream_id in binding['records'] and type(headers) in (tuple, list) and 0 < len(headers) <= 80,
            'invalid trailer action')
    request = binding['request']
    record = request_credit.stream(request, stream_id)
    require(not request['final'] and not record['request_end'] and not record['reset'] and
            not record['retired'] and request['case']['trailers'] == 0, 'invalid trailer action')
    fields = []
    for item in headers:
        require(type(item) in (tuple, list) and len(item) == 2 and all(type(value) is str for value in item) and
                not item[0].startswith(':'), 'invalid trailer action')
        fields.append(tuple(item))
    require(sum(len(name.encode('utf-8')) + len(value.encode('utf-8')) + 32 for name, value in fields) <= 8192,
            'trailer header bound')
    chunks = _serialize_headers(stage, stream_id, fields, True)
    request_credit.end_request(request, stream_id)
    request['case']['trailers'] += 1
    return chunks


def send_data(protocol, records, request, stream_id, data, *, stage, end_stream, pad_length):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and binding['protocol'] is protocol and binding['request'] is request and
            binding['records'] is records and stream_id in stage['active'] and not stage['signaled'], 'connection binding differs')
    require(type(data) is bytes and type(end_stream) is bool and
            (pad_length is None or type(pad_length) is int and 0 <= pad_length <= 255), 'invalid DATA action')
    require(stream_id in records, 'unregistered request')
    record = records[stream_id]
    flow = len(data) + (0 if pad_length is None else pad_length + 1)
    require(not record['ended'] and not record['reset_event'] and
            (flow == 0 or record['informationals'] == record['expected_info']), 'DATA before Continue or after terminal')
    request_credit.validate_data(request, stream_id, len(data), flow)
    request_credit.compare_public(request, protocol, [stream_id])
    try:
        protocol.send_data(stream_id, data, end_stream=end_stream, pad_length=pad_length)
        request_credit.send_data(request, stream_id, len(data), flow)
        if end_stream:
            request_credit.end_request(request, stream_id)
        request_credit.compare_public(request, protocol, [] if end_stream and record['ended'] else [stream_id])
    except Exception:
        stage['failed'] = True
        raise

def send_peer_reset(protocol, records, raw, request, credit, stream_id, *, stage):
    require_binding(stage, protocol, raw, request, credit)
    require(stage['binding']['records'] is records, 'connection binding differs')
    require(stream_id in records and stream_id in raw['streams'], 'unregistered peer reset')
    record = records[stream_id]
    observed = raw['streams'][stream_id]
    outbound = request_credit.stream(request, stream_id)
    inbound = response_credit.stream(credit, stream_id)
    require(record['policy'] == 'peer_reset' and observed['policy'] == 'peer_reset' and
            not observed['end'] and not observed['peer_reset'] and not observed['reset'] and
            not outbound['reset'] and not request['final'] and not inbound['ended'], 'invalid peer reset')
    require(stream_id in stage['active'] and stage['active'][stream_id]['role'] == 'reset' and
            not stage['active'][stream_id]['terminal'], 'invalid stage reset')
    try:
        protocol.reset_stream(stream_id, error_code=8)
        raw_observer.mark_peer_reset(raw, stream_id, 8)
        request_credit.reset_request(request, stream_id)
        response_credit.terminal(credit, stream_id, 'outgoing_reset')
        stage['active'][stream_id]['terminal'] = True
    except Exception:
        stage['failed'] = True
        raise

def complete(records, raw, stream_id):
    record = records[stream_id]
    policy = record['policy']
    require(policy not in raw_observer.CLOSE_POLICIES, 'closing target requires explicit transport finalization')
    if policy in ('healthy', 'refusal_after_final'):
        require(record['headers'] is not None and record['ended'] and raw['streams'][stream_id]['end'], 'missing final')
        if record['mode'] == 'hash_only':
            require(record['bytes'] == record['limit'] and record['hash'].hexdigest() == record['expected_sha256'],
                    'body length or digest differs')
    else:
        require(record['headers'] is None and not record['ended'], 'unexpected final')
    require(record['informationals'] == record['expected_info'], 'missing informational')
    require(raw['streams'][stream_id]['reset'] == (policy in ('public_cancel', 'refusal_after_final', 'application_failure')), 'missing reset')
    if policy in ('public_cancel', 'application_failure'):
        require(record['reset_event'], 'missing reset event')
    if policy == 'peer_reset':
        require(raw['streams'][stream_id]['peer_reset'], 'missing outgoing reset')


def retire(records, raw, stream_id, *, request, credit, stage):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and binding['raw'] is raw and binding['request'] is request and
            binding['credit'] is credit and binding['records'] is records, 'connection binding differs')
    complete(records, raw, stream_id)
    outbound = request_credit.stream(request, stream_id)
    inbound = response_credit.stream(credit, stream_id)
    require(outbound['response_end'] and not outbound['retired'] and inbound['ended'] and
            stream_id in stage['active'] and stage['active'][stream_id]['terminal'], 'invalid paired retirement')
    raw_observer.retire(raw, stream_id)
    request_credit.retire(request, stream_id)
    response_credit.retire(credit, stream_id)
    output_stage.retire(stage, stream_id)
    del records[stream_id]



def enter_final(stage, held=None):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and not stage['signaled'], 'invalid bound final')
    request = binding['request']
    case = request['case']
    require(not request['transport_closed'] and stage['case_state']['connections'] == stage['limits']['connections'] and
            request['client_settings'] == stage['expected_acks'] and case['sent'] == case['limit'] and
            case['zero_frames'] == case['zero_limit'] and
            case['trailers'] == int(stage['limits']['trailers_allowed']), 'incomplete case action accounting')
    output_stage.enter_final(stage, binding['raw'], request, binding['credit'], held)


def finish_final(stage):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and not stage['signaled'], 'invalid bound final')
    active = set() if stage['held'] is None else {stage['held']}
    require(set(binding['records']) == active and set(binding['credit']['streams']) == active,
            'final ledger differs')
    output_stage.finish_final(stage, binding['raw'])

def begin_termination(records, raw, stream_id, policy, phase, *, stage):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and binding['raw'] is raw and binding['records'] is records and
            stream_id in stage['active'] and stage['active'][stream_id]['role'] == 'transport' and
            ((policy == 'clean_disconnect' and stage['case'] == 'disconnect' and stage['connection_index'] == 1) or
             (policy == 'owned_shutdown' and stage['case'] == 'shutdown_active' and stage['signaled'])),
            'invalid staged termination')
    require(set(records) == {stream_id}, 'other response remains in flight')
    record = records[stream_id]
    require(record['policy'] == policy and record['headers'] is None and record['informationals'] == 0 and
            record['bytes'] == 0 and not record['ended'] and not record['reset_event'], 'unexpected target response')
    raw_observer.begin_termination(raw, stream_id, policy, phase)


def finish_termination(records, raw, stream_id, policy, phase, outcome, *, request, credit, stage):
    binding = stage['binding']
    require(binding is not None and not stage['failed'] and binding['raw'] is raw and binding['request'] is request and
            binding['credit'] is credit and binding['records'] is records, 'connection binding differs')
    require(set(records) == {stream_id}, 'other response remains in flight')
    record = records[stream_id]
    require(record['policy'] == policy and record['headers'] is None and record['informationals'] == 0 and
            record['bytes'] == 0 and not record['ended'] and not record['reset_event'], 'unexpected target response')
    if policy == 'clean_disconnect':
        proof = {'method': 'ssl_unwrap', 'tls_shutdown': 'success', 'tcp_eof': True,
                 'trailing_bytes': 0, 'close': 'normal'}
        require(type(outcome) is dict and outcome == proof and type(outcome.get('tcp_eof')) is bool and type(outcome.get('trailing_bytes')) is int,
                'strict close evidence differs')
    else:
        require(policy == 'owned_shutdown' and phase == 'post_signal' and outcome in ('eof', 'tls_eof'), 'invalid shutdown outcome')
    request_credit.stream(request, stream_id)
    incoming = response_credit.stream(credit, stream_id)
    require(not request['transport_closed'] and not incoming['ended'] and
            stream_id in stage['active'] and stage['active'][stream_id]['role'] == 'transport' and
            not stage['active'][stream_id]['terminal'] and
            (policy != 'owned_shutdown' or stage['signaled']), 'invalid transport terminal')
    result = raw_observer.finish_termination(raw, stream_id, policy, phase, outcome)
    output_stage.transport_ended(stage, stream_id, raw)
    request_credit.transport_end(request)
    response_credit.terminal(credit, stream_id, 'transport')
    response_credit.retire(credit, stream_id)
    result['response_terminal'] = 'transport'
    result['outcome'] = outcome
    del records[stream_id]
    return result
