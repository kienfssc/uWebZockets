"""Final collection preserves inherited accounting and a held active stream."""
import output_stage as stage
import model
import catalogue


def rejects(call, *args):
    try:
        call(*args)
    except ValueError:
        return
    raise RuntimeError('expected ValueError')


def check():
    item = stage.new_stage(stage.new_case('shutdown_active'), 1, 1, 10, 100)
    stage.register(item, 1, 'transport', primary=True, held=True)
    item['initial_settings'] = 1
    item['acks'] = 1
    raw = {'streams': {1: {}}, 'header': bytearray(b'\0'), 'frame': None, 'remaining': 0}
    request = {'connection_debt': 32, 'stream_debt_total': 32, 'streams': {1: {'debt': 32}}, 'final': False}
    response = {'initial_acked': True, 'pending': None, 'streams': {1: {}}}
    stage.read(item, b'a')
    for stream in (3, 5):
        stage.register(item, stream, 'small')
        stage.frame(item, 0, 1, 5, stream, False)
        stage.finished(item, 1, 5, stream)
        stage.retire(item, stream)
    response['streams'] = {}
    rejects(stage.enter_final, item, raw, request, response, 1)
    response['streams'] = {1: {}}
    stage.enter_final(item, raw, request, response, 1)
    if stage.remaining(item, 4) != 6:
        raise RuntimeError('remaining deadline differs')
    rejects(stage.remaining, item, 10)
    rejects(stage.remaining, item, True)
    if item['reads'] != 1 or item['case_deadline'] != 10 or item['whole_deadline'] != 100 or raw['header'] != bytearray(b'\0'):
        raise RuntimeError('lost inherited state')
    paths = ['/status/' + row[0] for row in model.BODY_SPECS] + ['/metrics']
    try:
        stage.register(item, 7, 'small', path='/metrics')
    except ValueError as error:
        if str(error) != 'invalid final observation':
            raise
    else:
        raise RuntimeError('early metrics accepted')
    for index, path in enumerate(paths):
        stream = 7 + index * 2
        stage.register(item, stream, 'small', path=path)
        if index == 0:
            try:
                stage.register(item, stream + 2, 'small', path=path)
            except ValueError as error:
                if str(error) != 'invalid final observation':
                    raise
            else:
                raise RuntimeError('duplicate status accepted')
        stage.frame(item, 0, 1, 5, stream, False)
        stage.finished(item, 1, 5, stream)
        stage.retire(item, stream)
    raw['header'].clear()
    stage.finish_final(item, raw)
    stage.signal(item)
    rejects(stage.register, item, 143, 'small')
    if set(item['active']) != {1}:
        raise RuntimeError('held request lost')
    capped = stage.new_stage(stage.new_case('shutdown_idle'), 1, 1, 10, 100)
    for _ in range(4096):
        stage.read(capped, b'x')
    rejects(stage.read, capped, b'x')
    rejects(stage.frame, capped, True, 4, 0, 0, False)
    large = stage.new_stage(stage.new_case('large_declared'), 1, 1, 180, 900)
    large['initial_settings'] = 1
    large['acks'] = 1
    large['primary_complete'] = True
    large['case_state']['small'] = large['limits']['small']
    large['case_state']['heads'] = large['limits']['heads']
    old = {'debt': 65535, 'retired': True, 'transport': False, 'reset': False,
           'request_end': True, 'response_end': True}
    large_request = {'connection_debt': 65535, 'stream_debt_total': 65535, 'streams': {1: old}, 'final': False}
    large_raw = {'streams': {}, 'header': bytearray(), 'frame': None, 'remaining': 0}
    large_credit = {'initial_acked': True, 'pending': None, 'streams': {}}
    large_request['connection_debt'] = 65536
    rejects(stage.enter_final, large, large_raw, large_request, large_credit)
    large_request['connection_debt'] = 65535
    stage.enter_final(large, large_raw, large_request, large_credit)
    if large['final_budget'] != catalogue.final_budget(131070) or large['case_deadline'] != 180:
        raise RuntimeError('large partial final bound differs')
    print('stage final checks passed')


if __name__ == '__main__':
    check()
