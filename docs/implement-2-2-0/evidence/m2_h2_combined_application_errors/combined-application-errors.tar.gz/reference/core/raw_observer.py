"""Bounded raw HTTP/2 frame-order observation; transport is external."""
import request_credit
import output_stage
READ_BOUND = 8192
STREAM_LIMIT = 8
FRAME_LIMIT = 16384
POLICIES = ('healthy', 'public_cancel', 'peer_reset', 'refusal_after_final', 'application_failure',
            'clean_disconnect', 'owned_shutdown')
CLOSE_POLICIES = ('clean_disconnect', 'owned_shutdown')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def new_state():
    return {'header': bytearray(), 'remaining': 0, 'frame': None,
            'reset_payload': bytearray(), 'streams': {}, 'high_water': 0,
            'closing': None, 'closed': False, 'bound': False}


def register(state, stream_id, policy):
    streams = state['streams']
    require(not state['closed'] and state['closing'] is None, 'connection closing')
    require(policy in POLICIES, 'invalid terminal policy')
    require(state['high_water'] < stream_id <= 0x7fffffff and stream_id & 1, 'invalid stream')
    require(len(streams) < STREAM_LIMIT, 'stream bound')
    state['high_water'] = stream_id
    streams[stream_id] = {'policy': policy, 'end': False, 'reset': False,
                          'peer_reset': False}


def mark_peer_reset(state, stream_id, code):
    record = state['streams'][stream_id]
    require(record['policy'] == 'peer_reset' and code == 8, 'invalid peer reset')
    require(not record['end'] and not record['peer_reset'], 'duplicate peer reset')
    record['peer_reset'] = True


def retire(state, stream_id):
    record = state['streams'][stream_id]
    policy = record['policy']
    complete = ((policy == 'healthy' and record['end'] and not record['reset']) or
                (policy in ('public_cancel', 'application_failure') and record['reset'] and not record['end']) or
                (policy == 'peer_reset' and record['peer_reset'] and not record['end'] and not record['reset']) or
                (policy == 'refusal_after_final' and record['end'] and record['reset']))
    require(complete, 'incomplete stream')
    del state['streams'][stream_id]


def begin_termination(state, stream_id, policy, phase):
    require(policy in CLOSE_POLICIES, 'invalid closing policy')
    require(phase == ('pre_unwrap' if policy == 'clean_disconnect' else 'post_signal'), 'invalid closing phase')
    require(not state['closed'] and state['closing'] is None, 'connection already closing')
    require(set(state['streams']) == {stream_id}, 'other response remains in flight')
    record = state['streams'][stream_id]
    require(record['policy'] == policy and not record['end'] and not record['reset'] and not record['peer_reset'], 'invalid closing target')
    require(not state['header'] and state['frame'] is None and state['remaining'] == 0, 'partial frame at closing boundary')
    state['closing'] = {'stream': stream_id, 'policy': policy, 'phase': phase, 'bytes': 0, 'frames': 0,
                        'connection_credit': 0, 'stream_credit': 0}


def finish_termination(state, stream_id, policy, phase, outcome):
    closing = state['closing']
    require(closing is not None and (closing['stream'], closing['policy'], closing['phase']) == (stream_id, policy, phase), 'closing identity differs')
    require(set(state['streams']) == {stream_id}, 'other response remains in flight')
    require(not state['header'] and state['frame'] is None and state['remaining'] == 0, 'trailing partial frame')
    if policy == 'clean_disconnect':
        expected = {'method': 'ssl_unwrap', 'tls_shutdown': 'success', 'tcp_eof': True,
                    'trailing_bytes': 0, 'close': 'normal'}
        require(outcome == expected and type(outcome.get('tcp_eof')) is bool and type(outcome.get('trailing_bytes')) is int, 'strict close evidence differs')
    else:
        require(policy == 'owned_shutdown' and phase == 'post_signal' and outcome in ('eof', 'tls_eof'), 'invalid shutdown outcome')
    result = {'kind': 'local_transport_only', 'frames': closing['frames'], 'bytes': closing['bytes'],
              'connection_credit': closing['connection_credit'], 'stream_credit': closing['stream_credit']}
    del state['streams'][stream_id]
    state['closed'] = True
    return result


def finish_frame(state, request, expected, stage):
    frame = state['frame']
    stream_id = frame['stream']
    record = state['streams'].get(stream_id)
    if frame['type'] == 4 and stage is not None and frame['flags'] == 0:
        payload = state['reset_payload']
        settings = {}
        for offset in range(0, len(payload), 6):
            key = int.from_bytes(payload[offset:offset + 2], 'big')
            require(key not in settings, 'duplicate server setting')
            settings[key] = int.from_bytes(payload[offset + 2:offset + 6], 'big')
        require(tuple(settings.items()) == ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)),
                'server settings shape differs')
        request_credit.server_initial_settings(request, settings.get(4, 65535))
    if frame['type'] == 8 and request is not None:
        increment = int.from_bytes(state['reset_payload'], 'big')
        require(increment <= 0x7fffffff, 'reserved window bit')
        if request_credit.refund(request, stream_id, increment):
            require(len(expected) < 631, 'update event bound')
            expected.append((stream_id, increment))
    if frame['type'] == 3:
        require(record is not None, 'reset on unregistered stream')
        policy = record['policy']
        require(policy in ('public_cancel', 'refusal_after_final', 'application_failure'), 'unexpected reset')
        require(not record['reset'], 'duplicate reset')
        require((policy == 'refusal_after_final') == record['end'], 'reset order')
        expected = {'public_cancel': 8, 'refusal_after_final': 0, 'application_failure': 2}[policy]
        require(int.from_bytes(state['reset_payload'], 'big') == expected, 'wrong reset code')
        record['reset'] = True
        if request is not None:
            request_credit.incoming_reset(request, stream_id)
    elif frame['type'] in (0, 1):
        require(record is not None, 'payload on unregistered stream')
        require(record['policy'] not in CLOSE_POLICIES, 'unexpected closing target payload')
        require(not record['end'] and not record['reset'] and not record['peer_reset'],
                'payload after terminal')
        if frame['flags'] & 1:
            record['end'] = True
            if request is not None:
                request_credit.end_response(request, stream_id)
    if state['closing'] is not None:
        increment = int.from_bytes(state['reset_payload'], 'big')
        require(1 <= increment <= 0x7fffffff, 'invalid closing credit')
        key = 'connection_credit' if stream_id == 0 else 'stream_credit'
        state['closing'][key] += increment
        state['closing']['frames'] += 1
        require(state['closing']['frames'] <= 4096, 'closing frame count bound')
    if stage is not None:
        output_stage.finished(stage, frame['type'], frame['flags'], stream_id)
    state['frame'] = None
    state['reset_payload'].clear()


def observe(state, data, *, request=None, stage=None):
    expected = []
    if stage is not None:
        require(request is not None, 'stage requires request ledger')
        output_stage.read(stage, data)
    require(not state['closed'], 'connection already closed')
    require(len(data) <= READ_BOUND, 'read bound')
    if state['closing'] is not None:
        state['closing']['bytes'] += len(data)
        require(state['closing']['bytes'] <= 65536, 'closing byte bound')
    offset = 0
    while offset < len(data):
        if state['frame'] is None:
            header = state['header']
            count = min(9 - len(header), len(data) - offset)
            header.extend(data[offset:offset + count])
            offset += count
            if len(header) < 9:
                continue
            length = int.from_bytes(header[:3], 'big')
            frame_type = header[3]
            stream_id = int.from_bytes(header[5:9], 'big') & 0x7fffffff
            require(length <= FRAME_LIMIT, 'frame bound')
            if stage is not None:
                output_stage.frame(stage, length, frame_type, header[4], stream_id, bool(header[5] & 128))
            if frame_type == 8 and request is not None:
                require(length == 4 and header[4] == 0 and header[5] < 128, 'invalid WINDOW_UPDATE frame')
            if state['closing'] is not None:
                require(state['closing']['policy'] == 'owned_shutdown', 'bytes during clean close')
                require(length == 4 and frame_type == 8 and header[4] == 0 and header[5] < 128, 'unexpected closing frame')
                require(stream_id in (0, state['closing']['stream']), 'unexpected closing stream')
            elif frame_type in (0, 1):
                record = state['streams'].get(stream_id)
                require(record is None or record['policy'] not in CLOSE_POLICIES, 'unexpected closing target payload')
            if frame_type == 3:
                require(length == 4 and stream_id != 0, 'invalid reset frame')
            state['frame'] = {'type': frame_type, 'flags': header[4], 'stream': stream_id}
            state['remaining'] = length
            header.clear()
            if length == 0:
                finish_frame(state, request, expected, stage)
            continue
        count = min(state['remaining'], len(data) - offset)
        if state['frame']['type'] == 3 or (state['frame']['type'] == 8 and request is not None) or (state['frame']['type'] == 4 and stage is not None and state['frame']['flags'] == 0) or state['closing'] is not None:
            state['reset_payload'].extend(data[offset:offset + count])
        offset += count
        state['remaining'] -= count
        if state['remaining'] == 0:
            finish_frame(state, request, expected, stage)

    return expected
