"""Response terminal distinctions and retirement checks."""
import response_credit as credit


def rejects(call, *args):
    try:
        call(*args)
    except ValueError:
        return
    raise RuntimeError('expected ValueError')


def check():
    for terminal in ('incoming_reset', 'outgoing_reset', 'transport'):
        state = credit.new_state()
        state['initial_acked'] = True
        credit.open_stream(state, 1)
        credit.terminal(state, 1, terminal)
        rejects(credit.end_response, state, 1)
        rejects(credit.terminal, state, 1, terminal)
        rejects(credit.grant, state, 1, 1)
        credit.retire(state, 1)
        rejects(credit.retire, state, 1)
    state = credit.new_state()
    state['initial_acked'] = True
    credit.open_stream(state, 1)
    rejects(credit.terminal, state, 1, 'success')
    credit.end_response(state, 1)
    if state['streams'][1]['terminal'] != 'end':
        raise RuntimeError('normal end missing')
    credit.retire(state, 1)
    print('response retirement checks passed')


if __name__ == '__main__':
    check()
