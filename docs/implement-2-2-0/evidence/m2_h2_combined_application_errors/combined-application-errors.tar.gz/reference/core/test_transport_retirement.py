"""Pure terminal observation keeps request debt on its original connection."""
import h2_client
import hpack
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def check():
    protocol = h2_client.new_protocol()
    response = response_credit.new_state()
    request = request_credit.new_state(request_credit.new_case('disconnect'))
    stage_case = output_stage.new_case('disconnect')
    stage = output_stage.new_stage(stage_case, 1, 1, 10, 100)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, response, records)
    if len(wire.startup(stage)) != 75:
        raise RuntimeError('original startup differs')
    payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                       ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    startup = len(payload).to_bytes(3, 'big') + b'\4\0\0\0\0\0' + payload + b'\0\0\0\4\1\0\0\0\0'
    wire.accept(protocol, startup, records, raw, trace, credit=response, request=request, stage=stage)
    protocol.data_to_send(amount=8192)
    stream, chunks = wire.start_request(stage, 'POST', 'localhost', '/upload/x', (), False,
                                        role='transport', primary=True, held=False, body_limit=0,
                                        final_status=200, info_count=0, policy='clean_disconnect', mode='small_body',
                                        expected_sha256=None, middleware_policy='required')
    if stream != 1 or not chunks:
        raise RuntimeError('original request differs')
    wire.send_data(protocol, records, request, 1, b'abcdefgh', stage=stage, end_stream=False, pad_length=None)
    protocol.data_to_send(amount=8192)
    wire.begin_termination(records, raw, 1, 'clean_disconnect', 'pre_unwrap', stage=stage)
    outcome = {'method': 'ssl_unwrap', 'tls_shutdown': 'success', 'tcp_eof': True,
               'trailing_bytes': 0, 'close': 'normal'}
    result = wire.finish_termination(records, raw, 1, 'clean_disconnect', 'pre_unwrap', outcome,
                                     request=request, credit=response, stage=stage)
    if result['response_terminal'] != 'transport' or response['streams'] or not request['transport_closed'] or not stage_case['transport_finished']:
        raise RuntimeError('transport retirement differs')
    if request['connection_debt'] != 8 or request['streams'][1]['debt'] != 8:
        raise RuntimeError('old connection debt lost')
    replacement = request_credit.new_state(request['case'])
    if replacement['connection_debt'] != 0:
        raise RuntimeError('debt transferred')
    next_protocol = h2_client.new_protocol()
    next_response = response_credit.new_state()
    next_stage = output_stage.new_stage(stage_case, 1, 1, 10, 100)
    next_raw, next_records, next_trace = raw_observer.new_state(), {}, {}
    try:
        wire.bind_connection(next_stage, protocol, next_raw, replacement, next_response, next_records)
    except ValueError as error:
        if str(error) != 'invalid connection binding':
            raise
    else:
        raise RuntimeError('old codec reused for replacement')
    wrong_case = request_credit.new_state(request_credit.new_case('disconnect'))
    try:
        wire.bind_connection(next_stage, next_protocol, next_raw, wrong_case, next_response, next_records)
    except ValueError as error:
        if str(error) != 'invalid connection binding':
            raise
    else:
        raise RuntimeError('independent case budget accepted')
    wire.bind_connection(next_stage, next_protocol, next_raw, replacement, next_response, next_records)
    if len(wire.startup(next_stage)) != 75:
        raise RuntimeError('replacement startup differs')
    try:
        wire.accept(next_protocol, b'', next_records, next_raw, next_trace,
                    credit=next_response, request=request, stage=next_stage)
    except ValueError as error:
        if str(error) != 'connection binding differs':
            raise
    else:
        raise RuntimeError('old debt ledger attached to replacement')
    payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                       ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    startup = len(payload).to_bytes(3, 'big') + b'\4\0\0\0\0\0' + payload + b'\0\0\0\4\1\0\0\0\0'
    wire.accept(next_protocol, startup, next_records, next_raw, next_trace, credit=next_response,
                request=replacement, stage=next_stage)
    next_protocol.data_to_send(amount=8192)
    stream, chunks = wire.start_request(next_stage, 'GET', 'localhost', '/health', (), True,
                                        role='small', primary=True, held=False, body_limit=0,
                                        final_status=200, info_count=0, policy='healthy', mode='small_body',
                                        expected_sha256=None, middleware_policy='required')
    if stream != 1 or not chunks:
        raise RuntimeError('replacement request differs')
    block = hpack.Encoder().encode([(':status', '200'), ('x-middleware', 'retained')])
    packet = len(block).to_bytes(3, 'big') + b'\1\5\0\0\0\1' + block
    wire.accept(next_protocol, packet, next_records, next_raw, next_trace, credit=next_response,
                request=replacement, stage=next_stage)
    wire.retire(next_records, next_raw, 1, request=replacement, credit=next_response, stage=next_stage)
    if stage_case['connections'] != 2 or request['connection_debt'] != 8 or replacement['connection_debt'] != 0:
        raise RuntimeError('replacement accounting differs')
    print('transport retirement checks passed')


if __name__ == '__main__':
    check()
