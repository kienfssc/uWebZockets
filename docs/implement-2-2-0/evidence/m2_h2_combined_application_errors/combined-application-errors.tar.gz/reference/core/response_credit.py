"""Caller-owned HTTP/2 response receive-credit accounting; no transport operations."""
from h2.settings import SettingCodes

MAX_WINDOW = 2147483647
MIN_WINDOW = -2147483648
INITIAL_WINDOW = 65535
STREAM_LIMIT = 8


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, low, high):
    require(type(value) is int and low <= value <= high, 'invalid integer')


def new_state():
    return {'connection': INITIAL_WINDOW, 'initial': INITIAL_WINDOW, 'initial_acked': False,
            'pending': None, 'high_water': 0, 'streams': {}, 'connection_granted': 0,
            'stream_granted': 0, 'flow_bytes': 0, 'logical_bytes': 0, 'bound': False}


def settings_sent(state, initial_window, *, initial=False):
    integer(initial_window, 0, MAX_WINDOW)
    require(type(initial) is bool and state['pending'] is None, 'invalid pending settings')
    require(initial != state['initial_acked'], 'initial settings ordering')
    if initial:
        require(initial_window == INITIAL_WINDOW, 'invalid initial settings')
    state['pending'] = (state['initial'], initial_window, initial)


def settings_acknowledged(state, event):
    pending = state['pending']
    require(pending is not None, 'unexpected settings ACK')
    old, new, initial = pending
    changed = event.changed_settings.get(SettingCodes.INITIAL_WINDOW_SIZE)
    if changed is None:
        require(old == new, 'missing initial-window change')
    else:
        require(type(changed.original_value) is int and type(changed.new_value) is int and
                changed.original_value == old and changed.new_value == new, 'settings ACK differs')
    delta = new - old
    for record in state['streams'].values():
        require(MIN_WINDOW <= record['window'] + delta <= MAX_WINDOW, 'stream window overflow')
    for record in state['streams'].values():
        record['window'] += delta
    state['initial'] = new
    state['initial_acked'] = state['initial_acked'] or initial
    state['pending'] = None


def open_stream(state, stream_id):
    integer(stream_id, 1, MAX_WINDOW)
    require(state['initial_acked'] and stream_id & 1 and stream_id > state['high_water'] and
            len(state['streams']) < STREAM_LIMIT, 'invalid stream opening')
    state['streams'][stream_id] = {'window': state['initial'], 'logical_bytes': 0,
                                   'flow_bytes': 0, 'granted': 0, 'ended': False, 'terminal': None}
    state['high_water'] = stream_id


def stream(state, stream_id):
    integer(stream_id, 1, MAX_WINDOW)
    require(stream_id in state['streams'], 'unknown stream')
    return state['streams'][stream_id]


def validate_grant(state, stream_id, increment):
    integer(stream_id, 0, MAX_WINDOW)
    integer(increment, 1, MAX_WINDOW)
    if stream_id == 0:
        require(state['connection'] + increment <= MAX_WINDOW, 'connection window overflow')
        return
    record = stream(state, stream_id)
    require(not record['ended'] and record['window'] + increment <= MAX_WINDOW, 'invalid stream grant')


def grant(state, stream_id, increment):
    validate_grant(state, stream_id, increment)
    if stream_id == 0:
        state['connection'] += increment
        state['connection_granted'] += increment
        return
    record = stream(state, stream_id)
    record['window'] += increment
    record['granted'] += increment
    state['stream_granted'] += increment


def receive(state, stream_id, logical_length, flow_length):
    integer(logical_length, 0, MAX_WINDOW)
    integer(flow_length, 0, MAX_WINDOW)
    record = stream(state, stream_id)
    require(not record['ended'] and logical_length <= flow_length, 'invalid DATA')
    require(flow_length == 0 or (flow_length <= state['connection'] and flow_length <= record['window']),
            'DATA exceeds receive credit')
    state['connection'] -= flow_length
    record['window'] -= flow_length
    state['logical_bytes'] += logical_length
    state['flow_bytes'] += flow_length
    record['logical_bytes'] += logical_length
    record['flow_bytes'] += flow_length


def end_response(state, stream_id):
    record = stream(state, stream_id)
    require(not record['ended'], 'duplicate response end')
    record['ended'] = True
    record['terminal'] = 'end'


def terminal(state, stream_id, reason):
    require(type(reason) is str and reason in ('incoming_reset', 'outgoing_reset', 'transport'), 'invalid terminal')
    record = stream(state, stream_id)
    require(not record['ended'], 'duplicate response terminal')
    record['ended'] = True
    record['terminal'] = reason


def retire(state, stream_id):
    record = stream(state, stream_id)
    require(record['ended'], 'response not ended')
    del state['streams'][stream_id]


def compare_public(state, protocol, query_streams):
    require(type(query_streams) in (tuple, list), 'invalid query list')
    connection = protocol.inbound_flow_control_window
    require(type(connection) is int and connection == state['connection'], 'connection window differs')
    seen = set()
    for stream_id in query_streams:
        record = stream(state, stream_id)
        require(stream_id not in seen, 'duplicate query')
        seen.add(stream_id)
        window = protocol.remote_flow_control_window(stream_id)
        require(type(window) is int and window == min(state['connection'], record['window']), 'stream window differs')
