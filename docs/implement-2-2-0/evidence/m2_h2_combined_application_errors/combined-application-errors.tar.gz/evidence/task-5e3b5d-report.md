# Task5e3b5d implementation report

Implemented the three B5 combined application-error schedules and their actual serialized codec tests against reviewed/pushed B5c `94eb6b1f17c1baffea729edbc8b8db180ec9347a`. This is source-only, pure in-memory public-codec/control/reset evidence. Independent Root review, public delivery and Git remain Root-owned. No all40, native, runtime or milestone acceptance is claimed.

## Scope and source authority

The exact task brief, release addendum and parent B5 brief govern the slice. Required project guidance and narrow TDD/API/review/constraint/failure-triage guidance were loaded. No Zig code, build graph, workflow or product API changed; no native/build/server/socket/SSLContext/real-clock/ownership/fault/scheduling/descriptor/kernel/race/panic/leak probe, old live entrypoint, dependency operation, agent delegation, external model CLI or Git operation ran.

The prescribed graphify query ran before the first source search/read:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "combined-cases adapter control_reset_cases application-error sink_error invalid_progress end_error" --budget 650
```

Its exit was 0, stderr empty; stdout explicitly reported a 650-token truncation. Located files supplied by the briefs were then read directly. The required post-edit AST update used the same prefix with `update .`, exit 0, stderr empty. It reported no relevant changes and left the ignored graph untouched. Both complete receipts are under `evidence/b5d/graphify-{query,update}.{stdout,stderr,exit}`.

Authoritative family source references are `.uwz-work/evidence/h2-streaming/integration-owned/application-error/cases.py` and `profile.zig`, authenticated by `task-5e3b-input-audit.json`. The current immutable combined model/schema supersedes the legacy family's singular counter aliases and string `none` reason. Family `cases.execute` provides the exact sibling, first7/first8, terminal status, stale pair, refund, sibling, recovery, stale pair order; `profile.chunk` provides the two diagnostic distinctions and no new accepted bytes on failure. No family runner or fixture was executed.

The immutable source/module authorities remain:

- Model/catalogue: `/tmp/uwz-task5e1-contract-v3`.
- Core: `/tmp/uwz-task5e3a-snapshot-v9/source`, 26 unchanged files.
- Fixture: `/tmp/uwz-task5e2-Fix1Final2/fixture`, 25 unchanged source-only files.
- Helper: `.uwz-work/evidence/h2-streaming/integration-client/h2_client.py`, SHA256 `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`.
- Python: `/home/codespace/.python/current/bin/python3`, binary SHA256 `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`; every direct Python invocation used `-B -S`, with `-O` additionally for optimized runs.
- Codecs: `/tmp/uwz-h2-client-tooling/packages`, all 42 exact ordered rows from B5c, aggregate `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`.

`evidence/b5d/immutable-inputs.json` retains the exact inherited input map and ordered codec rows. Aggregate reproduction is `hashlib.sha256(json.dumps(rows).encode()).hexdigest()` with default separators/spacing and retained row order. The audit rehashed every row and checked no extra/missing non-cache codec files, including licenses, metadata and type markers.

There are **119 retained identity rows / 114 unique identity entries**, consisting of **118 file rows / 113 unique resolved files**, plus the codec aggregate. The 118 file rows have 114 distinct path spellings: the helper's absolute/relative spellings identify one file; four runtime helper paths also repeat. Both row and resolved-file counts are retained accurately.

## Changed files and APIs

All directly owned modules are in `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`:

- Added `application_error_cases.py`: the three concrete schedules, exact application primary/recovery request construction, accepted-prefix barrier and terminal/sibling/recovery validation.
- Added `test_application_error.py`: independent bounded serialized request/DATA/order/hash/reset/refund/retirement checks and a shared synthetic application across fresh connection contexts.
- Changed `adapter.py`: dispatch the three cases; extend the existing no-successful-final reset policy, parser-complete reset-event completion and returned reset-code selection to `application_failure`/2. Existing policies/defaults and canonical `wire.complete`/paired `wire.retire` remain in force.
- Changed `cases.py`: explicit implemented selection 28->31, descriptive count 31.
- Changed `test_imports.py`: inventory and actual inert-import proof include both new modules.
- Changed `test_pause.py`, `test_admission.py`, `test_continue_quota.py`, `test_metadata_concurrency.py`: authorized explicit unsupported inventory 12->9; all existing rejection checks remain. Metadata/concurrency output now says 9 accordingly.

There are 27 modules: 2 added, 7 changed, 18 byte-identical to B5c, 0 removed. Exact all-module hashes and comparison are `evidence/b5d/snapshot.json`; complete initial/final module copies are `before-source/` and `final-source/`; `source.diff` is the full comparison. No prior schedule was rewritten.

Used seams are `model.request_contract`, `model.payload_span`, `model.record`, `model.validate_item`; `adapter.start/send_data/health/finish`; `pause_cases.status/pending`; and the existing `control_reset_cases.stale/refund` helpers. The B5c primary creation helper was deliberately not reused because its policy selection implements cancellation/reset, whereas the application schedule's start function adds the required application-failure role/policy binding. It is an invariant-bearing request constructor, not a forwarding-only wrapper.

Every actual request, DATA, settings, observation, credit and retirement still passes exactly once through the single bound `wire` codec/parser/request-ledger/response-ledger/output-stage seam. New schedule code performs no direct core/model/fixture/state mutation and applies no refund manually. The refund helper waits for legitimate observed connection debt to clear and requires the public codec window to be 65535 before sibling DATA. Caller integer time and inherited deadlines are checked at the existing actual-action/read/drain/final points; there is no real clock access.

## Exact schedule contracts

| Case | J heads | C small | R request flow | Primary DATA | Refund target |
| --- | ---: | ---: | ---: | --- | ---: |
| sink_error | 11 | 10 | 48 | first7 without END; first8 without END | 15 |
| invalid_progress | 11 | 10 | 48 | first7 without END; first8 without END | 15 |
| end_error | 10 | 9 | 65 | canonical32 with END | 32 |

Start health is request stream1; the sibling is stream3, `POST /echo`, content-length1, body still open; the application primary is stream5, declared32 `POST /limit/<tag>?case=<tag>`, `x-case=<tag>`, `role=reset`, `policy=application_failure`. Both sink/progress cases observe begins1, accepted7/H7, ready, ends0/cancels0, chunks1/max_span7 and no premature primary terminal before sending the canonical **first8 bytes at offset0**, not offset7. End-error has no preterminal status request.

Terminal status validates every current model field. Sink/progress have accepted7/H7, cancels1, ends0, reason `sink_failure`, and respectively chunk_errors1/invalid_progress0 or chunk_errors0/invalid_progress1. The failing callback contributes no accepted bytes and must follow the prefix callback. End-error has accepted32/H32, ends1, end_errors1, cancels0 and reason `None`; it must never gain a second cancellation. Metadata through unwind, terminal counts, hashes, diagnostic fields and stale counters are validated against the immutable model.

All primaries require exactly INTERNAL_ERROR2, no successful primary response HEADERS, no END, and no response body. Completion requires both canonical raw reset and protocol reset event and a complete parser, then canonical completion and paired retirement. No fabricated successful primary response is used to complete a case.

Only after terminal wire completion/retirement does each case issue stale resume/cancel and demand exact `BodyControlExpired`. After legitimate refund to 15/32, it sends sibling `b's'`+END and verifies the echo, then recovery canonical32+END and its exact record, then repeats both stale controls, then end health. The sibling contributes R's extra one byte. No closed-primary late DATA is invented.

The serialized test independently checks exact outgoing headers/multiplicity/method/path/query/stream IDs, auxiliary GET+END, DATA byte sequences and END flags/frame ordinals, per-upload counters and incremental hashes, settings ACK count, terminal/reset count, paired retirement at first stale control, debt/window barrier before sibling DATA, recovery isolation and exact J/C/R. It uses bounded per-upload counters/digests and finite pending synthetic responses, not frame/read histories. Each receive has a finite 200-read bound; the final complete status collection remains 67 records plus metrics.

The first three test executions share one caller-owned synthetic application while using fresh connection contexts and selected-before state. They preserve all six new persistent records and validate untouched records; final collection runs after the third case. All peer records are **model-derived synthetic supplied input**, not independent fixture/native evidence. Actual public-client serialization, parsing, reset validation and credit/retirement accounting are exercised.

## RED/GREEN history and exact commands

The fixed environment used for all new schedule and final regression commands is:

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

Before any implementation/selection change, `test_application_error.py` was authored and copied to `evidence/b5d/initial-test.py`. The initial exact command was:

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_application_error.py
```

1. `initial-red.*`: exit1, empty stdout, traceback terminating in `ValueError: case schedule not implemented`. This proves selection rejection only, not behavioral RED.
2. Concrete schedule + selection/dispatch were then added while leaving the old adapter terminal handling unchanged. Exact source copies are `behavioral-red-source/`. The same command produced `behavioral-red.*`: exit1, empty stdout, trace through `application_error_cases.run -> adapter.finish -> receive`, ending `RuntimeError: missing finite synthetic response`.
3. Before fixing that terminal seam, each case ran independently with:

```sh
/home/codespace/.python/current/bin/python3 -B -S -c 'import sys; import test_application_error; test_application_error.check(sys.argv[1])' sink_error
/home/codespace/.python/current/bin/python3 -B -S -c 'import sys; import test_application_error; test_application_error.check(sys.argv[1])' invalid_progress
/home/codespace/.python/current/bin/python3 -B -S -c 'import sys; import test_application_error; test_application_error.check(sys.argv[1])' end_error
```

All three `red-<case>.*` receipts have exit1, empty stdout and the same finite-input exhaustion at `adapter.finish`, after serialized INTERNAL_ERROR2 was parsed and terminal status validated. This is behavioral RED for the deliberately unimplemented application-failure adapter completion policy; it is not a native hang or immutable-core defect.

4. Minimal application-failure terminal/code2 handling plus authorized inventory/import edits were applied. `green-attempt-1.*` using the original command exited0, empty stderr, all six positive executions and 64 exact synthetic negative rejections. No intervening behavioral failure or test-source correction occurred. The initial test and final test remain byte-identical.
5. All final 34 normal/optimized commands passed. The first metadata audit subsequently failed only because it counted distinct path strings rather than resolved files: `audit-attempt-1.*`, exit1, `RuntimeError: retained row or unique path count differs`. The failed receipt is preserved. The correction used `str(Path(item['path']).resolve())` for unique file identities; no module/test gate/source changed. Final `final-audit.*` is exit0, empty stderr.

Every RED/GREEN command has its exact environment/invocation in a `.command` receipt and separate stdout/stderr/exit. No failure was swallowed or reclassified as behavioral proof.

## Final verification and raw outcomes

After the last module edit, these exact command templates ran for each of the 17 test names below:

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/TEST.py
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/TEST.py
```

`TEST` was each of `test_adapter`, `test_admission`, `test_application_error`, `test_async`, `test_continue_quota`, `test_control_reset`, `test_credit`, `test_final`, `test_imports`, `test_large`, `test_metadata_concurrency`, `test_negative`, `test_pause`, `test_ready`, `test_selection`, `test_shared`, `test_time`. This covers every prior directly owned test because the shared terminal/dispatch/selection seams changed. **34 exits0, all stderr empty.** Normal and `-O` modes are Python optimization modes; no Zig optimization/build mode applies.

`evidence/b5d/final-commands.json` retains every exact command and stdout/stderr path. Each `final-<test>-{normal,optimized}.{command,stdout,stderr,exit}` retains raw evidence separately. Both import runs print exactly:

```text
AST and inert import checks passed
```

The new test prints 70 lines per mode: six positive executions (three shared application cases plus split-reset success for each) and 64 postimplementation synthetic negative-control rejections. Their exact raw output follows later in this report and is retained unchanged in both receipts. Controls cover accepted-prefix bytes/readiness/cancel state, terminal reason/metadata/accepted bytes/hash/end/cancel counters, failed-callback ordinal, diagnostic distinctions, stale reply/count, missing/excess refund, sibling echo, recovery metadata, premature final, forbidden successful primary final, wrong reset code, duplicate/missing reset and untouched-record contamination. These are sensitivity checks, not additional pre-fix RED or native fixture evidence.

The final snapshot/identity audit used the same pinned Python `-B -S` with inline caller-owned metadata checks: AST parse all27 modules; compare SHA256 of live modules to saved final copies and the released25 map; validate every final command exit/stderr; rehash all immutable rows and exactly ordered42 codec rows; resolve path aliases for unique file counts; verify implemented31/remaining9/final67; reject any source change during snapshot. Its raw output is:

```text
27 modules: 2 added, 7 changed, 18 unchanged, 0 removed against released B5c
119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate
118 file rows have 114 path spellings; helper absolute/relative aliases resolve to the same file
42 ordered codec identities and default-json aggregate match; no extra or missing codec paths
34 final normal/-O commands exit 0 with empty stderr; all-module AST and inert empty/foreign argv imports pass
maximum control depth <=3; new schedule depth=1; new test depth=2
31 source schedules; 9 rejected unsupported selections; final collection 67 records plus metrics
```

The existing actual inert-import test imports all27 modules under both empty and foreign argv with rejecting caller-owned doubles for file/socket/SSLContext/process/clock/console effects. Every module has its main guard; AST rejects authored classes/custom exceptions and assertion-based proof statements. The final nesting audit respects same-level `elif` and resets depth at function boundaries; all modules remain <=3. There is no new authored executable recorder/helper module outside the27 directly owned modules; temporary metadata checks were guarded inline Python, not new executable modules.

## Self-review and remaining facts

Self-review checked correctness, ownership, tests, documentation, then gate integrity. The application schedule's start helper earns its existence by binding canonical metadata and reset/healthy role-policy contracts. The prefix helper binds a finite observed checkpoint to exact accepted bytes and no premature terminal. Existing stale/refund helpers fit the contract unchanged. Shared adapter terminal handling preserves parser completeness, exact code validation in immutable wire, no-successful-primary-final validation, canonical completion and paired retirement. Existing public-cancel/peer-reset behavior remains covered by the unchanged source test and passing normal/-O regressions.

No unimplemented selection succeeds; nine remaining selections reject before effects. No assertion, rejection loop, budget, capacity, inherited deadline, source/model/fixture contract or threshold was lowered. The only failures after implementation were expected synthetic negative controls and the disclosed metadata normalization audit mistake. No actionable source defect or immutable API gap remains identified within this slice. Root's independent review is still required.

Parent note: B5 cases are **31/40 source-only if reviewed**. All nine B6 schedules; default/subset/aggregate/strict-close/owned-runner/runtime closure; separately released sequential two-child native acceptance; adoption; full project/platform/compliance gates; and unchanged full2.2.0/all40 milestone requirements remain required. No idle/active shutdown acceptance, combined40 execution or native evidence is earned by this subset.

## New test raw stdout (normal; optimized output is identical)

```text
sink_error passed: J=11 C=10 R=48
invalid_progress passed: J=11 C=10 R=48
end_error passed: J=10 C=9 R=65
sink_error passed: J=11 C=10 R=48
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
invalid_progress passed: J=11 C=10 R=48
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
end_error passed: J=10 C=9 R=65
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
preterminal_cancel rejected: record mismatch: cancels
terminal_chunks rejected: failure callback follows accepted prefix
early_final rejected: upload completed before resume
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
preterminal_cancel rejected: record mismatch: cancels
terminal_chunks rejected: failure callback follows accepted prefix
early_final rejected: upload completed before resume
chunk_diagnostic rejected: record mismatch: chunk_errors
progress_diagnostic rejected: record mismatch: invalid_progress
end_diagnostic rejected: record mismatch: end_errors

```
