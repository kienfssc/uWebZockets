# Task5e3b5d: application sink and end failures

Released after B5c source/publication review and immediate push of commit
94eb6b1f17c1baffea729edbc8b8db180ec9347a. The accepted25-module map is
docs/implement-2-2-0/evidence/m2_h2_combined_cancel_reset/manifest.json and
task-5e3b5c-root-final-audit.json; committed bytes/push are verified by
task-5e3b5c-root-commit-audit.json. Acceptedsource28/40; no native acceptance.
Read task-5e3b-release-addendum.md and task-5e3b5-brief.md for binding interfaces,
pinned tools and immutable inputs. Preserve original all40 and all milestone
requirements.

Use evidence/b5c/immutable-inputs.json for exact pinned codec_files ordered
42 rows, including non-Python metadata/licenses/type markers. Aggregate is
SHA256(json.dumps(rows).encode()) with default separators/spacing and retained
row order, not an inferred glob or compact JSON recipe. Retained119 identity
rows are114 unique entries (118 file rows/113 unique paths plus codec aggregate);
five source/helper paths repeat. Preserve both counts accurately.

Own concrete application-error schedules/tests, minimal actually-used existing
adapter/cases/import-check changes, evidence/b5d and task-5e3b5d-report.md.
Reuse B5c's earned terminal/reset/refund/stale-control/sibling seams only where
the actual contract fits. No forwarding-only abstraction or rewrite of prior
cases. Root authorizes explicit unsupported-count assertions12->9 with all
rejection checks intact and cases.py description31. Preserve prior source and
raw evidence. You are not alone; do not revert others. Root owns Git/public
delivery. No agents or external model CLI.

Located B5c interfaces: control_reset_cases.stale(context,receive,tag) checks
the exact expired pair; refund(context,receive,target) waits for legitimately
observed connection debt and public window. Its start helper selects public
cancel for a primary, so it does not fit application-failure primary creation.
adapter.start has an explicit role keyword; adapter.response_finished and
finish currently handle only public_cancel/peer_reset terminal policies/code8.
Extend those actual used seams minimally for application_failure/code2 while
preserving parser completeness, no-successful-primary-final validation,
wire.complete/retire and existing defaults. No immutable-core defect follows
from this intentionally unimplemented next policy.

## Exact contracts

Authoritative located source under .uwz-work/evidence/h2-streaming/:
integration-owned/application-error/cases.py,profile.zig, authenticated by
task-5e3b-input-audit.json; current combined model/fixture schema supersedes
legacy field aliases. Old run_live.py is a read-only source reference, never
an entrypoint to invoke. Use model.request_contract and canonical payloads.

| Case | Heads J | Small C | Request flow R |
| --- | ---: | ---: | ---: |
| sink_error | 11 | 10 | 48 |
| invalid_progress | 11 | 10 | 48 |
| end_error | 10 | 9 | 65 |

Each opens the same POST /echo sibling declared1 with its request body open,
then primary declared32
POST /limit/<tag>?case=<tag> with x-case=<tag>, application_failure policy.
Sink/error progress cases send7 bytes without END, observe accepted7/H7, ready,
begins1/ends0/cancels0 and no premature terminal. Then send the canonical first
8 bytes without END as the source does; do not silently replace this with an
offset7 span. The failing callback accepts no new bytes. End-error sends32
canonical bytes with END and has no preterminal status request.

Validate terminal records through model: sink/error progress accepted7,
cancels1/ends0/reason sink_failure and exact respective diagnostics; end-error
accepted32/ends1/end_errors1/cancels0/reason none. All primaries have exact
INTERNAL_ERROR2 and no fabricated successful response HEADERS. One terminal
callback only; end-error must never add a second cancel. Metadata persists
through callback unwind; stale generation controls are expired.

After terminal wire completion, send stale resume and cancel and expect exact
BodyControlExpired. Observe legitimate connection credit reclamation target15
for sink/progress failures or32 for end-error through canonical ledgers, no
replayed refunds/extra heads. Send sibling b's'+END, verify healthy echo, then
new recovery32 canonical bytes+END and its validated record, then repeat both
stale controls. Preserve all six new persistent records and untouched records
with selected-before/shared synthetic app/fresh contexts/final67+metrics.

The one-byte sibling contributes the extra R byte; do not invent late DATA to
a closed primary or infer an immutable API defect from an old conditional
warning. Any actual core gap requires a smallest failing pure call/source
requirement, while independent cases continue. No silent omission or lowered
budgets/capacities/deadlines/model/core/fixture mutation.

The accepted combined architecture requires start/end health on these cases.
Keep that established B5c wrapper and its actual request/primary bindings;
legacy family runner omission of final health does not change combined budgets.

Use one canonical wire/parser/request+response ledgers/output stage for every
request/DATA/SETTINGS/grant/reset/observation/retirement, exactly once. Preserve
fresh caller integer time/inherited deadlines, finite same-connection barriers,
bounded spans/captures/hashes and no whole-body/frame/read histories. Terminal
finishing must require exact policy/reset/parser invariants and paired retire.

## Proof and handoff

Begin actual serialized schedule tests before implementation and preserve
initial test/RED/intermediate failures with exact scope. Selection/API failure
is not behavioral RED. Independently check request multiplicity/order, actual
DATA bytes/END and sibling ordering, reset2/no primary success, source finite
checkpoints, stale/refund barriers, diagnostic distinctions and recovery
isolation. Model-derived supplied peer records remain synthetic input, not
independent fixture/native evidence. Qualify synthetic negative controls.

After last edits use exact pinned Python -B -S normal/-O covering changed-seam
regressions with raw stdout/stderr/exits, all-module AST and actual silent/inert
empty/foreign-argv rejecting-effect import proof, and final full module hashes
compared to released B5c. Every authored helper has main guard; no authored
classes/custom exceptions/assert proof/hidden mutable globals/dead code/deep
control flow. Prescribed graphify prefix precedes first source search/read.

No native/build/server/socket/SSLContext/TLS-close/real-clock/process ownership/
transfer/descriptor/kernel/fault/cancel/scheduling/race/panic/leak experiment,
old live entrypoint, dependency/product/model/core/fixture/Git/public edits or
other agents. Pure in-memory public-codec/reset/control tests only.

Write full report with exact contracts/APIs/files/source identities, commands/
raw outcomes/history, final snapshot, self-review and remaining facts. Append
parent note: B5 cases31/40 source-only if reviewed; B6/default/aggregate/runtime/
native/adoption/full milestones still required. Return concise DONE/report/
tests/real concerns. Independent Root review follows implementation.
