# Actual combined40 H2 run: read-only architecture handoff

Architect /root/architect_h2_live_acceptance. Read-only source/evidence planning;
no edits, imports, builds, tests or native/client operations. This is a proposed
future preparation contract, NOT a compilation/execution receipt. Task5d3 five
outputs remain separately in progress; preserve all prior evidence unchanged.

## Topology and fixed constraints

Existing task-5d-architecture.md196 requires two sequential freshly owned
children under ONE new combined run identity: idle baseline first, then main
active child ending shutdown_active. Root confirmed the existing interpretation.
No historical idle checkpoint counts as executing this new run. Audit child
ownership, input identities, counters, deadlines, cleanup and exit separately.
Main39IDs uses40TLS connections including disconnect replacement; idle1ID adds
one connection. Total40IDs/twochildren/41connections, not single-App all40.

Keep immutable candidatefc69, helper/codecs/compiler/override identities, native
8connections/8H2streams/73728receive payload/two applicationbindings. Retain three
producer contexts with8192scratch each and separate8192file scratch. Client8live
responses/send/read8192, aggregate traces, no upload/output DATA retention.
Ordinarycase30s, each100000000-byteupload180s (existing limits), ready15s,
whole900s, grace<=15 and remainingcase/whole deadline. No broadnative release.

Exactly67persistent diagnostic bodyrecords, separate from two reusable slots:
- Core2: large_declared,large_undeclared.
- Pause/control5: partial_pause,final_pause,begin_pause_empty,control_one,control_two.
- Admission22: empty_headers,empty_data,empty_declared,limit_declared,
  limit_undeclared,limit_declared_reject,limit_declared_recovery,
  limit_observed_reject,limit_observed_recovery,zero_declared_reject,
  zero_declared_recovery,zero_observed_reject,zero_observed_recovery,
  continue_ready,continue_paused,quota_holder_one,quota_holder_two,quota_refuse,
  quota_recovery_one,quota_recovery_two,begin_failure,begin_recovery.
- Credit/concurrency6: queued_trailers_padding,receive_credit,concurrent_hold,
  concurrent_refused,concurrent_upload,concurrent_recovery.
- Metadata1: metadata_helpers.
- Cancellation6: cancel_ready,cancel_ready_recovery,cancel_paused,
  cancel_paused_recovery,peer_reset,peer_reset_recovery.
- Applicationerrors6: sink_error,sink_error_recovery,invalid_progress,
  invalid_progress_recovery,end_error,end_error_recovery.
- Lifecycle12: disconnect,disconnect_recovery,reuse_0..reuse_8,shutdown_active.
- Output7: producer_reuse,producer_reuse_next,output_pressure_window,
  output_pressure_ready,stream_file,early_final_order,early_final_recovery.
No repeated standalone spare namespaces. Partial selection emits all67 with
unselected exact defaults. Candidate public APIs suffice; no product gap found.

Proposed child-capture bound: bodyJSON<=768/outputJSON<=1024/markerprefix<=64,
67*(768+64)+4*(1024+64)+2048=62144 <65536. Actual combined formatters/prefixes
must prove these bounds during preparation; no combined formatter exists yet.

## Newly specified finite schedule counts

J=request heads; C=small final responses, excludes five special outputs and
eight reset/transport-only targets; R=outgoing request DATA flow includingpadding.
Use start/end health for nonterminalcases, retainedinternalbarriers and replacement
health for disconnect. These are proposed exact schedule contracts, NOT measured
counts from earlier native checkpoints. Poll loops require source-proven ordered
barrier replacements before these counts can be adopted for execution.

| ID | J | C | R | Required result |
| --- | ---: | ---: | ---: | --- |
| ready_buffered | 5 | 5 | 257 | Exact buffered echo; sink totals unchanged |
| async_delayed | 3 | 3 | 0 | delayed-ok10/content-type/END; no invented middleware guarantee |
| large_declared | 5 | 5 | 100000000 | Declared exact count/SHA/onebegin/end |
| large_undeclared | 5 | 5 | 100000000 | Same without CL |
| partial_pause | 7 | 7 | 12289 | Accepted7/second queuedEOFbarrier/resumeFIFO |
| final_pause | 6 | 6 | 32 | Allaccepted/noENDuntilresume |
| begin_pause_empty | 6 | 6 | 0 | Nochunk/enduntilresume/emptySHA |
| control_rules | 20 | 20 | 64 | Twocompletions/callbackactive/notpaused/expirederrors |
| empty_headers | 3 | 3 | 0 | HEADERSemptyEOF/zero limit |
| empty_data | 3 | 3 | 0 | DATAemptyEOF/zero limit |
| empty_declared | 3 | 3 | 0 | Declaredzero |
| limit_declared | 3 | 3 | 32 | Exactlimit |
| limit_undeclared | 3 | 3 | 32 | Observedexactlimit |
| limit_declared_reject | 4 | 4 | 32 | CL33refusal/32recovery |
| limit_observed_reject | 5 | 5 | 65 | Accept32/reject33/32recovery |
| zero_declared_reject | 4 | 4 | 0 | CL1refusedbeforebegin/emptyrecovery |
| zero_observed_reject | 4 | 4 | 1 | Firstbytecancel/zeroaccept/emptyrecovery |
| continue_ready | 3 | 3 | 32 | Exactlyone100beforeupload/final |
| continue_paused | 5 | 5 | 32 | One100/pausedbarrier/resume/final |
| quota_refuse | 11 | 11 | 128 | Twoholders/refusedthird/tworecovery/fouractivebarriers |
| begin_failure_rollback | 4 | 4 | 32 | Failedbegin/nocancel/recovery |
| queued_trailers_padding | 6 | 6 | 12297 | Logical12289+padding8/trailerisolation |
| receive_credit | 7 | 7 | 65536 | Exhaust65535/controlhealth/resume/finalbyte |
| concurrent_routes | 13 | 13 | 96 | Pausedholder/refusal/othersuccess/recovery |
| metadata_helpers | 6 | 6 | 32 | 66headers/17captures/helpercontracts |
| cancel_ready | 12 | 11 | 40 | Accepted7/CANCEL/recovery/sibling |
| cancel_paused | 12 | 11 | 65 | Accepted7of32/CANCEL/recovery/sibling |
| peer_reset | 11 | 10 | 65 | Accepted0paused/peerreset/recovery/sibling |
| sink_error | 11 | 10 | 48 | Accepted7/rejected8/INTERNAL_ERROR/recovery/sibling |
| invalid_progress | 11 | 10 | 48 | Sameprefix/invalidprogress |
| end_error | 10 | 9 | 65 | Accepted32/enderror/nocancel/recovery/sibling |
| disconnect | 25 | 24 | 64 | Strictunwrap+EOFafter7/replacement/stalecontrols |
| reuse | 389 | 389 | 288 | Ninedistinct/36staleresume/36stalecancel |
| producer_reuse | 9 | 8 | 64 | A/Bonlinebindinggeneration/fullproducer |
| output_pressure_window | 8 | 7 | 33 | Zero/8192/remainder/realblockedoffsetbarriers |
| output_pressure_ready | 6 | 5 | 33 | Amplecredit/sibling/hashEND |
| stream_file | 7 | 6 | 33 | Range/CL/onceclose |
| early_final_order | 7 | 6 | 32 | Held403/8+9/ENDbeforeNO_ERROR/recoveryholder |
| shutdown_active | 71 | 70 | 32 | Lastactive/accepted7/presignal67rows+metrics/shutdowncancel |
| shutdown_idle | 69 | 69 | 0 | Firstchild/health67zerorowsmetrics/drainedshutdown |

Reuse389 =9new+9activebarrier+360staleoperation/status+9finalstatus+2health.
Stale360=36*2*5. Disconnectoriginal3heads/2small/R32,replacement22/22/R32;
require actual ssl_unwrap success then normal TCP EOF/peer_closed cause.
Main733heads/720small/5special/8reset-or-transport-only. Idle69/69.
Whole802heads/789small. Mainbufferedmiddleware733-67=666, idle69.

## Source-derived budgets and accounting

Per-case immutable budget data; never turn global65 into unrestricted flow.
Connectiondebt<=min(R,65535); eachstream<=min(sentflow,65535). Each valid positive
refund consumes specific known debt once in each scope; at most2Rrefundframes.
No debt crosses connections; retain/report late debt, do not requirezero by fiat.

Receivewire units: small45064=4105+4095+9*4096;
producer16799868=16777313+4105+9*2050;
file250044=24593+4105+9*24594; early4140=17+4105+9*2.
For Kconnections,SclientSETTINGS,Iexpected100,Zincomingresets:
B_rx=45064*C+special+39*K+9*S+26*R+4105*I+13*Z.
DefaultK=S=1; disconnectK=S=2; outputsK1/S2. OnlycontinuecasesI1.
Z1forsevenadmission/concurrencyrefusals, twopubliccancellations,
threeapplicationerrors, earlyfinal; otherwise0. All arithmeticcheckedu64.

| Case/stage | Conservative decryptedH2 byte ceiling |
| --- | ---: |
| Each100000000upload | 2600225368 |
| reuse | 17537432 |
| producer_reuse | 17162101 |
| output_pressure_window | 17116231 |
| output_pressure_ready | 17026103 |
| stream_file | 521343 |
| early_final_order | 275426 |
| shutdown_active includingfinal | 3155360 |
| idlechild | 3109464 |
| Whole | 5288609050 |

These are work ceilings, NOT expectedtraffic/retainedbuffers. Nonempty receive
consumes>=1budgetbyte. Preserve existing4096receive limits where applicable;
originallargeuploadreader had no suchcap. No failure-driven relaxation.
Finalcollection68responses:3064352+13*actualremainingdebt. Fullmainlastconnection
sent32, debt<=64, final<=3065184. Partialendinglargeupload debt<=131070 and
final<=4768262. Preserveparser/ledgers/existingcasedeadline acrossfinalboundary.
Outboundheaderblock<=8192/HEADERSseparate, DATA<=8192logical andbothwindows,
positiveDATAframes<=R plusenumeratedzeroDATA. Trailersonlyqueued/metadatacases.
Responsegrantsexactonce/boundedactualbytes+startup/primarygrants.
data_to_send(amount=8192), aggregatesonly. Actualhelperstartupbytecount still
requires pure serialization during preparation; not established by architect.

## Selected-subset record model and aggregate targets

For eachsubset derive touchedtags andsumindependentexpectedrecords, notwhatever
happenedtofinish. Tablefields: bodyheads/attempts/successfulbegins/endinvocations/
cancels/acceptedbytes. Ends includesone end_error invocation.

| Family | Heads | Attempts | Begins | Ends | Cancels | Accepted |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Core | 2 | 2 | 2 | 2 | 0 | 200000000 |
| Pause/control | 5 | 5 | 5 | 5 | 0 | 12385 |
| Admission | 22 | 19 | 18 | 16 | 2 | 384 |
| Credit/concurrency | 6 | 5 | 5 | 5 | 0 | 77921 |
| Metadata | 1 | 1 | 1 | 1 | 0 | 32 |
| Cancellation | 6 | 6 | 6 | 3 | 3 | 110 |
| Applicationerrors | 6 | 6 | 6 | 4 | 2 | 142 |
| Lifecycle | 12 | 12 | 12 | 10 | 2 | 334 |
| Output | 7 | 6 | 6 | 6 | 0 | 192 |
| Fullmainpostdeinit | 67 | 62 | 61 | 52 | 9 | 200091500 |

Onefailedbegin/oneenderror/onechunkerror/oneinvalidprogress. Presignal8cancels,
oneactivepausedbinding; post9cancels/bothslotsinactive. MainR200091899; difference
399fromaccepted isbuffered/sibling/padding/rejected-or-unacceptedprefixes.
Outputlogical3*16777313+24593+17=50356549. EachlargeuploadSHA
190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2.
No concatenatedhash substitutes. Partialwithoutshutdown_active appends68final
responses/ordinaryidleteardown but doesnotcountshutdown_idle ID. Rejectduplicate/
unknownselections andactive shutdownanywhereexceptlast.

Preserve per-family metadata/callback contracts: pause/controlchecks==2*(1+chunks)
andtwo terminalchecks; metadata66headers/17captures/BodyNotBuffered/untouchedissue/
allocatorzero/beginendhelpers/trailerisolation; initialmethod/path/query/tag/header
comparisons andstalecontrols; producerborrowlifetime/ownedcopies/noRequestretention;
Bactualbinding==Aindex/genA+1, notinitialgen1incombinedrun. Producer2049writes/
oneend/Nhash/errors0/actualcounteralgebra, onlyAafterreuse>=1. Fileboundedrange/
closeonce/nodeinitdouble/noexactreadcount. Unselectedfilecallerowneduntilcleanup.
Returned-errorownership remainsseparateevidence, no newnativefaultprobe.

## Concrete gaps and ordered preparation

1. Combinedcontractdata first:40IDs/67tags/subsets/exactschedules/budgets/topology.
   Verification withprotocol/DX guidance. Acceptance: proposedfull/partial totals,
   rejectduplicates/unknowns/shutdownordering. Resolve finitebarriers fromsource.
2. Combinedfixture: currentoutputmodules plusretainedcore/pause/admission/credit/
   metadata/lifecyclebehaviors in cohesive modules/two sharedslots. Currentoutput
   onlysevenusedtags/32records/fixedindexmetadata cannot runcombined. Proveactual
   formatter/log bounds, thennewDebug/RScompile receipts/currentimmutableinputs.
3. Combinedclient: earnedaction-observationseam pairsactualpublicH2actions andboth
   ledgers/framing/terminalaccounting; deletionduplicatesordering/refunds/reset/
   boundedextraction acrossfamilies. ReuseactualTask5d3afterreview, lifecycle
   run_live/runner_adapter/strict_close/lifecycle_cases. Currentgaps:
   - request_credit globalMAX_REQUEST_FLOW65 needsper-caseflowbounds.
   - output_stage onlyoutputkinds/A32/final33/debt130/noactivefinal; needsexplicit
     ordinary/Continue/reset/transportpolicies andnarrowactivefinal68contract.
   - response_credit retiresonlyEND; reset/outgoingpeerreset/transportterminals
     need explicit pairedretirement semantics.
   - strict_close.observe_shutdown callswirewithoutnewledgers thenlegacyaggregated
     refunds; replacewith authoritative rawpath once.
   - oldstatuspolls do notproveexactrequestcounts; enumerate/provebarriers first.
   - asynccompletionneverpromisedretainedmiddlewareheader; preserveliteralcontract.
   Purepublic-codecproof forContinue/reset/latecredit/largeflow/final68/strictclose.
4. Freezeactualfixture/runtime/compiler/helper/codecs/loader/env; controlledactual
   ownedinputmutationreject/restore; freshindependentreview. No currentcombined
   formatter/layout/startupbytes/buildreceipt/closure exists. Stop beforeexecution.
5. SeparatelaterRootrelease newtwo-childall40attempt; bothfreshchildren/allIDs/
   exactbyteshashcallbacksbudgets/Appdeinit/keyremoval/exit0/reap. Forcedcleanup,
   omittedcase/deadlinewidening/unreviewedinput failcombinedclaim. Fullquality/
   platform/fuzz/package/compliance/adoption remainoutstanding.

Source API locators: candidate router/app.zig772route_body,940route_context,
978get_context,988get_async,1385listen,1519run,1549catch_shutdown_signals;
http/request_body.zig10-97binding/sink/route/control; http/response.zig281delay,
504file,584/628/642producer. These are locators, not execution proof.
