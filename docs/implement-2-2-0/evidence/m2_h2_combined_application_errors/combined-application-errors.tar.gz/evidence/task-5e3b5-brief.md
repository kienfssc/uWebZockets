# Task5e3b5: credit, metadata, controls and application errors

Continue the unchanged all40 plan from reviewed/pushed B4
fa6af7513b888f2bea113919c602db8e445bf5a7. Twenty-one schedules are earned;
implement the next ten finite cases using the existing bound adapter/core.
Read task-5e3b-release-addendum.md and linked original brief for exact global
interfaces and execution limits. Preserve B1..B4 source/proof and all40 scope.

## Ownership, inputs and process

Own concrete new schedule/test modules in the existing combined-cases directory,
minimal actual-used adapter/cases/import-check/helper changes, evidence/b5/
and task-5e3b5-report.md here. Root authorizes necessary explicit unsupported-
count assertions19->9 in existing test_pause.py,test_admission.py and
test_continue_quota.py, preserving assertions and rejection checks. Include
every edited module in final comparison/covering checks. Root owns Git/public
delivery. You are not alone; preserve others' work. No agents/external modelCLI.

Current18-module map is the B4committed manifest and
task-5e3b4-root-completion-audit.json. Immutable model/catalogue:
/tmp/uwz-task5e1-contract-v3; v9core:/tmp/uwz-task5e3a-snapshot-v9/source;
combined fixture source-only:/tmp/uwz-task5e2-Fix1Final2/fixture. Exact pinned
helper/codecs/Python and all41 final source identities are in the release
addendum/task-5e3b-input-audit.json.

Use final corrected family sources, not pre-fix copies:
- integration-owned/credit/fix1/cases.py,profile.zig,run_live.py;
- integration-owned/metadata/cases.py,profile.zig;
- integration-owned/lifecycle-control/cases.py,profile.zig;
- integration-owned/application-error/cases.py,profile.zig.
Those paths are under .uwz-work/evidence/h2-streaming/. They are source-only
authority for exact requests/controls/statuses/reset codes/diagnostics, not
entrypoints to execute. The combined model/current fixture schema supersedes
old field aliases. Keep accepted architecture and finite barrier handoff.

Run the release-addendum graphify query prefix before the first source search/
read in this task, including provided sources, and retain its outcome. Use the
exact pinned Python path with -B -S for every Python invocation, including
editing/metadata scripts. Do not repeat B4's disclosed invocation/search-order
deviations. No install/fetch/native operations or old live entrypoint execution.

## Exact cases

| Case | Heads J | Small C | Request flow R |
| --- | ---: | ---: | ---: |
| queued_trailers_padding | 6 | 6 | 12297 |
| receive_credit | 7 | 7 | 65536 |
| concurrent_routes | 13 | 13 | 96 |
| metadata_helpers | 6 | 6 | 32 |
| cancel_ready | 12 | 11 | 40 |
| cancel_paused | 12 | 11 | 65 |
| peer_reset | 11 | 10 | 65 |
| sink_error | 11 | 10 | 48 |
| invalid_progress | 11 | 10 | 48 |
| end_error | 10 | 9 | 65 |

Preserve all19 new persistent model records with exact diagnostics, terminal
reasons/callback/helper/capture/trailer/middleware fields and recovery tags.

Credit/trailers: preserve exact padding including its request-flow charge,
queued trailer retention, observe-once/paused FIFO contract, and source resume
order. Receive-credit has one DATA-bearing upload stream,65536logical bytes,
legitimate window exhaustion/refunds and independent connection/aggregate-stream
debt bounded65535. Do not spend one scope's credit as the other or invent grant
frames. Keep exact finite status/metrics/resume barriers and no extra heads.

Concurrent routes: preserve holder/refusal/independent healthy route/recovery
isolation on one connection and unchanged capacities. Metadata: preserve exact
method/path/query/header/capture/trailer/helper contracts from final source,
including overflow/refusal/helper timing and indexed metadata retention. Do
not invent exposed body-token generation; actual producer-binding generation
proof is later B6. Use model request construction/validators and current schema.

Controls/errors: preserve actual public cancellation and outgoing peer reset
CANCEL8, source application-error INTERNAL_ERROR2, exact absent/present response
headers and no fabricated successful primary response. C differs from J for
these reset-primary cases. Preserve source DATA/END/late-data order and full R,
metadata through callback unwind, no duplicate terminal/refund, stale controls
and unaffected recovery/sibling records. Existing explicit status/policy,
complete/keep/retire seams remain authoritative.

Every HEADERS/DATA/trailer/SETTINGS/grant/reset/observation/retirement must pair
once through existing wire/parser/request+response ledgers/stage. Do not encode
a required late DATA action outside that seam or reduce R to bypass a closed-
stream limitation. If an immutable core API genuinely cannot express a source-
required action, report its smallest failing pure call/required behavior to
Root and continue independent cases. Preserve allten requirements; no silent
omission, fake successful handler, alternate parser/refund replay, core/model/
fixture/product/dependency mutation or lowered counts/bounds/capacities/deadlines.

Keep fresh caller integer time at all actual actions/read/drain/final points,
inherited case/whole deadlines, bounded spans/captures/hashes and no whole
upload/output or per-DATA/read history. Finite barriers flush prior actions,
make one same-connection observation and fail on mismatch, without polling.
Pure reset/control requests and supplied transport records are allowed; no
native cancellation/fault/scheduler experiments are released.

Extend explicit supported selection to31cases, rejecting remaining9 before
actions. Full40/default/aggregate/native acceptance remains later work.
Prove shared synthetic app/selected-before state across fresh connection
contexts and existing67-status-plus-metrics collection, all19 selected records
and untouched records. No partial subset earns idle/active shutdown acceptance.

## Focused proof and report

Use behavior-first narrow RED/GREEN and actual in-memory public codecs. Retain
initial test source, real RED and every intermediate failure with exact scopes.
Selection-only or missing-API failures stay qualified; missing files/deliberate
mutations are not behavioral RED. Do not invent a failure for the narrative.

Independently check actual serialized headers/multiplicity/method/path/query,
DATA/padding/END/trailer/reset ordinals, hashes/lengths, distinct credit scopes,
paused/EOF/control ordering, error status/reset codes and recovery isolation.
Use bounded ordinal/counter checks, not retained frame histories. Target
negative checks at those named invariants and qualify post-implementation
synthetic sensitivity controls. No model-derived synthetic record is native
fixture evidence or an independent server implementation.

Capture each final relevant command's stdout/stderr/exit separately under
evidence/b5 with exact pinned normal/-O invocation after the last edit. Cover
changed prior adapter/selection seams and retain existing B1..B4 regressions;
do not rerun unrelated suites. Snapshot all directly owned modules/hashes with
exact comparison against B4. Every authored executable helper, including a new
recorder, needs a main guard and actual empty/foreign-argv silent/inert import
proof with rejecting effect doubles. No authored classes/custom exceptions/
inheritance/assert proof statements, hidden mutable globals, dead code or
nesting beyond3 levels. Keep modules cohesive; no speculative framework.

No native build/server/socket/SSLContext/TLS-close/process ownership/transfer/
descriptor/kernel/fault/cancel/scheduling/race/panic/leak/real-clock experiment.
No agents, external modelCLI, Git or public delivery edits. Root alone releases
any later exact native work. Write complete report with source/APIs/files,
commands/results/history, identities/self-review and real remaining facts.
Append short parent note, all40incomplete; return concise DONE/concerns/report/
testsummary. Root reviews before publication/commit/next unit.
