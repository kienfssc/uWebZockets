# Task5e3b release and exact interfaces

RELEASED after source/fix/publication reviews passed and commit
e8cc957e1a22022de13fd342c46db6e4c2831825 was immediately pushed to fork.
This addendum and task-5e3b-cases-pending-brief.md together are the complete
requirements. The pending heading in the older brief is superseded only by
this explicit release. All40 cases and all stated acceptance remain required.

Own NEW .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/,
NEW /tmp/uwz-task5e3b-* and task-5e3b-report.md in this plan workspace.
Preserve the core, model, fixture, product, dependencies and all old cases.
Root owns source fixes, independent review, delivery and Git. One implementer
at a time; no agents, external model CLI, commits, refs, pins or pushes.

Read task-5e3b-input-audit.json: Root has just matched all41 retained source
identities to the reviewed model publication book and all19 current runtime
files to the public output-driver manifest. The list includes corrected
admission/fix1, pause-control/fix1, credit/fix1, metadata, cancellation and
application-error source. Lifecycle helpers are authenticated under
/tmp/uwz-task5c3-runtime-v2. Old top-level/pre-fix copies are not authority.
These and /tmp/uwz-task5d3-runtime-v5 are source references only: do not invoke
old live entrypoints, real networking/constructors/close helpers or tests.

Immutable core: /tmp/uwz-task5e3a-snapshot-v9/source,26files, map in
task-5e3a-publication-source.json and the committed archive's source/current.
Archive SHA74c1f96d1334d7e87b8f0e5fbeacfd39539d44c16e7fa6cb7702371e1dba442a.
Use /tmp/uwz-task5e1-contract-v3 model/catalogue as immutable modules, not a
second copied model. Exact identities are in task-5e1-publication-source.json.
The current compiled-only fixture /tmp/uwz-task5e2-Fix1Final2/fixture has25
canonical files; maps/receipts are task-5e2-root-fix-1-audit.json. No compile
or fixture execution is released.

Pinned helper is .uwz-work/evidence/h2-streaming/integration-client/h2_client.py
SHA07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00.
Pinned42 codec files are /tmp/uwz-h2-client-tooling/packages, digest
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Use /home/codespace/.python/current/bin/python3 with -B -S, normal/-O.
No install/fetch, source mutation or real socket/TLS/SSLContext operation.

The reviewed wire.py is the sole public-codec action/observation seam. Create
caller-owned request-credit case and output-stage case state; disconnect
shares each case object across its two independent connection states. Bind
codec/raw/request/response/records to stage with wire.bind_connection.
wire.startup consumes an already initiated helper-shaped codec; never initiate
it twice. wire.start_request returns streamID and <=8192 header chunks, which
must be flushed before the next observation/action. wire.drain returns<=8192.
Pair settings/DATA/trailers/grants/reset, wire.accept/retire, enter_final/
finish_final and staged termination once. The case adapter may add concrete
schedule invariants; no forwarding-only layer, alternate parser or duplicate
aggregate-refund application is acceptable.

Source-selected status/reset/hold/middleware expectations belong to these
schedules. Preserve public cancellation/outgoing peer-reset CANCEL8,
application-failure INTERNAL_ERROR2 and ordered final-before-NO_ERROR0 for
refusals/early final according to retained sources. Preserve each exact HTTP
status; do not infer it from a response role. Optional retained-middleware
policy is only for the source-supported async response. Required pauses and
output pressure need explicit no-END-before-resume/grant checks. If the core
cannot express a source-required invariant, report the smallest exact gap to
Root and continue independent cases. Do not mutate core state to bypass the
seam, weaken a bound, omit a case or silently accept an unsupported action.

Use the canonical <=8192 payload generator and exact SHA for both logical
100000000-byte cases, not the previous flow-only test's zero block. Preserve
separate output/file/body hashes. Use consistent caller-supplied integer
monotonic time units: convert catalogue seconds once and retain case/whole
deadlines through final collection and disconnect replacement. No real clock
read is released. New callbacks/hooks/tests are caller-owned pure operations
or in-memory public codecs; actual process/socket/TLS/close ownership is later.

Keep the saved accepted combined architecture and finite barrier handoff;
do not repeat whole architecture or the previous five-output native proof.
No runtime/close adapter execution or native build/run/probe is released.
All40 schedules, default/subset semantics and exact counts must be implemented
and independently reviewed before subsequent runtime preparation is accepted.

Load AGENTS/CODING and narrow TDD/API/verification skills first. Every authored
executable helper has a main guard and actual silent/inert import proof under
empty/foreign argv with rejecting caller-owned doubles. No authored classes,
inheritance/custom exception classes or assertion-based proof statements,
including auxiliary temporary recorders. Keep snapshots small/immutable.
Write full task-5e3b-report.md with APIs, changed files, source identities,
exact commands/raw outcomes, new-behavior RED/GREEN, intermediate failures,
final snapshot, self-review and remaining facts; return only short status,
report location, test summary and concerns. Never claim synthetic or pure
codec results as native fixture output or combined40 acceptance.

You are not alone; do not revert/edit others' work. Graphify before new
codebase searches; provided paths are already located. Prefix:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
