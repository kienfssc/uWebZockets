"""Application callback failures with exact reset, stale-control and refund barriers."""
import json
import adapter
import control_reset_cases
import model
import pause_cases


def start(context, tag, primary):
    contract = model.request_contract(tag)
    return adapter.start(context, contract['method'], contract['target'],
                         [('content-length', str(contract['declared'])), ('x-case', contract['x-case'])],
                         False, primary, 4095, role='reset' if primary else 'small',
                         policy='application_failure' if primary else 'healthy')


def prefix(context, receive, stream, tag):
    observed = pause_cases.status(context, receive, tag)
    pause_cases.pending(context, stream)
    raw = context['raw']['streams'][stream]
    if raw['end'] or raw['reset'] or raw['peer_reset']:
        raise ValueError('primary terminal before failing callback')
    expected = model.record(tag, True, 'after')
    expected.update(bytes=7, sha256=model.H7, chunks=1, max_span=7, cancels=0, ends=0,
                    chunk_errors=0, invalid_progress=0, active=True, reason=None, stale_resume=0, stale_cancel=0)
    model.validate_item(observed, expected)


def run(context, receive):
    tag = context['stage']['case']
    adapter.health(context, receive)
    sibling = adapter.start(context, 'POST', '/echo', [('content-length', '1')], False, False, 1)
    primary = start(context, tag, True)
    if tag == 'end_error':
        adapter.send_data(context, primary, model.payload_span(32, 0, 32), True)
    else:
        adapter.send_data(context, primary, model.payload_span(32, 0, 7), False)
        prefix(context, receive, primary, tag)
        adapter.send_data(context, primary, model.payload_span(32, 0, 8), False)
    terminal = pause_cases.status(context, receive, tag)
    expected = model.record(tag, True, 'after')
    expected.update(stale_resume=0, stale_cancel=0)
    model.validate_item(terminal, expected)
    result = adapter.finish(context, primary, receive)
    if result['headers'] is not None or result['ended'] or result['bytes'] or result['reset'] != 2:
        raise ValueError('primary application reset response differs')
    control_reset_cases.stale(context, receive, tag)
    control_reset_cases.refund(context, receive, 32 if tag == 'end_error' else 15)
    adapter.send_data(context, sibling, b's', True)
    result = adapter.finish(context, sibling, receive)
    if result['body'] != b's' or result['bytes'] != 1:
        raise ValueError('sibling echo differs')
    recovery_tag = tag + '_recovery'
    recovery = start(context, recovery_tag, False)
    adapter.send_data(context, recovery, model.payload_span(32, 0, 32), True)
    result = json.loads(adapter.finish(context, recovery, receive)['body'])
    model.validate_item(result, model.record(recovery_tag, True, 'after'))
    control_reset_cases.stale(context, receive, tag)
    adapter.health(context, receive)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
