"""Partial selection final collection uses the existing codec seam."""
import test_ready


if __name__ == '__main__':
    test_ready.check('ready_buffered', final=True)
