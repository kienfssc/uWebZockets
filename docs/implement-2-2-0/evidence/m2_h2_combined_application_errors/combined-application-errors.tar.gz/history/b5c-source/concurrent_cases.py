"""Finite route-isolation schedule retaining the refused stream through recovery."""
import json
import adapter
import credit_cases
import model
import pause_cases


def start(context, tag):
    contract = model.request_contract(tag)
    headers = [('content-length', str(contract['declared']))]
    if contract['metadata'] is not None:
        headers.append(('x-metadata', contract['metadata']))
    refused = tag == 'concurrent_refused'
    if refused:
        headers.append(('expect', '100-continue'))
    hold = tag == 'concurrent_hold'
    return adapter.start(context, contract['method'], contract['target'], headers, False, hold,
                         0 if refused else 4095, held=hold, status=503 if refused else 200,
                         policy='refusal_after_final' if refused else 'healthy')


def active(context, receive):
    actual = adapter.metrics(context, receive)
    items = model.records(context['selected_before'], 'before')
    items['concurrent_hold'] = model.checkpoint('concurrent_hold', 'paused')
    items['concurrent_refused'] = model.record('concurrent_refused', True, 'after')
    upload = model.record('concurrent_upload', True, 'after')
    upload.update(bytes=0, sha256=model.EMPTY_HASH, chunks=0, max_span=0, ends=0,
                  active=True, metadata_end=0)
    items['concurrent_upload'] = upload
    for field in model.COMMON_COUNTERS + ('bytes',):
        if actual[field] != sum(item[field] for item in items.values()):
            raise ValueError('concurrent metrics mismatch: ' + field)
    previous_heads = sum(adapter.catalogue.case_budget(case)['heads'] for case in context['selected_before'])
    if (actual['active'], actual['paused'], actual['slot0_active'], actual['slot1_active'],
            actual['buffered_middleware']) != (2, 1, True, True,
            previous_heads + context['stage']['case_state']['heads'] - actual['middleware']):
        raise ValueError('concurrent active barrier differs')


def finish(context, receive, stream, tag):
    model.validate_item(json.loads(adapter.finish(context, stream, receive)['body']), model.record(tag, True, 'after'))


def run(context, receive):
    adapter.health(context, receive)
    hold = start(context, 'concurrent_hold')
    adapter.send_data(context, hold, model.payload_span(32, 0, 16), False)
    paused = credit_cases.barrier(context, receive, hold, 'concurrent_hold')
    refused = start(context, 'concurrent_refused')
    adapter.finish(context, refused, receive, keep=True)
    upload = start(context, 'concurrent_upload')
    active(context, receive)
    adapter.send_data(context, upload, model.payload_span(32, 0, 32), True)
    finish(context, receive, upload, 'concurrent_upload')
    adapter.health(context, receive)
    if credit_cases.barrier(context, receive, hold, 'concurrent_hold') != paused:
        raise ValueError('independent upload changed paused holder')
    credit_cases.resume(context, receive, hold, 'concurrent_hold')
    actual = pause_cases.status(context, receive, 'concurrent_hold')
    expected = model.record('concurrent_hold', True, 'after')
    expected.update(bytes=16, sha256=model.digest(32, 0, 16), chunks=None, max_span=None,
                    ends=0, active=True, paused=False, metadata_end=0)
    model.validate_item(actual, expected)
    pause_cases.pending(context, hold)
    adapter.send_data(context, hold, model.payload_span(32, 16, 16), True)
    finish(context, receive, hold, 'concurrent_hold')
    recovery = start(context, 'concurrent_recovery')
    adapter.send_data(context, recovery, model.payload_span(32, 0, 32), True)
    finish(context, receive, recovery, 'concurrent_recovery')
    adapter.health(context, receive)
    adapter.retire(context, refused)
    adapter.health(context, receive)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
