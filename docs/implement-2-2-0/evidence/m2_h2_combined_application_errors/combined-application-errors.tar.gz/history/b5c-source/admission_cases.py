"""Finite empty-body, limit and refusal schedules over the bound wire seam."""
import json
import adapter
import model


def start(context, tag, primary, end_stream, refusal=False, expect=False):
    contract = model.request_contract(tag)
    headers = []
    if contract['declared'] is not None:
        headers.append(('content-length', str(contract['declared'])))
    if expect:
        headers.append(('expect', '100-continue'))
    return adapter.start(context, contract['method'], contract['target'], headers, end_stream,
                         primary, 0 if refusal else 4095, status=413 if refusal else 200,
                         policy='refusal_after_final' if refusal else 'healthy')


def complete(context, receive, stream, tag):
    result = json.loads(adapter.finish(context, stream, receive)['body'])
    model.validate_item(result, model.record(tag, True, 'after'))


def accepted_prefix(context, receive, stream, tag):
    observed = json.loads(adapter.get(context, '/status/' + tag, receive)['body'])
    record = context['records'][stream]
    if record['headers'] is not None or record['ended'] or record['reset_event']:
        raise ValueError('refusal before accepted-prefix barrier')
    expected = model.record(tag, True, 'after')
    expected.update(cancels=0, active=True, reason=None)
    model.validate_item(observed, expected)


def run(context, receive):
    case = context['stage']['case']
    adapter.health(context, receive)
    if case in ('empty_headers', 'empty_data', 'empty_declared', 'limit_declared', 'limit_undeclared'):
        end = case in ('empty_headers', 'empty_declared')
        stream = start(context, case, True, end)
        if case == 'empty_data':
            adapter.send_data(context, stream, b'', True)
        elif case.startswith('limit_'):
            adapter.send_data(context, stream, model.payload_span(32, 0, 32), True)
        complete(context, receive, stream, case)
        adapter.health(context, receive)
        return
    declared = case in ('limit_declared_reject', 'zero_declared_reject')
    stream = start(context, case, True, False, refusal=True, expect=declared)
    if not declared:
        if case == 'limit_observed_reject':
            adapter.send_data(context, stream, model.payload_span(32, 0, 32), False)
            accepted_prefix(context, receive, stream, case)
        adapter.send_data(context, stream, b'x', False)
    adapter.finish(context, stream, receive, keep=True)
    recovery = case.replace('_reject', '_recovery')
    empty = recovery.startswith('zero_')
    good = start(context, recovery, False, empty)
    if not empty:
        adapter.send_data(context, good, model.payload_span(32, 0, 32), True)
    complete(context, receive, good, recovery)
    adapter.health(context, receive)
    adapter.retire(context, stream)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
