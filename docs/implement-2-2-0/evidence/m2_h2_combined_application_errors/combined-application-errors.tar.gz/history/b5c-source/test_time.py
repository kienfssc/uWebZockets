"""Caller-owned time guards reads, serialization, drains and final boundaries."""
import adapter
import h2_client
import test_ready


def rejected(call, *args):
    try:
        call(*args)
    except ValueError:
        return
    raise RuntimeError('invalid caller time accepted')


def check():
    current = [1]
    sent = []
    context = adapter.open_case('ready_buffered', h2_client.new_protocol(), sent.append,
                                1, 10, 20, clock=lambda: current[0])
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    current[0] = 2
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), 2)
    before = len(sent)
    current[0] = 10
    rejected(adapter.flush, context)
    rejected(adapter.start, context, 'POST', '/echo', (), False, False, 257)
    if len(sent) != before or context['stage']['case_state']['heads'] != 0:
        raise RuntimeError('expired header or drain acted')
    for value in (True, '3', None, -1, 1):
        current[0] = value
        rejected(adapter.flush, context)
    current[0] = 3
    stream = adapter.start(context, 'POST', '/echo', (), False, False, 257)
    sent_before = len(sent)
    current[0] = 10
    rejected(adapter.send_data, context, stream, b'x', True)
    calls = []
    rejected(adapter.finish, context, stream, lambda: calls.append('read'))
    if len(sent) != sent_before or calls or context['request']['case']['sent'] != 0:
        raise RuntimeError('expired DATA or read acted')
    current[0] = 4
    adapter.send_data(context, stream, b'x', True)
    if context['request']['case']['sent'] != 1:
        raise RuntimeError('increasing time control failed')

    whole_now = [1]
    whole_sent = []
    whole_context = adapter.open_case('ready_buffered', h2_client.new_protocol(), whole_sent.append,
                                      1, 10, 10, clock=lambda: whole_now[0])
    whole_now[0] = 10
    rejected(adapter.flush, whole_context)
    if len(whole_sent) != 1:
        raise RuntimeError('whole deadline allowed a send')

    value = [2]
    target = [None]
    def clock():
        if target[0] is not None and target[0]['stage']['final']:
            return target[0]['stage']['case_deadline']
        return value[0]

    def after_case(case_context, receive):
        target[0] = case_context
        stage = case_context['stage']
        deadlines = stage['case_deadline'], stage['whole_deadline']
        heads = stage['case_state']['heads']
        reads = []
        def guarded_receive():
            reads.append(True)
            return receive()
        value[0] = stage['case_deadline']
        rejected(adapter.final_collection, case_context, guarded_receive)
        if stage['final'] or stage['case_state']['heads'] != heads:
            raise RuntimeError('expired final boundary acted')
        value[0] = 3
        rejected(adapter.final_collection, case_context, guarded_receive)
        if reads or not stage['final'] or stage['case_state']['heads'] != heads or deadlines != (stage['case_deadline'], stage['whole_deadline']):
            raise RuntimeError('expired final observation acted')

    test_ready.check('ready_buffered', clock=clock, after_case=after_case)
    print('fresh time checks passed')


if __name__ == '__main__':
    check()
