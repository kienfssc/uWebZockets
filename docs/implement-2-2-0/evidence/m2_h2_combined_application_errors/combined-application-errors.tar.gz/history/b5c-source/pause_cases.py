"""Finite pause and control schedules over the reviewed wire seam."""
import json
import adapter
import model
import output_stage


def status(context, receive, tag):
    return json.loads(adapter.get(context, '/status/' + tag, receive)['body'])


def control(context, receive, action, tag, expected, resume_stream=None):
    stream = adapter.start(context, 'GET', '/control/' + action + '/' + tag, (), True, False, 64)
    if resume_stream is not None:
        output_stage.resume(context['stage'], resume_stream)
    reply = adapter.finish(context, stream, receive)['body']
    if reply != expected.encode():
        raise ValueError('control result differs')


def pending(context, stream):
    record = context['records'][stream]
    if record['ended'] or record['headers'] is not None or record['reset_event']:
        raise ValueError('upload completed before resume')


def upload(context, tag, primary, held=False):
    contract = model.request_contract(tag)
    return adapter.start(context, contract['method'], contract['target'], (), False, primary, 4095, held=held)


def complete(context, receive, stream, tag):
    result = json.loads(adapter.finish(context, stream, receive)['body'])
    model.validate_item(result, model.record(tag, True, 'after'))
    if status(context, receive, tag) != result:
        raise ValueError('terminal status differs')
    return result


def pause(context, receive, tag):
    size = {'partial_pause': 12289, 'final_pause': 32, 'begin_pause_empty': 0}[tag]
    stream = upload(context, tag, True, held=True)
    first = 8192 if tag == 'partial_pause' else size
    adapter.send_data(context, stream, model.payload_span(size, 0, first) if first else b'', tag != 'partial_pause')
    observed = status(context, receive, tag)
    pending(context, stream)
    model.validate_checkpoint(tag, observed, 'paused')
    if tag == 'partial_pause':
        adapter.send_data(context, stream, model.payload_span(size, first, size - first), True)
        second = status(context, receive, tag)
        pending(context, stream)
        if observed != second:
            raise ValueError('queued EOF changed paused record')
    control(context, receive, 'resume', tag, 'ok', resume_stream=stream)
    complete(context, receive, stream, tag)


def active_record(tag, actual):
    expected = model.record(tag, True, 'after')
    expected.update(bytes=0, sha256=model.EMPTY_HASH, chunks=0, max_span=0,
                    ends=0, active=True, callback_checks=2, terminal_checks=0)
    model.validate_item(actual, expected)


def controls(context, receive):
    first = upload(context, 'control_one', True)
    before = status(context, receive, 'control_one')
    active_record('control_one', before)
    control(context, receive, 'resume', 'control_one', 'BodyNotPaused')
    model.validate_unchanged_control('BodyNotPaused', 'BodyNotPaused', before, status(context, receive, 'control_one'))
    adapter.send_data(context, first, model.payload_span(32, 0, 32), True)
    one = complete(context, receive, first, 'control_one')
    second = upload(context, 'control_two', False)
    before_two = status(context, receive, 'control_two')
    active_record('control_two', before_two)
    for action in ('resume', 'cancel'):
        control(context, receive, action, 'control_one', 'BodyControlExpired')
    if status(context, receive, 'control_one') != one or status(context, receive, 'control_two') != before_two:
        raise ValueError('stale control mutated record')
    adapter.send_data(context, second, model.payload_span(32, 0, 32), True)
    two = complete(context, receive, second, 'control_two')
    for tag in ('control_one', 'control_two'):
        for action in ('resume', 'cancel'):
            control(context, receive, action, tag, 'BodyControlExpired')
    if status(context, receive, 'control_one') != one or status(context, receive, 'control_two') != two:
        raise ValueError('terminal stale control mutated record')


def run(context, receive):
    adapter.health(context, receive)
    case = context['stage']['case']
    if case == 'control_rules':
        controls(context, receive)
    else:
        pause(context, receive, case)
    adapter.health(context, receive)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
