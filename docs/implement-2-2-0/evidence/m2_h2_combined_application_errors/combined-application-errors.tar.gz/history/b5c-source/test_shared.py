"""Two synthetic application schedules and a carried-debt final boundary."""
import hashlib
import json
import adapter
import catalogue
import h2_client
import hpack
import model
import test_ready


def require(value, message):
    if not value:
        raise RuntimeError(message)


def record_upload(peer, payload, stream, terminal):
    peer['count'] += len(payload)
    peer['digest'].update(payload)
    peer['frames'] += 1
    peer['max_span'] = max(peer['max_span'], len(payload))
    increment = len(payload).to_bytes(4, 'big')
    updates = (test_ready.frame(8, 0, 0, increment), test_ready.frame(8, 0, stream, increment))
    if terminal:
        peer['last'] = updates
        return
    peer['pending'].append(b''.join(updates))


def check():
    app = {'heads': 0, 'records': {tag: model.record(tag, False, 'before') for tag in model.SPECS}}
    connections = []
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    initial = test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b'')

    for case, prior in (('ready_buffered', ()), ('large_declared', ('ready_buffered',))):
        decoder, encoder = hpack.Decoder(), hpack.Encoder()
        peer = {'buffer': bytearray(), 'pending': [], 'heads': [], 'paths': [], 'startup': True,
                'body': bytearray(), 'count': 0, 'digest': hashlib.sha256(), 'last': None,
                'final_reads': 0, 'final_bytes': 0, 'boundary': None, 'context': None}

        def response(path, stream):
            if path == '/health':
                body = b'ok'
            elif path == '/echo':
                body = bytes(peer['body'])
            elif path == '/upload/large_declared':
                item = app['records']['large_declared']
                item.update(middleware=1, attempts=1, begins=1, ends=1, bytes=peer['count'],
                            sha256=peer['digest'].hexdigest(), chunks=peer['frames'], max_span=peer['max_span'])
                body = json.dumps(item).encode()
            elif path.startswith('/status/'):
                body = json.dumps(app['records'][path[8:]]).encode()
            elif path == '/metrics':
                fields = model.COMMON_COUNTERS + ('bytes',)
                values = {key: sum(record[key] for record in app['records'].values()) for key in fields}
                values.update(active=0, paused=0, buffered_middleware=app['heads'] - values['middleware'],
                              slot0_active=False, slot1_active=False)
                body = json.dumps(values).encode()
            else:
                raise RuntimeError('unexpected path')
            block = encoder.encode(((':status', '200'), ('x-middleware', 'retained')))
            packet = test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body)
            if path == '/status/large_declared':
                context = peer['context']
                stage, request = context['stage'], context['request']
                boundary = peer['boundary']
                require(stage['final'] and stage['final_budget'] == catalogue.final_budget(boundary['debt']), 'final budget differs')
                require(stage['bytes'] == boundary['bytes'] and stage['reads'] == boundary['reads'], 'entry counters changed')
                require(context['raw'] is boundary['raw'] and context['request'] is boundary['request'] and
                        context['credit'] is boundary['credit'], 'connection identity changed')
                require((stage['case_deadline'], stage['whole_deadline']) == boundary['deadlines'], 'deadlines changed')
                require(request['connection_debt'] == boundary['connection_debt'] and
                        request['stream_debt_total'] == boundary['stream_debt'], 'entry debt changed')
                connection, stream_update = peer['last']
                peer['pending'].append(connection + stream_update[:5])
                peer['pending'].append(stream_update[5:] + packet)
                peer['last'] = None
                return
            peer['pending'].append(packet)

        def send(data):
            if peer['startup']:
                peer['startup'] = False
                return
            peer['buffer'].extend(data)
            while len(peer['buffer']) >= 9:
                size = int.from_bytes(peer['buffer'][:3], 'big')
                if len(peer['buffer']) < size + 9:
                    return
                packet = bytes(peer['buffer'][:size + 9])
                del peer['buffer'][:size + 9]
                kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
                if kind == 1:
                    headers = list(decoder.decode(packet[9:]))
                    path = dict(headers)[':path']
                    peer['paths'].append(path)
                    peer['heads'].append(headers)
                    app['heads'] += 1
                    if flags & 1:
                        response(path, stream)
                elif kind == 0:
                    payload = packet[9:]
                    if peer['paths'][-1].startswith('/upload/'):
                        record_upload(peer, payload, stream, bool(flags & 1))
                    else:
                        peer['body'].extend(payload)
                    if flags & 1:
                        response(peer['paths'][-1], stream)

        def receive():
            require(bool(peer['pending']), 'missing peer input')
            data = peer['pending'].pop(0)
            if peer['context']['stage']['final']:
                if peer['final_reads'] == 1:
                    context = peer['context']
                    require(len(context['raw']['header']) == 5 and context['request']['connection_debt'] == 0 and
                            context['request']['stream_debt_total'] == peer['boundary']['stream_debt'], 'split refund state differs')
                peer['final_reads'] += 1
                peer['final_bytes'] += len(data)
            return data, 2

        peer['frames'], peer['max_span'] = 0, 0
        context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001,
                                    selected_before=prior, clock=lambda: 2)
        peer['context'] = context
        require(context['request']['connection_debt'] == 0 and context['request']['stream_debt_total'] == 0, 'new ledger inherited debt')
        connections.append(context)
        adapter.observe(context, initial, 2)
        adapter.run_case(context, receive)
        expected_paths = ['/health', '/metrics', '/echo' if case == 'ready_buffered' else '/upload/large_declared', '/metrics', '/health']
        require(peer['paths'] == expected_paths, 'case request order differs')
        require((context['stage']['case_state']['heads'], context['stage']['case_state']['small'], context['request']['case']['sent']) ==
                ((5, 5, 257) if case == 'ready_buffered' else (5, 5, 100000000)), 'case J/C/R differs')
        actual = dict(peer['heads'][2])
        require(actual == {':method': 'POST', ':scheme': 'https', ':authority': 'localhost', ':path': expected_paths[2],
                           'content-length': '257' if case == 'ready_buffered' else '100000000'}, 'primary headers differ')
        if case == 'ready_buffered':
            require(bytes(peer['body']) == model.core_request(case)['body'], 'echo payload differs')
            require(app['records']['large_declared']['bytes'] == 0, 'ready changed prior body state')
            require(context['request']['connection_debt'] == 257 and context['request']['stream_debt_total'] == 257, 'ready debt differs')
            continue
        require(context['protocol'] is not connections[0]['protocol'] and context['request'] is not connections[0]['request'] and
                context['raw'] is not connections[0]['raw'] and context['credit'] is not connections[0]['credit'], 'connection state shared')
        require(connections[0]['request']['connection_debt'] == 257 and connections[0]['request']['stream_debt_total'] == 257, 'prior debt changed')
        require(peer['count'] == model.MAX_PAYLOAD and peer['digest'].hexdigest() == model.LARGE_HASH, 'upload differs')
        stage, request = context['stage'], context['request']
        peer['boundary'] = {'bytes': stage['bytes'], 'reads': stage['reads'], 'raw': context['raw'], 'request': request,
                            'credit': context['credit'], 'deadlines': (stage['case_deadline'], stage['whole_deadline']),
                            'connection_debt': request['connection_debt'], 'stream_debt': request['stream_debt_total'],
                            'debt': request['connection_debt'] + request['stream_debt_total']}
        require(peer['boundary']['connection_debt'] > 0 and peer['boundary']['stream_debt'] > 0 and peer['last'] is not None,
                'missing earned carried debt')
        adapter.final_collection(context, receive)
        require(peer['paths'] == expected_paths + ['/status/' + tag for tag, _, _, _ in model.BODY_SPECS] + ['/metrics'], 'final order differs')
        require(stage['final_complete'] and stage['bytes'] == peer['boundary']['bytes'] + peer['final_bytes'] and
                stage['reads'] == peer['boundary']['reads'] + peer['final_reads'] and stage['final_bytes'] == peer['final_bytes'], 'cumulative accounting differs')
        require((stage['case_deadline'], stage['whole_deadline']) == peer['boundary']['deadlines'] and
                stage['case_state']['bytes'] == stage['bytes'] and stage['case_state']['reads'] == stage['reads'], 'final state differs')
        require(request['connection_debt'] == 0 and request['stream_debt_total'] == 0 and not peer['pending'] and
                peer['last'] is None and not context['raw']['header'] and context['raw']['frame'] is None, 'refund or parser remains')
        model.validate_records(('ready_buffered', 'large_declared'), 'before', app['records'])
        print('entry debt connection=%d stream=%d budget=%d; final bytes=%d reads=%d; upload frames=%d' %
              (peer['boundary']['connection_debt'], peer['boundary']['stream_debt'], stage['final_budget'],
               peer['final_bytes'], peer['final_reads'], peer['frames']))
    print('shared schedules and carried final boundary passed')


if __name__ == '__main__':
    check()
