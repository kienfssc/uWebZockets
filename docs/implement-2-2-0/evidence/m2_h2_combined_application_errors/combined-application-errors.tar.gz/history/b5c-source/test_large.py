"""Canonical large uploads over bounded public codecs."""
import test_ready


if __name__ == '__main__':
    test_ready.check('large_declared')
    test_ready.check('large_undeclared')
