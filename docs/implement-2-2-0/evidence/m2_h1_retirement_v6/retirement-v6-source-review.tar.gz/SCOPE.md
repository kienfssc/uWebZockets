# R3 V6 source review checkpoint

This is source-only proposal/evidence, not accepted or implemented H1 retirement.
The exact V6 input receipt binds prepared R2 plus local reviewed libxev candidate
c223bd886c6a51d2cd60def39dd9a68d701fea73/tree86c6944f53dc009d7503a9ab0bc873aef3cd7b79.
The complete dependency source/history is separately saved by the registration
rollback archive under m3_libxev_registration_rollback; original App/R2 prepared
source is in m2_transport_preparation. Inputs here are source snapshots for
review, not one complete build. Earlier proposal revisions remain unchanged.

Fresh-context review found P1: non-Darwin kqueue worker close may publish after
its queue poll without waking kevent; once timers/scheduler stop, final close
callback and slot release can be stranded. V6's broad finite-close contract is
not accepted. Root surfaced the community-BSD scope choice and is proceeding
with explicit setup refusal as its default assumption, pending separate guard
implementation/review. No fourth full retirement review was launched blindly.
Independent typed loop callback/failure adaptation can proceed without activation.
No native timing experiment, fault/race/leak/cancellation/error injection or
stopped experiment ran. Maintained publication/adoption and production pins
remain unchanged. This archive does not claim live uploads or close safety.
