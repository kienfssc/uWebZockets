from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,re,tarfile
root=Path('/workspaces/uWebZockets')
e=root/'.uwz-work/evidence/h1-transport/r3'
dest=root/'docs/implement-2-2-0/evidence/m2_h1_retirement_v6'
dest.mkdir(parents=True,exist_ok=True)
receipt=json.loads((e/'v6-source-review-input.json').read_text())
retained={}
for name in ('retirement-plan-v3.md','retirement-plan-v4.md','retirement-plan-v5.md','retirement-plan-v6.md','h1-head-driver-seam.md','v4-independent-review.md','v6-independent-review.md','v6-source-review-input.json','package_v6.py'):
 retained['review/'+name]=(e/name).read_bytes()
for name,item in receipt['inputs'].items():
 data=Path(item['path']).read_bytes()
 assert hashlib.sha256(data).hexdigest()==item['sha256'],name
 retained['inputs/'+name+'.zig' if name not in ('proposal','head_admission_seam') else 'inputs/'+name+'.md']=data
extra={
 'R2_app.zig':root/'.uwz-work/drafts/m2-body-app/src/router/app.zig',
 'libxev_watcher_stream.zig':root/'.uwz-work/drafts/libxev-udp-fix/src/watcher/stream.zig'
}
for name,path in extra.items():retained['inputs/'+name]=path.read_bytes()
scope='''# R3 V6 source review checkpoint

This is source-only proposal/evidence, not accepted or implemented H1 retirement.
The exact V6 input receipt binds prepared R2 plus local reviewed libxev candidate
c223bd886c6a51d2cd60def39dd9a68d701fea73/tree86c6944f53dc009d7503a9ab0bc873aef3cd7b79.
The complete dependency source/history is separately saved by the registration
rollback archive under m3_libxev_registration_rollback; original App/R2 prepared
source is in m2_transport_preparation. Inputs here are source snapshots for
review, not one complete build. Earlier proposal revisions remain unchanged.

Fresh-context review found P1: non-Darwin kqueue worker close may publish after
its queue poll without waking kevent; once timers/scheduler stop, final close
callback and slot release can be stranded. V6's broad finite-close contract is
not accepted. Root surfaced the community-BSD scope choice and is proceeding
with explicit setup refusal as its default assumption, pending separate guard
implementation/review. No fourth full retirement review was launched blindly.
Independent typed loop callback/failure adaptation can proceed without activation.
No native timing experiment, fault/race/leak/cancellation/error injection or
stopped experiment ran. Maintained publication/adoption and production pins
remain unchanged. This archive does not claim live uploads or close safety.
'''
retained['SCOPE.md']=scope.encode()
values=[v.encode() for k,v in os.environ.items() if re.search(r'(?:TOKEN|SECRET|PASSWORD|CREDENTIAL|API_KEY)$',k) and len(v)>=20]
pattern=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})')
for name,data in retained.items():
 assert not any(v in data for v in values),name
 assert not pattern.search(data),name
inventory={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in retained.items()}
retained['inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
archive=dest/'retirement-v6-source-review.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(retained.items()):
    member=tarfile.TarInfo(name);member.mode=0o644;member.mtime=0;member.size=len(data)
    tar.addfile(member,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():
  path=PurePosixPath(member.name)
  assert member.isfile() and not path.is_absolute() and '..' not in path.parts
  assert tar.extractfile(member).read()==retained[member.name]
manifest={'date':'2026-10-27','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'safe_regular_members':len(retained),'inventory_entries':len(inventory),'proposal_sha256':receipt['inputs']['proposal']['sha256'],'reviewer':'/root/review_h1_retirement_v6','verdict':'Not accepted: P1 non-Darwin kqueue close-result wakeup gap','root_policy_assumption':'Explicit streaming setup refusal on community BSD pending separate implementation/review; user scope choice surfaced','source_only':True,'native_probes_or_runtime_lifetime_claims':False,'credential_scan':'All retained bytes checked against environment credential values and GitHub token patterns','files':inventory}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('archive_sha256','archive_bytes','safe_regular_members','inventory_entries')},indent=2))
