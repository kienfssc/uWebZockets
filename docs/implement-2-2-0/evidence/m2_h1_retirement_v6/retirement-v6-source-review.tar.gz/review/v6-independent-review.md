# Fresh-context V6 adversarial review, 2026-10-27

Reviewer /root/review_h1_retirement_v6, read-only, no inherited history.

P1: FreeBSD kqueue can strand the final worker close completion. Proposal207–209
claims finite close. watcher/stream.zig434 selects a thread-pool close on kqueue.
backend/kqueue.zig1002 publishes its result but1008 wakes only on Darwin. If the
worker finishes after the MPSC poll429, kevent520 can wait forever: retirement
timers have finished and prepared App.shutdown633 already stopped the scheduler.
The descriptor closes, but no callback releases the slot and shutdown does not
drain. Require a working FreeBSD worker wakeup or exclude runtime activation.

The reviewer examined four backend timer/ACK/target return paths, publication,
MPSC ownership, R2 close/release and kqueue timer/delete ordering. No other
concrete lifetime finding was reported. No edits, builds, tests, probes or native
fault experiments were performed. This is not acceptance of the V6 contract.

Root reconciliation: valid under V6's unrestricted kqueue wording. Existing
README platform tiers call BSD community targets without dedicated runtime CI;
that does not itself exclude the runtime from this artifact. A user scope choice
is pending: explicit streaming setup refusal for community BSD (recommended),
or add wakeups plus native validation. Three full review cycles have surfaced
substantive prerequisites; no fourth full retirement review is started blindly.
Independent typed core_loop adapter planning can continue without activating
this lifetime algorithm. Backend candidate c223bd88 remains unchanged/unadopted.
