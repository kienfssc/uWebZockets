# V3: finite close and reuse protocol

Source-only proposal. R2 production sources and owner layout remain unchanged.
No native algorithm, cancellation/race/fault test, compile job, dependency edit
or old stopped probe was started. Source references use frozen c49f6df libxev
backend bytes retained by the earlier retirement audit; the peer-only candidate
does not change these backends. R2's guarded LoopHandle seam passed fresh review.

## Prerequisites that barriers cannot replace

H1 targets are the ordinary static/dynamic TCP `.recv` and `.send` watchers:
one retained inline completion per direction, no thread-pool target, no explicit
delete, no completion/op reuse until its target and cancel have both retired.
The TCP watcher queues a target before the driver can queue its cancellation.
No loop reentry or callback-time App destruction is permitted.

Required maintained-epoll changes, independently reviewed before use:

1. The accepted dead-target decision: a retained private-dead non-timer target
   returns existing NotFound before fd access/stop. A completed timer retains
   successful cancellation. This prevents a queued cancel deleting a target
   that already disarmed in the previous ready batch.
2. Separately prove/implement ownership cleanup for successful cancellation of
   a registered, duplicated, non-thread-pool fd watcher. Current stop_completion
   unregisters but does not close its owned duplicate; normal disarm does close
   it. The dead-target change alone does not prove complete resource teardown.
   A narrow candidate may save the owned duplicate only for private-active,
   non-thread-pool, dup targets, stop once, then close that saved duplicate once.
   Dead/adding/deleting/worker paths must not read an uninitialized/stale dup fd.
   This must cover ordinary listener cancellation too, or the listener remains
   a separate full-App teardown obligation. No runtime leak claim follows.

For the H1 queue order, when epoll cancellation starts the target has either
registered, rearmed, or already completed: its initial adding entry precedes
the cancel; registration failure dispatches the target; the previous ready
batch finishes before the next submission phase. No deleting or worker case
is created by this driver. Do not generalize this proof to arbitrary raw users
or treat public active as proof of registration. Root must reconcile this
restricted contract with the maintained backend changes before implementation.

## Existing fields and pins

Use existing `read_active`/`is_writing` for target ownership,
`read_callback_active`/`write_callback_active` for their callback frames, and
`read_cancel_active`/`write_cancel_active` for the cancel operation **including
its ACK callback frame**. Keep the latter true until the callback's last state
write. One proposed cold `delivery_active` pin covers admission/body delivery
and close cleanup that can invoke application code. No callback-frame counter
framework or additional native completion is proposed.

Each direction retains its existing inline retirement completion and phase
idle/first/second. A non-idle phase means a **future** retirement callback;
the timer implementation must enforce the transition rule below. BodyState's
reservation and terminal state remain independent of native completion pins.

## Close sequence

1. Record close intent once (`conn.closing`, existing owner.close_pending),
   stop new I/O and invalidate/defer body ownership according to BodyState.
   While admission/body/native callback pins are active, record intent and
   return; never destroy TLS, metadata or binding state under their stack.
2. At an operation tail, perform deferred application/output cleanup under the
   delivery pin. Successful begin receives exactly one real cancel or end;
   failed/unstarted begin receives neither. Release admission only through the
   authoritative reject_begin/finish_terminal bool after callback unwind.
3. Submit queued operations before cancellation on kqueue/IOCP, through the
   guarded owner handle. Set each cancel flag before issuing its one cancel.
   Never issue another cancellation while that direction's flag is true.
4. A target callback clears its target-active flag, records its frame pin and
   observes close intent without delivering more body data. Before returning
   disarm it requests that direction's retirement; clear its frame pin as the
   final state write. It does not issue physical close in that frame.
5. An ACK callback keeps its cancel flag true while processing the result.
   Successful epoll abandonment may clear the corresponding target-active
   flag. Non-abandoning success and every NotFound leave that flag to the real
   target callback. Request/coalesce retirement **before** clearing the cancel
   flag as its final state write, then return disarm. Never call physical close
   from the ACK callback. A late ACK therefore cannot become an unretired final
   gate after target retirement has already ended.
6. Only a release-safe tail may issue physical close. Require no target-active,
   target-frame, cancel/ACK-frame, delivery/application pin, or non-idle
   retirement; accepted body ownership must have completed terminal cleanup.
   Set close_pending false **before** issuing close, preventing duplicate close
   submission. Keep conn.closing true. Windows retains synchronous close,
   immediate close_complete and the existing release-gate pairing at this point.
7. Once close completes, use only release_closed_connection for slot release;
   preserve callback nulling and pool_ptr clearing. Request metadata remains
   pinned until response ownership ends or safe final close. App/owner slabs
   are not deinitialized/freed from callbacks; healthy loop drain precedes free.

## Retirement and ACK-frame rule

On an idle retirement request, schedule fresh Timer.run(0), phase first. On a
first callback, set second and schedule a fresh Timer.run(0) on that now-fired
completion; return disarm. No external action occurs in this callback.

On the second callback, first set idle and complete every old retirement state
write. Only then enter a release-safe tail action: close, resume pending I/O,
or continue delivery. After that action, return disarm without reading or
overwriting owner/connection state. An ACK nested in this tail sees idle and
starts a fresh sequence on the fired completion; the outer callback must not
overwrite it afterward.

Consequently an ACK that observes first/second can coalesce: that callback is
future and will run after the ACK frame unwinds. It may run later in the same
timer pass; ACK ops have no fd-filter deletion to flush. If the target's timers
already ended, idle starts a fresh two-stage sequence. No active timer reset,
completion reinitialization, or timer rearm return is used.

The two-stage kqueue fd proof remains: timer_next(0) samples fresh time, while
each timer pass compares against one fixed now with strict less-than. Nested
public submit can insert a timer but cannot fire callbacks. Stage one can occur
before a pending local EV_DELETE flush; fresh stage two cannot expire in that
same pass, so a successful kevent flush intervenes. Any public run/submit error
hits the R2 failure fence before continuation; later timers cannot repair a
lost local deletion batch.

## Why the final timer does not need another timer

| Backend | Fired timer release boundary |
| --- | --- |
| epoll :421-437 | Heap removal, dead state and active decrement precede callback; disarm does not access completion afterward. |
| kqueue :400-422 | Same ordering; timer disarm has no kevent or post-callback deletion. |
| io_uring :193-200 | CQE accounting and dead state precede invoke; disarm does not dereference completion afterward. |
| IOCP :241-259 | Heap removal, dead state and active decrement precede callback; disarm has no later completion access. |

Static/dynamic Timer wrappers return the caller's action without post-callback
storage access. Public Timer/loop.timer docs permit scheduling another timer
from a fired callback. The completion lives in stable startup cold storage,
outside the recycled TCP slot; reset preserves it. A final timer may therefore
tail-dispatch close/release without recursively retiring itself forever. The
tail performs no later reads of possibly released connection/binding storage.
The close-completion callback retains the existing analogous last-action pool
release rule; low-level callers must preserve the same slab/loop lifetime.

## Result obligations

| Observation | What it proves / action |
| --- | --- |
| epoll successful active-fd cancellation | After backend remedy/cleanup proof, target was abandoned; clear only its active flag, then retire ACK frame. |
| epoll dead-fd NotFound | The restricted source path's target already returned disarm; do not clear a still-true target flag from NotFound. |
| kqueue success | ACK alone is insufficient; submit-before-cancel preserves a target callback, including a queued result. |
| io_uring / IOCP success or NotFound | Keep target flag until its real callback; completion may arrive after ACK or after ACK's timers. |
| unexpected cancellation error | No fabricated target completion; required teardown proof failed. Proposed enabled-only fixed failure observer latches and terminates. |
| retirement timer error/cancellation | Never grant retirement or retry/reset the timer. Proposed enabled-only fixed failure observer latches and terminates. |
| close-completion error without proven close | Never fabricate close_complete/reuse; use the same enabled failure observer. |

The last three rows need an explicit small adapter failure entry point using
the accepted fixed fence/panic policy; R2 currently guards returned run/submit
errors only. This is a proposed extension for review, not implemented. Ordinary
peer read/write errors still take the normal body-cancel/disarm/retire path.

Finite completion follows once the required backend contracts hold: every
target and ACK arrives once; the last such frame requests or coalesces a future
barrier, stage two opens the finite close gate, and close completes once. No
timeout, retry, public-state guess or physical-close fallback substitutes for a
missing callback. The separate shutdown alternative is not adopted without its
missing portable pending-send proof.
