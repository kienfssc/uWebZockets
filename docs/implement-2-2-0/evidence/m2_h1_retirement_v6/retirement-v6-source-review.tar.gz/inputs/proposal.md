# V6: finite close and reuse protocol

Source-only revision prepared after fresh independent review. R2 production
sources and owner layout remain unchanged. No physical-close algorithm or native
cancellation/race/fault experiment is implemented by this proposal. The earlier
stopped experiment stays stopped. Earlier revisions remain preserved under
their original hashes.

Source anchors use reviewed libxev base 7b7b1f14518d9504b15590d123ec494b8fadb2e3,
its reviewed duplicate-cleanup append 29490914cf58b24d7ab32ca5349f9a03a910435f,
and reviewed IOCP append b2afbafa6900d147ea0dea56e33b612b18f278d4.
Worker-publication append 179f22bc539548e024407b76d4aa39c54342e5b4
and registration rollback append c223bd886c6a51d2cd60def39dd9a68d701fea73
are also inputs. Their independent
reviews and verification are recorded in v6-source-review-input.json and must be
complete before relying on those contracts. These are local review inputs,
not an adopted root pin. R2's stable guarded LoopHandle seam retains its scoped
review; the callback-level failure observer remains a proposed extension.

## Prerequisites that barriers cannot replace

H1 targets are the ordinary static/dynamic TCP `.recv` and `.send` watchers:
one retained inline completion per direction, no thread-pool target, no explicit
delete, no completion/op reuse until its target and cancel have both retired.
The TCP watcher queues a target before the driver can queue its cancellation.
No loop reentry or callback-time App destruction is permitted.

Required maintained-backend changes, independently reviewed before use:

1. The accepted dead-target decision: a retained private-dead non-timer target
   returns existing NotFound before fd access/stop. A completed timer retains
   successful cancellation. This prevents a queued cancel deleting a target
   that already disarmed in the previous ready batch.
2. The separately reviewed registered-duplicate append implements cleanup for
   a registered, duplicated, non-thread-pool fd watcher. Original stop_completion
   unregistered without closing its duplicate; normal disarm closed it. The
   accepted correction saves the owned duplicate only for private-active,
   non-thread-pool, dup targets, stops once, then closes that saved duplicate once.
   Dead/adding/deleting/worker paths must not read an uninitialized/stale dup fd.
   It covers ordinary listener cancellation too; listener shutdown must use the
   same retained registration contract. No runtime leak claim follows.
3. IOCP must normalize only a failed CancelIoEx whose immediately captured
   GetLastError is ERROR_NOT_FOUND to the existing success acknowledgement.
   Kernel completion can precede callback delivery; the previous backend erased
   that ordinary outcome into Unexpected. All other failed-call errors retain
   their existing windows.unexpectedError diagnostic/result. Native success
   must not read last-error state. Preserve CancelError=error{Unexpected},
   completion layout, ACK queueing and existing dead/adding semantics.
   This repair does not promise a target callback for generic adding targets:
   cancellation there suppresses submission. H1 excludes that case through
   submit-before-cancel. Every IOCP ACK leaves a still-true target pin intact
   until its genuine callback. The driver cannot recover ERROR_NOT_FOUND from
   an already collapsed Unexpected result or use a timer to replace the target.

4. POSIX thread-pool completion publication ends the worker's access to that
   completion and its task/node storage. Capture the loop and epoll publication
   queue before publishing; finish the result before the push. After push, only
   the captured loop may be used for wakeup. MPSC push finishes node access at
   publication, and ThreadPool.run does not dereference the task after its
   callback returns. R2 must join the pool before destroying the captured loop.
   This permits completion-storage reuse without claiming worker return; timers
   cannot prove arbitrary worker quiescence. Both epoll and Darwin kqueue close
   workers need this correction before the final close callback can release.
5. A new epoll duplicate acquired by this start attempt must roll back if
   EPOLL_CTL_ADD fails. Use a named stack acquisition record distinguishing new
   duplicate ownership (including fd 0) from original/cached descriptors. One
   ADD helper takes a new duplicate once, invalidates its cached dup_fd, closes
   only it, and returns the exact ADD error. Preserve original operation fd,
   dup-request flag, callbacks, state and active accounting. No DEL is justified
   for failed ADD. All eleven registerable operations must use the transaction;
   connect carries its acquisition through WouldBlock. Dup failure produces no
   acquisition record and must not inspect stale cache. Existing cached-fd and
   immediate connect outcomes are outside this bounded correction; H1 accepted
   sockets use ordinary recv/send, not outgoing connect.

For the H1 queue order, when epoll cancellation starts the target has either
registered, rearmed, or already completed: its initial adding entry precedes
the cancel; registration failure dispatches the target; the previous ready
batch finishes before the next submission phase. No deleting or worker case
is created by this driver. Do not generalize this proof to arbitrary raw users
or treat public active as proof of registration. Root must reconcile this
restricted contract with the maintained backend changes before implementation.

## Existing fields and pins

Use existing `read_active`/`is_writing` for target ownership,
`read_callback_active`/`write_callback_active` for their callback frames, and
`read_cancel_active`/`write_cancel_active` for the cancel operation **including
its ACK callback frame**. Keep the latter true until the callback's last state
write. One proposed cold `delivery_active` pin covers admission/body delivery
and close cleanup that can invoke application code. No callback-frame counter
framework or additional native completion is proposed.

Each direction retains its existing inline retirement completion and phase
idle/first/second. A non-idle phase means a **future** retirement callback;
the timer implementation must enforce the transition rule below. BodyState's
reservation and terminal state remain independent of native completion pins.

## Close sequence

1. Record close intent once (`conn.closing`, existing owner.close_pending),
   stop new I/O and invalidate/defer body ownership according to BodyState.
   While admission/body/native callback pins are active, record intent and
   return; never destroy TLS, metadata or binding state under their stack.
2. At an operation tail, perform deferred application/output cleanup under the
   delivery pin. Successful begin receives exactly one real cancel or end;
   failed/unstarted begin receives neither. Release admission only through the
   authoritative reject_begin/finish_terminal bool after callback unwind.
3. Submit queued operations before cancellation on kqueue/IOCP, through the
   guarded owner handle. Set each cancel flag before issuing its one cancel.
   Never issue another cancellation while that direction's flag is true.
4. A target callback clears its target-active flag, records its frame pin and
   observes close intent without delivering more body data. Before returning
   disarm it requests that direction's retirement; clear its frame pin as the
   final state write. It does not issue physical close in that frame.
5. An ACK callback keeps its cancel flag true while processing the result.
   Successful epoll abandonment may clear the corresponding target-active
   flag. Every IOCP ACK and io_uring success, NotFound or ExpirationInProgress
   leave that flag to the real target callback. ExpirationInProgress is the
   ordinary EALREADY outcome for a request that progressed too far to cancel;
   its name does not restrict it to timers. Request/coalesce retirement **before** clearing the cancel
   flag as its final state write, then return disarm. Never call physical close
   from the ACK callback. A late ACK therefore cannot become an unretired final
   gate after target retirement has already ended.
6. Only a release-safe tail may issue physical close. Require no target-active,
   target-frame, cancel/ACK-frame, delivery/application pin, or non-idle
   retirement; accepted body ownership must have completed terminal cleanup.
   Set close_pending false **before** issuing close, preventing duplicate close
   submission. Keep conn.closing true. Windows retains synchronous close,
   immediate close_complete and the existing release-gate pairing at this point.
7. Once close completes, use only release_closed_connection for slot release;
   preserve callback nulling and pool_ptr clearing. Request metadata remains
   pinned until response ownership ends or safe final close. App/owner slabs
   are not deinitialized/freed from callbacks; healthy loop drain precedes free.

## Retirement and ACK-frame rule

On an idle retirement request, schedule fresh Timer.run(0), phase first. On a
first callback, set second and schedule a fresh Timer.run(0) on that now-fired
completion; return disarm. No external action occurs in this callback.

On the second callback, first set idle and complete every old retirement state
write. Only then enter a release-safe tail action: close, resume pending I/O,
or continue delivery. After that action, return disarm without reading or
overwriting owner/connection state. An ACK nested in this tail sees idle and
starts a fresh sequence on the fired completion; the outer callback must not
overwrite it afterward.

Consequently an ACK that observes first/second can coalesce: that callback is
future and will run after the ACK frame unwinds. It may run later in the same
timer pass; ACK ops have no fd-filter deletion to flush. If the target's timers
already ended, idle starts a fresh two-stage sequence. No active timer reset,
completion reinitialization, or timer rearm return is used.

The two-stage kqueue fd proof remains: timer_next(0) samples fresh time, while
each timer pass compares against one fixed now with strict less-than. Nested
public submit can insert a timer but cannot fire callbacks. Stage one can occur
before a pending local EV_DELETE flush; fresh stage two cannot expire in that
same pass, so a successful kevent flush intervenes. Any public run/submit error
hits the R2 failure fence before continuation; later timers cannot repair a
lost local deletion batch.

## Why the final timer does not need another timer

| Backend | Fired timer release boundary |
| --- | --- |
| epoll :421-437 | Heap removal, dead state and active decrement precede callback; disarm does not access completion afterward. |
| kqueue :400-422 | Same ordering; timer disarm has no kevent or post-callback deletion. |
| io_uring :193-200 | CQE accounting and dead state precede invoke; disarm does not dereference completion afterward. |
| IOCP :241-259 | Heap removal, dead state and active decrement precede callback; disarm has no later completion access. |

Static/dynamic Timer wrappers return the caller's action without post-callback
storage access. Public Timer/loop.timer docs permit scheduling another timer
from a fired callback. The completion lives in stable startup cold storage,
outside the recycled TCP slot; reset preserves it. A final timer may therefore
tail-dispatch close/release without recursively retiring itself forever. The
tail performs no later reads of possibly released connection/binding storage.
The close-completion callback retains the existing analogous last-action pool
release rule only after the worker-publication prerequisite above. The callback
may run before the worker returns: the worker must no longer access its storage.
Low-level callers must preserve the same slab/loop lifetime.

## Result obligations

| Observation | What it proves / action |
| --- | --- |
| epoll successful active-fd cancellation | After backend remedy/cleanup proof, target was abandoned; clear only its active flag, then retire ACK frame. |
| epoll dead-fd NotFound | The restricted source path's target already returned disarm; do not clear a still-true target flag from NotFound. |
| kqueue success | ACK alone is insufficient; submit-before-cancel preserves a target callback, including a queued result. |
| IOCP success, including normalized ERROR_NOT_FOUND | Keep any still-true target flag until its real callback; submit-before-cancel is required for this H1 contract. No generic adding-target callback promise. |
| io_uring success or NotFound | Keep target flag until its real callback; target CQE may arrive after ACK or its timers. |
| io_uring ExpirationInProgress (EALREADY) | Ordinary outcome, never the fatal observer; keep target pin and await its actual CQE. |
| unexpected cancellation error | No fabricated target completion; required teardown proof failed. Proposed enabled-only fixed failure observer latches and terminates. |
| retirement timer error/cancellation | Never grant retirement or retry/reset the timer. Proposed enabled-only fixed failure observer latches and terminates. |
| close-completion error without proven close | Never fabricate close_complete/reuse; use the same enabled failure observer. |

Backend-sensitive ACK classification belongs in the existing core_loop boundary;
TCP must not inspect xev.backend directly. The native observer cannot classify
expected missing/in-progress outcomes as fatal, and no ACK classification may
invent a target callback or physical-close permission.

The three failure rows need an explicit small adapter failure entry point using
the accepted fixed fence/panic policy; R2 currently guards returned run/submit
errors only. This is a proposed extension for review, not implemented. Ordinary
peer read/write errors still take the normal body-cancel/disarm/retire path.

Finite completion follows once the required backend contracts hold: every
target and ACK arrives once; the last such frame requests or coalesces a future
barrier, stage two opens the finite close gate, and close completes once. No
timeout, retry, public-state guess or physical-close fallback substitutes for a
missing callback. The separate shutdown alternative is not adopted without its
missing portable pending-send proof.

## Review correction and remaining acceptance

Fresh V3 source review found IOCP's erased ERROR_NOT_FOUND outcome and required
explicit io_uring ExpirationInProgress classification. The actual IOCP correction
is now independently reviewed and verified as local append b2afbafa. V4 fresh
review then found two further prerequisites: worker access after publication,
and newly duplicated fds left open after failed epoll ADD. Root accepts both
findings and the architect's two bounded contracts above. Their separate actual
source candidates, verification and independent reviews are prerequisites to
this revised retirement proposal. The V6 input receipt binds their actual source
identities and final evidence verdicts before its next fresh review.

No previous plan or component approval proves these contracts. The worker
correction needs source proof and unchanged healthy/foreign compilation checks;
rollback needs actual pure ownership tests plus source proof of the kernel-error
branch. These are not native race or leak measurements. Root dependency pins
and maintained publication stay unchanged until canonical fork gates pass.

Primary contracts:
- https://learn.microsoft.com/en-us/windows/win32/api/ioapiset/nf-ioapiset-cancelioex
- https://raw.githubusercontent.com/axboe/liburing/master/man/io_uring_prep_cancel.3
