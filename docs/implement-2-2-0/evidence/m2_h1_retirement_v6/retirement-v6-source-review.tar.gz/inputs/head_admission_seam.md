# Proposed H1 head/admission seam

Source-only contract for root acceptance, coordinated with the App author's
stated ownership needs. No fields or production APIs are added yet; the frozen
R2 owner remains authoritative until a versioned implementation is reviewed.
No fake begin/chunk/end/cancel callbacks represent registration or buffering.

## Small named boundary

Proposed internal types in core/http1_upload.zig:

```zig
pub const HeaderSlots = struct {
    names: [][]const u8,
    values: [][]const u8,
};
pub const CaptureSlots = struct {
    names: [][]const u8,
    values: [][]const u8,
};
pub const IngressBounds = struct {
    capacity: usize,
    line_content_limit: usize,
};
pub const HeadInput = struct {
    request: *Request,
    head: parser.HeadReady,
    method: ?radix.HttpMethod,
    headers: HeaderSlots,   // used mutable overflow slots, not a const cast
    captures: CaptureSlots, // existing caller-owned overflow capacity
    ingress: ?IngressBounds,
    pending_header_capacity: usize,
    early_data_forbidden: bool,
};
pub const AdmissionRefusal = enum {
    too_early, invalid_query, body_too_large, unavailable,
};
pub const HeadDecision = union(enum) {
    buffered,
    final,
    reject: AdmissionRefusal,
    stream: radix.BodyMatch, // explicitly unreserved
};
pub const HeadResolveFn = *const fn (
    *anyopaque, *const HeadInput, *Response,
) HeadDecision;
pub const HeadTarget = struct {
    context: *anyopaque,
    router: *radix.Router,
    resolve: HeadResolveFn,
};
```

One cold target carries the stable App context and its explicit mutable router.
This avoids extra forwarding reserve/release callbacks, changing TCP's existing
const router field, or recovering an App from a raw pointer. Root binds this
target only after stable App placement; reset preserves it. The router must be
the same route owner as conn.router. These pointers live through loop/slot drain.
HeadInput and Response are callback-only borrows; no full Request or array copy
is retained. Header/capture slots and individual initial bytes already have
connection-owned lifetimes.

## App resolution order

1. Use Router.match(path, method), which does not materialize captures. Select
   streaming only when the existing method/routing/upgrade precedence actually
   selects BodyMatch. OPTIONS-* or WebSocket upgrade precedence stays in the
   legacy path. A buffered decision runs no globals and changes no Request
   fields; H0 then commits its buffered checkpoint and preserves old full-body
   middleware timing, errors, compaction and pipeline behavior.
2. For a selected stream, apply the existing early-data refusal first. Bind the
   existing Request's used overflow header views and set its body empty, then
   run the existing QUERY check before capture matching or globals. Bind capture
   capacity and use match_request to materialize captures in its own arrays.
   Capture-capacity failure is bounded 503 before begin. No constCast, Request
   copy or parser-policy change is needed. Framing remains the original H0 value
   even if authorized middleware changes metadata.
3. Refuse incompatible late global policy before callbacks. check_body_route
   also reports quota full; defer that particular refusal until after globals,
   rather than changing the ADR's middleware-before-quota order. Run every
   authorized global once in existing order on the header-only legacy Request
   and fresh Response with request_body_complete=false.
4. If middleware stopped, return final; the driver applies normal bounded
   synchronous response completion, including the missing-response refusal.
   Producers remain forbidden by the incomplete-body phase. Otherwise preflight
   declared logical size, physical ingress, pending-header capacity and current
   admission. Return reject or an **unreserved** BodyMatch. There is no fallible
   reservation handoff hidden inside this callback. A rejection uses the same
   bounded Response, preserving middleware pending headers, then closes after
   final output drains. Output failure records close intent; it is not retried
   by inventing a sink callback or a larger queue.

## Driver reservation and real callbacks

The transport pins the entire resolution/delivery operation, including globals
and terminal callbacks. After resolve it copies the bounded pending header bytes
into the existing 2048-byte owner storage, retains no Response pointer, and checks
deferred close before reservation. A close during admission has no accepted body
binding and invokes no body callback.

For stream: verify BodyState is inactive/unreserved, reserve through the target's
explicit router, and immediately call BodyState.arm with the real control target,
limits and declared length. There is **no I/O or user callback between reserve
and arm**. If pure arm validation fails, that one local untransferred reservation
is rolled back once before returning; BodyState never accepted it. On success,
BodyState.reserved owns every later release. This atomic handoff adds no stored
ticket/second reservation flag. Root must explicitly accept this narrow rollback
rule before implementation.

Call the registered sink's real begin only afterward. Failed begin owns its own
partial rollback; reject_begin's bool releases admission, with no cancel. A
successful returned binding is accepted before processing deferred cancellation.
If cancellation occurred during begin, invoke its real cancel once after unwind;
otherwise send required 100 Continue, independently of whether binding readiness
is paused. Never wait for body content to decide Continue.

Chunk/end/cancel delivery remains in the transport using shared BodyState and
BodyDecoder. The control target can carry conn as its context; generation checks
expire it before slot reuse, so no second stored TCP pointer is required. Controls
used during begin/chunk refuse reentry, and terminal controls are already expired.
End gets a fresh response restored from persistent pending bytes with the body
complete guard true. Normal synchronous/producer completion rules apply; an end
error aborts output without a second cancel. finish_terminal releases admission
once only after its callback. An outgoing producer has independent application
context; upload binding cleanup does not extend that context's lifetime.

## Physical input and request lifetime

The initial prefix stays pinned at [0,header_end). Compute R=S-header_end with
checked arithmetic. An absent/known-empty body needs no tail, positive fixed
length needs R>=1, and chunked needs R>=3. Bounds are passed to App as an optional
value so an unavailable streaming tail is refused **after authorized middleware**,
while a buffered route retains its existing policy. Incomplete initial headers
that exhaust their physical accumulator retain bounded header refusal behavior.
Chunk/trailer line content limit is min(H,R-2); trailers remain discarded by
the shared decoder, independently bounded to H and 64 fields.

Socket reads and SSL_read are capped at min(8192,free retained space), including
before admission. Every returned plaintext byte fits retained connection storage.
Pause stops new reads and TLS plaintext extraction, preserving BIO contents.
Socket writes and independent outgoing response work continue. A full retained
window pauses; it is not a logical body-limit error.

Use only raw tail offsets; do not retain a callback chunk pointer. Count a newly
offered payload once in BodyState.observe and keep a pending_payload count for
its unaccepted observed suffix. Resume offers that suffix without observing it
again, before parsing/observing new payload. Accept prefixes in both shared
state and decoder, rebase reclaimed tail offsets through discard_prefix, and
never move the pinned head. Invalid progress terminates after callback unwind.
A final-byte pause must await explicit resume; resume can validate pending framing
and call end with zero remaining payload, without arming another read.

Upload pause is separate from dispatch_suspended: keep the existing idle wheel
node live while paused, and stop the initial-header deadline after streaming
head admission. dispatch_suspended continues to represent response ownership.
The stored HeadReady and metadata arrays survive body terminal cleanup and any
longer output producer. Request reset/pipeline compaction happens only after that
response ownership and every delivery pin ends. A fixed response whose bytes are
fully accepted into ordered output need not wait for OS drain, but no callback
may still borrow its arrays. Preserve following pipeline bytes, then reset parser
and request for the next head; never call the buffered route handler for a stream.

## Proposed cold-v3 delta and implementation boundary

Only three additions are currently proposed: optional HeadTarget, delivery_active
pin, and pending_payload count; CallbackPhase gains admission. Existing HeadReady,
pending headers, route identity, BodyState, decoder, raw cursors, loop handle and
two retirement completions remain. Existing dispatch_suspended/output producer
state supplies response ownership; existing close_pending becomes the one-shot
not-yet-issued close intent. No new native ACK completion or generic continuation
framework is needed. R2 sizes must not be edited until this version is accepted
and actually measured.

Implement pure bounds/progress/metadata-preservation tests first when root allows
compile work, then the real H1 vertical with actual registered sinks and ordinary
plain/TLS clients. Native close/cancel code remains blocked on v3 review and the
maintained backend prerequisites. Crypto/TLS review must verify the concrete BIO
and capped SSL_read hooks before any TLS behavior change is adopted.
