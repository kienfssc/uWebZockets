# Stage A: pure H1 retirement and close policy

Root accepted developer sketch after architect handoff, 2026-10-27.
Predecessor cold-v3 V2 digest35bcfec2f32c0f0789b534f0832a37b2e3dd543d97ccdbed52655719005d4fb1;
checkpoint c25c68ec8dfa30a699d9ac24a99b68bf01a995ad pushed to fork feature branch.
No native effects or callback wiring in this stage. Existing V6 remains only an
eligible-runtime implementation plan. Full goal/delivery/cleanup/TLS gates open.

Own new /tmp/uwz-m2-h1-retirement-policy and workspace evidence/h1-retirement-policy.
Never edit frozen predecessor/Root/pins. Only existing storage source plus central
body_app_tests; existing test_support exposes storage. No new stored fields or
layout growth, speculative state, generic action framework or forwarding layer.

Accepted exact contracts:
- request_retirement(*RetirementPhase) bool: idle->first,true (fresh arm needed);
  first/second unchanged,false (coalesced).
- RetirementExpiry enum{arm_second,tail}; RetirementError error{RetirementInactive}.
  expire_retirement(*RetirementPhase) error!RetirementExpiry: first->second,
  arm_second; second->idle,tail; idle returns error without mutation.
- CloseSnapshot six required bools without defaults: closing,close_complete,
  read_active,is_writing,read_cancel_active,write_cancel_active.
- claim_close(*Http1UploadStorage,CloseSnapshot) bool uses canonical owner pin
  predicate shared with is_drained. Valid intent requires initialized owner,
  healthy failure fence,closing,!close_complete,close_pending. Invalid input
  changes nothing. On a valid intent, clear both read/write resume-work flags
  even if body/frame/ACK/retirement pins defer physical close; these flags are
  pending work, not ownership pins. Document this mutation on a false result.
  Consume close_pending only if all snapshot target/ACK and owner body/reservation,
  delivery/frame/retirement/completion obligations permit it. Never set intent,
  clear ownership pins or release admission. Only close_pending is consumed at
  successful claim. Repeated policy calls cannot resurrect consumed close.
- is_drained keeps all old semantics plus previously accepted delivery pin,
  including !close_pending. Factor canonical pin check only as needed.

Test actual functions red/green: independent directions/coalescing/late request;
invalid expiry unchanged; each actual obligation separately denies claim;
invalid/uninitialized/failed-fence input unchanged; valid deferred close clears
resume-work while preserving intent and ownership; final close claims once.
Do not fabricate native callbacks/completions. Inert initialized caller state
only. Preserve old guards/reset and all20 App cases. Actual future callback
consumers are V6 disarm/ACK tails, two fresh direction timer stages and safe
physical-close tail. Do not claim their wiring or real body cleanup here.
RetirementInactive must later reconcile invariant handling with typed failure
fence; never disguise it as a benign native timer result.

Stage B native wiring follows separate actual-source implementation/review;
real delivery tails and terminal/admission cleanup required before activation.
Same c223 immutable override/original r2 C bindings; no pin/ref adoption.
No native cancellation/interleaving/race/crash/leak/registration-error/invalid-fd/
resource/kernel/injected-completion experiment or panic subprocess. Prior stopped
experiment remains stopped. Scoped actual pure checks, unchanged healthy suites,
eligible compile-only and source/layout proof; independent review before commit.
Keep concrete source snapshots durable each stage; /tmp can clear across turns.
