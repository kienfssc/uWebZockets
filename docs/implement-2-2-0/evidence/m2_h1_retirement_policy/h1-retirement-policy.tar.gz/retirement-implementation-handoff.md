# Eligible H1 retirement implementation handoff

Read-only architect /root/architect_h1_retirement_implementation. No edits,
builds, tests, native execution or probes by architect. Root persists output.
Baseline digest2795e885505248822125ef5ae5a1d695aaf557cb040040fb23c1bad74ec43e3f;
follow with independently reviewed cold-v3 data before implementation.
Existing V6 under eligible-retirement-contract.md is an implementation plan,
not a renewed unrestricted review or runtime proof. Community BSD setup refuses.
Linux/macOS/Windows eligibility, ordinary retained TCP recv/send submitted before
cancel, stable owners and no loop reentry/callback-time destruction are required.

## Ownership and exact extension points

All references are to frozen .uwz-work/drafts/m2-h1-baseline.
Transport owns tcp.zig checked_upload_owner1985,on_read_complete1992,
on_write_complete2049,close_after_flush2158,close_connection2174,
cancel callbacks2288/2303,release_closed_connection2350; arm_read1550,
start_write1734,arm_write1743,resume_async_dispatch1507. Cold storage owns
RetirementPhase, two inline timer completions, callback pins, pending resumes,
close_pending,is_drained49,reset65,deinit81. Consume existing core/loop.zig
cancel_ack_decision100,LoopHandle.cancel_ack131,fail_callback138,cancel162;
no replacement classifier/failure observer. Shared BodyState request_cancel219,
reject_begin172,accept_begin162,finish_terminal240 remain authoritative.

The existing checked owner/guarded handle is the seam. Deletion would scatter
ACK semantics, callback borrows, retirement timers and release eligibility.
A forwarding layer or generic action framework earns no new invariant.

## Required transitions

1. Enabled close records conn.closing and one-shot close_pending, stops new work,
   defers cleanup/close while delivery/native frame pins hold. Repeated requests
   never duplicate cancellations or resurrect consumed close intent. Owner-null
   behavior stays unchanged.
2. Cleanup runs under delivery_active across application/output teardown callbacks.
   Admission close prevents later reservation. Successful begin gets one real
   terminal callback; failed/unstarted begin gets none. Only reject_begin or
   finish_terminal boolean releases admission after callback unwind. Close intent
   wins over resumes. Do not destroy TLS, request metadata or output too early.
3. Target callback sets direction frame pin before clearing target-active. On
   disarm request retirement before clearing frame pin as final state write.
   Never physically close/release there. Preserve supported rearm separately
   from overwriting/resubmitting a disarmed retained completion.
4. Set cancel flag before guarded single cancellation and hold through ACK.
   Fresh direction submissions wait for callback/cancel/retirement obligations.
   In particular on_write_complete currently start_write before returning; use
   write_resume_pending when that would overwrite borrowed completion. arm_read
   reached by resume_async_dispatch requires the corresponding read gate.
5. Use actual owner.loop_handle.cancel_ack. Epoll success may abandon target;
   epoll NotFound retains. io_uring success/NotFound/ExpirationInProgress retain;
   kqueue/IOCP success retain. Other errors enter typed fatal fence. ACK never
   proves callback retirement. Coalesce retirement before clearing cancel flag
   as ACK callback final state write; retain never reacquires a cleared pin.
6. Idle retirement request becomes first and runs Timer.run(0) on direction's
   dedicated completion. First expiry becomes second, schedules a fresh zero
   timer on fired completion and returns disarm. Second expiry completes old
   writes and becomes idle before tail dispatch. No owner/connection access
   after tail can release. A nested late ACK starts fresh sequence without outer
   overwrite. Never reset active timer, use native recv/send/cancel storage as
   timer or return timer rearm. Propagate timer errors through retirement fence.
7. Physical close requires no target/frame/cancel/delivery/retirement pin and
   completed body terminal cleanup. Consume close_pending=false before issuing.
   Preserve Windows synchronous close_socket/close_complete/release pairing only
   at safe tail. Public completion state cannot fabricate retirement.
8. Enabled close error enters close fence before close_complete. No retry grants
   retirement. release_closed_connection alone returns pool slot, additionally
   requiring drained owner; clear callback/pool ownership before pool callback
   as final action. Nothing accesses possibly released storage afterward.

## Ordered slices and pure acceptance

A. Production-used pure transitions and actual one-shot close eligibility/claim,
   reuse existing fields, no speculative state/failure fields/framework.
B. Native target/ACK/timer wiring and all early-return/pending-submission tails.
C. Deferred cleanup/close/release with actual shared body ownership. Consult HTTP
   and router for terminal/admission and crypto for deferred TLS destruction.
D. Root integration and independent actual-source review, not a fourth whole V6
   design cycle. All existing final gates remain.

Use inert caller data and actual production transition functions, not fabricated
native callback invocations. Test early/late ACK ordering, coalesced requests,
independent directions and new retirement after idle. Each target/frame/ACK/
delivery/body/retirement obligation separately denies close; ready claim succeeds
once. Close beats resume and consumed intent cannot revive. Actual BodyState
close during begin/chunk, failed begin, accepted cancellation and terminal unwind
release admission once after borrows. Preserve metadata/generation under pins.
An inert pool callback exercises actual release gate and sees ownership already
cleared. Reuse actual ACK classifier errors; source proof latch-before-panic,
no panic subprocess. These tests prove policy, not kernel timing/quiescence.

## Dependencies and limits

Pure policy is independently testable. Enabled lifetime path needs real driver
tails to hold/release delivery_active, run actual terminal callbacks and release
admission; synthetic sinks or default inactive BodyState cannot complete it.
Do not activate merely because upload_owner exists. No new activation flag.
Resolver/body delivery/TLS extraction/parser policy/public surface separate.

Local c223bd886c6a51d2cd60def39dd9a68d701fea73/tree86c6944f53dc009d7503a9ab0bc873aef3cd7b79
prerequisites remain unadopted: dead targets, duplicate cleanup, IOCP normalization,
worker publication, epoll registration rollback. Maintained publication/protections,
ledger/provenance/allfourzon adoption external; Root pin c49 remains unchanged.
Final fmt including builds, conventions, release/dependency/package, Debug,
ReleaseSafe, sanitizers/MSan, Smith/OSS-Fuzz, ReleaseFast, compliance/cross-target,
performance, native Windows and real plaintext/TLS/protocol/generation gates stay.
Stopped native cancellation/fault/race/crash/leak/registration-error/invalid-fd/
resource exhaustion/injected completion experiments must never be reconstructed.
