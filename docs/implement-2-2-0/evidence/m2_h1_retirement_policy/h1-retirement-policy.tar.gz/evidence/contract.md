# Accepted stage A policy contract

Root accepted the following exact preparation boundary after the architect handoff. This does not implement or prove the future native delivery/lifetime path.

- request_retirement(*RetirementPhase) bool: idle becomes first and true requests a fresh boundary. Nonidle requests coalesce without changing phase.
- RetirementExpiry = enum { arm_second, tail }; RetirementError = error{RetirementInactive}. expire_retirement(*RetirementPhase): first becomes second/arm_second; second becomes idle/tail; idle returns RetirementInactive without mutation. The tail consumer must re-read current obligations: late retirement after idle creates a fresh sequence.
- CloseSnapshot contains six required bools with no defaults: closing, close_complete, read_active, is_writing, read_cancel_active, write_cancel_active.
- claim_close(*Http1UploadStorage, CloseSnapshot) bool: initialized storage, healthy optional failure fence, closing, !close_complete and close_pending establish valid intent. Invalid/uninitialized/failed-fence inputs change nothing. Valid intent clears both pending resume-work flags even when other pins defer physical close. False may therefore clear work, never ownership pins. Only when native target/ACK flags and shared owner body/frame/delivery/retirement/completion gates permit close does it consume close_pending and return true. It never sets close_pending and never mutates other state.
- One canonical owner-pin predicate is shared with is_drained; close_pending must not veto its own claim. is_drained retains its existing initialization/fence/close-intent and owner-pin semantics.

Future actual consumers: target disarm and cancel ACK tails in tcp.zig request direction retirement before the final frame/ACK flag clear; new direction timer callbacks expire to a fresh Timer.run(0) boundary or safe tail; physical-close tail calls claim_close before the platform close branch. close_connection records intent only on its existing !closing transition. Native submission/resume gates and actual cleanup remain subsequent slices.

RetirementInactive is a pure transition error here. Future native wiring must reconcile unexpected-phase invariant handling with the existing typed failure fence; it must not invent a benign timer-error mapping. ACK classification remains the existing core_loop classifier. No new fields, layout growth, activation flags, error records, native calls or callback wiring are authorized.
