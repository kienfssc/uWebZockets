# Pure H1 retirement policy handoff

Final source: `/tmp/uwz-m2-h1-retirement-policy`, frozen 1020 files mode 0444. Digest `d85afc4d1b5cb2d22013feef623e5757abcab8ada0d53e3d01c3451676060d6c`. Predecessor cold-v3 V2 digest `35bcfec2f32c0f0789b534f0832a37b2e3dd543d97ccdbed52655719005d4fb1` is unchanged. The new copy has independent file inodes, no hardlinks/symlinks and no inherited cache. Durable code is in `snapshots/final-green/`; `final.patch`, `final-source-manifest.json`, `copy-manifest.json` and `summary.json` bind source and provenance.

## Change and exact contract

Only `src/core/http1_upload_storage.zig` and appended `src/tests/body_app_tests.zig` change. request_retirement moves idle to first and reports that a fresh timer boundary is required; nonidle requests coalesce unchanged. expire_retirement moves first to second/arm_second, then second to idle/tail; idle expiry returns RetirementInactive without mutation. A late request after idle starts a fresh obligation, so a previously returned tail result never grants unchecked release.

CloseSnapshot is a flat value with six required bools and no defaults: closing, close_complete, read_active, is_writing, read_cancel_active and write_cancel_active. It is never stored. claim_close first validates initialized storage, optional healthy failure fence, closing, !close_complete and close_pending. Invalid inputs change nothing. For valid intent it suppresses both pending resume-work flags even if ownership pins defer physical close; false may therefore discard pending work. Only after all native target/ACK and canonical owner body/frame/delivery/retirement/completion gates drain does it consume close_pending and return true. It never restores intent or mutates body/reservation/native ownership flags. The caller creates intent only on its existing monotonic first closing transition.

is_drained and claim_close share one private owner-pin predicate. Initialized/fence validity remains explicitly checked before that predicate. Splitting the old close_pending guard from the callback-phase guard leaves is_drained's boolean semantics unchanged while allowing close intent to claim its own close. The stored owner struct, reset/deinit tail and all previous 20 App tests (including three cold-v3 invariants) are byte-identical to the predecessor. There are no new stored flags, callback functions, TCP imports, allocations, native calls, classifiers, error records or generic dispatch framework.

## Failing-first and verification

Both preserved red compiles fail on the missing actual policy API in the predecessor. `snapshots/red-missing-policy/` and `snapshots/red-final-tests/` contain exact two-file code for their recorded source digests; the latter includes all final assertions before implementation. No fake/no-op policy was written to manufacture a runtime failure. After implementation the 11 focused tests call the actual policy, covering coalescing, idle expiry refusal, independent directions, fresh late obligations, each native target/ACK/frame/delivery/callback/body/retirement pin family, invalid unchanged inputs, deferred resume suppression without dropping ownership pins, and once-only close claim.

| Assigned check | Outcome |
|---|---|
| Focused policy Debug / ReleaseSafe | 11/11 each |
| Whole App Debug / ReleaseSafe, ordinary OS | 31/31 each; original 20 unchanged |
| Existing pure admission Debug / ReleaseSafe | 7/7 each |
| Eligible centralized native/macOS/Windows graph |ReleaseSafe compile-only, all 0 |
| Scoped full zig fmt / conventions / release metadata |all 0 |
| Isolated graphify update |AST-only 0; temporary output symlink removed |

All final records bind source `d85afc4d1b5cb2d22013feef623e5757abcab8ada0d53e3d01c3451676060d6c` before and after, direct module/compiler/library inputs before and after, and all 93 immutable c223 override hashes before and after. The actual subprocess environment is copied, explicitly sets UWZ_TEST_XEV_BACKEND=io_uring, is passed as env=env, and the recorded value is read from that actual mapping. Run records bind compiled artifact and binary hashes before/after; no environment secrets are dumped. Full argv, real statuses and raw outputs are retained. Healthy App runs used authorized ordinary OS access directly, without known sandbox backend retries. The two expected missing-API reds are the only nonzero compiler/test outcomes in this slice.

## No stored layout growth

Before/after actual compiler proofs check all 25 stored fields, size, alignment and every field offset against cold-v3 V2. They pass for Linux native (2880 bytes, align 8), aarch64 macOS (2848, align 8) and x86_64 Windows GNU (3040, align 8). Probes are retained under `layout-probes/`. The stored struct is also byte-identical. Slab-sizing sources and inputs are unchanged; there is zero additional enabled or disabled slab growth. The unchanged cold-v3 totals remain Linux 684177024/687136384, macOS 684095104/687021696 and Windows 684676736/687799936 (disabled/enabled). These totals were not remeasured or adjusted in this slice.

## Binding limits and next actual consumers

The pure fixtures use inert initialized caller-owned data and an explicit inactive, never-started body. Negative body-phase/reservation checks prove gates, not actual terminal callback cleanup. The failed-fence fixture reads only the initialized fence; its undefined native loop payload is never read, copied or passed to a native API. No fabricated native completion or callback invocation occurs. Existing c223 completion.state checks its own initialized tagged value, independently of dynamic backend selection.

Actual future consumers are TCP target disarm and ACK tails, new direction timer callbacks, and the safe physical-close tail before the existing platform branch. Requests must precede final frame/ACK flag clearing; timer callbacks must arm fresh Timer.run(0) boundaries, then call a tail with no owner access after it could release. That integration is not present or proven here. Future native handling of unexpected RetirementInactive must reconcile the invariant with the existing typed failure fence; it must not invent a benign timer-error mapping or duplicate the ACK classifier.

Actual accepted body callbacks/admission release, delivery lifetime, cleanup ordering, resume/submission gating, release gate integration, real plaintext/TLS uploads, Windows runtime and fullRoot release checks remain subsequent work. No new stopped native cancellation/interleaving/race/crash/leak/registration/invalid-fd/resource/kernel/injection or panic probe was reconstructed. Root sources, dependency pins, maintained refs and predecessor were not edited; no fetch, commit, push or publication occurred. Root owns independent review and integration.
