from pathlib import Path
import json,sys,hashlib,subprocess,time
root=Path('/workspaces/uWebZockets');out=root/'.uwz-work/evidence/h1-retirement-policy';draft=Path('/tmp/uwz-m2-h1-retirement-policy');art=Path('/tmp/uwz-m2-h1-retirement-policy-artifacts');phase=sys.argv[1]
for target in ['native','aarch64-macos','x86_64-windows-gnu']:
 expected=json.loads((root/'.uwz-work/evidence/h1-cold-v3'/('after-'+target+'-values.json')).read_text());fields={k.removeprefix('offset_'):v for k,v in expected.items() if k.startswith('offset_')};probe=art/('layout-proof-'+target+'.zig')
 code='const support = @import("test_support");\nconst Owner = support.http1_upload_storage.Http1UploadStorage;\ncomptime {\n'
 code+=f'    if (@sizeOf(Owner) != {expected["owner_size"]}) @compileError("owner size changed");\n    if (@alignOf(Owner) != {expected["owner_alignment"]}) @compileError("owner alignment changed");\n    if (@typeInfo(Owner).@"struct".fields.len != {len(fields)}) @compileError("stored field count changed");\n'
 code+=''.join(f'    if (@offsetOf(Owner, "{name}") != {offset}) @compileError("stored field offset changed: {name}");\n' for name,offset in fields.items());code+='}\n';probe.write_text(code)
 argv=[]
 for arg in json.loads((root/'.uwz-work/evidence/m2-h1-baseline'/('layout-'+target+'.json')).read_text())['argv']:
  if arg.startswith('-Mroot='):arg='-Mroot='+str(probe)
  elif arg.startswith('-Mc='):arg='-Mc='+str(art/'bindings'/('c-'+target+'.zig'))
  elif arg.startswith('-femit-llvm-ir='):continue
  elif arg=='/tmp/uwz-m2-h1-baseline-cache':arg='/tmp/uwz-m2-h1-retirement-policy-cache'
  elif arg=='/tmp/uwz-m2-h1-baseline-global':arg='/tmp/uwz-m2-h1-retirement-policy-global'
  argv.append(arg)
 # Reuse the same actual-environment/source/input/override recording boundary.
 script=Path('/tmp/uwz-m2-h1-retirement-policy-driver.py').read_text();namespace={'__name__':'__main__'};script=script[:script.index('kind,label=sys.argv[1:3]')];exec(script,namespace);namespace['kind']='layout-proof';status=namespace['execute'](phase+'-layout-proof-'+target,argv,'compile-time proof of exact stored field count, size, alignment and every field offset; no execution')
 assert status==0,(phase,target,status)
 print('Layout unchanged:',target,'size',expected['owner_size'],'alignment',expected['owner_alignment'],'fields',len(fields),flush=True)
