# Task 3b feature fixtures: compile preparation complete, runtime pending

The v2 standalone profile compiles in ReleaseSafe; the final Python scripts
parse and the Zig profile passes formatting. No server/client execution, port
precheck/contact, protocol success, allocation instrumentation or native lifetime
claim is made for v2. Root owns independent review and any later ordinary run.

Only `.uwz-work/evidence/h1-plaintext/integration-v2/` and this NEW report were
edited. V1, approved corrected fixtures, Root's coherent source, production,
refs, pins, build graph and correction report remain unchanged. No agents,
commits, dependency fetches or package views were created. Prior WIP/preimages
are retained; the client was rebased on the approved corrected client.

## Actual compilation and source checks

Exact command executed from `/workspaces/uWebZockets`:

```sh
python3 .uwz-work/evidence/h1-plaintext/integration-v2/compile.py --record compile-features-r1
```

Raw result: `Exit status: 0`; `compile-features-r1.log` is empty. The explicit
argv is preserved in `compile-features-r1.command.json` and final
`compile-features-r1.json`. It invokes
`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build-exe`,
`-OReleaseSafe`, `-j2`, original r2 native C bindings, c223 libxev override and
existing native libraries. All output/caches are in the fresh
`/tmp/uwz-h1-profile-v2-preparation` directory. No prior cache was inherited.

Binary: `/tmp/uwz-h1-profile-v2-preparation/profile`

```text
sha256 c64d528df32ab227fa14f93e1db3299a8d5af02b7b5a925dea1b5ca0fbd8c865
```

The complete coherent source inventory has 1023 files, with identical before
and after canonical digests:

```text
acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b
```

`compile-features-r1-source-inputs.json` and `-source-after.json` retain both
full inventories. All 93 c223 override file hashes match the immutable manifest
before and after. The final record retains compiler/module-entry/library and
fixture pre/post hashes, exact argv/cwd/explicit environment, status, binary hash
and `inputs_unchanged: true`. The current profile/probe/compile hashes still
match the compile inputs. Final fixture identities and counts are also retained
in `preparation-features.json`; its scope is the recorded inputs, not a claim
that this worker inventoried every transitive external package source.

Exact additional commands:

```sh
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check .uwz-work/evidence/h1-plaintext/integration-v2/profile.zig
python3 -c 'import ast; from pathlib import Path; base = Path(".uwz-work/evidence/h1-plaintext/integration-v2"); [ast.parse((base / name).read_text(), filename=name) for name in ("probe.py", "compile.py")]; print("Python AST syntax passed; no harness execution")'
```

Raw results: formatter output empty, exit0; Python exit0 and
`Python AST syntax passed; no harness execution`. AST-only comparison additionally
proved all 21 approved case entries unchanged, together with the corrected
payload/send/upload/file/pipeline/refusal/failed-begin/413-trace functions listed
in `ast-review.json`. `response` adds only an optional generated-pattern
comparison branch for the new producer; default callers preserve their parser.
No harness was imported/executed for these checks.

No full project matrix, sanitizer, fuzz, compliance or runtime check was run for
v2, and no such check is implied by successful fixture compilation.

## Public API and ownership review

The profile imports only `std` and public `uWebZockets`. It keeps default small
ingress/body/window capacities and eight App connections. Three fixed
caller-owned route binding slots correspond to `/upload/:tag` (100000000),
`/limit/:tag` (32) and `/empty/:tag` (0), each with max_active1. Each route has its
own real copied BodyControl/stale token and counters. `/status`, `/resume`,
`/cancel`, `/stale` accept an explicit bounded `slot=0/1/2` selector; the legacy
unqualified form selects the most recent binding for the retained 21 cases.
The header-only middleware still preserves X-Middleware:retained.

Slot storage, control copies, route contexts, definitions and metrics are
stack-owned outside the App's scope and outlive logical callback cleanup.
Begin saves bounded initial metadata copies plus individual pinned byte slices,
never request/array-view pointers. Chunk hashing/counting accepts only the
returned prefix. Chunk/end/producer have no allocator call. This is inspected
source/compiled contract evidence, not a leak or allocator instrumentation run.

The outgoing producer context and its 8192-byte scratch belong to a separate
State field, independent of all upload binding slots. End copies its bounded
metadata records, individual pinned slices and accepted upload hash/count into
that independent context. Every real producer invocation checks the borrowed
bytes against independent bounded copies, then builds output from those
borrowed bytes. A flag set on end callback exit distinguishes subsequent real
producer calls. There is no private callback call, fabricated completion,
callback-only request retention, or invented producer abort hook.

Public `Response.begin_stream`/`write_chunk`/`end_chunks` define the actual
producer contract (`src/http/response.zig:56-72,576-600`): immediate invocation,
drain-driven reinvocation, pending on WouldBlock, done after end_chunks. Returning
done means framing was queued; it is NOT treated as proof of wire completion.
The client separately reads and compares the entire framed output and clean EOF.
Producer storage is deliberately single-use and retained for the server lifetime,
because the public API has no abort callback. Its metadata slices are read only
by active producer calls, not by later status/final snapshots.

Controls are copied before terminal operations. No binding fields are accessed
after a resume/cancel that might finish it inline. End-error mode owns its own
binding cleanup and returns its real callback error; the driver, not the fixture,
owns terminal/admission release. The client checks no second cancel and real
same-route reuse. No router counter, driver policy or native completion is
faked or called directly by the fixture.

## Exact prepared matrix: 26 total, all v2 runtime pending

There are **25 request/API cases in run_cases plus one owned lifecycle shutdown
case = 26**. The approved corrected baseline contributed21, not the earlier
Task3a report's mistaken21 for its original20. The approved21 entries remain:

```text
fixed_exact100000000
chunked_exact100000000
empty
empty_chunked
limit_exact32
limit_chunked_exact32
limit_chunked_over33
limit_chunk_size_only33
begin_expect100
partial_prefix
final_byte_fixed
final_byte_chunked
stream_stream_buffered_pipeline
file_health_pipeline
file_close
declared_limit_refusal
failed_begin
sink_error
invalid_progress
application_cancel_quota
malformed_chunk
```

Both exact decimal100000000 cases, nonzero bounded generation/final sentinel,
independent hash/count/end checks, metadata/middleware checks and real file
pipeline/close comparisons remain. Strict declared413/quota503, corrected
failed-begin clean EOF/no100 plus same-route retry, complete413-before-closure
tracing, separate post413 EOF/reset and size-line-only rejection remain. Reset
before complete413 and any surplus still fail.

| New case | Ordinary action and prepared assertions |
| --- | --- |
| producer_metadata_after_upload | Upload257 normally with real100; observe end and inactive binding over HTTP; verify accepted hash/count and expired upload control; reuse the same route binding with a successful new request; receive16777313 output bytes formed from initial target/capture/header/query and independently hash/compare every chunk; require retained metadata checked on every producer call and at least one call after end exit; require clean framed EOF and exact two begin/end/no-cancel accounting |
| simultaneous_distinct_routes | Hold upload257, limit32 and empty0 with public begin-pause and real100; HTTP status must show all three real caller slots admitted simultaneously with no terminal callback; send bounded bodies, resume each via its indexed real token, compare all three digests/metadata/headers, verify exact per-slot end counts/expired controls and clean EOF |
| ordinary_peer_disconnect | Send7 of declared257 after real100; HTTP status proves the prefix was accepted by an active binding; ordinary socket context close sends no linger/forced-reset manipulation; status must show exactly one peer_closed cancel/no end, correct slot and expired token; a successful same-route retry proves reusable admission |
| end_callback_error | Fully send257 after real100; real end callback returns ApplicationEndRefused; record actual output-abort terminal, require one end/one end_error/no second cancel, inactive binding and accepted257; verify expired control and actual successful same-route retry with exact terminal deltas |
| owned_shutdown_active_upload | After the25 request cases, send7 of declared257 after100 and prove active accepted prefix over HTTP; retain client socket while the existing owned runner sends SIGTERM to its own Popen child; require normal child0/reap/no forced kill, clean upload EOF, one shutdown cancel/no end, correct7-byte slot and no unrelated terminal increments from a single real post-deinit counter snapshot and post-deinit marker |

Observer deadlines only bound ordinary HTTP readiness/status checks. Every test
action is gated by an actual reported state, not a timer offset, native schedule,
completion injection or race assumption. The disconnect is ordinary socket close;
shutdown is the existing owned SIGTERM lifecycle, not a low-level cancellation
schedule or fault probe. No resource/kernel/descriptor/registration/crash/leak/
panic experiment was prepared or run.

## Lifecycle and result integrity

The client reuses normal static helper precheck, listener PID/socket-inode
ownership and bounded digest helpers. Bytecode writing is disabled BEFORE helper
exec_module. It preserves the optional Nix loader/library prefix, actual argv/cwd,
explicit H1_PROFILE values, build/binary/client/Python/helper identities, PID,
listener/health readiness and per-case evidence. A forced owned-child kill remains
a failure. It never contacts or kills an unrelated process.

Shutdown is a separate pending result while the owned socket remains held in an
ExitStack. It becomes passed only after child wait/reap, clean upload EOF, exact
terminal-counter validation, exactly one `H1_FINAL` JSON snapshot emitted AFTER
App deinit and `h1 profile shutdown drained`. The final snapshot reads independent
server metrics; it never dereferences expired controls or freed App storage. A
pending or failed shutdown case cannot satisfy the final all-cases gate.

Only generated fixtures/binaries/caches/live artifacts under owned `/tmp` paths
are used. Runtime case records retain actual headers/hashes/lengths/counters and
individual failures, including partial sender counts and complete413 before
closure inspection. Root must retain the small actual raw results/logs after its
run. This preparation report contains no new live result.

## Root runtime prerequisite and exact invocation

Root must review the final profile/client/diffs and authorize the ordinary run.
The already compiled binary is bound to the coherent acff1023 source and final
fixture hashes in `compile-features-r1.json`; no rebuild is needed if those inputs
remain exact. A complete invocation is:

```sh
python3 .uwz-work/evidence/h1-plaintext/integration-v2/probe.py --source /tmp/uwz-m2-h1-plaintext-combined --server /tmp/uwz-h1-profile-v2-preparation/profile --build-record /workspaces/uWebZockets/.uwz-work/evidence/h1-plaintext/integration-v2/compile-features-r1.json --artifacts /tmp/uwz-h1-profile-v2-live-records --port 18886 --root-authorized-runtime
```

Root must choose its own currently unused owned port and a NEW artifacts directory;
18886 is the explicit example, not a claim that this worker checked availability.
Append `--loader "$nix_loader" --library-path "$nix_library_path"` using the actual
normal Nix values when needed. No new package/build requirement is introduced.
The authorization flag prevents accidental invocation; it does not grant runtime
permission by itself.

## Precise remaining limitations

- Every new v2 case is compile/source prepared only; Root review/runtime remain.
- Producer storage is single-use fixed server-lifetime storage; no producer abort
  lifecycle or reclamation hook is claimed. Healthy complete output is the new case.
- End callback error intentionally aborts output without promising a particular
  status; partial/malformed response remains a failure. No new status was guessed.
- Wire receipt, control/accounting and post-deinit drain checks cannot substitute
  for allocator instrumentation, whole native liveness proof or platform validation.
- TLS/H2/H3 uploads, community BSD activation, native Windows/macOS runs, full
  project gates and wider milestone delivery remain outside this preparation.
- The original stopped native experiments remain stopped. Full matrix/compiler,
  sanitizer/fuzz/compliance/performance requirements remain with Root; this fixture
  does not weaken, replace or satisfy them merely by compiling.

Review artifacts: complete `.zig`/`.py` source, paused/original/approved preimages,
three unified diffs, `ast-review.json`, full compiler records and
`preparation-features.{json,log}` are durable in integration-v2. No graph refresh
was performed because only ignored private evidence was edited and graph files
are outside this worker's ownership.

## Scoped review fix round1: producer progress after binding reuse

Status: READY_FOR_SCOPED_REVIEW. This addresses only the Important finding in
`integration-v2/review-features.md`. No runtime/server/client/port contact occurred.
The earlier r1 current-input binding and invocation above are historical; use
`compile-features-fix1.json` and the fix1 executable for the updated client.

The reviewed client SHA256 was
`114c1fcb7a1d520887772993bb3475f43a4188fa4a5cc53018493b67eca5c561`.
Before editing, exact reviewed profile/client/compiler preimages, the complete
r1 compile records and review were copied into `integration-v2/fix-round-1/`.
The exact five-line scoped patch was written before applying it; its actual diff
matches `fix-round-1/producer-progress.patch`. Original r1 records remain exact,
with hashes retained in `r1-preservation.json`.

Only `producer_case` assertions/evidence changed:

1. After the successful rebound request returns, obtain a NEW actual public
   status and retain it as `after_binding_reuse`.
2. Require producer_done=false AND producer_bytes<16777313 at that snapshot.
   If the pending state is absent, the case fails with scenario coverage missing;
   completed output accepted by socket buffering cannot count as this coverage.
3. After exact output reception and EOF, require producer_calls and
   producer_calls_after_end to exceed that post-reuse snapshot, and require
   producer_metadata_checks and producer_bytes to progress beyond it. Existing
   exact output hash, all-call metadata validation, terminal counters and clean
   EOF assertions remain.

This proves the prepared case demands actual producer work and retained-byte
validation after binding overwrite, rather than merely after the old end
callback. No output size, socket buffer, timer, scheduling/controller behavior,
profile, producer API or compiler script was changed.

New client SHA256:

```text
34c47eb70712fb8c2ddd50fbb1a11ff078890ee9a5ea5781360dea6c6d82546f
```

Exact source-scope verification command:

```sh
python3 .uwz-work/evidence/h1-plaintext/integration-v2/fix-round-1/scope_check.py
```

Raw `scope-check-replay.log`, exit0:

```text
Python AST syntax: passed; exit status 0
Only producer_case AST changed; all other module AST unchanged
Approved21 case entries unchanged;25 request/API +1 owned shutdown =26
profile.zig and compile.py exactly unchanged
No runtime/server/client/port contact
Fixed probe SHA256: 34c47eb70712fb8c2ddd50fbb1a11ff078890ee9a5ea5781360dea6c6d82546f
```

The script AST-parses only; it never imports/runs the fixture. It compares every
other module AST node against the reviewed preimage and checks the approved21
entries. Profile and compiler script are byte-identical to reviewed r1.

An actual compile-only replay binds the updated fixture-input hash honestly,
preserving the previous record. Exact command:

```sh
python3 .uwz-work/evidence/h1-plaintext/integration-v2/compile.py --output /tmp/uwz-h1-profile-v2-fix1 --record compile-features-fix1
```

Raw result `Exit status: 0`; `compile-features-fix1.log` is empty. The recorded
explicit compiler invocation remains ReleaseSafe, -j2, original r2 bindings,
c223 override and existing native libraries. Its full1023-source pre/post digest
is still `acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b`;
override93 and all recorded module/compiler/library/fixture hashes are unchanged
across this replay. The final record, full source before/after inventories and
`fix-round-1/preparation.json` retain status and identities. No source cache or
other input was written inside the coherent source directory.

New executable: `/tmp/uwz-h1-profile-v2-fix1/profile`, actual SHA256:

```text
dcf51dcd57be752ec2acad4773048d9a897cba9605368d80dab8d6744d440a57
```

That artifact hash differs from r1; no byte-identity claim is made. Reviewed
profile/compiler sources are unchanged and each executable retains its own exact
compile record. Root's later approved invocation should select the fix1 binary,
`compile-features-fix1.json` and a NEW runtime artifacts directory. No v2 runtime
has occurred, and no coverage result is inferred from this source-only fix.

Scoped re-review paths: `integration-v2/probe.py:425`,
`integration-v2/fix-round-1/producer-progress.patch`,
`integration-v2/fix-round-1/{scope-check.json,scope-check-replay.log,preparation.json}`,
`integration-v2/compile-features-fix1.{command.json,json,log}` and this appended
section. Unrelated feature/controller work remains untouched.
