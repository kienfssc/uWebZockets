const std = @import("std");
const uz = @import("uWebZockets");
const Hash = std.crypto.hash.sha2.Sha256;
const producer_length = 16 * 1024 * 1024 + 97;

const Metadata = struct {
    expected: [512]u8 = undefined,
    length: usize = 0,
    borrowed: []const u8 = "",
};
const Slot = struct {
    owner: *State,
    index: usize,
    active: bool = false,
    hash: Hash = Hash.init(.{}),
    bytes: u64 = 0,
    pause_at: ?u64 = null,
    paused_once: bool = false,
    mode: enum { normal, sink_error, invalid_progress, end_error, producer } = .normal,
    metadata: [6]Metadata = [_]Metadata{.{}} ** 6,
};
const Counts = struct {
    begin_calls: u64 = 0,
    failed_begins: u64 = 0,
    begins: u64 = 0,
    ends: u64 = 0,
    end_errors: u64 = 0,
    cancels: u64 = 0,
    reason: []const u8 = "none",
};
const RouteState = struct {
    slot: Slot = undefined,
    control: ?uz.BodyControl = null,
    stale: ?uz.BodyControl = null,
    counts: Counts = .{},
};
const RouteContext = struct { state: *State, index: usize };

// No abort callback exists; producer storage remains owned until App deinit.
const Producer = struct {
    occupied: bool = false,
    end_returned: bool = false,
    done: bool = false,
    calls: u64 = 0,
    calls_after_end: u64 = 0,
    metadata_checks: u64 = 0,
    bytes: u64 = 0,
    upload_bytes: u64 = 0,
    upload_sha256: [64]u8 = undefined,
    metadata: [6]Metadata = [_]Metadata{.{}} ** 6,
    block: [8192]u8 = undefined,
};
const State = struct {
    routes: [3]RouteState = [_]RouteState{.{}} ** 3,
    last_slot: usize = 0,
    counts: Counts = .{},
    producer: Producer = .{},
};
const Snapshot = struct {
    begin_calls: u64,
    failed_begins: u64,
    begins: u64,
    ends: u64,
    end_errors: u64,
    cancels: u64,
    reason: []const u8,
    active: bool,
    bytes: u64,
    pause_reached: bool,
    slot_active: [3]bool,
    slot_bytes: [3]u64,
    slot_begins: [3]u64,
    slot_ends: [3]u64,
    slot_cancels: [3]u64,
    slot_reasons: [3][]const u8,
    producer_calls: u64,
    producer_calls_after_end: u64,
    producer_metadata_checks: u64,
    producer_bytes: u64,
    producer_done: bool,
    producer_upload_bytes: u64,
    producer_upload_sha256: []const u8,
};

fn snapshot(state: *const State, index: usize) Snapshot {
    var value: Snapshot = .{
        .begin_calls = state.counts.begin_calls,
        .failed_begins = state.counts.failed_begins,
        .begins = state.counts.begins,
        .ends = state.counts.ends,
        .end_errors = state.counts.end_errors,
        .cancels = state.counts.cancels,
        .reason = state.counts.reason,
        .active = state.routes[index].slot.active,
        .bytes = state.routes[index].slot.bytes,
        .pause_reached = state.routes[index].slot.paused_once,
        .slot_active = undefined,
        .slot_bytes = undefined,
        .slot_begins = undefined,
        .slot_ends = undefined,
        .slot_cancels = undefined,
        .slot_reasons = undefined,
        .producer_calls = state.producer.calls,
        .producer_calls_after_end = state.producer.calls_after_end,
        .producer_metadata_checks = state.producer.metadata_checks,
        .producer_bytes = state.producer.bytes,
        .producer_done = state.producer.done,
        .producer_upload_bytes = state.producer.upload_bytes,
        .producer_upload_sha256 = if (state.producer.occupied) &state.producer.upload_sha256 else "",
    };
    for (&state.routes, 0..) |*route, slot_index| {
        value.slot_active[slot_index] = route.slot.active;
        value.slot_bytes[slot_index] = route.slot.bytes;
        value.slot_begins[slot_index] = route.counts.begins;
        value.slot_ends[slot_index] = route.counts.ends;
        value.slot_cancels[slot_index] = route.counts.cancels;
        value.slot_reasons[slot_index] = route.counts.reason;
    }
    return value;
}

fn save(output: *Metadata, value: []const u8) !void {
    if (value.len > output.expected.len) return error.MetadataTooLong;
    @memcpy(output.expected[0..value.len], value);
    output.length = value.len;
    output.borrowed = value;
}

fn begin(context: *anyopaque, request: *const uz.StreamingRequest, control: uz.BodyControl) !uz.BodyBinding {
    const route_context: *RouteContext = @ptrCast(@alignCast(context));
    const state = route_context.state;
    const route = &state.routes[route_context.index];
    state.counts.begin_calls += 1;
    route.counts.begin_calls += 1;
    const mode = request.headers.get("x-mode") orelse "normal";
    if (std.mem.eql(u8, mode, "failed_begin")) {
        state.counts.failed_begins += 1;
        route.counts.failed_begins += 1;
        return error.ApplicationBeginRefused;
    }
    if (route.slot.active) return error.FixtureSlotBusy;
    route.slot = .{ .owner = state, .index = route_context.index };
    const slot = &route.slot;
    const tag = request.params.get("tag") orelse return error.MissingTag;
    const marker = request.headers.get("x-metadata") orelse return error.MissingMetadata;
    const values = [_][]const u8{ request.method, request.target, request.path, request.query, tag, marker };
    for (&slot.metadata, values) |*output, value| try save(output, value);
    const pause = request.headers.get("x-pause") orelse "none";
    if (std.mem.eql(u8, mode, "sink_error")) slot.mode = .sink_error;
    if (std.mem.eql(u8, mode, "invalid_progress")) slot.mode = .invalid_progress;
    if (std.mem.eql(u8, mode, "end_error")) slot.mode = .end_error;
    if (std.mem.eql(u8, mode, "producer")) slot.mode = .producer;
    if (std.mem.eql(u8, pause, "partial")) slot.pause_at = 7;
    if (std.mem.eql(u8, pause, "final")) {
        slot.pause_at = try std.fmt.parseInt(u64, request.headers.get("x-size") orelse return error.MissingSize, 10);
    }
    const paused = std.mem.eql(u8, pause, "begin");
    slot.paused_once = paused;
    slot.active = true;
    state.last_slot = route_context.index;
    state.counts.begins += 1;
    route.counts.begins += 1;
    route.control = control;
    return .{ .context = slot, .readiness = if (paused) .paused else .ready };
}

fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    if (slot.mode == .sink_error) return error.ApplicationSinkRefused;
    if (slot.mode == .invalid_progress) return .{ .consumed = input.len + 1, .readiness = .ready };
    var accepted = input.len;
    var pause = false;
    if (!slot.paused_once) {
        if (slot.pause_at) |at| {
            accepted = @intCast(@min(input.len, at - slot.bytes));
            pause = slot.bytes + accepted == at;
        }
    }
    slot.hash.update(input[0..accepted]);
    slot.bytes += accepted;
    if (pause) slot.paused_once = true;
    return .{ .consumed = accepted, .readiness = if (pause) .paused else .ready };
}

fn check_metadata(saved: *const [6]Metadata) bool {
    for (saved) |*entry| {
        if (!std.mem.eql(u8, entry.expected[0..entry.length], entry.borrowed)) return false;
    }
    return true;
}

fn produce(context: *anyopaque, response: *uz.Response) !uz.StreamStatus {
    const producer: *Producer = @ptrCast(@alignCast(context));
    producer.calls += 1;
    if (producer.end_returned) producer.calls_after_end += 1;
    if (!check_metadata(&producer.metadata)) return error.ProducerMetadataChanged;
    producer.metadata_checks += 1;
    var seed_buffer: [6 * 512 + 8]u8 = undefined;
    const metadata = &producer.metadata;
    const seed = try std.fmt.bufPrint(&seed_buffer, "{s}|{s}|{s}|{s}\n", .{ metadata[1].borrowed, metadata[4].borrowed, metadata[5].borrowed, metadata[3].borrowed });
    while (producer.bytes < producer_length) {
        const length: usize = @intCast(@min(producer.block.len, producer_length - producer.bytes));
        for (producer.block[0..length], 0..) |*byte, offset| byte.* = seed[@intCast((producer.bytes + offset) % seed.len)];
        response.write_chunk(producer.block[0..length]) catch |err| switch (err) {
            error.WouldBlock => return .pending,
            else => return err,
        };
        producer.bytes += length;
    }
    response.end_chunks() catch |err| switch (err) {
        error.WouldBlock => return .pending,
        else => return err,
    };
    producer.done = true;
    return .done;
}

fn end(context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const state = slot.owner;
    const route = &state.routes[slot.index];
    defer slot.active = false;
    state.counts.ends += 1;
    route.counts.ends += 1;
    route.stale = route.control;
    route.control = null;
    if (slot.mode == .end_error) {
        state.counts.end_errors += 1;
        route.counts.end_errors += 1;
        return error.ApplicationEndRefused;
    }
    var metadata_ok = check_metadata(&slot.metadata);
    const values = [_][]const u8{ request.method, request.target, request.path, request.query, request.params.get("tag") orelse "", request.headers.get("x-metadata") orelse "" };
    for (&slot.metadata, values) |*saved, value| {
        metadata_ok = metadata_ok and std.mem.eql(u8, saved.expected[0..saved.length], value);
    }
    var digest: [Hash.digest_length]u8 = undefined;
    slot.hash.final(&digest);
    const hex = std.fmt.bytesToHex(digest, .lower);
    if (slot.mode == .producer) {
        if (!metadata_ok) return error.ProducerMetadataChanged;
        if (state.producer.occupied) return error.ProducerFixtureAlreadyUsed;
        const producer = &state.producer;
        producer.occupied = true;
        producer.metadata = slot.metadata;
        producer.upload_bytes = slot.bytes;
        producer.upload_sha256 = hex;
        defer producer.end_returned = true;
        try response.begin_stream("200 OK", "", producer, produce);
        return;
    }
    var output: [256]u8 = undefined;
    const body = try std.fmt.bufPrint(&output, "{{\"bytes\":{d},\"sha256\":\"{s}\",\"metadata_ok\":{}}}", .{ slot.bytes, hex, metadata_ok });
    try response.text(body);
}

fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const state = slot.owner;
    const route = &state.routes[slot.index];
    slot.active = false;
    state.counts.cancels += 1;
    state.counts.reason = @tagName(reason);
    route.counts.cancels += 1;
    route.counts.reason = @tagName(reason);
    route.stale = route.control;
    route.control = null;
}

fn middleware(_: *anyopaque, _: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
    response.append_header("X-Middleware", "retained") catch |err| {
        std.log.err("middleware failed: {}", .{err});
        return .stop;
    };
    return .continue_dispatch;
}

fn reply(response: *uz.Response, value: []const u8) void {
    response.text(value) catch |err| std.log.err("response failed: {}", .{err});
}

fn health(_: *uz.Request, response: *uz.Response) void {
    reply(response, "ok");
}

fn echo(_: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    reply(response, request.body);
}

fn selected_index(state: *const State, request: *const uz.Request) !usize {
    if (request.query.len == 0) return state.last_slot;
    if (std.mem.eql(u8, request.query, "slot=0")) return 0;
    if (std.mem.eql(u8, request.query, "slot=1")) return 1;
    if (std.mem.eql(u8, request.query, "slot=2")) return 2;
    return error.InvalidFixtureSlot;
}

fn status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const index = selected_index(state, request) catch |err| {
        reply(response, @errorName(err));
        return;
    };
    var output: [4096]u8 = undefined;
    response.json_buf(snapshot(state, index), &output) catch |err| std.log.err("status response failed: {}", .{err});
}

fn control_route(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const index = selected_index(state, request) catch |err| {
        reply(response, @errorName(err));
        return;
    };
    const route = &state.routes[index];
    const stale = std.mem.eql(u8, request.path, "/stale");
    const control = (if (stale) route.stale else route.control) orelse {
        reply(response, "missing");
        return;
    };
    const result = if (std.mem.eql(u8, request.path, "/cancel")) control.cancel() else control.@"resume"();
    result catch |err| {
        reply(response, @errorName(err));
        return;
    };
    reply(response, "ok");
}

pub fn main(init: std.process.Init) !void {
    const root = init.environ_map.get("H1_PROFILE_ROOT") orelse return error.MissingRoot;
    const port = try std.fmt.parseInt(u16, init.environ_map.get("H1_PROFILE_PORT") orelse return error.MissingPort, 10);
    var state: State = .{};
    var contexts: [3]RouteContext = undefined;
    var definitions: [3]uz.BodyRoute = undefined;
    const limits = [_]u64{ 100000000, 32, 0 };
    for (&state.routes, &contexts, &definitions, limits, 0..) |*route, *context, *definition, limit, index| {
        route.slot = .{ .owner = &state, .index = index };
        context.* = .{ .state = &state, .index = index };
        definition.* = .{
            .sink = .{ .context = context, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel },
            .limits = .{ .max_body_bytes = limit, .max_active = 1 },
            .middleware_policy = .headers_only,
        };
    }
    {
        var server = try uz.Server.preset(init.io, .{ .max_connections = 8, .stream_request_bodies = true }).build(init.arena.allocator());
        defer server.deinit();
        _ = try server.use(&state, middleware);
        _ = try server.route_body(.post, "/upload/:tag", &definitions[0]);
        _ = try server.route_body(.post, "/limit/:tag", &definitions[1]);
        _ = try server.route_body(.post, "/empty/:tag", &definitions[2]);
        _ = try server.get("/health", health);
        _ = try server.get_context("/status", &state, status);
        _ = try server.get_context("/resume", &state, control_route);
        _ = try server.get_context("/cancel", &state, control_route);
        _ = try server.get_context("/stale", &state, control_route);
        _ = try server.route_context(.post, "/echo", &state, echo);
        _ = try server.static("/files", root, .{});
        try server.listen("127.0.0.1", port);
        try server.catch_shutdown_signals();
        try server.run();
        try server.shutdown();
    }
    std.log.info("H1_FINAL {f}", .{std.json.fmt(snapshot(&state, state.last_slot), .{})});
    std.log.info("h1 profile shutdown drained", .{});
}
