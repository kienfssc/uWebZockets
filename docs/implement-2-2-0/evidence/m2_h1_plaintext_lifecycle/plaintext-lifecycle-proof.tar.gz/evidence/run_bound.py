"""Retain ordinary client outcomes even when the input audit fails."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path('/workspaces/uWebZockets')
EVIDENCE = ROOT / '.uwz-work/evidence/h1-plaintext/integration-v2'
BUILD = ROOT / '.uwz-work/evidence/h1-plaintext/integration-v2/compile-features-fix1.json'
SOURCE = Path('/tmp/uwz-m2-h1-plaintext-combined')
ARTIFACTS = Path('/tmp/uwz-h1-profile-live-features-fix1')
RECORD = EVIDENCE / 'runtime-features-fix1-binding.json'
LOADER = Path('/nix/store/znb3q6g1ik34454j3vcjx824h1871asg-glibc-2.42-84/lib/ld-linux-x86-64.so.2')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshot():
    build = json.loads(BUILD.read_text())
    manifest = ROOT / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json'
    override = json.loads(manifest.read_text())
    files = {p: sha(p) for p in build['input_sha256']}
    for name in build['fixture_after']:
        files[str(EVIDENCE / name)] = sha(EVIDENCE / name)
    for path in [EVIDENCE / 'probe.py', Path(__file__), BUILD, SOURCE / 'tests/static_interop/probe.py', Path(sys.executable), Path('/tmp/uwz-h1-profile-v2-fix1/profile'), LOADER, LOADER.parent / 'libc.so.6', LOADER.parent / 'libm.so.6']:
        files[str(path)] = sha(path)
    pairs = [(str(p.relative_to(SOURCE)), sha(p)) for p in sorted(SOURCE.rglob('*')) if p.is_file()]
    actual_override = {p: sha(Path(override['path']) / p) for p in override['files_sha256']}
    return {'source_digest': hashlib.sha256(json.dumps(pairs).encode()).hexdigest(), 'source_files': pairs, 'files': files, 'override_manifest_sha256': sha(manifest), 'override_commit': override['commit'], 'override_files': actual_override}


assert len(sys.argv) == 2, 'expected reviewed client SHA256 argument'
assert not RECORD.exists() and not ARTIFACTS.exists()
before = snapshot()
build = json.loads(BUILD.read_text())
assert before['source_digest'] == build['source_tree_sha256']
assert before['files'][str(EVIDENCE / 'probe.py')] == sys.argv[1]
assert all(before['files'][p] == h for p, h in build['input_sha256'].items())
assert all(before['files'][str(EVIDENCE / name)] == h for name, h in build['fixture_after'].items())
assert before['files']['/tmp/uwz-h1-profile-v2-fix1/profile'] == build['binary_sha256']
manifest = json.loads((ROOT / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json').read_text())
assert before['override_files'] == manifest['files_sha256']
argv = [sys.executable, '-B', str(EVIDENCE / 'probe.py'), '--source', str(SOURCE), '--server', '/tmp/uwz-h1-profile-v2-fix1/profile', '--build-record', str(BUILD), '--artifacts', str(ARTIFACTS), '--port', '18886', '--loader', str(LOADER), '--library-path', str(LOADER.parent), '--root-authorized-runtime']
record = {'authorization': 'Root releases the reviewed producer/lifecycle ordinary client against the unchanged reviewed combined server', 'before': before, 'argv': argv, 'cwd': str(ROOT)}
RECORD.write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
try:
    with (EVIDENCE / 'runtime-features-fix1-runner.log').open('wb') as log:
        result = subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    record['exit_status'] = result.returncode
    RECORD.write_text(json.dumps(record, indent=2) + '\n')
except Exception as error:
    record['launch_error'] = repr(error)
finally:
    record['elapsed_seconds'] = time.monotonic() - started
    try:
        record['after'] = snapshot()
        record['inputs_unchanged'] = record['before'] == record['after']
    except Exception as error:
        record['after_audit_error'] = repr(error)
        record['inputs_unchanged'] = False
    for name in ['results.json', 'server.log', 'server.command']:
        source = ARTIFACTS / name
        if source.exists():
            (EVIDENCE / ('runtime-features-fix1-' + name)).write_bytes(source.read_bytes())
    RECORD.write_text(json.dumps(record, indent=2) + '\n')
print('Exit status:', record.get('exit_status'))
print('Inputs unchanged:', record['inputs_unchanged'])
sys.exit(record.get('exit_status', 1) if record['inputs_unchanged'] else 2)
