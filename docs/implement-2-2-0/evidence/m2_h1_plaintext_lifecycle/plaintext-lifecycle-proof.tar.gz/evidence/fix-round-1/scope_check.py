"""AST/source comparison only; never imports the fixture under review."""
import ast
import hashlib
from pathlib import Path


def function(tree, name):
    return next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)


def cases(tree):
    return next(node.value for node in function(tree, 'run_cases').body if isinstance(node, ast.Assign) and isinstance(node.value, ast.List))


def other_nodes(tree):
    return [node for node in tree.body if not (isinstance(node, ast.FunctionDef) and node.name == 'producer_case')]


def main():
    fix = Path(__file__).resolve().parent
    out = fix.parent
    before = ast.parse((fix / 'probe.py.reviewed-preimage').read_text())
    after = ast.parse((out / 'probe.py').read_text())
    approved = ast.parse((out / 'probe.py.corrected-preimage').read_text())
    assert len(other_nodes(before)) == len(other_nodes(after))
    assert all(ast.dump(one) == ast.dump(two) for one, two in zip(other_nodes(before), other_nodes(after)))
    assert len(cases(approved).elts) == 21 and len(cases(after).elts) == 25
    assert all(ast.dump(one) == ast.dump(two) for one, two in zip(cases(approved).elts, cases(after).elts))
    for name in ('profile.zig', 'compile.py'):
        assert (out / name).read_bytes() == (fix / (name + '.reviewed-preimage')).read_bytes()
    ast.parse((out / 'compile.py').read_text())
    print('Python AST syntax: passed; exit status 0')
    print('Only producer_case AST changed; all other module AST unchanged')
    print('Approved21 case entries unchanged;25 request/API +1 owned shutdown =26')
    print('profile.zig and compile.py exactly unchanged')
    print('No runtime/server/client/port contact')
    print('Fixed probe SHA256:', hashlib.sha256((out / 'probe.py').read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
