# Task 3b prepared fixture review

Verdict: Needs fixes before prepared-source approval. No runtime was performed.

## Actionable finding

Important: `probe.py:419-437` does not prove producer activity after binding reuse. The client observes upload end, performs the rebound request, and finally checks only `producer_calls_after_end > 0`. All producer invocations could already have finished before the rebound request if the output was accepted into socket buffering; the subsequent exact wire read would still pass. That execution never tests metadata access after the original slot is overwritten, despite claiming pending-output binding reuse. Record an actual status after the rebound request, require that the producer is still unfinished there, and require later producer call/metadata-check progress beyond that snapshot before accepting the complete output. This uses existing public status and ordinary reads; no timing or socket-buffer manipulation is needed. If the required pending state is not observed, the case must not count as coverage of this scenario.

## Checked scope and evidence

The producer context, scratch and copied expected metadata records are independently owned in State. Retained values are individual request byte slices, not callback request pointers or header/capture array views. The producer reads those slices only during active producer calls. Shutdown's post-deinit snapshot reads independent counts, static reason strings and owned hash bytes, not controls, App storage or retained request slices. Public control operations copy the token before invoking terminal-capable operations.

The three fixed route slots, simultaneous-admission assertions, ordinary peer-close accounting, end-error/no-second-cancel checks, same-route retries, held seven-byte shutdown upload, child ownership/reap checks and post-deinit snapshot checks have no additional actionable finding in this review. The original corrected helper functions were independently AST-compared and remain unchanged. Runtime readiness and listener ownership retain the ordinary owned-process mechanism.

Inspected compile-features-r1.json and empty compiler log: ReleaseSafe compile exited zero, source before/after is `acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b`, with unchanged module/compiler/library inputs and 93 override files. Actual fixture files match recorded before/after hashes; actual binary hash matches `c64d528df32ab227fa14f93e1db3299a8d5af02b7b5a925dea1b5ca0fbd8c865`.

Reviewed fixture hashes:

- profile.zig: `7f05c9a71df55008f22bd96cb5f0d5572430c1e24744efe4aebca27c895c8b8c`
- probe.py: `114c1fcb7a1d520887772993bb3475f43a4188fa4a5cc53018493b67eca5c561`
- compile.py: `744d42996439ef05558663ab638f99002a304f9a2996be1e8ef5bc80aae6fb84`

All 25 request/API cases plus the owned shutdown case remain prepared, not executed. Compilation does not establish metadata lifetime under live backpressure, terminal timing, native platform behavior, allocation instrumentation or full project acceptance. No build, harness execution, fault/cancellation probe, source/ref/pin change or architecture re-review was performed; only this report was written.
