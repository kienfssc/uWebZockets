# Task5b3 source-backed trailers, credit and concurrency plan

Read-only architect_h2_live_plan output adopted by Root for later preparation.
No fixture/client/native execution or implementation is authorized by this plan.
Keep immutable fc69/c223/config/client/helper and two sink slots unchanged.
Use a fresh ordinary H2/TLS connection for each case within the same owned child;
each case's barriers and controls stay on that connection. Six persistent body
records, maximum two active accepted bindings, suffice for this scoped slice.

P(n) means the exact existing payload helper for total n, independently hashed
by the client and compared with the real sink hash.

## queued_trailers_padding

One POST /upload/queued_trailers_padding?case=qtp, length12289, initial headers
x-metadata:initial-qtp and x-initial-only:initial-only, partial-once mode at7.
Send first8192 P12289 bytes withoutEOF, sameconnstatus proves7/paused/1/0/0.
Send remaining4097 with pad_length7, noEOF, then valid trailingHEADERS+EOF:
x-metadata:trailer-qtp and x-trailer-only:discarded. Sameconnstatus still7/noend/
nocancel/no finalHEADERS/end, then publicresume completes200/12289/H12289/1/1/0.
End retains original method/target/path/query/tag/initial headers; trailer-only
absent and trailer value does not replace initial value. Check response middleware
header separately. Logical12289, flow12297 (eight padding-related bytes).
Before resume, connection and stream WU sums each<=15 (7consumed+8padding);
no packet/frame-count assertion. Later refunds<=sentflow, no required closedstream
refund. Source server1596-1634,1291-1296,1651-1679; body_queue112-145.

## receive_credit

One POST /upload/receive_credit, length65536, beginpaused, no padding/trailers/
Expect. Process initialsettings, require advertisedstreaminitial65535 and
connection/currentstreamledger/localmin65535. Connection initial65535 is protocol
constant, not a separately advertised setting.
Send first65535 P65536 bytes in legal<=8192 chunks, respecting peer frame/current
connection/stream credit, noEOF. Sameconn HEADERS-only health/status proveaccepted0/
chunks0/end0,paused,1/0/0 and bothledger/localmin0; no refund of held unpaddedDATA.
Health200/ok and publicresume work at zero requestDATAcredit. Resume drains65535
without end. Read actualWU in bothscopes; do not send untilbothpermit. Status
accepted65535/end0; cumulative settled connection and stream refunds65535 each,
not one-frame assertions. Send helper.payload_block(65536,65535,1)+EOF.
Final200/65536/H65536/1/1/0; logical=flow65536, no premature response/end/reset/
info/duplicateprefix. Never enlarge receive window, send overcredit or manufacture
upload credit with localWU; response acknowledgements concern reverse direction.
Source connection12-13,743-752; server1596-1679,1732-1754.

## concurrent_routes

Ruling: use paused quota-one /limit as the held streamed upload and healthy
/upload as other route. This preserves paused-body/sibling/capture/quota isolation
and uses only two slots; it does not require a third slot to fill uploadquota2.
Four records:
P=/limit/concurrent_hold,length32,beginpaused;
R=/limit/concurrent_refused,length1+Expect,noDATA;
U=/upload/concurrent_upload,length32,ready;
L=/limit/concurrent_recovery,length32,ready.
Send first16 P32 bytes toP withoutEOF; statusactive/paused/accepted0. R gets503/
empty/no100/noA and orderedNOERRORreset. AdmitU beforeDATA, verifytwo active
bindings and distinct records. CompleteU withP32/EOF,200/32/H32 andhealth whileP
stayspaused/0/end0. ResumeP, statusaccepted16/end0, sendremaining16/EOF andexpect
200/32/H32. CompleteL same-route recoveryP32/EOF. P andU have distinct initial
x-metadata; check their own tag/path/query/value atbegin/end, independent of the
common middleware response header. TotalsM4/A3/B3/E3/C0/F0,96logical/flowbytes;
onlyR permits oneNOERRORreset afterfinalEOS. Atmosttwo slots. Source
body_admission49-62,http2_upload194-220,server2086-2092.

## Bounded flow ledger

Public pinned client fields: remote_settings.initial_window_size (streaminitial),
outbound_flow_control_window (currentconnection), local_flow_control_window(id)
(minconnection/stream), max_outbound_frame_size, WindowUpdated.stream_id/delta.
No public separate currentstream window: derive it, do not inspectprivate state
or use reverse-direction remote_flow_control_window. Source pinned
h2/connection.py363-373,1291-1325 and events.py324-345,369-392.

C=65535+receivedWUconnection-sentflowallstreams;
S_i=advertisedinitial+settingsadjustments+receivedWU_i-sentflow_i.
Each outgoingDATA flowlength (payload+padlengthbyte+padding) fits C,S_i andpeer
frame limit beforeencoding. C equals publicconnectionwindow; openstreamlocalmin
equalsmin(C,S_i). With unchangedsettings require0<=C,S_i<=65535 andrefunds<=sentflow.
Stop queryingclosedstreams and don'trequire their finalcredit. HEADERS consume
noDATAcredit. Do not equate applicationaccepted bytes with immediate queuedblock
refunds; no TLS-read/callback/WU-frame/packet-boundary assumptions. Bounds remain
<=8 response records, fixed metadata/event/state retention and absolute deadlines.

All3cases:6records/M6,A5/B5/E5,C0/F0,acceptedlogical77921,flow77929,
normalinactive/deinit/exit0/reaped. Full5b1+5b2+5b3 needs at least33records before
metadata helper cases. A later combined fixture must explicitly resolve that
caller-owned record capacity and log bound; do not silently reset/reuse history
or claim32 suffices. Production profile/two sink slots remain unchanged.
Rest5b/5c/fullmilestones remain required; no code or runtime changed in planning.
