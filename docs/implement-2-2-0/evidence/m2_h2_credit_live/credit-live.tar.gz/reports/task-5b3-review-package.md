# Task5b3 initial source review package
Root base/head50324061f32b7bfcec761d03c590876682c270cf; production and refs unchanged. All following test-only files are new. Frozen v4 is the current subject; earlier versions are preserved evidence, not the reviewed runtime subject.
Manifest: /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/review-manifest-v4.json
SHA256: 67af47d54c4622d9c9ca822f00f1e10f2afbaf1debc7d69a1c5545a919ef8446
Bound current files: 2431; trees: 6. Review closure completeness against frozen imports and actual compile recipes; full manifest is available at the stated path.

## /tmp/uwz-task5b3-frozen-v4/cases.py (107 lines, SHA256 77897c3ccbe4433641f08283f3556e5ff5543d04f0b137a14c42421e38918388)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/cases.py
@@ -0,0 +1,107 @@
+"""Bounded case plans and independent record expectations; import is inert."""
+CASES = ('queued_trailers_padding', 'receive_credit', 'concurrent_routes', 'shutdown_idle')
+TAGS = ('queued_trailers_padding', 'receive_credit', 'concurrent_hold', 'concurrent_refused',
+        'concurrent_upload', 'concurrent_recovery') + tuple('spare_%02d' % i for i in range(26))
+GROUPS = {'queued_trailers_padding': ('queued_trailers_padding',), 'receive_credit': ('receive_credit',),
+          'concurrent_routes': ('concurrent_hold', 'concurrent_refused', 'concurrent_upload', 'concurrent_recovery')}
+LENGTHS = {'queued_trailers_padding': 12289, 'receive_credit': 65536, 'concurrent_hold': 32,
+           'concurrent_upload': 32, 'concurrent_recovery': 32}
+HASHES = {'queued_trailers_padding': 'f84149bf46313d9f7da734e3d53f88b2d01a2c01c38bf422063c507b237915f4',
+          'concurrent_hold': '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5',
+          'concurrent_upload': '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5',
+          'concurrent_recovery': '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5'}
+
+
+def selected_tags(cases):
+    return {tag for case in cases if case != 'shutdown_idle' for tag in GROUPS[case]}
+
+
+def expected(tag, selected, empty_hash, credit_hash):
+    touched = tag in selected
+    accepted = touched and tag != 'concurrent_refused'
+    length = LENGTHS[tag] if accepted else 0
+    digest = (credit_hash if tag == 'receive_credit' else HASHES[tag]) if accepted else empty_hash
+    return {'tag': tag, 'middleware': int(touched), 'attempts': int(accepted), 'begin': int(accepted),
+            'end': int(accepted), 'cancel': 0, 'failure': 0, 'accepted': length, 'sha256': digest,
+            'active': False, 'paused': False, 'reason': 'none', 'metadata_begin': int(accepted),
+            'metadata_end': int(accepted), 'errors': 0}
+
+
+def verify_record(actual, expected_record):
+    for key, value in expected_record.items():
+        if actual.get(key) != value:
+            raise ValueError('record ' + expected_record['tag'] + ' field ' + key + ' differs')
+    if set(actual) != set(expected_record) | {'chunks', 'max_span'}:
+        raise ValueError('record fields differ')
+    chunks, span = actual['chunks'], actual['max_span']
+    if not isinstance(chunks, int) or not isinstance(span, int) or chunks < 0 or not 0 <= span <= 8192:
+        raise ValueError('chunk statistics out of bounds')
+    if expected_record['accepted'] == 0 and (chunks or span):
+        raise ValueError('unexpected empty record chunk')
+    if expected_record['accepted'] and (not chunks or not span):
+        raise ValueError('missing accepted chunk')
+
+
+def barrier(api, tag, stream, accepted, paused, end=0):
+    observed = api['status'](tag)
+    if (observed['accepted'], observed['paused'], observed['begin'], observed['end'], observed['cancel']) != (accepted, paused, 1, end, 0):
+        raise ValueError('body barrier differs: ' + tag)
+    api['pending'](stream)
+    return observed
+
+
+def execute(api, case):
+    if case not in GROUPS:
+        raise ValueError('unsupported case')
+    start, send, finish = api['start'], api['send'], api['finish']
+    if case == 'queued_trailers_padding':
+        tag = case
+        stream = start('upload', tag, 12289, '?case=qtp', [('x-metadata', 'initial-qtp'), ('x-initial-only', 'initial-only')])
+        send(stream, 12289, 0, 8192, False)
+        barrier(api, tag, stream, 7, True)
+        send(stream, 12289, 8192, 4097, False, padding=7)
+        api['trailers'](stream, [('x-metadata', 'trailer-qtp'), ('x-trailer-only', 'discarded')])
+        barrier(api, tag, stream, 7, True)
+        api['refund_bound'](stream, 15)
+        api['resume'](tag)
+        finish(stream)
+    elif case == 'receive_credit':
+        tag = case
+        stream = start('upload', tag, 65536, '', [])
+        api['initial_credit'](stream)
+        for offset in range(0, 65535, 8192):
+            send(stream, 65536, offset, min(8192, 65535 - offset), False)
+        api['health']()
+        observed = barrier(api, tag, stream, 0, True)
+        if observed['chunks'] != 0:
+            raise ValueError('paused credit stream invoked chunk')
+        api['zero_credit'](stream)
+        api['resume'](tag)
+        barrier(api, tag, stream, 65535, False)
+        api['settled_credit'](stream, 65535)
+        send(stream, 65536, 65535, 1, True)
+        finish(stream)
+    elif case == 'concurrent_routes':
+        hold = start('limit', 'concurrent_hold', 32, '?case=hold', [('x-metadata', 'hold-metadata')])
+        send(hold, 32, 0, 16, False)
+        barrier(api, 'concurrent_hold', hold, 0, True)
+        refused = start('limit', 'concurrent_refused', 1, '', [('expect', '100-continue')], status=503, reset=True)
+        finish(refused, keep=True)
+        upload = start('upload', 'concurrent_upload', 32, '?case=upload', [('x-metadata', 'upload-metadata')])
+        api['active'](2)
+        send(upload, 32, 0, 32, True)
+        finish(upload)
+        api['health']()
+        barrier(api, 'concurrent_hold', hold, 0, True)
+        api['resume']('concurrent_hold')
+        barrier(api, 'concurrent_hold', hold, 16, False)
+        send(hold, 32, 16, 16, True)
+        finish(hold)
+        recovery = start('limit', 'concurrent_recovery', 32, '', [])
+        send(recovery, 32, 0, 32, True)
+        finish(recovery)
+        api['health']()
+        api['retire'](refused)
+    else:
+        raise ValueError('unsupported case')
+    api['health']()

## /tmp/uwz-task5b3-frozen-v4/coverage_inventory.json (16 lines, SHA256 2aa26a773da59316afd604c7b996deb5fa0528de3dd7af6a4c0ff87bd8ebd03f)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/coverage_inventory.json
@@ -0,0 +1,16 @@
+{
+  "prior_22_proved": [
+    "ready_buffered", "async_delayed", "large_declared", "large_undeclared", "shutdown_idle",
+    "partial_pause", "final_pause", "begin_pause_empty", "control_rules",
+    "empty_headers", "empty_data", "empty_declared", "limit_declared", "limit_undeclared",
+    "limit_declared_reject", "limit_observed_reject", "zero_declared_reject", "zero_observed_reject",
+    "continue_ready", "continue_paused", "quota_refuse", "begin_failure_rollback"
+  ],
+  "remaining_15_plan_rows": [
+    ["queued_trailers_padding"], ["receive_credit"], ["concurrent_routes"], ["metadata_helpers"],
+    ["producer_reuse"], ["output_pressure_window", "output_pressure_ready"], ["stream_file"],
+    ["early_final_order"], ["cancel_ready", "cancel_paused"], ["peer_reset"],
+    ["sink_error", "invalid_progress"], ["end_error"], ["disconnect"], ["reuse"], ["shutdown_active"]
+  ],
+  "qualification": "Counts follow the original matrix rows: three rows have two required variants. None of the remaining rows is proved by Stage A."
+}

## /tmp/uwz-task5b3-frozen-v4/fixture-contract.md (7 lines, SHA256 b2a91e868d9922f05828128cc28ac5658167b414bd8c19b2eec1134e315d9fae)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/fixture-contract.md
@@ -0,0 +1,7 @@
+# Credit fixture contract, compile-only
+
+The fixture retains the prior eight-connection `Server.preset(...).build_https` profile and registers real `/upload/:tag` (100000000 bytes, quota 2) and `/limit/:tag` (32 bytes, quota 1) routes with headers-only middleware. It retains two reusable sink slots and 32 persistent records. Six tags are named in `profile.zig`; indices 6 through 31 are explicit rejected spares. Records, expected metadata constants and tokens are independent of reusable slots; no callback-borrowed request or body slice is retained. The constants specify method, target, path, query, tag and initial metadata for both begin and end. End also checks the absence of trailer-only metadata. Each successful comparison increments a separately reported counter; mismatches increment errors and fail the callback.
+
+`queued_trailers_padding` hashes and accepts up to a cumulative seven bytes across arbitrary callback spans before pausing once. `receive_credit` and `concurrent_hold` begin paused. Resuming copies the public control token and uses only persistent record storage and the control request's own response after calling resume. The other accepted records consume and hash exactly the provided bytes. No fixture callback applies route quotas or body limits, stores full bodies, or manufactures credit. Refused streams must never call begin.
+
+Actual middleware appends `X-Middleware: retained` and counts body heads. Public `/health`, `/status/:tag`, `/metrics`, and `/resume/:tag` routes and post-deinit record/metric logs preserve the prior process contract. There are 32 result snapshots and at most two active sink bindings. The all-case expected body totals are M6/A5/B5/E5/C0/F0 and 77921 accepted bytes; the driver must independently verify every record and untouched spare. Compilation establishes type checking only. Metadata behavior, response headers, credit, socket lifecycle and these totals require the separately authorized future run.

## /tmp/uwz-task5b3-frozen-v4/flow_ledger.py (81 lines, SHA256 f71787b310255802111876b66eb31ee1a5d341001ea5289e8745dd224465feff)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/flow_ledger.py
@@ -0,0 +1,81 @@
+"""Caller-owned HTTP/2 outbound credit accounting; no transport effects."""
+from dataclasses import dataclass, field
+
+INITIAL = 65535
+MAX_STREAMS = 8
+
+
+@dataclass
+class StreamCredit:
+    window: int
+    sent: int = 0
+    refunded: int = 0
+    open: bool = True
+
+
+@dataclass
+class FlowLedger:
+    connection: int = INITIAL
+    initial_stream: int = INITIAL
+    sent: int = 0
+    refunded: int = 0
+    streams: dict[int, StreamCredit] = field(default_factory=dict)
+    unchanged_settings: bool = True
+
+
+def open_stream(ledger: FlowLedger, stream_id: int) -> None:
+    if stream_id in ledger.streams or len(ledger.streams) >= MAX_STREAMS:
+        raise ValueError('duplicate stream or stream capacity exceeded')
+    ledger.streams[stream_id] = StreamCredit(ledger.initial_stream)
+
+
+def send_data(ledger: FlowLedger, stream_id: int, payload: int, padding: int | None, max_frame: int, finished: bool = False) -> int:
+    stream = ledger.streams[stream_id]
+    if not stream.open or payload < 0 or padding is not None and not 0 <= padding <= 255:
+        raise ValueError('invalid DATA request')
+    flow = payload + (padding + 1 if padding is not None else 0)
+    if flow > min(ledger.connection, stream.window, max_frame):
+        raise ValueError('DATA exceeds public credit or frame limit')
+    ledger.connection -= flow
+    ledger.sent += flow
+    stream.window -= flow
+    stream.sent += flow
+    stream.open = not finished
+    return flow
+
+
+def receive_batch(ledger: FlowLedger, updates: list[tuple[int, int]], new_initial: int | None = None) -> None:
+    if new_initial is not None:
+        if not 0 <= new_initial <= 2147483647:
+            raise ValueError('invalid initial window')
+        change = new_initial - ledger.initial_stream
+        ledger.initial_stream = new_initial
+        ledger.unchanged_settings = ledger.unchanged_settings and change == 0
+        for stream in ledger.streams.values():
+            if stream.open:
+                stream.window += change
+    for stream_id, delta in updates:
+        if delta <= 0:
+            raise ValueError('invalid window update')
+        if stream_id == 0:
+            ledger.connection += delta
+            ledger.refunded += delta
+        else:
+            stream = ledger.streams[stream_id]
+            stream.window += delta
+            stream.refunded += delta
+    if ledger.unchanged_settings:
+        if not 0 <= ledger.connection <= INITIAL or ledger.refunded > ledger.sent:
+            raise ValueError('invalid connection refund')
+        for stream in ledger.streams.values():
+            if stream.refunded > stream.sent or stream.open and not 0 <= stream.window <= INITIAL:
+                raise ValueError('invalid stream refund')
+
+
+def check_public(ledger: FlowLedger, connection_window: int, stream_windows: dict[int, int]) -> None:
+    if connection_window != ledger.connection:
+        raise ValueError('connection window differs')
+    for stream_id, public_window in stream_windows.items():
+        stream = ledger.streams[stream_id]
+        if not stream.open or public_window != min(ledger.connection, stream.window):
+            raise ValueError('stream minimum differs or stream closed')

## /tmp/uwz-task5b3-frozen-v4/prepare.py (79 lines, SHA256 3d944c3f70e123386177b070230df2b09a16f10184b9ded272de95a5bb25829e)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/prepare.py
@@ -0,0 +1,79 @@
+"""Explicit compile-only replay. Never starts a server or client."""
+import argparse
+import hashlib
+import json
+import subprocess
+from pathlib import Path
+
+ROOT = Path('/workspaces/uWebZockets')
+HERE = Path(__file__).resolve().parent
+ZIG = '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig'
+
+
+def digest(path):
+    result = hashlib.sha256()
+    with Path(path).open('rb') as source:
+        while data := source.read(8192):
+            result.update(data)
+    return result.hexdigest()
+
+
+def main():
+    parser = argparse.ArgumentParser()
+    parser.add_argument('--source', type=Path, default=Path('/tmp/uwz-task4d-fix1-frozen'))
+    parser.add_argument('--output', type=Path, default=Path('/tmp/uwz-task5a-compile'))
+    parser.add_argument('--record', default='compile')
+    parser.add_argument('--optimization', choices=['Debug', 'ReleaseSafe'], required=True)
+    parser.add_argument('--cache-root', type=Path)
+    parser.add_argument('--expected-source-digest', default='fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de')
+    args = parser.parse_args()
+    if args.output.exists() and any(args.output.iterdir()):
+        raise RuntimeError('select a fresh output/cache directory')
+    args.output.mkdir(parents=True, exist_ok=True)
+    if (HERE / (args.record + '.json')).exists():
+        raise RuntimeError('compile record already exists; select a fresh record label')
+    cache_root = args.output if args.cache_root is None else args.cache_root
+    if args.cache_root is not None and not ((cache_root / 'cache').is_dir() and (cache_root / 'global').is_dir()):
+        raise RuntimeError('explicit cache reuse requires this task existing compiler cache directories')
+    argv = [ZIG, 'build-exe', '-O' + args.optimization, '--dep', 'uWebZockets', '-Mroot=' + str(HERE / 'profile.zig'), '-O' + args.optimization, '--dep', 'c', '--dep', 'xev', '--dep', 'zslay', '-MuWebZockets=' + str(args.source / 'src/root.zig'), '-Mc=' + str(ROOT / '.uwz-work/evidence/h1-transport/r2/c-native.zig'), '--dep', 'xev_impl', '-Mxev=' + str(args.source / 'src/core/xev.zig'), '-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig']
+    seed = json.loads((ROOT / '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json').read_text())['argv']
+    zslay = next(value.split('=', 1)[1] for value in seed if value.startswith('-Mzslay='))
+    argv += ['-Mzslay=' + str(ROOT / zslay), '-lc++', '-lc']
+    argv += [str(ROOT / 'zig-out/lib' / name) for name in ('libuWebZockets.a', 'libssl.a', 'libcrypto.a', 'liblsquic.a', 'libdeflate.a', 'libz.a')]
+    argv += ['-j2', '--cache-dir', str(cache_root / 'cache'), '--global-cache-dir', str(cache_root / 'global'), '-femit-bin=' + str(args.output / 'profile')]
+    inputs = [Path(value.split('=', 1)[1]) for value in argv if value.startswith('-M')]
+    inputs += [Path(value) for value in argv if value.endswith('.a')]
+    inputs += [Path(ZIG)]
+    source_inputs = {str(path.relative_to(args.source)): digest(path) for path in sorted(args.source.rglob('*')) if path.is_file()}
+    (HERE / (args.record + '-source-inputs.json')).write_text(json.dumps(source_inputs, indent=2) + '\n')
+    source_digest = hashlib.sha256(json.dumps(list(source_inputs.items())).encode()).hexdigest()
+    if source_digest != args.expected_source_digest:
+        raise RuntimeError('combined source digest differs from Root supplied coherent source')
+    override_manifest = ROOT / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json'
+    override = json.loads(override_manifest.read_text())
+    override_inputs = {name: digest(Path(override['path']) / name) for name in override['files_sha256']}
+    if override_inputs != override['files_sha256']:
+        raise RuntimeError('c223 override differs from immutable input manifest')
+    fixture_inputs = {path.name: digest(path) for path in (HERE / 'profile.zig', HERE / 'prepare.py')}
+    record = {'qualification': 'H2 fixture compile only; no runtime claim', 'expected_source_digest': args.expected_source_digest, 'fixture_before': fixture_inputs, 'override_manifest_sha256': digest(override_manifest), 'override_before': override_inputs, 'source_tree_sha256': hashlib.sha256(json.dumps(list(source_inputs.items())).encode()).hexdigest(), 'source_tree_encoding': 'sha256(json.dumps(relative_path, file_sha256 pairs in sorted pathlib path order))', 'argv': argv, 'cwd': str(args.source), 'optimization': args.optimization, 'explicit_environment': {}, 'input_sha256': {str(path): digest(path) for path in inputs}, 'execution': 'compile only; no server/client execution'}
+    (HERE / (args.record + '.command.json')).write_text(json.dumps(record, indent=2) + '\n')
+    with (HERE / (args.record + '.log')).open('wb') as log:
+        result = subprocess.run(argv, cwd=args.source, stdout=log, stderr=subprocess.STDOUT)
+    record['exit_status'] = result.returncode
+    record['input_after'] = {str(path): digest(path) for path in inputs}
+    record['fixture_after'] = {name: digest(HERE / name) for name in fixture_inputs}
+    source_after = {str(path.relative_to(args.source)): digest(path) for path in sorted(args.source.rglob('*')) if path.is_file()}
+    (HERE / (args.record + '-source-after.json')).write_text(json.dumps(source_after, indent=2) + '\n')
+    record['source_after_sha256'] = hashlib.sha256(json.dumps(list(source_after.items())).encode()).hexdigest()
+    record['override_after'] = {name: digest(Path(override['path']) / name) for name in override_inputs}
+    record['inputs_unchanged'] = record['input_after'] == record['input_sha256'] and record['fixture_after'] == fixture_inputs and source_after == source_inputs and record['override_after'] == override_inputs
+    if result.returncode == 0:
+        record['binary_sha256'] = digest(args.output / 'profile')
+    (HERE / (args.record + '.json')).write_text(json.dumps(record, indent=2) + '\n')
+    print((HERE / (args.record + '.log')).read_text(), end='')
+    print('Exit status:', result.returncode)
+    raise SystemExit(result.returncode if record['inputs_unchanged'] else 1)
+
+
+if __name__ == '__main__':
+    main()

## /tmp/uwz-task5b3-frozen-v4/profile.zig (361 lines, SHA256 a370cb6c5a846ff0f628ebb7e76871f933cd5751249cfcb2d3a3898ebf3ef745)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/profile.zig
@@ -0,0 +1,361 @@
+const std = @import("std");
+const uz = @import("uWebZockets");
+const Hash = std.crypto.hash.sha2.Sha256;
+const config: uz.ServerConfig = .{
+    .max_connections = 8,
+    .stream_request_bodies = true,
+    .max_request_line_size = 512,
+    .max_header_size = 4096,
+    .max_header_count = 80,
+    .max_body_size = 256,
+    .max_h2_body_size = 4096,
+    .max_h2_header_block_size = 8192,
+    .max_h2_response_header_size = 4096,
+    .max_h2_response_header_count = 32,
+    .max_route_params = 24,
+    .write_queue_size = 65536,
+    .enable_dev_log = false,
+};
+const tags = [_][]const u8{
+    "queued_trailers_padding",
+    "receive_credit",
+    "concurrent_hold",
+    "concurrent_refused",
+    "concurrent_upload",
+    "concurrent_recovery",
+    "spare_00",
+    "spare_01",
+    "spare_02",
+    "spare_03",
+    "spare_04",
+    "spare_05",
+    "spare_06",
+    "spare_07",
+    "spare_08",
+    "spare_09",
+    "spare_10",
+    "spare_11",
+    "spare_12",
+    "spare_13",
+    "spare_14",
+    "spare_15",
+    "spare_16",
+    "spare_17",
+    "spare_18",
+    "spare_19",
+    "spare_20",
+    "spare_21",
+    "spare_22",
+    "spare_23",
+    "spare_24",
+    "spare_25",
+};
+const Record = struct {
+    token: ?uz.BodyControl = null,
+    hash: Hash = Hash.init(.{}),
+    bytes: u64 = 0,
+    chunks: u32 = 0,
+    max_span: usize = 0,
+    middleware: u32 = 0,
+    attempts: u32 = 0,
+    begins: u32 = 0,
+    ends: u32 = 0,
+    cancels: u32 = 0,
+    failures: u32 = 0,
+    errors: u32 = 0,
+    active: bool = false,
+    paused: bool = false,
+    reason: ?uz.BodyCancelReason = null,
+    metadata_begin: u32 = 0,
+    metadata_end: u32 = 0,
+    partial_done: bool = false,
+};
+const Slot = struct { record: ?*Record = null, owner: *State = undefined, index: usize = 0 };
+const State = struct {
+    slots: [2]Slot = [_]Slot{.{}} ** 2,
+    records: [32]Record = [_]Record{.{}} ** 32,
+    buffered_middleware: u32 = 0,
+    errors: u32 = 0,
+};
+fn tag_index(tag: []const u8) ?usize {
+    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
+    return null;
+}
+fn account_body_head(state: *State, request: *const uz.Request) void {
+    const tag = request.get_param("tag") orelse {
+        state.errors += 1;
+        return;
+    };
+    const index = tag_index(tag) orelse {
+        state.errors += 1;
+        return;
+    };
+    if (index >= 6) {
+        state.errors += 1;
+        return;
+    }
+    state.records[index].middleware += 1;
+}
+fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
+    const state: *State = @ptrCast(@alignCast(context));
+    if (std.mem.startsWith(u8, request.path, "/upload/") or std.mem.startsWith(u8, request.path, "/limit/") or std.mem.startsWith(u8, request.path, "/empty/")) {
+        account_body_head(state, request);
+    } else state.buffered_middleware += 1;
+    response.append_header("X-Middleware", "retained") catch {
+        state.errors += 1;
+        return .stop;
+    };
+    return .continue_dispatch;
+}
+const ExpectedMetadata = struct {
+    target: []const u8,
+    path: []const u8,
+    query: []const u8,
+    metadata: ?[]const u8,
+    initial_only: ?[]const u8 = null,
+};
+const expected_metadata = [_]ExpectedMetadata{
+    .{ .target = "/upload/queued_trailers_padding?case=qtp", .path = "/upload/queued_trailers_padding", .query = "case=qtp", .metadata = "initial-qtp", .initial_only = "initial-only" },
+    .{ .target = "/upload/receive_credit", .path = "/upload/receive_credit", .query = "", .metadata = null },
+    .{ .target = "/limit/concurrent_hold?case=hold", .path = "/limit/concurrent_hold", .query = "case=hold", .metadata = "hold-metadata" },
+    .{ .target = "/limit/concurrent_refused", .path = "/limit/concurrent_refused", .query = "", .metadata = null },
+    .{ .target = "/upload/concurrent_upload?case=upload", .path = "/upload/concurrent_upload", .query = "case=upload", .metadata = "upload-metadata" },
+    .{ .target = "/limit/concurrent_recovery", .path = "/limit/concurrent_recovery", .query = "", .metadata = null },
+};
+fn optional_equal(actual: ?[]const u8, expected: ?[]const u8) bool {
+    if (actual) |a| {
+        const e = expected orelse return false;
+        return std.mem.eql(u8, a, e);
+    }
+    return expected == null;
+}
+fn metadata_matches(index: usize, request: *const uz.StreamingRequest) bool {
+    const expected = expected_metadata[index];
+    return std.mem.eql(u8, request.method, "POST") and
+        std.mem.eql(u8, request.target, expected.target) and
+        std.mem.eql(u8, request.path, expected.path) and
+        std.mem.eql(u8, request.query, expected.query) and
+        optional_equal(request.params.get("tag"), tags[index]) and
+        optional_equal(request.headers.get("x-metadata"), expected.metadata) and
+        optional_equal(request.headers.get("x-initial-only"), expected.initial_only) and
+        request.headers.get("x-trailer-only") == null;
+}
+fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
+    const state: *State = @ptrCast(@alignCast(context));
+    const tag = request.params.get("tag") orelse {
+        state.errors += 1;
+        return error.MissingTag;
+    };
+    const index = tag_index(tag) orelse {
+        state.errors += 1;
+        return error.InvalidTag;
+    };
+    if (index >= 6) {
+        state.errors += 1;
+        return error.SpareTag;
+    }
+    const record = &state.records[index];
+    record.attempts += 1;
+    if (!metadata_matches(index, request)) {
+        record.errors += 1;
+        record.failures += 1;
+        return error.MetadataMismatch;
+    }
+    record.metadata_begin += 1;
+    if (record.attempts != 1 or record.middleware != 1) {
+        record.errors += 1;
+        record.failures += 1;
+        return error.DuplicateTag;
+    }
+    for (&state.slots) |*slot| {
+        if (slot.record != null) continue;
+        slot.* = .{ .owner = state, .record = record, .index = index };
+        record.token = token;
+        record.begins += 1;
+        record.active = true;
+        record.paused = index == 1 or index == 2;
+        return .{ .context = slot, .readiness = if (record.paused) .paused else .ready };
+    }
+    record.failures += 1;
+    record.errors += 1;
+    return error.NoFixtureSlot;
+}
+fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
+    const slot: *Slot = @ptrCast(@alignCast(context));
+    const record = slot.record orelse return error.MissingRecord;
+    record.max_span = @max(record.max_span, input.len);
+    record.chunks += 1;
+    var consumed = input.len;
+    if (slot.index == 0 and !record.partial_done) {
+        consumed = @min(input.len, 7 - @as(usize, @intCast(record.bytes)));
+        if (record.bytes + consumed == 7) {
+            record.partial_done = true;
+            record.paused = true;
+        }
+    }
+    record.hash.update(input[0..consumed]);
+    record.bytes += consumed;
+    return .{ .consumed = consumed, .readiness = if (record.paused) .paused else .ready };
+}
+fn format_record(record: *const Record, tag: []const u8, output: []u8) ![]const u8 {
+    var copy = record.hash;
+    var digest: [Hash.digest_length]u8 = undefined;
+    copy.final(&digest);
+    const hex = std.fmt.bytesToHex(digest, .lower);
+    const reason = if (record.reason) |value| @tagName(value) else "none";
+    return std.fmt.bufPrint(output, "{{\"tag\":\"{s}\",\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"accepted\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":\"{s}\",\"metadata_begin\":{d},\"metadata_end\":{d},\"errors\":{d}}}", .{ tag, record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.metadata_begin, record.metadata_end, record.errors });
+}
+fn end(context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response) !void {
+    const slot: *Slot = @ptrCast(@alignCast(context));
+    const record = slot.record orelse return error.MissingRecord;
+    if (!metadata_matches(slot.index, request)) {
+        record.errors += 1;
+        return error.MetadataMismatch;
+    }
+    record.metadata_end += 1;
+    record.ends += 1;
+    record.active = false;
+    record.paused = false;
+    record.token = null;
+    slot.record = null;
+    var output: [1024]u8 = undefined;
+    try response.text(try format_record(record, tags[slot.index], &output));
+}
+fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
+    const slot: *Slot = @ptrCast(@alignCast(context));
+    const record = slot.record orelse {
+        slot.owner.errors += 1;
+        return;
+    };
+    record.cancels += 1;
+    record.reason = reason;
+    record.active = false;
+    record.paused = false;
+    record.token = null;
+    slot.record = null;
+}
+fn health(_: *uz.Request, response: *uz.Response) void {
+    response.text("ok") catch |err| std.log.err("health: {}", .{err});
+}
+fn status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
+    const state: *State = @ptrCast(@alignCast(context));
+    const tag = request.get_param("tag") orelse {
+        state.errors += 1;
+        return;
+    };
+    const index = tag_index(tag) orelse {
+        state.errors += 1;
+        return;
+    };
+    var output: [1024]u8 = undefined;
+    const body = format_record(&state.records[index], tags[index], &output) catch {
+        state.errors += 1;
+        return;
+    };
+    response.text(body) catch {
+        state.errors += 1;
+    };
+}
+const Totals = struct {
+    middleware: u64 = 0,
+    attempts: u64 = 0,
+    begins: u64 = 0,
+    ends: u64 = 0,
+    cancels: u64 = 0,
+    failures: u64 = 0,
+    accepted: u64 = 0,
+    active: u32 = 0,
+    errors: u64 = 0,
+};
+fn totals(state: *const State) Totals {
+    var result: Totals = .{ .errors = state.errors };
+    for (state.records) |record| {
+        result.middleware += record.middleware;
+        result.attempts += record.attempts;
+        result.begins += record.begins;
+        result.ends += record.ends;
+        result.cancels += record.cancels;
+        result.failures += record.failures;
+        result.accepted += record.bytes;
+        result.errors += record.errors;
+        result.active += @intFromBool(record.active);
+    }
+    return result;
+}
+fn format_totals(state: *const State, output: []u8) ![]const u8 {
+    const t = totals(state);
+    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"accepted\":{d},\"active\":{d},\"errors\":{d},\"buffered_middleware\":{d},\"slot0_active\":{any},\"slot1_active\":{any}}}", .{ t.middleware, t.attempts, t.begins, t.ends, t.cancels, t.failures, t.accepted, t.active, t.errors, state.buffered_middleware, state.slots[0].record != null, state.slots[1].record != null });
+}
+fn metrics(context: *anyopaque, _: *uz.Request, response: *uz.Response) void {
+    const state: *State = @ptrCast(@alignCast(context));
+    var output: [1024]u8 = undefined;
+    const body = format_totals(state, &output) catch {
+        state.errors += 1;
+        return;
+    };
+    response.text(body) catch {
+        state.errors += 1;
+    };
+}
+fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
+    const state: *State = @ptrCast(@alignCast(context));
+    const tag = request.get_param("tag") orelse {
+        state.errors += 1;
+        return;
+    };
+    const index = tag_index(tag) orelse {
+        state.errors += 1;
+        return;
+    };
+    const token = state.records[index].token orelse {
+        state.errors += 1;
+        return;
+    };
+    if (!state.records[index].paused) {
+        state.errors += 1;
+        return;
+    }
+    state.records[index].paused = false;
+    token.@"resume"() catch {
+        state.errors += 1;
+        response.text("error") catch {
+            state.errors += 1;
+        };
+        return;
+    };
+    response.text("ok") catch {
+        state.errors += 1;
+    };
+}
+pub fn main(init: std.process.Init) !void {
+    const certificate = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_CERT") orelse return error.MissingCertificate);
+    const key = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_KEY") orelse return error.MissingKey);
+    const nonce = init.environ_map.get("H2_PROFILE_NONCE") orelse return error.MissingNonce;
+    if (nonce.len == 0 or nonce.len > 64) return error.InvalidNonce;
+    var state: State = .{};
+    const sink: uz.BodySink = .{ .context = &state, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel };
+    var upload: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 100000000, .max_active = 2 }, .middleware_policy = .headers_only };
+    var limit: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 32, .max_active = 1 }, .middleware_policy = .headers_only };
+    {
+        var server = try uz.Server.preset(init.io, config).build_https(init.arena.allocator(), certificate, key);
+        defer server.deinit();
+        _ = try server.use(&state, middleware);
+        _ = try server.route_body(.post, "/upload/:tag", &upload);
+        _ = try server.route_body(.post, "/limit/:tag", &limit);
+        _ = try server.get("/health", health);
+        _ = try server.get_context("/status/:tag", &state, status);
+        _ = try server.get_context("/metrics", &state, metrics);
+        _ = try server.get_context("/resume/:tag", &state, control);
+        std.log.info("H2_CAPACITY config={f} request_stride={d} h2_bytes={d} h2_stride={d} slab={d} router={d}", .{ std.json.fmt(config, .{}), try config.request_buffer_stride(), try config.h2_session_bytes(), try config.h2_session_stride(), try config.slab_bytes(), try config.router_storage_bytes() });
+        try server.listen("127.0.0.1", 28443);
+        try server.catch_shutdown_signals();
+        std.log.info("H2_READY {s}", .{nonce});
+        try server.run();
+    }
+    for (&state.records, 0..) |*record, i| {
+        var output: [1024]u8 = undefined;
+        std.log.info("H2_RECORD {s} {s}", .{ nonce, try format_record(record, tags[i], &output) });
+    }
+    var output: [1024]u8 = undefined;
+    std.log.info("H2_DEINIT {s} {s}", .{ nonce, try format_totals(&state, &output) });
+}

## /tmp/uwz-task5b3-frozen-v4/pure_cases_checks.py (34 lines, SHA256 f3df2bf936bd4e234bd6ee1f534f9249988531da48ca0ff0ff9a21c3069d409c)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/pure_cases_checks.py
@@ -0,0 +1,34 @@
+"""Independent bounded payload and selection expectations, without network I/O."""
+import hashlib
+import h2_client
+import cases
+
+
+def digest(length):
+    state = hashlib.sha256()
+    for offset in range(0, length, 8192):
+        state.update(h2_client.payload_block(length, offset, min(8192, length - offset)))
+    return state.hexdigest()
+
+
+def main():
+    empty = hashlib.sha256(b'').hexdigest()
+    credit = digest(65536)
+    assert digest(12289) == cases.HASHES['queued_trailers_padding']
+    assert digest(32) == cases.HASHES['concurrent_hold']
+    selected = cases.selected_tags(cases.CASES)
+    records = [cases.expected(tag, selected, empty, credit) for tag in cases.TAGS]
+    assert len(records) == 32 and len(selected) == 6
+    for field, target in (('middleware', 6), ('attempts', 5), ('begin', 5), ('end', 5),
+                          ('cancel', 0), ('failure', 0), ('accepted', 77921), ('errors', 0)):
+        assert sum(record[field] for record in records) == target
+    assert all(r['accepted'] == 0 and r['sha256'] == empty for r in records[6:])
+    for case, tags in cases.GROUPS.items():
+        assert cases.selected_tags((case,)) == set(tags)
+    print('32 records, six selected: M6/A5/B5/E5/C0/F0, accepted 77921')
+    print('P12289 and P32 match pinned expected SHA-256; H65536:', credit)
+    print('all single-case selections preserve untouched spares')
+
+
+if __name__ == '__main__':
+    main()

## /tmp/uwz-task5b3-frozen-v4/pure_codec_checks.py (55 lines, SHA256 b8f9a92635c07505dbba48c7c3d926876081157712c4497ab4795b22e75b03c0)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/pure_codec_checks.py
@@ -0,0 +1,55 @@
+"""Exercise response decoding with pinned h2, without sockets."""
+import h2.config
+import h2.connection
+import raw_observer
+import wire
+
+
+def pair():
+    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
+    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
+    client.initiate_connection()
+    server.initiate_connection()
+    server.receive_data(client.data_to_send())
+    client.receive_data(server.data_to_send())
+    client.send_headers(1, [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/')])
+    server.receive_data(client.data_to_send())
+    return client, server
+
+
+def scenario(status, informational, expected_status, expected_info, middleware=True):
+    client, server = pair()
+    records, trace, raw = {}, {}, raw_observer.new_state()
+    wire.register(records, raw, 1, 0, expected_status, expected_info, False)
+    if informational:
+        server.send_headers(1, [(':status', informational)])
+    headers = [(':status', status)]
+    if middleware:
+        headers.append(('x-middleware', 'retained'))
+    server.send_headers(1, headers, end_stream=True)
+    data = server.data_to_send()
+    for offset in range(0, len(data), 3):
+        wire.accept(client, data[offset:offset + 3], records, raw, trace)
+    wire.complete(records, raw, 1)
+
+
+def rejected(name, **kwargs):
+    try:
+        scenario(**kwargs)
+    except ValueError as error:
+        print(name + ': rejected: ' + str(error))
+        return
+    raise AssertionError(name + ': unexpectedly accepted')
+
+
+def main():
+    scenario('200', '100', '200', 1)
+    print('split informational and final: accepted')
+    rejected('wrong final', status='413', informational=None, expected_status='200', expected_info=0)
+    rejected('unexpected informational', status='200', informational='100', expected_status='200', expected_info=0)
+    rejected('missing informational', status='200', informational=None, expected_status='200', expected_info=1)
+    rejected('missing middleware', status='200', informational=None, expected_status='200', expected_info=0, middleware=False)
+
+
+if __name__ == '__main__':
+    main()

## /tmp/uwz-task5b3-frozen-v4/pure_flow_checks.py (72 lines, SHA256 1c14f2eb16bd070f2bda0bf4ec263dc251d11d6bd5740d013a535cc44d1abe01)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/pure_flow_checks.py
@@ -0,0 +1,72 @@
+"""Pinned codec and pure ledger checks; no sockets or native executable."""
+import h2.config
+import h2.connection
+import h2.events
+import h2.settings
+import flow_ledger as flow
+
+
+def pair():
+    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True))
+    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False))
+    client.initiate_connection()
+    server.initiate_connection()
+    server.receive_data(client.data_to_send())
+    client.receive_data(server.data_to_send())
+    client.send_headers(1, [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/')])
+    server.receive_data(client.data_to_send())
+    return client, server
+
+
+def main():
+    client, server = pair()
+    ledger = flow.FlowLedger()
+    flow.open_stream(ledger, 1)
+    flow.check_public(ledger, client.outbound_flow_control_window, {1: client.local_flow_control_window(1)})
+    for amount in (8192, 8192, 8192, 8192, 8192, 8192, 8192, 8191):
+        flow.send_data(ledger, 1, amount, None, client.max_outbound_frame_size)
+        client.send_data(1, b'x' * amount)
+        server.receive_data(client.data_to_send())
+    flow.check_public(ledger, client.outbound_flow_control_window, {1: client.local_flow_control_window(1)})
+    assert ledger.connection == ledger.streams[1].window == 0
+    try:
+        flow.send_data(ledger, 1, 1, None, client.max_outbound_frame_size)
+    except ValueError:
+        print('zero-credit DATA: rejected')
+    else:
+        raise AssertionError('zero-credit DATA accepted')
+    for delta in (30000, 35535):
+        server.increment_flow_control_window(delta)
+        server.increment_flow_control_window(delta, stream_id=1)
+    events = client.receive_data(server.data_to_send())
+    updates = [(e.stream_id, e.delta) for e in events if isinstance(e, h2.events.WindowUpdated)]
+    assert len(updates) == 4
+    flow.receive_batch(ledger, updates)
+    flow.check_public(ledger, client.outbound_flow_control_window, {1: client.local_flow_control_window(1)})
+    assert ledger.refunded == ledger.streams[1].refunded == 65535
+    print('coalesced four peer WINDOW_UPDATE events: final public connection and minimum match; refunds 65535 each')
+    flow.send_data(ledger, 1, 1, None, client.max_outbound_frame_size, finished=True)
+    client.send_data(1, b'x', end_stream=True)
+    assert ledger.sent == 65536
+    distinct = flow.FlowLedger()
+    flow.open_stream(distinct, 1)
+    flow.open_stream(distinct, 3)
+    flow.send_data(distinct, 1, 20, None, 8192)
+    flow.receive_batch(distinct, [(0, 20)])
+    flow.check_public(distinct, 65535, {1: 65515, 3: 65535})
+    print('public stream window is min(connection, derived stream), not standalone connection')
+    padded = flow.FlowLedger()
+    flow.open_stream(padded, 1)
+    assert flow.send_data(padded, 1, 4097, 7, 8192) == 4105
+    assert padded.sent == 4105
+    print('padding consumes 4097 + 1 + 7 = 4105 flow bytes')
+    try:
+        flow.check_public(padded, padded.connection, {1: padded.streams[1].window + 1})
+    except ValueError:
+        print('incorrect public minimum: rejected')
+    else:
+        raise AssertionError('incorrect minimum accepted')
+
+
+if __name__ == '__main__':
+    main()

## /tmp/uwz-task5b3-frozen-v4/pure_raw_checks.py (53 lines, SHA256 7fd7736cb3905b162770d6750cd7cc217be72c82d3f5feff3f108093861b3de1)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/pure_raw_checks.py
@@ -0,0 +1,53 @@
+"""Exercise raw frame order using the pinned hyperframe encoder, without sockets."""
+from hyperframe.frame import HeadersFrame, RstStreamFrame
+import raw_observer as observer
+
+
+def frame_headers(stream):
+    frame = HeadersFrame(stream)
+    frame.flags.add('END_STREAM')
+    frame.flags.add('END_HEADERS')
+    frame.data = b'\x88'
+    return frame.serialize()
+
+
+def reset(stream, code=0):
+    frame = RstStreamFrame(stream)
+    frame.error_code = code
+    return frame.serialize()
+
+
+def rejects(name, data, expect_reset=True):
+    state = observer.new_state()
+    observer.register(state, 1, expect_reset)
+    try:
+        observer.observe(state, data)
+    except ValueError as error:
+        print(name + ': rejected: ' + str(error))
+        return
+    raise AssertionError(name + ': unexpectedly accepted')
+
+
+def main():
+    state = observer.new_state()
+    observer.register(state, 1, True)
+    data = frame_headers(1) + reset(1)
+    for byte in data:
+        observer.observe(state, bytes([byte]))
+    observer.retire(state, 1)
+    print('split final and NO_ERROR reset: accepted')
+    rejects('early', reset(1))
+    rejects('duplicate', frame_headers(1) + reset(1) + reset(1))
+    rejects('wrong code', frame_headers(1) + reset(1, 2))
+    rejects('wrong stream', frame_headers(1) + reset(3))
+    rejects('healthy', frame_headers(1) + reset(1), False)
+    try:
+        observer.observe(state, reset(1))
+    except ValueError as error:
+        print('retired exception: rejected: ' + str(error))
+    else:
+        raise AssertionError('retired exception accepted')
+
+
+if __name__ == '__main__':
+    main()

## /tmp/uwz-task5b3-frozen-v4/pure_sequences_checks.py (62 lines, SHA256 33491cc90f8ebc8c5657a4d9d9441b22e2746f9bc67b608adcb29e1342331b52)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/pure_sequences_checks.py
@@ -0,0 +1,62 @@
+"""Check case ordering and bounds with caller-owned synthetic observations."""
+import cases
+
+
+def scenario(case):
+    state = {'records': {}, 'next': 1, 'sent': 0, 'flow': 0, 'events': []}
+    def start(route, tag, length, query, headers, status=200, reset=False):
+        stream = state['next']
+        state['next'] += 2
+        state['records'][stream] = {'tag': tag, 'accepted': 0, 'paused': tag in ('receive_credit', 'concurrent_hold'), 'held': 0}
+        state['events'].append(('start', route, tag, length, query, tuple(headers), status, reset))
+        return stream
+    def send(stream, total, offset, count, end, padding=None):
+        assert count <= 8192
+        state['sent'] += count
+        state['flow'] += count + (padding + 1 if padding is not None else 0)
+        item = state['records'][stream]
+        if item['tag'] == 'queued_trailers_padding' and offset == 0:
+            item['accepted'] = 7
+            item['paused'] = True
+        elif item['paused']:
+            item['held'] += count
+        else:
+            item['accepted'] += count
+        state['events'].append(('send', item['tag'], offset, count, end, padding))
+    def status(tag):
+        item = next(item for item in state['records'].values() if item['tag'] == tag)
+        return {'accepted': item['accepted'], 'paused': item['paused'], 'begin': 1, 'end': 0, 'cancel': 0, 'chunks': 0}
+    def resume(tag):
+        item = next(item for item in state['records'].values() if item['tag'] == tag)
+        item['paused'] = False
+        item['accepted'] += item['held']
+        state['events'].append(('resume', tag))
+    def mark(name):
+        def action(*args):
+            state['events'].append((name,) + args)
+        return action
+    api = {'start': start, 'send': send, 'status': status, 'resume': resume,
+           'finish': lambda stream, keep=False: state['events'].append(('finish', state['records'][stream]['tag'], keep)),
+           'trailers': mark('trailers'), 'pending': mark('pending'), 'refund_bound': mark('refund_bound'),
+           'initial_credit': mark('initial_credit'), 'zero_credit': mark('zero_credit'),
+           'settled_credit': mark('settled_credit'), 'active': mark('active'), 'health': mark('health'), 'retire': mark('retire')}
+    cases.execute(api, case)
+    return state
+
+
+def main():
+    expectations = {'queued_trailers_padding': (12289, 12297), 'receive_credit': (65536, 65536), 'concurrent_routes': (96, 96)}
+    for case, counts in expectations.items():
+        result = scenario(case)
+        assert (result['sent'], result['flow']) == counts
+        print(case, 'logical', result['sent'], 'flow', result['flow'], 'events', len(result['events']))
+    try:
+        cases.execute({}, 'unsupported')
+    except ValueError:
+        print('unsupported case: rejected')
+    else:
+        raise AssertionError('unsupported case accepted')
+
+
+if __name__ == '__main__':
+    main()

## /tmp/uwz-task5b3-frozen-v4/raw_observer.py (78 lines, SHA256 13f686ffcfa3ba2b0d13c12d52f317e54e691f36d8e7474aea76da96a88bfc48)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/raw_observer.py
@@ -0,0 +1,78 @@
+"""Bounded raw HTTP/2 frame-order observation; transport is external."""
+
+READ_BOUND = 8192
+STREAM_LIMIT = 8
+
+
+def require(condition, message):
+    if not condition:
+        raise ValueError(message)
+
+
+def new_state():
+    return {"header": bytearray(), "remaining": 0, "frame": None,
+            "reset_payload": bytearray(), "streams": {}}
+
+
+def register(state, stream_id, expect_reset):
+    streams = state["streams"]
+    require(0 < stream_id <= 0x7fffffff and stream_id not in streams, "invalid stream")
+    require(len(streams) < STREAM_LIMIT, "stream bound")
+    streams[stream_id] = {"expect_reset": expect_reset, "end": False, "reset": False}
+
+
+def retire(state, stream_id):
+    record = state["streams"][stream_id]
+    require(record["end"] and record["reset"] == record["expect_reset"], "incomplete stream")
+    del state["streams"][stream_id]
+
+
+def finish_frame(state):
+    frame = state["frame"]
+    stream_id = frame["stream"]
+    if frame["type"] == 3:
+        record = state["streams"].get(stream_id)
+        require(record is not None, "reset on unregistered stream")
+        require(record["expect_reset"], "reset on healthy stream")
+        require(record["end"], "reset before final end")
+        require(not record["reset"], "duplicate reset")
+        require(state["reset_payload"] == b'\0\0\0\0', "wrong reset code")
+        record["reset"] = True
+    elif frame["type"] in (0, 1) and frame["flags"] & 1:
+        record = state["streams"].get(stream_id)
+        if record is not None:
+            require(not record["end"], "duplicate final end")
+            record["end"] = True
+    state["frame"] = None
+    state["reset_payload"].clear()
+
+
+def observe(state, data):
+    require(len(data) <= READ_BOUND, "read bound")
+    offset = 0
+    while offset < len(data):
+        if state["frame"] is None:
+            header = state["header"]
+            count = min(9 - len(header), len(data) - offset)
+            header.extend(data[offset:offset + count])
+            offset += count
+            if len(header) < 9:
+                continue
+            length = int.from_bytes(header[:3], "big")
+            frame_type = header[3]
+            stream_id = int.from_bytes(header[5:9], "big") & 0x7fffffff
+            if frame_type == 3:
+                require(length == 4 and stream_id != 0, "invalid reset frame")
+            state["frame"] = {"type": frame_type, "flags": header[4], "stream": stream_id}
+            state["remaining"] = length
+            header.clear()
+            if length == 0:
+                finish_frame(state)
+            continue
+        count = min(state["remaining"], len(data) - offset)
+        if state["frame"]["type"] == 3:
+            state["reset_payload"].extend(data[offset:offset + count])
+        offset += count
+        state["remaining"] -= count
+        if state["remaining"] == 0:
+            finish_frame(state)

## /tmp/uwz-task5b3-frozen-v4/run_live.py (511 lines, SHA256 6ab4db7f444c64be50c7b334c07e20f265997a26abbd0a5d3a539d8088aeee8a)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/run_live.py
@@ -0,0 +1,511 @@
+"""Explicitly gated ordinary owned H2 fixture runner; importing is inert."""
+import argparse
+import hashlib
+import importlib.util
+import json
+import os
+from pathlib import Path
+import signal
+import socket
+import ssl
+import subprocess
+import sys
+import threading
+import time
+
+HERE = Path(__file__).resolve().parent
+PORT = 28443
+PYTHON = '/home/codespace/.python/current/bin/python3'
+PACKAGES = '/tmp/uwz-h2-client-tooling/packages'
+HELPER = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'
+OPENSSL = '/opt/conda/bin/openssl'
+CASES = ('queued_trailers_padding', 'receive_credit', 'concurrent_routes', 'shutdown_idle')
+
+
+def require(condition, message):
+    if not condition:
+        raise RuntimeError(message)
+
+
+def digest(path):
+    value = hashlib.sha256()
+    with open(path, 'rb') as source:
+        while block := source.read(8192):
+            value.update(block)
+    return value.hexdigest()
+
+
+def check_manifest(path, expected):
+    require(digest(path) == expected, 'review manifest identity differs')
+    manifest = json.loads(path.read_text())
+    for root, expected_files in manifest['trees'].items():
+        actual = {str(p.relative_to(root)) for p in Path(root).rglob('*') if p.is_file()}
+        require(actual == set(expected_files), 'tree inventory differs: ' + root)
+        for name, value in expected_files.items():
+            require(digest(Path(root) / name) == value, 'tree input identity differs: ' + name)
+    for name, value in manifest['inputs'].items():
+        require(digest(name) == value, 'input identity differs: ' + name)
+    require(manifest['state'] == 'ready-for-independent-review', 'manifest not review ready')
+    checked_path(__file__, manifest['runner'], manifest['inputs'])
+    checked_path(manifest['wire'], manifest['wire'], manifest['inputs'])
+    checked_path(manifest['raw'], manifest['raw'], manifest['inputs'])
+    checked_path(manifest['cases'], manifest['cases'], manifest['inputs'])
+    checked_path(manifest['flow'], manifest['flow'], manifest['inputs'])
+    checked_path(manifest['helper'], manifest['helper'], manifest['inputs'])
+    return manifest
+
+
+def checked_path(actual, expected, inputs):
+    require(Path(actual).absolute() == Path(expected).absolute(), 'executing source path differs')
+    require(Path(actual).resolve() == Path(expected).absolute(), 'source path resolves elsewhere')
+    require(expected in inputs and digest(actual) == inputs[expected], 'executing source hash differs')
+
+
+def load_bound(name, path, inputs):
+    checked_path(path, path, inputs)
+    spec = importlib.util.spec_from_file_location(name, path)
+    require(spec is not None and spec.loader is not None, 'module loader unavailable')
+    module = importlib.util.module_from_spec(spec)
+    sys.modules[name] = module
+    spec.loader.exec_module(module)
+    checked_path(module.__file__, path, inputs)
+    return module
+
+
+def new_capture():
+    return {'lock': threading.Lock(), 'bytes': bytearray(), 'overflow': False, 'error': None}
+
+
+def capture_fragment(capture, data):
+    with capture['lock']:
+        room = 65536 - len(capture['bytes'])
+        capture['bytes'].extend(data[:room])
+        if len(data) > room:
+            capture['overflow'] = True
+
+
+def capture_snapshot(capture):
+    with capture['lock']:
+        return bytes(capture['bytes']), capture['overflow'], capture['error']
+
+
+def check_capture(capture):
+    _, overflow, error = capture_snapshot(capture)
+    require(not overflow, 'server output exceeds 65536 bytes')
+    require(error is None, 'server output collector failed: ' + str(error))
+
+
+def drain_capture(pipe, capture):
+    try:
+        while data := os.read(pipe.fileno(), 8192):
+            capture_fragment(capture, data)
+    except BaseException as exc:
+        with capture['lock']:
+            capture['error'] = repr(exc)
+    finally:
+        try:
+            pipe.close()
+        except BaseException as exc:
+            with capture['lock']:
+                capture['error'] = repr(exc)
+
+
+def cleanup_actions(actions):
+    errors = []
+    for name, action in actions:
+        try:
+            action()
+        except BaseException as exc:
+            errors.append({'action': name, 'error': repr(exc)})
+    return errors
+
+
+def remaining(deadline):
+    seconds = deadline - time.monotonic()
+    require(seconds > 0, 'absolute deadline expired')
+    return seconds
+
+
+def child_start(pid):
+    # comm can contain spaces or parentheses; the final ')' ends that field.
+    text = Path('/proc', str(pid), 'stat').read_text()
+    return text[text.rfind(')') + 2:].split()[19]
+
+
+def owned_listener(pid):
+    inodes = set()
+    for entry in Path('/proc', str(pid), 'fd').iterdir():
+        target = os.readlink(entry)
+        if target.startswith('socket:['):
+            inodes.add(target[8:-1])
+    rows = Path('/proc/net/tcp').read_text().splitlines()[1:]
+    return [row.split()[9] for row in rows if row.split()[1] == '0100007F:6F1B'
+            and row.split()[3] == '0A' and row.split()[9] in inodes]
+
+
+def wait_marker(child, capture, nonce, deadline):
+    marker = ('H2_READY ' + nonce).encode()
+    while True:
+        check_capture(capture)
+        require(child.poll() is None, 'child exited before readiness')
+        data, _, _ = capture_snapshot(capture)
+        if marker in data:
+            listeners = owned_listener(child.pid)
+            require(len(listeners) == 1, 'owned loopback listener not uniquely identified')
+            return listeners[0]
+        time.sleep(min(0.05, remaining(deadline)))
+
+
+def flush(sock, protocol, deadline, capture):
+    check_capture(capture)
+    pending = protocol.data_to_send()
+    if pending:
+        sock.settimeout(remaining(deadline))
+        sock.sendall(pending)
+
+
+def receive(sock, protocol, records, raw, trace, deadline, wire, capture):
+    check_capture(capture)
+    sock.settimeout(remaining(deadline))
+    data = sock.recv(8192)
+    require(data, 'TLS EOF before response completion')
+    events = wire.accept(protocol, data, records, raw, trace['events'])
+    import h2.events
+    import h2.settings
+    updates = [(event.stream_id, event.delta) for event in events if isinstance(event, h2.events.WindowUpdated)]
+    initial = None
+    for event in events:
+        if isinstance(event, h2.events.RemoteSettingsChanged):
+            changed = event.changed_settings.get(h2.settings.SettingCodes.INITIAL_WINDOW_SIZE)
+            if changed is not None:
+                initial = changed.new_value
+                require(initial == 65535, 'peer stream initial window changed')
+    ledger = trace['ledger']
+    trace['flow'].receive_batch(ledger, updates, initial)
+    windows = {stream_id: protocol.local_flow_control_window(stream_id)
+               for stream_id, item in ledger.streams.items() if item.open}
+    trace['flow'].check_public(ledger, protocol.outbound_flow_control_window, windows)
+    require(len(trace['snapshots']) < 4096, 'flow snapshot bound exceeded')
+    trace['snapshots'].append({'connection': ledger.connection, 'sent': ledger.sent,
+                               'refunded': ledger.refunded, 'windows': windows, 'updates': updates})
+    flush(sock, protocol, deadline, capture)
+
+
+def start(protocol, records, raw, method, path, headers, end_stream, limit, wire, status=200, info=0, reset=False):
+    stream = protocol.get_next_available_stream_id()
+    wire.register(records, raw, stream, limit, status, info, reset)
+    protocol.send_headers(stream, [(':method', method), (':scheme', 'https'),
+                                  (':authority', 'localhost'), (':path', path)] + headers,
+                          end_stream=end_stream)
+    return stream
+
+
+def complete(sock, protocol, records, raw, trace, stream, deadline, wire, capture, keep=False):
+    flush(sock, protocol, deadline, capture)
+    record = records[stream]
+    while not (record['ended'] and (not record['expect_reset'] or raw['streams'][stream]['reset'])
+               and not raw['header'] and raw['frame'] is None):
+        receive(sock, protocol, records, raw, trace, deadline, wire, capture)
+    wire.complete(records, raw, stream)
+    result = {'headers': record['headers'], 'bytes': record['bytes'],
+              'sha256': record['hash'].hexdigest(), 'body': bytes(record['body']).decode('utf-8'),
+              'informationals': record['informationals'], 'raw_reset': raw['streams'][stream]['reset'],
+              'reset_event': record['reset_event']}
+    if not keep:
+        wire.retire(records, raw, stream)
+    return result
+
+
+def request(sock, protocol, records, raw, trace, path, deadline, wire, capture, limit=1024):
+    stream = start(protocol, records, raw, 'GET', path, [], True, limit, wire)
+    return complete(sock, protocol, records, raw, trace, stream, deadline, wire, capture)
+
+
+def status(sock, protocol, records, raw, trace, tag, deadline, wire, capture):
+    response = request(sock, protocol, records, raw, trace, '/status/' + tag, deadline, wire, capture)
+    return json.loads(response['body'])
+
+
+def metrics(sock, protocol, records, raw, trace, deadline, wire, capture):
+    response = request(sock, protocol, records, raw, trace, '/metrics', deadline, wire, capture)
+    return json.loads(response['body'])
+
+
+def health(sock, protocol, records, raw, trace, deadline, wire, capture):
+    response = request(sock, protocol, records, raw, trace, '/health', deadline, wire, capture, 2)
+    require(response['body'] == 'ok', 'health differs')
+    return response
+
+
+def run(args, manifest):
+    helper = load_bound('h2_client', manifest['helper'], manifest['inputs'])
+    raw_module = load_bound('raw_observer', manifest['raw'], manifest['inputs'])
+    sys.modules['raw_observer'] = raw_module
+    wire = load_bound('admission_wire', manifest['wire'], manifest['inputs'])
+    require(wire.raw_observer is raw_module, 'raw observer binding differs')
+    cases = load_bound('credit_cases', manifest['cases'], manifest['inputs'])
+    flow = load_bound('credit_flow', manifest['flow'], manifest['inputs'])
+    require(cases.CASES == CASES, 'case catalogue differs')
+    import h2
+    import hpack
+    import hyperframe
+    for module in (h2, hpack, hyperframe):
+        require(Path(module.__file__).resolve().is_relative_to(Path(PACKAGES)), 'client module origin differs')
+    require(Path(helper.__file__).resolve() == Path(HELPER) / 'h2_client.py', 'helper origin differs')
+    overall = time.monotonic() + 900
+    run_dir = Path(args.output).resolve()
+    run_dir.mkdir(mode=0o700)
+    cert, key, log = run_dir / 'certificate.pem', run_dir / 'private-key.pem', run_dir / 'server.log'
+    nonce = os.urandom(16).hex()
+    result = {'nonce': nonce, 'cases': {}, 'success': False, 'cleanup': {},
+              'python': sys.executable, 'python_path': sys.path, 'openssl': OPENSSL,
+              'profile': manifest['binary'], 'manifest_sha256': args.manifest_sha256}
+    child = None
+    sock = None
+    start_id = None
+    error = None
+    capture = new_capture()
+    collector = None
+    try:
+        command = [OPENSSL, 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
+                   '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost',
+                   '-keyout', str(key), '-out', str(cert)]
+        result['certificate_command'] = command
+        certificate_env = {'OPENSSL_CONF': '/opt/conda/ssl/openssl.cnf'}
+        result['certificate_environment'] = certificate_env
+        subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True,
+                       env=certificate_env, timeout=remaining(overall))
+        os.chmod(key, 0o600)
+        cert_der = ssl.PEM_cert_to_DER_cert(cert.read_text())
+        result['certificate_sha256'] = hashlib.sha256(cert_der).hexdigest()
+        env = {'H2_PROFILE_CERT': str(cert), 'H2_PROFILE_KEY': str(key), 'H2_PROFILE_NONCE': nonce}
+        result['child_argv'] = [manifest['binary']]
+        result['child_environment'] = env.copy()
+        child = subprocess.Popen([manifest['binary']], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
+        collector = threading.Thread(target=drain_capture, args=(child.stdout, capture), daemon=True)
+        collector.start()
+        start_id = child_start(child.pid)
+        result['child'] = {'pid': child.pid, 'start': start_id, 'binary_sha256': digest(manifest['binary'])}
+        deadline = min(overall, time.monotonic() + 15)
+        result['listener_inode'] = wait_marker(child, capture, nonce, deadline)
+        ready_output = capture_snapshot(capture)[0].decode('utf-8')
+        capacity = [line for line in ready_output.splitlines() if 'H2_CAPACITY ' in line]
+        require(len(capacity) == 1 and 'slab=4098304' in capacity[0], 'fixture capacity differs')
+        result['capacity'] = capacity[0]
+        require(child_start(child.pid) == start_id and child.poll() is None, 'owned child changed')
+        context = ssl.create_default_context(cafile=str(cert))
+        context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_3
+        context.set_alpn_protocols(['h2'])
+        p32 = helper.payload_block(32, 0, 32)
+        require(hashlib.sha256(p32).hexdigest() == '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5', 'payload digest differs')
+        credit_hash = hashlib.sha256()
+        for offset in range(0, 65536, 8192):
+            credit_hash.update(helper.payload_block(65536, offset, min(8192, 65536 - offset)))
+        responses = {}
+        result['connections'] = []
+        connection_cases = args.cases
+        for case in connection_cases:
+            if sock is not None:
+                require(not records and not raw_state['streams'], 'records remain on previous connection')
+                sock.close()
+                sock = None
+            deadline = min(overall, time.monotonic() + 30)
+            require(child.poll() is None and child_start(child.pid) == start_id, 'owned child changed')
+            require(owned_listener(child.pid) == [result['listener_inode']], 'owned listener changed')
+            raw = socket.create_connection(('127.0.0.1', PORT), timeout=remaining(deadline))
+            try:
+                raw.settimeout(remaining(deadline))
+                sock = context.wrap_socket(raw, server_hostname='localhost', suppress_ragged_eofs=False)
+            except BaseException:
+                raw.close()
+                raise
+            require(sock.version() == 'TLSv1.3' and sock.selected_alpn_protocol() == 'h2', 'TLS/ALPN differs')
+            require(hashlib.sha256(sock.getpeercert(binary_form=True)).hexdigest() == result['certificate_sha256'], 'peer certificate identity differs')
+            require(child.poll() is None and child_start(child.pid) == start_id, 'owned child died')
+            protocol, records, raw_state = helper.new_protocol(), {}, raw_module.new_state()
+            trace = {'events': {}, 'ledger': flow.FlowLedger(), 'flow': flow, 'snapshots': []}
+            flush(sock, protocol, deadline, capture)
+            health(sock, protocol, records, raw_state, trace, deadline, wire, capture)
+            require(protocol.remote_settings.initial_window_size == 65535, 'initial stream window differs')
+            observed, stream_tags = [], {}
+            if case == 'shutdown_idle':
+                result['connections'].append({'case': case, 'tls': sock.version(), 'alpn': sock.selected_alpn_protocol(), 'snapshots': trace['snapshots']})
+                continue
+            def begin(route, tag, length, query, extra, status=200, reset=False):
+                headers = [('content-length', str(length))] + extra
+                stream = start(protocol, records, raw_state, 'POST', '/' + route + '/' + tag + query,
+                               headers, False, 0 if reset else 1024, wire, status, 0, reset)
+                stream_tags[stream] = tag
+                if not reset: flow.open_stream(trace['ledger'], stream)
+                flush(sock, protocol, deadline, capture)
+                return stream
+            def finish(stream, keep=False):
+                item = complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture, keep)
+                tag = stream_tags[stream]
+                responses[tag] = item
+                observed.append({'tag': tag, 'response': item})
+                return item
+            def send(stream, total, offset, length, end_stream, padding=None):
+                require(length <= 8192, 'generated data exceeds bound')
+                data = helper.payload_block(total, offset, length)
+                ledger = trace['ledger']
+                flow.check_public(ledger, protocol.outbound_flow_control_window, {stream: protocol.local_flow_control_window(stream)})
+                flow.send_data(ledger, stream, len(data), padding, protocol.max_outbound_frame_size, end_stream)
+                protocol.send_data(stream, data, end_stream=end_stream, pad_length=padding)
+                require(len(trace['snapshots']) < 4096, 'flow snapshot bound exceeded')
+                trace['snapshots'].append({'send_stream': stream, 'logical': len(data), 'padding': padding, 'connection': ledger.connection, 'stream': ledger.streams[stream].window, 'sent': ledger.sent})
+                flush(sock, protocol, deadline, capture)
+            def trailers(stream, headers):
+                protocol.send_headers(stream, headers, end_stream=True)
+                # The stream may still receive WINDOW_UPDATE; no public stream query after END_STREAM.
+                trace['ledger'].streams[stream].open = False
+                flush(sock, protocol, deadline, capture)
+            def get_status(tag):
+                return status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture)
+            def get_metrics():
+                return metrics(sock, protocol, records, raw_state, trace, deadline, wire, capture)
+            def do_resume(tag):
+                item = request(sock, protocol, records, raw_state, trace, '/resume/' + tag, deadline, wire, capture, 64)
+                require(item['body'] == 'ok', 'resume failed')
+            def pending(stream):
+                require(records[stream]['headers'] is None and not records[stream]['ended'], 'final before resume')
+            def active(count):
+                require(get_metrics()['active'] == count, 'active binding count differs')
+            def initial_credit(stream):
+                ledger = trace['ledger']
+                require(ledger.initial_stream == ledger.connection == ledger.streams[stream].window == 65535, 'initial credit differs')
+                flow.check_public(ledger, protocol.outbound_flow_control_window, {stream: protocol.local_flow_control_window(stream)})
+            def zero_credit(stream):
+                ledger = trace['ledger']
+                require(ledger.connection == ledger.streams[stream].window == ledger.refunded == ledger.streams[stream].refunded == 0, 'zero credit differs')
+                flow.check_public(ledger, protocol.outbound_flow_control_window, {stream: protocol.local_flow_control_window(stream)})
+            def settled_credit(stream, amount):
+                ledger = trace['ledger']
+                while ledger.refunded < amount or ledger.streams[stream].refunded < amount:
+                    receive(sock, protocol, records, raw_state, trace, deadline, wire, capture)
+                require(ledger.refunded == ledger.streams[stream].refunded == amount, 'settled credit differs')
+            def refund_bound(stream, maximum):
+                ledger = trace['ledger']
+                require(ledger.refunded <= maximum and ledger.streams[stream].refunded <= maximum, 'early refund exceeds bound')
+            api = {'start': begin, 'finish': finish, 'send': send, 'trailers': trailers, 'status': get_status,
+                   'metrics': get_metrics, 'resume': do_resume, 'pending': pending, 'active': active,
+                   'initial_credit': initial_credit, 'zero_credit': zero_credit, 'settled_credit': settled_credit,
+                   'refund_bound': refund_bound, 'health': lambda: health(sock, protocol, records, raw_state, trace, deadline, wire, capture),
+                   'retire': lambda stream: wire.retire(records, raw_state, stream)}
+            cases.execute(api, case)
+            require(not records and not raw_state['streams'], 'response records remain after case')
+            require(get_metrics()['active'] == 0, 'case has active bindings')
+            expected_flow = {'queued_trailers_padding': 12297, 'receive_credit': 65536, 'concurrent_routes': 96}[case]
+            require(trace['ledger'].sent == expected_flow, 'case flow total differs')
+            result['cases'][case] = observed
+            result['connections'].append({'case': case, 'tls': sock.version(), 'alpn': sock.selected_alpn_protocol(),
+                                          'events': trace['events'], 'snapshots': trace['snapshots'], 'sent_flow': trace['ledger'].sent})
+        deadline = min(overall, time.monotonic() + 30)
+        final = {tag: status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture) for tag in cases.TAGS}
+        aggregate = metrics(sock, protocol, records, raw_state, trace, deadline, wire, capture)
+        selected = cases.selected_tags(args.cases)
+        empty_hash = hashlib.sha256(b'').hexdigest()
+        for tag in cases.TAGS:
+            cases.verify_record(final[tag], cases.expected(tag, selected, empty_hash, credit_hash.hexdigest()))
+            if tag in selected and tag != 'concurrent_refused':
+                require(json.loads(responses[tag]['body']) == final[tag], 'final response differs from status')
+        for field in ('middleware', 'attempts', 'begin', 'end', 'cancel', 'failure', 'accepted', 'errors'):
+            require(aggregate[field] == sum(record[field] for record in final.values()), 'aggregate ' + field + ' differs')
+        require(aggregate['active'] == 0 and not aggregate['slot0_active'] and not aggregate['slot1_active'], 'active fixture')
+        result['final_status'] = final
+        result['final_metrics'] = aggregate
+        sock.close()
+        sock = None
+        require(child_start(child.pid) == start_id and child.poll() is None, 'child identity changed')
+        os.kill(child.pid, signal.SIGTERM)
+        exit_code = child.wait(timeout=remaining(min(overall, time.monotonic() + 15)))
+        result['cleanup'] = {'signal': 'SIGTERM', 'exit_code': exit_code, 'reaped': True, 'forced': False}
+        require(exit_code == 0, 'owned server exit differs')
+        collector.join(timeout=remaining(overall))
+        require(not collector.is_alive(), 'server output collector did not finish')
+        check_capture(capture)
+        text = capture_snapshot(capture)[0].decode('utf-8')
+        post = {}
+        post_metrics = None
+        for line in text.splitlines():
+            marker = 'H2_RECORD ' + nonce + ' '
+            if marker in line:
+                item = json.loads(line.split(marker, 1)[1])
+                require(item['tag'] not in post, 'duplicate post-deinit tag')
+                post[item['tag']] = item
+            marker = 'H2_DEINIT ' + nonce + ' '
+            if marker in line:
+                require(post_metrics is None, 'duplicate post-deinit aggregate')
+                post_metrics = json.loads(line.split(marker, 1)[1])
+        require(post == final and post_metrics == aggregate, 'post-deinit state differs')
+        if 'shutdown_idle' in args.cases:
+            result['cases']['shutdown_idle'] = {'exit_code': exit_code, 'post_deinit': True}
+        result['success'] = True
+    except BaseException as exc:
+        error = repr(exc)
+    finally:
+        def close_socket():
+            if sock is not None:
+                sock.close()
+
+        def signal_child():
+            if child is None or child.poll() is not None:
+                return
+            require(start_id is None or child_start(child.pid) == start_id, 'child identity changed during cleanup')
+            result['cleanup']['forced'] = True
+            child.kill()
+
+        def wait_child():
+            if child is None:
+                return
+            child.wait(timeout=15)
+            result['cleanup']['exit_code'] = child.returncode
+            result['cleanup']['reaped'] = True
+
+        def delete_key():
+            key.unlink(missing_ok=True)
+
+        def save_log():
+            if collector is not None:
+                collector.join(timeout=15)
+            data, overflow, collector_error = capture_snapshot(capture)
+            log.write_bytes(data)
+            require(collector is None or not collector.is_alive(), 'server output collector did not finish')
+            require(not overflow and collector_error is None, 'server output collection failed or overflowed')
+
+        def close_pipe():
+            if child is not None and child.stdout is not None:
+                child.stdout.close()
+
+        errors = cleanup_actions((('socket', close_socket), ('child_signal', signal_child),
+                                  ('child_wait', wait_child), ('key', delete_key), ('log', save_log),
+                                  ('pipe', close_pipe)))
+        if errors or result['cleanup'].get('forced', False):
+            result['success'] = False
+        result['cleanup']['errors'] = errors
+        result['error'] = error
+        (run_dir / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
+    require(result['success'], 'owned run failed: ' + str(error))
+
+
+def main():
+    parser = argparse.ArgumentParser()
+    parser.add_argument('--run', action='store_true', required=True)
+    parser.add_argument('--manifest', type=Path, required=True)
+    parser.add_argument('--manifest-sha256', required=True)
+    parser.add_argument('--output', required=True)
+    parser.add_argument('--cases', nargs='+', choices=CASES, required=True)
+    args = parser.parse_args()
+    require(set(os.environ) == {'PYTHONPATH'}, 'runner environment must contain only fixed PYTHONPATH')
+    require(sys.executable == PYTHON and sys.dont_write_bytecode and sys.flags.no_site and os.environ.get('PYTHONPATH') == PACKAGES + ':' + HELPER,
+            'Python interpreter or PYTHONPATH differs')
+    require(len(set(args.cases)) == len(args.cases) and ('shutdown_idle' not in args.cases or args.cases[-1] == 'shutdown_idle'), 'invalid case order')
+    output = Path(args.output)
+    require(output.is_absolute() and output.resolve().is_relative_to(Path('/tmp')) and output.resolve() != Path('/tmp'), 'output must be new /tmp path')
+    require(not output.exists(), 'output already exists')
+    manifest = check_manifest(args.manifest, args.manifest_sha256)
+    run(args, manifest)
+
+
+if __name__ == '__main__':
+    main()

## /tmp/uwz-task5b3-frozen-v4/wire.py (97 lines, SHA256 41394947f72bbf25eb3d00eb82c46204c3b0e8c732aff56159bba1eb6da42d11)
--- /dev/null
+++ /tmp/uwz-task5b3-frozen-v4/wire.py
@@ -0,0 +1,97 @@
+"""Bounded HTTP/2 response event and raw reset observation."""
+import hashlib
+import h2.events
+import raw_observer
+
+READ_BOUND = 8192
+STREAM_LIMIT = 8
+HEADER_FIELDS = 32
+HEADER_BYTES = 4096
+INFO_COUNT = 16
+INFO_BYTES = 16384
+EVENT_LIMIT = 64
+
+
+def require(condition, message):
+    if not condition:
+        raise ValueError(message)
+
+
+def register(records, raw, stream_id, body_limit, final_status, info_count, expect_reset):
+    require(len(records) < STREAM_LIMIT and stream_id not in records, 'stream record bound')
+    require(0 <= body_limit < 4096 and info_count in (0, 1), 'invalid expectation')
+    raw_observer.register(raw, stream_id, expect_reset)
+    records[stream_id] = {'headers': None, 'informationals': 0, 'info_bytes': 0,
+                          'bytes': 0, 'hash': hashlib.sha256(), 'body': bytearray(),
+                          'limit': body_limit, 'ended': False, 'reset_event': False,
+                          'status': str(final_status), 'expected_info': info_count,
+                          'expect_reset': expect_reset}
+
+
+def checked_headers(headers):
+    require(len(headers) <= HEADER_FIELDS, 'header field count bound')
+    size = sum(len(k.encode('utf-8')) + len(v.encode('utf-8')) + 32 for k, v in headers)
+    require(size <= HEADER_BYTES, 'header byte bound')
+    return size
+
+
+def accept(protocol, data, records, raw, trace):
+    require(len(data) <= READ_BOUND, 'read exceeds bound')
+    raw_observer.observe(raw, data)
+    events = protocol.receive_data(data)
+    for event in events:
+        name = type(event).__name__
+        require(name in trace or len(trace) < EVENT_LIMIT, 'event type bound')
+        trace[name] = trace.get(name, 0) + 1
+        if isinstance(event, h2.events.ConnectionTerminated):
+            raise ValueError('HTTP/2 connection terminated')
+        if not isinstance(event, (h2.events.InformationalResponseReceived, h2.events.ResponseReceived,
+                                  h2.events.TrailersReceived, h2.events.DataReceived,
+                                  h2.events.StreamEnded, h2.events.StreamReset)):
+            continue
+        require(event.stream_id in records, 'unregistered response stream')
+        record = records[event.stream_id]
+        if isinstance(event, h2.events.InformationalResponseReceived):
+            size = checked_headers(event.headers)
+            require(record['informationals'] < INFO_COUNT and record['info_bytes'] + size <= INFO_BYTES,
+                    'informational bound')
+            require(record['headers'] is None and [v for k, v in event.headers if k == ':status'] == ['100'] and not any(k == 'x-middleware' for k, _ in event.headers), 'unexpected informational')
+            record['informationals'] += 1
+            record['info_bytes'] += size
+            require(record['informationals'] <= record['expected_info'], 'extra informational')
+        elif isinstance(event, h2.events.ResponseReceived):
+            checked_headers(event.headers)
+            require(record['headers'] is None, 'duplicate response headers')
+            require([v for k, v in event.headers if k == ':status'] == [record['status']], 'wrong final status')
+            require([v for k, v in event.headers if k == 'x-middleware'] == ['retained'], 'middleware header')
+            record['headers'] = list(event.headers)
+        elif isinstance(event, h2.events.TrailersReceived):
+            raise ValueError('unexpected trailers')
+        elif isinstance(event, h2.events.DataReceived):
+            require(not record['ended'] and record['bytes'] + len(event.data) <= record['limit'], 'response body bound')
+            record['bytes'] += len(event.data)
+            record['hash'].update(event.data)
+            record['body'].extend(event.data)
+            protocol.acknowledge_received_data(event.flow_controlled_length, event.stream_id)
+        elif isinstance(event, h2.events.StreamEnded):
+            require(not record['ended'], 'duplicate end')
+            record['ended'] = True
+        elif isinstance(event, h2.events.StreamReset):
+            require(record['expect_reset'] and raw['streams'][event.stream_id]['reset'], 'unexpected reset event')
+            require(not record['reset_event'] and int(event.error_code) == 0, 'invalid reset event')
+            record['reset_event'] = True
+
+    return events
+
+
+def complete(records, raw, stream_id):
+    record = records[stream_id]
+    require(record['headers'] is not None and record['ended'], 'missing final')
+    require(record['informationals'] == record['expected_info'], 'missing informational')
+    require(raw['streams'][stream_id]['reset'] == record['expect_reset'], 'missing reset')
+
+
+def retire(records, raw, stream_id):
+    complete(records, raw, stream_id)
+    raw_observer.retire(raw, stream_id)
+    del records[stream_id]

## /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/freeze.py (104 lines, SHA256 15d87ee2697e1dc3edeeaf0b7ee6173955b4734d3a9abfb56f1ec783ff40564a)
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/freeze.py
@@ -0,0 +1,104 @@
+"""Create a current-closure review manifest without executing candidate code."""
+import hashlib
+import json
+from pathlib import Path
+import shutil
+
+HERE = Path(__file__).resolve().parent
+ROOT = Path('/workspaces/uWebZockets')
+FROZEN = Path('/tmp/uwz-task5b3-frozen-v4')
+PRIOR = ROOT / '.uwz-work/evidence/h2-streaming/integration-owned/admission/fix1/review-manifest.json'
+SOURCE_NAMES = ('profile.zig', 'prepare.py', 'run_live.py', 'cases.py', 'wire.py', 'raw_observer.py',
+                'flow_ledger.py', 'pure_flow_checks.py', 'pure_cases_checks.py', 'pure_sequences_checks.py',
+                'pure_codec_checks.py', 'pure_raw_checks.py', 'fixture-contract.md', 'coverage_inventory.json')
+
+
+def digest(path):
+    value = hashlib.sha256()
+    with Path(path).open('rb') as source:
+        while block := source.read(8192):
+            value.update(block)
+    return value.hexdigest()
+
+
+def inventory(root):
+    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file()}
+
+
+def main():
+    prior = json.loads(PRIOR.read_text())
+    tree_paths = ['/tmp/uwz-task4d-fix1-frozen', '/tmp/uwz-reviewed-libxev-c223-loop-callbacks',
+                  '/tmp/uwz-h2-client-tooling/packages',
+                  '/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy']
+    trees = {}
+    for name in tree_paths:
+        actual = inventory(Path(name))
+        if actual != prior['trees'][name]:
+            raise ValueError('current tree differs from prior reviewed identity: ' + name)
+        trees[name] = actual
+    zig_lib = '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/lib'
+    trees[zig_lib] = inventory(Path(zig_lib))
+    inputs = {}
+    fixed = ['/home/codespace/.python/current/bin/python3', '/opt/conda/bin/openssl', '/opt/conda/ssl/openssl.cnf',
+             '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig',
+             '/lib/x86_64-linux-gnu/libc.so.6', '/lib/x86_64-linux-gnu/libm.so.6',
+             '/lib/x86_64-linux-gnu/libpthread.so.0', '/lib/x86_64-linux-gnu/libdl.so.2',
+             '/lib/x86_64-linux-gnu/libcrypto.so.3', '/lib/x86_64-linux-gnu/libssl.so.3',
+             '/lib64/ld-linux-x86-64.so.2', '/opt/conda/lib/libcrypto.so.3', '/opt/conda/lib/libssl.so.3',
+             str(ROOT / '.uwz-work/evidence/h1-transport/r2/c-native.zig'),
+             str(ROOT / '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'),
+             str(ROOT / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json'),
+             str(ROOT / '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json')]
+    for path in fixed:
+        inputs[path] = digest(path)
+        if path in prior['inputs'] and inputs[path] != prior['inputs'][path]:
+            raise ValueError('reviewed input differs: ' + path)
+    python_lib = Path('/home/codespace/.python/current/lib/python3.14')
+    for path in sorted(python_lib.rglob('*')):
+        relative = path.relative_to(python_lib)
+        if any(part in ('site-packages', 'test', 'tests', 'idlelib', 'tkinter', 'venv', 'ensurepip') for part in relative.parts):
+            continue
+        if path.is_file() and path.suffix in ('.py', '.pyc', '.so', '.zip'):
+            inputs[str(path)] = digest(path)
+    for mode in ('debug', 'release'):
+        label = 'fixture-' + mode + '-v1'
+        record = json.loads((HERE / (label + '.json')).read_text())
+        binary = '/tmp/uwz-task5b3-' + mode + '/profile'
+        if record['exit_status'] != 0 or not record['inputs_unchanged'] or digest(binary) != record['binary_sha256']:
+            raise ValueError('build receipt or binary differs: ' + mode)
+        if record['fixture_after']['profile.zig'] != digest(HERE / 'profile.zig') or record['fixture_after']['prepare.py'] != digest(HERE / 'prepare.py'):
+            raise ValueError('compiled sources differ: ' + mode)
+        inputs[binary] = digest(binary)
+        for suffix in ('.json', '.command.json', '.log', '-source-inputs.json', '-source-after.json'):
+            path = HERE / (label + suffix)
+            inputs[str(path)] = digest(path)
+    if FROZEN.exists():
+        raise ValueError('frozen destination already exists')
+    FROZEN.mkdir(mode=0o700)
+    for name in SOURCE_NAMES:
+        shutil.copyfile(HERE / name, FROZEN / name)
+    trees[str(FROZEN)] = inventory(FROZEN)
+    for name, value in trees[str(FROZEN)].items():
+        inputs[str(FROZEN / name)] = value
+    for name in ('freeze.py', 'pure-flow-v2.log', 'pure-cases.log', 'pure-sequences.log', 'pure-sequences-v2.log', 'pure-sequences-v3.log', 'pure-codec.log', 'pure-raw.log', 'format.log', 'ast-v3.log'):
+        inputs[str(HERE / name)] = digest(HERE / name)
+    manifest = {'state': 'ready-for-independent-review', 'runner': str(FROZEN / 'run_live.py'),
+                'wire': str(FROZEN / 'wire.py'), 'raw': str(FROZEN / 'raw_observer.py'),
+                'cases': str(FROZEN / 'cases.py'), 'flow': str(FROZEN / 'flow_ledger.py'),
+                'helper': str(ROOT / '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'),
+                'binary': '/tmp/uwz-task5b3-release/profile', 'trees': trees,
+                'tree_counts': {name: len(files) for name, files in trees.items()}, 'inputs': inputs,
+                'historical_manifest_sha256': {str(PRIOR): digest(PRIOR)},
+                'scope': 'current dependency closure only; historical manifests preserved by identity, not runtime inputs'}
+    output = HERE / 'review-manifest-v4.json'
+    if output.exists():
+        raise ValueError('manifest already exists')
+    output.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
+    print('current tree counts:', manifest['tree_counts'])
+    print('current individual inputs:', len(inputs))
+    print('frozen manifest SHA-256:', digest(output))
+    print('historical manifest SHA-256:', digest(PRIOR))
+
+
+if __name__ == '__main__':
+    main()

## /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/check_frozen_v4.py (15 lines, SHA256 8b3b5239e897e2148532c546e0f2082fde860905f79f5162fdc4baef5348d848)
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/check_frozen_v4.py
@@ -0,0 +1,15 @@
+"""Read-only AST and manifest verification; does not run the candidate."""
+import ast
+import importlib.util
+from pathlib import Path
+
+root = Path('/tmp/uwz-task5b3-frozen-v4')
+for path in sorted(root.glob('*.py')):
+    ast.parse(path.read_text(), filename=str(path))
+    print('AST OK:', path.name)
+spec = importlib.util.spec_from_file_location('frozen_runner', root / 'run_live.py')
+module = importlib.util.module_from_spec(spec)
+spec.loader.exec_module(module)
+manifest = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/review-manifest-v4.json')
+module.check_manifest(manifest, '67af47d54c4622d9c9ca822f00f1e10f2afbaf1debc7d69a1c5545a919ef8446')
+print('frozen runner and current manifest: all bound paths and hashes matched')
