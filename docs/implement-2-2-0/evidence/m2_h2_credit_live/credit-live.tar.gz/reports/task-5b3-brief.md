# Task5b3 StageA: trailers, credit and concurrent routes

Read this first, then task-5b3-architecture.md for the source-backed exact
sequences and ledger equations. Current Root50324061f32b7bfcec761d03c590876682c270cf
is clean and pushed. The prior upload/pause/admission proofs stay preserved;
all three new cases and the later metadata/5c/full-milestone requirements remain.

Own ONLY new .uwz-work/evidence/h2-streaming/integration-owned/credit/ test-only
sources, evidence and this task's reports. You are not alone; no reverts or
Root/other-agent edits, subagents, commits/refs/pushes/fetches/downloads/external
model CLI. Graphify before new code searches; provided frozen paths may be read.

Use immutable /tmp/uwz-task4d-fix1-frozen,1031files,
fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de,
reviewed c22393-file override, originalr2bindings/sixlibs, pinned42-file client
0f85bd19 and unchanged helper07a5201. No production or dependency adoption.
Keep the exact eight-connection profile: requestline512,header4096/count80,
H1body256,H2body4096,encodedheader8192,responseheader4096/count32,captures24,
writequeue65536,streamingtrue,unrelatedfeatures/devlogoff; slab4098304 unchanged.

Use real Server.preset(...).build_https, /upload/:tag limit100000000/quota2 and
/limit/:tag limit32/quota1, two reusable sink slots and32persistent result slots.
Six named body records: queued_trailers_padding,receive_credit,concurrent_hold,
concurrent_refused,concurrent_upload,concurrent_recovery; remaining26 are explicit
untouched spares. Keep records and independent expected metadata separate from
reused bindings and valid through deinit. Hash only actually accepted prefixes;
never accumulate full bodies or simulate protocol limits in fixture callbacks.

Public status/metrics/resume and authorized headers_only middleware retain the
approved actual-response header X-Middleware:retained and body-head accounting.
Copied controls run on owning loop; resume may retire binding synchronously.
No callback-local Request/StreamingRequest/Response/view arrays/chunk pointers
retained; postresume reads stable result storage and its own fresh Response.
Compare begin/end request metadata against independent owned expected constants,
not a copy of actual begin values. Track checks/errors explicitly.

Supported selectable IDs only queued_trailers_padding,receive_credit,
concurrent_routes,shutdown_idle; unique subsets with idle last. Every case uses
a FRESH ordinary H2/TLS connection within the same directly owned child; all its
status/control barriers are on that case's connection. Close a case connection
normally only after no active binding/stream. No retries, fallback or close-flag/
linger manipulation. Ensure stream-ID reuse across connections cannot overwrite
earlier per-tag observations. Final32 snapshots then finalmetrics LAST, no more
buffered requests before owned shutdown; all postdeinit data must match.

queued_trailers_padding: actual /upload/queued_trailers_padding?case=qtp,
Content-Length12289, initial x-metadata:initial-qtp and x-initial-only:initial-only.
Partial-once callback mode accepts cumulative7 then pauses independent of TLS
span boundaries. Send first8192 P12289 bytes/noEOF; status7/paused/B1/E0/C0/no
finalHEADERS/end. Send remaining4097 with pad_length7/noEOF then trailerHEADERS
EOF x-metadata:trailer-qtp,x-trailer-only:discarded. Second barrier unchanged7/
noend/cancel/finalresponse. Publicresume completes200/12289/H12289/1/1/0.
Expected SHA f84149bf46313d9f7da734e3d53f88b2d01a2c01c38bf422063c507b237915f4.
Logical12289,flow12297. End sees original method,target/path/query/tag and both
initial values; no trailer-only field or replacement. Before resume each scope's
WU sum<=15 (7consumed+8padding), no exact packet/frame/delta assumptions. Later
refunds<=sentflow; no required final credit after stream closes.

receive_credit: /upload/receive_credit,length65536,beginpaused,no padding/trailers/
Expect. After initialsettings require streaminitial65535,connection65535,
streamledger65535,publicmin65535. Send first65535 P65536 bytes in legal<=8192
chunks with noEOF. Sameconn HEADERS-only health/status at zero requestDATAcredit
must work while both ledgers/publicmin0,accepted0/chunks0/E0/B1/C0. No refund of
held unpadded bytes before resume. Publicresume drains65535 withoutend. Read
genuine peerWU in both scopes until settled sums65535 each; require status
accepted65535/end0/no finalresponse. Send helper.payload_block(65536,65535,1)+EOF
only when both scopes permit. Final200/65536/independentH65536/1/1/0;logical=flow
65536. No over-window send, receive-window enlargement, localWU manufacture of
upload credit, private stream-state inspection or siblingDATA-at-zero promise.

concurrent_routes: paused quotaONE /limit/concurrent_hold,length32; ready other
/upload/concurrent_upload,length32. Refused /limit/concurrent_refused,length1+
Expect/noDATA and later /limit/concurrent_recovery,length32. Give held and healthy
uploads distinct initial x-metadata and path/query expectations. Hold first16
P32 bytes queued/paused/accepted0. Refused head503/empty/no100/noA,one ordered
rawNOERROR reset. Admit healthy other route BEFORE DATA and verify TWO active
bindings; complete its P32/EOF with200/H32 andhealth, holder still0/paused/noend.
Resume holder, status16/end0, send remaining16/EOF,200/H32; complete same-route
recoveryP32/EOF,200/H32. M4/A3/B3/E3/C0/F0,96logical/flow,distinct metadata intact,
at mosttwo slots. Only refused stream permits reset; every healthy forbids it.
Ruling: paused quota-one limit is the held streamed upload, preserving intended
route/capture/quota isolation without increasing to a third fixture sink slot.

P(n) uses original helper incrementally<=8192; P32 SHA
7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5.
Full3case totals:6bodyrecords/M6,A5/B5/E5,C0/F0,accepted77921,flow77929,
no active/errors. Each subset is self-contained; unused named/spare records stay
zero/empty/none. One finalmiddleware header each; no informational, GOAWAY,
response trailer, unexpected reset or EOF. Preserve bounded trailing refusal
barrier then retire exception to default raw reset rejection.

Implement a focused pure flow ledger using public h2 fields/events, with explicit
caller data, no native I/O/clock/logging. Connection C=65535+receivedWU0-sentflow;
stream S=advertisedinitial+settingsadjustments+receivedWUi-sentflowi. Public
outbound_flow_control_window is C; local_flow_control_window(id) is min(C,S),
NOT standalone S. remote_settings.initial_window_size is streaminitial only;
remote_flow_control_window is the opposite direction and unsuitable.
Before send, full DATA flow cost (payload+pad byte+padding) fits C,S and peer
maxframe; HEADERS do not debit DATA credit. Compare updated public counters at
the correct batch boundary: protocol.receive_data applies ALL frames before
returning events, so accumulate a receive batch's WU/settings events before
comparing its final public state. No false per-event mismatch for coalesced WUs.
Track open streams only for current-window queries; stop querying closed/send-
finished streams and do not demand final stream refunds. With unchanged settings
require0<=C,S<=65535 and cumulative refunds<=sentflow; no packetization or
callback/WU-frame count oracle. Record actual ledger snapshots/results.

Preserve process guards: exact executing runner and every custommodule/helper
path/hash and loaded identity; inert imports/explicit--run; fixedPython-B-S and
package/helperPYTHONPATH; frozen review-ready source; own direct PID/start/nonce/
listener/cert fingerprint beforehealth on every connection; TLS1.3/h2;
127.0.0.1:28443 only; freshprivate/tmp output;15ready/30eachcase/900total/
15graceful absolute deadlines; continuouscombinedoutput65536; independentclose/
signal/reap/keydelete/log/pipecleanup, forced/errorsnever success. Reads and
generatedlogical spans8192, responsebody<4096, headers32/4096,info16/16384,
<=8active response records, bounded event/frame/flow/32result storage.

StageA allows source, fixedZig0.16 Debug/RS COMPILE ONLY(-j2), profilefmt, AST and
meaningful real pinned-codec/data checks. Pure server-side codec WU generation
may test ledger math in memory; it is not evidence of native credit behavior.
No fixture/client/server/socket/certificate/candidate native execution or binary
--help, fulltests, stopped experiments, new native cancellation schedule/race/
fault/resource/leak/invalidfd/kernelerror/injectedcompletion/panic probes.
Legitimate advertised protocol-credit exhaustion is not kernel resource failure;
its future native run still needs independent review and Root precise permission.

Ruling on manifests: bind the COMPLETE CURRENT dependency closure (frozen custom
modules, production/override/client/zslay trees, current actual builds/receipts,
original binding/libs/compiler/interpreter/loader/TLS tools/helper). Preserve
prior proofs and their manifests/archives by identity; old unrelated test binaries
are historical evidence, not current runtime dependencies. Do not blindly inherit
the growing union of all previous input maps. Reviewers must verify no true
transitive input is omitted. This removes artificial history dependencies without
weakening any current source/binary/module or fixture assertion.

Use new/tmp source/cache/output/graph paths; compiler caches may be shared. Preserve
intermediate sources/failures/recipes/binaries/reports. No Root source edits or
new orphan product support roots. Record prior22proved IDs and remaining15 IDs
explicitly as data; unsupported selections fail. The eventual combined fixture
needs>=33records before metadata/>=34after it; do not silently reuse32history.
Only this isolated6record scope uses32. No combined-capacity change is authorized
or implied by this current preparation.

Work in bounded internal steps: first actual fixture+pureflowledger+Debug/RS
compile, with a concrete fixture contract; then driver/integration/freeze. Report
each completed step honestly and continue the next authorized bounded piece.
Write task-5b3-report.md (and scoped step reports if needed), exact commands/raw
results/paths/hashes/bounds/remaining gaps. Full StageA DONE requires the coherent
frozen review manifest plus both actual builds and integrated all3case driver.
Independent review precedes any later precise ordinary owned run. Full5b4/5c/
H3/multipart/physical/platform/quality/adoption/original milestones remain open.
