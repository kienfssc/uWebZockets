# Task5b3 owned native result

The three credit/trailer/concurrency cases plus idle shutdown pass on the host
executor. This is one completed ordinary protocol run after one separate
restricted-executor startup failure. Both attempts are preserved; no source,
backend, capacity or assertion was changed between them. No stopped experiment,
native fault injection or denied historical socket case was reconstructed.

Reviewed subject /tmp/uwz-task5b3-fix1-frozen-v2, manifest
952c497fb60c4af72f1d8024e142c20ad82c65a3d9ca2de91dc47cb628d00d94;
ReleaseSafe binary243c5582c0b79e438de70aabd09620bd336394b5ddb6e5fa4e08e341cb447001.
Root preflighted2438individual inputs/6trees/6static archives/two actual builds;
audit SHAed780f4336fac96314b0c937831f36c525fb8265354d806fd353504afc84e6ef
is identical after both attempts. Isolated AST refresh of14codefiles exits0,
164nodes/333edges/12communities, no API. Product/pins remain unchanged.

## Exact command and executor history

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5b3-fix1-frozen-v2/run_live.py --run --manifest /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/fix1/review-manifest-v2.json --manifest-sha256 952c497fb60c4af72f1d8024e142c20ad82c65a3d9ca2de91dc47cb628d00d94 --output /tmp/uwz-h2-credit-owned-2026-10-28-r2 --cases queued_trailers_padding receive_credit concurrent_routes shutdown_idle
```

Completed host invocation: require_escalated, tool approval granted;
execsession76549/finalchunkc61e26/exit0/empty output. Precise Root host release
fix1/stage-b-authorization-host.json SHA
d2517e5a3b530a2a9ee7797144a76923e7ea2e61e144fed7dee6d5e05b0cb8f0.

First command used identical code/arguments/environment except output r1 and
use_default executor; auth30eec4b8049cc7af1e368d21fd2b3fdf29ba73e171b400fb0ae427906b82a0a5,
session74627/finalchunkb1a80d/exit1. Child4 printed capacity then error.Unexpected
before readiness, exited1/reaped; no case completed, keyremoved, no cleanup
errors. Exact failing syscall is unproved. Current restricted tool process
metadata was NSpid3/NoNewPrivs1/Seccomp2/uidmap1000->0 length1. Read-only source
localizes the failure interval to listen/catch_shutdown_signals. Root records a
separate host-executor ruling, conditionally approved through the tool. This
is two startup attempts, not a zero-failure run history or an automatic retry.
No additional native execution is authorized by these records.

## Actual successful observations

- Four fresh TLS1.3/h2 connections, including idle; exact owned child368486,
  start1959706/listener/nonce/certificate checked by the reviewed driver.
- queued_trailers_padding:12289accepted/logical,12297flow,Hf84149bf46313d9f7da734e3d53f88b2d01a2c01c38bf422063c507b237915f4,
  BEC1/1/0,begin/end metadata checks1each. Two paused-seven barriers and<=15
  earlyrefund bounds pass; initial metadata survives conflicting discarded
  trailers. Maxofferedspan8192 is observed, not a callback-count oracle.
- receive_credit:65535legal queued bytes exhaust both scopes; sameconnection
  HEADERS/control barriers pass atzero credit/zero accepted. Genuine peer
  refunds65535 in both scopes precede the finalbyte/EOF.65536accepted,
  Hf1666d44e02004f92bd350d6c56825b1b9f882e5edcd9f25ed8d2dfe1e414bab,
  BEC1/1/0. Independent Root snapshot math confirms zero credit and finalbyte
  only after both real refunds; no window enlargement or manufactured credit.
- concurrent_routes: pausedquotaONE holder,503empty/no100/noadmission refusal
  with one ordered rawNO_ERROR reset; healthy other route admitted as second
  binding, completeswhileholderpaused; holderresume and same-route recovery
  complete. Three32-byte/H7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5
  successes,independent metadata intact,96logical/flow. Healthy resets forbidden.
- TotalsM6/A5/B5/E5/C0/F0,77921accepted/77929flow,active/errors0,all successful
  begin/end metadata checks1each. Final middleware header once on all six body
  responses.32persistent records,including26untouchedspares,and finalmetrics
  equal post-deinit. Bufferedmiddleware57 plusbodymiddleware6 account63heads.
- OwnedSIGTERMexit0/reaped/no force/errors; Root host read-only audit confirms
  exact PIDabsent and keyabsent. Serverlog12346B below65536. Publiccertificate
  DERfingerprint6050efbc9aad8cf507175c83c8a6d6c60b24b6fae47d4a5ab1a5ea301e559bbe.

Successful rawresult74113B SHA
5d3c43c938c7a48259600fcbabf192eb2a388d80517775d842c5429ef8adf575.
Independent Root result audit387bc5847729cec99a311a2707a69886dd68c8be0c60a096faca85fc693f844f
checks exact records/metrics/postlogs/payloadhashes/headers/reset distinction,
all flow snapshots and process/cert cleanup. Raw files are under stage-b;
startupfailure149cf2255bbaf218c2f72ccf1ee8e62b74289e16df80493557863fda6a20c0d5
and execution details remain under stage-b-attempt1. Raw stdout counters in the
idle-connection object omit an events field; no aggregate event-count claim is
inferred from that omission. Source completion/assertions remain explicit.

No full native/sanitizer/physical lifetime/platform/compliance/performance,
H3/multipart/genuine earlydata/adoption/original milestone claim.15further H2 IDs
and combinedmatrix remain. Supported subsets have source/pure evidence; only
this all-three selection has the new native result. Public report/archive and
independent publication review precede the Root commit/immediate fork push.
