# Task5b3 fix round1/5

Resume original worker /root/prepare_h2_credit_live. Read the original brief
and existing report, then both credit/review-{protocol,process}-v4.md reports.
Those are Root's scoped transcriptions; each retains the reviewer/source
identity and exact file/line/failure scenario. Root has read the actual reports,
actual frozen runner/freeze source, compile receipts and raw pure-check logs.
No native or live execution has occurred or is authorized.

Exact open finding text from process review:

1. **P1 — Documented clean launch always fails its environment guard.**
   `/tmp/uwz-task5b3-frozen-v4/run_live.py:499` requires `os.environ` to contain
   only `PYTHONPATH`. Root’s benign pinned-interpreter check confirmed that the
   documented `env -i … python3 -B -S` launch inserts `LC_CTYPE=C.UTF-8`. Every
   authorized case selection therefore fails before manifest validation or
   child creation. Explicitly pin and permit the locale environment, or
   otherwise control startup coercion consistently with the guard.
2. **P2 — The current dependency closure omits all six actual static link
   inputs.** `freeze.py:63` adds binaries and receipt files, but never adds
   their six `.a` inputs. Both actual compile recipes link `libuWebZockets.a`,
   `libssl.a`, `libcrypto.a`, `liblsquic.a`, `libdeflate.a`, and `libz.a`; none
   appears in manifest `inputs` or `trees`. Changing or removing one after
   compilation leaves `check_manifest()` satisfied because it checks the
   receipt’s bytes without checking the inputs named inside it. Add these
   actual build inputs using their recorded hashes and enforce their reviewed
   identities. The recorded archive hashes currently match the prior
   manifest; this finding concerns missing enforcement.

Protocol review independently raises the same archive omission as P1 and asks
to add inputs from actual receipts, validate current versus recorded hashes,
and retain them in manifest verification. Its exact evidence-gap statement:
`pure_sequences_checks.py:46` checks byte totals and records events, but never
asserts their order or arguments. The report’s claimed ordering proof therefore
exceeds that check’s assertions.

Own only new credit/fix1 evidence, new frozen /tmp subject, updated task5b3
reports and directly necessary test-only corrections. You are not alone; no
reverts of other work, subagents, refs/commit/push, downloads, external CLI or
product edits. Preserve ALL v1-v4 frozen sources/manifests/binaries/receipts/
bound inputs. Do not overwrite any file named in the reviewed v4 input map.
Use a new fix1 freeze recipe/checker and corrected source copies.

Address the two unique required findings:

1. Missing complete current build closure (protocol P1/process P2). Derive
   actual build inputs from BOTH current Debug/ReleaseSafe receipts and validate
   recorded before/after/current identities. Bind all direct actual compile
   dependencies, including all six original zig-out/lib archives, either in
   current inputs or correctly covered exact trees. Merge only these CURRENT
   builds, not historical unrelated test binaries. Preserve reviewed fc69/c223/
   client/helper/original bindings/six-library identities. Do not merely trust
   receipt JSON hashes. Reject inconsistent/missing receipt inputs. Add focused
   meaningful caller-data/map checks and actual final closure audit; do not
   mutate any shared archive/source to manufacture a failure.

2. Pinned clean launch refuses Python's locale coercion (process P1). Root's
   benign interpreter-only check (chunk ff9316, exit0) used documented env -i
   PYTHONPATH=<fixed package:helper> pinnedPython -B -S -c import os,sys and
   observed environment_keys=['LC_CTYPE','PYTHONPATH'], LC_CTYPE='C.UTF-8',
   utf8_mode=1. No candidate import, socket, child or TLS was involved.
   Pin LC_ALL=C.UTF-8 explicitly with the existing PYTHONPATH and make the
   launch guard require exactly those keys/values. Document exact invocation.
   A focused benign pinned-interpreter environment-only check is allowed;
   no candidate runner invocation, fixture/client/server/socket/certificate.
   Keep unbound loader/TLS environment rejection intact.

Also correct the confirmed evidence wording gap: pure_sequences_checks checks
logical/flow totals and records operations; it does not assert full ordering
or argument values. State its actual coverage rather than claim ordering proof.
All required live sequence assertions remain mandatory. Do not introduce fake
I/O/native results or redundant implementation-mirroring tests to manufacture
behavioral red. Preserve and accurately qualify the existing failed synthetic
unsupported-selection check.

Rerun checks covering amended source/manifest/guard, frozen AST, actual current
closure validation and existing focused frozen pure checks as needed. Profile
is unchanged, so both accepted actual binaries/compile receipts remain valid;
do not repeat unchanged compiles. No full/native/sanitizer/fault probes or
stopped experiments. Exact same three cases/six records/two sink slots/profile/
bounds and deadlines remain required.

Append fix report to task-5b3-report.md: exact amended paths, commands/raw
results, new manifest and source identities, old-input preservation, covering
checks, and explicit unrun native status. Return DONE only once coherent frozen
package is ready. Root will generate a v4-to-fix1 diff and request scoped
re-review from the same reviewers. Stage B remains separately gated.
