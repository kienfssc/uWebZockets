# Task5b3 round1 scoped fix diff
Reviewed base: frozen-v4, manifest67af47d54c4622d9c9ca822f00f1e10f2afbaf1debc7d69a1c5545a919ef8446. New subject: fix1-frozen-v2, manifest952c497fb60c4af72f1d8024e142c20ad82c65a3d9ca2de91dc47cb628d00d94. Root base/head5032406 unchanged.
--- /dev/null
+++ /tmp/uwz-task5b3-fix1-frozen-v2/build_closure.py
@@ -0,0 +1,39 @@
+"""Validate current direct build inputs using caller-provided receipt maps."""
+ARCHIVES = tuple('/workspaces/uWebZockets/zig-out/lib/' + name for name in (
+    'libuWebZockets.a', 'libssl.a', 'libcrypto.a', 'liblsquic.a', 'libdeflate.a', 'libz.a'))
+
+
+def argv_inputs(argv):
+    if not argv or not argv[0].startswith('/'):
+        raise ValueError('missing compiler')
+    modules = [arg.split('=', 1)[1] for arg in argv if arg.startswith('-M') and '=' in arg]
+    archives = [arg for arg in argv if arg.endswith('.a')]
+    if len(archives) != len(ARCHIVES) or set(archives) != set(ARCHIVES):
+        raise ValueError('archive list differs')
+    if len(modules) != 6 or len(set(modules)) != len(modules):
+        raise ValueError('module input list differs')
+    return set(modules + archives + [argv[0]])
+
+
+def validate_receipts(receipts, commands, current, approved_archives):
+    merged = {}
+    if len(receipts) != 2 or len(commands) != 2:
+        raise ValueError('both build receipts are required')
+    for receipt, command, mode in zip(receipts, commands, ('Debug', 'ReleaseSafe')):
+        before = receipt['input_sha256']
+        if receipt['optimization'] != mode or receipt['exit_status'] != 0 or not receipt['inputs_unchanged']:
+            raise ValueError('build receipt status differs')
+        if receipt['argv'] != command['argv'] or before != command['input_sha256']:
+            raise ValueError('build command receipt differs')
+        if set(before) != argv_inputs(receipt['argv']) or before != receipt['input_after']:
+            raise ValueError('build input map is incomplete or changed')
+        for path, value in before.items():
+            if current.get(path) != value or (path in merged and merged[path] != value):
+                raise ValueError('current or cross-build input differs: ' + path)
+            merged[path] = value
+    if set(approved_archives) != set(ARCHIVES):
+        raise ValueError('reviewed archive map is incomplete')
+    for path in ARCHIVES:
+        if merged[path] != approved_archives[path]:
+            raise ValueError('archive differs from reviewed identity: ' + path)
+    return merged
--- /dev/null
+++ /tmp/uwz-task5b3-fix1-frozen-v2/pure_closure_checks.py
@@ -0,0 +1,45 @@
+"""Exercise receipt-map validation without changing any actual build input."""
+import copy
+import build_closure as closure
+
+
+def rejected(label, receipts, commands, current, approved):
+    try:
+        closure.validate_receipts(receipts, commands, current, approved)
+    except (ValueError, KeyError):
+        print(label + ': rejected')
+        return
+    raise AssertionError(label + ': unexpectedly accepted')
+
+
+def main():
+    modules = ['/test/module' + str(i) for i in range(6)]
+    argv = ['/test/zig'] + ['-Mm' + str(i) + '=' + path for i, path in enumerate(modules)] + list(closure.ARCHIVES)
+    current = {path: 'hash-' + str(i) for i, path in enumerate(['/test/zig'] + modules + list(closure.ARCHIVES))}
+    approved = {path: current[path] for path in closure.ARCHIVES}
+    receipts = [{'argv': argv, 'input_sha256': current.copy(), 'input_after': current.copy(),
+                 'optimization': mode, 'exit_status': 0, 'inputs_unchanged': True} for mode in ('Debug', 'ReleaseSafe')]
+    commands = [{'argv': argv, 'input_sha256': current.copy()} for _ in receipts]
+    assert closure.validate_receipts(receipts, commands, current, approved) == current
+    print('both complete consistent input maps: accepted')
+    broken = current.copy()
+    broken[closure.ARCHIVES[0]] = 'changed'
+    rejected('current archive differs', receipts, commands, broken, approved)
+    broken = approved.copy()
+    broken.pop(closure.ARCHIVES[1])
+    rejected('reviewed archive missing', receipts, commands, current, broken)
+    broken_receipts = copy.deepcopy(receipts)
+    broken_receipts[1]['input_after'].pop(closure.ARCHIVES[2])
+    rejected('one build missing after input', broken_receipts, commands, current, approved)
+    broken_commands = copy.deepcopy(commands)
+    broken_commands[0]['input_sha256'].pop(closure.ARCHIVES[3])
+    rejected('command receipt missing input', receipts, broken_commands, current, approved)
+    broken_receipts = copy.deepcopy(receipts)
+    broken_receipts[0]['argv'] = argv[:-1]
+    broken_commands = copy.deepcopy(commands)
+    broken_commands[0]['argv'] = argv[:-1]
+    rejected('archive omitted from argv', broken_receipts, broken_commands, current, approved)
+
+
+if __name__ == '__main__':
+    main()
--- /tmp/uwz-task5b3-frozen-v4/run_live.py
+++ /tmp/uwz-task5b3-fix1-frozen-v2/run_live.py
@@ -489,21 +489,22 @@
 
 
 def main():
     parser = argparse.ArgumentParser()
     parser.add_argument('--run', action='store_true', required=True)
     parser.add_argument('--manifest', type=Path, required=True)
     parser.add_argument('--manifest-sha256', required=True)
     parser.add_argument('--output', required=True)
     parser.add_argument('--cases', nargs='+', choices=CASES, required=True)
     args = parser.parse_args()
-    require(set(os.environ) == {'PYTHONPATH'}, 'runner environment must contain only fixed PYTHONPATH')
+    require(dict(os.environ) == {'PYTHONPATH': PACKAGES + ':' + HELPER, 'LC_ALL': 'C.UTF-8'},
+            'runner environment must contain only the pinned locale and PYTHONPATH')
     require(sys.executable == PYTHON and sys.dont_write_bytecode and sys.flags.no_site and os.environ.get('PYTHONPATH') == PACKAGES + ':' + HELPER,
             'Python interpreter or PYTHONPATH differs')
     require(len(set(args.cases)) == len(args.cases) and ('shutdown_idle' not in args.cases or args.cases[-1] == 'shutdown_idle'), 'invalid case order')
     output = Path(args.output)
     require(output.is_absolute() and output.resolve().is_relative_to(Path('/tmp')) and output.resolve() != Path('/tmp'), 'output must be new /tmp path')
     require(not output.exists(), 'output already exists')
     manifest = check_manifest(args.manifest, args.manifest_sha256)
     run(args, manifest)
 
 
--- /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/freeze.py
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/fix1/freeze_fix1_v2.py
@@ -1,104 +1,109 @@
-"""Create a current-closure review manifest without executing candidate code."""
+"""Bind both actual build input maps and freeze only this fix's current closure."""
 import hashlib
 import json
 from pathlib import Path
 import shutil
+import build_closure
 
 HERE = Path(__file__).resolve().parent
-ROOT = Path('/workspaces/uWebZockets')
-FROZEN = Path('/tmp/uwz-task5b3-frozen-v4')
-PRIOR = ROOT / '.uwz-work/evidence/h2-streaming/integration-owned/admission/fix1/review-manifest.json'
+CREDIT = HERE.parent
+V4 = CREDIT / 'review-manifest-v4.json'
+ADMISSION = CREDIT.parent / 'admission/fix1/review-manifest.json'
+FROZEN = Path('/tmp/uwz-task5b3-fix1-frozen-v2')
+V4_ROOT = '/tmp/uwz-task5b3-frozen-v4'
 SOURCE_NAMES = ('profile.zig', 'prepare.py', 'run_live.py', 'cases.py', 'wire.py', 'raw_observer.py',
                 'flow_ledger.py', 'pure_flow_checks.py', 'pure_cases_checks.py', 'pure_sequences_checks.py',
-                'pure_codec_checks.py', 'pure_raw_checks.py', 'fixture-contract.md', 'coverage_inventory.json')
+                'pure_codec_checks.py', 'pure_raw_checks.py', 'fixture-contract.md', 'coverage_inventory.json',
+                'build_closure.py', 'pure_closure_checks.py')
 
 
 def digest(path):
     value = hashlib.sha256()
     with Path(path).open('rb') as source:
         while block := source.read(8192):
             value.update(block)
     return value.hexdigest()
 
 
 def inventory(root):
     return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file()}
 
 
 def main():
-    prior = json.loads(PRIOR.read_text())
-    tree_paths = ['/tmp/uwz-task4d-fix1-frozen', '/tmp/uwz-reviewed-libxev-c223-loop-callbacks',
-                  '/tmp/uwz-h2-client-tooling/packages',
-                  '/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy']
-    trees = {}
-    for name in tree_paths:
-        actual = inventory(Path(name))
-        if actual != prior['trees'][name]:
-            raise ValueError('current tree differs from prior reviewed identity: ' + name)
-        trees[name] = actual
-    zig_lib = '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/lib'
-    trees[zig_lib] = inventory(Path(zig_lib))
-    inputs = {}
-    fixed = ['/home/codespace/.python/current/bin/python3', '/opt/conda/bin/openssl', '/opt/conda/ssl/openssl.cnf',
-             '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig',
-             '/lib/x86_64-linux-gnu/libc.so.6', '/lib/x86_64-linux-gnu/libm.so.6',
-             '/lib/x86_64-linux-gnu/libpthread.so.0', '/lib/x86_64-linux-gnu/libdl.so.2',
-             '/lib/x86_64-linux-gnu/libcrypto.so.3', '/lib/x86_64-linux-gnu/libssl.so.3',
-             '/lib64/ld-linux-x86-64.so.2', '/opt/conda/lib/libcrypto.so.3', '/opt/conda/lib/libssl.so.3',
-             str(ROOT / '.uwz-work/evidence/h1-transport/r2/c-native.zig'),
-             str(ROOT / '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'),
-             str(ROOT / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json'),
-             str(ROOT / '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json')]
-    for path in fixed:
-        inputs[path] = digest(path)
-        if path in prior['inputs'] and inputs[path] != prior['inputs'][path]:
-            raise ValueError('reviewed input differs: ' + path)
-    python_lib = Path('/home/codespace/.python/current/lib/python3.14')
-    for path in sorted(python_lib.rglob('*')):
-        relative = path.relative_to(python_lib)
-        if any(part in ('site-packages', 'test', 'tests', 'idlelib', 'tkinter', 'venv', 'ensurepip') for part in relative.parts):
-            continue
-        if path.is_file() and path.suffix in ('.py', '.pyc', '.so', '.zip'):
-            inputs[str(path)] = digest(path)
+    if digest(V4) != '67af47d54c4622d9c9ca822f00f1e10f2afbaf1debc7d69a1c5545a919ef8446':
+        raise ValueError('v4 manifest identity differs')
+    v4 = json.loads(V4.read_text())
+    for root, expected in v4['trees'].items():
+        if inventory(Path(root)) != expected:
+            raise ValueError('v4 tree changed: ' + root)
+    for path, value in v4['inputs'].items():
+        if digest(path) != value:
+            raise ValueError('v4 input changed: ' + path)
+    if digest(ADMISSION) != v4['historical_manifest_sha256'][str(ADMISSION)]:
+        raise ValueError('prior reviewed manifest differs')
+    approved_inputs = json.loads(ADMISSION.read_text())['inputs']
+    approved_archives = {path: approved_inputs[path] for path in build_closure.ARCHIVES}
+    receipts, commands = [], []
     for mode in ('debug', 'release'):
         label = 'fixture-' + mode + '-v1'
-        record = json.loads((HERE / (label + '.json')).read_text())
+        receipts.append(json.loads((CREDIT / (label + '.json')).read_text()))
+        commands.append(json.loads((CREDIT / (label + '.command.json')).read_text()))
+    paths = set().union(*(build_closure.argv_inputs(receipt['argv']) for receipt in receipts))
+    current = {path: digest(path) for path in paths}
+    merged = build_closure.validate_receipts(receipts, commands, current, approved_archives)
+    for mode, record in zip(('debug', 'release'), receipts):
         binary = '/tmp/uwz-task5b3-' + mode + '/profile'
-        if record['exit_status'] != 0 or not record['inputs_unchanged'] or digest(binary) != record['binary_sha256']:
-            raise ValueError('build receipt or binary differs: ' + mode)
-        if record['fixture_after']['profile.zig'] != digest(HERE / 'profile.zig') or record['fixture_after']['prepare.py'] != digest(HERE / 'prepare.py'):
-            raise ValueError('compiled sources differ: ' + mode)
-        inputs[binary] = digest(binary)
-        for suffix in ('.json', '.command.json', '.log', '-source-inputs.json', '-source-after.json'):
-            path = HERE / (label + suffix)
-            inputs[str(path)] = digest(path)
+        if digest(binary) != record['binary_sha256']:
+            raise ValueError('build binary differs: ' + mode)
+    if digest(HERE / 'profile.zig') != merged[str(CREDIT / 'profile.zig')]:
+        raise ValueError('fixture source differs from compiled profile')
+    for record in receipts:
+        if record['fixture_before'] != record['fixture_after']:
+            raise ValueError('build fixture inputs changed')
+        for name, value in record['fixture_before'].items():
+            if digest(CREDIT / name) != value or digest(HERE / name) != value:
+                raise ValueError('actual compile recipe or fixture differs: ' + name)
     if FROZEN.exists():
-        raise ValueError('frozen destination already exists')
+        raise ValueError('frozen destination exists')
     FROZEN.mkdir(mode=0o700)
     for name in SOURCE_NAMES:
         shutil.copyfile(HERE / name, FROZEN / name)
+    trees = {root: files for root, files in v4['trees'].items() if root != V4_ROOT}
     trees[str(FROZEN)] = inventory(FROZEN)
+    inputs = {path: value for path, value in v4['inputs'].items()
+              if not path.startswith(V4_ROOT + '/') and not path.startswith(str(CREDIT) + '/')}
+    for mode in ('debug', 'release'):
+        label = 'fixture-' + mode + '-v1'
+        for suffix in ('.json', '.command.json', '.log', '-source-inputs.json', '-source-after.json'):
+            path = str(CREDIT / (label + suffix))
+            inputs[path] = v4['inputs'][path]
+    inputs.update(merged)
+    inputs[str(CREDIT / 'prepare.py')] = receipts[0]['fixture_before']['prepare.py']
     for name, value in trees[str(FROZEN)].items():
         inputs[str(FROZEN / name)] = value
-    for name in ('freeze.py', 'pure-flow-v2.log', 'pure-cases.log', 'pure-sequences.log', 'pure-sequences-v2.log', 'pure-sequences-v3.log', 'pure-codec.log', 'pure-raw.log', 'format.log', 'ast-v3.log'):
-        inputs[str(HERE / name)] = digest(HERE / name)
-    manifest = {'state': 'ready-for-independent-review', 'runner': str(FROZEN / 'run_live.py'),
-                'wire': str(FROZEN / 'wire.py'), 'raw': str(FROZEN / 'raw_observer.py'),
-                'cases': str(FROZEN / 'cases.py'), 'flow': str(FROZEN / 'flow_ledger.py'),
-                'helper': str(ROOT / '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'),
-                'binary': '/tmp/uwz-task5b3-release/profile', 'trees': trees,
-                'tree_counts': {name: len(files) for name, files in trees.items()}, 'inputs': inputs,
-                'historical_manifest_sha256': {str(PRIOR): digest(PRIOR)},
-                'scope': 'current dependency closure only; historical manifests preserved by identity, not runtime inputs'}
-    output = HERE / 'review-manifest-v4.json'
+    for name in ('freeze_fix1_v2.py', 'pure-closure.log', 'environment.log'):
+        path = HERE / name
+        inputs[str(path)] = digest(path)
+    manifest = dict(v4)
+    manifest.update(state='ready-for-independent-review', trees=trees,
+                    tree_counts={name: len(files) for name, files in trees.items()}, inputs=inputs,
+                    runner=str(FROZEN / 'run_live.py'), wire=str(FROZEN / 'wire.py'),
+                    raw=str(FROZEN / 'raw_observer.py'), cases=str(FROZEN / 'cases.py'),
+                    flow=str(FROZEN / 'flow_ledger.py'),
+                    historical_manifest_sha256={str(V4): digest(V4), str(ADMISSION): digest(ADMISSION)},
+                    build_input_receipts=['fixture-debug-v1.json', 'fixture-release-v1.json'],
+                    scope='current actual build inputs and runtime closure; v4 preserved by identity')
+    output = HERE / 'review-manifest-v2.json'
     if output.exists():
         raise ValueError('manifest already exists')
     output.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
-    print('current tree counts:', manifest['tree_counts'])
-    print('current individual inputs:', len(inputs))
-    print('frozen manifest SHA-256:', digest(output))
-    print('historical manifest SHA-256:', digest(PRIOR))
+    print('v4 trees and inputs: unchanged')
+    print('both receipts and commands: 13 current inputs match before, after and actual')
+    for path in build_closure.ARCHIVES:
+        print(path + ' ' + merged[path])
+    print('frozen files:', len(trees[str(FROZEN)]))
+    print('fix1 manifest SHA-256:', digest(output))
 
 
 if __name__ == '__main__':
     main()
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/fix1/audit_fix1_v2.py
@@ -0,0 +1,69 @@
+"""Read-only AST, build-closure, and reviewed-input preservation audit."""
+import ast
+import hashlib
+import json
+from pathlib import Path
+
+HERE = Path(__file__).resolve().parent
+CREDIT = HERE.parent
+ROOT = Path('/tmp/uwz-task5b3-fix1-frozen-v2')
+V4_ROOT = Path('/tmp/uwz-task5b3-frozen-v4')
+
+
+def digest(path):
+    value = hashlib.sha256()
+    with Path(path).open('rb') as source:
+        while block := source.read(8192):
+            value.update(block)
+    return value.hexdigest()
+
+
+def audit_manifest(path, expected_digest):
+    if digest(path) != expected_digest:
+        raise ValueError('manifest digest differs')
+    manifest = json.loads(path.read_text())
+    for root, files in manifest['trees'].items():
+        actual = {str(p.relative_to(root)) for p in Path(root).rglob('*') if p.is_file()}
+        if actual != set(files):
+            raise ValueError('tree membership differs: ' + root)
+        for name, value in files.items():
+            if digest(Path(root) / name) != value:
+                raise ValueError('tree content differs: ' + name)
+    for name, value in manifest['inputs'].items():
+        if digest(name) != value:
+            raise ValueError('input content differs: ' + name)
+    return manifest
+
+
+def main():
+    v4 = audit_manifest(CREDIT / 'review-manifest-v4.json', '67af47d54c4622d9c9ca822f00f1e10f2afbaf1debc7d69a1c5545a919ef8446')
+    manifest = audit_manifest(HERE / 'review-manifest-v2.json', '952c497fb60c4af72f1d8024e142c20ad82c65a3d9ca2de91dc47cb628d00d94')
+    for path in sorted(ROOT.glob('*.py')):
+        ast.parse(path.read_text(), filename=str(path))
+    print('frozen AST: all Python files accepted')
+    for mode in ('debug', 'release'):
+        record = json.loads((CREDIT / ('fixture-' + mode + '-v1.json')).read_text())
+        for path, before in record['input_sha256'].items():
+            if record['input_after'][path] != before or digest(path) != before or manifest['inputs'].get(path) != before:
+                raise ValueError('actual receipt input missing or changed: ' + path)
+    for mode in ('debug', 'release'):
+        record = json.loads((CREDIT / ('fixture-' + mode + '-v1.json')).read_text())
+        for name, value in record['fixture_before'].items():
+            if record['fixture_after'][name] != value or digest(CREDIT / name) != value or manifest['inputs'].get(str(CREDIT / name)) != value:
+                raise ValueError('fixture input missing or changed: ' + name)
+    print('both actual compile receipts: all 13 direct inputs and compile recipe bound and current')
+    for name, value in v4['trees'][str(V4_ROOT)].items():
+        if name != 'run_live.py' and digest(ROOT / name) != value:
+            raise ValueError('unrelated source changed: ' + name)
+    before = (V4_ROOT / 'run_live.py').read_text()
+    after = (ROOT / 'run_live.py').read_text()
+    old = "    require(set(os.environ) == {'PYTHONPATH'}, 'runner environment must contain only fixed PYTHONPATH')"
+    new = "    require(dict(os.environ) == {'PYTHONPATH': PACKAGES + ':' + HELPER, 'LC_ALL': 'C.UTF-8'},\n            'runner environment must contain only the pinned locale and PYTHONPATH')"
+    if before.count(old) != 1 or before.replace(old, new) != after:
+        raise ValueError('runner changes exceed pinned environment guard')
+    print('runner diff: only exact locale/environment guard')
+    print('v4 and fix1 manifests: all trees, input paths and hashes matched')
+
+
+if __name__ == '__main__':
+    main()

Report coverage correction: synthetic sequence checks verify logical/flow totals and record operations; they do not assert complete ordering or arguments. See task-5b3-report.md fix section for exact commands and raw log paths.
