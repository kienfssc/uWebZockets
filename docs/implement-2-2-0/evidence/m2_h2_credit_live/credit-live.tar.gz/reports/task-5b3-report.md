# Task 5b3 Stage A report

Stage A preparation is complete for independent review. No fixture binary, live runner, socket, certificate, server, or live client was executed. This is not native credit, trailer, concurrency, milestone, or full-matrix evidence. Root must separately authorize any later ordinary owned run. The isolated fixture retains six named and 26 spare records; the later combined fixture still requires at least 33 records before metadata and 34 afterwards.

The originally reviewed package was `/tmp/uwz-task5b3-frozen-v4`; its manifest is `.uwz-work/evidence/h2-streaming/integration-owned/credit/review-manifest-v4.json`, SHA-256 `67af47d54c4622d9c9ca822f00f1e10f2afbaf1debc7d69a1c5545a919ef8446`. Its inputs cover the exact custom source, both actual builds and receipts, fc69 production tree (1031 files), c223 override (93), pinned client (42), zslay (14), Zig library tree (19542), compiler, Python standard-library code and bytecode, loader, TLS tools and configuration, helper, original binding, but omitted the six static library inputs; fix1 below corrects that omission. Historical evidence is retained by identity and is not inherited as runtime dependencies. Independent reviewers must audit the closure and the driver before any live use. Superseded v1, v2 and v3 frozen sources/manifests remain intact; v3 reused the preceding connection for a selected shutdown_idle, corrected in v4.

The fixture has two reusable sink slots, independently stored expected begin/end metadata, 32 persistent results, cumulative seven-byte partial pause, and real headers-only middleware on `/upload` and `/limit`. The driver has a fresh owned TLS/H2 connection per selected case, public window ledger, batch-boundary public-counter comparisons, padded flow accounting, bounded raw-reset exception, and final 32 snapshots followed by metrics and owned shutdown. The original v4 runner required `env -i`, the fixed `PYTHONPATH`, and Python `-B -S`; its locale guard was defective and is corrected in fix1 below; the certificate tool has an explicit configuration environment. Selected case names and 22 prior proved IDs/15 remaining plan rows are retained in `credit/coverage_inventory.json`. The 15 rows include three paired-variant rows; all variants remain required.

## Actual compile-only commands

```
python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/credit/prepare.py --optimization Debug --output /tmp/uwz-task5b3-debug --cache-root /tmp/uwz-task5a-debug --record fixture-debug-v1
Exit status: 0
python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/credit/prepare.py --optimization ReleaseSafe --output /tmp/uwz-task5b3-release --cache-root /tmp/uwz-task5a-debug --record fixture-release-v1
Exit status: 0
```

Both raw compiler logs are empty; receipts and full argv/input before/after maps are in `credit/fixture-{debug,release}-v1*`. Both report unchanged inputs and fc69 source digest `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`. Compiled profile SHA-256 is `a370cb6c5a846ff0f628ebb7e76871f933cd5751249cfcb2d3a3898ebf3ef745`; Debug binary is `6ea92917fd043121dae52e2fa723a4a5eb53408e44e8600b308d6801d4490d15`, ReleaseSafe binary is `243c5582c0b79e438de70aabd09620bd336394b5ddb6e5fa4e08e341cb447001`. `zig fmt --check .uwz-work/evidence/h2-streaming/integration-owned/credit/profile.zig` exited 0 with empty output.

## Frozen pure checks

The five frozen checks were each invoked with `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5b3-frozen-v4/<name>.py`, where `<name>` is `pure_flow_checks`, `pure_cases_checks`, `pure_sequences_checks`, `pure_codec_checks`, or `pure_raw_checks`; each exited 0. Complete raw output is in `credit/frozen-v4-<name>.log`. Representative raw output:

```
zero-credit DATA: rejected
coalesced four peer WINDOW_UPDATE events: final public connection and minimum match; refunds 65535 each
public stream window is min(connection, derived stream), not standalone connection
padding consumes 4097 + 1 + 7 = 4105 flow bytes
incorrect public minimum: rejected
32 records, six selected: M6/A5/B5/E5/C0/F0, accepted 77921
P12289 and P32 match pinned expected SHA-256; H65536: f1666d44e02004f92bd350d6c56825b1b9f882e5edcd9f25ed8d2dfe1e414bab
queued_trailers_padding logical 12289 flow 12297 events 10
receive_credit logical 65536 flow 65536 events 19
concurrent_routes logical 96 flow 96 events 21
unsupported case: rejected
```

The sequence checks use synthetic caller observations to check logical and flow totals and record operations; they do not assert complete operation order or arguments. The flow check uses actual pinned in-memory h2 codec objects; generated peer WINDOW_UPDATE frames do not establish native server credit behavior. The first sequence check exited 1 because an unsupported case accessed the API before validating its name; `pure-sequences.log` preserves the traceback and the preceding source is `cases-before-sequence-fix.py`. The corrected check exits 0. Frozen Python AST and exact manifest/source/tree/input hashes were checked by the read-only recipe `credit/check_frozen_v4.py`, with output in `credit/frozen-v4-check.log`; raw result includes `frozen runner and current manifest: all bound paths and hashes matched`, exit 0.

## Historical identities

```
0f2ff0dfbe0a73866b12fe7cc858a0db82c0ea7a009eb2fe634089769131f9c0  core/fix1/review-manifest.json
ae6f618eacc5d640889354ca322c395b6c135c258b3aa00286b3e3b1c6480d8f  core/stage-b/result.json
ca20660a9356b4452bd4a4cede8d4ff4b4851e6ae49d41780d4c6c5d415ed86f  pause-control/fix1/review-manifest.json
6944b2f396279d8ffc7346f9b03cf0f1a1d82123d992e7c6527becc5cc6d63a8  pause-control/stage-b/result.json
b5553efdd08b8cc95f66eb03e00108614dd537811df50f32877010484785baef  admission/fix1/review-manifest.json
ba7fb2b177531e11802443dffb06b6f36301c8e2b99668bdec1282ecde3e4932  admission/stage-b/result.json
```

Paths above are relative to `.uwz-work/evidence/h2-streaming/integration-owned/`. None of these is a new runtime input. The independent review, native Stage B cases, 5b4, 5c, H3, multipart, platform, physical lifetime, sanitizer/full local matrix, adoption, and original milestone remain open. No full project gates were run under this Stage A authorization.

## Fix round 1: current build closure and locale guard

The review findings are corrected in `/tmp/uwz-task5b3-fix1-frozen-v2`; `.uwz-work/evidence/h2-streaming/integration-owned/credit/fix1/review-manifest-v2.json` has SHA-256 `952c497fb60c4af72f1d8024e142c20ad82c65a3d9ca2de91dc47cb628d00d94`. Its runner SHA-256 is `a69428257d582508dff18972c04ed4bdb22a124b1d12b3e2ede19857bf87d016`; its `build_closure.py` SHA-256 is `b67b37b2b0d7c3111980ad4c9f59fdafff26e4b7f35b0c6ba33737b357b5592c`. Source diff against reviewed v4 changes only the environment guard. Its manifest adds all direct inputs identified from both actual Debug and ReleaseSafe compile commands and receipts, including all six archives, and the actual compile recipe. Before, after, current and prior reviewed archive hashes agree. `credit/fix1/freeze-v2.log` contains the six full hashes. Old v1-v4 manifests, frozen sources, binaries and receipt-bound inputs were independently rehashed unchanged. The first fix1 freeze remains preserved as an intermediate; v2 also binds the original compile recipe.

The required future invocation, shown as a template and **not executed**, is:

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5b3-fix1-frozen-v2/run_live.py --run --manifest /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/fix1/review-manifest-v2.json --manifest-sha256 952c497fb60c4af72f1d8024e142c20ad82c65a3d9ca2de91dc47cb628d00d94 --output /tmp/NEW-PRIVATE-OUTPUT --cases queued_trailers_padding receive_credit concurrent_routes shutdown_idle
```

The pinned interpreter-only check used exactly `env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S -c 'import os,sys; print("environment:", dict(sorted(os.environ.items()))); print("utf8_mode:", sys.flags.utf8_mode)'`. It exited 0 and printed:

```
environment: {'LC_ALL': 'C.UTF-8', 'PYTHONPATH': '/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'}
utf8_mode: 0
```

`python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/credit/fix1/audit_fix1_v2.py` exited 0; its raw `audit-v2.log` says:

```
frozen AST: all Python files accepted
both actual compile receipts: all 13 direct inputs and compile recipe bound and current
runner diff: only exact locale/environment guard
v4 and fix1 manifests: all trees, input paths and hashes matched
```

The frozen six pure checks were invoked using `PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5b3-fix1-frozen-v2/<name>.py`, for the five prior names and `pure_closure_checks`; each exited 0. Raw `frozen-v2-pure_closure_checks.log`:

```
both complete consistent input maps: accepted
current archive differs: rejected
reviewed archive missing: rejected
one build missing after input: rejected
command receipt missing input: rejected
archive omitted from argv: rejected
```

Those rejections use caller-owned synthetic maps; no actual build input was modified. The unchanged fixture was not recompiled. No candidate runner, native fixture, live client, socket, certificate, or server was executed. The six checks do not prove native case ordering or behavior. Scoped independent re-review and separate Root authorization for Stage B remain required.
