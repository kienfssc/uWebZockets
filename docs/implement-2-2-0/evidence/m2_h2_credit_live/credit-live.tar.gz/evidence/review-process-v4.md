SPEC COMPLIANCE: REQUEST CHANGES.
TASK QUALITY: REQUEST CHANGES. Stage A only, not native qualification.

P1 — Documented clean launch always fails its environment guard.
Frozen run_live.py:499 requires only PYTHONPATH in os.environ. Root's benign
pinned-interpreter command confirms env -i ... python3 -B -S inserts
LC_CTYPE=C.UTF-8. All documented selections fail before manifest validation or
child creation. Explicitly pin and permit locale, or control startup coercion
consistently with the guard.

P2 — Current dependency closure omits all six actual static link inputs.
freeze.py:63 adds binaries/receipts without their six .a inputs. Actual recipes
link libuWebZockets.a/libssl.a/libcrypto.a/liblsquic.a/libdeflate.a/libz.a;
none appears in manifest inputs/trees. Changing/removing one leaves
check_manifest satisfied: receipt bytes are checked, not named inputs. Bind
actual build inputs with recorded hashes and reviewed identities. Archive
hashes currently match prior manifest; enforcement is missing.

Strengths: inert imports/bound custom modules; fresh case connections including
idle; independent cleanup and forced-cleanup failure; final32 snapshots then
metrics and exact post-deinit comparison. No additional structural defect.

Gap: sequence checks assert totals/record operations, not complete order or
arguments. Native TLS ownership, credit, trailer retention, concurrency and
shutdown remain unproved. No native execution or repeated tests.

Source: final report /root/review_h2_credit_process, frozen-v4 initial review.
