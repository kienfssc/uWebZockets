"""Pinned codec and pure ledger checks; no sockets or native executable."""
import h2.config
import h2.connection
import h2.events
import h2.settings
import flow_ledger as flow


def pair():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False))
    client.initiate_connection()
    server.initiate_connection()
    server.receive_data(client.data_to_send())
    client.receive_data(server.data_to_send())
    client.send_headers(1, [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/')])
    server.receive_data(client.data_to_send())
    return client, server


def main():
    client, server = pair()
    ledger = flow.FlowLedger()
    flow.open_stream(ledger, 1)
    flow.check_public(ledger, client.outbound_flow_control_window, {1: client.local_flow_control_window(1)})
    for amount in (8192, 8192, 8192, 8192, 8192, 8192, 8192, 8191):
        flow.send_data(ledger, 1, amount, None, client.max_outbound_frame_size)
        client.send_data(1, b'x' * amount)
        server.receive_data(client.data_to_send())
    flow.check_public(ledger, client.outbound_flow_control_window, {1: client.local_flow_control_window(1)})
    assert ledger.connection == ledger.streams[1].window == 0
    try:
        flow.send_data(ledger, 1, 1, None, client.max_outbound_frame_size)
    except ValueError:
        print('zero-credit DATA: rejected')
    else:
        raise AssertionError('zero-credit DATA accepted')
    for delta in (30000, 35535):
        server.increment_flow_control_window(delta)
        server.increment_flow_control_window(delta, stream_id=1)
    events = client.receive_data(server.data_to_send())
    updates = [(e.stream_id, e.delta) for e in events if isinstance(e, h2.events.WindowUpdated)]
    assert len(updates) == 4
    flow.receive_batch(ledger, updates)
    flow.check_public(ledger, client.outbound_flow_control_window, {1: client.local_flow_control_window(1)})
    assert ledger.refunded == ledger.streams[1].refunded == 65535
    print('coalesced four peer WINDOW_UPDATE events: final public connection and minimum match; refunds 65535 each')
    flow.send_data(ledger, 1, 1, None, client.max_outbound_frame_size, finished=True)
    client.send_data(1, b'x', end_stream=True)
    assert ledger.sent == 65536
    distinct = flow.FlowLedger()
    flow.open_stream(distinct, 1)
    flow.open_stream(distinct, 3)
    flow.send_data(distinct, 1, 20, None, 8192)
    flow.receive_batch(distinct, [(0, 20)])
    flow.check_public(distinct, 65535, {1: 65515, 3: 65535})
    print('public stream window is min(connection, derived stream), not standalone connection')
    padded = flow.FlowLedger()
    flow.open_stream(padded, 1)
    assert flow.send_data(padded, 1, 4097, 7, 8192) == 4105
    assert padded.sent == 4105
    print('padding consumes 4097 + 1 + 7 = 4105 flow bytes')
    try:
        flow.check_public(padded, padded.connection, {1: padded.streams[1].window + 1})
    except ValueError:
        print('incorrect public minimum: rejected')
    else:
        raise AssertionError('incorrect minimum accepted')


if __name__ == '__main__':
    main()
