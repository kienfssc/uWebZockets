"""Read-only AST, build-closure, and reviewed-input preservation audit."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
CREDIT = HERE.parent
ROOT = Path('/tmp/uwz-task5b3-fix1-frozen')
V4_ROOT = Path('/tmp/uwz-task5b3-frozen-v4')


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as source:
        while block := source.read(8192):
            value.update(block)
    return value.hexdigest()


def audit_manifest(path, expected_digest):
    if digest(path) != expected_digest:
        raise ValueError('manifest digest differs')
    manifest = json.loads(path.read_text())
    for root, files in manifest['trees'].items():
        actual = {str(p.relative_to(root)) for p in Path(root).rglob('*') if p.is_file()}
        if actual != set(files):
            raise ValueError('tree membership differs: ' + root)
        for name, value in files.items():
            if digest(Path(root) / name) != value:
                raise ValueError('tree content differs: ' + name)
    for name, value in manifest['inputs'].items():
        if digest(name) != value:
            raise ValueError('input content differs: ' + name)
    return manifest


def main():
    v4 = audit_manifest(CREDIT / 'review-manifest-v4.json', '67af47d54c4622d9c9ca822f00f1e10f2afbaf1debc7d69a1c5545a919ef8446')
    manifest = audit_manifest(HERE / 'review-manifest.json', '8d7f53ad2dd982f968b8b958c8096e1348653e1f1bc9dec4e9faab3939d69498')
    for path in sorted(ROOT.glob('*.py')):
        ast.parse(path.read_text(), filename=str(path))
    print('frozen AST: all Python files accepted')
    for mode in ('debug', 'release'):
        record = json.loads((CREDIT / ('fixture-' + mode + '-v1.json')).read_text())
        for path, before in record['input_sha256'].items():
            if record['input_after'][path] != before or digest(path) != before or manifest['inputs'].get(path) != before:
                raise ValueError('actual receipt input missing or changed: ' + path)
    print('both actual compile receipts: all 13 direct input hashes bound and current')
    for name, value in v4['trees'][str(V4_ROOT)].items():
        if name != 'run_live.py' and digest(ROOT / name) != value:
            raise ValueError('unrelated source changed: ' + name)
    before = (V4_ROOT / 'run_live.py').read_text()
    after = (ROOT / 'run_live.py').read_text()
    old = "    require(set(os.environ) == {'PYTHONPATH'}, 'runner environment must contain only fixed PYTHONPATH')"
    new = "    require(dict(os.environ) == {'PYTHONPATH': PACKAGES + ':' + HELPER, 'LC_ALL': 'C.UTF-8'},\n            'runner environment must contain only the pinned locale and PYTHONPATH')"
    if before.count(old) != 1 or before.replace(old, new) != after:
        raise ValueError('runner changes exceed pinned environment guard')
    print('runner diff: only exact locale/environment guard')
    print('v4 and fix1 manifests: all trees, input paths and hashes matched')


if __name__ == '__main__':
    main()
