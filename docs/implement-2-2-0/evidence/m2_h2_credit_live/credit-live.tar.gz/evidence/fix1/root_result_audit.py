"""Audit retained results without invoking the fixture or client."""
import hashlib
import json
from pathlib import Path
import ssl


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit_flow(connection):
    sent = refunded = 0
    stream_sent = {}
    stream_refunded = {}
    logical = 0
    zero_observed = False
    final_credit_byte = False
    for snapshot in connection['snapshots']:
        if 'send_stream' in snapshot:
            stream = snapshot['send_stream']
            payload = snapshot['logical']
            padding = snapshot['padding']
            cost = payload + (padding + 1 if padding is not None else 0)
            assert 0 <= cost <= 8192 + 256
            if connection['case'] == 'receive_credit' and payload == 1:
                assert sent == 65535 and refunded == 65535
                assert stream_refunded.get(stream, 0) == 65535
                final_credit_byte = True
            assert cost <= 65535 + refunded - sent
            assert cost <= 65535 + stream_refunded.get(stream, 0) - stream_sent.get(stream, 0)
            sent += cost
            logical += payload
            stream_sent[stream] = stream_sent.get(stream, 0) + cost
            assert snapshot['sent'] == sent
            assert snapshot['stream'] == 65535 + stream_refunded.get(stream, 0) - stream_sent[stream]
        else:
            for stream, increment in snapshot['updates']:
                assert increment > 0
                if stream == 0:
                    refunded += increment
                else:
                    stream_refunded[stream] = stream_refunded.get(stream, 0) + increment
                    assert stream_refunded[stream] <= stream_sent.get(stream, 0)
            assert snapshot['sent'] == sent and snapshot['refunded'] == refunded
            for name, window in snapshot['windows'].items():
                stream = int(name)
                expected = min(65535 + refunded - sent,
                               65535 + stream_refunded.get(stream, 0) - stream_sent.get(stream, 0))
                assert window == expected
            if connection['case'] == 'receive_credit' and snapshot['connection'] == 0:
                assert sent == 65535 and refunded == 0
                assert snapshot['windows'] and set(snapshot['windows'].values()) == {0}
                zero_observed = True
        assert snapshot['connection'] == 65535 + refunded - sent
        assert 0 <= snapshot['connection'] <= 65535 and refunded <= sent
    expected = {'queued_trailers_padding': (12289, 12297), 'receive_credit': (65536, 65536),
                'concurrent_routes': (96, 96), 'shutdown_idle': (0, 0)}[connection['case']]
    assert (logical, sent) == expected
    if connection['case'] == 'receive_credit':
        assert zero_observed and final_credit_byte
    return {'case': connection['case'], 'logical': logical, 'flow': sent,
            'connection_refunded_observed': refunded, 'zero_credit_observed': zero_observed,
            'final_byte_after_peer_refunds': final_credit_byte}


def main():
    run = Path('/tmp/uwz-h2-credit-owned-2026-10-28-r2')
    evidence = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit')
    result = json.loads((run / 'result.json').read_text())
    assert result['success'] and result['error'] is None
    assert list(result['cases']) == ['queued_trailers_padding', 'receive_credit', 'concurrent_routes', 'shutdown_idle']
    assert result['cleanup'] == {'signal': 'SIGTERM', 'exit_code': 0, 'reaped': True, 'forced': False, 'errors': []}
    assert not (run / 'private-key.pem').exists()
    assert not Path('/proc', str(result['child']['pid'])).exists(), 'owned host PID still present'
    records = result['final_status']
    assert len(records) == 32
    expected_counts = {'queued_trailers_padding': (12289, 'f84149bf46313d9f7da734e3d53f88b2d01a2c01c38bf422063c507b237915f4'),
                       'receive_credit': (65536, 'f1666d44e02004f92bd350d6c56825b1b9f882e5edcd9f25ed8d2dfe1e414bab'),
                       'concurrent_hold': (32, '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5'),
                       'concurrent_upload': (32, '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5'),
                       'concurrent_recovery': (32, '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5')}
    empty_sha = hashlib.sha256(b'').hexdigest()
    for tag, record in records.items():
        assert not record['active'] and not record['paused'] and record['reason'] == 'none'
        assert record['cancel'] == record['failure'] == record['errors'] == 0
        if tag in expected_counts:
            count, sha = expected_counts[tag]
            assert record['accepted'] == count and record['sha256'] == sha
            assert record['middleware'] == record['attempts'] == record['begin'] == record['end'] == 1
            assert record['metadata_begin'] == record['metadata_end'] == 1
            assert 0 < record['max_span'] <= 8192
            continue
        assert record['accepted'] == record['attempts'] == record['begin'] == record['end'] == 0
        assert record['chunks'] == record['max_span'] == record['metadata_begin'] == record['metadata_end'] == 0
        assert record['sha256'] == empty_sha
        assert record['middleware'] == int(tag == 'concurrent_refused')
    expected_totals = {'middleware': 6, 'attempts': 5, 'begin': 5, 'end': 5, 'cancel': 0,
                       'failure': 0, 'accepted': 77921, 'active': 0, 'errors': 0,
                       'buffered_middleware': 57, 'slot0_active': False, 'slot1_active': False}
    assert result['final_metrics'] == expected_totals
    text = (run / 'server.log').read_text()
    nonce = result['nonce']
    post = {}
    post_totals = []
    for line in text.splitlines():
        marker = 'H2_RECORD ' + nonce + ' '
        if marker in line:
            record = json.loads(line.split(marker, 1)[1])
            assert record['tag'] not in post
            post[record['tag']] = record
        marker = 'H2_DEINIT ' + nonce + ' '
        if marker in line:
            post_totals.append(json.loads(line.split(marker, 1)[1]))
    assert post == records and post_totals == [expected_totals]
    assert text.count('H2_READY ' + nonce) == 1
    assert (run / 'server.log').stat().st_size <= 65536
    fingerprint = hashlib.sha256(ssl.PEM_cert_to_DER_cert((run / 'certificate.pem').read_text())).hexdigest()
    assert fingerprint == result['certificate_sha256']
    assert len(result['connections']) == 4
    flows = []
    for connection in result['connections']:
        assert connection['tls'] == 'TLSv1.3' and connection['alpn'] == 'h2'
        flows.append(audit_flow(connection))
    refused = result['cases']['concurrent_routes'][0]
    assert refused['tag'] == 'concurrent_refused'
    response = refused['response']
    assert response['bytes'] == response['informationals'] == 0 and response['body'] == ''
    assert response['raw_reset'] and response['reset_event']
    assert response['headers'].count([':status', '503']) == response['headers'].count(['x-middleware', 'retained']) == 1
    for case in result['cases'].values():
        if not isinstance(case, list):
            continue
        for item in case:
            if item['tag'] == 'concurrent_refused':
                continue
            response = item['response']
            assert response['informationals'] == 0 and not response['raw_reset'] and not response['reset_event']
            assert response['headers'].count([':status', '200']) == response['headers'].count(['x-middleware', 'retained']) == 1
            assert json.loads(response['body']) == records[item['tag']]
    audit = {'checks_passed': True, 'source_digest': 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de',
             'binary_sha256': result['child']['binary_sha256'], 'cases_passed': list(result['cases']),
             'totals': expected_totals, 'flow_checks': flows, 'logical_total': 77921, 'flow_total': 77929,
             'post_deinit_records_match': 32, 'post_deinit_metrics_match': True,
             'child_exit_zero_reaped': True, 'host_pid_absent': True, 'key_absent': True,
             'certificate_fingerprint_match': True, 'server_log_bytes': (run / 'server.log').stat().st_size,
             'result_sha256': digest(run / 'result.json'), 'startup_attempts': 2,
             'prior_pre_ready_failure_preserved': True, 'completed_protocol_runs': 1,
             'scope': 'Owned ordinary protocol result only; no full quality/platform/milestone or adoption claim.'}
    output = evidence / 'stage-b/root-result-audit.json'
    output.write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps({'checks_passed': True, 'audit_sha256': digest(output), 'logical': 77921, 'flow': 77929,
                      'records_equal_through_deinit': 32, 'startup_attempts': 2}))


if __name__ == '__main__':
    main()
