"""Exercise raw frame order using the pinned hyperframe encoder, without sockets."""
from hyperframe.frame import HeadersFrame, RstStreamFrame
import raw_observer as observer


def frame_headers(stream):
    frame = HeadersFrame(stream)
    frame.flags.add('END_STREAM')
    frame.flags.add('END_HEADERS')
    frame.data = b'\x88'
    return frame.serialize()


def reset(stream, code=0):
    frame = RstStreamFrame(stream)
    frame.error_code = code
    return frame.serialize()


def rejects(name, data, expect_reset=True):
    state = observer.new_state()
    observer.register(state, 1, expect_reset)
    try:
        observer.observe(state, data)
    except ValueError as error:
        print(name + ': rejected: ' + str(error))
        return
    raise AssertionError(name + ': unexpectedly accepted')


def main():
    state = observer.new_state()
    observer.register(state, 1, True)
    data = frame_headers(1) + reset(1)
    for byte in data:
        observer.observe(state, bytes([byte]))
    observer.retire(state, 1)
    print('split final and NO_ERROR reset: accepted')
    rejects('early', reset(1))
    rejects('duplicate', frame_headers(1) + reset(1) + reset(1))
    rejects('wrong code', frame_headers(1) + reset(1, 2))
    rejects('wrong stream', frame_headers(1) + reset(3))
    rejects('healthy', frame_headers(1) + reset(1), False)
    try:
        observer.observe(state, reset(1))
    except ValueError as error:
        print('retired exception: rejected: ' + str(error))
    else:
        raise AssertionError('retired exception accepted')


if __name__ == '__main__':
    main()
