"""Exercise response decoding with pinned h2, without sockets."""
import h2.config
import h2.connection
import raw_observer
import wire


def pair():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    client.initiate_connection()
    server.initiate_connection()
    server.receive_data(client.data_to_send())
    client.receive_data(server.data_to_send())
    client.send_headers(1, [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/')])
    server.receive_data(client.data_to_send())
    return client, server


def scenario(status, informational, expected_status, expected_info, middleware=True):
    client, server = pair()
    records, trace, raw = {}, {}, raw_observer.new_state()
    wire.register(records, raw, 1, 0, expected_status, expected_info, False)
    if informational:
        server.send_headers(1, [(':status', informational)])
    headers = [(':status', status)]
    if middleware:
        headers.append(('x-middleware', 'retained'))
    server.send_headers(1, headers, end_stream=True)
    data = server.data_to_send()
    for offset in range(0, len(data), 3):
        wire.accept(client, data[offset:offset + 3], records, raw, trace)
    wire.complete(records, raw, 1)


def rejected(name, **kwargs):
    try:
        scenario(**kwargs)
    except ValueError as error:
        print(name + ': rejected: ' + str(error))
        return
    raise AssertionError(name + ': unexpectedly accepted')


def main():
    scenario('200', '100', '200', 1)
    print('split informational and final: accepted')
    rejected('wrong final', status='413', informational=None, expected_status='200', expected_info=0)
    rejected('unexpected informational', status='200', informational='100', expected_status='200', expected_info=0)
    rejected('missing informational', status='200', informational=None, expected_status='200', expected_info=1)
    rejected('missing middleware', status='200', informational=None, expected_status='200', expected_info=0, middleware=False)


if __name__ == '__main__':
    main()
