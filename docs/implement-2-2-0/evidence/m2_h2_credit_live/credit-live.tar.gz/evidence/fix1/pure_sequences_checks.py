"""Check case ordering and bounds with caller-owned synthetic observations."""
import cases


def scenario(case):
    state = {'records': {}, 'next': 1, 'sent': 0, 'flow': 0, 'events': []}
    def start(route, tag, length, query, headers, status=200, reset=False):
        stream = state['next']
        state['next'] += 2
        state['records'][stream] = {'tag': tag, 'accepted': 0, 'paused': tag in ('receive_credit', 'concurrent_hold'), 'held': 0}
        state['events'].append(('start', route, tag, length, query, tuple(headers), status, reset))
        return stream
    def send(stream, total, offset, count, end, padding=None):
        assert count <= 8192
        state['sent'] += count
        state['flow'] += count + (padding + 1 if padding is not None else 0)
        item = state['records'][stream]
        if item['tag'] == 'queued_trailers_padding' and offset == 0:
            item['accepted'] = 7
            item['paused'] = True
        elif item['paused']:
            item['held'] += count
        else:
            item['accepted'] += count
        state['events'].append(('send', item['tag'], offset, count, end, padding))
    def status(tag):
        item = next(item for item in state['records'].values() if item['tag'] == tag)
        return {'accepted': item['accepted'], 'paused': item['paused'], 'begin': 1, 'end': 0, 'cancel': 0, 'chunks': 0}
    def resume(tag):
        item = next(item for item in state['records'].values() if item['tag'] == tag)
        item['paused'] = False
        item['accepted'] += item['held']
        state['events'].append(('resume', tag))
    def mark(name):
        def action(*args):
            state['events'].append((name,) + args)
        return action
    api = {'start': start, 'send': send, 'status': status, 'resume': resume,
           'finish': lambda stream, keep=False: state['events'].append(('finish', state['records'][stream]['tag'], keep)),
           'trailers': mark('trailers'), 'pending': mark('pending'), 'refund_bound': mark('refund_bound'),
           'initial_credit': mark('initial_credit'), 'zero_credit': mark('zero_credit'),
           'settled_credit': mark('settled_credit'), 'active': mark('active'), 'health': mark('health'), 'retire': mark('retire')}
    cases.execute(api, case)
    return state


def main():
    expectations = {'queued_trailers_padding': (12289, 12297), 'receive_credit': (65536, 65536), 'concurrent_routes': (96, 96)}
    for case, counts in expectations.items():
        result = scenario(case)
        assert (result['sent'], result['flow']) == counts
        print(case, 'logical', result['sent'], 'flow', result['flow'], 'events', len(result['events']))
    try:
        cases.execute({}, 'unsupported')
    except ValueError:
        print('unsupported case: rejected')
    else:
        raise AssertionError('unsupported case accepted')


if __name__ == '__main__':
    main()
