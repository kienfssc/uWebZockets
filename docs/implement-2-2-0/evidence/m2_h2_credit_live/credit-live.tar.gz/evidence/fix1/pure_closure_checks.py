"""Exercise receipt-map validation without changing any actual build input."""
import copy
import build_closure as closure


def rejected(label, receipts, commands, current, approved):
    try:
        closure.validate_receipts(receipts, commands, current, approved)
    except (ValueError, KeyError):
        print(label + ': rejected')
        return
    raise AssertionError(label + ': unexpectedly accepted')


def main():
    modules = ['/test/module' + str(i) for i in range(6)]
    argv = ['/test/zig'] + ['-Mm' + str(i) + '=' + path for i, path in enumerate(modules)] + list(closure.ARCHIVES)
    current = {path: 'hash-' + str(i) for i, path in enumerate(['/test/zig'] + modules + list(closure.ARCHIVES))}
    approved = {path: current[path] for path in closure.ARCHIVES}
    receipts = [{'argv': argv, 'input_sha256': current.copy(), 'input_after': current.copy(),
                 'optimization': mode, 'exit_status': 0, 'inputs_unchanged': True} for mode in ('Debug', 'ReleaseSafe')]
    commands = [{'argv': argv, 'input_sha256': current.copy()} for _ in receipts]
    assert closure.validate_receipts(receipts, commands, current, approved) == current
    print('both complete consistent input maps: accepted')
    broken = current.copy()
    broken[closure.ARCHIVES[0]] = 'changed'
    rejected('current archive differs', receipts, commands, broken, approved)
    broken = approved.copy()
    broken.pop(closure.ARCHIVES[1])
    rejected('reviewed archive missing', receipts, commands, current, broken)
    broken_receipts = copy.deepcopy(receipts)
    broken_receipts[1]['input_after'].pop(closure.ARCHIVES[2])
    rejected('one build missing after input', broken_receipts, commands, current, approved)
    broken_commands = copy.deepcopy(commands)
    broken_commands[0]['input_sha256'].pop(closure.ARCHIVES[3])
    rejected('command receipt missing input', receipts, broken_commands, current, approved)
    broken_receipts = copy.deepcopy(receipts)
    broken_receipts[0]['argv'] = argv[:-1]
    broken_commands = copy.deepcopy(commands)
    broken_commands[0]['argv'] = argv[:-1]
    rejected('archive omitted from argv', broken_receipts, broken_commands, current, approved)


if __name__ == '__main__':
    main()
