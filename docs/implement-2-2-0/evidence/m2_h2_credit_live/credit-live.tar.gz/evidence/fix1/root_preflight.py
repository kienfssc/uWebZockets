"""Read-only identity audit of the exact reviewed fixture inputs."""
import hashlib
import json
from pathlib import Path


def sha256(path):
    value = hashlib.sha256()
    with path.open('rb') as source:
        while block := source.read(65536):
            value.update(block)
    return value.hexdigest()


def covered(manifest, name, expected):
    if manifest['inputs'].get(name) == expected:
        return True
    path = Path(name)
    for root, files in manifest['trees'].items():
        if path.is_relative_to(root):
            return files.get(path.relative_to(root).as_posix()) == expected
    return False


def main():
    evidence = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit')
    manifest_path = evidence / 'fix1/review-manifest-v2.json'
    manifest_sha = sha256(manifest_path)
    assert manifest_sha == '952c497fb60c4af72f1d8024e142c20ad82c65a3d9ca2de91dc47cb628d00d94'
    manifest = json.loads(manifest_path.read_text())
    for name, expected in manifest['inputs'].items():
        assert sha256(Path(name)) == expected, name
    trees = []
    for root, files in manifest['trees'].items():
        paths = sorted(p for p in Path(root).rglob('*') if p.is_file())
        actual = {p.relative_to(root).as_posix(): sha256(p) for p in paths}
        assert actual == files, root
        assert len(actual) == manifest['tree_counts'][root], root
        trees.append({'path': root, 'files': len(actual)})
    builds = []
    libraries = {}
    for mode in ('debug', 'release'):
        receipt_path = evidence / ('fixture-' + mode + '-v1.json')
        receipt = json.loads(receipt_path.read_text())
        assert receipt['exit_status'] == 0 and receipt['inputs_unchanged']
        assert receipt['input_sha256'] == receipt['input_after']
        for name, expected in receipt['input_sha256'].items():
            assert covered(manifest, name, expected), name
            assert sha256(Path(name)) == expected, name
            if name.endswith('.a'):
                libraries[name] = expected
        profile_hash = sha256(Path(manifest['runner']).parent / 'profile.zig')
        assert profile_hash == receipt['fixture_before']['profile.zig']
        assert receipt['fixture_before'] == receipt['fixture_after']
        assert receipt['source_tree_sha256'] == receipt['source_after_sha256']
        assert receipt['source_after_sha256'] == 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de'
        binary = Path(next(a.split('=', 1)[1] for a in receipt['argv'] if a.startswith('-femit-bin=')))
        assert sha256(binary) == receipt['binary_sha256']
        assert covered(manifest, str(binary), receipt['binary_sha256'])
        assert covered(manifest, str(receipt_path), sha256(receipt_path))
        assert (evidence / ('fixture-' + mode + '-v1.log')).stat().st_size == 0
        builds.append({'mode': receipt['optimization'], 'binary': str(binary),
                       'binary_sha256': receipt['binary_sha256'],
                       'direct_inputs': len(receipt['input_sha256'])})
    assert len(libraries) == 6
    assert sha256(manifest_path) == manifest_sha
    result = {'checks_passed': True, 'manifest_sha256': manifest_sha,
              'inputs_checked': len(manifest['inputs']), 'trees_checked': trees,
              'builds': builds, 'libraries_checked': len(libraries),
              'profile_sha256': profile_hash,
              'source_digest': 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de',
              'source_files': 1031, 'native_execution': False}
    output = evidence / 'fix1/root-preflight.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'checks_passed': True, 'inputs': result['inputs_checked'],
                      'trees': len(trees), 'libraries': len(libraries),
                      'audit_sha256': sha256(output)}))


if __name__ == '__main__':
    main()
