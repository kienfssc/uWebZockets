"""Independent bounded payload and selection expectations, without network I/O."""
import hashlib
import h2_client
import cases


def digest(length):
    state = hashlib.sha256()
    for offset in range(0, length, 8192):
        state.update(h2_client.payload_block(length, offset, min(8192, length - offset)))
    return state.hexdigest()


def main():
    empty = hashlib.sha256(b'').hexdigest()
    credit = digest(65536)
    assert digest(12289) == cases.HASHES['queued_trailers_padding']
    assert digest(32) == cases.HASHES['concurrent_hold']
    selected = cases.selected_tags(cases.CASES)
    records = [cases.expected(tag, selected, empty, credit) for tag in cases.TAGS]
    assert len(records) == 32 and len(selected) == 6
    for field, target in (('middleware', 6), ('attempts', 5), ('begin', 5), ('end', 5),
                          ('cancel', 0), ('failure', 0), ('accepted', 77921), ('errors', 0)):
        assert sum(record[field] for record in records) == target
    assert all(r['accepted'] == 0 and r['sha256'] == empty for r in records[6:])
    for case, tags in cases.GROUPS.items():
        assert cases.selected_tags((case,)) == set(tags)
    print('32 records, six selected: M6/A5/B5/E5/C0/F0, accepted 77921')
    print('P12289 and P32 match pinned expected SHA-256; H65536:', credit)
    print('all single-case selections preserve untouched spares')


if __name__ == '__main__':
    main()
