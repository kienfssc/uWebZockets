"""Bind both actual build input maps and freeze only this fix's current closure."""
import hashlib
import json
from pathlib import Path
import shutil
import build_closure

HERE = Path(__file__).resolve().parent
CREDIT = HERE.parent
V4 = CREDIT / 'review-manifest-v4.json'
ADMISSION = CREDIT.parent / 'admission/fix1/review-manifest.json'
FROZEN = Path('/tmp/uwz-task5b3-fix1-frozen')
V4_ROOT = '/tmp/uwz-task5b3-frozen-v4'
SOURCE_NAMES = ('profile.zig', 'prepare.py', 'run_live.py', 'cases.py', 'wire.py', 'raw_observer.py',
                'flow_ledger.py', 'pure_flow_checks.py', 'pure_cases_checks.py', 'pure_sequences_checks.py',
                'pure_codec_checks.py', 'pure_raw_checks.py', 'fixture-contract.md', 'coverage_inventory.json',
                'build_closure.py', 'pure_closure_checks.py')


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as source:
        while block := source.read(8192):
            value.update(block)
    return value.hexdigest()


def inventory(root):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file()}


def main():
    if digest(V4) != '67af47d54c4622d9c9ca822f00f1e10f2afbaf1debc7d69a1c5545a919ef8446':
        raise ValueError('v4 manifest identity differs')
    v4 = json.loads(V4.read_text())
    for root, expected in v4['trees'].items():
        if inventory(Path(root)) != expected:
            raise ValueError('v4 tree changed: ' + root)
    for path, value in v4['inputs'].items():
        if digest(path) != value:
            raise ValueError('v4 input changed: ' + path)
    if digest(ADMISSION) != v4['historical_manifest_sha256'][str(ADMISSION)]:
        raise ValueError('prior reviewed manifest differs')
    approved_inputs = json.loads(ADMISSION.read_text())['inputs']
    approved_archives = {path: approved_inputs[path] for path in build_closure.ARCHIVES}
    receipts, commands = [], []
    for mode in ('debug', 'release'):
        label = 'fixture-' + mode + '-v1'
        receipts.append(json.loads((CREDIT / (label + '.json')).read_text()))
        commands.append(json.loads((CREDIT / (label + '.command.json')).read_text()))
    paths = set().union(*(build_closure.argv_inputs(receipt['argv']) for receipt in receipts))
    current = {path: digest(path) for path in paths}
    merged = build_closure.validate_receipts(receipts, commands, current, approved_archives)
    for mode, record in zip(('debug', 'release'), receipts):
        binary = '/tmp/uwz-task5b3-' + mode + '/profile'
        if digest(binary) != record['binary_sha256']:
            raise ValueError('build binary differs: ' + mode)
    if digest(HERE / 'profile.zig') != merged[str(CREDIT / 'profile.zig')]:
        raise ValueError('fixture source differs from compiled profile')
    if digest(HERE / 'prepare.py') != receipts[0]['fixture_after']['prepare.py']:
        raise ValueError('compile recipe differs')
    if FROZEN.exists():
        raise ValueError('frozen destination exists')
    FROZEN.mkdir(mode=0o700)
    for name in SOURCE_NAMES:
        shutil.copyfile(HERE / name, FROZEN / name)
    trees = {root: files for root, files in v4['trees'].items() if root != V4_ROOT}
    trees[str(FROZEN)] = inventory(FROZEN)
    inputs = {path: value for path, value in v4['inputs'].items()
              if not path.startswith(V4_ROOT + '/') and not path.startswith(str(CREDIT) + '/')}
    for mode in ('debug', 'release'):
        label = 'fixture-' + mode + '-v1'
        for suffix in ('.json', '.command.json', '.log', '-source-inputs.json', '-source-after.json'):
            path = str(CREDIT / (label + suffix))
            inputs[path] = v4['inputs'][path]
    inputs.update(merged)
    for name, value in trees[str(FROZEN)].items():
        inputs[str(FROZEN / name)] = value
    for name in ('freeze_fix1.py', 'pure-closure.log', 'environment.log'):
        path = HERE / name
        inputs[str(path)] = digest(path)
    manifest = dict(v4)
    manifest.update(state='ready-for-independent-review', trees=trees,
                    tree_counts={name: len(files) for name, files in trees.items()}, inputs=inputs,
                    runner=str(FROZEN / 'run_live.py'), wire=str(FROZEN / 'wire.py'),
                    raw=str(FROZEN / 'raw_observer.py'), cases=str(FROZEN / 'cases.py'),
                    flow=str(FROZEN / 'flow_ledger.py'),
                    historical_manifest_sha256={str(V4): digest(V4), str(ADMISSION): digest(ADMISSION)},
                    build_input_receipts=['fixture-debug-v1.json', 'fixture-release-v1.json'],
                    scope='current actual build inputs and runtime closure; v4 preserved by identity')
    output = HERE / 'review-manifest.json'
    if output.exists():
        raise ValueError('manifest already exists')
    output.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    print('v4 trees and inputs: unchanged')
    print('both receipts and commands: 13 current inputs match before, after and actual')
    for path in build_closure.ARCHIVES:
        print(path + ' ' + merged[path])
    print('frozen files:', len(trees[str(FROZEN)]))
    print('fix1 manifest SHA-256:', digest(output))


if __name__ == '__main__':
    main()
