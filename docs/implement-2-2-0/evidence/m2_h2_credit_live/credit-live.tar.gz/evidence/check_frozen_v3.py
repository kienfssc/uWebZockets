"""Read-only AST and manifest verification; does not run the candidate."""
import ast
import importlib.util
from pathlib import Path

root = Path('/tmp/uwz-task5b3-frozen-v3')
for path in sorted(root.glob('*.py')):
    ast.parse(path.read_text(), filename=str(path))
    print('AST OK:', path.name)
spec = importlib.util.spec_from_file_location('frozen_runner', root / 'run_live.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
manifest = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/review-manifest-v3.json')
module.check_manifest(manifest, '0853e02d76c33eb1f3a04811711f907679621023b93f487d85fc33dba43eeeef')
print('frozen runner and current manifest: all bound paths and hashes matched')
