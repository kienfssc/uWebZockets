"""Read-only AST and manifest verification; does not run the candidate."""
import ast
import importlib.util
from pathlib import Path

root = Path('/tmp/uwz-task5b3-frozen-v4')
for path in sorted(root.glob('*.py')):
    ast.parse(path.read_text(), filename=str(path))
    print('AST OK:', path.name)
spec = importlib.util.spec_from_file_location('frozen_runner', root / 'run_live.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
manifest = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/credit/review-manifest-v4.json')
module.check_manifest(manifest, '67af47d54c4622d9c9ca822f00f1e10f2afbaf1debc7d69a1c5545a919ef8446')
print('frozen runner and current manifest: all bound paths and hashes matched')
