"""Create a current-closure review manifest without executing candidate code."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspaces/uWebZockets')
FROZEN = Path('/tmp/uwz-task5b3-frozen-v4')
PRIOR = ROOT / '.uwz-work/evidence/h2-streaming/integration-owned/admission/fix1/review-manifest.json'
SOURCE_NAMES = ('profile.zig', 'prepare.py', 'run_live.py', 'cases.py', 'wire.py', 'raw_observer.py',
                'flow_ledger.py', 'pure_flow_checks.py', 'pure_cases_checks.py', 'pure_sequences_checks.py',
                'pure_codec_checks.py', 'pure_raw_checks.py', 'fixture-contract.md', 'coverage_inventory.json')


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as source:
        while block := source.read(8192):
            value.update(block)
    return value.hexdigest()


def inventory(root):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file()}


def main():
    prior = json.loads(PRIOR.read_text())
    tree_paths = ['/tmp/uwz-task4d-fix1-frozen', '/tmp/uwz-reviewed-libxev-c223-loop-callbacks',
                  '/tmp/uwz-h2-client-tooling/packages',
                  '/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy']
    trees = {}
    for name in tree_paths:
        actual = inventory(Path(name))
        if actual != prior['trees'][name]:
            raise ValueError('current tree differs from prior reviewed identity: ' + name)
        trees[name] = actual
    zig_lib = '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/lib'
    trees[zig_lib] = inventory(Path(zig_lib))
    inputs = {}
    fixed = ['/home/codespace/.python/current/bin/python3', '/opt/conda/bin/openssl', '/opt/conda/ssl/openssl.cnf',
             '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig',
             '/lib/x86_64-linux-gnu/libc.so.6', '/lib/x86_64-linux-gnu/libm.so.6',
             '/lib/x86_64-linux-gnu/libpthread.so.0', '/lib/x86_64-linux-gnu/libdl.so.2',
             '/lib/x86_64-linux-gnu/libcrypto.so.3', '/lib/x86_64-linux-gnu/libssl.so.3',
             '/lib64/ld-linux-x86-64.so.2', '/opt/conda/lib/libcrypto.so.3', '/opt/conda/lib/libssl.so.3',
             str(ROOT / '.uwz-work/evidence/h1-transport/r2/c-native.zig'),
             str(ROOT / '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'),
             str(ROOT / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json'),
             str(ROOT / '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json')]
    for path in fixed:
        inputs[path] = digest(path)
        if path in prior['inputs'] and inputs[path] != prior['inputs'][path]:
            raise ValueError('reviewed input differs: ' + path)
    python_lib = Path('/home/codespace/.python/current/lib/python3.14')
    for path in sorted(python_lib.rglob('*')):
        relative = path.relative_to(python_lib)
        if any(part in ('site-packages', 'test', 'tests', 'idlelib', 'tkinter', 'venv', 'ensurepip') for part in relative.parts):
            continue
        if path.is_file() and path.suffix in ('.py', '.pyc', '.so', '.zip'):
            inputs[str(path)] = digest(path)
    for mode in ('debug', 'release'):
        label = 'fixture-' + mode + '-v1'
        record = json.loads((HERE / (label + '.json')).read_text())
        binary = '/tmp/uwz-task5b3-' + mode + '/profile'
        if record['exit_status'] != 0 or not record['inputs_unchanged'] or digest(binary) != record['binary_sha256']:
            raise ValueError('build receipt or binary differs: ' + mode)
        if record['fixture_after']['profile.zig'] != digest(HERE / 'profile.zig') or record['fixture_after']['prepare.py'] != digest(HERE / 'prepare.py'):
            raise ValueError('compiled sources differ: ' + mode)
        inputs[binary] = digest(binary)
        for suffix in ('.json', '.command.json', '.log', '-source-inputs.json', '-source-after.json'):
            path = HERE / (label + suffix)
            inputs[str(path)] = digest(path)
    if FROZEN.exists():
        raise ValueError('frozen destination already exists')
    FROZEN.mkdir(mode=0o700)
    for name in SOURCE_NAMES:
        shutil.copyfile(HERE / name, FROZEN / name)
    trees[str(FROZEN)] = inventory(FROZEN)
    for name, value in trees[str(FROZEN)].items():
        inputs[str(FROZEN / name)] = value
    for name in ('freeze.py', 'pure-flow-v2.log', 'pure-cases.log', 'pure-sequences.log', 'pure-sequences-v2.log', 'pure-sequences-v3.log', 'pure-codec.log', 'pure-raw.log', 'format.log', 'ast-v3.log'):
        inputs[str(HERE / name)] = digest(HERE / name)
    manifest = {'state': 'ready-for-independent-review', 'runner': str(FROZEN / 'run_live.py'),
                'wire': str(FROZEN / 'wire.py'), 'raw': str(FROZEN / 'raw_observer.py'),
                'cases': str(FROZEN / 'cases.py'), 'flow': str(FROZEN / 'flow_ledger.py'),
                'helper': str(ROOT / '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'),
                'binary': '/tmp/uwz-task5b3-release/profile', 'trees': trees,
                'tree_counts': {name: len(files) for name, files in trees.items()}, 'inputs': inputs,
                'historical_manifest_sha256': {str(PRIOR): digest(PRIOR)},
                'scope': 'current dependency closure only; historical manifests preserved by identity, not runtime inputs'}
    output = HERE / 'review-manifest-v4.json'
    if output.exists():
        raise ValueError('manifest already exists')
    output.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    print('current tree counts:', manifest['tree_counts'])
    print('current individual inputs:', len(inputs))
    print('frozen manifest SHA-256:', digest(output))
    print('historical manifest SHA-256:', digest(PRIOR))


if __name__ == '__main__':
    main()
