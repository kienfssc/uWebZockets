"""Publish the reviewed credit fixture and both actual startup outcomes."""
import gzip
import importlib.util
import json
from pathlib import Path
import tarfile


def main():
    root = Path('/workspaces/uWebZockets')
    evidence = root / '.uwz-work/evidence/h2-streaming/integration-owned/credit'
    common_path = root / '.uwz-work/tools/publish-h2-admission-live.py'
    spec = importlib.util.spec_from_file_location('publication_common', common_path)
    assert spec is not None and spec.loader is not None
    common = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(common)
    audit = json.loads((evidence / 'stage-b/root-result-audit.json').read_text())
    first = json.loads((evidence / 'stage-b-attempt1/result.json').read_text())
    auth = json.loads((evidence / 'fix1/stage-b-authorization-host.json').read_text())
    preflight_sha = common.digest((evidence / 'fix1/root-preflight.json').read_bytes())
    assert audit['checks_passed'] and audit['host_pid_absent'] and audit['key_absent']
    assert audit['child_exit_zero_reaped'] and audit['post_deinit_records_match'] == 32
    assert audit['post_deinit_metrics_match'] and preflight_sha == auth['preflight_sha256']
    assert not first['success'] and not first['cases'] and first['cleanup']['exit_code'] == 1
    assert first['cleanup']['reaped'] and not first['cleanup']['errors']
    assert audit['logical_total'] == 77921 and audit['flow_total'] == 77929
    members = {}
    for path in sorted(evidence.rglob('*')):
        if path.is_file():
            common.add_file(members, 'evidence/' + path.relative_to(evidence).as_posix(), path)
    versions = [('v1', '/tmp/uwz-task5b3-frozen-v1'), ('v2', '/tmp/uwz-task5b3-frozen-v2'),
                ('v3', '/tmp/uwz-task5b3-frozen-v3'), ('v4', '/tmp/uwz-task5b3-frozen-v4'),
                ('fix1-v1', '/tmp/uwz-task5b3-fix1-frozen'),
                ('fix1-v2', '/tmp/uwz-task5b3-fix1-frozen-v2')]
    for label, location in versions:
        for path in sorted(Path(location).iterdir()):
            common.add_file(members, 'source/' + label + '/' + path.name, path)
    reports = ['task-5b3-brief.md', 'task-5b3-architecture.md', 'task-5b3-report.md',
               'task-5b3-fixture-report.md', 'task-5b3-driver-report.md',
               'task-5b3-fix-1-brief.md', 'task-5b3-stage-b-report.md',
               'task-5b3-review-package.md', 'task-5b3-fix1-review-package.md']
    for name in reports:
        common.add_file(members, 'reports/' + name, root / '.superpowers/sdd/h2_streaming_plan' / name)
    common.add_file(members, 'reports/component.md', root / 'docs/implement-2-2-0/m2_h2_credit_live.md')
    common.add_file(members, 'inputs/h2_client.py', root / '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py')
    common.add_file(members, 'inputs/immutable-libxev-input.json', root / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json')
    common.add_file(members, 'inputs/focused-final-ReleaseSafe.command.json', root / '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json')
    common.add_file(members, 'inputs/c-native.zig', root / '.uwz-work/evidence/h1-transport/r2/c-native.zig')
    common.add_file(members, 'publication/publish-h2-credit-live.py', Path(__file__).resolve())
    common.add_file(members, 'publication/publish-h2-admission-live.py', common_path)
    for name, data in members.items():
        data.decode('utf-8')
        assert not data.startswith(b'\0asm'), name
    inventory = [{'path': name, 'bytes': len(data), 'sha256': common.digest(data)}
                 for name, data in sorted(members.items())]
    members['inventory.json'] = (json.dumps({'scope': 'Publication bytes; pre-review versions are historical drafts. Final runtime subject is fix1-v2.',
                                           'files': inventory}, indent=2) + '\n').encode()
    output = root / 'docs/implement-2-2-0/evidence/m2_h2_credit_live'
    output.mkdir(parents=True, exist_ok=True)
    archive = output / 'credit-live.tar.gz'
    archive.write_bytes(gzip.compress(common.tar_bytes(members), mtime=0))
    with tarfile.open(archive, 'r:gz') as reader:
        entries = reader.getmembers()
        assert len(entries) == len(members)
        for entry in entries:
            assert entry.isfile() and reader.extractfile(entry).read() == members[entry.name]
    remaining = ['metadata_helpers', 'producer_reuse', 'output_pressure_window', 'output_pressure_ready',
                 'stream_file', 'early_final_order', 'cancel_ready', 'cancel_paused', 'peer_reset',
                 'sink_error', 'invalid_progress', 'end_error', 'disconnect', 'reuse', 'shutdown_active']
    prior = json.loads((evidence / 'coverage_inventory.json').read_text())['prior_22_proved']
    assert len(prior) == 22 and len(remaining) == 15
    manifest = {'scope': 'Owned Linux ReleaseSafe credit/trailers/concurrent routes plus idle; full milestone and adoption open.',
                'archive': archive.name, 'archive_sha256': common.digest(archive.read_bytes()),
                'archive_bytes': archive.stat().st_size, 'safe_regular_members': len(members),
                'inventory_entries': len(inventory), 'source_digest': audit['source_digest'], 'source_files': 1031,
                'source_checkpoint': '../m2_h2_native_tcp/README.md', 'binary_sha256': audit['binary_sha256'],
                'review_manifest_sha256': common.digest((evidence / 'fix1/review-manifest-v2.json').read_bytes()),
                'preflight_sha256': preflight_sha, 'postrun_preflight_identical': True,
                'authorization_sha256': common.digest((evidence / 'fix1/stage-b-authorization-host.json').read_bytes()),
                'result_sha256': audit['result_sha256'],
                'root_result_audit_sha256': common.digest((evidence / 'stage-b/root-result-audit.json').read_bytes()),
                'cases_passed': audit['cases_passed'], 'previously_verified': prior,
                'planned_unimplemented': remaining, 'totals': audit['totals'],
                'logical_bytes': 77921, 'flow_bytes': 77929, 'post_deinit_records_equal': 32,
                'post_deinit_metrics_equal': True, 'fresh_tls_connections': 4,
                'tls': 'TLS1.3 / h2', 'runtime_mode': 'ReleaseSafe', 'exit_status': 0,
                'startup_attempts': 2, 'completed_protocol_runs': 1, 'automatic_retries': 0,
                'prior_startup_failure': {'exit_status': 1, 'completed_cases': 0,
                                          'error': first['error'],
                                          'result_sha256': common.digest((evidence / 'stage-b-attempt1/result.json').read_bytes()),
                                          'exact_failing_syscall': 'unproved'},
                'child_exit_zero_reaped': True, 'private_key_removed': True,
                'remaining': ['All15 further H2 IDs and combined matrix', 'H3, multipart transport and genuine early data',
                              'Full native, sanitizer, physical lifetime, compliance and platform gates',
                              'Maintained publication, production adoption and original milestones']}
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (output / 'README.md').write_text(f'''# Owned HTTP/2 credit and concurrency evidence

The [archive](credit-live.tar.gz) contains actual fixture and client sources,
pre-review versions and corrected subject, compile recipes/receipts, full input
inventories, pure checks and failures, both source reviews and scoped fixes,
Root identity audit and exact authorizations, both startup outcomes, public
certificates, raw logs/results and independent result audit. All {len(members)}
members are safe regular files; {len(inventory)} inventory entries verify.
No private key or compiled executable is included.

Archive SHA-256: `{manifest['archive_sha256']}` ({manifest['archive_bytes']} bytes).
See [manifest](manifest.json) and [component report](../../m2_h2_credit_live.md).

Three cases plus idle pass: padded12289payload/12297flow, legitimate65535credit
exhaustion followed by actual peer refunds/finalbyte65536, and concurrent route
isolation/refusal/recovery. Totals:6bodyheads,5begins/ends,0cancels/failures,
77921payload/77929flow,0active/errors. All32 records and finalmetrics match after
deinit; four fresh TLS1.3/h2 connections use the same directly owned child.
The503 refusal checks one NO_ERROR reset after finalEOS; healthy streams forbid
resets. Initial request metadata survives discarded trailers. Fixed capacities
and packet-independent predicates are retained.

Two startup attempts are recorded. The restricted executor printed capacity,
then Unexpected before readiness, exited1 and completed no case. The exact
failing syscall is unproved. A separately authorized host-executor attempt of
the identical reviewed code/configuration/assertions passes and exits0/reaps.
Both outcomes and authorizations are included; both keys were removed. This
is one completed protocol run, not a zero-failure startup history. No automatic
retry, stopped experiment or historical denied socket case was reconstructed.

Final subject is source/fix1-v2; review-manifest SHA
`{manifest['review_manifest_sha256']}`. The archive's older draft manifests record
historical stage identities; they are not the current runtime subject. Both
actual fixture builds use profilea370cb6c5a846ff0f628ebb7e76871f933cd5751249cfcb2d3a3898ebf3ef745
and unchanged1031-file source `{manifest['source_digest']}` with the reviewedc223
override. The [native checkpoint](../m2_h2_native_tcp/README.md) reconstructs that
source; [pinned client](../m2_h2_client/README.md) restores offline tools.
Current closure binds both actual build input maps, original binding/six static
archives, compiler/library trees, interpreter/stdlib/loader/TLS tools/helper and
all custom modules. Root checks2438individual inputs/6trees before and after.

Source review fixed missing archive identities and Python locale coercion;
both scoped re-reviews pass. Debug/ReleaseSafe compile and six pure checks pass.
Synthetic sequence checks assert totals/record operations, not complete order
or native results. Native claims come from the separately released owned run.
Execution argv/environment are in evidence/fix1/stage-b-authorization-host.json;
that authorizes only the recorded attempt. Publication scripts are both retained
because the credit publisher reuses the admission publisher's archive helpers.

All15 further H2 IDs, combined matrix, H3/multipart/genuine earlydata, full
quality/platform/compliance/physical gates, maintained publication, production
adoption and original milestones remain open. No performance/RSS/leak/general
native-safety or unexecuted selectable-subset result is claimed.
''')
    print(json.dumps({k: manifest[k] for k in ('archive_sha256', 'archive_bytes', 'safe_regular_members', 'inventory_entries', 'result_sha256')}, indent=2))


if __name__ == '__main__':
    main()
