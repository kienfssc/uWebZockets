# Reviewed request-streaming activation guard V2

Apply11 overlay files after prepared App/R2 and typed-loop callback checkpoint.
This isolated successor is not current production. Raw versioned evidence binds
905source/metadata files, immutable93-file c223 input and unchanged4Root pin views.
Preserve currentRoot multipart/H0/timer/fuzz/support/consumer changes during final
assembly: the source-authority record here identifies all stale preimages.

User confirmed community-BSD setup refusal. The actual pure policy leaves all
disabled tags available, enables linux/macos/windows only, and returns the existing
InvalidTransportConfiguration elsewhere. Fallible setup guards precede allocation,
carving/ownership and native initialization. Nonfallible bound-owner checks retain
existing invariant signatures. No fields, closed config tag, generic-loop policy,
root exports, R3 lifecycle or consumer/TLS hooks were added.

Linux pure policy2/2,body-appV2 17/17 zero skips,config1/1,BodyState21/21,decoder5/5
pass both modes. FinalV2 eligible Windows/macOS full graphs compile0 without exec.
RealFreeBSD compile/comptime and full17case graph pass with precisely recorded
TEMPORARY generated-binding annotations; otherBSDs are pure-policy coverage only.
Seven feature-positive test guards follow actualpolicy; mixed disabled/refusal/
generic checks remain available. V1 and every failed attempt retain exact bindings.
No native foreign behavior, wakeup fix or fullRoot gate is claimed.

Raw/adjusted generatedC bindings and the original sys/time header are retained;
only2u64 result annotations change the temporary translation, never product,
dependency or compiler/header source. Full159fileV2 proof snapshot plus root wrapper
is retained; V1 snapshot can be reconstructed from unchanged sources and its saved
test preimage/wrapper/hash map. Large derived outputs are omitted by hash/size.
No native cancellation/fault/interleaving/race/crash/leak/invalid-fd/resource-
exhaustion/injected-completion probe or stopped experiment ran.
