# Eligible-runtime H1 implementation contract

The unrestricted V6 kqueue finite-close claim remains rejected in its historical
archive. Its fresh review found the non-Darwin worker-wakeup counterexample.
The user explicitly selected setup refusal on community BSD. The actual guarded
setup/binding/entry-point unit is now independently reviewed with no findings;
pure/refusal/borrowed/cluster/comptime and final eligible compilation evidence
bind its exact source. Linux/macOS/Windows eligibility does not establish native
support; the Windows release runtime gate remains required.

Root accepts V6's finite-retirement design as an IMPLEMENTATION PLAN only under
this enforced eligibility precondition and its declared ordinary retained TCP
recv/send, submit-before-cancel, stable-owner/no-reentry contracts. Use the actual
checked-owner entry points and actual core_loop ACK classifier/fixed observer.
Do not copy this conclusion to generic BSD loops, raw deletion/worker targets or
unsubmitted adding targets. Existing bounded backend candidate prerequisites
remain local c223bd886c6a51d2cd60def39dd9a68d701fea73 and unadopted.

This resolves the reported activation-domain finding, not actual lifecycle code.
Cold-v3 data, two fresh retirement stages, callback/ACK/delivery pins, one-shot
physical close and final-action release must still be implemented and reviewed.
Crypto review, ordinary plaintext/TLS uploads, combined protocol/generation tests,
maintained publication/protections/all-four-pin adoption and fullRoot gates remain
required. No native timing or fault experiment is authorized or implied.
