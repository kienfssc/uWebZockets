from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,re,tarfile
root=Path('/workspaces/uWebZockets')
e=root/'.uwz-work/evidence/upload-platform'
impl=e/'implementation'
draft=root/'.uwz-work/drafts/m2-upload-platform'
dest=root/'docs/implement-2-2-0/evidence/m2_upload_platform'
dest.mkdir(parents=True,exist_ok=True)
audit=json.loads((impl/'final/source-audit.json').read_text())
for name in ('base_unchanged','earlier_prepared_base_unchanged','only_assigned_files_changed','immutable_93_file_export_unchanged','protected_root_files_unchanged','standalone_snapshot_159_sources_match_final_successor'):assert audit[name],name
for name,digest in audit['frozen_files_sha256'].items():assert hashlib.sha256((draft/name).read_bytes()).hexdigest()==digest,name
summary=json.loads((impl/'summary.json').read_text())
assert len(summary['checks'])==44 and summary['expected_builder_refusal']
failures={'freebsd-builder-reject':1,'freebsd-policy':1,'freebsd-refusal-comptime':1,'freebsd-refusal-generic-comptime':1,'freebsd-storage-comptime':1,'policy-red':1,'translate-freebsd-sandbox':2}
for name,record in summary['checks'].items():assert record['exit_status']==failures.get(name,0),name
terminal=json.loads((impl/'v2-eligible-terminal-records.json').read_text())
for name,record in terminal.items():
 assert record['exit_status']==0
 assert all(record[k] for k in ('source_stable','compiler_inputs_stable','binds_all_frozen_v2_sources','frozen_sources_still_identical','compile_only_flags_present'))
 assert record['body_app_test_sha256']==audit['frozen_files_sha256']['src/tests/body_app_tests.zig']
(e/'independent-review.md').write_text('''# Independent activation-guard review, 2026-10-27

Fresh reviewer /root/review_upload_platform_v2, no inherited history, read-only.
No actionable findings in the bounded activation unit. Review ran no builds,
tests or probes. FreeBSD evidence is compile/comptime only with the documented
temporary binding adjustment; other BSDs have actual pure-policy coverage.
At review time eligible Windows/macOS body-app records boundV1, notV2. Combined
root gates, native foreign behavior and full R3 lifetime safety remain outside.

Root reconciliation: accept the eligibility/early-side-effect guard unit under
the user's explicit scope choice. Subsequently both fullV2 Windows/macOS compile
graphs finished0, with all11 current sources/input hashes stable and explicit
no-execution flags; terminal records were inspected by root. No source changed
for that followup and no new native runtime claim follows. No fourth whole R3
review was performed. Actual H1 implementation and combined checks remain open.
''')
(e/'eligible-retirement-contract.md').write_text('''# Eligible-runtime H1 implementation contract

The unrestricted V6 kqueue finite-close claim remains rejected in its historical
archive. Its fresh review found the non-Darwin worker-wakeup counterexample.
The user explicitly selected setup refusal on community BSD. The actual guarded
setup/binding/entry-point unit is now independently reviewed with no findings;
pure/refusal/borrowed/cluster/comptime and final eligible compilation evidence
bind its exact source. Linux/macOS/Windows eligibility does not establish native
support; the Windows release runtime gate remains required.

Root accepts V6's finite-retirement design as an IMPLEMENTATION PLAN only under
this enforced eligibility precondition and its declared ordinary retained TCP
recv/send, submit-before-cancel, stable-owner/no-reentry contracts. Use the actual
checked-owner entry points and actual core_loop ACK classifier/fixed observer.
Do not copy this conclusion to generic BSD loops, raw deletion/worker targets or
unsubmitted adding targets. Existing bounded backend candidate prerequisites
remain local c223bd886c6a51d2cd60def39dd9a68d701fea73 and unadopted.

This resolves the reported activation-domain finding, not actual lifecycle code.
Cold-v3 data, two fresh retirement stages, callback/ACK/delivery pins, one-shot
physical close and final-action release must still be implemented and reviewed.
Crypto review, ordinary plaintext/TLS uploads, combined protocol/generation tests,
maintained publication/protections/all-four-pin adoption and fullRoot gates remain
required. No native timing or fault experiment is authorized or implied.
''')
(e/'SCOPE.md').write_text('''# Reviewed request-streaming activation guard V2

Apply11 overlay files after prepared App/R2 and typed-loop callback checkpoint.
This isolated successor is not current production. Raw versioned evidence binds
905source/metadata files, immutable93-file c223 input and unchanged4Root pin views.
Preserve currentRoot multipart/H0/timer/fuzz/support/consumer changes during final
assembly: the source-authority record here identifies all stale preimages.

User confirmed community-BSD setup refusal. The actual pure policy leaves all
disabled tags available, enables linux/macos/windows only, and returns the existing
InvalidTransportConfiguration elsewhere. Fallible setup guards precede allocation,
carving/ownership and native initialization. Nonfallible bound-owner checks retain
existing invariant signatures. No fields, closed config tag, generic-loop policy,
root exports, R3 lifecycle or consumer/TLS hooks were added.

Linux pure policy2/2,body-appV2 17/17 zero skips,config1/1,BodyState21/21,decoder5/5
pass both modes. FinalV2 eligible Windows/macOS full graphs compile0 without exec.
RealFreeBSD compile/comptime and full17case graph pass with precisely recorded
TEMPORARY generated-binding annotations; otherBSDs are pure-policy coverage only.
Seven feature-positive test guards follow actualpolicy; mixed disabled/refusal/
generic checks remain available. V1 and every failed attempt retain exact bindings.
No native foreign behavior, wakeup fix or fullRoot gate is claimed.

Raw/adjusted generatedC bindings and the original sys/time header are retained;
only2u64 result annotations change the temporary translation, never product,
dependency or compiler/header source. Full159fileV2 proof snapshot plus root wrapper
is retained; V1 snapshot can be reconstructed from unchanged sources and its saved
test preimage/wrapper/hash map. Large derived outputs are omitted by hash/size.
No native cancellation/fault/interleaving/race/crash/leak/invalid-fd/resource-
exhaustion/injected-completion probe or stopped experiment ran.
''')
(e/'source-authority.md').write_bytes((root/'.uwz-work/evidence/m2-baseline-authority/authority.md').read_bytes())
retained={};omitted={}
for path in sorted(e.rglob('*')):
 if not path.is_file():continue
 name=path.relative_to(e).as_posix();data=path.read_bytes()
 if path.name.startswith('bin-') or data.startswith(b'\x7fELF') or path.suffix in ('.o','.obj','.exe','.a','.lib'):
  omitted[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};continue
 assert not path.is_symlink(),name
 retained[name]=data
for name in audit['frozen_files_sha256']:retained['overlay/'+name]=(draft/name).read_bytes()
w=json.loads((impl/'freebsd-binding-workaround.json').read_text())
for key,name,digest_key in (('generated_input','raw-freebsd-binding.zig','raw_sha256'),('adjusted_input','adjusted-freebsd-binding.zig','adjusted_sha256')):
 data=Path(w[key]).read_bytes();assert hashlib.sha256(data).hexdigest()==w[digest_key]
 retained['proof-inputs/'+name]=data
retained['proof-inputs/freebsd-sys-time.h']=Path(w['original_c_header']).read_bytes()
snapshot=json.loads((impl/'standalone-snapshot-v2.json').read_text())
for name,digest in snapshot['files_sha256'].items():
 path=Path(snapshot['snapshot_source_root'])/name
 data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==digest,name
 retained['proof-snapshot-v2/src/'+name]=data
wrapper=Path(snapshot['verification_only_wrapper']).read_bytes()
assert hashlib.sha256(wrapper).hexdigest()==snapshot['wrapper_sha256']
retained['proof-snapshot-v2/src/storage_proof_root.zig']=wrapper
output=Path(summary['large_artifacts'])
for path in sorted(output.rglob('*')):
 if not path.is_file():continue
 name=str(path)
 if name in (w['generated_input'],w['adjusted_input']):continue
 digest=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):digest.update(block)
 omitted[name]={'bytes':path.stat().st_size,'sha256':digest.hexdigest()}
retained['omitted-derived-outputs.json']=(json.dumps(omitted,indent=2)+'\n').encode()
values=[v.encode() for k,v in os.environ.items() if re.search(r'(?:TOKEN|SECRET|PASSWORD|CREDENTIAL|API_KEY)$',k) and len(v)>=20]
pattern=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})')
for name,data in retained.items():assert not any(v in data for v in values) and not pattern.search(data),name
inventory={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in retained.items()}
retained['inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
archive=dest/'request-streaming-platform-v2.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(retained.items()):
    member=tarfile.TarInfo(name);member.mode=0o644;member.mtime=0;member.size=len(data)
    tar.addfile(member,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():
  name=PurePosixPath(member.name)
  assert member.isfile() and not name.is_absolute() and '..' not in name.parts
  assert tar.extractfile(member).read()==retained[member.name]
manifest={'date':'2026-10-27','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'safe_regular_members':len(retained),'inventory_entries':len(inventory),'confirmed_user_scope':'Gate streaming on community BSD targets','frozen_overlay_sha256':audit['frozen_files_sha256'],'independent_review':'No actionable findings in bounded activation unit','root_terminal_followup':terminal,'runtime':'Linux17casepositive only; all foreign checks compile/comptime only','root_production_or_pin_change':False,'credential_scan':'All retained bytes checked against credential values/GitHub token patterns; omitted outputs byhash/size','omitted_derived_outputs':omitted,'files':inventory}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('archive_sha256','archive_bytes','safe_regular_members','inventory_entries')},indent=2))
