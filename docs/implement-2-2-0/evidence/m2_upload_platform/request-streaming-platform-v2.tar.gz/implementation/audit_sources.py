from pathlib import Path
import hashlib,json,difflib,shutil
root=Path('/workspaces/uWebZockets');out=Path(__file__).resolve().parent
copy=json.loads((out/'copy-manifest.json').read_text());initial=copy['files_sha256']
base=Path(copy['base']);successor=Path(copy['successor']);excluded=set(copy['excluded_names'])
protected=json.loads((out/'protected-inputs.json').read_text())
def manifest(directory):
 result={}
 for path in directory.rglob('*'):
  name=path.relative_to(directory)
  if any(part in excluded for part in name.parts):continue
  if path.is_symlink():result[str(name)]={'symlink':str(path.readlink())}
  elif path.is_file():result[str(name)]=hashlib.sha256(path.read_bytes()).hexdigest()
 return result
current=manifest(successor);changed=sorted(name for name in initial if initial[name]!=current.get(name));extras=sorted(set(current)-set(initial))
expected=sorted(['src/core/loop.zig','src/core/tcp.zig','src/core/http1_upload_storage.zig','src/router/config.zig','src/router/app.zig','src/tests/core_tests.zig','src/tests/config_tests.zig','src/tests/body_app_tests.zig','README.md','docs/deployment.md','docs/adr/0008-request-body-streaming.md'])
input_manifest=json.loads(Path(protected['immutable_input_manifest']).read_text());export=Path(input_manifest['path'])
export_files={str(path.relative_to(export)):hashlib.sha256(path.read_bytes()).hexdigest() for path in export.rglob('*') if path.is_file()}
snapshot_record=out/'standalone-snapshot-v2.json'
if not snapshot_record.exists():snapshot_record=out/'standalone-snapshot.json'
snapshot=json.loads(snapshot_record.read_text());snapshot_root=Path(snapshot['snapshot_source_root']);actual_source_root=Path(snapshot['original_source_root'])
snapshot_matches=all(hashlib.sha256((snapshot_root/name).read_bytes()).hexdigest()==wanted==hashlib.sha256((actual_source_root/name).read_bytes()).hexdigest() for name,wanted in snapshot['files_sha256'].items())
audit={'base_unchanged':manifest(base)==initial,'earlier_prepared_base_unchanged':manifest(root/'.uwz-work/drafts/m2-body-app')==protected['previous_prepared_base_sha256'],'changed_successor_files':changed,'extra_successor_files':extras,'only_assigned_files_changed':changed==expected and not extras,'immutable_93_file_export_unchanged':export_files==input_manifest['files_sha256'],'protected_root_files_unchanged':all(hashlib.sha256((root/name).read_bytes()).hexdigest()==wanted for name,wanted in protected['root_files_sha256'].items()),'future_integration_must_preserve_root_commit':'3cc8f81','standalone_snapshot_159_sources_match_final_successor':snapshot_matches,'frozen_files_sha256':{name:current[name] for name in changed}}
(out/'final/source-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
for key in ['base_unchanged','earlier_prepared_base_unchanged','only_assigned_files_changed','immutable_93_file_export_unchanged','protected_root_files_unchanged','standalone_snapshot_159_sources_match_final_successor']:
 if not audit[key]:raise SystemExit('audit failed: '+key)
patch=[]
for name in changed:
 destination=out/'final'/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(successor/name,destination)
 patch.extend(difflib.unified_diff((base/name).read_text().splitlines(True),(successor/name).read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(out/'final/complete.diff').write_text(''.join(patch))
print(json.dumps(audit,indent=2))
print('Diff SHA256:',hashlib.sha256((out/'final/complete.diff').read_bytes()).hexdigest())
