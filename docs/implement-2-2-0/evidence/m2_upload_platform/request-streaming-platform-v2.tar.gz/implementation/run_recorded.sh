#!/usr/bin/env bash
set -u

uwz_record=$1
shift
printf 'cwd: %s\ncommand:' "$PWD" > "$uwz_record.command"
printf ' %q' "$@" >> "$uwz_record.command"
printf '\n' >> "$uwz_record.command"
"$@" > "$uwz_record.log" 2>&1
uwz_record_status=$?
printf '%s\n' "$uwz_record_status" > "$uwz_record.status"
cat "$uwz_record.log"
exit "$uwz_record_status"
