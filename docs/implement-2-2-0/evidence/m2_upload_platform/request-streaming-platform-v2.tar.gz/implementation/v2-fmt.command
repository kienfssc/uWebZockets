cwd: /workspaces/uWebZockets/.uwz-work/drafts/m2-upload-platform
command: /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt src/tests/body_app_tests.zig
