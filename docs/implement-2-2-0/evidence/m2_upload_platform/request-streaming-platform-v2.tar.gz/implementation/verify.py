from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/workspaces/uWebZockets')
out = Path(__file__).resolve().parent
draft = root / '.uwz-work/drafts/m2-upload-platform'
artifacts = Path('/tmp/uwz-upload-platform-output')
artifacts.mkdir(exist_ok=True)
label, kind, mode = sys.argv[1:4]
target = sys.argv[4] if len(sys.argv) > 4 else 'native'
template_target = 'aarch64-macos' if target == 'x86_64-freebsd' else target
source_record = root / '.uwz-work/evidence/body-app' / (
    'focused-final-ReleaseSafe.command.json' if target == 'native' else
    'foreign-' + template_target + '.command.json'
)
recorded = json.loads(source_record.read_text())
argv = []
skip_next = False
for arg in recorded['argv']:
    if skip_next:
        skip_next = False
        continue
    if arg in ('--test-no-exec', '-fno-emit-bin') or arg.startswith('-femit-bin='):
        continue
    if arg in ('--cache-dir', '--global-cache-dir'):
        skip_next = True
        continue
    if arg.startswith('-O'):
        arg = '-O' + mode
    if target == 'x86_64-freebsd' and arg == template_target:
        arg = target
    if target == 'x86_64-freebsd' and arg.startswith('-Mc='):
        arg = '-Mc=/tmp/uwz-upload-platform-output/c-x86_64-freebsd.zig'
    if arg.startswith('-Mxev_impl='):
        arg = '-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig'
    elif arg.startswith('-Mzslay=zig-pkg/'):
        arg = '-Mzslay=' + str(root / arg.split('=', 1)[1])
    elif arg.startswith('-Mroot='):
        module = {
            'healthy': 'src/tests/body_app_tests.zig',
            'config': 'src/tests/config_tests.zig',
            'body-state': 'src/tests/request_body_tests.zig',
            'setup-tests': 'src/tests/body_app_tests.zig',
            'config-setup': 'src/tests/config_tests.zig',
            'decoder': 'src/tests/http_tests.zig',
        }.get(kind, 'src/tests/core_tests.zig')
        fixture = {
            'refusal': 'refusal_comptime.zig', 'storage': 'storage_comptime.zig',
            'builder-reject': 'builder_reject.zig', 'backstops': 'backstop_compile.zig',
        }.get(kind)
        arg = '-Mroot=' + (str(out / fixture) if fixture else module)
    if target != 'native' and arg.endswith('.a'):
        continue
    argv.append(arg)
argv.extend(['-j2', '--cache-dir', '/tmp/uwz-relocated-m2-body-app-cache',
             '--global-cache-dir', '/tmp/uwz-multipart-integrated-global'])
if kind == 'storage':
    root_index = next(index for index, arg in enumerate(argv) if arg.startswith('-Mroot='))
    argv[root_index:root_index] = ['--dep', 'upload_storage']
    snapshot = '/tmp/uwz-upload-platform-proof-tree-v2' if label.startswith('v2-') else '/tmp/uwz-upload-platform-proof-tree'
    argv.extend(['-target', target, '-O' + mode, '--dep', 'xev',
                 '-Mupload_storage=' + snapshot + '/src/storage_proof_root.zig'])
if kind == 'pure':
    argv.extend(['--test-filter', 'core: request streaming setup'])
if kind == 'setup-tests':
    argv.extend(['--test-filter', 'ineligible setup', '--test-filter', 'null upload detach', '--test-filter', 'pure body registry'])
if kind == 'config-setup':
    argv.extend(['--test-filter', 'request streaming setup'])
if kind == 'decoder':
    for name in ['chunk size CRLF', 'chunk extension CRLF', 'chunk trailer terminator',
                 'decodes bounded chunked bodies', 'accepts only hexadecimal chunk sizes']:
        argv.extend(['--test-filter', name])
if kind in ('compile-core', 'backstops', 'refusal', 'storage', 'builder-reject') or target != 'native':
    argv.extend(['--test-no-exec', '-fno-emit-bin'])
else:
    argv.append('-femit-bin=' + str(artifacts / ('bin-' + label)))
if kind == 'backstops':
    argv.append('-femit-llvm-ir=' + str(artifacts / (label + '.ll')))
environment = os.environ.copy()
environment['UWZ_TEST_XEV_BACKEND'] = 'io_uring'

def source_hashes():
    return {name: hashlib.sha256((draft / name).read_bytes()).hexdigest() for name in [
        'src/core/loop.zig', 'src/tests/core_tests.zig', 'src/core/xev.zig',
        'src/core/tcp.zig', 'src/router/app.zig',
        'src/core/http1_upload_storage.zig', 'src/router/config.zig',
        'src/tests/config_tests.zig', 'src/tests/body_app_tests.zig',
        'README.md', 'docs/deployment.md', 'docs/adr/0008-request-body-streaming.md',
        'build.zig.zon', 'build.zig.zon.json', 'build.zig.zon.nix', 'build.zig.zon.txt',
    ]}

def input_hashes():
    inputs = {}
    for arg in argv:
        name = arg.split('=', 1)[1] if arg.startswith('-M') else arg if arg.endswith('.a') else None
        if name is None:
            continue
        path = Path(name)
        if not path.is_absolute():
            path = draft / path
        if path.is_file():
            inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return inputs

record = {'argv': argv, 'cwd': str(draft), 'environment': {'UWZ_TEST_XEV_BACKEND': 'io_uring'},
          'command_template': str(source_record), 'source_before': source_hashes(),
          'input_before': input_hashes(),
          'override_provenance': str(out / 'protected-inputs.json')}
(out / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
with (out / (label + '.log')).open('wb') as log:
    result = subprocess.run(argv, cwd=draft, env=environment, stdout=log, stderr=subprocess.STDOUT)
record.update(exit_status=result.returncode, elapsed_seconds=time.monotonic() - started,
              source_after=source_hashes(), input_after=input_hashes())
binary = next((Path(arg.split('=', 1)[1]) for arg in argv if arg.startswith('-femit-bin=')), None)
if binary is not None and binary.is_file():
    record['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
(out / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print((out / (label + '.log')).read_text(), end='')
print('Exit status:', result.returncode)
raise SystemExit(result.returncode)
