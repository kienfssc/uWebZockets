const std = @import("std");
const support = @import("test_support");
const core_loop = support.loop;
const config_module = support.config;
const App = support.app.app(2);

comptime {
    @setEvalBranchQuota(1_000_000);
    const disabled = config_module.ServerConfig{ .max_connections = 2 };
    disabled.validate() catch @compileError("disabled setup was restricted");
    _ = support.builder.configured_builder(disabled).AppType;
    const state = support.request_body.BodyState{};
    if (state.phase != .inactive) @compileError("generic body state changed");
    var parser = support.http_parser.HttpParser{};
    var request = support.http_request.Request{};
    var wire = "POST / HTTP/1.1\r\nHost: example.test\r\nContent-Length: 1\r\n\r\nx".*;
    if (support.http_parser.consume(&parser, &request, &wire) != wire.len) @compileError("generic decoder was restricted");
    if (parser.state != .done) @compileError("generic parser did not finish");
    if (!std.mem.eql(u8, request.body, "x")) @compileError("generic body decode failed");
    if (core_loop.require_request_streaming_setup(true)) |_| {} else |expected| {
        const config = disabled.with(.{ .stream_request_bodies = true });
        if (config.validate()) |_| @compileError("enabled config unexpectedly succeeded") else |err| {
            if (err != expected) @compileError("wrong configuration refusal");
        }
        if (config_module.required_bytes(config)) |_| @compileError("enabled planner unexpectedly succeeded") else |err| {
            if (err != expected) @compileError("wrong planner refusal");
        }
        var slab = [_]u8{0xa5} ** 128;
        if (config_module.carve(&slab, config)) |_| @compileError("enabled carve unexpectedly succeeded") else |err| {
            if (err != expected) @compileError("wrong carve refusal");
        }
        if (App.init_from_slab(std.testing.io, std.testing.allocator, &slab, config)) |_| @compileError("borrowed setup unexpectedly succeeded") else |err| {
            if (err != expected) @compileError("wrong borrowed refusal");
        }
        for (slab) |byte| if (byte != 0xa5) @compileError("borrowed slab was mutated");
        if (App.init_configured(std.testing.io, std.testing.allocator, config)) |_| @compileError("owned setup unexpectedly succeeded") else |err| {
            if (err != expected) @compileError("owned setup reached an effect before refusal");
        }
        const Cluster = App.cluster(1);
        if (Cluster.init_with_options(std.testing.allocator, std.testing.io, config, .{ .worker_count = 0 })) |_| @compileError("cluster options unexpectedly succeeded") else |err| {
            if (err != expected) @compileError("worker-count resolution preceded platform refusal");
        }
        if (Cluster.init_with_worker_count(std.testing.allocator, std.testing.io, config, .{}, 0)) |_| @compileError("cluster count unexpectedly succeeded") else |err| {
            if (err != expected) @compileError("worker-count validation preceded platform refusal");
        }
    }
}

test "actual target setup refusal and disabled builder compile at comptime" {}
