# Request-streaming platform activation guard

The successor is frozen for independent review. The implementation is limited
to request-streaming setup eligibility and its low-level backstops. It adds no
R3 lifetime algorithm, physical-close permission, body driver, worker wakeup,
platform selector, stored state, registry or root export.

The user explicitly confirmed gating streaming on community BSD targets,
as relayed by root. This is a confirmed requirement, not a default assumption.
`scope-confirmation.json` binds that confirmation to the unchanged README,
deployment and ADR hashes. No policy change was needed for V2.

## Source and dependency isolation

Base: `/workspaces/uWebZockets/.uwz-work/drafts/m2-loop-callbacks`.
Successor: `/workspaces/uWebZockets/.uwz-work/drafts/m2-upload-platform`.

`copy-manifest.json` records an exact 905-file copy, excluding Git metadata,
caches, build outputs and dependency symlinks. The final source audit proves
both prior prepared trees remain unchanged, with exactly the assigned eight
Zig files and three documentation files changed in the successor. ADR 0008 was
updated because its public activation contract otherwise omitted the new
platform restriction.

`final/source-audit.json` contains every frozen file hash. The complete direct
delta is `final/complete.diff`, SHA256
`60ac6b7307340dd7f002b9a0c9fe8023094fb4be0485d35ac16c9da94bc54e26`.
Preimages and final files are retained under `preimage/` and `final/`.

All project test/compiler graphs use the explicit compiler module override
`-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig`.
The immutable 93-file export remains byte-identical at commit
`c223bd886c6a51d2cd60def39dd9a68d701fea73`, tree
`86c6944f53dc009d7503a9ab0bc873aef3cd7b79`. Root's four dependency views
remain unchanged. This is an isolated compiler override, with no adoption or
local dependency overlay.

`protected-inputs.json` and the final audit also prove root's timer source and
central core tests were not overwritten. This prepared source predates root
commit **3cc8f81**. Future combined integration must preserve that commit's
timer fix and regression; apply the reviewed delta rather than replacing root
files with this older prepared tree.

All new binaries, compiler caches, generated C bindings, large IR and the
verification-only source snapshot are under task-specific `/tmp` paths. The
evidence directory retains their paths, hashes, commands, statuses and small
text excerpts. No historical source or artifact was deleted or relocated by
this slice.

## Production changes

- `core/loop.zig` adds the exact closed
  `RequestStreamingSetupError = error{InvalidTransportConfiguration}` and the
  pure `request_streaming_setup_decision(enabled, os_tag)`. Disabled setup
  always succeeds. Enabled Linux/macOS/Windows setup succeeds; every other tag
  returns that same error. The native wrapper supplies `builtin.os.tag`.
- `router/config.zig` invokes that policy from `validate_transport`, reusing
  the existing configuration error tag. The existing required-bytes, carve and
  builder paths already validate before allocation or mutation.
- Both enabled App cluster constructors preflight before worker-count
  resolution/validation and worker, inbox or thread allocations.
- `App.loop_handle` checks nonempty upload-owner storage before binding the
  failure fence or owner handles. Its nonfallible signature is preserved with
  a documented invariant panic.
- `Http1UploadStorage.init` checks before the first storage write or Timer
  initialization.
- `Tcp.bind_upload_owner` checks non-null attachment before touching owners;
  its existing void/invariant contract and null detach behavior are preserved.
- One private checked-owner accessor rejects direct assignment to the public
  owner field. It runs before mutations at read-start, read-arm, read-callback,
  dispatch, close-after-flush and close entry points. It returns null unchanged
  for the disabled path; future enabled H1 entries must use it.

No platform conditional was added to portable production modules; they call
the core policy. Generic Loop, LoopHandle, fence, decoder, registry and
BodyState contracts remain unchanged. No data field, default slab layout, API
signature or existing closed configuration error tag changed.

README, deployment guidance and ADR 0008 state that setup eligibility is
separate from runtime support. Community BSD activation waits for worker
wakeups and native validation. Windows remains subject to its release-job
gate. This slice makes no new runtime-support claim.

## Failing-first evidence

`policy-red` executed the actual new pure classifier with the predecessor's
unrestricted policy extracted as its initial implementation. The disabled
test passed and the enabled-target test failed on the first BSD expectation:
`expected error.InvalidTransportConfiguration, found void`.
Outcome: 1 passed, 1 failed, exit 1. This is a behavioral pure-policy red,
not a declaration failure, native target spoof or native cancellation test.
Its exact sources are retained in `red/` with before/after command bindings.

The final classifier passes both tests: three eligible tags, all four named
community BSD tags, representative other rejected tags, and every real OS tag
with the feature disabled. These are values passed to the actual pure
production policy, not injected native results.

## V2 test-only refinement

Root authorized unfreezing only `src/tests/body_app_tests.zig` after V1.
`v2-authorization-audit.json` proves every other successor file, including
all production and documentation, remains byte-identical to V1. V1's source
audit, summary, complete diff, report and exact test preimage remain under
`v1/`; all original command/log records retain their exact bindings.

The body-app file derives one compile-time eligibility constant from the actual
core policy, with no duplicate OS list. Seven feature-positive-only cases use
that constant to report SkipZigTest on ineligible targets. Every positive
assertion remains on eligible targets. Mixed tests retain disabled branches and
check refusal before allocation, planning or borrowed-slab mutation. The pure
registry and null detach tests remain unconditional. Decoder and BodyState
suites are unchanged.

V2 test SHA256:
`586469fb363c008a4eea9b9591bfebf4994411619b4b6a1aee757a0cbda725c2`.
The test-only delta is `v2-body-app-only.diff`, SHA256
`bc319dadf72f20a9752a33e37831f09a63eba17489274a49e89827cde56707e9`.
The separate unconditional enabled-builder rejection fixture is unchanged.

## Linux verification

All checks use the exact Zig 0.16.0 compiler
`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`, `-j2`,
and existing `/tmp` caches. `verify.py` records complete argv, working
directory, the established `UWZ_TEST_XEV_BACKEND=io_uring` expectation, source
hashes and compiler input bindings. Normal OS access was used for the existing
body-app suite. No native fault test was selected.

| Scope | Debug | ReleaseSafe |
| --- | --- | --- |
| Actual setup policy | 2/2 | 2/2 |
| V2 body-app suite, all eligible positive assertions | 17/17, no skips | 17/17, no skips |
| Focused configuration setup test | 1/1 | 1/1 |
| Unchanged BodyState suite | 21/21 | 21/21 |
| Five unchanged chunk/body-decoder cases | 5/5 | 5/5 |

The Linux-only successful eligibility branch does not execute the new
unsupported-target setup branch. That branch is evaluated using the real
FreeBSD compiler target as described below. No blanket skip was added to the
decoder, registry or BodyState tests.

The V2 17-case executions are recorded under `v2-healthy-body-app-*`.
Unaffected production and pure checks retain their original V1 argv and hash
bindings. Their inputs did not change merely because the unrelated body-app
test file changed; they were not repeated or relabeled as V2 executions.
V2 formatting and convention checks passed separately.

Scoped `zig fmt`, `zig fmt --check`, unchanged convention checks and release
version checks passed. The convention command supplies the existing Codex
`rg` directory in PATH. Release metadata still matches 2.1.6. No unintegrated
full root build or sanitizer run was claimed.

## Foreign and comptime verification

Windows and macOS setup-policy graphs and the V1 full eligible body-app test
graphs compile in ReleaseSafe without execution. Their exact V1 bindings are
retained. The same two full eligible body-app graphs were then compiled again
against frozen final V2 under new labels:

| V2 terminal record | Target | Outcome |
| --- | --- | --- |
| `v2-eligible-app-windows` | `x86_64-windows-gnu` | Exit 0; compile only |
| `v2-eligible-app-macos` | `aarch64-macos` | Exit 0; compile only |

Both records bind the final V2 body-app test hash and all frozen source files,
with unchanged source and compiler inputs before/after each invocation. They
retain full argv and use `--test-no-exec -fno-emit-bin`; compiler caches remain
under `/tmp`, and no foreign executable was emitted or executed. Terminal
binding checks are in `v2-eligible-terminal-records.json`. This closes the V1
versus V2 compile-evidence gap without a new native runtime claim, source
change or unrelated test rerun.

For FreeBSD, the compiler's raw C translation exposed an unrelated generated
`sys/time.h::bintime_shift` issue: two `@bitCast` expressions lacked a result
type. Root approved explicit `u64` result annotations in the temporary
generated binding only. The original C field is `uint64_t`, and the generated
field is `u64`; the original expressions shift that field by `_exp` and
`-_exp`. `freebsd-binding-workaround.json` records both expressions, raw and
adjusted hashes and the original header. The exact two-expression delta is
`freebsd-binding-annotation.diff`. The raw binding is retained under `/tmp`.
No compiler, repository, maintained dependency or C header source was changed.

The following are **compile proofs using that generated-binding workaround**,
not native BSD builds, runtime tests or support validation:

- Real FreeBSD target setup policy and selected config/setup test graphs.
- The complete V2 17-case body-app graph compiles, with seven feature-only
  guards and mixed disabled/generic/refusal checks available. No BSD execution
  or runtime skip-count result is claimed.
- Comptime disabled configuration and builder acceptance.
- Comptime enabled config, required-bytes and carve refusal with unchanged
  caller bytes.
- Comptime owned and borrowed App refusal before allocation or ownership
  transfer. Borrowed slab bytes retain their sentinels.
- Both cluster constructors return the platform error before resolving or
  rejecting an explicitly invalid worker count.
- Generic BodyState construction and actual buffered parser/body-decoder use
  succeed at comptime despite streaming activation being unavailable.
- Unchanged BodyState and decoder test graphs compile, and the generic registry
  test compiles without applying the activation restriction.
- Disabled App setup and nonfallible backstops compile/code-generate. Small
  source/IR excerpts show eligibility checks before the guarded mutations.
- The expected-failure builder fixture fails with the existing diagnostic
  `invalid ServerConfig: InvalidTransportConfiguration`. Its exit status is 1
  and that exact diagnostic is checked in `summary.json`.

For the direct standalone-storage proof, a hash-identical 159-file snapshot of
the real `src` tree was created under `/tmp`, with one verification-only root
wrapper at its src boundary. This preserves relative imports without adding a
library export or successor file. `standalone-snapshot.json` records the V1
source hashes, mapping and wrapper; that snapshot remains unchanged.
`standalone-snapshot-v2.json` records a fresh separate snapshot containing the
V2 test file. The final audit verifies all 159 V2 sources match the frozen
successor. The actual
storage initializer is invoked at comptime under the real FreeBSD target and
returns the platform error before changing owner sentinels or initializing its
Timer.

Invariant panics and the prior terminating observer were not executed. No
subprocess crash test was added.

## Preserved failed attempts

Raw logs and actual statuses are retained separately:

- `translate-freebsd-sandbox`: exit 2 creating a cache manifest on a read-only
  filesystem. The same translation succeeded with normal compiler-cache access.
- `freebsd-policy` and `freebsd-refusal-comptime`: raw generated-binding
  compile failures before the approved annotations.
- `freebsd-storage-comptime`: direct-module-root attempt rejected relative
  imports outside that module's path, before the approved identical snapshot.
- `freebsd-refusal-generic-comptime`: the initial evidence-only HTTP/1.1
  parser fixture omitted Host. The corrected fixture includes Host and proves
  successful body decoding; production parser behavior did not change.

`summary.json` records all actual outcomes and distinguishes the expected pure
red and builder refusal from successful checks. Source/input bindings remain
available for each invocation.

## Limits and integration

Eligible positive runtime coverage is Linux Debug/ReleaseSafe, 17/17 each.
Unsupported-target refusal is proved by the pure matrix, source order and
actual FreeBSD compile/comptime checks. V2 also compiles the entire FreeBSD
body-app graph using the documented baseline translation workaround. This is
not native BSD runtime validation or verification of BSD worker wakeups.
Other BSD tags are covered by the actual pure policy matrix without claiming
new native builds or runtime support there.

No native cancellation, registration-error, interleaving, race, crash/leak,
resource-exhaustion, invalid-descriptor, injected-completion or kernel-error
probe was created or run. The prior stopped experiment was not reconstructed.
The null-detach test uses only caller-owned memory and never submits or reads
its opaque socket field. No BSD wakeup implementation or R3 activation code
was added.

Independent source review and combined integration remain root-owned. Preserve
root 3cc8f81 during that integration. Root also retains graph refresh,
archiving, commits, publication and dependency adoption decisions.
