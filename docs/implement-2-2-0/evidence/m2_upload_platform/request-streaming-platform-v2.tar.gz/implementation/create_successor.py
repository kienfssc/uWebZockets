from pathlib import Path
import hashlib,json,shutil

root=Path('/workspaces/uWebZockets')
out=Path(__file__).resolve().parent
base=root/'.uwz-work/drafts/m2-loop-callbacks'
successor=root/'.uwz-work/drafts/m2-upload-platform'
excluded={'.git','.zig-cache','zig-out','zig-pkg','graphify-out','__pycache__'}
def manifest(directory):
    result={}
    for path in directory.rglob('*'):
        name=path.relative_to(directory)
        if any(part in excluded for part in name.parts):continue
        if path.is_symlink():result[str(name)]={'symlink':str(path.readlink())}
        elif path.is_file():result[str(name)]=hashlib.sha256(path.read_bytes()).hexdigest()
    return result
initial=manifest(base)
shutil.copytree(base,successor,symlinks=True,ignore=lambda directory,names:set(names)&excluded)
if manifest(base)!=initial or manifest(successor)!=initial:raise SystemExit('copy identity failed')
(out/'copy-manifest.json').write_text(json.dumps({'base':str(base),'successor':str(successor),'excluded_names':sorted(excluded),'file_count':len(initial),'files_sha256':initial,'base_unchanged':True,'copy_identical':True},indent=2)+'\n')
input_manifest=root/'.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json'
export=json.loads(input_manifest.read_text())
for name,wanted in export['files_sha256'].items():
    if hashlib.sha256((Path(export['path'])/name).read_bytes()).hexdigest()!=wanted:raise SystemExit('dependency mismatch: '+name)
protected=['src/core/timer.zig','src/tests/core_tests.zig','build.zig.zon','build.zig.zon.json','build.zig.zon.nix','build.zig.zon.txt']
(out/'protected-inputs.json').write_text(json.dumps({'immutable_input_manifest':str(input_manifest),'immutable_input_manifest_sha256':hashlib.sha256(input_manifest.read_bytes()).hexdigest(),'dependency_commit':export['commit'],'dependency_tree':export['tree'],'module_override':'-Mxev_impl='+export['path']+'/src/main.zig','required_future_root_integration_preserves':'3cc8f81','root_files_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in protected},'previous_prepared_base_sha256':manifest(root/'.uwz-work/drafts/m2-body-app')},indent=2)+'\n')
print('Copied',len(initial),'files; both prior source trees and dependency export preserved')
