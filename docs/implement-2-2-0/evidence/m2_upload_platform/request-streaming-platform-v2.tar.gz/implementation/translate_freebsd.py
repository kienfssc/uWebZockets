from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/workspaces/uWebZockets');out=Path(__file__).resolve().parent
draft=root/'.uwz-work/drafts/m2-upload-platform'
template=root/'.uwz-work/evidence/h1-transport/r2/translate-aarch64-macos.command.json'
argv=json.loads(template.read_text())['argv'];argv=[str(root/arg) if arg.startswith('zig-pkg/') else arg for arg in argv]
argv[argv.index('-target')+1]='x86_64-freebsd'
argv[argv.index('--cache-dir')+1]='/tmp/uwz-upload-platform-translate-cache'
argv[argv.index('--global-cache-dir')+1]='/tmp/uwz-multipart-integrated-global'
argv.append('-j2')
destination=Path('/tmp/uwz-upload-platform-output/c-x86_64-freebsd.zig')
record={'argv':argv,'cwd':str(draft),'template':str(template),'output_path':str(destination),'input_sha256':hashlib.sha256((draft/'src/c.h').read_bytes()).hexdigest()}
started=time.monotonic()
with destination.open('wb') as output,(out/'translate-freebsd.log').open('wb') as errors:
 result=subprocess.run(argv,cwd=draft,stdout=output,stderr=errors)
record.update(exit_status=result.returncode,elapsed_seconds=time.monotonic()-started,output_sha256=hashlib.sha256(destination.read_bytes()).hexdigest())
(out/'translate-freebsd.json').write_text(json.dumps(record,indent=2)+'\n')
print((out/'translate-freebsd.log').read_text(),end='');print('Translation exit status:',result.returncode)
raise SystemExit(result.returncode)
