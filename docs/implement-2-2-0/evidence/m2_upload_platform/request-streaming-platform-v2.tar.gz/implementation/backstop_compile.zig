const support = @import("test_support");
const App = support.app.app(2);
const std = @import("std");

export fn check_disabled_setup(io: *std.Io, allocator: *std.mem.Allocator) void {
    var app = App.init_configured(io.*, allocator.*, .{ .max_connections = 2 }) catch return;
    app.deinit();
}

export fn check_public_owner_binding(app: *App) void {
    _ = app.loop_handle();
}

export fn check_upload_attach(connection: *support.tcp.TcpConnection) void {
    support.tcp.bind_upload_owner(connection, connection.upload_owner);
}

export fn check_read_start(connection: *support.tcp.TcpConnection, loop: *support.loop.Loop) void {
    support.tcp.read_start(connection, loop);
}

export fn check_close(connection: *support.tcp.TcpConnection) void {
    support.tcp.close_connection(connection);
}
