const support = @import("test_support");
const Rejected = support.builder.configured_builder(.{ .max_connections = 2, .stream_request_bodies = true });
test "existing builder diagnostic rejects enabled setup" {
    _ = Rejected.AppType;
}
