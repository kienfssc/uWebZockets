cwd: /workspaces/uWebZockets/.uwz-work/drafts/m2-upload-platform
command: /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt src/core/loop.zig src/core/tcp.zig src/core/http1_upload_storage.zig src/router/config.zig src/router/app.zig src/tests/core_tests.zig src/tests/config_tests.zig src/tests/body_app_tests.zig
