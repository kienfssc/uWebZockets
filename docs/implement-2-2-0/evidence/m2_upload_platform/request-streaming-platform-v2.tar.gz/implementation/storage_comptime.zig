const storage = @import("upload_storage").storage;
const std = @import("std");

comptime {
    var owner = storage.Http1UploadStorage{ .retirement_timer = undefined, .pending_header_length = 17 };
    if (storage.init(&owner)) |_| @compileError("standalone owner unexpectedly initialized") else |err| {
        if (err != error.InvalidTransportConfiguration) @compileError("wrong standalone owner refusal");
    }
    if (owner.initialized or owner.pending_header_length != 17) @compileError("owner mutated before refusal");
}

test "standalone owner refuses before mutation and timer initialization" {
    _ = std;
}
