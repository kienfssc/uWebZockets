# Request-streaming platform activation guard

The successor is frozen for independent review. The implementation is limited
to request-streaming setup eligibility and its low-level backstops. It adds no
R3 lifetime algorithm, physical-close permission, body driver, worker wakeup,
platform selector, stored state, registry or root export.

## Source and dependency isolation

Base: `/workspaces/uWebZockets/.uwz-work/drafts/m2-loop-callbacks`.
Successor: `/workspaces/uWebZockets/.uwz-work/drafts/m2-upload-platform`.

`copy-manifest.json` records an exact 905-file copy, excluding Git metadata,
caches, build outputs and dependency symlinks. The final source audit proves
both prior prepared trees remain unchanged, with exactly the assigned eight
Zig files and three documentation files changed in the successor. ADR 0008 was
updated because its public activation contract otherwise omitted the new
platform restriction.

`final/source-audit.json` contains every frozen file hash. The complete direct
delta is `final/complete.diff`, SHA256
`b2f3426a96ec646e7a1b0c140418dacc24797ac8810cb0dc816292992743ab64`.
Preimages and final files are retained under `preimage/` and `final/`.

All project test/compiler graphs use the explicit compiler module override
`-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig`.
The immutable 93-file export remains byte-identical at commit
`c223bd886c6a51d2cd60def39dd9a68d701fea73`, tree
`86c6944f53dc009d7503a9ab0bc873aef3cd7b79`. Root's four dependency views
remain unchanged. This is an isolated compiler override, with no adoption or
local dependency overlay.

`protected-inputs.json` and the final audit also prove root's timer source and
central core tests were not overwritten. This prepared source predates root
commit **3cc8f81**. Future combined integration must preserve that commit's
timer fix and regression; apply the reviewed delta rather than replacing root
files with this older prepared tree.

All new binaries, compiler caches, generated C bindings, large IR and the
verification-only source snapshot are under task-specific `/tmp` paths. The
evidence directory retains their paths, hashes, commands, statuses and small
text excerpts. No historical source or artifact was deleted or relocated by
this slice.

## Production changes

- `core/loop.zig` adds the exact closed
  `RequestStreamingSetupError = error{InvalidTransportConfiguration}` and the
  pure `request_streaming_setup_decision(enabled, os_tag)`. Disabled setup
  always succeeds. Enabled Linux/macOS/Windows setup succeeds; every other tag
  returns that same error. The native wrapper supplies `builtin.os.tag`.
- `router/config.zig` invokes that policy from `validate_transport`, reusing
  the existing configuration error tag. The existing required-bytes, carve and
  builder paths already validate before allocation or mutation.
- Both enabled App cluster constructors preflight before worker-count
  resolution/validation and worker, inbox or thread allocations.
- `App.loop_handle` checks nonempty upload-owner storage before binding the
  failure fence or owner handles. Its nonfallible signature is preserved with
  a documented invariant panic.
- `Http1UploadStorage.init` checks before the first storage write or Timer
  initialization.
- `Tcp.bind_upload_owner` checks non-null attachment before touching owners;
  its existing void/invariant contract and null detach behavior are preserved.
- One private checked-owner accessor rejects direct assignment to the public
  owner field. It runs before mutations at read-start, read-arm, read-callback,
  dispatch, close-after-flush and close entry points. It returns null unchanged
  for the disabled path; future enabled H1 entries must use it.

No platform conditional was added to portable production modules; they call
the core policy. Generic Loop, LoopHandle, fence, decoder, registry and
BodyState contracts remain unchanged. No data field, default slab layout, API
signature or existing closed configuration error tag changed.

README, deployment guidance and ADR 0008 state that setup eligibility is
separate from runtime support. Community BSD activation waits for worker
wakeups and native validation. Windows remains subject to its release-job
gate. This slice makes no new runtime-support claim.

## Failing-first evidence

`policy-red` executed the actual new pure classifier with the predecessor's
unrestricted policy extracted as its initial implementation. The disabled
test passed and the enabled-target test failed on the first BSD expectation:
`expected error.InvalidTransportConfiguration, found void`.
Outcome: 1 passed, 1 failed, exit 1. This is a behavioral pure-policy red,
not a declaration failure, native target spoof or native cancellation test.
Its exact sources are retained in `red/` with before/after command bindings.

The final classifier passes both tests: three eligible tags, all four named
community BSD tags, representative other rejected tags, and every real OS tag
with the feature disabled. These are values passed to the actual pure
production policy, not injected native results.

## Linux verification

All checks use the exact Zig 0.16.0 compiler
`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`, `-j2`,
and existing `/tmp` caches. `verify.py` records complete argv, working
directory, the established `UWZ_TEST_XEV_BACKEND=io_uring` expectation, source
hashes and compiler input bindings. Normal OS access was used for the existing
body-app suite. No native fault test was selected.

| Scope | Debug | ReleaseSafe |
| --- | --- | --- |
| Actual setup policy | 2/2 | 2/2 |
| Prepared body-app suite plus three pure setup/registry tests | 17/17 | 17/17 |
| Focused configuration setup test | 1/1 | 1/1 |
| Unchanged BodyState suite | 21/21 | 21/21 |
| Five unchanged chunk/body-decoder cases | 5/5 | 5/5 |

The Linux-only successful eligibility branch does not execute the new
unsupported-target setup branch. That branch is evaluated using the real
FreeBSD compiler target as described below. No blanket skip was added to the
decoder, registry or BodyState tests.

Scoped `zig fmt`, `zig fmt --check`, unchanged convention checks and release
version checks passed. The convention command supplies the existing Codex
`rg` directory in PATH. Release metadata still matches 2.1.6. No unintegrated
full root build or sanitizer run was claimed.

## Foreign and comptime verification

Windows and macOS setup-policy graphs and the full eligible body-app test
graphs compile in ReleaseSafe without execution.

For FreeBSD, the compiler's raw C translation exposed an unrelated generated
`sys/time.h::bintime_shift` issue: two `@bitCast` expressions lacked a result
type. Root approved explicit `u64` result annotations in the temporary
generated binding only. The original C field is `uint64_t`, and the generated
field is `u64`; the original expressions shift that field by `_exp` and
`-_exp`. `freebsd-binding-workaround.json` records both expressions, raw and
adjusted hashes and the original header. The exact two-expression delta is
`freebsd-binding-annotation.diff`. The raw binding is retained under `/tmp`.
No compiler, repository, maintained dependency or C header source was changed.

The following are **compile proofs using that generated-binding workaround**,
not native BSD builds, runtime tests or support validation:

- Real FreeBSD target setup policy and selected config/setup test graphs.
- Comptime disabled configuration and builder acceptance.
- Comptime enabled config, required-bytes and carve refusal with unchanged
  caller bytes.
- Comptime owned and borrowed App refusal before allocation or ownership
  transfer. Borrowed slab bytes retain their sentinels.
- Both cluster constructors return the platform error before resolving or
  rejecting an explicitly invalid worker count.
- Generic BodyState construction and actual buffered parser/body-decoder use
  succeed at comptime despite streaming activation being unavailable.
- Unchanged BodyState and decoder test graphs compile, and the generic registry
  test compiles without applying the activation restriction.
- Disabled App setup and nonfallible backstops compile/code-generate. Small
  source/IR excerpts show eligibility checks before the guarded mutations.
- The expected-failure builder fixture fails with the existing diagnostic
  `invalid ServerConfig: InvalidTransportConfiguration`. Its exit status is 1
  and that exact diagnostic is checked in `summary.json`.

For the direct standalone-storage proof, a hash-identical 159-file snapshot of
the real `src` tree was created under `/tmp`, with one verification-only root
wrapper at its src boundary. This preserves relative imports without adding a
library export or successor file. `standalone-snapshot.json` records all source
hashes, original/snapshot roots, wrapper bytes, hash and path. The final audit
verifies every copied source still matches the frozen successor. The actual
storage initializer is invoked at comptime under the real FreeBSD target and
returns the platform error before changing owner sentinels or initializing its
Timer.

Invariant panics and the prior terminating observer were not executed. No
subprocess crash test was added.

## Preserved failed attempts

Raw logs and actual statuses are retained separately:

- `translate-freebsd-sandbox`: exit 2 creating a cache manifest on a read-only
  filesystem. The same translation succeeded with normal compiler-cache access.
- `freebsd-policy` and `freebsd-refusal-comptime`: raw generated-binding
  compile failures before the approved annotations.
- `freebsd-storage-comptime`: direct-module-root attempt rejected relative
  imports outside that module's path, before the approved identical snapshot.
- `freebsd-refusal-generic-comptime`: the initial evidence-only HTTP/1.1
  parser fixture omitted Host. The corrected fixture includes Host and proves
  successful body decoding; production parser behavior did not change.

`summary.json` records all actual outcomes and distinguishes the expected pure
red and builder refusal from successful checks. Source/input bindings remain
available for each invocation.

## Limits and integration

FreeBSD checks use selected negative-setup and generic consumers. The old full
feature-positive body-app suite remains an eligible-platform suite; its
enabled builder expectation intentionally conflicts with BSD activation
refusal if that entire positive suite is selected. It was not presented as a
passing FreeBSD runtime suite.

No native cancellation, registration-error, interleaving, race, crash/leak,
resource-exhaustion, invalid-descriptor, injected-completion or kernel-error
probe was created or run. The prior stopped experiment was not reconstructed.
The null-detach test uses only caller-owned memory and never submits or reads
its opaque socket field. No BSD wakeup implementation or R3 activation code
was added.

Independent source review and combined integration remain root-owned. Preserve
root 3cc8f81 during that integration. Root also retains graph refresh,
archiving, commits, publication and dependency adoption decisions.
