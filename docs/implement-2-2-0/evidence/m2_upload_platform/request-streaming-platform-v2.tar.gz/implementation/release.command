cwd: /workspaces/uWebZockets/.uwz-work/drafts/m2-upload-platform
command: sh scripts/check_release_version.sh
