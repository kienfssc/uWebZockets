from pathlib import Path
import hashlib,json,shutil,difflib

root=Path('/workspaces/uWebZockets');out=Path(__file__).resolve().parent
artifacts=Path('/tmp/uwz-upload-platform-output')
binding=artifacts/'c-x86_64-freebsd.zig';raw=binding.read_text()
translation=json.loads((out/'translate-freebsd.json').read_text())
if hashlib.sha256(binding.read_bytes()).hexdigest()!=translation['output_sha256']:raise SystemExit('raw translation changed')
raw_copy=artifacts/'c-x86_64-freebsd-raw.zig';shutil.copy2(binding,raw_copy)
replacements={
 '@intCast(@bitCast(@as(c_long, _exp)))':'@intCast(@as(u64, @bitCast(@as(c_long, _exp))))',
 '@intCast(@bitCast(@as(c_long, -_exp)))':'@intCast(@as(u64, @bitCast(@as(c_long, -_exp))))',
}
adjusted=raw
for before,after in replacements.items():
 if adjusted.count(before)!=1:raise SystemExit('expected one generated expression: '+before)
 adjusted=adjusted.replace(before,after,1)
binding.write_text(adjusted)
(out/'freebsd-binding-annotation.diff').write_text(''.join(difflib.unified_diff(raw.splitlines(True),adjusted.splitlines(True),fromfile=str(raw_copy),tofile=str(binding))))
(out/'freebsd-binding-workaround.json').write_text(json.dumps({'scope':'root-approved compile-proof workaround only; no native BSD build/runtime claim','original_c_header':'/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/lib/libc/include/generic-freebsd/sys/time.h','original_c_type':'struct bintime.frac is uint64_t; generated field is u64','original_c_expressions':['_bt->frac <<= _exp;','_bt->frac >>= -_exp;'],'generated_input':str(raw_copy),'adjusted_input':str(binding),'raw_sha256':hashlib.sha256(raw_copy.read_bytes()).hexdigest(),'adjusted_sha256':hashlib.sha256(binding.read_bytes()).hexdigest(),'only_two_result_annotations':replacements},indent=2)+'\n')

original=root/'.uwz-work/drafts/m2-upload-platform/src'
snapshot=Path('/tmp/uwz-upload-platform-proof-tree/src')
snapshot.parent.mkdir(exist_ok=True)
shutil.copytree(original,snapshot)
manifest={str(path.relative_to(original)):hashlib.sha256(path.read_bytes()).hexdigest() for path in original.rglob('*') if path.is_file()}
for name,wanted in manifest.items():
 if hashlib.sha256((snapshot/name).read_bytes()).hexdigest()!=wanted:raise SystemExit('snapshot mismatch: '+name)
wrapper=snapshot/'storage_proof_root.zig'
wrapper.write_text('pub const storage = @import("core/http1_upload_storage.zig");\n')
(out/'standalone-snapshot.json').write_text(json.dumps({'original_source_root':str(original),'snapshot_source_root':str(snapshot),'source_file_count':len(manifest),'all_copied_source_hashes_identical':True,'files_sha256':manifest,'verification_only_wrapper':str(wrapper),'wrapper_bytes':wrapper.read_text(),'wrapper_sha256':hashlib.sha256(wrapper.read_bytes()).hexdigest()},indent=2)+'\n')
print('Annotated exactly two generated expressions; copied',len(manifest),'identical source files plus one verification-only root wrapper')
