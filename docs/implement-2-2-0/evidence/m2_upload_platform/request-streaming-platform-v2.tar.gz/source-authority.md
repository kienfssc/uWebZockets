# Read-only M2 baseline authority map, 2026-10-27

Explorer /root/map_m2_baseline_authority. Start an isolated baseline from current
Root production3cc8f81; later3d6b6f9 changes documentation only. Never replace the
whole Root tree from the prepared App snapshot. No assembly/build/test/probe ran
in the explorer pass. Platform guard is still a separate review input.

Prepared App metadata records baseline00c8564, draft_HEAD8da20c2 and explicit H0v2,
R2/registry seeds. Git proves affected production preimages outside multipart and
timer remain unchanged through current Root. All base/src files match the prior
transport-recovery archive; its175members include159src files and metadata.

| Paths | Authority and merge |
| --- | --- |
| http/parser,request,body_decoder | CurrentRoot; byte-identical to App/H2/H3. Keep H0v2, saturation correction and buffered compatibility; Request39aa4255 remains authoritative. |
| http/request_body,streaming_request | CurrentRoot; common state/contracts identical in drafts. |
| http/multipart,multipart_streaming,multipart_sink | CurrentRoot only, commits0a26e8e/ec31328. App predates both; H2/H3 lack later sink integration. multipart17fbce66. |
| router/radix | CurrentRoot plus reviewed App registry delta(a1c05328): BodyMatch, optional columns, selection/admission/preflight. No laterRoot change. |
| router/app,config | CurrentRoot plus reviewed App owner/config deltas, then final reviewed platform guard. Root preimages unchanged. |
| router/builder | CurrentRoot plus reviewed App73c2bfe2 streaming builder entry. |
| core/loop | CurrentRoot + R2 stable handle/fence + reviewed typed callbacks74c4e5b + final reviewed platform guard. No laterRoot change in this file. |
| core/tcp | CurrentRoot + R2 cold/guarded handles + H2 selector delta(App->H2) + final reviewed guard. Neither current draft alone combines these. |
| core/http1_upload_storage | Reviewed R2 addition4dd51686 plus final guard. No Root counterpart. |
| core/http1_upload | Reviewed admission additione03c106a: bounds and reserve-to-arm; remains unconnected. |
| core/timer_wheel | CurrentRoot onlyb0a3fc27; preserve3cc8f81. All inspected drafts retain a8ae2f22. |
| core/udp; client/client,connection | CurrentRoot plus supporting R2 handle-preservation/guarded-submission deltas; Root preimages unchanged. |
| http2/server | CurrentRoot + complete finalH2v6 delta409ab150. Recovery7c681723 and v5b00ec885 are superseded partial versions. |
| http2/connection | CurrentRoot + H2 width-safe send-credit guards8a80413b. |
| quic/engine,stream | CurrentRoot + complete H3 delta: engineca04df2e inherited from recovery and v7streamf6827cb4. v7 changed-list alone omits engine wiring. |
| root.zig | CurrentRoot only9bd47d83; identical throughout drafts; no extra root export required by prepared components. |
| test_support | CurrentRoot plus Admission's one http1_upload import; preserve all current H0/fuzz/multipart support. |
| tests/main | CurrentRoot + App + Admission + H2refusal/width + H3refusal/width imports; preserve all current H0/multipart imports. No complete draft main exists. |
| tests/core_tests | CurrentRoot + typed callback3cases/import + reviewed platform tests; preserve count_wheel_expiration and3cc8 overflow regression. |
| New ordinary component tests | Use reviewed component versions; H2refusal5e4de2c3 is v6. Verification-only facade files remain test inputs, not new library exports. |
| fuzz_support; tests/fuzz_main; tests/package_consumer/main | CurrentRoot only; no transport component changes required. Preserve H0 fuzz and full multipart consumer coverage. |

Exactly stale/partly stale base paths: src/http/multipart.zig,
src/core/timer_wheel.zig,src/fuzz_support.zig,src/test_support.zig,
src/tests/{core_tests,fuzz_main,main}.zig,tests/package_consumer/main.zig.
EightRoot additions absent from App: src/fuzz/{http_body,multipart_streaming}.zig,
src/http/{multipart_streaming,multipart_sink}.zig,
src/tests/{http_body_decoder,multipart_large,multipart_sink,multipart_streaming}_tests.zig.

Shared hotspots requiring explicit composition: loop(R2+typed+guard),
tcp(R2+H2selector+guard),App/config/coldOwner(guard),
testSupport/currentmain/currentcoreTests. Other source/pins keep currentRoot.
Actual assembly waits for final guard review; retain the explicit immutable
c223bd886c6a51d2cd60def39dd9a68d701fea73 test override without adopting a pin.
The future public surface still cannot land without actual H1 consumer and
H2/H3 fallback, crypto review and combined gates.
