# Task5e3b3: nine empty, limited and refusal/recovery schedules

Continue the unchanged all40 combined-client plan from the reviewed/pushed B2
checkpoint8cc7114c5aefb4f07db053ce02fdefd330969ec8. Eight schedules are earned;
implement this cohesive nine-case admission unit using their existing adapter.
Read task-5e3b-release-addendum.md and its linked original brief for binding
global interfaces and execution limits. Do not rewrite completed B1/B2 or
substitute source mapping for implementation.

## Ownership and source authority

Own new admission schedules/tests in the existing combined-cases directory,
minimal necessary adapter.py/cases.py/test_imports.py changes, durable
evidence/b3/ there and task-5e3b3-report.md in this plan workspace. Preserve
all earlier source snapshots and proof. Root owns Git/public delivery. You
are not alone; preserve others' edits. No agents or external model CLI.

Current14-module map is the committed B2manifest and
task-5e3b2-root-final-audit.json. Root rechecked all14 bytes against the pushed
checkpoint and final admission reference hashes before dispatch. Immutable
model/catalogue: /tmp/uwz-task5e1-contract-v3; immutable v9core:
/tmp/uwz-task5e3a-snapshot-v9/source. Pinned helper/codecs/Python paths and
identities are in the release addendum. Combined fixture source-only routes/
schemas: /tmp/uwz-task5e2-Fix1Final2/fixture.

Authoritative final admission source is
.uwz-work/evidence/h2-streaming/integration-owned/admission/fix1/cases.py,
profile.zig and run_live.py. Their hashes are bound in
task-5e3b-input-audit.json. Use the combined model request contracts and schema,
not older family record aliases. Read these files as source only; never invoke
their old entrypoints. The finite barrier handoff supersedes old poll loops:
flush preceding actions, one same-connection observation, fail on mismatch.

## Required cases and exact J/C/R

| Case | Heads J | Small C | Request flow R |
| --- | ---: | ---: | ---: |
| empty_headers | 3 | 3 | 0 |
| empty_data | 3 | 3 | 0 |
| empty_declared | 3 | 3 | 0 |
| limit_declared | 3 | 3 | 32 |
| limit_undeclared | 3 | 3 | 32 |
| limit_declared_reject | 4 | 4 | 32 |
| limit_observed_reject | 5 | 5 | 65 |
| zero_declared_reject | 4 | 4 | 0 |
| zero_observed_reject | 4 | 4 | 1 |

Empty cases preserve their distinct HEADERS END, empty DATA END, and explicit
content-length0 contracts. Valid limit cases send canonical32 bytes with the
correct declared/absent length. Declared refusals preserve their source Expect
headers and final413 without100/positive primary DATA, then same-connection
healthy recovery. Observed limit refusal sends32 withoutEND, uses the accepted-
prefix finite status barrier, then the offending1 byte; zero-observed sends
the offending1 byte without a false successful upload. Preserve all exact
source statuses, ordered response-END-before-NO_ERROR0 resets, early-return
and retirement behavior, refused versus begun/cancelled records, reasons and
healthy recovery. Do not infer status/reset policy from response role.

Import unchanged catalogue/model validators, payload generator and request
contracts. Each refusal has the exact separate recovery tag from the model;
do not reuse/overwrite its persistent diagnostic. Retain all13 new body records
and checked source counters. No second expected-state model or schema widening.

Extend the actual used adapter seams only as required for exact final-status/
informationals/reset policy and primary identity of these paths. Every action
and observation must use the approved wire/parser/both-ledgers/stage path once.
No raw-parser alternative, duplicate aggregate refund, codec bypass or direct
mutation that evades a bound. Source-required response/terminal ordering must
be checked, not merely a final record. Preserve independent connection state,
fresh caller-owned integer time at actions/read/drain/final boundaries, bounded
spans/captures and inherited case/whole deadlines. No per-DATA/read histories.

Dispatch the earned17-case subset explicitly and reject the remaining23
unsupported IDs before actions. Do not silently call this the full40 default.
Cover a selected-before shared synthetic app with fresh codecs/ledgers and
existing final67-status-plus-metrics collection, retaining prior case records.
No new native fixture API, core/model mutation, count/budget/deadline change,
placeholder or unsupported successful handler is authorized.

## Focused proof and handoff

Use narrow behavior-first RED/GREEN, recording the actual pre-change failure
and intermediate fixes accurately. Selection-only RED remains selection-only;
missing test files or deliberate mutations are not behavioral REDs. Do not
invent a failure or unnecessary behavior change. Prove exact serialized
methods/paths/query/header multiplicity/declaration/Expect/END/DATA sizes and
digests, refusal/Continue/reset order, accepted-prefix barrier, recovery and
record isolation. Use bounded ordinal checks, not retained frame histories.
Add focused negative controls for the named ordering/refusal invariants and
clearly qualify any sensitivity controls.

Use pinned Python3.14.2 -B -S, normal/-O and in-memory public codecs only.
Capture each final covering command's actual stdout, stderr and exit separately
under evidence/b3 after the last edit; include relevant B1/B2 regressions for
changed adapter/selection seams. Do not rerun unrelated suites. Snapshot all
current directly owned modules, with hashes and exact changed/new comparison
against B2. All authored helpers need main guards and actual empty/foreign-
argv silent/inert imports with rejecting effect doubles. No authored classes,
inheritance/custom exceptions/assert proof statements, hidden mutable globals,
dead code or control-flow nesting beyond3 levels.

No native build/server/socket/SSLContext/TLS/close/process ownership/transfer/
descriptor/kernel/fault/cancel/scheduling/race/panic/leak/real-clock experiment
is released. Pure serialized refusal/control/reset tests are allowed. Stopped
native experiments remain stopped. If an immutable source/core seam actually
prevents a required path, report the smallest failing pure call and continue
independent cases; do not bypass it or quietly weaken scope.

Write full task-5e3b3-report.md with source bindings/APIs, changed files,
commands/raw results, failure history, final identities, self-review and
precise remaining facts. Append a short parent-report note, keeping all40
incomplete. Return concise DONE/concerns, report location and verification
summary. Root independently reviews before publication/commit/next unit.
