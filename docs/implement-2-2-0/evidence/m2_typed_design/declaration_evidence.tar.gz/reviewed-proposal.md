# M2 compatibility-preserving request-streaming revision

Status: architecture proposal, 2026-10-26. Root has selected the compatibility
and error-policy directions below; implementation and final ADR amendment
remain root-owned. No repository or frozen-draft source was edited here.
This proposal replaces only the conflicting request-view/middleware/error
portions of ADR 0008, not its lifecycle, framing, quotas, or transport bounds.

## Assumptions and resolved design frontier

1. Preserve existing Request and OwnedRequest public shapes, helpers, error
   sets, buffered results, and clone semantics. Do not require ordinary buffered
   callers to widen catches for a feature they did not enable.
2. Keep the new route-level sink and existing reviewed BodyControl/BodyState
   lifecycle. Introduce a distinct StreamingRequest for new begin/end callbacks.
3. Legacy global middleware keeps its original callback ABI. It can run on an
   incomplete request only after an explicit new BodyRoute policy acknowledges
   that the entire global chain is header-only. No global callback is skipped.
4. Keep the old closed send_file error set: its incomplete-upload refusal is
   BodyNotAllowed. Starts whose sets are already open use BodyNotComplete.
5. A cloned streaming view owns metadata only and derives its borrowed views
   from owned arrays after construction; never point at a moved inline Request.

Root explicitly accepted these directions after the compiler evidence. The
remaining field-level implementation and ownership checks are acceptance work,
not a reason to ask the user to waive the compatibility requirement.

## Compiler evidence and the contradiction

The original four-error Request.form set is MissingContentType,
TooManyQueryParameters, QueryComponentTooLong, and UnsupportedMediaType.
The frozen draft adds BodyNotBuffered. Both a narrow-return wrapper and a
normal exhaustive catch on a default buffered Request compile against baseline
and fail against draft. Evidence is retained at
/tmp/uwz-m2-helper-compatibility/REPORT.md; its 50-file inventory is
SHA256 aa14ab7ad4932b8ef2f6f8c5b6b4c35f4c92679d6047e34efa8f68b7d86d7cc7.
The contradiction is type-level even when the runtime value stays buffered.
Aliases, anyerror, or mapping the condition to an unrelated old error cannot
preserve both the old closed signature and the new distinct error.

Additional declaration probes are in /tmp/uwz-m2-compat-design-probes. They use
Zig 0.16 build-obj -fno-emit-bin, isolated caches, and existing translated
bindings; no C graph, linker, full test, or live server was run.

- compat_shape exits 0: an actual unchanged Request.form narrow/exhaustive
  consumer coexists with a separate toy view form returning BodyNotBuffered.
  This is a type-level feasibility example, not the proposed implementation.
- shape_layout intentionally exits 1 for compileLog: the proposed native view
  shape is 208 bytes/alignment 8; proposed flat owned shape 176/alignment 8;
  the actual unchanged Request is 2752. These are proposal-shape measurements.
- open_response_membership exits 0: BodyNotComplete is already representable
  in begin_chunked, begin_stream, stream_file, begin_json, and sse return sets.
- send_file_membership exits 1 specifically because BodyNotComplete is absent
  from its closed eleven-error set. The reflection log retains that full set.
- Initial discarded-error probe setup diagnostics remain separately labeled.
  Reflected open inferred sets have null member lists; do not infer nominal
  type identity from comparing their unresolved type to the anyerror type.

## New metadata-only interface

Keep src/http/request.zig unchanged for this revision. Remove the draft's
BodyMode field, helper guards, clone-mode changes, and corresponding old-type
exports. Type choice expresses body availability instead of a runtime mode in
legacy Request. No public BodyMode enum is needed for this contract.

Add src/http/streaming_request.zig with named flat types:

```zig
pub const BodyReadError = error{BodyNotBuffered};

pub const RouteParamsView = struct {
    names: []const []const u8,
    values: []const []const u8,
    extra_names: []const []const u8 = &.{},
    extra_values: []const []const u8 = &.{},
};

pub const StreamingRequest = struct {
    method: []const u8,
    target: []const u8,
    path: []const u8,
    protocol: []const u8,
    query: []const u8,
    headers: fetch.HeadersView,
    params: RouteParamsView,
};
```

There is no Request pointer and no raw body field in StreamingRequest. Its
constructor projects only the five metadata slices plus bounded header and
capture views from the transport's pinned Request. It ignores Request.body,
even if a caller constructs a source with a nonempty body. Projection performs
no I/O, allocation, logging, environment access, or metadata-array copy.

The new view has text()/bytes() returning an empty slice. json(T,allocator),
validate_json(T,allocator), validate_json_detailed(T,allocator,issue), form(),
and multipart() return BodyReadError before parsing, media-type checking,
allocation, or issue mutation. Their payload types retain the familiar parsed
JSON/query/multipart shapes, but the new type's closed refusal set is deliberate.
These methods implement a complete unavailability contract, not placeholder
parsers. Query parsing and bounded capture lookup remain available.

Use headers.get/has/entries directly; avoid a second layer of trivial header
forwarders. RouteParamsView.get performs the bounded primary/extra lookup and
preserves case-sensitive route-name semantics. If the multipart adapter needs
unique-header validation, add that actual invariant once at the HeadersView or
new view seam; do not duplicate a broad Request facade speculatively.
Common application validation can take HeadersView and explicit method/path
slices, allowing reuse from legacy and streaming code without a request factory.

The new callback aliases become:

```zig
pub const BodyBeginFn = *const fn (
    *anyopaque, *const StreamingRequest, BodyControl,
) anyerror!BodyBinding;
pub const BodyEndFn = *const fn (
    *anyopaque, *const StreamingRequest, *Response,
) anyerror!void;
```

Only these unpublished new aliases change. Existing Handler, MiddlewareHandler,
AsyncHandler and C callbacks remain unchanged. Chunk/cancel, BodyControl,
BodyLimits and the reviewed pure lifecycle state retain their existing design.
A const metadata view also prevents sink callbacks from casually modifying the
owner's parsing/framing metadata.

## Explicit global middleware policy

Add only to the new, unpublished BodyRoute interface:

```zig
pub const BodyMiddlewarePolicy = enum { reject_legacy, headers_only };
pub const BodyRoute = struct {
    sink: BodySink,
    limits: BodyLimits,
    middleware_policy: BodyMiddlewarePolicy = .reject_legacy,
};
```

The policy covers the entire global chain, including callbacks registered later.
It is borrowed immutable route configuration, not a second registry or capacity.

- With no global middleware, either policy can admit the route normally.
- With any global middleware and reject_legacy, route_body returns the new
  BodyMiddlewareIncompatible error before mutating route storage.
- App.use can still append a callback after a successful body registration.
  Do not add a new error to App.use, Router.use, listen, or run to police this.
  Recheck policy during body admission before invoking any middleware, reserving
  quota, calling begin, or sending 100 Continue. An incompatible late chain
  receives bounded 503 and normal transport rejection cleanup. Handle that
  refusal inside dispatch; it is not an event-loop failure returned by run.
- headers_only explicitly certifies that every current/future global callback
  uses metadata and response operations only. Invoke every callback exactly once
  in existing order, with the original *Request ABI and body empty. Stop and
  early-response semantics remain unchanged.

Crucial distinction: that legacy header-only Request retains BASELINE helper
semantics and errors. Request.form can parse an empty form; it does not gain
BodyNotBuffered. The dedicated refusal guarantee belongs to StreamingRequest
in the new sink callbacks. Document this distinction in the ADR rather than
claiming old middleware acquired impossible new errors. The safe default keeps
a body-dependent global from silently seeing an incomplete body. Applications
must move body-dependent validation into the sink or retain buffered routes;
incorrectly declaring such a chain headers_only violates the explicit contract.

This needs no generic callback, request pointer cast, extra middleware wrapper,
new global state, or fixed-size bitset assumption. Router permits custom
middleware capacities up to u8 max, not only the default 32; this policy does
not alter that existing capacity.

## Owned streaming snapshots

Use OwnedStreamingRequest with owned flat metadata arrays, not an inline
legacy Request bridge. It holds allocator, byte storage, owned header-name/
value and capture-name/value arrays, and the five copied metadata slices.
clone allocates only on this explicit caller-requested surface, with checked
size arithmetic and complete failure cleanup. It never allocates or copies a
body, future payload, callback pointer, BodyControl, Response or transport owner.

view() constructs a StreamingRequest value from the owned heap arrays and
copied slices. It must not retain HeadersView pointing into a returned/moved
inline Request. Returning the owner through a helper before the first view is
safe; all header/capture data outlives views until deinit. Copying ownership or
using any view after deinit remains caller misuse, as for OwnedRequest.
The existing Request.clone/OwnedRequest implementation can remain byte-unchanged.

The live streaming view preserves the callback-only pointer/view lifetime from
ADR 0008. Its HeadersView/RouteParamsView array slices are borrowed
only for that callback; individual pinned byte slices have the existing longer
lifetime. Clone creates a separate owned lifetime and preserves unavailability
by returning the distinct owned-streaming type, not OwnedRequest.

## Pre-body response errors without a second source break

Before accepting ownership or emitting output, open-error response starts
begin_chunked/begin_stream/stream_file/begin_json/sse refuse incomplete uploads
with BodyNotComplete. writable_stream keeps its nonfallible constructor; its
first write reaches the same canonical start guard. Existing fixed bounded
final responses remain permitted for early refusal.

Legacy Response.send_file has a closed error set. Its incomplete-upload guard
returns the existing BodyNotAllowed tag, which accurately states that this
file body cannot start in the current phase. Do not return ZeroCopyUnavailable,
which would invite a fallback, or an unrelated parse/IO error. Document this
explicit exception to the earlier blanket BodyNotComplete wording. Tests must
prove no head, queue mutation, transfer slot, or descriptor ownership was taken.
Default-complete Response values retain their old behavior.

## Scope and capacity consequences

First revised slice contains the new metadata type/ownership and existing pure
BodyState contract only, plus exports/tests/package references. It still adds no
live route, decoder, transport storage or upload capability. The rejected
runtime-mode draft's Request2752->2760 and default-slab+73728 measurements remain
historical evidence; do not apply their config assertion changes.

Legacy Request/OwnedRequest and transport structs remain unchanged in this slice,
so no Request-driven default slab or HeaderSet growth is intended. Actual new
view/owner sizes and unchanged production layouts must be measured before that
claim is finalized; the 208/176 values above are native toy declaration shapes.
Later optional adapter state, receive pools and response guards require their
own exact measurement. This does not validate unimplemented storage estimates.

All other accepted bounds remain: startup opt-in, logical u64 limits and positive
per-route/per-worker max_active, pinned initial metadata, exactly one end/cancel,
inline generation-safe controls, HTTP/1 physical ingress/formulas, HTTP/2 bounded
credit/block-pool behavior, and positive reusable H3 input storage. Preserve
ADR 0008 terminal ownership and callbacks' no-use-after-inline-control rules.

BodyEnd may arm a response producer, but upload terminal cleanup does not
extend output lifetime. Output context, scratch and any owned metadata must
independently outlive that response. A producer cannot retain freed upload
binding state or callback-only StreamingRequest/header-array views. Individual
pinned metadata bytes have the separately documented response lifetime.
Source metadata arrays and slots remain pinned through the entire active
callback, including after synchronous response end/reset, and through any longer
response lifetime. Expired controls do not mean callback storage is releasable.

## Ordered ownership and implementation plan

1. Root/architect: amend ADR0008 public aliases, request/helper paragraph,
   middleware admission ordering/policy, clone and send_file exception; retain
   every other accepted lifetime/storage/framing decision. Record the compiler
   counterexample and preferred revision in the M2 report.
2. HTTP/DX developer: in the isolated draft, revert ONLY the legacy Request
   changes, add streaming_request.zig, adapt request_body.zig aliases and the
   new middleware policy. Keep the reviewed BodyControl/BodyState logic.
   Root serializes root.zig/test_support/main imports and public aliases.
3. Verification: rewrite old runtime-mode tests as new-view tests, preserve
   lifecycle cases, add unchanged legacy compile consumers and metadata/owned
   view lifetime tests. Update package consumer against release exports.
4. Independent reviewer: review interface and compiler proof, then source,
   ownership, compatibility and exact measurements. Re-review changed work.
5. Root: integrate only after M1 closure and required revised-slice gates.
   Then proceed to router/admission and serialized H1/TLS/H2/H3 adapters.
   Do not advertise live streaming from this common contract checkpoint.

## Common-contract acceptance for the next slice

- Original narrow-return and exhaustive-catch consumers compile unchanged
  against baseline AND revised release exports. Add an actual default-buffered
  runtime form assertion; do not widen the consumer's four errors or add else.
- Legacy Request and OwnedRequest interfaces/layouts/helpers remain unchanged;
  generic JSON/schema helpers are not widened by a hidden runtime branch.
- New stream form/multipart/JSON/schema helpers refuse with BodyNotBuffered
  before media checks, parser/custom hooks, allocations or issue mutation.
  text/bytes are empty and no raw/future body field is exposed.
- Projection preserves method/target/path/protocol/query, all initial headers
  including extra fields, and all inline/overflow route captures. Query and
  case-sensitive capture lookup work without allocation.
- Clone through a returned-by-value helper, poison source byte/array storage,
  derive the owned view, and verify every field including overflow metadata.
  Assert view arrays refer to owned allocations, not an inline temporary.
  Exercise every allocation failure and release all owned memory once.
- Retain all pure lifecycle tests, inline terminal/context-release tests and
  accepted-prefix/u64/first-cause cancellation checks from the reviewed draft.
- Type-test the new callback aliases, BodyMiddlewarePolicy default and the
  already-proven baseline Response error memberships. The common checkpoint
  does not implement middleware admission or Response guards yet.
- Measure actual Request/transport/default-slab/new-view/owner layouts on claimed
  targets; preserve strict equality operators, thresholds and existing tests.
  No rejected-draft +8/+73728 config assertion changes belong in this slice.
- Run formatter/conventions/version/docs/dependency/native tests plus applicable
  canonical sanitizer, target, package and examples on actual integrated
  changes. Old draft or toy probes are not revised API implementation proof.
  Refresh graphify and retain source-bound artifacts and independent review.

## Router/transport acceptance in the later ordered slices

- Empty-chain/default-policy registration works. Existing global/default policy
  refuses atomically. Late use is caught before any callback/begin/100 Continue
  and returns 503 with clean transport state. Explicit headers_only invokes all
  globals once in order and preserves header-only legacy helper semantics.
  Buffered routes retain their old full-body middleware timing/results.
- Keep App.use/Router.use/listen/run error surfaces unchanged; new configuration
  refusals belong to new route APIs or caught HTTP admission paths.
- Open response starts reject with BodyNotComplete; legacy send_file rejects
  with BodyNotAllowed and its closed set remains unchanged. Assert zero head,
  queue, transfer-slot and descriptor-ownership mutation on refusal. Fixed early
  responses and pending metadata satisfy the accepted output/reset ordering.
- After a BodyEnd callback starts a pending response producer and releases its
  upload binding, prove output uses independently valid state/scratch. Also
  end/reset synchronously then read the callback metadata again before return;
  source arrays/slots cannot be recycled underneath that active callback.
- Keep the original 100 MB transport, pause/resume-at-EOF, cancellation/reset,
  100 Continue, trailer, allocation and framing matrix. Apply its canonical
  sanitizer/fuzz/protocol/package gates to the actual owning transport changes.
  Common-contract completion never claims these unimplemented wire results.

## Deep-module seam and stress-test outcome

StreamingRequest is the typed seam between upload delivery and unavailable
full-body APIs. Deleting it forces either every sink to enforce unavailable-body
rules manually or legacy Request to acquire the proven breaking error. The
projection/owned snapshot also centralizes metadata borrows across three
transport adapters. A Mode factory, legacy pointer cast, large facade of header
forwarders, unrelated error mapping or widened anyerror old API adds complexity
without preserving the actual contract and is rejected.

The design tree was stress-tested against concrete closed consumers, late
middleware registration, a body-dependent global, snapshot return-by-value,
empty/malformed body helper inputs, early file response ownership, and inline
control cleanup. Root resolved the compatibility/middleware/ownership/send_file
frontier explicitly. Fresh independent proposal/source review remains root-owned;
this delegated planning pass did not spawn a nested reviewer or external CLI.
Cross-model review was skipped in this noninteractive subordinate scope.
