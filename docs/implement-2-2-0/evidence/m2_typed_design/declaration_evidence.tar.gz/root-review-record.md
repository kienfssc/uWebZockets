# Root decision and independent review

Date: 2026-10-26. This is an integrator-authored record, not a compiler log.

The architect proposed a distinct StreamingRequest with unchanged legacy
Request/OwnedRequest, explicit whole-chain middleware policy and a closed
send_file error exception. Independent reviewer m1_file_h3_review found one
P2: upload cleanup must not invalidate a pending outgoing producer. Root
added independent output lifetime and full active-callback storage pinning,
including synchronous end/reset after controls expire, to the reviewed
derivative and actual ADR0008.

The same independent reviewer boundedly re-reviewed the changed sections and
reported no findings, resolving the prior P2. No builds or tests were repeated
by that bounded review. Root accepts the revised design. Actual new types,
unchanged buffered compiler consumers, clones, production layouts, response
guards, middleware ordering and live transports remain implementation gates.

The original proposal and all declaration probe bytes remain unchanged. The
derivative includes the two lifetime paragraphs and their later adapter tests.
The toy shape sizes are not implemented production-layout measurements.
