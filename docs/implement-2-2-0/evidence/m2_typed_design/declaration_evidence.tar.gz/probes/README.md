# M2 compatibility design probes

These read-only-source Zig 0.16 declaration probes use build-obj -fno-emit-bin.
No native C build, link, test gate, or repository source edit occurred.

compat_shape passes using the actual legacy Request.form with its exact four
old errors and a separate toy metadata-view form returning BodyNotBuffered.
This proves the type-level separation can coexist, not that a revised
StreamingRequest implementation has been written or tested.

shape_layout intentionally exits one for compileLog: proposed native view208,
owned metadata shape176, both alignment8; actual unchanged Request2752.
Actual production/cross-target layouts remain required after implementation.

response_errors intentionally reflects the original error sets. Open sets have
null member reflection, but their unresolved inferred type does not compare
identically to the anyerror type; do not infer type identity from that boolean.
The concrete open_response_membership probe exits zero after assigning
BodyNotComplete into every relevant open set. send_file_membership exits one
specifically because that tag is absent from the closed send_file set.

response_membership_setup_failure preserves an initial discarded-error setup
mistake and must not be reported as a behavioral compatibility failure.
Every command, log and numeric status is retained beside its source.
