const types = @import("compat_shape.zig");
comptime {
    @compileLog("StreamingRequest proposal shape", @sizeOf(types.StreamingRequestShape), @alignOf(types.StreamingRequestShape));
    @compileLog("OwnedStreamingRequest proposal shape", @sizeOf(types.OwnedStreamingRequestShape), @alignOf(types.OwnedStreamingRequestShape));
    @compileLog("Actual unchanged Request", @sizeOf(@import("request").http_request.Request));
}
