const module = @import("test_support").http_response;
const Response = module.Response;

fn report(comptime name: []const u8, comptime Return: type) void {
    const Errors = @typeInfo(Return).error_union.error_set;
    _ = name;
    const candidate: Errors = error.BodyNotComplete;
    _ = candidate;
}

comptime {
    const response: *Response = undefined;
    report("begin_chunked", @TypeOf(response.begin_chunked("", "")));
    report("begin_stream", @TypeOf(response.begin_stream("", "", undefined, undefined)));
    report("send_file", @TypeOf(response.send_file("", "", undefined, 0, 0)));
    report("stream_file", @TypeOf(response.stream_file("", "", undefined)));
    report("begin_json", @TypeOf(response.begin_json()));
    report("sse", @TypeOf(response.sse()));
    const writer = response.writable_stream();
    _ = writer;
}
