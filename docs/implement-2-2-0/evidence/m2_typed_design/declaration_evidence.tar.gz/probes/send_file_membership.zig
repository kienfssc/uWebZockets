const module = @import("test_support").http_response;
const Response = module.Response;

fn report(comptime name: []const u8, comptime Return: type) void {
    const Errors = @typeInfo(Return).error_union.error_set;
    _ = name;
    const candidate: Errors = error.BodyNotComplete;
    if (!@import("std").mem.eql(u8, @errorName(candidate), "BodyNotComplete")) @compileError("unexpected error tag");
}

comptime {
    const response: *Response = undefined;
    report("send_file", @TypeOf(response.send_file("", "", undefined, 0, 0)));
    const writer = response.writable_stream();
    _ = writer;
}
