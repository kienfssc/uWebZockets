const std = @import("std");
const support = @import("request");
const Request = support.http_request.Request;
const QueryParams = support.query.QueryParams;

const LegacyFormErrors = error{
    MissingContentType,
    TooManyQueryParameters,
    QueryComponentTooLong,
    UnsupportedMediaType,
};

pub const RouteParamsViewShape = struct {
    names: []const []const u8 = &.{},
    values: []const []const u8 = &.{},
    extra_names: []const []const u8 = &.{},
    extra_values: []const []const u8 = &.{},
};

pub const StreamingRequestShape = struct {
    method: []const u8 = "",
    target: []const u8 = "",
    path: []const u8 = "",
    protocol: []const u8 = "",
    query: []const u8 = "",
    headers: support.fetch.HeadersView = .{ .names = &.{}, .values = &.{} },
    params: RouteParamsViewShape = .{},

    pub fn form(_: *const StreamingRequestShape) error{BodyNotBuffered}!QueryParams {
        return error.BodyNotBuffered;
    }
};

pub const OwnedStreamingRequestShape = struct {
    allocator: std.mem.Allocator,
    storage: []u8,
    header_names: [][]const u8,
    header_values: [][]const u8,
    param_names: [][]const u8,
    param_values: [][]const u8,
    method: []const u8,
    target: []const u8,
    path: []const u8,
    protocol: []const u8,
    query: []const u8,
};

fn narrow_form(request: *const Request) LegacyFormErrors!QueryParams {
    return try request.form();
}

export fn coexistence(request: *const Request, stream: *const StreamingRequestShape) void {
    _ = narrow_form(request) catch |err| switch (err) {
        error.MissingContentType,
        error.TooManyQueryParameters,
        error.QueryComponentTooLong,
        error.UnsupportedMediaType,
        => return,
    };
    _ = stream.form() catch |err| switch (err) {
        error.BodyNotBuffered => return,
    };
}
