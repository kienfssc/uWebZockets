const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const support = b.createModule(.{
        .root_source_file = .{ .cwd_relative = "/workspaces/uWebZockets/.uwz-work/drafts/m2-multipart-verification/src/test_support.zig" },
        .target = target,
        .optimize = optimize,
    });
    const module = b.createModule(.{
        .root_source_file = .{ .cwd_relative = "/workspaces/uWebZockets/.uwz-work/drafts/m2-multipart-verification/src/tests/fuzz_main.zig" },
        .target = target,
        .optimize = optimize,
    });
    module.addImport("test_support", support);
    const tests = b.addTest(.{ .root_module = module, .filters = &.{"fuzz: multipart streaming"} });
    const run = b.addRunArtifact(tests);
    b.step("fuzz", "Run the centralized multipart Smith target").dependOn(&run.step);
}
