import datetime
import json
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
label = sys.argv[1]
argv = sys.argv[2:]
record = {'argv': argv, 'cwd': str(pathlib.Path.cwd()), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
completed = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(root / (label + '.log')).write_bytes(completed.stdout)
record['status'] = completed.returncode
record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(root / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
sys.stdout.buffer.write(completed.stdout)
print('status=' + str(completed.returncode))
sys.exit(completed.returncode)
