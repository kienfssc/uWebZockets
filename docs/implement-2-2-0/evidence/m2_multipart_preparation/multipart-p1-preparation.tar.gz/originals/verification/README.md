The multipart trust-boundary verification slice is frozen against parser SHA256
7ae5d814c323a279ba9b2a89f3cd726c2c8a36cfab397ef5a557e632d6b4cb5e.
Production parser and adapter changes are excluded from this patch.

Apply verification-v3.patch, then verification-v4-dictionary.patch. Their SHA256s
are 9ef60bcf43cfe4340f949a508a92c7b396fa580f633a6046aa830708eca4f3dd and
182d5fec9051a651aa630c01714c864463252ca71d775d8d4c8b6adf37d7354b.
Both passed git apply --check against the integrating root checkout. v1 and v2
remain retained to explain the corrected binary-file diff headers and executable
mode metadata. Owned source bytes changed after v3 only in dictionary escaping.
The source archive verification-v1-sources.tar.gz plus the v4 dictionary delta
reconstructs final owned sources; manifest-v4-dictionary.json binds all 24 files.

The shared harness compares whole, bytewise and uneven chunking. It checks exact
successful payload bytes, normalized metadata, part counts and end state. Failed
parses must agree on the closed error tag and committed metadata; acknowledged
payload prefixes must agree, while differing acceptance quantum near a logical
limit may leave differing prefix lengths. Errors are then terminal across next,
accept_data and finish. Header/carry guards, B+4 carry capacity, virtual replay
bounds, accepted real byte accounting, pending input budget, invalid progress
preservation, zero/partial acknowledgement and alternating poisoned input banks
are checked. Known-valid generated entities supply an independent exact payload
and quoted metadata oracle so mutually consistent parser failures cannot pass.

Every command below has its full exact argv, cwd, timestamps and raw status in
its .json file and complete stdout/stderr in its .log file. evidence-manifest.json
binds those records by SHA256. Compiler mode is ReleaseSafe except the comparison
benchmark, which is ReleaseFast.

| Evidence label | Raw result |
| --- | --- |
| red_missing_parser | status 1, StreamingLimits absent before importing the parser dependency |
| multipart_smith_compile_2 | 1/1 focused centralized fuzz tests passed; 1 fuzz test found |
| native_smith_100k | status 0; Runs 0 -> 100999; Unique runs 0 -> 992; coverage 442/10007; 3/3 build steps and 1/1 tests passed |
| bounded_smoke | status 0; all deterministic seeds and their truncations completed |
| oss_fuzz_objects | status 0; 14/14 steps; fuzzer counter sections present in 6 objects |
| oss_fuzz_smoke | status 0; 14/14 steps; installed multipart_streaming_smoke; multipart smoke run 10s |
| installed_exports | status 0; 0000000000000000 T LLVMFuzzerTestOneInput |
| installed_coverage | status 0; fuzzer counter sections present in 1 object |
| external_build_final | status 0; actual oss-fuzz/build.sh built and packaged all 6 external targets |
| libfuzzer_10000_correct_dictionary | status 0; seed 271828; 9075 registered inline counters; 10000 runs; ft 1907; Done 10000 runs in 30 second(s) |
| large_release_safe | status 0; 1/1 100000000 logical byte test passed |
| fmt, conventions, dictionary_conventions, release_version | status 0; release metadata matches 2.1.6 |

The exact external target enumeration is http_framing, ws_masking, quic_packets,
query_parse, cookie_parse, multipart_streaming. external-enumeration.json binds
executables, seed zip entries, available dictionaries and options. Multipart has
12 seed files totalling 9622 bytes; the largest seed is 7061 bytes and target
max_len is 8192. Split candidates, preamble, epilogue, truncation, many parts,
large parts, quoted metadata and explicit resource refusals are retained.

The first actual libFuzzer run rejected C-style CR/LF dictionary escapes. The
v4 correction uses libFuzzer's hexadecimal byte escapes. That run also exposed
LeakSanitizer process introspection being blocked by the sandbox. The successful
bounded rerun used approved escalation with leak checks enabled; no sanitizer
option or threshold was weakened. AddressSanitizer links the external engine;
Zig ReleaseSafe checks and sanitizer coverage are active, but this does not
claim ASan instrumentation of Zig loads/stores. No parser defect was found.

The large ordinary test feeds exactly 100000000 logical entity bytes from 4 KiB
source blocks, using two 4 KiB relocation banks, a 127-byte slow sink, 256 header
bytes and 9 carry bytes. Every emitted payload byte, metadata, begin/end count,
logical count, hash, storage guards and terminal state is checked. There is one
99999869-byte part. This is a pure parser proof, not an actual transport upload.

benchmark.zig is explicitly a standalone raw proof artifact, outside the public
benchmark suite. Its SHA and executable SHA are bound in manifest-v3.json and
later manifests. It allocates and fills the same complete 100000000-byte fixture
before timing, proves legacy/streaming metadata, count and payload hash equality,
then times the same payload/metadata hash work. The fixture has payload hash
3d5779fe5019c3ac and metadata hash 65d1d2a60ef48ce, with 4096-byte streaming splits.
Two warmups and seven alternating samples per parser are retained verbatim in
benchmark_release_fast.log. Median raw times were legacy 357421486 ns and
streaming 363758402 ns. Host, compiler and CPU evidence is in host.log, cpu.log,
zig_env.log and clang_version.log. This was a shared runner with concurrent
verification, not a quiet-host run. These are parser-only measurements, not an
HTTP throughput guarantee result, an actual upload result, or a speedup claim.

Full integrated source, sanitizer, cross-target, package, h1spec and real-upload
gates remain the root integrator's responsibility. MSan does not instrument Zig
code and cannot be combined with ASan. Root must update the shared graph after
integration and review the final combined diff independently.
