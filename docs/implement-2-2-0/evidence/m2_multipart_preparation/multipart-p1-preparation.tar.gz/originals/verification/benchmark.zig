const std = @import("std");
const multipart = @import("test_support").multipart;

const entity_length = 100_000_000;
const opening = "--large\r\nContent-Disposition: form-data; name=\"upload\"; filename=\"big.bin\"\r\nContent-Type: application/octet-stream\r\n\r\n";
const closing = "\r\n--large--\r\n";
const split = 4096;
const hash_offset = 0xcbf29ce484222325;
const hash_prime = 0x100000001b3;
const Timespec = extern struct { seconds: i64, nanoseconds: i64 };
extern "c" fn clock_gettime(clock_id: c_int, stamp: *Timespec) c_int;
const Stats = struct { parts: usize = 0, bytes: usize = 0, hash: u64 = hash_offset, metadata_hash: u64 = hash_offset };
const ParserKind = enum { legacy, streaming };

pub fn main() !void {
    const body = try std.heap.page_allocator.alloc(u8, entity_length);
    defer std.heap.page_allocator.free(body);
    @memcpy(body[0..opening.len], opening);
    const payload_end = body.len - closing.len;
    for (body[opening.len..payload_end], 0..) |*byte, offset| byte.* = @as(u8, @intCast(offset % 23)) + 'a';
    @memcpy(body[payload_end..], closing);

    // The same complete caller fixture exists before any timing operation.
    const legacy = try parse_legacy(body);
    const streaming = try parse_streaming(body);
    try equal_stats(legacy, streaming);
    if (legacy.parts != 1 or legacy.bytes != entity_length - opening.len - closing.len) return error.SemanticMismatch;
    std.debug.print("fixture_bytes={d} payload_bytes={d} parts={d} hash={x} metadata_hash={x} split={d}\n", .{ body.len, legacy.bytes, legacy.parts, legacy.hash, legacy.metadata_hash, split });
    for (0..2) |round| {
        try sample(body, .legacy, "warmup", round, legacy);
        try sample(body, .streaming, "warmup", round, legacy);
    }
    for (0..7) |round| {
        if (round % 2 == 0) {
            try sample(body, .legacy, "sample", round, legacy);
            try sample(body, .streaming, "sample", round, legacy);
        } else {
            try sample(body, .streaming, "sample", round, legacy);
            try sample(body, .legacy, "sample", round, legacy);
        }
    }
}

fn hash_bytes(initial: u64, bytes: []const u8) u64 {
    var hash = initial;
    for (bytes) |byte| hash = (hash ^ byte) *% hash_prime;
    return hash;
}

fn metadata_hash(initial: u64, name: []const u8, filename: ?[]const u8, content_type: ?[]const u8) u64 {
    var hash = hash_bytes(initial, name);
    hash = hash_bytes(hash, "\x00");
    if (filename) |bytes| hash = hash_bytes(hash, bytes);
    hash = hash_bytes(hash, "\x00");
    if (content_type) |bytes| hash = hash_bytes(hash, bytes);
    return hash_bytes(hash, "\x00");
}

fn parse_legacy(body: []const u8) !Stats {
    var parser = try multipart.Parser.init(body, "large");
    var stats = Stats{};
    while (try parser.next_part()) |part| {
        stats.parts += 1;
        stats.bytes += part.data.len;
        stats.hash = hash_bytes(stats.hash, part.data);
        stats.metadata_hash = metadata_hash(stats.metadata_hash, part.name, part.filename, part.content_type);
    }
    return stats;
}

fn parse_streaming(body: []const u8) !Stats {
    var headers: [256]u8 = undefined;
    var carry: [9]u8 = undefined;
    var parser = try multipart.StreamingParser.init("large", .{ .max_body_bytes = body.len, .max_parts = 1, .max_part_headers = 2 }, .{ .headers = &headers, .carry = &carry });
    var stats = Stats{};
    var offset: usize = 0;
    var end: usize = 0;
    while (true) {
        if (offset == end) end = @min(body.len, offset + split);
        const step = try parser.next(body[offset..end]);
        offset += step.consumed;
        if (step.event) |event| {
            switch (event) {
                .part_begin => |meta| {
                    stats.parts += 1;
                    stats.metadata_hash = metadata_hash(stats.metadata_hash, meta.name, meta.filename, meta.content_type);
                },
                .part_data => |bytes| {
                    stats.bytes += bytes.len;
                    stats.hash = hash_bytes(stats.hash, bytes);
                    offset += try parser.accept_data(bytes.len);
                },
                .part_end => {},
            }
            continue;
        }
        if (offset == body.len) break;
        if (step.consumed == 0) return error.NoProgress;
    }
    try parser.finish();
    if (parser.total_bytes != body.len) return error.AccountingMismatch;
    return stats;
}

fn equal_stats(expected: Stats, actual: Stats) !void {
    if (expected.parts != actual.parts or expected.bytes != actual.bytes or expected.hash != actual.hash or expected.metadata_hash != actual.metadata_hash) return error.SemanticMismatch;
}

fn now() !u64 {
    var stamp: Timespec = undefined;
    if (clock_gettime(1, &stamp) != 0) return error.ClockFailed;
    return @as(u64, @intCast(stamp.seconds)) * 1_000_000_000 + @as(u64, @intCast(stamp.nanoseconds));
}

fn sample(body: []const u8, kind: ParserKind, phase: []const u8, round: usize, expected: Stats) !void {
    const start = try now();
    const stats = switch (kind) {
        .legacy => try parse_legacy(body),
        .streaming => try parse_streaming(body),
    };
    const duration = (try now()) - start;
    try equal_stats(expected, stats);
    std.debug.print("{s} round={d} parser={s} nanoseconds={d} hash={x}\n", .{ phase, round, @tagName(kind), duration, stats.hash });
}
