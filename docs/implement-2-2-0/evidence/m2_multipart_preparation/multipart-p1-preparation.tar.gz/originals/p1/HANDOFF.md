# P1 multipart parser draft v1

Base: `00c85640de26823f02a9c5d1fb82ccecb832aea4`.
Draft: `/workspaces/uWebZockets/.uwz-work/drafts/m2-multipart-parser`.
All unique source and evidence remain under `.uwz-work`; only regenerable Zig caches use `/tmp`.

`p1-v1.patch`, `p1-v1-sources.tar.gz`, and `p1-v1-manifest.json` freeze these files:

- `src/http/multipart_streaming.zig`: pure incremental parser and strict metadata scanner.
- `src/http/multipart.zig`: appended public aliases only.
- `src/tests/multipart_streaming_tests.zig`: 20 focused tests.
- `src/tests/main.zig`: centralized import only.

The manifest records source/patch SHA256 and proof that the legacy multipart file's original 7900-byte prefix is exact. No original root source was edited and no commit was created.

## Evidence

Every command record has exact argv, working directory, exit status, elapsed seconds, and relevant source hashes in its JSON sidecar. Raw output is retained in corresponding `.stdout` and `.stderr` files. `run.py` reproduces the focused suite; `gate.py` records arbitrary checks.

- `red-001` established absence of StreamingParser but also exposed eager C dependency exports in the full test support module. `red-002` exposed module-root restrictions when importing legacy multipart directly. `red-003` is the corrected focused command's expected missing-module failure before implementation. Initial tests were written first; this new parser had no pre-existing runtime defect to reproduce.
- `green-001` records a mutable-slice compiler error from std.mem.trim returning a const slice. The scanner now derives a mutable subspan of its caller-owned header buffer.
- `green-002` passes the initial four tests.
- `expanded-001` records a test pointer-capture typo; `expanded-002` passes nine tests. `expanded-003` passes 17 and `expanded-004` passes 20.
- `fmt-001`: whole-tree `zig fmt src builds examples tests fuzz`, exit 0.
- `conventions-001`: `sh scripts/check_conventions.sh`, exit 0.
- `release-version-001`: `sh scripts/check_release_version.sh`, exit 0.
- `freeze-v1-debug`, `freeze-v1-release-safe`: all 20 focused tests pass in Debug and ReleaseSafe.
- `layout-v1`: native x86_64 parser size 176 bytes, alignment 8; limits 16 bytes, storage descriptor 32 bytes. Caller headers and B+4 carry are separate.
- `zig-env`: exact Zig 0.16.0 toolchain and native target.

The focused suite uses `focused_support.zig`, a minimal facade exposing the same test access path without the full support module's eager C exports. It compiles the actual standalone production parser, but does not prove the combined public namespace or C graph. Root integration must run those gates.

## Contracts and limits

The copied boundary is at most 70 bytes. Init requires positive part and field limits, nonempty header storage, disjoint header/carry slices, and at least B+4 carry bytes. Only that carry prefix is used. Headers exclude the final CRLFCRLF. The u64 entity budget includes preamble, envelope, headers, payload and epilogue. Data offers are preflighted before acknowledgement can expose effects.

Candidates are reconstructed from known boundary/literal bytes and scalar cursors. A false candidate with one accepted '-' suffix has a virtual replay length of B+5, emitted in fragments of at most B+4. This is not extra payload storage. Replay advances real input by zero and precedes acceptance of the deciding mismatch. A held suffix CR can become the next candidate's opening CR. No input pointer is retained.

The strict new scanner validates all fields and counts ignored fields. It rejects duplicate disposition/type fields, duplicate name/filename parameters, invalid tokens/controls/folding and missing disposition/name; quoted semicolons and pairs decode within their original header spans. Empty-present names are accepted. Filenames remain opaque.

The exact ordinary CRLF / closing '--' suffix subset and ignored-but-counted epilogue match ADR 0011. MP-L1 ordinary delimiter transport padding remains unsupported. No general MIME conformance claim, transport integration, file helper or M2 completion is made.

## Remaining root integration

Independent review and verification may require versioned fixes. Full `zig build test --summary all`, h1spec, C sanitizers, cross targets, package consumers, graph update, fuzz integration, 100 MB proof and deterministic comparison remain unrun here. The fuzz agent owns independent parser harness coverage, and the root owns P2 and integration. Do not infer those gates from the focused green results.

Protocol sources: accepted ADR 0011; RFC 2046 section 5.1.1 (boundary grammar and known subset limitation), RFC 7578 section 4.2 (disposition/name and filename metadata), RFC 9110 sections 5.6.2 and 5.6.4 (tokens and quoted pairs). Official RFC text was checked during implementation.
