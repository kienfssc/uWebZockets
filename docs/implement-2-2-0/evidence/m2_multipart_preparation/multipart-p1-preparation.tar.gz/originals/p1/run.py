import hashlib,json,pathlib,subprocess,sys,time
root=pathlib.Path('/workspaces/uWebZockets/.uwz-work/drafts/m2-multipart-parser')
out=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/multipart-parser')
label=sys.argv[1]
argv=['/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig','test','--cache-dir','/tmp/uwz-multipart-parser-cache','--global-cache-dir','/tmp/uwz-multipart-parser-global','--dep','test_support','-Mroot=src/tests/multipart_streaming_tests.zig','--dep','multipart','-Mtest_support=/workspaces/uWebZockets/.uwz-work/evidence/multipart-parser/focused_support.zig','-Mmultipart=src/http/multipart_streaming.zig']+sys.argv[2:]
files=['src/http/multipart.zig','src/http/multipart_streaming.zig','src/tests/multipart_streaming_tests.zig','src/tests/main.zig']
manifest={'argv':argv,'cwd':str(root),'source_sha256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files if (root/f).exists()}}
start=time.monotonic();p=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);manifest.update(exit_status=p.returncode,elapsed_seconds=time.monotonic()-start)
(out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);(out/(label+'.json')).write_text(json.dumps(manifest,indent=2)+'\n');print(p.stderr.decode()[-8000:]);print('exit_status:',p.returncode);sys.exit(p.returncode)
