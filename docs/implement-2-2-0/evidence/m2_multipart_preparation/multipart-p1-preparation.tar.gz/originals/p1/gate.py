import hashlib,json,pathlib,subprocess,sys,time
root=pathlib.Path('/workspaces/uWebZockets/.uwz-work/drafts/m2-multipart-parser');out=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/multipart-parser')
label=sys.argv[1];argv=sys.argv[2:];start=time.monotonic();p=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
files=['src/http/multipart.zig','src/http/multipart_streaming.zig','src/tests/multipart_streaming_tests.zig','src/tests/main.zig']
manifest={'argv':argv,'cwd':str(root),'exit_status':p.returncode,'elapsed_seconds':time.monotonic()-start,'source_sha256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files if (root/f).exists()}}
(out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);(out/(label+'.json')).write_text(json.dumps(manifest,indent=2)+'\n');print(p.stdout.decode()[-2000:]);print(p.stderr.decode()[-6000:]);print('exit_status:',p.returncode);sys.exit(p.returncode)
