const std = @import("std");
const multipart = @import("multipart");

test "multipart parser layout evidence" {
    std.debug.print("StreamingParser bytes={d} alignment={d}\nStreamingLimits bytes={d}\nStreamingStorage bytes={d}\n", .{ @sizeOf(multipart.StreamingParser), @alignOf(multipart.StreamingParser), @sizeOf(multipart.StreamingLimits), @sizeOf(multipart.StreamingStorage) });
}
