import gzip
import hashlib
import io
import json
import pathlib
import re
import subprocess
import sys
import tarfile


def digest(content):
    return hashlib.sha256(content).hexdigest()


stage = pathlib.Path(__file__).resolve().parent.parent
delivery = stage.parent
originals = json.loads((stage / 'originals-inventory.json').read_text())
original_root = pathlib.Path(originals['original_root'])
for original, metadata in originals['original_files'].items():
    if digest((original_root / original).read_bytes()) != metadata['sha256']:
        raise ValueError('original changed: ' + original)
    if digest((stage / metadata['bundle_path']).read_bytes()) != metadata['sha256']:
        raise ValueError('copied original changed: ' + original)
for source in (stage / 'originals').rglob('*.tar.gz'):
    with tarfile.open(source, 'r:gz') as nested:
        names = set()
        for member in nested.getmembers():
            name = member.name
            if not member.isfile() or name in names or name.startswith('/') or any(piece in ('', '.', '..') for piece in name.split('/')):
                raise ValueError('unsafe original source archive: ' + str(source))
            names.add(name)
files = sorted(path for path in stage.rglob('*') if path.is_file() and path != stage / 'SHA256SUMS')
lines = []
for path in files:
    if path.is_symlink():
        raise ValueError('symlink in staging: ' + str(path))
    name = str(path.relative_to(stage))
    if not re.fullmatch(r'[A-Za-z0-9_./-]+', name):
        raise ValueError('unsafe staging path: ' + name)
    lines.append(digest(path.read_bytes()) + '  ' + name)
(stage / 'SHA256SUMS').write_text('\n'.join(lines) + '\n')
files.append(stage / 'SHA256SUMS')
files.sort()
archive = delivery / 'multipart-p1-preparation.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as target:
            for path in files:
                content = path.read_bytes()
                member = tarfile.TarInfo(str(path.relative_to(stage)))
                member.size = len(content)
                member.mode = 0o644
                member.mtime = 0
                member.uid = 0
                member.gid = 0
                member.uname = ''
                member.gname = ''
                target.addfile(member, io.BytesIO(content))
freezes = json.loads((stage / 'source-freezes.json').read_text())
evidence = json.loads((stage / 'originals/verification/evidence-manifest.json').read_text())
p1 = json.loads((stage / 'originals/p1/p1-v1-manifest.json').read_text())
p2_tests = json.loads((stage / 'originals/p1/p1-v2-tests-manifest.json').read_text())
patches = [
    ('originals/p1/p1-v1.patch', p1['patch_sha256']),
    ('originals/p1/p1-v2-tests.patch', p2_tests['delta_patch_sha256']),
    ('originals/verification/verification-v3.patch', evidence['previous_patch_sha256']),
    ('originals/verification/verification-v4-dictionary.patch', evidence['patch_sha256']),
]
for name, expected in patches:
    if digest((stage / name).read_bytes()) != expected:
        raise ValueError('patch identity mismatch: ' + name)
manifest = {
    'kind': 'multipart P1 preparation evidence for a later commit',
    'base_revision': p1['base_commit'],
    'scope': 'Frozen P1 parser v1 plus v2 focused tests and final verification v4; archive preparation integrity only.',
    'excluded_scope': ['Root canonical matrix', 'Incomplete parent jobs', 'Live transport upload proof', 'P2 adapter', 'Independent review transcripts', 'Commits, pushes or remote pull requests'],
    'archive': {
        'filename': archive.name,
        'sha256': digest(archive.read_bytes()),
        'bytes': archive.stat().st_size,
        'member_count': len(files),
        'uncompressed_member_bytes': sum(path.stat().st_size for path in files),
        'regular_files_only': True,
        'safe_unique_relative_paths_only': True,
        'members': {str(path.relative_to(stage)): {'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes())} for path in files},
    },
    'inventory': {'member': 'SHA256SUMS', 'sha256': digest((stage / 'SHA256SUMS').read_bytes()), 'coverage': 'Every archive member except the inventory itself; inventory digest is bound here and by the archive.'},
    'patch_order': [{'member': name, 'sha256': expected} for name, expected in patches],
    'source_freezes': freezes,
    'original_evidence': originals,
    'source_authority': {
        'p1_production_and_v1_tests': p1['files'],
        'p1_v2_test_sha256': p2_tests['tests_sha256'],
        'p1_v2_production_unchanged_sha256': p2_tests['production_source_sha256'],
        'fuzz_v4_owned_hashes': evidence['files'],
        'fuzz_parser_dependency': evidence['parser_dependency'],
    },
    'verification_command_records': evidence['evidence_commands'],
    'focused_results': {'native_smith': evidence['native_fuzz_raw_report'], 'external_llvm': evidence['llvm_fuzz_raw_report'], 'large_proof': 'originals/verification/large_release_safe.json'},
    'benchmark': {'metadata': evidence['benchmark'], 'summary': json.loads((stage / 'originals/verification/benchmark-summary.json').read_text()), 'trust_limit': 'Standalone parser-only exploratory measurements on a shared runner; no speed threshold, quiet-host, root HTTP guarantee or actual upload claim.'},
    'omitted_artifact_inventory': {'member': 'exclusions.json', 'sha256': digest((stage / 'exclusions.json').read_bytes())},
    'binary_inspection': json.loads((stage / 'inspections/summary.json').read_text()),
    'trust_limits': ['Original evidence is copied without rewriting; prior failures remain visible.', 'Original records contain captured absolute paths and must be explicitly rebased for replay.', 'Historical provisional source states, binary byte identity and evolved fuzz corpus identity are not universally reproducible from final sources.', 'Zig ReleaseSafe and sanitizer coverage do not establish ASan instrumentation of Zig loads/stores; MSan does not instrument Zig and cannot combine with ASan.', 'MP-L1 ordinary delimiter transport padding remains unsupported; no general MIME conformance claim.', 'Independent review evidence remains separate with the root integrator.'],
}
manifest_path = delivery / 'manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
verification_argv = [sys.executable, '-B', str(stage / 'tools/verify_archive.py'), str(archive), '--outer-manifest', str(manifest_path)]
verification_run = subprocess.run(verification_argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(delivery / 'archive-verification.stdout').write_bytes(verification_run.stdout)
(delivery / 'archive-verification.stderr').write_bytes(verification_run.stderr)
(delivery / 'archive-verification-command.json').write_text(json.dumps({'argv': verification_argv, 'cwd': str(pathlib.Path.cwd()), 'status': verification_run.returncode}, indent=2) + '\n')
if verification_run.returncode != 0:
    raise ValueError('archive verification failed')
report = json.loads(verification_run.stdout)
(delivery / 'archive-verification.json').write_text(json.dumps(report, indent=2) + '\n')
for name in ['README.md', 'HANDOFF.md']:
    preface = 'Paths in this draft document are archive-relative; in this preparation directory they resolve under bundle/.\n\n'
    (delivery / name).write_text(preface + (stage / name).read_text())
print(json.dumps(report, indent=2))
