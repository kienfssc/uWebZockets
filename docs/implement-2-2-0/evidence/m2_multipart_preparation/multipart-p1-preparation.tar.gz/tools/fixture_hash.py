import hashlib
import json

opening = b'--large\r\nContent-Disposition: form-data; name="upload"; filename="big.bin"\r\nContent-Type: application/octet-stream\r\n\r\n'
closing = b'\r\n--large--\r\n'
entity_length = 100_000_000
payload_length = entity_length - len(opening) - len(closing)
pattern = bytes(range(ord('a'), ord('a') + 23)) * 4096
hash_state = hashlib.sha256()
hash_state.update(opening)
remaining = payload_length
while remaining:
    count = min(remaining, len(pattern))
    hash_state.update(pattern[:count])
    remaining -= count
hash_state.update(closing)
print(json.dumps({
    'entity_bytes': entity_length,
    'payload_bytes': payload_length,
    'derived_fixture_sha256': hash_state.hexdigest(),
    'provenance': 'Streaming regeneration from the frozen benchmark formula; no original retained fixture file is claimed.',
}, indent=2))
