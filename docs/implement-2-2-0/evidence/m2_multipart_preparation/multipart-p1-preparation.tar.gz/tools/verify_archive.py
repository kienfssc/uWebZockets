import argparse
import hashlib
import json
import pathlib
import re
import tarfile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(content):
    return hashlib.sha256(content).hexdigest()


def verify(archive, outer_manifest=None):
    contents = {}
    with tarfile.open(archive, 'r:gz') as source:
        for member in source.getmembers():
            name = member.name
            pieces = name.split('/')
            require(member.isfile(), 'non-regular member: ' + name)
            require(bool(re.fullmatch(r'[A-Za-z0-9_./-]+', name)), 'unsafe path characters: ' + name)
            require(all(piece not in ('', '.', '..') for piece in pieces), 'unsafe path component: ' + name)
            require(not pathlib.PurePosixPath(name).is_absolute(), 'absolute member: ' + name)
            require(name not in contents, 'duplicate member: ' + name)
            contents[name] = source.extractfile(member).read()
    require('SHA256SUMS' in contents, 'missing member inventory')
    inventory = {}
    for line in contents['SHA256SUMS'].decode().splitlines():
        expected, name = line.split('  ', 1)
        require(bool(re.fullmatch(r'[0-9a-f]{64}', expected)), 'invalid inventory digest')
        require(name not in inventory, 'duplicate inventory path: ' + name)
        inventory[name] = expected
    require(set(inventory) == set(contents) - {'SHA256SUMS'}, 'inventory member set mismatch')
    for name, expected in inventory.items():
        require(digest(contents[name]) == expected, 'member digest mismatch: ' + name)
    originals = json.loads(contents['originals-inventory.json'])
    for original, record in originals['original_files'].items():
        content = contents[record['bundle_path']]
        require(len(content) == record['bytes'], 'original size mismatch: ' + original)
        require(digest(content) == record['sha256'], 'original digest mismatch: ' + original)
    freezes = json.loads(contents['source-freezes.json'])
    source_count = 0
    for version, record in freezes.items():
        for name, metadata in record['files'].items():
            content = contents['frozen/' + version + '/' + name]
            require(digest(content) == metadata['sha256'], 'source freeze mismatch: ' + version + '/' + name)
            require(len(content) == metadata['bytes'], 'source freeze size mismatch: ' + name)
            source_count += 1
    evidence = json.loads(contents['originals/verification/evidence-manifest.json'])
    require(len(evidence['evidence_commands']) == 39, 'verification record count changed')
    for label, record in evidence['evidence_commands'].items():
        for field, checksum in [('record', 'record_sha256'), ('raw_output', 'raw_sha256')]:
            name = 'originals/verification/' + record[field]
            require(digest(contents[name]) == record[checksum], 'verification record mismatch: ' + label)
    inspection = json.loads(contents['inspections/summary.json'])
    expected_object = evidence['artifact_sha256']['install/oss-fuzz/multipart_streaming.o']
    require(inspection['object_sha256'] == expected_object, 'inspection object identity changed')
    for label, record in inspection['commands'].items():
        require(record['object_sha256'] == expected_object, 'inspection command identity changed: ' + label)
        for stream in ['stdout', 'stderr']:
            require(digest(contents['inspections/' + label + '.' + stream]) == record[stream + '_sha256'], 'inspection output mismatch: ' + label)
    archive_digest = digest(pathlib.Path(archive).read_bytes())
    if outer_manifest:
        outer = json.loads(pathlib.Path(outer_manifest).read_text())
        require(outer['archive']['sha256'] == archive_digest, 'outer archive digest mismatch')
        require(outer['archive']['bytes'] == pathlib.Path(archive).stat().st_size, 'outer archive size mismatch')
        require(outer['archive']['member_count'] == len(contents), 'outer member count mismatch')
        require(outer['source_freezes'] == freezes, 'outer source authority mismatch')
        require(outer['original_evidence'] == originals, 'outer original evidence mismatch')
        for name, record in outer['archive']['members'].items():
            require(name in contents and digest(contents[name]) == record['sha256'] and len(contents[name]) == record['bytes'], 'outer member mismatch: ' + name)
        require(set(outer['archive']['members']) == set(contents), 'outer member set mismatch')
    return {
        'archive_sha256': archive_digest,
        'archive_bytes': pathlib.Path(archive).stat().st_size,
        'safe_unique_regular_members': len(contents),
        'inventory_checksums_verified': len(inventory),
        'original_evidence_files_verified': len(originals['original_files']),
        'verification_command_records_verified': len(evidence['evidence_commands']),
        'frozen_source_members_verified': source_count,
        'inspection_object_sha256': expected_object,
        'outer_manifest_verified': bool(outer_manifest),
        'scope': 'Archive integrity and frozen focused evidence only; no root canonical matrix, P2 or live upload proof.',
        'status': 0,
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('archive', type=pathlib.Path)
    parser.add_argument('--outer-manifest', type=pathlib.Path)
    arguments = parser.parse_args()
    print(json.dumps(verify(arguments.archive, arguments.outer_manifest), indent=2))
