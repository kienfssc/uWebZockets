The authoritative historical commands are the original JSON sidecars. All 39
verification command/output pairs are copied byte-for-byte and hash-checked
against originals/verification/evidence-manifest.json. Parser command sidecars
retain stdout and stderr separately, plus modes and source hashes where recorded.

Use a separate checkout of base revision
00c85640de26823f02a9c5d1fb82ccecb832aea4, apply the four patches listed in
HANDOFF.md, and provide the recorded Zig 0.16.0 compiler and dependencies.
The full base checkout is required for standard-library imports and the project
build graph. Frozen files are versioned snapshots rather than an assembled
replacement repository. Existing project executable modes come from the base
and patches, not the decoded 0644 archival source copies.

Original commands use absolute paths under /workspaces/uWebZockets/.uwz-work.
For a new location, replace only the checkout/evidence/cache prefixes with the
new locations and document that rebasing. Do not overwrite originals or treat
an edited historical record as original evidence. The focused support facade
uses an explicit module import, avoiding unrelated native C graphs.

Focused P1 suite: reproduce originals/p1/freeze-v2-debug.json and
originals/p1/freeze-v2-release-safe.json using the final v2 test suite,
originals/p1/focused_support.zig and the frozen production parser module.
originals/p1/run.py captures the exact focused command; gate.py captures checks.

Central multipart Smith test: originals/verification/multipart_smith_compile_2.json
records the normal corpus pass. native_smith_100k.json records the dedicated
centralized multipart test through the retained smith_build.zig, using
--fuzz=100K and ReleaseSafe. Rebase the two source paths in a new working copy of
smith_build.zig when needed. This focused run does not imply that the root's full
canonical fuzz graph was executed.

Large logical-byte proof: originals/verification/large_release_safe.json records
the pure ReleaseSafe command using the frozen multipart_large_tests.zig file
under frozen/verification-v4/src/tests and the reconstructed test_support module.
Source storage consists of
4KiB blocks, two 4KiB relocation banks, a 127-byte sink, 256 header bytes and
9 carry bytes. The exact logical length includes envelope and headers.

Object and smoke graphs: originals/verification/oss_fuzz_objects.json and
oss_fuzz_smoke.json record project build invocations, prefix and cache paths.
installed_exports.json and installed_coverage.json record the inspected installed
object. Additional read-only inspection commands and tool versions are retained
under inspections. The omitted object's digest is checked before and after the
new preparation inspections; no binary is substituted into the archive.

External packaging: originals/verification/external_build_final.json records the
exact env, compilers, link flags and oss-fuzz/build.sh invocation. Create a fresh
external source alias and output/work directories at the rebased locations.
The recorded build uses the existing Zig sanitizer-coverage registration shim;
a frozen base copy is under context/base/oss-fuzz. Small generated dictionary,
options and seed zip files are included under generated/external-packaging.

External runtime: originals/verification/libfuzzer_10000_correct_dictionary.json
records the bounded command with seed 271828, max_len 8192 and the corrected
dictionary. Start with a fresh empty output corpus and the original 12 seed
files. LeakSanitizer required approved sandbox escalation for process
introspection in the captured environment. Keep leak checks enabled; a new host
may need an equivalent permitted execution context. Do not infer ASan memory
instrumentation of Zig-generated loads/stores from linking the external engine.

Benchmark: originals/verification/benchmark_compile_2.json and
benchmark_release_fast.json record build and execution. benchmark.zig builds
and fills the complete 100000000-byte fixture before timing; no fixture file is
needed. Both parsers perform the same hashing work. The same fixture's derived
SHA256 can be recomputed without storing 100MB using tools/fixture_hash.py.
benchmark-summary.json and the raw log retain semantic counts and all samples.
Repeated measurements may differ on another shared runner and have no numerical
speed threshold. Historical binary byte identity is not promised across paths,
compiler/linker environments or unfrozen provisional source generations.

Integrity checks after obtaining the archive:

    python3 tools/verify_archive.py /path/to/multipart-p1-preparation.tar.gz

The helper validates safe unique relative regular members, the complete member
SHA256 inventory, original evidence hashes and every declared frozen source hash.
It does not execute the archived test commands or confer root integration status.
