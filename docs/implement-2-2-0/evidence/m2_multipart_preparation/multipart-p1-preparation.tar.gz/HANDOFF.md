Prepared P1 source and focused verification only. Keep this preparation separate
from the root canonical matrix, P2 multipart sink/transport work and live upload
proof. Parent jobs still in progress at preparation time are not represented.
The root integrator will store independent review evidence separately.

Base revision: 00c85640de26823f02a9c5d1fb82ccecb832aea4.
Apply these retained patches to a suitable checkout, in order:

1. originals/p1/p1-v1.patch
   SHA256 d352bb58b6f0555585681dfa840786c11561fb4684e2a1d8322e5e4babdffc53
2. originals/p1/p1-v2-tests.patch
   SHA256 bce8ab45ba1e2cddf4cf8fd76a5a52949bd3ff9e16f465bfa9da3cbaf1cedb52
3. originals/verification/verification-v3.patch
   SHA256 9ef60bcf43cfe4340f949a508a92c7b396fa580f633a6046aa830708eca4f3dd
4. originals/verification/verification-v4-dictionary.patch
   SHA256 182d5fec9051a651aa630c01714c864463252ca71d775d8d4c8b6adf37d7354b

P1 production parser SHA256:
7ae5d814c323a279ba9b2a89f3cd726c2c8a36cfab397ef5a557e632d6b4cb5e.
The public multipart facade SHA256 is
92f080b5aa054787380f977320aa48a3de3bd9ab940f7254e7c9b60633845a67.
The final focused parser suite SHA256 is
2236d7446df45a92aa99f68fa5fc55e4fadd41fd3697f0e854c0a7f34889c59e.
All 24 final verification-owned hashes are preserved in source-freezes.json and
originals/verification/manifest-v4-dictionary.json. Shared imports and build
mutations still require the root's serialized integration.

The malformed early verification patch and its raw failure remain preserved.
v3 corrects staging prefixes and executable-mode diff metadata without source
byte changes. v4 changes only libFuzzer dictionary CR/LF escapes to hexadecimal
byte escapes. The original runtime failure also records LeakSanitizer sandbox
introspection failure. The corrected successful run used approved escalation
with leak checks enabled; no test, threshold or sanitizer option was weakened.
The earlier replay-capacity harness assertion was corrected because virtual
reconstruction can represent B+5 bytes while each fragment stays within B+4
caller storage. Its original panic and explanation remain preserved.

Read original command sidecars before replay: they preserve the exact argv,
cwd, modes, statuses and raw outputs, including setup/compile failures. The
focused facade and launchers are under originals/p1/focused_support.zig,
originals/p1/run.py, originals/p1/gate.py,
originals/verification/smith_build.zig and originals/verification/run.py.
Absolute paths reflect their original workspace and must be rebased explicitly.
The reference base checkout and pinned Zig/Clang dependencies are not vendored
into this small evidence archive.

Passed preparation evidence, with complete raw output retained:

- P1 v2 parser suite: 22/22 Debug and 22/22 ReleaseSafe.
- Native multipart Smith: 100999 runs, 992 unique, 442/10007 coverage counters.
- ReleaseSafe six-object coverage/export and six-target smoke graphs: 14/14 each.
- Actual external packaging: six executable targets, bounded seed zip archives,
  per-target options and applicable dictionaries.
- External multipart libFuzzer: 10000 runs, seed 271828, 9075 inline counters,
  1907 reported features, status 0 with leak checks enabled.
- Fixed-block 100000000 logical-byte pure parser proof: 1/1 ReleaseSafe.
- Formatting, conventions and release-version checks: status 0.

The 100MB benchmark has two warmups and seven alternating samples per parser.
Raw output, semantic counts, source, host, CPU, tool versions and configuration
are preserved. It is a parser-only comparison with no speed acceptance bar.
No actual transport upload, package consumer, sanitizer matrix, cross-target,
h1spec or whole root fuzz/test result is claimed by this bundle.

Before using the result in a later commit, integrate the shared files, retain
root-level source provenance, complete the canonical checks applicable to the
combined tree, update the graph and attach independent review and transport
proof separately. This archive does not authorize or perform a commit or push.
