This is the P1 multipart parser preparation bundle for a later reviewed commit.
It preserves the frozen parser, focused tests and trust-boundary verification
sources with their original evidence. It is not the root canonical matrix,
P2 adapter evidence, a live upload proof, or completion of the multipart feature.
No commits, pushes or remote review operations were performed to prepare it.

Start with HANDOFF.md for patch order and scope, REPRODUCE.md for replay notes,
and source-freezes.json for byte-level source authority. The original evidence
files are copied unchanged under originals/p1 and originals/verification.
Original paths and SHA256s are bound in originals-inventory.json. The exact
39 verification command records and their complete raw outputs are preserved,
including failures. No successful status was inferred from an unrun command.

The source versions are deliberately separate. frozen/p1-v1 contains the parser
and its original 20-test freeze. frozen/p1-v2-tests contains the later 22-test
suite; production bytes did not change. frozen/verification-v4 contains the
final 24 verification-owned files, including the corrected dictionary. Shared
main.zig files reflect their individual author's freeze, not a new combined
root tree. The original source archives remain available with their original
member metadata; decoded source copies use archival mode 0644. Apply patches
to preserve the project's executable modes.

The focused results include 22 parser tests in Debug and ReleaseSafe; the native
Smith run reports 100999 runs; the external libFuzzer target completed 10000 runs
with seed 271828 and 9075 registered inline counters. The object and smoke graphs
each report 14/14 successful steps in ReleaseSafe. The 100000000 logical-byte
ordinary test checks every emitted payload byte, metadata, counts, hash and
bounded storage from fixed small blocks. These results apply to the recorded
focused configurations; they do not substitute for integrated transport gates.

The parser implements ADR 0011's exact ordinary CRLF / closing double-dash
suffix subset. Ordinary delimiter transport padding remains unsupported under
MP-L1. No general MIME or RFC 2046 conformance claim is made. The original
7900-byte legacy multipart prefix is preserved exactly by the P1 freeze.

The 100MB comparison is a standalone raw proof artifact. Both parsers consume
the same complete fixture, prepared before timing, and perform the same payload
and metadata hash work. The fixture contains one 99999869-byte payload with hash
3d5779fe5019c3ac and metadata hash 65d1d2a60ef48ce. Streaming splits are 4096
bytes. ReleaseFast warmups and all seven samples per parser remain verbatim.
Median times were legacy 357421486 ns and streaming 363758402 ns on a shared
runner with concurrent verification. No speed threshold, speedup, quiet-host,
HTTP throughput guarantee or actual upload claim follows from these samples.

Generated binaries, objects, evolved fuzz corpora, checkout symlinks and the
100MB fixture are omitted. exclusions.json lists hashes and original command
records for omitted artifacts and explains reproduction limits. The fixture's
SHA256 was computed during preparation by streaming regeneration of its frozen
formula; it is explicitly not a digest read from an original retained fixture
file. No giant fixture or compiler cache is embedded.

inspections contains read-only symbol, section and entry-point disassembly
outputs bound to the omitted installed multipart object's SHA256. Those checks
establish structural ABI and coverage facts, not a proof of every memory or
protocol property. The external engine linked AddressSanitizer with leak checks
enabled; Zig ReleaseSafe and coverage do not imply ASan instrumentation of Zig
loads/stores. MSan does not instrument Zig and cannot be combined with ASan.

Every archive member is a safe, unique relative regular file. SHA256SUMS covers
all other members; the outer manifest binds the inventory itself, archive hash,
size, members, original evidence and source freezes. The independent review
transcripts, root matrix runs and live upload evidence are intentionally not
fabricated or included; the root integrator owns their separate delivery.
