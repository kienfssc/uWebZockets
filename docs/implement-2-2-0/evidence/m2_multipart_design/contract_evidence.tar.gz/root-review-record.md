# Incremental multipart contract decision

Date: 2026-10-26. Integrator-authored record, not test output.

Independent reviewer m6_gro_review checked the frozen architect proposal and
accepted outer ADR0008. One P2 assigned BodyNotBuffered to legacy Request.multipart.
The corrected derivative separates unchanged legacy Request/OwnedRequest and
Parser.init error sets from the new typed-view refusals and refreshes stale
ADR references. Empty-present name and limits-before-sink-effects checks remain
explicit. The original proposal is unchanged.

Root recorded the contract in ADR0011. Compression review additionally required
its explicit carry.len >= boundary.len + 4 init minimum and B+4/B+3 acceptance.
Root added those plus the original stable/exclusive/non-overlapping storage rule.
Bounded re-review reported no remaining actionable findings: accepted-prefix
accounting, false-prefix replay, no-input EOF and terminal ownership wording
retain the reviewed meaning. Root accepts the contract.

This is contract evidence only. Actual implementation, old compiler consumers,
split/pause/carry/lifetime tests, bounded 100 MB input, same-input comparison,
fuzzing and the actual upload transport gates remain mandatory. Parser-only
preparation may run isolated; production integration follows ADR0008 gates.
