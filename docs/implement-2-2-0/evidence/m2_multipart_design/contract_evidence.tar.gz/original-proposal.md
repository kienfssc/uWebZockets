# M2-2 incremental multipart contract proposal

Status: Proposed, not accepted or implemented. Prepared 2026-10-26 UTC by the
read-only architect for root review. No source edits, builds, test execution,
dependency changes, remote writes, or transport-conformance claims accompany it.
Root owns integration. M1 closure and the accepted ADR 0008 transport sequence
remain prerequisites to production multipart integration.

## Hard decisions and counterexamples

1. **The pure parser returns one event at a time; callbacks and I/O live outside
   it.** A parser that calls an arbitrary file writer is no longer independently
   fuzzable and mixes filesystem failure with multipart recognition. The existing
   `uz.multipart` namespace gains the pure contract; a separate concrete sink
   adapter owns callback sequencing, progress validation, and part cleanup.
2. **Payload emission does not imply input acceptance.** An input-backed data
   event stays unconsumed until its accepted prefix is acknowledged. Otherwise a
   sink accepting 3 of 20 bytes can lose 17 bytes when the HTTP owner reuses its
   ingress window. The core keeps pending origin/count, not a retained input
   pointer; the caller retains and reoffers the exact unaccepted input suffix.
3. **Do not consume the deciding mismatch while replaying an ambiguous prefix.**
   Suppose one HTTP chunk ends with `CRLF--boundary` and the next starts `X`.
   Those delimiter-looking bytes are payload. Replay them before consuming `X`.
   If the part sink pauses, `X` remains real retained input for `BodyControl`
   resume. This rule applies to partial prefix and one-byte suffix states too.
   Consuming `X` first can leave deferred application data at HTTP EOF; ADR 0008
   permits resume to go straight to `BodySink.end`, which cannot pause.
4. **EOF never flushes unresolved data through a callback.** EOF with a partial
   delimiter, incomplete headers, no closing delimiter, or pending payload is
   `IncompleteMultipartBody`. `finish` rejects it and the effect adapter aborts
   its accepted active part once. It cannot try a potentially pausing write from
   `BodySink.end`. That end owns cleanup even on error; no outer cancel follows.
5. **Begin/end metadata events are committed once before returning paused.** A
   paused `begin_part` is not invoked again. A paused `end_part` has already
   completed part cleanup and is not followed by `cancel_part`. Only a payload
   event can have an unaccepted prefix. No parse-ahead queues another event.
6. **The B+4 limit covers actual raw-body carry.** B is at most 70. Retaining a
   complete `CRLF--boundary` plus two suffix bytes would require B+6 and is
   rejected as a design. Once the complete known prefix matches, represent it
   with a phase/replay cursor and the parser's immutable boundary configuration;
   reuse the same carry for at most one undecided suffix byte. Every literal and
   configuration-backed replay fragment must be accounted for in split tests.
7. **Legacy permissiveness is not silently hardened.** Existing `Parser`,
   `Part`, `ChunkIterator`, `boundary_from_content_type`, and `Request.multipart`
   retain their current buffered behavior. The new streaming contract explicitly
   rejects duplicate Content-Disposition and malformed metadata. Shared use of
   the old first-match header/parameter helpers would accidentally preserve
   ambiguity in the new trust boundary. Any legacy hardening needs its own
   reviewed compatibility change.
8. **Delimiter transport padding is a named initial limit.** Root accepts this
   limit for the proposal: ordinary delimiter suffixes are exactly CRLF, closing
   suffixes exactly `--`; a boundary prefix followed by another suffix remains
   payload. No blanket RFC 2046 conformance claim is made. Padding is not solved
   with a second carry buffer, an unbounded scan, or a hidden storage allowance.
9. **A filename is metadata, never an authority to open a path.** Optional file
   writing receives an already-open caller-owned file and explicit `std.Io`.
   It never opens, creates, joins, renames, deletes, or commits a filename supplied
   by the multipart body. Caller policy owns destination selection and rollback.

## Assumptions, authority, and source evidence

- Accepted [ADR 0008](/workspaces/uWebZockets/docs/adr/0008-request-body-streaming.md)
  defines the body lifecycle. In the repository the relevant anchors are
  `docs/adr/0008-request-body-streaming.md:78` (successful begin/one terminal),
  `:83` (accepted-prefix and explicit pause), `:89` (end owns cleanup), `:104`
  (inline controls), `:116` (pending end with no input), `:128` (full-body helper
  guards), and `:255` (sequential transport/multipart implementation).
- `2.2.0-TODO.md:496` M2-2 requires arbitrary splits, maximum boundary 70,
  carry at most B+4, bounded headers/part counts, caller logical limits,
  metadata/data borrowing, a named streaming API, sink pauses/errors, fuzzing,
  and deterministic large-input and throughput evidence.
- The reviewed common draft is at `/tmp/uwz-m2-common-draft`. Its
  `src/http/request_body.zig` supplies named `BodyReadiness`, `BodyProgress`,
  `BodySink`, `BodyControl`, `BodyCancelReason`, and `validate_progress`.
  Draft tests are parent-reported evidence, not tests run for this proposal.
- `src/http/multipart.zig:33` is the full-body parser. Its next part returns
  borrowed complete data, while `:144` recognizes only CRLF/`--` suffixes and
  skips false prefixes. `:164` and `:179` choose first matching header and
  parameter, skip malformed header lines, split parameters on semicolons, and
  do not explicitly reject duplicates. `:199` validates the existing boundary
  alphabet and 70-byte maximum.
- `src/tests/framework_tests.zig:70` requires `CRLF--abcX is payload` to remain
  inside part data. `src/tests/http_tests.zig:316` accepts preamble/epilogue.
  `src/tests/fuzz_main.zig:319` exercises the full-body multipart API with Smith.
  This full-body baseline must continue to pass unchanged.
- `fuzz/http_framing.zig` does not fuzz multipart. There is no current LLVM
  multipart target. `builds/fuzzing.zig` enumerates five objects, coverage
  inputs, and smoke binaries; `oss-fuzz/build.sh` enumerates those same five
  targets and packages corpus/dictionaries/options. New multipart coverage must
  reach every one of those boundaries, not just a local smoke executable.
- [RFC 7578 sections 4.1 and 4.2](https://www.rfc-editor.org/rfc/rfc7578.html#section-4.2)
  supply the form-data boundary, disposition/name, and untrusted filename basis.
  [RFC 2046 section 5.1.1](https://www.rfc-editor.org/rfc/rfc2046.html#section-5.1.1)
  defines delimiter CRLF ownership, the 70-character limit, preamble/epilogue,
  and transport padding. The proposed exact-suffix subset does not meet that
  RFC's general padding requirement. Quotes are intentionally avoided here.
- Existing ADR numbers observed are 0001 through 0010. If root chooses an ADR,
  the next candidate is `0011-incremental-multipart.md`; recheck numbering when
  integrating. This scratch proposal neither reserves nor accepts an ADR.

## Proposed public contract

Names below are proposed exact types for review, not a new general event bus.
Use existing `uz.multipart` for the parser and one new
`uz.multipart_sink` module for the concrete effect adapter. Do not add root
forwarding functions or aliases for every type.

```zig
// src/http/multipart.zig; existing public types remain unchanged.
pub const StreamingLimits = struct {
    max_body_bytes: u64,
    max_parts: u32,
    max_part_headers: u16,
};
pub const StreamingStorage = struct { headers: []u8, carry: []u8 };
pub const PartMeta = struct {
    name: []const u8,
    filename: ?[]const u8,
    content_type: ?[]const u8,
};
pub const StreamingEvent = union(enum) {
    part_begin: PartMeta,
    part_data: []const u8,
    part_end: void,
};
pub const StreamingStep = struct {
    consumed: usize,
    event: ?StreamingEvent = null,
};
```

`StreamingParser` is a named plain-data struct with these operations:

```zig
pub fn init(boundary: []const u8, limits: StreamingLimits,
    storage: StreamingStorage) StreamingError!StreamingParser;
pub fn next(parser: *StreamingParser, input: []const u8) StreamingError!StreamingStep;
pub fn accept_data(parser: *StreamingParser, consumed: usize) StreamingError!usize;
pub fn finish(parser: *StreamingParser) StreamingError!void;
```

`StreamingError` is a named error set, including existing relevant multipart
errors and explicit storage/limit/progress/state errors: InvalidMultipartBoundary,
InvalidMultipartStorage, InvalidMultipartLimits, MultipartBodyTooLarge,
MultipartHeadersTooLarge, MultipartTooManyHeaders, MultipartTooManyParts,
InvalidMultipartHeaders, MissingContentDisposition, InvalidContentDisposition,
MissingPartName, IncompleteMultipartBody, InvalidMultipartProgress,
InvalidMultipartState. Do not expose implementation-state errors from stdlib
containers or introduce a generic error-mapping abstraction.

The parser borrows storage and copies its validated boundary into a fixed
70-byte configuration array. It retains no pointer into the input or original
Content-Type. Parser and external buffers stay stable and exclusively owned
until terminal disposal. Their memory cannot overlap each other, current input,
or another active upload. No allocator, callback, Io, clock, logging, randomness,
environment reads, global mutable state, or file type enters the pure core.

### Storage, logical bounds, and metadata

- Require positive `max_parts` and `max_part_headers`; both are caller-selected
  explicit bounds, with checked counters and no inferred defaults. A zero
  `max_body_bytes` allows no entity bytes, matching the body contract's limit
  semantics, although a valid multipart envelope itself requires bytes.
- `headers.len` is the exact per-part header-content limit; the final CRLFCRLF
  separator is excluded. No second line or parameter buffer is allocated.
  `headers.len == 0` is invalid storage. Every field, including unknown fields,
  counts toward `max_part_headers`. All fields must validate before begin.
- Require `carry.len >= boundary.len + 4`; use only that prefix, at most 74
  bytes. This same storage can hold a split header terminator in header phase.
  Extra caller capacity does not authorize extra carry. Partial candidate
  bytes, undecided suffix bytes, and header-terminator lookbehind are mutually
  exclusive phase uses, not separately allocated caches.
- The fixed boundary configuration is not raw-body carry. Once a complete
  known delimiter prefix matches, a phase/replay cursor can reconstruct it
  from literal CRLF/dashes and that configuration, freeing its raw carry space.
  Do not hide arbitrary payload bytes in integer fields or another array.
- `max_body_bytes` counts the HTTP entity after transfer decoding, including
  preamble, delimiters, part headers, part payload, and epilogue. Count newly
  consumed input exactly once with checked `u64` arithmetic. Replayed carry,
  virtual delimiter fragments, retried input, and sink acknowledgements must
  not double-count previously accepted bytes. Buffer positions remain `usize`.
- Check limits before accepting the byte/part/header that would exceed them.
  Part count advances only after a complete valid metadata block and before
  emitting begin. Repeated field names in different parts are allowed.
  In particular, bound a direct data event by the remaining logical-byte budget
  before invoking a sink; discovering overflow only in accept_data would let a
  sink write bytes that the parser then refuses to accept.
- Strict stream headers require valid field-name tokens/colon, CRLF line
  endings, no obsolete folding, and no NUL, bare CR/LF, or invalid controls.
  Reject duplicate Content-Disposition and duplicate Content-Type; unknown
  well-formed headers may repeat. Require exactly one form-data disposition
  with a present name. A present empty name/filename is distinct from absence.
- Parse disposition parameters with a bounded scanner that respects quoted
  semicolons and quoted-pairs. Reject malformed quotes and duplicate recognized
  name/filename parameters. Validate all header structure before emitting any
  metadata. Decode permitted quoted-pairs in place within their own header
  spans without shifting later fields. Metadata contains no CR/LF or NUL.
  Do not percent-decode, normalize paths, or honor filename* as a pathname.
- `PartMeta` deliberately omits a raw header view. Its slices borrow normalized
  spans in caller header storage. Parser users may read them until the next
  mutating parser operation; sink users may read them only during begin_part.
  Copy needed names/filenames into caller-owned per-request state before return,
  including before returning paused. Legacy `Part.headers` remains unchanged.

### Event acceptance and precise input ownership

1. `next` accepts only its returned `step.consumed` prefix. With no event, either
   it consumes input, or it is waiting for additional input; it never requests
   an unbounded copy. Normal drivers do not repeatedly poll an empty slice.
2. Begin/end events are committed in parser state before returning. They require
   no acknowledgement and never repeat. A caller may stop after one event;
   `next` does not pre-parse or queue another event behind it.
3. A nonempty data event borrows current input, carry, or immutable virtual
   delimiter fragments. It is valid only until `accept_data` or another mutating
   operation. Do not retain it across a pause. The parser records only pending
   origin/count, and must reject `next` while an event awaits acknowledgement.
4. `accept_data(n)` validates `0 <= n <= offered.len`, accepts exactly that
   payload prefix, releases that event borrow, and returns additional input
   advancement: n for input-backed data, zero for already accepted carry or
   virtual data. The caller adds this to step.consumed and reoffers the exact
   remaining input suffix. A partial acknowledgement does not consume or retain
   its input suffix. The next data event may have different fragmentation.
5. For an input-backed event, the parser has not already counted those bytes
   in step.consumed. For carry/virtual events, its bytes were counted when the
   original candidate was accepted. At a direct-data event, next may already
   have accepted earlier framing; input advancement is their sum, never overlap.
6. When peeking a mismatch invalidates a carried candidate, replay candidate
   payload before consuming that mismatch. A pause on replay therefore has
   nonempty input retained by the owner. Recheck overlap such as a mismatch CR
   starting the next candidate. Boundary characters contain no CR/LF, which
   bounds the candidate overlap; do not drop a held suffix CR.
7. The effect adapter validates a part write with existing `validate_progress`:
   ready requires the complete offered data slice; partial/zero progress must
   pause. A ready result lets the driver continue until it has accepted the
   complete outer input or emitted a paused event. No spin-polling on pause.
8. **No pending application data at accepted-input EOF:** once consume reports
   all input accepted, a paused begin/end has already been committed, and a
   paused data event has no pending suffix unless real input remains retained.
   A subsequent ready EOF needs only pure finish validation, not another callback.
   Truncated candidate carry at EOF fails instead of attempting a deferred write.

`finish` is required once, only at validated HTTP entity EOF. A seen closing
delimiter plus fully accepted epilogue and no pending data is success. Otherwise
it fails without emitting any event. next/accept/finish after terminal success or
failure return InvalidMultipartState; they cannot produce more events. Invalid
progress is rejected before mutation. Any parser/data-contract error terminates
the adapter and prevents further delivery until its terminal cleanup.

### Delimiters, compatibility, and named limit

The initial delimiter may start the entity or a preamble line, retaining the
existing line-start compatibility (after LF); later delimiters require CRLF.
Recognize a candidate only after its complete boundary and exact suffix are
known. Preamble false-prefix lines are ignored as preamble. In a part,
`CRLF--B` followed by a suffix other than CRLF or `--` stays ordinary payload,
at every split. The framing CRLF preceding a real delimiter is not payload.
After a closing `--`, the remaining entity is ignored epilogue and still counts
against the logical limit, consistent with the current close/epilogue behavior.
An immediate closing first delimiter yields zero parts, as the existing parser
allows. Empty part data yields begin/end with no empty data callback.

**MP-L1: ordinary delimiter transport padding unsupported.** Owner: HTTP
specialist and root. Date: 2026-10-26. Root accepted this limit for the initial
proposal; the complete contract still needs review. Padding such as SP/HTAB
before an ordinary delimiter CRLF is not recognized as a delimiter. A close
suffix has already entered epilogue; this does not validate a padded delimiter
line. No general RFC 2046 claim is appropriate. Restoration requires a separate
reviewed bound/storage/accounting design, every split and overlap test, paused
replay tests, fuzz coverage, and updated source/capacity evidence. Do not add
padding buffering as an implementation detail of this proposal.

Legacy differences remain explicit: the current full-body helper selects first
duplicate headers/parameters, skips colonless lines, accepts a trimmed field
name, and uses a semicolon splitter; the stream API rejects ambiguous/malformed
headers and can parse quoted semicolons. The legacy first-boundary helper also
selects a prefix before validating its suffix; the stream preamble scanner waits
for a complete valid delimiter. Differential tests compare only the common-valid
language; malformed-input differences are named policy tests, not regressions to
"fix" by changing the baseline.

## Concrete sink adapter and BodySink integration

```zig
// src/http/multipart_sink.zig; reuse request_body.zig named types.
pub const PartBeginFn = *const fn (*anyopaque, PartMeta) anyerror!BodyReadiness;
pub const PartChunkFn = *const fn (*anyopaque, []const u8) anyerror!BodyProgress;
pub const PartEndFn = *const fn (*anyopaque) anyerror!BodyReadiness;
pub const PartCancelFn = *const fn (*anyopaque, BodyCancelReason) void;
pub const PartSink = struct {
    context: *anyopaque,
    begin_part: PartBeginFn,
    write_chunk: PartChunkFn,
    end_part: PartEndFn,
    cancel_part: PartCancelFn,
};
```

One caller-owned `MultipartSink` holds a StreamingParser, borrowed immutable
PartSink callbacks, and explicit part-active/terminal state. Its concrete
operations are `consume(*MultipartSink, []const u8) anyerror!BodyProgress`,
`finish(*MultipartSink) anyerror!void`, and
`cancel(*MultipartSink, BodyCancelReason) void`. The adapter adds the accepted
prefix/one-active-part/once-only terminal invariants; it is not a forwarding layer.
Its event loop lives here, outside pure multipart parsing. It performs no I/O
except the application callbacks explicitly supplied to it. No generic event
dispatcher, PartBinding, continuation framework, global scheduler, new control
token, synthetic empty BodyChunk, or route factory is needed.

- `begin_part` chooses/initializes per-part resources in the upload's caller-owned
  context. Mark active only after success. Failure owns its own partial rollback;
  cancel_part does not follow a failed begin. Paused success accepts metadata
  once and returns paused to the outer BodySink owner.
- `write_chunk` receives a callback-only borrow, reused BodyProgress, and the
  exact offered bytes. A successful accepted prefix updates parser/input state.
  Invalid progress or a thrown error terminates consume, retaining the active
  part for the outer cancellation path after the callback unwinds.
- Mark inactive before `end_part`. It owns successful-part cleanup even when it
  throws or pauses. No later part cancel follows. If it pauses, stop before any
  next metadata/header event; the existing BodyControl resumes input or pending
  outer EOF. Do not add a duplicate adapter readiness token.
- `cancel` marks adapter terminal and clears active before invoking cancel_part
  once. Repeated cancel and cancel after successful whole-entity finish do
  nothing. Cancellation between completed parts still terminates the upload;
  there simply is no active part to notify. The adapter owns no memory and does
  not free its containing upload state. finish must not repeat.
- If finish rejects an incomplete/malformed entity, it invokes cancel_part once
  for a previously accepted active part before returning the error. Use invalid_body
  for syntax/truncation and body_too_large for a logical-limit failure. Already
  ended parts and failed begins receive no cancel. All paths mark terminal first.

Part callbacks own only their part resources. They must not free the containing
upload/MultipartSink or reenter its driver. The accepted outer BodySink terminal
callback may release that containing state only after adapter cleanup returns.
Work retained after an accepted paused end_part belongs to the caller's outer
upload cleanup; it cannot depend on a later cancel_part notification for that
already-ended part. Reset during that pause must stop that work before the
outer callback frees its state.

The application BodySink begins by taking a bounded upload slot, creating parser
and adapter in that slot, copying BodyControl there, and returning that context.
Use the BodyRoute logical limit for the parser limit; fixed header/carry storage
is part of each admitted slot. No request-time allocation, lock, route-table
growth, bigger transport ingress/body ceiling, or unbounded file list is required.
Missing per-upload storage refuses admission/begin with explicit rollback.

BodySink.chunk calls consume and returns its exact BodyProgress. BodySink.end
calls finish, finalizes application resources, and uses its fresh synchronous
Response; cleanup belongs to this callback even on error. A wrapper can catch a
known finish syntax error and send its chosen bounded response. BodySink.cancel
calls adapter.cancel then releases upload context/resources once. The outer
owner invalidates generation before terminal notification and releases route
admission after it returns; the adapter does not duplicate admission accounting.

Important error boundary: a parser or part callback error thrown from BodyChunk
is a sink failure under ADR 0008. This design adds no automatic multipart 400
status or transport `invalid_body` classification. If a product needs a clean
early multipart-error HTTP response while upload remains incomplete, that is a
separately reviewed body-sink response policy; do not smuggle it into this parser.
Do not call BodyControl.cancel/resume inside the active outer chunk callback.

Store no Request/Response pointer across callbacks. Retain only copied metadata
or the ADR's explicitly pinned individual byte slices. BodyControl is loop-bound;
outside callbacks, either operation can synchronously free the whole upload
context. Copy the control and any independently valid values before calling, and
never access that context afterward. A paused file sink also needs caller-owned
payload copying before acknowledging bytes; it cannot queue a borrowed pointer.

### Optional explicit file helper

Defer a library helper until a concrete sample/consumer needs it. A sufficient
first usage is an application PartChunk callback with an already-open `std.Io.File`,
caller Io, and checked u64 offset. A later small named writer may extract exactly
that repetition. It writes only offered bytes using the pinned Zig 0.16 API,
returns fully accepted ready on success, and propagates failures. It does not
hide blocking file I/O, claim asynchronous disk backpressure, or add opening/
closing/commit lifecycle callbacks. Caller end/cancel owns close, truncate/unlink,
durability, and partial-write rollback. A slow asynchronous sink must use its own
bounded copied storage and existing BodyControl outside callbacks.

## Ownership and ordered tests-first slices

Root serializes shared files. Do not start production integration before M1
closure and the ADR 0008 common/router/transport gates. Parser-only work can be
prepared/reviewed in isolation without claiming any live request transport works.

1. **Contract review, no implementation.** HTTP specialist owns grammar/events,
   transport specialist checks accepted-prefix/EOF/control lifetimes, router
   specialist checks public aliases/body limits, verification owns fuzz/proof.
   Root accepts or revises this scratch contract and may record ADR 0011 after
   rechecking numbering. Explicit review checkpoints are accept_data, B+4 virtual
   replay accounting, strict-vs-legacy grammar, MP-L1, and PartSink terminal rules.
2. **Pure parser, tests first.** HTTP specialist owns
   `src/http/multipart.zig` and new `src/tests/multipart_stream_tests.zig`.
   Root owns serialized suite/test-support imports. First red tests cover init,
   one complete part/empty part, all structural split points, preamble/epilogue,
   and unchanged legacy false-prefix payload. Next red tests cover partial/zero
   acknowledgements, virtual replay, bounds and terminal misuse. Reuse the private
   pure boundary validator only; do not refactor/harden legacy parsing incidentally.
3. **Concrete effect adapter, after parser review.** HTTP specialist owns new
   `src/http/multipart_sink.zig` and `src/tests/multipart_sink_tests.zig`;
   transport specialist guides BodyControl/terminal fixtures. Router specialist
   owns the single `src/root.zig` module export; root serializes suite/support
   changes. Use synthetic BodyState/owner fixtures first, with no transport edits.
   Add only the application integration example needed to show bounded slots,
   copied metadata, and safe control use after actual route_body is available.
4. **Trust-boundary fuzzing, in parallel only after contract freezes.** Verification
   owns `src/tests/fuzz_main.zig`, new `fuzz/multipart_stream.zig`,
   `fuzz/smoke_multipart.zig`, `oss-fuzz/corpus/multipart_stream/*`,
   `oss-fuzz/dictionaries/multipart_stream.dict`, and
   `oss-fuzz/options/multipart_stream.options`. Root serializes
   `src/fuzz_support.zig` to export the pure multipart module. Build/vendor owns
   the exact new object/install/coverage-check/smoke dependencies in
   `builds/fuzzing.zig` and target enumeration in `oss-fuzz/build.sh`.
   Keep `fuzz/check_fuzzer_coverage.sh` generic; pass it the new emitted object,
   rather than changing/weakening its coverage assertion.
5. **Large input, controlled comparison, and live integration.** Verification
   owns deterministic proof, raw artifacts, and the controlled same-input
   comparison; HTTP/application specialist owns any optional file
   sample. Transport owners add multipart to each already-proved M2 upload
   transport without revising the common sink lifecycle or enlarging windows.
   Root integrates, independent reviewer assesses final diff/evidence, then
   required gates run for the actual combined source.

The deep-module seam is **recognize/acknowledge multipart events** versus
**invoke part sinks and own their lifecycle**. Deletion test: remove the effect
adapter and its export; pure parser tests, Smith target, and standalone LLVM
target still compile/run without Request, Response, BodyControl, std.Io, or any
application callback. Conversely a minimal real-parser multipart fixture can
exercise the adapter's prefix/terminal contract without sockets/files or an
injectable parser abstraction. If core fuzzing starts
linking transports or file helpers, or every caller must copy parser transition
logic, the seam has failed. Do not add a shared base-parser module merely to
save a few lines of boundary validation.

## Verifiable acceptance

### Pure parser and storage

- Preserve every existing full-body test, error expectation, public name, and
  `Request.multipart` buffered/BodyNotBuffered behavior. Add explicit paired
  tests for legacy-first-match versus strict-stream duplicate/header policies.
- For boundaries of length 1 and 70, exercise every byte split of opening,
  ordinary, and closing delimiters, final delimiter without terminal CRLF,
  split header terminator/parameter quotes, empty part, and preamble/epilogue.
  Boundary 0/71, invalid alphabet, and trailing space fail init as before.
- For every split, payload `CRLF--B` plus bad suffix, longer boundary prefix,
  `CRLF--B` then CR/X and -/X, nested CR/CRLF overlap, and one-byte input all
  reproduce payload exactly without a false delimiter or false error. Include
  the literal existing `--abcX is payload` fixture.
- Guard bytes around carry and header buffers remain unchanged. Minimum B+4
  succeeds, B+3 refuses init, and larger buffers do not expand active carry.
  Assert raw retained bytes plus reconstructible-state origin at each step;
  configuration replay must not use a stale input pointer or a hidden raw array.
- Header bytes/count and part count test exact-limit success and one-over
  failure before offending acceptance. Validate duplicate CD/CT, duplicate name/
  filename, missing name, malformed colon/name/quote/folding, actual CRLF/NUL
  injection, quoted semicolon/escaped quote, repeated fields in separate parts,
  and untrusted path-like/percent-encoded filenames as opaque metadata.
- Use arithmetic fixtures near u64 limits rather than huge allocations. Verify
  copied candidate bytes count once, replay counts zero, input acknowledgement
  counts once, no usize truncation, and max-body overflow never wraps.
- Truncate at every offset: succeed only after a valid close and accepted
  epilogue; unresolved partial candidates/headers/body fail finish without
  emitting payload/end. No events after failure/finish or invalid ack; validate
  all pending-event and terminal-state misuse before mutation.

### Pause, lifetime, terminal, and integration

- Pause at every event and every payload prefix, including zero and full length.
  Reoffer retained suffix in a different backing allocation and poison previous
  input after acceptance; compare exact bytes and metadata. This detects retained
  input pointers while allowing the caller to move unaccepted bytes safely.
- For false-prefix replay, pause in every literal/configuration/carry fragment
  with the deciding mismatch as the last HTTP byte. Assert nonempty retained
  input until deferred payload is accepted. Then consume the last real byte and
  pause fully: resume goes directly to finish/end, with no synthetic empty chunk.
- Pause successful begin once, end once, and final payload once. Callback counts
  remain exact across resume; finish may run with no new chunk callback.
  Pause during truncated delimiter carry then EOF must fail/abort once, not flush.
- Fail each callback position: failed begin rolls itself back/no cancel; failed
  write yields one accepted-part cancel after outer chunk unwinds; failed end
  owns cleanup/no cancel. Incomplete finish aborts an active part once because
  outer end has no later cancel. Reset/shutdown/timeout/application cancel while
  paused terminate once, reclaim slot once, and stop subsequent events. Include
  reset after paused end_part: outer upload cleanup stops any retained work,
  while the ended part receives no duplicate end/cancel notification.
- Invalid PartProgress, stale generation, active-callback control use, and
  repeated resume/cancel satisfy the existing BodyControl contract. Use a mock
  terminal that poisons/frees binding state inline; no code touches it after
  control returns or under an active callback. Retained metadata must be copied.
- Parser errors from chunk remain sink_failure at the HTTP owner; tests must not
  promise an unimplemented clean 400 path. A known error caught in finish can be
  handled by the application's actual BodyEnd response policy.

### Fuzz, large input, comparison, and release gates

- Smith exercises chunk schedules, data-prefix acknowledgements, limit edges,
  and event/byte/terminal invariants, with a bounded event/iteration fuel budget.
  LLVM target exports exact `LLVMFuzzerTestOneInput` C ABI through fuzz_support,
  uses bounded input/storage, and derives split/pause schedules from fuzz bytes.
  Seeds cover valid one/two/empty parts, maximum boundary, preamble/epilogue,
  every delimiter suffix, metadata errors, and truncation; dictionary contains
  framing and disposition tokens. Smoke must invoke the same fuzz_one entry.
- `zig build fuzz`, `zig build oss-fuzz-objects`, and `zig build oss-fuzz-smoke`
  must include multipart. Confirm emitted object export, `__sancov_cntrs`
  coverage, installed object, sanitizer runtime linkage, zipped seeds, dictionary,
  options, and external OSS-Fuzz enumeration. No blind target or smoke-only
  claim. Compare the legacy parser only on the common-valid grammar subset.
- Generate exactly 100,000,000 logical HTTP entity bytes from fixed small
  caller-owned blocks, including envelope accounting and a part much larger than
  the old body window. Use deterministic per-byte/checksum verification, tiny
  split windows, and a slow copied-storage sink; no 100 MB materialized part or
  growing queue. Assert exact part metadata/count/data totals, bound high-water
  marks, and once-only cleanup. Repeat with file failure/cancel if a file sample
  is included. Only claim transports actually exercised by real clients after
  their M2 adapters land; unit proof is not a live transport result.
- Compare streaming versus legacy full-body parsing on the **same complete
  deterministic caller-owned 100,000,000-byte input** initialized before timing.
  The benchmark harness may acquire that one complete fixture during setup;
  full-body comparison inherently needs it. This is separate from the bounded
  generated-stream proof above, which never materializes the entity. Both parsers
  must allocate nothing during parsing. Verify identical part metadata/count/
  payload hash first. Record revision, Zig/target/mode, CPU, size, split schedule,
  warmup, iterations, raw samples, and exact commands. If host memory prevents
  this comparison, record that check as unavailable for root disposition; a
  smaller supplemental fixture cannot silently satisfy the requested 100 MB
  comparison. Do not infer throughput from different inputs, setup time, or one
  noisy run. No speedup or numerical performance threshold is invented here.
- For the actual changed source, run canonical fmt/conventions/version/native
  tests, the relevant sanitizers and cross-target gates, Smith/LLVM smoke and
  coverage, package-consumer export checks, and the accepted M2 live transport
  matrix. Required minimum commands remain `zig fmt src builds examples tests
  fuzz`, `sh scripts/check_conventions.sh`, `sh scripts/check_release_version.sh`,
  and `zig build test`; never report an unrun gate as passing. Run graphify update
  only after actual source changes. Independent review includes terminal/error
  ownership, B+4 accounting, public API shape, and MP-L1 wording.

## Dependencies and approval boundary

This proposal requires no new dependency or speculative filesystem abstraction.
The blocking architectural input is root's fresh review of this exact public
contract; routine choices do not require a user interview. The production path
also depends on M1 closure, ADR 0008 common/router exports, and its sequential
transport behavior/proofs. This document approves none of those gates, claims no
benchmark result, and does not mark M2-2 or any later milestone complete.
