# Guarded submit/cancel callback source audit

Read-only explorer /root/audit_guarded_submit_callback_timing. No native execution,
builds, probes, edits or subagents. Roots: frozen /tmp/uwz-m2-h1-retirement-policy
and immutable c223bd886c6a51d2cd60def39dd9a68d701fea73 libxev export.

App core/loop.zig123-128 LoopHandle.submit -> core/xev.zig118-132 concrete
submit when present; cancel162-170 -> xev.cancel. There is no submit_guarded
symbol; guarded submission is the handle method. Candidate dynamic.zig122-175
adds no submit/callback layer.

No inline H1 recv/send/accept/cancel completion callback from these operations:
- io_uring submit231-239/add362-565 prepares/submits SQEs; cancel583-606 adds;
  completion invocation is tick193-200.
- epoll has no submit (app adapter no-op); add272-290 queues; tick462-485 starts
  work; start903-919 invokes callbacks only within tick. Timer cancellation969
  also runs through tick processing.
- kqueue submit172-180 promises deferred callbacks; immediate results927-933 queue;
  cancellation work158-163/888-894 queues; dispatch later in tick.
- IOCP recv/send623-673 produces submitted/result actions; immediate results792-795
  queue; cancel start739-742 queues; ACK170-188 queues, callback dispatch264-275.

Generic exception: IOCP submit156-159 -> start_completion749-770 -> callback764
invokes first job_object association inline, contradicting its general comment145.
Do not assume every H1 loop excludes unrelated adding job-object work.
Both cancellation flags before first submit are not forced by native TCP timing,
but publish both before generic callback-capable submission when that guarantee
is needed. Successful submit need not mean target still active: immediate errors
may already queue results; kqueue938-944 preserves an existing queued result.

Baseline tcp2195-2211 submission precedes cancels2217-2237 but raw submit error
logs/continues. This is call order, not successful submit-before-cancel proof.
Enabled path must use actual bound failure-fence handle; its failed submit
terminates before cancellation (loop124-126,155-158).

Root next-unit decisions (not runtime proof): initial !closing transition is the
one cancellation discriminator; later tails never recancel, avoiding a new stored
flag after ACK retires but genuine target remains. Destructive cleanup/close stay
deferred. Proposed close-initiation operation borrow reuses delivery_active and
publishes both needed cancel flags before submit; architect evaluating exact
reentry/tail obligations before native code release. B+C plus real delivery and
terminal/admission cleanup is one eventual review/activation unit. Typed payloadless
retirement_inactive failure tag is independently coherent and currently assigned.
No native probing/maintained publication/pin adoption or generic liveness claim.
