# Next native H1 lifetime unit: bounded implementation contract

Read-only architect /root/architect_h1_retirement_implementation supplied the
source-grounded handoff. Root persisted it here; no native probing occurred.
StageA policy d85afc4d1b5cb2d22013feef623e5757abcab8ada0d53e3d01c3451676060d6c is
verified/reviewed/pushed106f747. Typed invariant successor81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108
is frozen/reviewed no findings, all14checks0; Root archiving. No native wiring yet.

## Independently coherent invariant extension

One payloadless CallbackFailure.retirement_inactive and fixed panic arm after
unchanged unconditional fence.failed=true. No new helper, field, error record,
HTTP import or alias relocation. Storage RetirementError remains owned there.
Future native callback exhaustively maps only RetirementInactive to this tag;
native Timer.RunError remains .retirement. Actual observer IR on3targets proves
latch-before-panic without executing panic. Existing3payloadcontracts unchanged.

## Root accepted cancellation amendment

V6 literal record-and-return under pins cannot later distinguish never-issued
cancel from ACK+retirement completed but target still retained. No new state:
initial !conn.closing transition is the sole cancellation discriminator; later
tails never initiate/retry. This is an explicit bounded implementation amendment,
not renewed unrestricted liveness approval. User-confirmed BSD gate remains.

Acquire existing delivery_active only if false; remember ownership locally.
Capture actual owner/bound LoopHandle/local needed-direction decisions. Publish
closing,close_pending and BOTH needed cancel flags before generic submission.
Guarded submit through captured handle must succeed before local selected cancels.
Do not clear target flags. Generic inline IOCP job-object callbacks are possible;
see submit-callback-source-audit.md, not an invented submit_guarded function.
Reentered close sees closing and returns. If inherited pin, retain it and return;
if owned, clear it as final state write then enter safe continuation with no
post-tail access/defer. Real generic callbacks may mutate body/response/work;
re-read current gates in continuation, never restore snapshots. Direct raw field
replacement, callback-time App destruction and event-loop reentry unsupported.

The bool operation borrow is sound only if all nested operations preserve it,
release_closed_connection adds owner drain gate, and reset/bind/deinit enforce
drain. resume_async_dispatch must refuse closing/busy metadata compaction BEFORE
first mutation (currently1507); pump_stream_body1433 can invoke it after producer
step_stream called close. Live deferred compaction resumes after real borrow.
BodyControl targets also need closing-aware behavior: shared validation alone
knows only phase/generation. Legitimate cancellation/cleanup must finish before
reporting BodyDeliveryFailed; no abandoned terminal ownership.

## Native consumers and final-action tails

Actual recv/send callbacks set frame pin before clearing target-active. Every
enabled disarm requests/coalesces retirement and arms only on true, then clears
frame pin as final write. ACKs keep cancel flag through actual cancel_ack; only
abandon_target clears target flag. Request retirement before final ACK flag clear.
Retirement callbacks handle native error, actual expire_retirement, fresh second
Timer.run(0), then idle-before-tail; return disarm, never timer rearm or post-tail
access. Never reuse recv/send/cancel completions as timers. Gate fresh read/write
submission on direction frame/cancel/retirement and use existing pending flags.

Safe tail builds actual six-field CloseSnapshot and calls claim_close. False
may suppress work; it must not recancel. Real body cleanup uses canonical state,
never sets inactive artificially. Close completion fences error before complete,
then release gate as final action. Pool callback/pointer nulling precede callback;
no access after possible release. Owner-null default stays unchanged.

## Minimum B+C real cleanup and delivery

B+C is one actual review/activation unit; B-only drafting is not complete lifecycle.
Under preserved delivery borrow: BodyState.request_cancel, actual registered
route_definition.sink.cancel, authoritative reject_begin/finish_terminal boolean,
then actual head_target.router.release_body_route(record_index). Real reserve
rollback also handles BodyAdmissionMissing. Map it to one needed payloadless
CallbackFailure.body_admission_missing/fixed diagnostic, same latch ordering;
never cast to a native cancellation/timer/close error or ignore it.

Keep metadata and TLS until native targets/frames/ACKs/retirement drain. After
successful physical-close claim, guard synchronous TLS destruction with existing
delivery borrow, then clear owned borrow immediately before platform close tail.
Use existing clear_stream and async-state cancellation; producer has NO abort
callback, so do not invent one.

Real callable operations retain borrow across callbacks, terminal completion
and quota release; outer unwind reaches safe continuation last:
- Admission/begin borrows prepared HeadInput/Response, invokes bound real target,
  preserves pending headers, stops on close, actual reserve_and_arm and sink.begin,
  rejects failed begin or accepts successful binding then pending cancellation.
- Chunk offers already-observed payload via start_chunk/sink.chunk/accept_chunk
  or fail_chunk, maintains accepted-prefix accounting and terminal unwind.
- End uses take_end with genuine framing/queued-byte facts, real sink.end with
  projected metadata/fresh restored Response, finishes terminal even on error,
  never invokes a second cancel.
- Cancel defers begin/chunk, otherwise real sink.cancel/finish_terminal.
- Actual control targets must implement closing-aware cancel AND real retained-
  input resume. No no-op resume or fabricated inactive body is implementation.

Root dependency observation: a real resume target cannot be complete while its
retained-input continuation is absent. The next native unit must include that
actual plaintext continuation/decoder progression, or explicitly remain partial
and unactivated until the real driver is bound. No generic continuation callback
or stub to hide this dependency. App head resolution may stage separately, but
actual public plaintext activation/live claims require the real App binding too.
TLS plaintext extraction/caps still require crypto source review and actual TLS
clients. Root will release a concrete full plaintext scope before native coding.

## Ownership, proof and limits

Transport owns effects/borrows; HTTP/router guide real terminal/admission; crypto
reviews deferred TLS destruction. Existing checked owner + guarded handle is the
seam; no generic framework. Review all disarm/early-return/inherited pin and
inline mutation paths, one-shot cancellation/close and actual final release.
Use actual registered sinks and caller-owned records for CPU policy tests, not
fabricated native completions. Ordinary owned clients only after coherent real
binding; stopped cancellation/interleaving/race/crash/leak/registration-error/
invalid-fd/resource/kernel/injected-completion/panic experiments remain stopped.
Local c223 prerequisite unadopted; maintained publication/protections/all4zon,
full project gates and native Windows remain. No global liveness/upload/TLS claim.
