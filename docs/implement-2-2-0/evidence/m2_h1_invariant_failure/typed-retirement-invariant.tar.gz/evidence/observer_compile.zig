const support = @import("test_support");
const core_loop = support.loop;

export fn check_retirement_inactive(owner: *core_loop.Loop) noreturn {
    const handle = core_loop.LoopHandle{ .owner = owner };
    handle.fail_callback(.retirement_inactive);
}
