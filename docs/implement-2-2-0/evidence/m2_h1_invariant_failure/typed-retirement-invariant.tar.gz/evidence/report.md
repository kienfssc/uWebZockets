# Typed retirement invariant failure extension

Final source is `/tmp/uwz-m2-h1-native-lifetime`, frozen 1020 files mode 0444, digest `81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108`. It independently copies accepted Stage A digest `d85afc4d1b5cb2d22013feef623e5757abcab8ada0d53e3d01c3451676060d6c` with no hardlinks, symlinks or inherited cache. Durable changed code is `snapshots/final-invariant/src/core/loop.zig`; `final.patch`, `final-source-manifest.json` and `summary.json` bind exact code and all checks.

## Exact two-line production delta

Append one payloadless `CallbackFailure.retirement_inactive` tag after the existing three tags, and add one fixed panic arm to the actual existing LoopHandle.fail_callback switch: `guarded event loop retirement callback was inactive`. The existing unconditional `fence.failed = true` remains before the switch. No function/helper, stored field, error record, HTTP import, alias relocation or framework was added. The existing cancellation, retirement and close payload types and panic arms remain unchanged. RetirementError stays storage-owned. No other internal CallbackFailure exhaustive switch required a change; the client switch uses unrelated ParseFailure.

All other 1019 source files remain byte-identical. In particular root public exports, the Stage A storage/policy module, all 31 App tests and core tests are unchanged. Loop's stored definition is byte-identical; no owner-layout field changes or new persistent CallbackFailure storage occurred.

## Actual observer proof without execution

The established compiler-only observer pattern is reused by `observer_compile.zig`: its exported entry constructs the existing handle and calls the actual `handle.fail_callback(.retirement_inactive)`. There is no substitute observer or panic handler. Before the source change, the actual call fails compilation because the union lacks the tag; exit1, exact predecessor snapshot and full argv/raw log are retained in red-missing-tag records. No runtime panic test was written or executed.

Actual ReleaseSafe LLVM IR was generated for native Linux, aarch64 macOS and x86_64 Windows GNU. Each entry calls the real core.loop.LoopHandle.fail_callback. Its bound-fence block stores true before calling defaultPanic with the new fixed message, in the same basic block with no intervening branch. Source also places the latch store unconditionally after the existing bound-fence guard and before the exhaustive switch.

| Target IR | Latch store line | New fixed panic call line |
|---|---:|---:|
| native | 932 | 934 |
| aarch64-macos | 793 | 795 |
| x86_64-windows-gnu | 175798 | 175800 |

`observer-latch-ir.txt` retains exact globals/caller/observer excerpts with original line numbers. `observer-ir-proof.json` and each compiler record bind the full IR SHA256/path/size. Full 19–24 MB IR files remain under `/tmp/uwz-m2-h1-native-lifetime-artifacts/`, not workspace evidence. The proof assumes the existing required bound fence and stable owner/fence on the owning loop. The missing-fence path retains its existing precondition panic and has no fence to latch. No claim is made that this compile-only evidence executes a panic or proves runtime lifetime ordering.

## Scoped verification

| Check | Outcome |
|---|---|
| Actual observer new-tag IR generation, native/macOS/Windows |all 0; never executed |
| Existing pure classifier and closed-payload tests, Debug/ReleaseSafe |3/3 each |
| Eligible centralized native/macOS/Windows graph |ReleaseSafe compile-only, all 0 |
| Full scoped zig fmt / conventions / release metadata |all 0 |
| Isolated graphify update |AST-only 0; temporary output symlink removed |

Every final check records source digest `81f8bc248df272e5e5750b63745db0478d17091e9ad6ef1a291dc89ce92a6108` before/after, full actual argv, direct compiler/module/library inputs before/after, and all 93 immutable c223 override hashes before/after. Pure execution records bind compiler artifact and executable before/after hashes. The driver actually copies the environment, explicitly sets UWZ_TEST_XEV_BACKEND=io_uring, passes that mapping to subprocess.run and records that value directly; no other environment values are dumped. These pure tests do not initialize a native backend. The missing-tag compile red is the only nonzero compiler/test result in this slice. No new literal/mirror tests, whole App runtime, terminating observer, native callback or panic subprocess were executed.

## Mandatory stop and future mapping

This completes only the independently coherent typed invariant extension. It does not wire native callbacks or advance delivery/lifetime/cleanup/close/release behavior. A subsequent native catch must exhaustively map only storage-owned RetirementInactive to `.retirement_inactive`; native timer errors keep the existing `.retirement` payload and must not be forged. The concrete coherent B+C release remains with Root. No stopped native cancellation/fault/race/crash/leak/registration/error/invalid-fd/resource/kernel/injected-completion or panic experiment was reconstructed. No refs, dependency fetch/adoption, Root source/pin edits, commits, pushes or publication occurred. Work stops here pending Root's next concrete authorization.
