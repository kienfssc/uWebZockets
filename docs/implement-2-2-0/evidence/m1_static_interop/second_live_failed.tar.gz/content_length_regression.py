import importlib.util
import io
import tempfile
from pathlib import Path

from aioquic.h3.events import DataReceived, HeadersReceived

source = Path('/workspaces/uWebZockets/tests/static_interop/probe.py')
spec = importlib.util.spec_from_file_location('static_probe', source)
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


def response_case(directory, label, lengths, *, required, payload=b'ok', expected=b'ok', ended=True):
    expected_path = directory / (label + '.source')
    expected_path.write_bytes(expected)
    body_path = directory / (label + '.body')
    with expected_path.open('rb') as original, body_path.open('wb') as output:
        response = probe.ResponseState(source=original, output=output, body_path=body_path, headers=[], bytes=0, max_event_bytes=0, done=False, proof={}, require_content_length=required)
        state = {'requests': {0: response}, 'trace': io.StringIO()}
        headers = [(b':status', b'200'), *((b'content-length', value) for value in lengths)]
        probe.h3_consume(state, HeadersReceived(headers=headers, stream_id=0, stream_ended=False))
        probe.h3_consume(state, DataReceived(data=payload, stream_id=0, stream_ended=ended))
        return response


def rejected(action, detail):
    try:
        action()
    except RuntimeError:
        print(detail + ': rejected')
        return
    raise AssertionError(detail + ' was accepted')


with tempfile.TemporaryDirectory(prefix='uwz-h3-length-check-') as temporary:
    directory = Path(temporary)
    health = response_case(directory, 'health_no_length', [], required=False)
    assert health['done'] and health['proof']['bytes'] == 2
    print('Health without Content-Length: exact bytes and END_STREAM accepted')
    health = response_case(directory, 'health_valid_length', [b'2'], required=False)
    assert health['done'] and health['proof']['bytes'] == 2
    print('Health with valid optional Content-Length: accepted')
    rejected(lambda: response_case(directory, 'health_duplicate', [b'2', b'2'], required=False), 'Optional duplicate Content-Length')
    rejected(lambda: response_case(directory, 'health_mismatch', [b'3'], required=False), 'Optional mismatched Content-Length')
    static = response_case(directory, 'static_valid_length', [b'2'], required=True)
    assert static['done'] and static['proof']['bytes'] == 2
    print('Static required Content-Length matching exact bytes: accepted')
    rejected(lambda: response_case(directory, 'static_missing', [], required=True), 'Static missing required Content-Length')
    rejected(lambda: response_case(directory, 'static_duplicate', [b'2', b'2'], required=True), 'Static duplicate Content-Length')
    rejected(lambda: response_case(directory, 'static_mismatch', [b'3'], required=True), 'Static mismatched Content-Length')
    rejected(lambda: response_case(directory, 'wrong_body', [], required=False, payload=b'no'), 'Body byte mismatch')
    rejected(lambda: response_case(directory, 'early_end', [], required=False, payload=b'o'), 'Premature END_STREAM')
    unfinished = response_case(directory, 'no_end', [], required=False, ended=False)
    assert not unfinished['done'] and not unfinished['proof']
    print('Exact body without END_STREAM: remains incomplete')
    large_event = response_case(directory, 'large_event', [b'65537'], required=True, payload=b'x' * 65537, expected=b'x' * 65537)
    assert large_event['done'] and large_event['proof']['bytes'] == 65537
    print('Legal 65537-byte event: exact body accepted with 8192-byte comparison slices')
