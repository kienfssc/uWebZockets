#!/usr/bin/env bash
set -euo pipefail

export PATH="/home/codespace/.nix-profile/bin:${PATH}"
export NIX_CONFIG='experimental-features = nix-command flakes'
export ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache
export ZIG_LOCAL_CACHE_DIR=/tmp/uwz-frozen-m1a-cache

source_dir=/workspaces/uWebZockets
source_rev=1488ecc49721dde935ee628b6b5668e99d600836
artifact_dir=/tmp/uwz-m1-static-live-1488ecc
outer_log=/tmp/uwz-m1-static-live-1488ecc-outer.log
outer_status=/tmp/uwz-m1-static-live-1488ecc-outer.status

cd -- "${source_dir}"
git rev-parse HEAD > /tmp/uwz-m1-static-live-1488ecc-source.before.rev
git status --porcelain --untracked-files=normal > /tmp/uwz-m1-static-live-1488ecc-source.before.status
test "$(cat /tmp/uwz-m1-static-live-1488ecc-source.before.rev)" = "${source_rev}"
test ! -s /tmp/uwz-m1-static-live-1488ecc-source.before.status

gate_status=0
bash tests/static_interop/run.sh "${source_rev}" "${artifact_dir}" >"${outer_log}" 2>&1 || gate_status=$?
printf '%s\n' "${gate_status}" >"${outer_status}"
git rev-parse HEAD > /tmp/uwz-m1-static-live-1488ecc-source.after.rev
git status --porcelain --untracked-files=normal > /tmp/uwz-m1-static-live-1488ecc-source.after.status
exit "${gate_status}"
