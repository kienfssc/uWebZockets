openssl x509 -in /tmp/nix-shell.9rZTbv/uwz-static-interop-5c7sdfdm/cert.pem -noout -sha256 -fingerprint -dates
