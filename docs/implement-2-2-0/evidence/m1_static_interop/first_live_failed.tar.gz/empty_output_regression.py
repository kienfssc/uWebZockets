import importlib.util
import tempfile
from pathlib import Path

source = Path('/workspaces/uWebZockets/tests/static_interop/probe.py')
spec = importlib.util.spec_from_file_location('static_probe', source)
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


def no_body_curl(directory, label, arguments, **keywords):
    (directory / (label + '.headers')).write_text('HTTP/1.1 304 Not Modified\r\nVary: Accept-Encoding\r\n\r\n')
    output = directory / (label + '.log')
    output.write_text('1.1 304 0 1 0\n')
    return output


def rejects(action, detail):
    try:
        action()
    except RuntimeError:
        print(detail + ': rejected')
        return
    raise AssertionError(detail + ' was accepted')


probe.command = no_body_curl
endpoint = probe.Endpoint(name='h1', version='1.1', flag='--http1.1', scheme='http', port=18880, cert=Path('/unused'))
with tempfile.TemporaryDirectory(prefix='uwz-empty-output-check-') as temporary:
    directory = Path(temporary)
    response = probe.curl_request(endpoint, directory, 'empty_304', '/files/asset.txt')
    assert probe.check_response(response, 304, None) == {'bytes': 0}
    print('Successful curl 304 without a body write: accepted with owned empty output')
    unexpected_download = response | {'metadata': [['1.1', '304', '1', '1', '0']]}
    rejects(lambda: probe.check_response(unexpected_download, 304, None), 'Nonzero bodyless size_download')
    response['body'].write_bytes(b'x')
    rejects(lambda: probe.check_response(response, 304, None), 'Unexpected body bytes with zero metadata')
    try:
        probe.curl_request(endpoint, directory, 'empty_304', '/files/asset.txt')
    except FileExistsError:
        assert response['body'].read_bytes() == b'x'
        print('Existing caller-owned output: refused without overwrite')
    else:
        raise AssertionError('existing output was accepted')
