#!/usr/bin/env bash
set -euo pipefail

export PATH="/home/codespace/.nix-profile/bin:${PATH}"
export NIX_CONFIG='experimental-features = nix-command flakes'
export ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache
export ZIG_LOCAL_CACHE_DIR=/tmp/uwz-frozen-m1a-cache

source_dir=/workspaces/uWebZockets
source_rev=b2d2acb570eb0eae89bdb47e35889d1aa3264a6a
artifact_dir=/tmp/uwz-m1-static-live-b2d2acb
outer_log=/tmp/uwz-m1-static-live-b2d2acb-outer.log
outer_status=/tmp/uwz-m1-static-live-b2d2acb-outer.status

cd -- "${source_dir}"
git rev-parse HEAD > /tmp/uwz-m1-static-live-b2d2acb-source.before.rev
git status --porcelain --untracked-files=normal > /tmp/uwz-m1-static-live-b2d2acb-source.before.status
test "$(cat /tmp/uwz-m1-static-live-b2d2acb-source.before.rev)" = "${source_rev}"
test ! -s /tmp/uwz-m1-static-live-b2d2acb-source.before.status

gate_status=0
bash tests/static_interop/run.sh "${source_rev}" "${artifact_dir}" >"${outer_log}" 2>&1 || gate_status=$?
printf '%s\n' "${gate_status}" >"${outer_status}"
git rev-parse HEAD > /tmp/uwz-m1-static-live-b2d2acb-source.after.rev
git status --porcelain --untracked-files=normal > /tmp/uwz-m1-static-live-b2d2acb-source.after.status
exit "${gate_status}"
