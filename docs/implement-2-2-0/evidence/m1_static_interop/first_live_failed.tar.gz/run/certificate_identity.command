openssl x509 -in /tmp/nix-shell.5EaWO4/uwz-static-interop-in3nli0k/cert.pem -noout -sha256 -fingerprint -dates
