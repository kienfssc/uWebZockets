from pathlib import Path
import hashlib, json, subprocess

root = Path('/workspaces/uWebZockets')
repo = root / '.uwz-work/drafts/libxev-udp-fix'
evidence = root / '.uwz-work/evidence/iocp-cancel-not-found'
final = evidence / 'implementation/final'
base = '29490914cf58b24d7ab32ca5349f9a03a910435f'

def run(args, cwd=repo):
    result = subprocess.run(args, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'{args}: {result.returncode}: {result.stdout.decode(errors="replace")}')
    return result.stdout

files = []
for line in (final / 'frozen-source.sha256').read_text().splitlines():
    digest, name = line.split(None, 1)
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest, name
    files.append(name)
assert run(['git', 'rev-parse', 'HEAD']).decode().strip() == base
assert not run(['git', 'diff', '--cached', '--name-only'])
assert set(files) == {'src/backend/iocp.zig', 'src/backend/iocp_cancel.zig', 'src/tests/iocp_cancel_tests.zig', 'src/main.zig'}
for name in ('policy-debug', 'policy-release-safe', 'healthy-debug-unrestricted', 'healthy-release-safe-unrestricted', 'windows-release-safe', 'abi-compile', 'abi-compare', 'fmt-check', 'whitespace-final'):
    assert (final / f'{name}.status').read_text().strip() == '0', name
assert (evidence / 'implementation/red/policy-debug.status').read_text().strip() == '1'
run(['git', 'diff', '--check'])
run(['git', 'add', '--', *files])
assert set(run(['git', 'diff', '--cached', '--name-only']).decode().splitlines()) == set(files)
(evidence / 'staged.diff').write_bytes(run(['git', 'diff', '--cached', '--binary']))
(evidence / 'commit.log').write_bytes(run(['git', 'commit', '-m', 'uwz(iocp): acknowledge cancellation when the request has completed']))
commit = run(['git', 'rev-parse', 'HEAD']).decode().strip()
tree = run(['git', 'rev-parse', 'HEAD^{tree}']).decode().strip()
assert run(['git', 'rev-parse', 'HEAD^']).decode().strip() == base
assert not run(['git', 'status', '--porcelain'])
bundle = evidence / 'iocp-cancel-not-found.bundle'
(evidence / 'bundle-create.log').write_bytes(run(['git', 'bundle', 'create', str(bundle), 'HEAD']))
source = evidence / 'source.tar.gz'
source.write_bytes(run(['git', 'archive', '--format=tar.gz', 'HEAD']))
restore = Path('/tmp/uwz-iocp-cancel-bundle-verify')
assert not restore.exists()
restore.mkdir()
run(['git', 'init', '--bare', str(restore)], cwd=root)
checks = [
    ['git', 'bundle', 'verify', str(bundle)],
    ['git', 'fetch', str(bundle), 'HEAD:refs/heads/candidate'],
    ['git', 'fsck', '--strict', '--full'],
]
for number, command in enumerate(checks):
    (evidence / f'bundle-verify-{number}.log').write_bytes(run(command, cwd=restore))
assert run(['git', 'rev-parse', 'candidate'], cwd=restore).decode().strip() == commit
assert run(['git', 'rev-parse', 'candidate^{tree}'], cwd=restore).decode().strip() == tree
candidate = {
    'candidate': commit, 'parent': base, 'tree': tree,
    'local_branch': 'draft/uwz-iocp-cancel',
    'maintained_publication': False, 'root_pin_changed': False,
    'review_agent': '/root/review_iocp_cancel_result',
    'bundle_sha256': hashlib.sha256(bundle.read_bytes()).hexdigest(),
    'bundle_bytes': bundle.stat().st_size,
    'source_archive_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'restored_empty_repository': str(restore), 'strict_fsck_exit': 0,
    'verification': {'focused_Debug': 30, 'focused_ReleaseSafe': 30, 'named_new_policy_tests': 4,
                     'healthy_Debug': {'passed':155, 'skipped':4, 'total':159},
                     'healthy_ReleaseSafe': {'passed':155, 'skipped':4, 'total':159},
                     'windows_build_steps':8, 'windows_execution':False, 'abi_assembly_identical':True},
    'scope': 'Only FALSE+ERROR_NOT_FOUND classification; acknowledgement does not retire target storage'
}
(evidence / 'candidate.json').write_text(json.dumps(candidate, indent=2) + '\n')
print(json.dumps(candidate, indent=2))
