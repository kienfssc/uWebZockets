const std = @import("std");
const iocp_cancel = @import("../backend/iocp_cancel.zig");

test "IOCP cancel failure policy acknowledges ERROR_NOT_FOUND" {
    try std.testing.expect(iocp_cancel.failure_is_acknowledged(.NOT_FOUND));
}

test "IOCP cancel failure policy rejects ordinary Windows failures" {
    const errors = [_]std.os.windows.Win32Error{
        .INVALID_HANDLE,
        .ACCESS_DENIED,
        .INVALID_PARAMETER,
        .NOT_ENOUGH_MEMORY,
        .OPERATION_ABORTED,
        .IO_PENDING,
        .FILE_NOT_FOUND,
        .PATH_NOT_FOUND,
    };
    for (errors) |err| {
        try std.testing.expect(!iocp_cancel.failure_is_acknowledged(err));
    }
}

test "IOCP cancel failure policy rejects ERROR_SUCCESS after FALSE" {
    try std.testing.expect(!iocp_cancel.failure_is_acknowledged(.SUCCESS));
}

test "IOCP cancel failure policy rejects unknown Windows errors" {
    const err: std.os.windows.Win32Error = @enumFromInt(0xffff_ffff);
    try std.testing.expect(!iocp_cancel.failure_is_acknowledged(err));
}
