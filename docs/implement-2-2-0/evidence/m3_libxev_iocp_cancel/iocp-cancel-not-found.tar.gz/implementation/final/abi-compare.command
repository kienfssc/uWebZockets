cwd: /workspaces/uWebZockets/.uwz-work/drafts/libxev-udp-fix
command: cmp /workspaces/uWebZockets/.uwz-work/evidence/iocp-cancel-not-found/implementation/base/abi_contract.s /workspaces/uWebZockets/.uwz-work/evidence/iocp-cancel-not-found/implementation/final/abi_contract.s
