cwd: /workspaces/uWebZockets/.uwz-work/drafts/libxev-udp-fix
command: /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check src/backend/iocp.zig src/backend/iocp_cancel.zig src/tests/iocp_cancel_tests.zig src/main.zig
