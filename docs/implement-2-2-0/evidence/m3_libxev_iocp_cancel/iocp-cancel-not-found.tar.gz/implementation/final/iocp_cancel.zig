const std = @import("std");

/// Classifies only the last error captured after CancelIoEx returns FALSE.
pub fn failure_is_acknowledged(err: std.os.windows.Win32Error) bool {
    // A missing request may still have its target completion queued.
    return err == .NOT_FOUND;
}
