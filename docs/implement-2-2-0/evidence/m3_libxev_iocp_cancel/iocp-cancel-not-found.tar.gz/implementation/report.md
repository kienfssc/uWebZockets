# Bounded IOCP cancellation-result implementation

Source is frozen for independent review. No staging, commits, ref updates,
publication, dependency-pin updates, or root source edits were performed.

## Source and scope

Clone: `/workspaces/uWebZockets/.uwz-work/drafts/libxev-udp-fix`.
Base: `29490914cf58b24d7ab32ca5349f9a03a910435f`, tree
`e13b3948e95075cd1245b25a872fa714045ba95e`.

Exactly four clone source files changed:

- `src/backend/iocp.zig`: the two active cancellation branches now call the
  same small native helper. It returns on nonzero native success, reads
  `GetLastError` once immediately on FALSE, applies the real pure classifier,
  and retains `windows.unexpectedError(err)` for every other error.
- `src/backend/iocp_cancel.zig`: the pure FALSE-only classifier acknowledges
  exactly `std.os.windows.Win32Error.NOT_FOUND`.
- `src/tests/iocp_cancel_tests.zig`: four pure value tests cover NOT_FOUND,
  eight ordinary failures, SUCCESS after FALSE, and an unnamed enum value.
- `src/main.zig`: one import in the existing central discovery test.

`final/complete.diff` includes both tracked modifications and new files.
`base/source.sha256`, `red/source.sha256`, `final/source.sha256`, and
`final/frozen-source.sha256` retain before/after identities. Source snapshots
are in `base/`, `red/`, and `final/`. The final snapshot is the frozen source.

## Failing-first evidence

`red/iocp_cancel.zig` faithfully extracts the old FALSE-result policy as a
classifier returning false for every input. Both actual native cancellation
sites were wired to that policy before running the new tests. This is an
**extracted-old-policy red**, not an executed native race reproduction and not
a declaration-absence compile failure.

The focused Debug run compiled, ran 30 tests, and failed only the new
NOT_FOUND acknowledgement expectation: 29 pass, 1 fail, exit 1. The other
three named tests passed. The filter also runs 26 existing discovery tests.
Only the classifier changed for green: it now compares the captured value
with `.NOT_FOUND`. Raw command, complete log, exit status, source and hashes
are retained under `red/`.

## Checks actually run

All build checks used the exact Zig 0.16.0 compiler
`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`.
Build-system commands used `-j2`, the clone's existing `.zig-cache` symlink, and
`ZIG_GLOBAL_CACHE_DIR=/workspaces/uWebZockets/.uwz-work/evidence/libxev-udp-fix/cache-global`.
The respective `.command`, `.log`, and `.status` files preserve each check.

| Record | Check | Result |
| --- | --- | --- |
| `base/abi-compile` | Windows ReleaseSafe layout/closed-error consumer before edits | Exit 0 |
| `red/policy-debug` | `zig build test '-Dtest-filter=IOCP cancel failure policy' -j2 --summary all` against extracted old policy | Exit 1; 29 pass, 1 fail |
| `final/fmt` | `zig fmt` on the four changed source files | Exit 0; no formatter changes |
| `final/policy-debug` | Same focused command against final policy | Exit 0; 30/30 pass |
| `final/policy-release-safe` | Focused command plus `-Doptimize=ReleaseSafe` | Exit 0; 30/30 pass |
| `final/healthy-debug` | `zig build test -j2 --summary all` in default sandbox | Exit 1; 111 pass, 4 skip, 44 fail |
| `final/healthy-debug-unrestricted` | Same unchanged healthy Debug suite with ordinary local socket/backend access | Exit 0; 155 pass, 4 existing skips, 159 total |
| `final/healthy-release-safe-unrestricted` | Same unchanged healthy suite plus `-Doptimize=ReleaseSafe`, with ordinary local socket/backend access | Exit 0; 155 pass, 4 existing skips, 159 total |
| `final/windows-release-safe` | Foreign Windows C library and full test executable compilation; command below | Exit 0; 8/8 build steps |
| `final/abi-compile` | Same Windows layout/closed-error consumer after edits | Exit 0 |
| `final/abi-compare` | `cmp` of base/final consumer assembly | Exit 0; byte-identical |
| `final/fmt-check` | `zig fmt --check` on all four changed source files | Exit 0 |
| `final/whitespace`, `final/whitespace-final` | `git diff --check` | Exit 0 |

The default sandbox denied socket creation with EPERM and made the expected
io_uring preference unavailable. The failed log was retained separately; no
test, assertion, gate, or production code was changed to accommodate it. The
same unchanged healthy checks then passed with ordinary OS access.

The healthy suite grew from the supplied baseline of 151 passing tests and 4
existing skips to 155 passing tests and the same 4 skips.

## Exact foreign commands

The working directory for all three was the clone above. These commands only
compiled or installed artifacts; no Windows executable was run.

```sh
ZIG_GLOBAL_CACHE_DIR=/workspaces/uWebZockets/.uwz-work/evidence/libxev-udp-fix/cache-global /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build-obj -target x86_64-windows-gnu -OReleaseSafe -fstrip --dep xev -Mroot=/workspaces/uWebZockets/.uwz-work/evidence/iocp-cancel-not-found/implementation/abi_contract.zig -Mxev=src/main.zig -fno-emit-bin -femit-asm=/workspaces/uWebZockets/.uwz-work/evidence/iocp-cancel-not-found/implementation/base/abi_contract.s

ZIG_GLOBAL_CACHE_DIR=/workspaces/uWebZockets/.uwz-work/evidence/libxev-udp-fix/cache-global /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build -Dtarget=x86_64-windows-gnu -Doptimize=ReleaseSafe -Demit-man-pages=false --prefix /workspaces/uWebZockets/.uwz-work/evidence/iocp-cancel-not-found/implementation/final/windows-release-safe -j2 --summary all

ZIG_GLOBAL_CACHE_DIR=/workspaces/uWebZockets/.uwz-work/evidence/libxev-udp-fix/cache-global /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build-obj -target x86_64-windows-gnu -OReleaseSafe -fstrip --dep xev -Mroot=/workspaces/uWebZockets/.uwz-work/evidence/iocp-cancel-not-found/implementation/abi_contract.zig -Mxev=src/main.zig -fno-emit-bin -femit-asm=/workspaces/uWebZockets/.uwz-work/evidence/iocp-cancel-not-found/implementation/final/abi_contract.s
```

## Source and compatibility audit

- Native success returns before any last-error read or classification. No
  mock, native-call injection, or native execution was used to check this.
- The same production classifier is used for accept and the combined
  read/pread/write/pwrite/recv/send/sendto/recvfrom branch.
- FALSE+SUCCESS, ordinary failures, and unknown Win32 values remain unexpected
  failures. The existing Windows unexpected-error diagnostic remains at the
  native boundary.
- `CancelError` remains exactly `error{Unexpected}`. `Result.cancel` remains
  `CancelError!void`; its consumer exhaustively switches only `Unexpected`.
- On x86_64-windows-gnu, Result is 40 bytes/alignment 8; Completion is 272
  bytes/alignment 8. Every exported Completion field offset and the consumer
  code are byte-identical in the before/after assembly. See `abi_contract.zig`
  and `final/abi-values.txt`.
- Completion and Result declarations, flags, counters, queues, callbacks,
  `.dead`, and `.adding` handling are unchanged. In particular, raw `.adding`
  cancellation still suppresses submission without promising a target callback.
- No ownership or lifetime algorithm changed. A cancellation acknowledgement
  does not retire target storage or discharge an H1 pin awaiting its genuine
  callback; caller policy is handled by root's R3 work.
- `build.zig`, `src/backend/epoll.zig`, `src/c_api.zig`, and `include/xev.h`
  hashes match the base manifest. No build dependency was added.

The primary [Microsoft CancelIoEx documentation](https://learn.microsoft.com/en-us/windows/win32/api/ioapiset/nf-ioapiset-cancelioex)
was checked: a missing request yields FALSE with ERROR_NOT_FOUND, and target
OVERLAPPED storage must remain available until the operation completes.
The implementation deliberately changes only the result classification.

## Remaining work and limits

No Windows runtime, native CancelIoEx experiment, cancellation/interleaving
probe, injected completion, invalid descriptor, resource-exhaustion test, or
stopped experiment was constructed or executed. Pure policy tests do not prove
native timing or caller ownership algorithms. Independent source review is
still required before any candidate commit; root owns integration, root quality
gates, graph refresh, R3 documentation, and all publication/pin decisions.
