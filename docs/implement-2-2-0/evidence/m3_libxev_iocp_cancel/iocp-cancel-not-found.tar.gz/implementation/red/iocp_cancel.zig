const std = @import("std");

/// Classifies only the last error captured after CancelIoEx returns FALSE.
pub fn failure_is_acknowledged(err: std.os.windows.Win32Error) bool {
    _ = err;
    return false;
}
