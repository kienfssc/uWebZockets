const xev = @import("xev").IOCP;

comptime {
    if (xev.CancelError != error{Unexpected}) @compileError("CancelError changed");
}

export const iocp_completion_size: usize = @sizeOf(xev.Completion);
export const iocp_completion_align: usize = @alignOf(xev.Completion);
export const iocp_result_size: usize = @sizeOf(xev.Result);
export const iocp_result_align: usize = @alignOf(xev.Result);
export const iocp_completion_op_offset: usize = @offsetOf(xev.Completion, "op");
export const iocp_completion_userdata_offset: usize = @offsetOf(xev.Completion, "userdata");
export const iocp_completion_callback_offset: usize = @offsetOf(xev.Completion, "callback");
export const iocp_completion_next_offset: usize = @offsetOf(xev.Completion, "next");
export const iocp_completion_result_offset: usize = @offsetOf(xev.Completion, "result");
export const iocp_completion_flags_offset: usize = @offsetOf(xev.Completion, "flags");
export const iocp_completion_overlapped_offset: usize = @offsetOf(xev.Completion, "overlapped");
export const iocp_completion_loop_offset: usize = @offsetOf(xev.Completion, "loop");

export fn consume_iocp_cancel(result: *const xev.Result) void {
    result.cancel catch |err| switch (err) {
        error.Unexpected => {},
    };
}
