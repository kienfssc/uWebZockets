from pathlib import Path, PurePosixPath
import gzip, hashlib, io, json, os, re, tarfile

root = Path('/workspaces/uWebZockets')
evidence = root / '.uwz-work/evidence/iocp-cancel-not-found'
dest = root / 'docs/implement-2-2-0/evidence/m3_libxev_iocp_cancel'
dest.mkdir(parents=True, exist_ok=True)
archive = dest / 'iocp-cancel-not-found.tar.gz'

scope = '''# IOCP cancellation-result candidate

The exact reviewed four-file source is local append commit b2afbafa6900d147ea0dea56e33b612b18f278d4,
parent 29490914cf58b24d7ab32ca5349f9a03a910435f, tree 512dbee775106f1a84d14715a0ce4cf85f47dceb.
Only FALSE+ERROR_NOT_FOUND is acknowledged. Success avoids reading stale last-error;
other failures still use Unexpected. Public errors and layout are unchanged.
An acknowledgement does not retire target storage or promise a target callback for adding state.

Independent source review found no actionable findings within this bounded change.
Raw extracted-policy red, successful focused/healthy suites, foreign compilation,
byte-identical ABI assembly, source snapshots and exact commands are retained.
Default-sandbox OS-access failures are retained separately from successful unrestricted checks.
Windows artifacts are omitted with a path/size/hash inventory; Windows was not executed.
The complete-history Git bundle restores its commit/tree into an empty repository and passes strict fsck.

No new native cancellation/interleaving/race/leak/error-injection experiment ran.
The stopped experiment stays stopped. This does not establish H1 transport lifetime safety.
Fresh R3 source review additionally requires worker post-publication access removal and
failed epoll registration rollback before the proposed transport retirement algorithm can land.
Maintained publication, protection confirmation, root pin adoption and root integration remain open.
The Codespace token reports push=false for both maintained dependencies on 2026-10-27.
'''
(evidence / 'SCOPE.md').write_text(scope)
permission_dir = root / '.uwz-work/evidence/maintained-permissions-resumed'
(evidence / 'maintained-permissions').mkdir(exist_ok=True)
for name in ('viewer.log', 'libxev.log', 'lsquic.log'):
    (evidence / 'maintained-permissions' / name).write_bytes((permission_dir / name).read_bytes())

omitted = {}
retained = {}
for path in sorted(evidence.rglob('*')):
    if not path.is_file():
        continue
    assert not path.is_symlink(), str(path)
    name = path.relative_to(evidence).as_posix()
    data = path.read_bytes()
    entry = {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}
    if name.startswith('implementation/final/windows-release-safe/'):
        omitted[name] = entry
    else:
        retained[name] = data
omission_data = (json.dumps({'reason':'Derived foreign build outputs, no Windows execution', 'files':omitted}, indent=2) + '\n').encode()
(evidence / 'omitted-binaries.json').write_bytes(omission_data)
retained['omitted-binaries.json'] = omission_data

sensitive = [v.encode() for k,v in os.environ.items() if re.search(r'(?:TOKEN|SECRET|PASSWORD|CREDENTIAL|API_KEY)$',k) and len(v) >= 20]
pattern = re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})')
for name,data in retained.items():
    assert not any(value in data for value in sensitive), f'Credential match: {name}'
    assert not pattern.search(data), f'Token pattern: {name}'
with tarfile.open(fileobj=io.BytesIO(retained['source.tar.gz']),mode='r:gz') as source:
    for member in source.getmembers():
        if member.isfile():
            data = source.extractfile(member).read()
            assert not any(value in data for value in sensitive), f'Source credential match: {member.name}'
            assert not pattern.search(data), f'Source token pattern: {member.name}'
inventory = {name:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in retained.items()}
retained['inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
with archive.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as package:
            for name,data in sorted(retained.items()):
                member = tarfile.TarInfo(name)
                member.size,member.mode,member.mtime = len(data),0o644,0
                package.addfile(member,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as package:
    for member in package.getmembers():
        path = PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        data = package.extractfile(member).read()
        assert data == retained[member.name]
manifest = {
    'date':'2026-10-27', 'archive':archive.name,
    'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_bytes':archive.stat().st_size,
    'safe_regular_members':len(retained), 'inventory_entries':len(inventory),
    'candidate':json.loads((evidence/'candidate.json').read_text()),
    'credential_scan':'Outer retained bytes and decoded source checked against credential values/token patterns; packed historical objects not exhaustively decoded',
    'omitted_foreign_outputs':omitted, 'files':inventory
}
(dest / 'manifest.json').write_text(json.dumps(manifest,indent=2) + '\n')
print(json.dumps({k:manifest[k] for k in ('archive_sha256','archive_bytes','safe_regular_members','inventory_entries')},indent=2))
