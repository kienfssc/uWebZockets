# Accepted bounded IOCP cancellation-result plan

Root accepts the fresh architect contract from /root/architect_iocp_cancel_result after independent R3 source review /root/review_h1_retirement_resume_1. Base commit is reviewed local 29490914cf58b24d7ab32ca5349f9a03a910435f, tree e13b3948e95075cd1245b25a872fa714045ba95e.

Only FALSE CancelIoEx with immediate ERROR_NOT_FOUND becomes the existing success acknowledgement. Every other failure retains windows.unexpectedError(err). GetLastError is read once immediately on FALSE, never on native success. Both accept and read/pread/write/pwrite/recv/send/sendto/recvfrom paths use the same policy. Preserve CancelError=error{Unexpected}, result and completion layouts, counters, queues, .dead/.adding semantics and C ABI.

The pure decision takes Win32Error, acknowledges only NOT_FOUND and is consumed by the actual native boundary. A small native helper may centralize atomic error capture and keep both callers shallow. Existing main test root imports focused src/tests cases; avoid a new build dependency. Pure regression must use the real classifier, on Linux with values only. Record any declaration-only or extracted-old-policy red honestly. Compile the Windows graph without execution; retain closed-error/layout consumer evidence. No native Windows claim.

R3 must retain target pins for every IOCP ACK under submit-before-cancel, with no generic target callback promise for raw .adding cancellation. io_uring success, NotFound and ExpirationInProgress all retain target ownership until the real callback. Timers retire frames, never targets. The expected Windows missing-cancel outcome must not trigger the new fatal observer.

Scope excludes physical-close implementation, timer ordering changes, new native cancellation/interleaving/race/crash/leak probes, invalid descriptors, resource exhaustion, injected completions and the stopped experiment. Use pure classification and unchanged healthy verification only. Independent source review is required before a local append candidate commit. Root controls commits, complete recovery bundle, push and any publication/pin decision. Maintained publication/protection and all-four-view adoption remain separate.

Primary sources: https://learn.microsoft.com/en-us/windows/win32/api/ioapiset/nf-ioapiset-cancelioex and https://raw.githubusercontent.com/axboe/liburing/master/man/io_uring_prep_cancel.3 .
