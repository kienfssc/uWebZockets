# IOCP cancellation-result candidate

The exact reviewed four-file source is local append commit b2afbafa6900d147ea0dea56e33b612b18f278d4,
parent 29490914cf58b24d7ab32ca5349f9a03a910435f, tree 512dbee775106f1a84d14715a0ce4cf85f47dceb.
Only FALSE+ERROR_NOT_FOUND is acknowledged. Success avoids reading stale last-error;
other failures still use Unexpected. Public errors and layout are unchanged.
An acknowledgement does not retire target storage or promise a target callback for adding state.

Independent source review found no actionable findings within this bounded change.
Raw extracted-policy red, successful focused/healthy suites, foreign compilation,
byte-identical ABI assembly, source snapshots and exact commands are retained.
Default-sandbox OS-access failures are retained separately from successful unrestricted checks.
Windows artifacts are omitted with a path/size/hash inventory; Windows was not executed.
The complete-history Git bundle restores its commit/tree into an empty repository and passes strict fsck.

No new native cancellation/interleaving/race/leak/error-injection experiment ran.
The stopped experiment stays stopped. This does not establish H1 transport lifetime safety.
Fresh R3 source review additionally requires worker post-publication access removal and
failed epoll registration rollback before the proposed transport retirement algorithm can land.
Maintained publication, protection confirmation, root pin adoption and root integration remain open.
The Codespace token reports push=false for both maintained dependencies on 2026-10-27.
