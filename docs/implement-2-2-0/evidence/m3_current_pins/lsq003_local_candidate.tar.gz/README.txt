Local LSQ-003 HPACK gitlink candidate for independent review

Commit: 87e318737657b2c6cde04ad94d583651340d6968
Parent: 85bd081c9103c077a7cc98271d09334d0f1043d4
Tree:   73c9b29643d0c37c2ca2e93d3a0a539dfe4badc1
Checkout: /tmp/uwz-lsq003.6DDWrH/lsquic
Local branch: sync/hpack-gitlink-alignment-local

Exactly one mode-160000 path changes:
src/lshpack cf0f70dd10b352194c97448eb5d00b4aa484f531 ->
            fda48e02491d865cce00612be8cc10c2622b8e55

QPACK remains 91567706c41c0d97ab8dc576873ecd472d7869fa. Every other path,
including lsquic source, existing fork guards, generated inputs and build
files, compares equal. Candidate and targeted-test source checkouts are
clean. The root repository was not edited by this slice; root before/after
status snapshots preserve the concurrent parent-owned work and head move.

The 880-byte incremental Git bundle preserves the candidate and its gitlink.
It explicitly requires the known published parent. Verification and restore
in an independent temporary repository reproduced the exact full commit,
parent and tree. This is not a full M6 fork backup. No build-time patch,
source overlay or unpublished root pin is introduced.

Read candidate_manifest.json, ledger_proposal.md,
publication_and_restoration.md and targeted_test_notes.txt. Exact commands,
raw output and actual statuses are retained. Ten focused upstream HPACK
test runs passed with Zig 0.16.0: five Debug and five UB-trap runs, with the
known alignment exception confined to the bundled xxhash object. The first
attempt's xxhash alignment abort is also retained and explained; no HPACK
assertion or existing gate was weakened.

Live remote checks:
- Published maintained integration: 85bd081c9103c077a7cc98271d09334d0f1043d4
- Maintained master: 413ca7c1acb443b0f9f7aa28611ca723c6738844
- Upstream master: 02b10a9e620bc235e40baa8dd0b2d9f32ff96cab
- Both defaults advertise master. Exact live mirror equality is false.

No remote ref was written. No fork, pull request or comment was created.
The candidate is unpublished and requires independent review plus authorized
maintainer publication before any authoritative pin update. M3 remains open.
