#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0

run_root=/tmp/uwz-lsq003.6DDWrH
source_root="$run_root/lshpack"
output_root="$run_root/targeted_tests_v2"
mkdir "$output_root" "$run_root/test-global-cache-v2" "$run_root/test-local-cache-v2"
cd "$output_root"
export ZIG_GLOBAL_CACHE_DIR="$run_root/test-global-cache-v2"
export ZIG_LOCAL_CACHE_DIR="$run_root/test-local-cache-v2"
test "$(git -C "$source_root" rev-parse HEAD)" = fda48e02491d865cce00612be8cc10c2622b8e55
test -z "$(git -C "$source_root" status --porcelain)"
zig version > zig_version.txt
test "$(cat zig_version.txt)" = 0.16.0
command -v zig > zig_path.txt
date -u '+started_at_utc=%Y-%m-%dT%H:%M:%SZ' > timestamps.txt

common_flags=(
    -std=c11 -O0 -g -DLS_HPACK_EMIT_TEST_CODE=1
    '-DXXH_HEADER_NAME="xxhash.h"'
    -I "$source_root" -I "$source_root/test"
    -I "$source_root/deps/xxhash"
)

run_case() {
    local mode=$1
    local name=$2
    local test_source=$3
    shift 3
    local output="$output_root/${mode}_${name}"
    local -a flags=("${common_flags[@]}")
    if test "$mode" = ubsan_trap; then
        flags+=(-fsanitize=undefined -fsanitize-trap=undefined)
    fi
    {
        printf '%q ' zig cc "${flags[@]}" "$@" "$test_source" "$source_root/lshpack.c" "$output_root/${mode}_xxhash.o" -o "$output"
        printf '\n'
    } > "$output.command.txt"
    local compile_status=0
    zig cc "${flags[@]}" "$@" "$test_source" "$source_root/lshpack.c" "$output_root/${mode}_xxhash.o" -o "$output" > "$output.compile.log" 2>&1 || compile_status=$?
    printf '%s\n' "$compile_status" > "$output.compile.exit.txt"
    test "$compile_status" = 0
    local run_status=0
    "$output" > "$output.run.log" 2>&1 || run_status=$?
    printf '%s\n' "$run_status" > "$output.run.exit.txt"
    printf '%s\t%s\t%s\t%s\n' "$mode" "$name" "$compile_status" "$run_status" >> results.tsv
    test "$run_status" = 0
}

for mode in zig_debug ubsan_trap; do
    mode_flags=()
    if test "$mode" = ubsan_trap; then
        mode_flags+=(-fsanitize=undefined -fsanitize-trap=undefined)
    fi
    # The exception belongs only to bundled xxhash's intentional unaligned
    # reads; HPACK and its tests retain their full alignment checks.
    printf '%q ' zig cc "${common_flags[@]}" "${mode_flags[@]}" -fno-sanitize=alignment -c "$source_root/deps/xxhash/xxhash.c" -o "$output_root/${mode}_xxhash.o" > "$output_root/${mode}_xxhash.command.txt"
    printf '\n' >> "$output_root/${mode}_xxhash.command.txt"
    xxhash_status=0
    zig cc "${common_flags[@]}" "${mode_flags[@]}" -fno-sanitize=alignment -c "$source_root/deps/xxhash/xxhash.c" -o "$output_root/${mode}_xxhash.o" > "$output_root/${mode}_xxhash.compile.log" 2>&1 || xxhash_status=$?
    printf '%s\n' "$xxhash_status" > "$output_root/${mode}_xxhash.compile.exit.txt"
    test "$xxhash_status" = 0
    for hash in 0 1; do
        for http in 0 1; do
            run_case "$mode" "hpack_hash${hash}_http${http}" "$source_root/test/test_hpack.c" "-DLSHPACK_DEC_HTTP1X_OUTPUT=$http" "-DLSHPACK_DEC_CALC_HASH=$hash"
        done
    done
    run_case "$mode" int "$source_root/test/test_int.c"
done

git -C "$source_root" status --porcelain > source_status_after.txt
test ! -s source_status_after.txt
date -u '+finished_at_utc=%Y-%m-%dT%H:%M:%SZ' >> timestamps.txt
