# Local restoration and publication prerequisites

The candidate is unpublished. No authoritative pin names it. The current
session has no write access to the maintained lsquic fork, and its local
origin push URL is deliberately disabled. Nothing was pushed, commented on,
or opened as a pull request. All upstream repositories remain fetch-only.

The incremental `lsq003_candidate.bundle` requires published parent
`85bd081c9103c077a7cc98271d09334d0f1043d4`. It is a review/restoration
artifact for one candidate commit, not a full M6 fork backup. Its commit
contains the gitlink; it does not contain the HPACK submodule's Git objects.
The existing exact HPACK commit must be acquired separately from its
read-only upstream when a complete initialized checkout is needed.

Restore into a temporary clone that already contains the parent:

```sh
git bundle verify /path/to/lsq003_candidate.bundle
git fetch /path/to/lsq003_candidate.bundle \
  refs/heads/sync/hpack-gitlink-alignment-local:refs/heads/review/lsq003-candidate
git show --raw --full-index refs/heads/review/lsq003-candidate
```

An independent temporary bare repository was seeded with only the known
parent's retained history, verified this bundle, fetched the review ref,
and reproduced the exact candidate SHA, parent and tree. The raw verification
and fetch logs are retained. No patch is applied to a vendor build tree.

Before any publication or pin acceptance:

1. Independently review the one-gitlink diff, retained decoder-hardening
   rationale, narrow xxhash test exception and proposed LSQ-003 row.
2. Obtain authorized maintainer fork access. Re-read published integration
   and mirror refs; do not assume this local candidate is still current.
3. Address the recorded live mirror mismatch through the maintained-fork
   policy. The reviewed fork mirror is `413ca7c1...`; live upstream master
   was `02b10a9e...`. Review that upstream range and perform any authorized
   fast-forward mirror sync separately. Do not merge unrelated upstream
   source changes into this one-gitlink candidate.
4. Confirm required mirror and integration protections are active. The
   current slice does not claim protection verification.
5. Publish only a reviewed topic branch in `farbenbuilds/lsquic`, then use a
   reviewed pull request targeting `uwz/main`. Never push directly to that
   append-only integration branch or to the upstream repository. If the
   integration parent changes first, prepare and re-review a new local
   candidate on the published parent; do not rewrite integration history.
6. After a reviewed integration merge, use its resulting full commit in all
   four uWebZockets dependency views, derive and compare the actual Zig and
   Nix hashes, add the ledger row, notices and migration/changelog record,
   and run the required fresh-cache build, clean package consumer and
   protocol gates. These later steps are not claimed by this local candidate.

The existing uWebZockets pin remains `85bd081c...`. M3 remains open until
publication, synchronized authoritative metadata and required review/gates
are complete. Full final fork bundles, second-machine reproduction and
platform runtime evidence remain separate M6 work.
