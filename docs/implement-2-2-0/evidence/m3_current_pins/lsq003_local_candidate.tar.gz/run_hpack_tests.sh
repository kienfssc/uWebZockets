#!/usr/bin/env bash
set -euo pipefail

run_root=/tmp/uwz-lsq003.6DDWrH
source_root="$run_root/lshpack"
mkdir "$run_root/targeted_tests" "$run_root/test-global-cache" "$run_root/test-local-cache"
export ZIG_GLOBAL_CACHE_DIR="$run_root/test-global-cache"
export ZIG_LOCAL_CACHE_DIR="$run_root/test-local-cache"
test "$(git -C "$source_root" rev-parse HEAD)" = fda48e02491d865cce00612be8cc10c2622b8e55
test -z "$(git -C "$source_root" status --porcelain)"
zig version > "$run_root/targeted_tests/zig_version.txt"
test "$(cat "$run_root/targeted_tests/zig_version.txt")" = 0.16.0
command -v zig > "$run_root/targeted_tests/zig_path.txt"
date -u '+started_at_utc=%Y-%m-%dT%H:%M:%SZ' > "$run_root/targeted_tests/timestamps.txt"

run_case() {
    local mode=$1
    local name=$2
    local test_source=$3
    shift 3
    local output="$run_root/targeted_tests/${mode}_${name}"
    local -a flags=(
        -std=c11 -O0 -g -DLS_HPACK_EMIT_TEST_CODE=1
        '-DXXH_HEADER_NAME="xxhash.h"'
        -I "$source_root" -I "$source_root/test"
        -I "$source_root/deps/xxhash"
    )
    if test "$mode" = ubsan_trap; then
        # Bundled xxhash deliberately reads unaligned words; preserve its
        # documented alignment exception while checking other C UB.
        flags+=(-fsanitize=undefined -fsanitize-trap=undefined -fno-sanitize=alignment)
    fi
    {
        printf '%q ' zig cc "${flags[@]}" "$@" "$test_source" "$source_root/lshpack.c" "$source_root/deps/xxhash/xxhash.c" -o "$output"
        printf '\n'
    } > "$output.command.txt"
    local compile_status=0
    zig cc "${flags[@]}" "$@" "$test_source" "$source_root/lshpack.c" "$source_root/deps/xxhash/xxhash.c" -o "$output" > "$output.compile.log" 2>&1 || compile_status=$?
    printf '%s\n' "$compile_status" > "$output.compile.exit.txt"
    test "$compile_status" = 0
    local run_status=0
    "$output" > "$output.run.log" 2>&1 || run_status=$?
    printf '%s\n' "$run_status" > "$output.run.exit.txt"
    printf '%s\t%s\t%s\t%s\n' "$mode" "$name" "$compile_status" "$run_status" >> "$run_root/targeted_tests/results.tsv"
    test "$run_status" = 0
}

for mode in plain ubsan_trap; do
    for hash in 0 1; do
        for http in 0 1; do
            run_case "$mode" "hpack_hash${hash}_http${http}" "$source_root/test/test_hpack.c" "-DLSHPACK_DEC_HTTP1X_OUTPUT=$http" "-DLSHPACK_DEC_CALC_HASH=$hash"
        done
    done
    run_case "$mode" int "$source_root/test/test_int.c"
done

git -C "$source_root" status --porcelain > "$run_root/targeted_tests/source_status_after.txt"
test ! -s "$run_root/targeted_tests/source_status_after.txt"
date -u '+finished_at_utc=%Y-%m-%dT%H:%M:%SZ' >> "$run_root/targeted_tests/timestamps.txt"
