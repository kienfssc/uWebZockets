# Proposed LSQ-003 ledger entry

This is a local proposal for independent review. It does not modify the
uWebZockets ledger or any authoritative dependency pin.

| ID | Fork | Area | Upstream reference | Invariant | Test evidence | Retirement criterion |
| --- | --- | --- | --- | --- | --- | --- |
| LSQ-003 | lsquic | HPACK gitlink alignment | None: downstream metadata alignment to reviewed upstream ls-hpack commit `fda48e02491d865cce00612be8cc10c2622b8e55` | The fork records the same hardened HPACK revision that uWebZockets already builds; QPACK, lsquic source, LSQ-001 and LSQ-002 remain unchanged. | Exactly one mode-160000 gitlink delta; all other paths compare equal; incremental bundle restores the exact commit, parent and tree; upstream HPACK's four hash/HTTP-output configurations and integer tests pass with Zig 0.16.0 in Debug and UB-trap modes, with the alignment exception limited to the bundled xxhash object. | A compatible upstream base records this HPACK revision or a reviewed successor synchronized with the separately pinned package, preserving equivalent decoder hardening. |

Local candidate:

- Commit: `87e318737657b2c6cde04ad94d583651340d6968`
- Parent: `85bd081c9103c077a7cc98271d09334d0f1043d4`
- Tree: `73c9b29643d0c37c2ca2e93d3a0a539dfe4badc1`
- Path: `src/lshpack`, mode 160000 retained
- Old gitlink: `cf0f70dd10b352194c97448eb5d00b4aa484f531`
- Proposed gitlink: `fda48e02491d865cce00612be8cc10c2622b8e55`
- QPACK remains `91567706c41c0d97ab8dc576873ecd472d7869fa`.

The separately pinned HPACK package already contains decoder UB repairs and
malformed EOS-padding rejection. Rolling it back to the old gitlink would
remove those changes. This proposal changes only the fork's dependency
metadata; it introduces no decoder implementation patch or ABI change.

No workflow, guard, source list, generated input, build flag, root manifest
or local overlay is changed. No source was rewritten inside a Zig cache.
