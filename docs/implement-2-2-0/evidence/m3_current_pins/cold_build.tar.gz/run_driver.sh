#!/usr/bin/env bash
set -euo pipefail

run_root=/tmp/uwz-m3.NDjCTk
source_root=/home/codespace/.codex/worktrees/d7a1/uWebZockets
revision=fa7449e80334cef360cb32ec61e051d255c37249
global_cache="$run_root/global"
library_cache="$run_root/library-cache"
consumer_cache="$run_root/consumer-cache"
mkdir "$global_cache" "$library_cache" "$consumer_cache" "$run_root/probe-tmp"

cd "$source_root"
test "$(git rev-parse HEAD)" = "$revision"
test -z "$(git status --porcelain --untracked-files=no)"
test ! -e zig-pkg
test ! -L zig-pkg
test ! -e .zig-cache
test ! -L .zig-cache
test -z "$(ls -A "$global_cache")"
test -z "$(ls -A "$library_cache")"
test -z "$(ls -A "$consumer_cache")"
{
    printf 'source_commit=%s\n' "$revision"
    printf 'source_root=%s\n' "$source_root"
    printf 'tracked_clean=true\nproject_zig_pkg_absent=true\nproject_zig_cache_absent=true\n'
    printf 'global_cache_empty=true\nlibrary_cache_empty=true\nconsumer_cache_empty=true\n'
    date -u '+started_at_utc=%Y-%m-%dT%H:%M:%SZ'
} > "$run_root/preflight.txt"
git status --porcelain --untracked-files=no > "$run_root/source_status_before.txt"
git ls-tree HEAD vendor/h1spec > "$run_root/h1spec_gitlink.txt"
sha256sum flake.lock build.zig.zon build.zig.zon.json build.zig.zon.nix build.zig.zon.txt .gitmodules > "$run_root/source_checksums.txt"
cp build.zig.zon build.zig.zon.json build.zig.zon.nix build.zig.zon.txt "$run_root/"

export ZIG_GLOBAL_CACHE_DIR="$global_cache"
export ZIG_LOCAL_CACHE_DIR="$library_cache"
zig version > "$run_root/zig_version.txt"
test "$(cat "$run_root/zig_version.txt")" = 0.16.0
command -v zig > "$run_root/zig_path.txt"
zig env > "$run_root/zig_env.json"
printf '%s\n' 'zig build lib -Doptimize=ReleaseSafe -j2 --prefix /tmp/uwz-m3.NDjCTk/install --summary all --verbose-cc' > "$run_root/cold_build.command.txt"
if zig build lib -Doptimize=ReleaseSafe -j2 --prefix "$run_root/install" --summary all --verbose-cc > "$run_root/cold_build.log" 2>&1; then
    build_status=0
else
    build_status=$?
fi
printf '%s\n' "$build_status" > "$run_root/cold_build.exit.txt"
printf 'cold_build exit %s\n' "$build_status"
if test -d zig-pkg; then
    printf '%s\n' zig-pkg/* > "$run_root/expanded_package_paths.txt"
fi
if test -d "$global_cache/p"; then
    rg --files --hidden --no-ignore -0 "$global_cache/p" | sort -z | xargs -0 -r sha256sum > "$run_root/package_checksums_after_build.txt"
fi
test "$build_status" = 0

test -z "$(ls -A "$consumer_cache")"
export ZIG_LOCAL_CACHE_DIR="$consumer_cache"
export TMPDIR="$run_root/probe-tmp"
printf '%s\n' 'sh -x scripts/check_package_paths.sh' > "$run_root/package_paths.command.txt"
if sh -x scripts/check_package_paths.sh > "$run_root/package_paths.log" 2>&1; then
    package_status=0
else
    package_status=$?
fi
printf '%s\n' "$package_status" > "$run_root/package_paths.exit.txt"
printf 'package_paths exit %s\n' "$package_status"
git status --porcelain --untracked-files=no > "$run_root/source_status_after.txt"
test ! -s "$run_root/source_status_after.txt"
if test -d "$global_cache/p"; then
    rg --files --hidden --no-ignore -0 "$global_cache/p" | sort -z | xargs -0 -r sha256sum > "$run_root/package_checksums_final.txt"
fi
date -u '+finished_at_utc=%Y-%m-%dT%H:%M:%SZ' > "$run_root/finished.txt"
test "$package_status" = 0
