M3 current-pin evidence slice

Source: fa7449e80334cef360cb32ec61e051d255c37249
Worktree: /home/codespace/.codex/worktrees/d7a1/uWebZockets
Zig: verified 0.16.0 from the pinned Nix shell
Start: 2026-10-26T13:59:33Z
Finish: 2026-10-26T14:13:48Z

Confirmed results:
- Genuinely cold ReleaseSafe library build: exit 0, 20/20 build steps.
- Existing .paths-filtered package consumer: exit 0 using a different fresh
  local cache and the newly populated shared global cache.
- Existing online maintained-fork provenance gate: exit 0.
- All six installed static archives contain only object members.
- Frozen source remained exact and tracked-clean.

Read gate_results.json and provenance_manifest.json first. Full unedited
command output and actual saved statuses are retained beside them. The cold
driver asserted both project-local Zig directories absent before any Zig
command and all three caches empty. No package was seeded from Nix or a warm
checkout. The downstream source package and its absence-of-removed-paths
proof are retained too.

Read audit_classification.txt for the executable-step audit and the existing
ls-hpack synchronization gap. Literal patch matches include meaningful
rejection guards and semantic-version names, which were preserved. Two
stale overlay comments remain for root correction. The HPACK history proves
the separately pinned newer revision retains decoder UB and malformed EOS
repairs; the source was left unchanged for owning-domain review.

maintained_sources/ contains both normalized cold-fetched Zig packages and
full Git source-tree archives for the current maintained integration pins.
Fork commit logs and the lsquic submodule gitlinks are retained under
fork_git/ (the evidence bundle includes textual records, not shallow Git
object stores). Full final Git bundles and second-machine/platform runtime
evidence remain M6 work.

The existing HTTP/3 and h1spec runs are reused from
docs/implement-2-2-0/evidence/m1_a/frozen_verification on the same source and
dependency pins. The HTTP/3 archive checksum was independently rechecked;
the protocol runs were not repeated by this slice.

No tracked source/doc file, Git commit, branch, remote ref or dependency pin
was changed by this slice. Root must integrate and independently review the
evidence. This report does not declare M3 complete.
