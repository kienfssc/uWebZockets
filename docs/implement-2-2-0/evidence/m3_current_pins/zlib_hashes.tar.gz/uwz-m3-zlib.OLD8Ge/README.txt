Read-only zlib hash-semantics addendum

Conclusion: both recorded hashes are correct. No generated-view repair or
regeneration is warranted for this discrepancy.

Both views identify the same pinned release URL:
https://github.com/madler/zlib/releases/download/v1.3.2/zlib-1.3.2.tar.gz
Both use Zig package hash:
N-V-__8AAJ2cNgAgfBtAw33Bxfu1IWISDeKKSr3DAqoAysIJ

JSON hash:
sha256-uzKaCizQJ00FUZ1hxmfAYuBpkNcuEl7i36jeZPARnRY=
This is the flat SHA256 of the downloaded archive bytes. It is retained for
naked archive packages by zon2nix's backwards-compatible JSON contract.
Official-source nix-prefetch-url without --unpack returned this hash,
confirmed again by nix hash file. Flat SHA256 in hex:
bb329a0a2cd0274d05519d61c667c062e06990d72e125ee2dfa8de64f0119d16

Nix hash:
sha256-tKLefmGqB2HVUMILJ7Gqa0v9GH7fqv64d5S5kK1tcYU=
This is the NAR hash of the unpacked source tree after its one top-level
directory is stripped. The generated Nix expression uses fetchzip.
Official-source nix-prefetch-url --unpack returned this hash, confirmed
again by nix hash path. Both prefetch commands exited 0.

The exact pinned zon2nix v0.9.0 source at
8e91c0d44aa49d0ac415f7e3046662e9aa754335 explicitly documents these different
JSON and Nix meanings in README.md:72-80. Its Dep.zig selects fetchzip for
archives with a top-level directory. Excerpts are retained beside this file.
The local migration commit 8c4463d8283e45d8c1b3aada806a173cb55324fe changed
zlib's Nix fetcher from fetchurl/unpack=false to fetchzip while preserving
the JSON contract; its exact diff is retained.

The retained cold Zig package has the same file paths and file bytes as the
official Nix-unpacked source. Its own NAR hash differs because Zig's package
representation marks os400/make.sh executable and drops two empty test
directories. The complete metadata comparison is retained. This explains
why hashing Zig's expanded package as a Nix path is not the fetchzip check.
No fetched package or source tree was changed during these checks.

The original current-pin evidence remains frozen at:
/tmp/uwz-m3-current-pin-evidence.tar.gz
SHA256 adf5dae9cf2e3bf2a6fe4c352527df9834d39d2f5b7246edcce19df796139505

Retained lsquic Git directory for a future reversible metadata candidate:
/tmp/uwz-m3.NDjCTk/fork_git/lsquic.git
It is a shallow bare repository. FETCH_HEAD names exact integration commit
85bd081c9103c077a7cc98271d09334d0f1043d4, the compatible base commit is
present, and no topic branch was created by this slice. M3 remains open for
the independently reviewed maintained-fork HPACK gitlink alignment.

No tracked manifest, source, documentation, dependency pin, branch or remote
ref was edited. No broad build was run.
