The `hash` in the JSON is in Nix's SRI form. For a naked package, one whose
hash begins `N-V-` because it has no manifest of its own, it is the SHA-256 of
the archive file as downloaded; for any other archive it is the Nix hash of
the unpacked contents, stripped of their top-level directory, and for a git
repository the Nix hash of an ordinary checkout, `.gitattributes` applied —
which the Nix expression's own git hash, taken without them, can differ from. Tools outside zon2nix build
distribution packages from this file, so that meaning does not change, even
though the Nix expression now fetches most naked packages unpacked and so
gives some of them a different hash from the JSON.
