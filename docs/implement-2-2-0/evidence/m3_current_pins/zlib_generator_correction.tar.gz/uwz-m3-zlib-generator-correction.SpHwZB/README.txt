Additive correction to zlib generator provenance

The earlier zlib addendum mislabeled the generator as v0.9.0 at
8e91c0d44aa49d0ac415f7e3046662e9aa754335. That revision belongs to the
transitive zon2nix_2 lock node, not the frozen root's zon2nix input.

Correct root input for uWebZockets fa7449e80334cef360cb32ec61e051d255c37249:
- Lock root: root
- root.inputs.zon2nix: node zon2nix
- Revision: d5a6545496dfb17878fe23d026e0a880ee9e12c9
- Source NAR: sha256-Z0jYkEqGgWoovZWSvQqwUDXzUn79QcG1ybpJG8fMQk0=
- Evaluated source: /nix/store/lqmhwfswwg03nbwrzqipa201pjr11px0-source
- Source package version: 0.9.1 (from its build.zig.zon)

The frozen flake selects inputs.zon2nix.packages.${system}.zon2nix. Structured
lock resolution, exact Nix eval output and status, source NAR hash and status,
source manifest, and excerpts are retained. The independently computed NAR
matches the actual root lock node. No assumptions about the last matching
node in the lock file are used.

The original source-path lookup had returned this same correct source path;
its excerpts were misattributed to the wrong commit/version. They describe
the actual root generator. This correction adds the decisive implementation
at src/main.zig:923-943: JSON emits the flat local archive SHA256 for naked
N-V packages; the Nix expression may fetch such archives unpacked.
src/Dep.zig:173-184 chooses fetchzip for a single-root-directory archive.

The verified numerical conclusion is unchanged:
- JSON flat archive SHA256:
  sha256-uzKaCizQJ00FUZ1hxmfAYuBpkNcuEl7i36jeZPARnRY=
- Nix unpacked fetchzip source NAR:
  sha256-tKLefmGqB2HVUMILJ7Gqa0v9GH7fqv64d5S5kK1tcYU=
Both matched independent official-source prefetches in the original
addendum. No zlib manifest repair or regeneration is required.

This record supersedes only the wrong generator identity/version attribution
in the earlier addendum's README.txt and result.json. Both prior immutable
bundle files remain byte-for-byte unchanged; their checksums are recorded.
No tracked source or generated view was edited.
