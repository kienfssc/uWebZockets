from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

root = Path('/workspaces/uWebZockets')
directory = root / '.uwz-work/evidence/h2-streaming/integration-client'
packages = Path('/tmp/uwz-h2-client-tooling/packages')
label = sys.argv[1]
source = directory / 'h2_client.py'
test = directory / 'info_budget_regression.py'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inventory():
    rows = [(str(path.relative_to(packages)), sha(path)) for path in sorted(packages.rglob('*')) if path.is_file()]
    expected = json.loads((root / '.uwz-work/evidence/h2-streaming/client-tooling/installed-files.json').read_text())
    assert rows == [tuple(row) for row in expected]
    assert len(rows) == 42
    return {'files': len(rows), 'sha256': hashlib.sha256(json.dumps(rows).encode()).hexdigest()}

for suffix in ('.json', '.log', '-source.py', '-regression.py'):
    assert not (directory / (label + suffix)).exists()
env = dict(os.environ, PYTHONPATH=str(packages), PYTHONDONTWRITEBYTECODE='1')
argv = [sys.executable, '-B', str(test)]
record = {'argv': argv, 'cwd': str(root), 'environment': {key: env[key] for key in ('PYTHONPATH', 'PYTHONDONTWRITEBYTECODE')},
          'python': sys.executable, 'python_sha256': sha(Path(sys.executable).resolve()),
          'source_before': sha(source), 'test_before': sha(test), 'package_before': inventory(),
          'scope': 'Pure encoded hyper-h2 client/server pair only; no network, sockets, native clients or uWebZockets'}
binding_code = 'import h2,h2.connection,h2.events,hpack,hyperframe,json; print(json.dumps({m.__name__:m.__file__ for m in (h2,h2.connection,h2.events,hpack,hyperframe)}))'
binding = subprocess.run([sys.executable, '-B', '-c', binding_code], env=env, capture_output=True, text=True, check=True)
record['loaded_bindings'] = json.loads(binding.stdout)
assert all(Path(value).is_relative_to(packages) for value in record['loaded_bindings'].values())
with (directory / (label + '.log')).open('xb') as output:
    result = subprocess.run(argv, cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=60)
record.update(exit_status=result.returncode, source_after=sha(source), test_after=sha(test), package_after=inventory())
(directory / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
shutil.copyfile(source, directory / (label + '-source.py'))
shutil.copyfile(test, directory / (label + '-regression.py'))
print((directory / (label + '.log')).read_text())
print('Exit status:', result.returncode)
sys.exit(result.returncode)
