from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

root = Path('/workspaces/uWebZockets')
directory = root / '.uwz-work/evidence/h2-streaming/integration-client'
tooling = root / '.uwz-work/evidence/h2-streaming/client-tooling'
packages = Path('/tmp/uwz-h2-client-tooling/packages')
label = sys.argv[1]
record_path = directory / (label + '.json')
assert not record_path.exists()
source = directory / 'h2_client.py'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def package_manifest():
    values = [(str(path.relative_to(packages)), sha(path))
              for path in sorted(packages.rglob('*')) if path.is_file()]
    assert values == [tuple(row) for row in json.loads((tooling / 'installed-files.json').read_text())]
    return hashlib.sha256(json.dumps(values).encode()).hexdigest()

env = dict(os.environ)
env['PYTHONPATH'] = str(packages)
env['PYTHONDONTWRITEBYTECODE'] = '1'
argv = [sys.executable, '-B', str(source), '--self-check']
record = {'argv': argv, 'cwd': str(root), 'source_before': sha(source),
          'package_before': package_manifest(), 'python': sys.executable,
          'python_sha256': sha(Path(sys.executable).resolve()),
          'environment': {'PYTHONPATH': str(packages), 'PYTHONDONTWRITEBYTECODE': '1'},
          'scope': 'Pure hyper-h2 protocol pair and bounded payload generator only; no uWebZockets, sockets, native clients or endpoint contact'}
started = time.monotonic()
with (directory / (label + '.log')).open('wb') as output:
    result = subprocess.run(argv, cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=60)
record.update(exit_status=result.returncode, elapsed_seconds=time.monotonic() - started)
record_path.write_text(json.dumps(record, indent=2) + '\n')
record.update(source_after=sha(source), package_after=package_manifest())
record_path.write_text(json.dumps(record, indent=2) + '\n')
shutil.copyfile(source, directory / (label + '-source.py'))
print((directory / (label + '.log')).read_text())
print('Exit status:', result.returncode)
sys.exit(result.returncode)
