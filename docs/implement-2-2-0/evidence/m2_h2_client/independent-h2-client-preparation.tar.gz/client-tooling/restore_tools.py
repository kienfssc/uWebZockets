"""Restore the exact pure HTTP/2 verifier sources without network or package scripts."""

from pathlib import Path
import hashlib
import json
import stat
import sys
import zipfile


def restore(destination):
    source = Path(__file__).resolve().parent
    if destination.exists():
        raise RuntimeError("choose a new empty destination path")
    records = json.loads((source / "packages.json").read_text())
    expected = json.loads((source / "installed-files.json").read_text())
    destination.mkdir(parents=True)
    for record in records:
        path = source / "wheels" / record["wheel"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != record["sha256"]:
            raise RuntimeError("wheel identity differs")
        with zipfile.ZipFile(path) as archive:
            for member in archive.infolist():
                relative = Path(member.filename)
                if relative.is_absolute() or ".." in relative.parts or stat.S_ISLNK(member.external_attr >> 16):
                    raise RuntimeError("unsafe wheel member")
                if relative.suffix.lower() in {".so", ".dll", ".pyd", ".dylib", ".exe", ".pth"}:
                    raise RuntimeError("pure-source wheel required")
                if ".data/scripts/" in member.filename:
                    raise RuntimeError("package scripts are excluded")
                target = destination / relative
                if member.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.exists():
                    raise RuntimeError("duplicate wheel output")
                target.write_bytes(archive.read(member))
    actual = [[str(path.relative_to(destination)), hashlib.sha256(path.read_bytes()).hexdigest()]
              for path in sorted(destination.rglob("*")) if path.is_file()]
    if actual != expected:
        raise RuntimeError("restored package source inventory differs")
    return {"path": str(destination), "files": len(actual),
            "source_digest": hashlib.sha256(json.dumps(actual).encode()).hexdigest(),
            "package_scripts_executed": False, "network_contact": False}


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise RuntimeError("usage: restore_tools.py NEW_DESTINATION")
    print(json.dumps(restore(Path(sys.argv[1]).resolve()), indent=2))
