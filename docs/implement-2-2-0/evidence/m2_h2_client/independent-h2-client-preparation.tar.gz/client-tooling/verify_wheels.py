from pathlib import Path
from email.parser import BytesParser
import datetime
import hashlib
import json
import shutil
import stat
import urllib.request
import zipfile

root = Path('/workspaces/uWebZockets')
output = root / '.uwz-work/evidence/h2-streaming/client-tooling'
wheels = Path('/tmp/uwz-h2-client-tooling/wheels')
packages = wheels.parent / 'packages'
assert not packages.exists()
packages.mkdir()
preserved = output / 'wheels'
preserved.mkdir(exist_ok=False)
records = []
requirements = []
for path in sorted(wheels.glob('*.whl')):
    with zipfile.ZipFile(path) as wheel:
        metadata_names = [name for name in wheel.namelist() if name.endswith('.dist-info/METADATA')]
        assert len(metadata_names) == 1
        metadata = BytesParser().parsebytes(wheel.read(metadata_names[0]))
        name, version = metadata['Name'], metadata['Version']
        assert name.lower() in {'h2', 'hpack', 'hyperframe'}
        url = 'https://pypi.org/pypi/' + name + '/' + version + '/json'
        with urllib.request.urlopen(url, timeout=30) as response:
            published = json.load(response)
        matches = [entry for entry in published['urls'] if entry['filename'] == path.name]
        assert len(matches) == 1
        origin = matches[0]
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert digest == origin['digests']['sha256']
        assert origin['packagetype'] == 'bdist_wheel' and origin['url'].startswith('https://files.pythonhosted.org/')
        assert not origin.get('yanked', False)
        for member in wheel.infolist():
            relative = Path(member.filename)
            assert not relative.is_absolute() and '..' not in relative.parts
            assert not stat.S_ISLNK(member.external_attr >> 16)
            assert relative.suffix.lower() not in {'.so', '.dll', '.dylib', '.pyd', '.exe', '.pth'}
            assert '.data/scripts/' not in member.filename
            destination = packages / relative
            if member.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            assert not destination.exists()
            destination.write_bytes(wheel.read(member))
        shutil.copyfile(path, preserved / path.name)
        requirements.append(name + '==' + version + ' --hash=sha256:' + digest)
        records.append({'name': name, 'version': version, 'wheel': path.name, 'sha256': digest,
                        'bytes': path.stat().st_size, 'metadata_url': url, 'source_url': origin['url'],
                        'retrieved_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        'requires_python': metadata['Requires-Python'],
                        'requires_dist': metadata.get_all('Requires-Dist', []),
                        'pure_wheel_only': True, 'package_scripts_executed': False})
manifest = [(str(path.relative_to(packages)), hashlib.sha256(path.read_bytes()).hexdigest())
            for path in sorted(packages.rglob('*')) if path.is_file()]
(output / 'requirements.lock').write_text('\n'.join(requirements) + '\n')
(output / 'packages.json').write_text(json.dumps(records, indent=2) + '\n')
(output / 'installed-files.json').write_text(json.dumps(manifest, indent=2) + '\n')
record = {'path': str(packages), 'files': len(manifest),
          'source_digest': hashlib.sha256(json.dumps(manifest).encode()).hexdigest(),
          'method': 'Verified official PyPI wheel hashes; extracted pure source without package scripts',
          'network_tests_run': False, 'client_api': 'https://python-hyper.org/projects/hyper-h2/en/stable/api.html'}
(output / 'tooling.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
print('Pinned packages:', [(entry['name'], entry['version']) for entry in records])
