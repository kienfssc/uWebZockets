# Client informational retention fix, round 1

Status: fixed and frozen for Root's independent re-review. Pure preparation only;
no live-use approval and no product/runtime acceptance claim.

## Cause and bounded behavior

`h2_client.py` appended every decoded `InformationalResponseReceived` header list.
CAPTURE bounds DATA prefix storage only, so repeated legal 100/103 responses could
retain unlimited headers. The fix adds fixed `INFO_COUNT_LIMIT = 16` and
`INFO_HEADER_BUDGET = 16384`, plus per-response `informational_bytes` accounting.
Each header costs 32 plus UTF-8 name/value bytes. Count and aggregate byte guards
run before copying/appending or changing retained response state. Stable failures:

- `informational response count limit exceeded`
- `informational response header budget exceeded`

The summary exposes accepted informational bytes. Sender/window/TLS/terminal
helpers are unchanged. Decode/trace state can advance before rejection; the
retained response state stays unchanged. These are retained-state budgets, not a
claim that hyper-h2 decoding itself allocates nothing or has identical bounds.

## Frozen identities

All artifact filenames below are relative to
`.uwz-work/evidence/h2-streaming/integration-client/`.

- Original helper: `e92dbdabe460a8f3b44eb10cdcff90d86262d86fefe4c536a09a678ca5e8503b`
- Fixed `h2_client.py`: `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`
- Final `info_budget_regression.py`: `64a56bbb091cb3a44fd003b0e6e9634722c5cb65e5f3867ca94e02008d3b0c8c`
- Python `/home/codespace/.python/current/bin/python3`, binary SHA256
  `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.
- Whole installed 42-file package inventory SHA256:
  `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`.
  Every before/after inventory matches immutable `client-tooling/installed-files.json`.
  Records verify loaded h2, h2.connection, h2.events, hpack and hyperframe paths
  under `/tmp/uwz-h2-client-tooling/packages` (h2 4.4.1, hpack 4.2.0,
  hyperframe 6.1.0). No packages, pins, wheels or original evidence changed.

Full original source: `client-info-budget-round1-behavior-red-source.py`.
Full fix diff: `client-info-budget-round1-fix.diff`.
Every run retains helper and regression snapshots, exact argv/environment,
Python identity, package inventory, loaded bindings, raw log and exit status.
The evidence runner is retained as `client-info-budget-round1-evidence-runner.py`;
its executed scratch path was `/tmp/uwz_info_budget_evidence.py`.
Python ran with `-B`, not `-O`; no Zig optimization mode applies.

## Commands and raw results

Working directory: `/workspaces/uWebZockets`.

```sh
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages python3 -B /tmp/uwz_info_budget_evidence.py client-info-budget-round1-behavior-red
```

Exit 1. `client-info-budget-round1-behavior-red.log` records these actual behavior
failures before any implementation, using literal budgets (no missing keys or
constants):

```text
count_boundary: over-budget informational response retained: count=17, bytes=714
byte_over_boundary: over-budget informational response retained: count=2, bytes=16385
byte_boundary_and_final: over-budget informational response retained: count=3, bytes=16459
entry_overhead: over-budget informational response retained: count=2, bytes=16386
```

```sh
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages python3 -B /tmp/uwz_info_budget_evidence.py client-info-budget-round1-final-green
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages python3 -B .uwz-work/evidence/h2-streaming/integration-client/run_selfcheck.py client-info-budget-round1-selfcheck
```

Both exit 0. Final regression raw output:

```text
count_boundary: retained_count=16, retained_bytes=672,
 diagnostic=informational response count limit exceeded
byte_over_boundary: retained_count=1, retained_bytes=42,
 diagnostic=informational response header budget exceeded
byte_boundary_and_final: retained_count=2, retained_bytes=16384,
 diagnostic=informational response header budget exceeded
entry_overhead: retained_count=1, retained_bytes=42,
 diagnostic=informational response header budget exceeded
failures: []
```

Full unabridged JSON output lives in the corresponding `.log` files. The regression
uses genuine encoded hyper-h2 peer pairs, three-byte wire fragmentation, exactly
16 accepted 100 responses followed by a refused 17th; aggregate 16384 accepted
and 16385 refused; UTF-8 multibyte field values; per-entry overhead with empty
values; unchanged retained summary/accounting after refusals; and normal final
headers, padded DATA, digest, trailers and stream end after the exact boundary.

Existing corrected self-check reports 100000000 logical generator bytes with
SHA256 `190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2`,
9 response bytes and 17 receive-flow bytes, retained 100/final/trailer headers,
and informational_bytes=42. This is preparation evidence only.

## Preserved intermediate failures

`client-info-budget-round1-green` exited 1 because `copy.deepcopy` reconstructs
hpack `HeaderTuple` values with a different tuple shape. A direct pure diagnosis
showed the copied summary already differed before rejection. The fixed helper
had correctly refused excess headers. The regression now snapshots canonical
JSON, retaining the complete response summary and avoiding tuple-subclass
reconstruction. This is a test correction, not a weakened retention assertion.
`client-info-budget-round1-corrected-green` exited 0; the final run added explicit
accepted-byte accounting equality and exited 0. All intermediate logs, JSON and
source snapshots remain intact. Earlier unrelated bad 33-byte-expected-literal
self-check failures remain untouched and are not behavioral-red evidence.

## Scope and limits

No sockets, TLS, native probes, uWebZockets servers or network contacts ran.
No product source, Task3 evidence, Root graph, refs, commits or package metadata
changed. Relevant project documents and review/testing/debugging skills were read.
No new project source exploration was needed beyond supplied located artifacts.
Zig/native/project-wide gates were intentionally outside this Python-only brief.
Root must independently review this frozen source before ordinary live use.

## Independent scratch AST refresh

Ran from fresh `/tmp/uwz_info_budget_ast_co1unw58`, initially containing only
identical copies of `h2_client.py` and `info_budget_regression.py`:

```sh
env PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

Exit 0. Raw output is retained in `client-info-budget-round1-ast.log`; exact
argv/cwd, original before/after hashes, identical scratch hashes and generated
graph identity are retained in `client-info-budget-round1-ast.json` beside it.
The helper remains SHA256 `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`;
the regression remains `64a56bbb091cb3a44fd003b0e6e9634722c5cb65e5f3867ca94e02008d3b0c8c`.
No source changes or test reruns occurred. Root/product graphs were untouched.
Code-only AST output (no LLM/API or docs extraction):

```text
Re-extracting code files in . (no LLM needed)...
  AST cache: 0/2 files served from cache (0%); 2 to extract
[graphify watch] Rebuilt: 36 nodes, 100 edges, 7 communities
[graphify watch] graph.json, graph.html and GRAPH_REPORT.md updated in graphify-out
Code graph updated. For doc/paper/image changes run /graphify --update in your AI assistant.
Tip: set GEMINI_API_KEY or GOOGLE_API_KEY to use Gemini for semantic extraction.
```

No tooling limitation encountered; the Gemini tip is informational and no key
or semantic extraction was requested or used. Generated AST/graph stays in `/tmp`.
