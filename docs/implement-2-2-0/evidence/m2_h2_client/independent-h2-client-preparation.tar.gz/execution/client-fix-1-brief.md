# Independent client preparation: review fix round 1

Root authored the separate client preparation; product Task3 has a different
worker and nonoverlapping ownership. This fix is an independent verification
artifact, not another product implementation. User's independent-team rule
permits parallel work in these disjoint paths. Do not edit product sources,
Task3 copies/evidence, Root tracked files or another agent's work. No subagents,
commits/refs/pins/network/package changes, sockets, clients or native probes.

Own only .uwz-work/evidence/h2-streaming/integration-client/h2_client.py, a focused
new pure regression script there, new nonoverwriting evidence labels, and the
round report beside this brief. Existing client/tooling evidence remains immutable.
Read preparation.md and the exact current source before editing.

Open finding, reviewer /root/review_h2_storage_measurement:
P2 at h2_client.py80-81: every InformationalResponseReceived appends its complete
headers without a count or byte limit. Repeated100/103 can grow retained memory
indefinitely; hyper-h2 legally accepts repeated informational responses and DATA
CAPTURE does not bound them. Fixed retained informational budget and deterministic
failure required before live use. This is a real bounded-tooling gap, not a plan
conflict. Keep the scope to this finding and directly necessary tests/accounting.

Add immutable INFO_COUNT_LIMIT=16 and INFO_HEADER_BUDGET=16384. Each informational
header entry costs32 plus UTF-8 byte lengths of its name/value; this bounds entry
overhead as well as values. Per-response state counts accepted informational
bytes. Preflight both count and aggregate budget before copying/appending/changing
retained state; on excess raise RuntimeError with a specific stable diagnostic.
Preserve ordinary informational/final/DATA/trailer behavior and all existing
sender/window/TLS/terminal semantics. Count and byte budgets apply across all
informational responses on a stream, not freshly per frame. Make accounting
observable in response_summary if useful. No production/server capacity changes.

Use a genuine pure hyper-h2 client/server pair for regression: exactly16 ordinary
100 headers accepted,17th refused with retained count/bytes unchanged; an aggregate
byte-budget boundary and one over-boundary informational field refused before
retention. Test actual encoded frame input, normal declared responses remain
usable, and optionally fragment incoming wire to preserve existing decoder scope.
Use literal budgets in the test before implementation so red proves actual
unbounded behavior, not missing constants/keys. Preserve red raw/source snapshot,
then implement and run covering regressions plus existing corrected pure selfcheck.
The earlier two bad33-byte-expected-literal failures are NOT behavioral-red proof;
do not reclassify or overwrite them.

Pinned packages at /tmp/uwz-h2-client-tooling/packages are h2 4.4.1/hpack4.2.0/
hyperframe6.1.0. Whole42-file manifest and loaded module bindings are verified in
client-tooling; requirements.lock, source URLs, wheels, restore_tools.py and
inventory remain immutable. Run Python -B with PYTHONPATH pointing there; no
bytecode/source pollution, network or native/server/client contact. Existing
run_selfcheck.py provides source/package/Python hash records; use fresh labels
and correct scope text. Full count100000000 generator hash190f6457... is only pure
client preparation, never uWebZockets or socket evidence.

Read applicable review/testing/debugging skills and project conventions. Before
new project source exploration use graphify query with installed prefix; supplied
paths can be read directly. Keep graphs/big scratch under /tmp. Refresh AST for
changed prepared Python code in an independent identical scratch copy if needed;
no API/semantic cost and no Root graph/source edits. Do not run unrelated Zig/
native/full-project gates for this Python artifact.

Save full preimage/fix diff and exact command/source/package/Python before-after
identities, logs and statuses. Freeze source after covering tests. Write
client-fix-1-report.md beside this brief, with cause, change, tests, outcomes and
limits. Return only status, source identity, short test summary and concerns.
Root will send a scoped re-review of this finding/fix only before any live use.
