"""Verify a supplied closure hash and actual owned-input mutation rejection."""
import argparse
import importlib.util
import os
from pathlib import Path
import stat
import sys

HERE = Path(__file__).resolve().parent
RUNNER = Path('/tmp/uwz-task5c3-runtime-v2/run_live.py')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    manifest_path = HERE / 'manifest-v4.json'
    spec = importlib.util.spec_from_file_location('closure_runner', RUNNER)
    if spec is None or spec.loader is None:
        raise ValueError('runner loader unavailable')
    module = importlib.util.module_from_spec(spec)
    sys.modules['closure_runner'] = module
    spec.loader.exec_module(module)
    manifest = module.check_manifest(manifest_path, args.manifest_sha256)
    print('current closure: accepted')
    target = HERE / 'run_live.py'
    if str(target) not in manifest['inputs']:
        raise ValueError('mutation target not bound')
    original = target.read_bytes()
    mode = stat.S_IMODE(target.stat().st_mode)
    try:
        target.write_bytes(original + b'\n')
        try:
            module.check_manifest(manifest_path, args.manifest_sha256)
        except RuntimeError as error:
            if str(target) not in str(error) or 'input identity differs' not in str(error):
                raise
            print('mutated actual input: rejected:', error)
        else:
            raise ValueError('mutated actual input accepted')
    finally:
        target.write_bytes(original)
        os.chmod(target, mode)
    if target.read_bytes() != original or stat.S_IMODE(target.stat().st_mode) != mode:
        raise ValueError('actual input restoration differs')
    module.check_manifest(manifest_path, args.manifest_sha256)
    print('restored closure: accepted')


if __name__ == '__main__':
    main()
