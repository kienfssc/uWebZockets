import json
import unittest
from unittest.mock import patch

import flow_ledger
import raw_observer
import run_live
import runner_adapter
import strict_close
import lifecycle_cases
from test_lifecycle_cases import ReuseDouble
import wire


class ProtocolDouble:
    def __init__(self):
        self.outbound_flow_control_window = 65535
        self.max_outbound_frame_size = 16384
        self.stream_windows = {}
        self.sent = []

    def local_flow_control_window(self, stream):
        return min(self.outbound_flow_control_window, self.stream_windows[stream])

    def send_data(self, stream, data, end_stream):
        self.sent.append((stream, data, end_stream))
        self.outbound_flow_control_window -= len(data)
        self.stream_windows[stream] -= len(data)


class OpsDouble:
    def __init__(self):
        self.next_stream = 1
        self.requests = []

    def start(self, protocol, records, raw, method, target, headers, eof, limit, wire_module, policy):
        stream = self.next_stream
        self.next_stream += 2
        protocol.stream_windows[stream] = 65535
        wire_module.register(records, raw, stream, limit, 200, 0, policy)
        return stream

    def flush_headers(self, *args):
        pass

    def flush(self, *args):
        pass

    def request(self, sock, protocol, records, raw, trace, path, deadline, wire_module, capture, limit):
        self.requests.append(path)
        return {'body': '{}'}

    def complete(self, sock, protocol, records, raw, trace, stream, deadline, wire_module, capture):
        del records[stream]
        del raw['streams'][stream]
        return {'body': json.dumps({'tag': 'actual'}), 'headers': [(':status', '200')]}


def setup():
    ops = OpsDouble()
    context = {'ops': ops, 'wire': wire, 'flow': flow_ledger, 'strict_close': strict_close,
               'payload': bytes(range(1, 11)) + b'final-upload-sentinel!', 'clock': lambda: 1,
               'deadline': 10, 'capture': None, 'buffered_requests': 0, 'sealed': False}
    connection = {'socket': object(), 'protocol': ProtocolDouble(), 'records': {}, 'raw': raw_observer.new_state(),
                  'trace': {'ledger': flow_ledger.FlowLedger(), 'events': {}}, 'offsets': {}, 'closed': False}
    return context, connection, ops


def metadata(tag):
    return {'method': 'POST', 'path': '/limit/' + tag, 'query': 'case=' + tag,
            'target': '/limit/' + tag + '?case=' + tag, 'x-case': tag, 'content-length': '32'}


class AdapterTests(unittest.TestCase):
    def test_actual_reuse_case_through_adapter(self):
        context, connection, _ = setup()
        case = ReuseDouble()
        class CaseOps(OpsDouble):
            def __init__(self):
                super().__init__()
                self.tags = {}
            def start(self, protocol, records, raw, method, target, headers, eof, limit, wire_module, policy):
                tag = target.split('?', 1)[0].rsplit('/', 1)[1]
                case.start(tag, metadata(tag), policy)
                stream = super().start(protocol, records, raw, method, target, headers, eof, limit, wire_module, policy)
                self.tags[stream] = tag
                return stream
            def request(self, sock, protocol, records, raw, trace, path, deadline, wire_module, capture, limit):
                self.requests.append(path)
                pieces = path.split('/')
                body = case.status(pieces[2]) if pieces[1] == 'status' else case.control(pieces[2], pieces[3])
                return {'body': json.dumps(body) if isinstance(body, dict) else body}
            def complete(self, sock, protocol, records, raw, trace, stream, deadline, wire_module, capture):
                outcome = case.finish(self.tags[stream])
                del records[stream]
                del raw['streams'][stream]
                return {'body': json.dumps(outcome['record']), 'headers': [(':status', str(outcome['status']))]}
        class CaseProtocol(ProtocolDouble):
            def send_data(self, stream, data, end_stream):
                super().send_data(stream, data, end_stream)
                case.send(context['ops'].tags[stream], len(data), end_stream)
        context['ops'] = CaseOps()
        connection['protocol'] = CaseProtocol()
        result = lifecycle_cases.reuse(runner_adapter.reuse_api(context, connection))
        self.assertEqual((result['requests'], result['stale_resume'], result['stale_cancel']), (9, 36, 36))
        self.assertEqual(context['buffered_requests'], 378)
        self.assertEqual(connection['trace']['ledger'].sent, 288)

    def test_nine_stream_offsets_and_bounded_credit_slots(self):
        context, connection, _ = setup()
        for i in range(9):
            tag = 'reuse_' + str(i)
            stream = runner_adapter.start(context, connection, tag, metadata(tag), 'healthy')
            runner_adapter.send(context, connection, stream, 7, False)
            runner_adapter.send(context, connection, stream, 25, True)
            result = runner_adapter.finish(context, connection, stream)
            self.assertEqual(result, {'status': 200, 'record': {'tag': 'actual'}})
            self.assertEqual(connection['trace']['ledger'].streams, {})
        sent = connection['protocol'].sent
        for i in range(9):
            self.assertEqual(sent[i * 2][1:], (context['payload'][:7], False))
            self.assertEqual(sent[i * 2 + 1][1:], (context['payload'][7:], True))
        self.assertEqual(connection['trace']['ledger'].sent, 288)
        flow_ledger.receive_batch(connection['trace']['ledger'], [(1, 7), (0, 7)])
        self.assertEqual(connection['trace']['ledger'].retired[1].refunded, 7)
        self.assertEqual(connection['trace']['ledger'].refunded, 7)

    def test_metadata_request_accounting_and_metrics_seal(self):
        context, connection, ops = setup()
        invalid = dict(metadata('reuse_0'), target='/wrong')
        with self.assertRaises(ValueError):
            runner_adapter.start(context, connection, 'reuse_0', invalid, 'healthy')
        runner_adapter.status(context, connection, 'reuse_0')
        runner_adapter.control(context, connection, 'resume', 'reuse_0')
        runner_adapter.metrics(context, connection)
        self.assertEqual(context['buffered_requests'], 3)
        self.assertEqual(ops.requests, ['/status/reuse_0', '/control/resume/reuse_0', '/metrics'])
        with self.assertRaises(ValueError):
            runner_adapter.status(context, connection, 'reuse_0')
        with self.assertRaises(ValueError):
            runner_adapter.start(context, connection, 'reuse_0', metadata('reuse_0'), 'healthy')

    def test_disconnect_uses_same_raw_parser_and_strict_helper(self):
        context, connection, _ = setup()
        class Plain:
            def settimeout(self, value):
                pass
            def recv(self, bound):
                return b''
            def close(self):
                pass
        class Tls:
            def settimeout(self, value):
                pass
            def unwrap(self):
                return Plain()
        connection['socket'] = Tls()
        stream = runner_adapter.start(context, connection, 'disconnect', metadata('disconnect'), 'clean_disconnect')
        runner_adapter.send(context, connection, stream, 32, False)
        raw = connection['raw']
        proof = runner_adapter.clean_close(context, connection)
        self.assertTrue(proof['tcp_eof'])
        self.assertIs(connection['raw'], raw)
        self.assertTrue(raw['closed'])
        self.assertTrue(connection['closed'])

    def test_shutdown_open_signal_and_closing_credit_once(self):
        context, connection, _ = setup()
        stream = runner_adapter.start(context, connection, 'shutdown_active', metadata('shutdown_active'), 'owned_shutdown')
        runner_adapter.send(context, connection, stream, 32, False)
        context['sealed'] = True
        context['prior_complete'] = True
        context['signal'] = lambda conn, deadline: {'signal': 'SIGTERM', 'owned_identity': conn is connection,
                                                     'watcher_installed': True, 'client_open': not conn['closed']}
        context['graceful_deadline'] = lambda: 9
        context['wait'] = lambda deadline: None
        context['post'] = lambda deadline: None
        class StrictDouble:
            def observe_shutdown(self, sock, protocol, records, raw, trace, target, signal, deadline, clock):
                if raw is not connection['raw'] or target != stream or deadline != 9 or not signal['client_open']:
                    raise AssertionError('wrong shutdown ownership')
                protocol.outbound_flow_control_window += 7
                return ({'phase': 'post_signal', 'outcome': 'eof', 'primary_response': False,
                         'frames_valid': True, 'trailing_bytes': 0},
                        {'connection_credit': 7, 'stream_credit': 7, 'frames': 2})
        context['strict_close'] = StrictDouble()
        api = runner_adapter.shutdown_api(context)
        self.assertTrue(api['signal'](connection, 9)['client_open'])
        self.assertEqual(api['termination'](connection, 9)['outcome'], 'eof')
        self.assertEqual(connection['trace']['ledger'].refunded, 7)
        self.assertEqual(connection['trace']['ledger'].streams[stream].refunded, 7)
        self.assertEqual(connection['closing_observation']['frames'], 2)

    def test_selection_and_failure_cleanup(self):
        for selection in (['disconnect'], ['reuse', 'shutdown_active'], list(run_live.CASES)):
            run_live.validate_selection(selection)
        for selection in ([], ['shutdown_active', 'reuse'], ['reuse', 'reuse'], ['sink_error']):
            with self.assertRaises(RuntimeError):
                run_live.validate_selection(selection)
        events = []
        def fail():
            events.append('failed')
            raise ValueError('synthetic cleanup failure')
        errors = run_live.cleanup_actions((('first', fail), ('second', lambda: events.append('continued'))))
        self.assertEqual(events, ['failed', 'continued'])
        self.assertEqual(errors[0]['action'], 'first')

    def test_owned_identity_deadline_and_all_client_cleanup(self):
        class Child:
            pid = 17
            def poll(self):
                return None
        with patch.object(run_live, 'child_start', return_value='start'), patch.object(run_live, 'owned_listener', return_value=['inode']):
            run_live.require_owned_child(Child(), 'start', 'inode')
            with self.assertRaises(RuntimeError):
                run_live.require_owned_child(Child(), 'wrong', 'inode')
            with self.assertRaises(RuntimeError):
                run_live.require_owned_child(Child(), 'start', 'wrong')
        with patch.object(run_live.time, 'monotonic', return_value=10):
            with self.assertRaises(RuntimeError):
                run_live.remaining(10)
        class Client:
            def __init__(self, error=False):
                self.error = error
                self.closed = False
            def close(self):
                self.closed = True
                if self.error:
                    raise ValueError('close failed')
        first, second = Client(True), Client()
        connections = [{'socket': first, 'closed': False}, {'socket': second, 'closed': False}]
        with self.assertRaises(RuntimeError):
            run_live.close_connections(connections)
        self.assertTrue(first.closed and second.closed)
        self.assertIsNone(connections[1]['socket'])
        last = Client()
        connection = {'socket': last, 'closed': False}
        run_live.close_connections([connection])
        self.assertTrue(connection['closed'] and last.closed)

    def test_actual_shutdown_helper_uses_existing_parser(self):
        context, connection, _ = setup()
        class Tls:
            def settimeout(self, value):
                pass
            def recv(self, bound):
                return b''
        connection['socket'] = Tls()
        stream = runner_adapter.start(context, connection, 'shutdown_active', metadata('shutdown_active'), 'owned_shutdown')
        runner_adapter.send(context, connection, stream, 32, False)
        context.update(sealed=True, prior_complete=True, signal=lambda conn, deadline: {
            'signal': 'SIGTERM', 'owned_identity': True, 'watcher_installed': True, 'client_open': not conn['closed']},
            graceful_deadline=lambda: 9, wait=lambda deadline: None, post=lambda deadline: None)
        raw = connection['raw']
        api = runner_adapter.shutdown_api(context)
        api['signal'](connection, 9)
        evidence = api['termination'](connection, 9)
        self.assertEqual(evidence['outcome'], 'eof')
        self.assertIs(connection['raw'], raw)
        self.assertTrue(raw['closed'])


if __name__ == '__main__':
    unittest.main()
