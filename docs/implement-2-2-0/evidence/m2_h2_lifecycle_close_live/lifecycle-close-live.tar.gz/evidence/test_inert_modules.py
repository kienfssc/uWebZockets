"""Import actual current modules without performing external effects."""
import importlib.util
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

NAMES = ('run_live.py', 'runner_adapter.py', 'lifecycle_cases.py', 'expectations.py', 'wire.py',
         'raw_observer.py', 'flow_ledger.py', 'strict_close.py', 'validate_builds.py',
         'compile_fixture.py', 'freeze_runtime.py', 'check_closure.py')


class InertTests(unittest.TestCase):
    def test_actual_module_imports_are_inert(self):
        root = Path(__file__).resolve().parent
        for index, name in enumerate(NAMES):
            path = root / name
            spec = importlib.util.spec_from_file_location('inert_checked_' + str(index), path)
            if spec is None or spec.loader is None:
                raise ValueError('module loader unavailable')
            module = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = module
            try:
                with self.subTest(name=name), \
                     patch('socket.socket', side_effect=AssertionError('socket')), \
                     patch('socket.create_connection', side_effect=AssertionError('connection')), \
                     patch('ssl.SSLContext', side_effect=AssertionError('TLS context')), \
                     patch('subprocess.Popen', side_effect=AssertionError('process')), \
                     patch('subprocess.run', side_effect=AssertionError('process')), \
                     patch('os.kill', side_effect=AssertionError('signal')), \
                     patch.object(Path, 'write_bytes', side_effect=AssertionError('write')), \
                     patch.object(Path, 'write_text', side_effect=AssertionError('write')):
                    spec.loader.exec_module(module)
            finally:
                del sys.modules[spec.name]


if __name__ == '__main__':
    unittest.main()
