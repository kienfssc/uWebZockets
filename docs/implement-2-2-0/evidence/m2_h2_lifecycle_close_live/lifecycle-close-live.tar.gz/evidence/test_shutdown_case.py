import copy
import unittest

import expectations
import lifecycle_cases


class ShutdownDouble:
    def __init__(self, selection, defect=None):
        self.selection = selection
        self.defect = defect
        self.connection = object()
        self.deadline = object()
        self.rows = expectations.records(selection, 'before')
        for row in self.rows.values():
            row.update(chunks=int(row['accepted'] > 0), max_span=row['accepted'])
        self.events = []
        self.count = 0
        self.sealed = False

    def preconditions(self, connection):
        self.events.append('preconditions')
        return {'prior_complete': self.defect != 'prior', 'client_open': self.defect != 'close_first'}

    def start(self, connection, tag, metadata, policy):
        self.events.append('start')
        if connection is not self.connection or tag != 'shutdown_active' or policy != 'owned_shutdown':
            raise AssertionError('start differs')
        if metadata != {'method': 'POST', 'path': '/limit/shutdown_active', 'query': 'case=shutdown_active',
                        'target': '/limit/shutdown_active?case=shutdown_active', 'x-case': 'shutdown_active',
                        'content-length': '32'}:
            raise AssertionError('metadata differs')
        return tag

    def send(self, connection, stream, length, end_stream):
        self.events.append('send')
        if connection is not self.connection or stream != 'shutdown_active' or (length, end_stream) != (32, False):
            raise AssertionError('send differs')

    def status(self, connection, tag):
        if self.sealed:
            raise AssertionError('request after metrics')
        self.events.append(('status', tag))
        self.count += 1
        row = copy.deepcopy(self.rows[tag])
        if tag == 'shutdown_active' and self.defect == 'barrier':
            row['paused'] = False
        if tag == 'shutdown_active' and self.defect == 'boolean_type':
            row['active'] = 1
        if tag == 'spare_00' and self.defect == 'spare':
            row['middleware'] = 1
        return row

    def metrics(self, connection):
        if self.sealed:
            raise AssertionError('duplicate metrics')
        self.events.append('metrics')
        self.count += 1
        self.sealed = True
        metrics = lifecycle_cases.expected_metrics(self.selection, 'before', self.count)
        metrics.update(slot0_active=True, slot1_active=False)
        if self.defect == 'metric':
            metrics['accepted'] -= 1
        return metrics

    def request_count(self):
        self.events.append('request_count')
        return self.count

    def graceful_deadline(self):
        self.events.append('deadline')
        return self.deadline

    def signal(self, connection, deadline):
        self.events.append('signal')
        if connection is not self.connection or deadline is not self.deadline or not self.sealed:
            raise AssertionError('signal ordering differs')
        return {'signal': 'SIGTERM', 'owned_identity': self.defect != 'owner', 'watcher_installed': self.defect != 'watcher',
                'client_open': self.defect != 'close_signal'}

    def termination(self, connection, deadline):
        self.events.append('termination')
        if connection is not self.connection or deadline is not self.deadline or self.events[-2] != 'signal':
            raise AssertionError('termination ordering differs')
        return {'phase': 'post_signal', 'outcome': 'timeout' if self.defect == 'timeout' else 'tls_eof',
                'primary_response': self.defect == 'response', 'frames_valid': True, 'trailing_bytes': 0}

    def wait(self, deadline):
        self.events.append('wait')
        if deadline is not self.deadline:
            raise AssertionError('deadline differs')
        return {'exit_code': 1 if self.defect == 'exit' else 0,
                'reaped': self.defect != 'reap', 'forced': self.defect == 'force',
                'run_ok': self.defect != 'run', 'deinit_ok': self.defect != 'deinit',
                'key_removed': self.defect != 'key'}

    def post(self, deadline):
        self.events.append('post')
        if deadline is not self.deadline:
            raise AssertionError('deadline differs')
        rows = expectations.records(self.selection, 'after')
        for row in rows.values():
            row.update(chunks=int(row['accepted'] > 0), max_span=row['accepted'])
        if self.defect == 'cause':
            rows['shutdown_active']['reason'] = 'peer_closed'
        if self.defect == 'posthash':
            rows['shutdown_active']['sha256'] = expectations.H32
        if self.defect == 'identity':
            rows['shutdown_active']['tag'] = 'wrong'
        if self.defect == 'missing_cancel':
            rows['shutdown_active']['cancel'] = 0
        if self.defect == 'duplicate_cancel':
            rows['shutdown_active']['cancel'] = 2
        if self.defect == 'other':
            rows['spare_01']['accepted'] = 1
        if self.defect == 'other_semantic':
            rows['reuse_0']['stale_cancel'] -= 1
        if self.defect == 'diagnostics':
            rows['shutdown_active']['chunks'] += 1
        metrics = lifecycle_cases.expected_metrics(self.selection, 'after', self.count)
        metrics.update(slot0_active=False, slot1_active=False)
        return {'records': rows, 'metrics': metrics}

    def api(self):
        return {name: getattr(self, name) for name in ('preconditions', 'start', 'send', 'status', 'metrics',
                'request_count', 'graceful_deadline', 'signal', 'termination', 'wait', 'post')}


class ShutdownTests(unittest.TestCase):
    def test_full_and_subset(self):
        for selection, before, after in ((('disconnect', 'reuse', 'shutdown_active'), (12, 12, 10, 1, 334, 1), (12, 12, 10, 2, 334, 0)),
                                         (('shutdown_active',), (1, 1, 0, 0, 7, 1), (1, 1, 0, 1, 7, 0)),
                                         (('disconnect', 'shutdown_active'), (3, 3, 1, 1, 46, 1), (3, 3, 1, 2, 46, 0)),
                                         (('reuse', 'shutdown_active'), (10, 10, 9, 0, 295, 1), (10, 10, 9, 1, 295, 0))):
            with self.subTest(selection=selection):
                double = ShutdownDouble(selection)
                result = lifecycle_cases.shutdown_active(double.api(), double.connection, selection)
                self.assertEqual(expectations.totals(result['before']['records']), before)
                self.assertEqual(expectations.totals(result['after']['records']), after)
                for metrics, values in ((result['before']['metrics'], before), (result['after']['metrics'], after)):
                    self.assertEqual(tuple(metrics[key] for key in ('attempts', 'begin', 'end', 'cancel', 'accepted', 'active')), values)
                    self.assertEqual(metrics['buffered_middleware'], 34)
                self.assertEqual(double.events[-7:], ['metrics', 'request_count', 'deadline', 'signal', 'termination', 'wait', 'post'])
                self.assertEqual(double.events.count('metrics'), 1)
                self.assertEqual(sum(isinstance(event, tuple) and event[0] == 'status' for event in double.events), 33)

    def test_rejects_bad_observations(self):
        for defect in ('prior', 'close_first', 'barrier', 'boolean_type', 'spare', 'metric', 'close_signal', 'owner', 'watcher', 'timeout', 'response',
                       'exit', 'reap', 'force', 'run', 'deinit', 'key', 'cause', 'posthash', 'identity',
                       'missing_cancel', 'duplicate_cancel', 'other', 'other_semantic', 'diagnostics'):
            with self.subTest(defect=defect):
                double = ShutdownDouble(('disconnect', 'reuse', 'shutdown_active'), defect)
                with self.assertRaises(ValueError):
                    lifecycle_cases.shutdown_active(double.api(), double.connection, double.selection)

    def test_rejects_unordered_selection(self):
        double = ShutdownDouble(('shutdown_active',))
        for selection in ((), ('shutdown_active', 'reuse'), ('reuse',), ('shutdown_active', 'shutdown_active')):
            with self.subTest(selection=selection):
                with self.assertRaises(ValueError):
                    lifecycle_cases.shutdown_active(double.api(), double.connection, selection)


if __name__ == '__main__':
    unittest.main()
