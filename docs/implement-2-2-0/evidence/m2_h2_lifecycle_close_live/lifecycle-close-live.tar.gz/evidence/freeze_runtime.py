"""Freeze actual runtime and bind it to the two actual native build receipts."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspaces/uWebZockets')
BASE = HERE.parent / 'application-error/manifest-v3.json'
BASE_HASH = 'd2bb368da8f912f3b37ed97376d8d73a11259570b44aae893981609e3ac5a62f'
FROZEN = Path('/tmp/uwz-task5c3-runtime-v1')
FIXTURE = Path('/tmp/uwz-task5c3-fixture-v1')
MANIFEST = HERE / 'manifest-v1.json'
RUNTIME = ('run_live.py', 'runner_adapter.py', 'lifecycle_cases.py', 'expectations.py', 'wire.py',
           'raw_observer.py', 'flow_ledger.py', 'strict_close.py', 'validate_builds.py')
TOOLS = ('compile_fixture.py', 'freeze_runtime.py', 'check_closure.py', 'test_inert_modules.py',
         'test_runner_adapter.py', 'test_lifecycle_cases.py', 'test_disconnect_case.py',
         'test_shutdown_case.py', 'test_expectations.py', 'test_close_paths.py',
         'test_observer.py', 'test_credit_case.py', 'test_listener.py', 'cases.py', 'profile.zig',
         'profile-debug-v1.bin', 'profile-release-v1.bin')
HELPER = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'
HELPER_HASH = '07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00'


def digest(path):
    value = hashlib.sha256()
    with open(path, 'rb') as source:
        while block := source.read(1048576):
            value.update(block)
    return value.hexdigest()


def inventory(path):
    return {str(item.relative_to(path)): digest(item) for item in sorted(path.rglob('*')) if item.is_file()}


def main():
    if FROZEN.exists() or MANIFEST.exists():
        raise ValueError('runtime snapshot or manifest exists')
    if digest(BASE) != BASE_HASH:
        raise ValueError('reviewed base manifest differs')
    base = json.loads(BASE.read_text())
    trees = {}
    for root, original in base['trees'].items():
        if root.startswith('/tmp/uwz-task5c2-'):
            continue
        current = inventory(Path(root))
        if current != original:
            raise ValueError('reviewed tree differs: ' + root)
        trees[root] = current
    fixture = inventory(FIXTURE)
    if fixture != {'profile.zig': '3336d93a5684d88c6a4373d305838ff646b89173abcfb4999a0fd7b1eb951920'}:
        raise ValueError('fixture snapshot differs')
    trees[str(FIXTURE)] = fixture
    source_before = {name: digest(HERE / name) for name in RUNTIME}
    FROZEN.mkdir(mode=0o700)
    for name in RUNTIME:
        shutil.copyfile(HERE / name, FROZEN / name)
        (FROZEN / name).chmod(0o444)
    FROZEN.chmod(0o555)
    trees[str(FROZEN)] = inventory(FROZEN)
    if source_before != trees[str(FROZEN)] or source_before != {name: digest(HERE / name) for name in RUNTIME}:
        raise ValueError('runtime source changed while freezing')
    retained = ('/home/codespace/.python/current/', '/lib/', '/lib64/', '/opt/conda/')
    inputs = {path: value for path, value in base['inputs'].items() if path.startswith(retained)}
    inputs[HELPER] = HELPER_HASH
    receipts = [str(HERE / ('fixture-' + mode + '-v1.json')) for mode in ('debug', 'release')]
    for receipt_path in receipts:
        receipt = json.loads(Path(receipt_path).read_text())
        for path, value in receipt['input_before'].items():
            if path in inputs and inputs[path] != value:
                raise ValueError('conflicting actual build input: ' + path)
            inputs[path] = value
        inputs[receipt_path] = digest(receipt_path)
        for name in (receipt['stdout'], receipt['stderr']):
            path = str(HERE / name)
            inputs[path] = digest(path)
        output = next(item.split('=', 1)[1] for item in receipt['argv'] if item.startswith('-femit-bin='))
        inputs[output] = receipt['binary_sha256']
    for name in RUNTIME:
        inputs[str(FROZEN / name)] = digest(FROZEN / name)
        inputs[str(HERE / name)] = digest(HERE / name)
    for name in TOOLS:
        inputs[str(HERE / name)] = digest(HERE / name)
    for path, expected in inputs.items():
        if digest(path) != expected:
            raise ValueError('input differs: ' + path)
    if digest(HERE / 'profile-debug-v1.bin') != '99750d37a7445550014ff4303818fc4ea66ac72a1aea46b2be165f411e0cc7e3' or digest(HERE / 'profile-release-v1.bin') != '768598a27e0a22445b9dac740c4c3ce4309351f2124e90590a851b1fa1f80495':
        raise ValueError('retained build binary differs')
    spec = importlib.util.spec_from_file_location('frozen_validator', FROZEN / 'validate_builds.py')
    if spec is None or spec.loader is None:
        raise ValueError('validator loader unavailable')
    validator = importlib.util.module_from_spec(spec)
    sys.modules['frozen_validator'] = validator
    spec.loader.exec_module(validator)
    manifest = {'state': 'ready-for-independent-review', 'scope': 'actual fixture builds and current runtime; no live execution',
                'trees': trees, 'tree_counts': {path: len(files) for path, files in trees.items()},
                'inputs': inputs, 'build_input_receipts': receipts, 'approved_archives': base['approved_archives'],
                'binary': '/tmp/uwz-task5c3-fixture-release-v1/profile', 'helper': HELPER,
                'environment': {'LC_ALL': 'C.UTF-8', 'PYTHONPATH': '/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'},
                'python': '/home/codespace/.python/current/bin/python3', 'python_flags': ['-B', '-S']}
    for key, name in (('runner', 'run_live.py'), ('adapter', 'runner_adapter.py'), ('lifecycle', 'lifecycle_cases.py'),
                      ('expectations', 'expectations.py'), ('wire', 'wire.py'), ('raw', 'raw_observer.py'),
                      ('flow', 'flow_ledger.py'), ('strict', 'strict_close.py'), ('validator', 'validate_builds.py')):
        manifest[key] = str(FROZEN / name)
    validator.validate(manifest, inputs)
    MANIFEST.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    print('frozen runtime files:', len(trees[str(FROZEN)]))
    print('tree counts:', manifest['tree_counts'])
    print('direct inputs:', len(inputs))
    print('manifest sha256:', digest(MANIFEST))


if __name__ == '__main__':
    main()
