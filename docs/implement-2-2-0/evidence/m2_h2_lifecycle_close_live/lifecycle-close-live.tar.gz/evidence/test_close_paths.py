import ssl
import unittest
from pathlib import Path
from unittest.mock import patch

from hyperframe.frame import DataFrame, GoAwayFrame, HeadersFrame, RstStreamFrame, WindowUpdateFrame
import raw_observer
import wire
import strict_close


class Protocol:
    def receive_data(self, data):
        return []


def window(stream=0, increment=7):
    item = WindowUpdateFrame(stream)
    item.window_increment = increment
    return item.serialize()


class ClosePaths(unittest.TestCase):
    def state(self, policy):
        records, raw = {}, raw_observer.new_state()
        wire.register(records, raw, 1, 0, 200, 0, policy)
        return records, raw

    def test_actual_fragmented_shutdown_credit_and_eof(self):
        records, raw = self.state('owned_shutdown')
        wire.begin_termination(records, raw, 1, 'owned_shutdown', 'post_signal')
        encoded = window() + window(1, 3)
        for part in (encoded[:3], encoded[3:11], encoded[11:]):
            wire.accept(Protocol(), part, records, raw, {})
        result = wire.finish_termination(records, raw, 1, 'owned_shutdown', 'post_signal', 'tls_eof')
        self.assertEqual(result['outcome'], 'tls_eof')
        self.assertEqual(result['frames'], 2)
        self.assertEqual((result['connection_credit'], result['stream_credit']), (7, 3))
        self.assertFalse(records)

    def test_rejects_wrong_phase_other_stream_and_partial(self):
        records, raw = self.state('owned_shutdown')
        with self.assertRaises(ValueError):
            wire.begin_termination(records, raw, 1, 'owned_shutdown', 'before_signal')
        with self.assertRaises(ValueError):
            wire.retire(records, raw, 1)
        wire.register(records, raw, 3, 0, 200, 0, 'healthy')
        with self.assertRaises(ValueError):
            wire.begin_termination(records, raw, 1, 'owned_shutdown', 'post_signal')
        records, raw = self.state('owned_shutdown')
        wire.begin_termination(records, raw, 1, 'owned_shutdown', 'post_signal')
        wire.accept(Protocol(), window()[:10], records, raw, {})
        with self.assertRaises(ValueError):
            wire.finish_termination(records, raw, 1, 'owned_shutdown', 'post_signal', 'eof')

    def test_rejects_target_payload_reset_goaway_and_invalid_credit(self):
        for item in (DataFrame(1), HeadersFrame(1), RstStreamFrame(1), GoAwayFrame(0), WindowUpdateFrame(3)):
            if isinstance(item, WindowUpdateFrame):
                item.window_increment = 1
            raw_bytes = item.serialize()
            with self.subTest(kind=type(item).__name__):
                records, raw = self.state('owned_shutdown')
                wire.begin_termination(records, raw, 1, 'owned_shutdown', 'post_signal')
                with self.assertRaises(ValueError):
                    wire.accept(Protocol(), raw_bytes, records, raw, {})
        for payload in (bytes(4), b'\x80\x00\x00\x01'):
            records, raw = self.state('owned_shutdown')
            wire.begin_termination(records, raw, 1, 'owned_shutdown', 'post_signal')
            with self.assertRaises(ValueError):
                wire.accept(Protocol(), b'\x00\x00\x04\x08\x00\x00\x00\x00\x00' + payload, records, raw, {})

    def test_clean_disconnect_requires_evidence_and_full_frame(self):
        records, raw = self.state('clean_disconnect')
        with self.assertRaises(ValueError):
            wire.retire(records, raw, 1)
        wire.begin_termination(records, raw, 1, 'clean_disconnect', 'pre_unwrap')
        with self.assertRaises(ValueError):
            wire.finish_termination(records, raw, 1, 'clean_disconnect', 'pre_unwrap', 'eof')
        proof = {'method': 'ssl_unwrap', 'tls_shutdown': 'success', 'tcp_eof': True,
                 'trailing_bytes': 0, 'close': 'normal'}
        result = wire.finish_termination(records, raw, 1, 'clean_disconnect', 'pre_unwrap', proof)
        self.assertEqual(result['kind'], 'local_transport_only')

    def test_pretermination_frames_and_closing_bounds(self):
        for policy in ('clean_disconnect', 'owned_shutdown'):
            for item in (DataFrame(1), HeadersFrame(1), RstStreamFrame(1)):
                records, raw = self.state(policy)
                with self.subTest(policy=policy, kind=type(item).__name__):
                    with self.assertRaises(ValueError):
                        wire.accept(Protocol(), item.serialize(), records, raw, {})
        records, raw = self.state('owned_shutdown')
        wire.accept(Protocol(), window()[:2], records, raw, {})
        with self.assertRaises(ValueError):
            wire.begin_termination(records, raw, 1, 'owned_shutdown', 'post_signal')
        records, raw = self.state('owned_shutdown')
        wire.begin_termination(records, raw, 1, 'owned_shutdown', 'post_signal')
        with self.assertRaises(ValueError):
            wire.accept(Protocol(), bytes(8193), records, raw, {})
        records, raw = self.state('owned_shutdown')
        wire.begin_termination(records, raw, 1, 'owned_shutdown', 'post_signal')
        for _ in range(8):
            wire.accept(Protocol(), window() * 512, records, raw, {})
        with self.assertRaises(ValueError):
            wire.accept(Protocol(), window(), records, raw, {})

    def test_wrong_target_outcome_and_after_close(self):
        records, raw = self.state('owned_shutdown')
        with self.assertRaises(ValueError):
            wire.begin_termination(records, raw, 3, 'owned_shutdown', 'post_signal')
        wire.begin_termination(records, raw, 1, 'owned_shutdown', 'post_signal')
        for outcome in ('timeout', 'reset', 'before_signal'):
            with self.assertRaises(ValueError):
                wire.finish_termination(records, raw, 1, 'owned_shutdown', 'post_signal', outcome)
        wire.finish_termination(records, raw, 1, 'owned_shutdown', 'post_signal', 'eof')
        with self.assertRaises(ValueError):
            wire.accept(Protocol(), window(), records, raw, {})


class PlainDouble:
    def __init__(self, outcome=b''):
        self.outcome = outcome
        self.closed = False
        self.timeouts = []

    def settimeout(self, value):
        self.timeouts.append(value)

    def recv(self, bound):
        if isinstance(self.outcome, BaseException):
            raise self.outcome
        return self.outcome

    def close(self):
        self.closed = True


class TlsDouble:
    def __init__(self, plain, error=None):
        self.plain, self.error, self.timeouts = plain, error, []

    def settimeout(self, value):
        self.timeouts.append(value)

    def unwrap(self):
        if self.error is not None:
            raise self.error
        return self.plain


class StrictCloseTests(unittest.TestCase):
    def test_observer_module_imports_are_inert(self):
        root = Path(__file__).resolve().parent
        for name in ('raw_observer.py', 'wire.py', 'strict_close.py', 'runner_adapter.py', 'run_live.py'):
            path = root / name
            code = compile(path.read_bytes(), str(path), 'exec')
            with self.subTest(name=name):
                with patch('socket.socket', side_effect=AssertionError('socket')), \
                     patch('subprocess.Popen', side_effect=AssertionError('process')), \
                     patch.object(Path, 'write_bytes', side_effect=AssertionError('write')):
                    exec(code, {'__name__': 'inert_import', '__file__': str(path)})

    def test_unwrap_and_normal_eof(self):
        plain = PlainDouble()
        tls = TlsDouble(plain)
        proof = strict_close.unwrap_eof(tls, 10, lambda: 1)
        self.assertEqual(proof['tcp_eof'], True)
        self.assertTrue(plain.closed)
        self.assertEqual((tls.timeouts, plain.timeouts), ([9], [9]))

    def test_failures_preserve_error_and_ownership(self):
        for error in (TimeoutError('deadline'), ConnectionResetError('reset'), ValueError('unwrap')):
            plain = PlainDouble()
            tls = TlsDouble(plain, error)
            with self.assertRaises(type(error)) as raised:
                strict_close.unwrap_eof(tls, 10, lambda: 1)
            self.assertIs(raised.exception, error)
            self.assertFalse(plain.closed)
        for outcome in (b'extra', None, TimeoutError('read'), ConnectionResetError('read')):
            plain = PlainDouble(outcome)
            with self.assertRaises((ValueError, TimeoutError, ConnectionResetError)):
                strict_close.unwrap_eof(TlsDouble(plain), 10, lambda: 1)
            self.assertTrue(plain.closed)

    def test_deadline_and_cleanup_error_preserve_primary(self):
        plain = PlainDouble()
        tls = TlsDouble(plain)
        with self.assertRaises(TimeoutError):
            strict_close.unwrap_eof(tls, 10, lambda: 10)
        self.assertFalse(plain.closed)
        error = TimeoutError('primary read failure')
        class BadCleanup(PlainDouble):
            def close(self):
                raise ValueError('cleanup failure')
        with self.assertRaises(TimeoutError) as raised:
            strict_close.unwrap_eof(TlsDouble(BadCleanup(error)), 10, lambda: 1)
        self.assertIs(raised.exception, error)
        self.assertIn('cleanup failure', raised.exception.__notes__[0])

    def test_actual_shutdown_observer_fragmented_then_tls_eof(self):
        records, raw = ClosePaths().state('owned_shutdown')
        class ReadDouble:
            def __init__(self):
                self.parts = [window()[:5], window()[5:], ssl.SSLEOFError('no alert')]
                self.timeouts = []
            def settimeout(self, value):
                self.timeouts.append(value)
            def recv(self, bound):
                part = self.parts.pop(0)
                if isinstance(part, BaseException):
                    raise part
                return part
        reader = ReadDouble()
        signal = {'signal': 'SIGTERM', 'owned_identity': True, 'watcher_installed': True, 'client_open': True}
        evidence, observation = strict_close.observe_shutdown(reader, Protocol(), records, raw, {}, 1, signal, 10, lambda: 1)
        self.assertEqual(evidence['outcome'], 'tls_eof')
        self.assertEqual(observation['frames'], 1)
        self.assertEqual(reader.timeouts, [9, 9, 9])

    def test_shutdown_observer_rejects_early_and_failed_termination(self):
        signal = {'signal': 'SIGTERM', 'owned_identity': True, 'watcher_installed': True, 'client_open': True}
        class ReadDouble:
            def __init__(self, parts):
                self.parts = list(parts)
            def settimeout(self, value):
                pass
            def recv(self, bound):
                part = self.parts.pop(0)
                if isinstance(part, BaseException):
                    raise part
                return part
        for parts, error in (([TimeoutError('timeout')], TimeoutError),
                             ([ConnectionResetError('reset')], ConnectionResetError),
                             ([None], ValueError),
                             ([window()[:3], b''], ValueError),
                             ([DataFrame(1).serialize()], ValueError)):
            records, raw = ClosePaths().state('owned_shutdown')
            with self.subTest(parts=parts):
                with self.assertRaises(error):
                    strict_close.observe_shutdown(ReadDouble(parts), Protocol(), records, raw, {}, 1, signal, 10, lambda: 1)
        records, raw = ClosePaths().state('owned_shutdown')
        bad_signal = dict(signal, client_open=False)
        reader = ReadDouble([b''])
        with self.assertRaises(ValueError):
            strict_close.observe_shutdown(reader, Protocol(), records, raw, {}, 1, bad_signal, 10, lambda: 1)
        self.assertEqual(reader.parts, [b''])
        records, raw = ClosePaths().state('owned_shutdown')
        evidence, _ = strict_close.observe_shutdown(ReadDouble([b'']), Protocol(), records, raw, {}, 1, signal, 10, lambda: 1)
        self.assertEqual(evidence['outcome'], 'eof')


if __name__ == '__main__':
    unittest.main()
