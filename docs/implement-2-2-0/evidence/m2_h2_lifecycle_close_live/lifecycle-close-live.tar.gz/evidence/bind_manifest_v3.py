"""Bind the actual prior preparation manifests and final guarded tools."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
RUNNER = Path('/tmp/uwz-task5c3-runtime-v1/run_live.py')
V1_HASH = 'd8e754635a3cdf0d030d4997e5873e1174d209946a36b418fcd2ef664dc0e070'
V2_HASH = '1ab3d608d353410afd3eb871ff83ec607bd212d58ebf03d816be3f79f0b69a43'


def digest(path):
    value = hashlib.sha256()
    with open(path, 'rb') as source:
        while block := source.read(1048576):
            value.update(block)
    return value.hexdigest()


def main():
    output = HERE / 'manifest-v3.json'
    if output.exists():
        raise ValueError('current manifest already exists')
    spec = importlib.util.spec_from_file_location('binding_runner_v3', RUNNER)
    if spec is None or spec.loader is None:
        raise ValueError('runner loader unavailable')
    module = importlib.util.module_from_spec(spec)
    sys.modules['binding_runner_v3'] = module
    spec.loader.exec_module(module)
    manifest = module.check_manifest(HERE / 'manifest-v2.json', V2_HASH)
    prior = HERE / 'manifest-v1.json'
    if digest(prior) != V1_HASH:
        raise ValueError('first manifest differs')
    manifest['inputs'][str(prior)] = V1_HASH
    manifest['inputs'][str(HERE / 'manifest-v2.json')] = V2_HASH
    for name in ('bind_manifest_v3.py', 'check_closure_v3.py', 'test_bind_v3_import.py'):
        path = HERE / name
        manifest['inputs'][str(path)] = digest(path)
    output.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    result = digest(output)
    module.check_manifest(output, result)
    print('v2 closure accepted; current closure accepted')
    print('direct inputs:', len(manifest['inputs']))
    print('manifest sha256:', result)


if __name__ == '__main__':
    main()
