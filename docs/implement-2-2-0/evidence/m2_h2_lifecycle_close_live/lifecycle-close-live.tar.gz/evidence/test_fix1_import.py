"""The final binder and checker perform no action on import."""
from pathlib import Path
import unittest
from unittest.mock import patch


class BindingImportTests(unittest.TestCase):
    def test_guarded_tools_are_inert(self):
        root = Path(__file__).resolve().parent
        for name in ('freeze_runtime_fix1.py', 'check_closure_fix1.py'):
            path = root / name
            code = compile(path.read_bytes(), str(path), 'exec')
            with self.subTest(name=name), \
                 patch.object(Path, 'read_bytes', side_effect=AssertionError('read')), \
                 patch.object(Path, 'write_bytes', side_effect=AssertionError('write')), \
                 patch.object(Path, 'write_text', side_effect=AssertionError('write')), \
                 patch('os.kill', side_effect=AssertionError('signal')), \
                 patch('socket.socket', side_effect=AssertionError('socket')), \
                 patch('ssl.SSLContext', side_effect=AssertionError('TLS context')), \
                 patch('subprocess.Popen', side_effect=AssertionError('process')):
                exec(code, {'__name__': 'inert_binding', '__file__': str(path)})


if __name__ == '__main__':
    unittest.main()
