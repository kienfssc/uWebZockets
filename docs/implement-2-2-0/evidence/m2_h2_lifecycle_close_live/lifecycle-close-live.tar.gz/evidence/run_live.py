"""Explicitly gated ordinary owned H2 fixture runner; importing is inert."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import ssl
import subprocess
import sys
import threading
import time
import traceback

HERE = Path(__file__).resolve().parent
PORT = 28443
PYTHON = '/home/codespace/.python/current/bin/python3'
PACKAGES = '/tmp/uwz-h2-client-tooling/packages'
HELPER = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'
OPENSSL = '/opt/conda/bin/openssl'
CASES = ('disconnect', 'reuse', 'shutdown_active')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    value = hashlib.sha256()
    with open(path, 'rb') as source:
        while block := source.read(8192):
            value.update(block)
    return value.hexdigest()


def check_manifest(path, expected):
    require(digest(path) == expected, 'review manifest identity differs')
    manifest = json.loads(path.read_text())
    for root, expected_files in manifest['trees'].items():
        actual = {str(p.relative_to(root)) for p in Path(root).rglob('*') if p.is_file()}
        require(actual == set(expected_files), 'tree inventory differs: ' + root)
        for name, value in expected_files.items():
            require(digest(Path(root) / name) == value, 'tree input identity differs: ' + name)
    for name, value in manifest['inputs'].items():
        require(digest(name) == value, 'input identity differs: ' + name)
    require(manifest['state'] == 'ready-for-independent-review', 'manifest not review ready')
    checked_path(__file__, manifest['runner'], manifest['inputs'])
    checked_path(manifest['wire'], manifest['wire'], manifest['inputs'])
    checked_path(manifest['raw'], manifest['raw'], manifest['inputs'])
    for key in ('lifecycle', 'expectations', 'adapter', 'strict', 'flow', 'helper'):
        checked_path(manifest[key], manifest[key], manifest['inputs'])
    validator = load_bound('validate_builds', manifest['validator'], manifest['inputs'])
    validator.validate(manifest, manifest['inputs'])
    return manifest


def checked_path(actual, expected, inputs):
    require(Path(actual).absolute() == Path(expected).absolute(), 'executing source path differs')
    require(Path(actual).resolve() == Path(expected).absolute(), 'source path resolves elsewhere')
    require(expected in inputs and digest(actual) == inputs[expected], 'executing source hash differs')


def load_bound(name, path, inputs):
    checked_path(path, path, inputs)
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, 'module loader unavailable')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    checked_path(module.__file__, path, inputs)
    return module



def failure_details(exc, stage):
    return {'type': type(exc).__name__, 'message': str(exc),
            'filename': getattr(exc, 'filename', None), 'stage': stage,
            'traceback': ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))[-16384:]}


def new_capture():
    return {'lock': threading.Lock(), 'bytes': bytearray(), 'overflow': False, 'error': None}


def capture_fragment(capture, data):
    with capture['lock']:
        room = 65536 - len(capture['bytes'])
        capture['bytes'].extend(data[:room])
        if len(data) > room:
            capture['overflow'] = True


def capture_snapshot(capture):
    with capture['lock']:
        return bytes(capture['bytes']), capture['overflow'], capture['error']


def check_capture(capture):
    _, overflow, error = capture_snapshot(capture)
    require(not overflow, 'server output exceeds 65536 bytes')
    require(error is None, 'server output collector failed: ' + str(error))


def drain_capture(pipe, capture):
    try:
        while data := os.read(pipe.fileno(), 8192):
            capture_fragment(capture, data)
    except BaseException as exc:
        with capture['lock']:
            capture['error'] = repr(exc)
    finally:
        try:
            pipe.close()
        except BaseException as exc:
            with capture['lock']:
                capture['error'] = repr(exc)


def cleanup_actions(actions):
    errors = []
    for name, action in actions:
        try:
            action()
        except BaseException as exc:
            errors.append({'action': name, 'error': repr(exc)})
    return errors


def remaining(deadline):
    seconds = deadline - time.monotonic()
    require(seconds > 0, 'absolute deadline expired')
    return seconds


def choose_graceful_deadline(overall, case_deadline, now):
    deadline = min(overall, now + 15)
    return min(deadline, case_deadline) if case_deadline is not None else deadline


def child_start(pid):
    # comm can contain spaces or parentheses; the final ')' ends that field.
    text = Path('/proc', str(pid), 'stat').read_text()
    return text[text.rfind(')') + 2:].split()[19]


def owned_listener(pid):
    inodes = set()
    for entry in Path('/proc', str(pid), 'fd').iterdir():
        try:
            target = os.readlink(entry)
        except FileNotFoundError:
            continue
        if target.startswith('socket:['):
            inodes.add(target[8:-1])
    rows = Path('/proc/net/tcp').read_text().splitlines()[1:]
    return [row.split()[9] for row in rows if row.split()[1] == '0100007F:6F1B'
            and row.split()[3] == '0A' and row.split()[9] in inodes]


def require_owned_child(child, start_id, listener):
    require(child.poll() is None and child_start(child.pid) == start_id, 'owned child changed')
    require(owned_listener(child.pid) == [listener], 'owned listener changed')


def close_connections(connections):
    failures = []
    for connection in connections:
        if connection['socket'] is None:
            continue
        try:
            connection['socket'].close()
        except BaseException as exc:
            failures.append(repr(exc))
        else:
            connection['socket'] = None
            connection['closed'] = True
    require(not failures, 'client cleanup failed: ' + repr(failures))


def wait_marker(child, capture, nonce, deadline):
    marker = ('H2_READY ' + nonce).encode()
    while True:
        check_capture(capture)
        require(child.poll() is None, 'child exited before readiness')
        data, _, _ = capture_snapshot(capture)
        if marker in data:
            listeners = owned_listener(child.pid)
            require(len(listeners) == 1, 'owned loopback listener not uniquely identified')
            return listeners[0]
        time.sleep(min(0.05, remaining(deadline)))


def flush(sock, protocol, deadline, capture):
    check_capture(capture)
    pending = protocol.data_to_send()
    if pending:
        sock.settimeout(remaining(deadline))
        sock.sendall(pending)


def encoded_headers_size(pending, stream):
    from hyperframe.frame import Frame, HeadersFrame, ContinuationFrame
    offset = 0
    total = 0
    ended = False
    while offset < len(pending):
        require(len(pending) - offset >= 9, 'truncated generated frame header')
        frame, length = Frame.parse_frame_header(memoryview(pending)[offset:offset + 9])
        offset += 9
        require(offset + length <= len(pending), 'truncated generated frame payload')
        frame.parse_body(memoryview(pending)[offset:offset + length])
        offset += length
        require(isinstance(frame, (HeadersFrame, ContinuationFrame)) and frame.stream_id == stream and not ended, 'unexpected generated header frame')
        total += len(frame.data)
        require(total <= 8192, 'encoded header block exceeds bound')
        ended = 'END_HEADERS' in frame.flags
    require(ended, 'missing generated END_HEADERS')
    return total


def flush_headers(sock, protocol, deadline, capture, stream):
    check_capture(capture)
    pending = protocol.data_to_send()
    total = encoded_headers_size(pending, stream)
    sock.settimeout(remaining(deadline))
    sock.sendall(pending)
    return total


def receive(sock, protocol, records, raw, trace, deadline, wire, capture):
    check_capture(capture)
    sock.settimeout(remaining(deadline))
    data = sock.recv(8192)
    require(data, 'TLS EOF before response completion')
    events = wire.accept(protocol, data, records, raw, trace['events'])
    import h2.events
    import h2.settings
    updates = [(event.stream_id, event.delta) for event in events if isinstance(event, h2.events.WindowUpdated)]
    initial = None
    for event in events:
        if isinstance(event, h2.events.RemoteSettingsChanged):
            changed = event.changed_settings.get(h2.settings.SettingCodes.INITIAL_WINDOW_SIZE)
            if changed is not None:
                initial = changed.new_value
                require(initial == 65535, 'peer stream initial window changed')
    ledger = trace['ledger']
    for stream_id, entry in ledger.streams.items():
        observed = raw['streams'].get(stream_id)
        if observed is not None and observed['reset']:
            entry.open = False
    trace['flow'].receive_batch(ledger, updates, initial)
    windows = {stream_id: protocol.local_flow_control_window(stream_id)
               for stream_id, item in ledger.streams.items() if item.open}
    trace['flow'].check_public(ledger, protocol.outbound_flow_control_window, windows)
    require(trace['receive_count'] < 4096, 'flow observation bound exceeded')
    trace['receive_count'] += 1
    observation = json.dumps({'connection': ledger.connection, 'sent': ledger.sent,
                              'refunded': ledger.refunded, 'windows': windows, 'updates': updates},
                             sort_keys=True, separators=(',', ':')).encode()
    require(len(observation) < 4096, 'flow observation byte bound')
    trace['flow_digest'].update(len(observation).to_bytes(4, 'big'))
    trace['flow_digest'].update(observation)
    flush(sock, protocol, deadline, capture)


def start(protocol, records, raw, method, path, headers, end_stream, limit, wire, status=200, info=0, policy='healthy'):
    stream = protocol.get_next_available_stream_id()
    wire.register(records, raw, stream, limit, status, info, policy)
    protocol.send_headers(stream, [(':method', method), (':scheme', 'https'),
                                  (':authority', 'localhost'), (':path', path)] + headers,
                          end_stream=end_stream)
    return stream


def complete(sock, protocol, records, raw, trace, stream, deadline, wire, capture, keep=False):
    flush(sock, protocol, deadline, capture)
    record = records[stream]
    def finished():
        policy = record['policy']
        raw_record = raw['streams'][stream]
        terminal = (record['ended'] if policy == 'healthy' else
                    raw_record['reset'] if policy in ('public_cancel', 'application_failure') else
                    raw_record['peer_reset'] if policy == 'peer_reset' else
                    record['ended'] and raw_record['reset'])
        return terminal and not raw['header'] and raw['frame'] is None
    while not finished():
        receive(sock, protocol, records, raw, trace, deadline, wire, capture)
    wire.complete(records, raw, stream)
    result = {'headers': record['headers'], 'bytes': record['bytes'],
              'sha256': record['hash'].hexdigest(), 'body': bytes(record['body']).decode('utf-8'),
              'informationals': record['informationals'], 'raw_reset': raw['streams'][stream]['reset'],
              'reset_event': record['reset_event']}
    if not keep:
        wire.retire(records, raw, stream)
    return result


def request(sock, protocol, records, raw, trace, path, deadline, wire, capture, limit=1024):
    stream = start(protocol, records, raw, 'GET', path, [], True, limit, wire)
    return complete(sock, protocol, records, raw, trace, stream, deadline, wire, capture)


def status(sock, protocol, records, raw, trace, tag, deadline, wire, capture):
    response = request(sock, protocol, records, raw, trace, '/status/' + tag, deadline, wire, capture)
    return json.loads(response['body'])


def metrics(sock, protocol, records, raw, trace, deadline, wire, capture):
    response = request(sock, protocol, records, raw, trace, '/metrics', deadline, wire, capture)
    return json.loads(response['body'])


def health(sock, protocol, records, raw, trace, deadline, wire, capture):
    response = request(sock, protocol, records, raw, trace, '/health', deadline, wire, capture, 2)
    require(response['body'] == 'ok', 'health differs')
    return response


def run(args, manifest):
    helper = load_bound('h2_client', manifest['helper'], manifest['inputs'])
    raw_module = load_bound('raw_observer', manifest['raw'], manifest['inputs'])
    sys.modules['raw_observer'] = raw_module
    wire = load_bound('wire', manifest['wire'], manifest['inputs'])
    sys.modules['wire'] = wire
    require(wire.raw_observer is raw_module, 'raw observer binding differs')
    flow = load_bound('flow_ledger', manifest['flow'], manifest['inputs'])
    expectations = load_bound('expectations', manifest['expectations'], manifest['inputs'])
    sys.modules['expectations'] = expectations
    cases = load_bound('lifecycle_cases', manifest['lifecycle'], manifest['inputs'])
    strict = load_bound('strict_close', manifest['strict'], manifest['inputs'])
    adapter = load_bound('runner_adapter', manifest['adapter'], manifest['inputs'])
    import h2
    import hpack
    import hyperframe
    for module in (h2, hpack, hyperframe):
        require(Path(module.__file__).resolve().is_relative_to(Path(PACKAGES)), 'client module origin differs')
    require(Path(helper.__file__).resolve() == Path(HELPER) / 'h2_client.py', 'helper origin differs')
    payload = helper.payload_block(32, 0, 32)
    require(payload == bytes(range(1, 11)) + b'final-upload-sentinel!', 'payload literal differs')
    require(hashlib.sha256(payload).hexdigest() == expectations.H32 and hashlib.sha256(payload[:7]).hexdigest() == expectations.H7, 'payload hash differs')
    overall = time.monotonic() + 900
    run_dir = Path(args.output).resolve()
    run_dir.mkdir(mode=0o700)
    cert, key, log = run_dir / 'certificate.pem', run_dir / 'private-key.pem', run_dir / 'server.log'
    nonce = os.urandom(16).hex()
    result = {'nonce': nonce, 'cases': {}, 'connections': [], 'success': False, 'cleanup': {},
              'python': sys.executable, 'python_path': sys.path, 'openssl': OPENSSL,
              'profile': manifest['binary'], 'manifest_sha256': args.manifest_sha256}
    child = None
    start_id = None
    collector = None
    connections = []
    capture = new_capture()
    error = None
    stage = 'setup'
    context = None
    try:
        stage = 'certificate'
        command = [OPENSSL, 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
                   '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost',
                   '-keyout', str(key), '-out', str(cert)]
        result['certificate_command'] = command
        certificate_env = {'OPENSSL_CONF': '/opt/conda/ssl/openssl.cnf'}
        result['certificate_environment'] = certificate_env
        subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True,
                       env=certificate_env, timeout=remaining(overall))
        os.chmod(key, 0o600)
        result['certificate_sha256'] = hashlib.sha256(ssl.PEM_cert_to_DER_cert(cert.read_text())).hexdigest()
        env = {'H2_PROFILE_CERT': str(cert), 'H2_PROFILE_KEY': str(key), 'H2_PROFILE_NONCE': nonce}
        result['child_argv'] = [manifest['binary']]
        result['child_environment'] = env.copy()
        stage = 'launch'
        child = subprocess.Popen([manifest['binary']], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
        collector = threading.Thread(target=drain_capture, args=(child.stdout, capture), daemon=True)
        collector.start()
        start_id = child_start(child.pid)
        result['child'] = {'pid': child.pid, 'start': start_id, 'binary_sha256': digest(manifest['binary'])}
        stage = 'readiness'
        result['listener_inode'] = wait_marker(child, capture, nonce, min(overall, time.monotonic() + 15))
        ready = capture_snapshot(capture)[0].decode('utf-8')
        capacity = [line for line in ready.splitlines() if 'H2_CAPACITY ' in line]
        require(len(capacity) == 1 and 'slab=4098304' in capacity[0], 'fixture capacity differs')
        result['capacity'] = capacity[0]
        tls_context = ssl.create_default_context(cafile=str(cert))
        tls_context.minimum_version = tls_context.maximum_version = ssl.TLSVersion.TLSv1_3
        tls_context.set_alpn_protocols(['h2'])
        context = {'ops': sys.modules[__name__], 'wire': wire, 'flow': flow, 'strict_close': strict,
                   'payload': payload, 'clock': time.monotonic, 'capture': capture,
                   'buffered_requests': 0, 'sealed': False, 'prior_complete': True}

        def owned():
            require_owned_child(child, start_id, result['listener_inode'])

        def connect(label):
            owned()
            deadline = context['deadline']
            raw_socket = socket.create_connection(('127.0.0.1', PORT), timeout=remaining(deadline))
            try:
                raw_socket.settimeout(remaining(deadline))
                sock = tls_context.wrap_socket(raw_socket, server_hostname='localhost', suppress_ragged_eofs=False)
            except BaseException:
                raw_socket.close()
                raise
            try:
                require(sock.version() == 'TLSv1.3' and sock.selected_alpn_protocol() == 'h2', 'TLS/ALPN differs')
                require(hashlib.sha256(sock.getpeercert(binary_form=True)).hexdigest() == result['certificate_sha256'], 'peer certificate identity differs')
                owned()
            except BaseException as exc:
                try:
                    sock.close()
                except BaseException as cleanup_error:
                    exc.add_note('unregistered TLS cleanup failed: ' + repr(cleanup_error))
                raise
            protocol = helper.new_protocol()
            connection = {'socket': sock, 'protocol': protocol, 'records': {}, 'raw': raw_module.new_state(),
                          'trace': {'events': {}, 'ledger': flow.FlowLedger(), 'flow': flow,
                                    'receive_count': 0, 'flow_digest': hashlib.sha256()},
                          'offsets': {}, 'closed': False, 'label': label}
            connections.append(connection)
            flush(sock, protocol, deadline, capture)
            context['buffered_requests'] += 1
            health(sock, protocol, connection['records'], connection['raw'], connection['trace'], deadline, wire, capture)
            require(protocol.remote_settings.initial_window_size == 65535, 'initial stream window differs')
            result['connections'].append({'label': label, 'tls': sock.version(), 'alpn': sock.selected_alpn_protocol()})
            return connection

        def replacement():
            connection = connect('disconnect_replacement')
            return {'connection': connection, 'owned': True, 'tls': 'TLSv1.3', 'alpn': 'h2'}

        context['replacement'] = replacement
        last = None
        for case in args.cases:
            if last is not None and not last['closed']:
                require(not last['records'] and not last['raw']['streams'], 'prior responses remain')
                last['socket'].close()
                last['socket'] = None
                last['closed'] = True
            context['deadline'] = min(overall, time.monotonic() + 30)
            stage = 'case:' + case + ':connect'
            last = connect(case)
            stage = 'case:' + case + ':execute'
            if case == 'disconnect':
                context['prior_complete'] = False
                result['cases'][case] = cases.disconnect(adapter.disconnect_api(context), last)
                last = connections[-1]
            elif case == 'reuse':
                context['prior_complete'] = False
                result['cases'][case] = cases.reuse(adapter.reuse_api(context, last))
            else:
                break
            require(not last['records'] and not last['raw']['streams'], 'case responses remain')
            context['prior_complete'] = True

        def graceful_deadline():
            case_deadline = context['deadline'] if args.cases[-1] == 'shutdown_active' else None
            return choose_graceful_deadline(overall, case_deadline, time.monotonic())

        def send_signal(connection, deadline):
            remaining(deadline)
            require(context['sealed'] and connection is last and not connection['closed'] and connection['socket'] is not None, 'client not open at signal')
            owned()
            os.kill(child.pid, signal.SIGTERM)
            return {'signal': 'SIGTERM', 'owned_identity': True, 'watcher_installed': True, 'client_open': True}

        def parse_post(deadline):
            remaining(deadline)
            check_capture(capture)
            output = capture_snapshot(capture)[0].decode('utf-8')
            records, metrics = {}, None
            for line in output.splitlines():
                marker = 'H2_RECORD ' + nonce + ' '
                if marker in line:
                    item = json.loads(line.split(marker, 1)[1])
                    require(item['tag'] not in records, 'duplicate post-deinit tag')
                    records[item['tag']] = item
                marker = 'H2_DEINIT ' + nonce + ' '
                if marker in line:
                    require(metrics is None, 'duplicate post-deinit aggregate')
                    metrics = json.loads(line.split(marker, 1)[1])
            require(metrics is not None, 'missing deinit marker')
            return {'records': records, 'metrics': metrics}

        def wait_owned(deadline):
            exit_code = child.wait(timeout=remaining(deadline))
            collector.join(timeout=remaining(deadline))
            require(not collector.is_alive(), 'server output collector did not finish')
            post = parse_post(deadline)
            key.unlink(missing_ok=True)
            require(not key.exists(), 'private key remains')
            result['cleanup'] = {'signal': 'SIGTERM', 'exit_code': exit_code, 'reaped': True, 'forced': False}
            return {'exit_code': exit_code, 'reaped': True, 'forced': False,
                    'run_ok': post['metrics'] is not None, 'deinit_ok': post['metrics'] is not None, 'key_removed': True}

        context.update(graceful_deadline=graceful_deadline, signal=send_signal, wait=wait_owned, post=parse_post)
        if args.cases[-1] == 'shutdown_active':
            result['cases']['shutdown_active'] = cases.shutdown_active(adapter.shutdown_api(context), last, tuple(args.cases))
        else:
            stage = 'idle_final_status'
            rows = {tag: adapter.status(context, last, tag) for tag in expectations.TAGS}
            metrics = adapter.metrics(context, last)
            cases.verify_final(rows, metrics, tuple(args.cases), 'after', context['buffered_requests'])
            last['socket'].close()
            last['socket'] = None
            last['closed'] = True
            deadline = graceful_deadline()
            owned()
            os.kill(child.pid, signal.SIGTERM)
            process = wait_owned(deadline)
            require(process == {'exit_code': 0, 'reaped': True, 'forced': False, 'run_ok': True, 'deinit_ok': True, 'key_removed': True}, 'idle shutdown failed')
            post = parse_post(deadline)
            cases.verify_final(post['records'], post['metrics'], tuple(args.cases), 'after', context['buffered_requests'])
            for tag in expectations.TAGS:
                require(all(rows[tag][key] == post['records'][tag][key] for key in ('chunks', 'max_span')), 'idle post diagnostics differ')
            result['idle_teardown'] = {'before': {'records': rows, 'metrics': metrics}, 'after': post, 'process': process}
        total_sent = 0
        for connection, observation in zip(connections, result['connections']):
            ledger = connection['trace']['ledger']
            total_sent += ledger.sent
            observation.update(sent_flow=ledger.sent, refunded_flow=ledger.refunded,
                               receive_count=connection['trace']['receive_count'],
                               flow_sha256=connection['trace']['flow_digest'].hexdigest(),
                               events=connection['trace']['events'], closing=connection.get('closing_observation'))
        expected_sent = sum({'disconnect': 64, 'reuse': 288, 'shutdown_active': 32}[case] for case in args.cases)
        require(total_sent == expected_sent, 'client DATA total differs')
        result['sent_flow'] = total_sent
        result['success'] = True
    except BaseException as exc:
        error = repr(exc)
        result['failure'] = failure_details(exc, stage)
    finally:
        def close_clients():
            close_connections(connections)
        def signal_child():
            if child is None or child.poll() is not None:
                return
            require(start_id is None or child_start(child.pid) == start_id, 'child identity changed during cleanup')
            result['cleanup']['forced'] = True
            child.kill()
        def wait_child():
            if child is not None:
                child.wait(timeout=15)
                result['cleanup']['exit_code'] = child.returncode
                result['cleanup']['reaped'] = True
        def delete_key():
            key.unlink(missing_ok=True)
            require(not key.exists(), 'private key remains')
        def save_log():
            if collector is not None:
                collector.join(timeout=15)
            data, overflow, collector_error = capture_snapshot(capture)
            log.write_bytes(data)
            require(collector is None or not collector.is_alive(), 'server output collector did not finish')
            require(not overflow and collector_error is None, 'server output collection failed or overflowed')
        def close_pipe():
            if child is not None and child.stdout is not None:
                child.stdout.close()
        errors = cleanup_actions((('clients', close_clients), ('child_signal', signal_child), ('child_wait', wait_child),
                                  ('key', delete_key), ('log', save_log), ('pipe', close_pipe)))
        if errors or result['cleanup'].get('forced', False):
            result['success'] = False
        result['cleanup']['errors'] = errors
        result['error'] = error
        (run_dir / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    require(result['success'], 'owned run failed: ' + str(error))


def validate_selection(selection):
    require(bool(selection) and len(set(selection)) == len(selection), 'invalid case selection')
    require(set(selection) <= set(CASES), 'unsupported case selection')
    require('shutdown_active' not in selection or selection[-1] == 'shutdown_active', 'shutdown must be last')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true', required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--cases', nargs='+', choices=CASES, default=list(CASES))
    args = parser.parse_args()
    require(dict(os.environ) == {'PYTHONPATH': PACKAGES + ':' + HELPER, 'LC_ALL': 'C.UTF-8'},
            'runner environment must contain only the pinned locale and PYTHONPATH')
    require(sys.executable == PYTHON and sys.dont_write_bytecode and sys.flags.no_site and os.environ.get('PYTHONPATH') == PACKAGES + ':' + HELPER,
            'Python interpreter or PYTHONPATH differs')
    validate_selection(args.cases)
    output = Path(args.output)
    require(output.is_absolute() and output.resolve().is_relative_to(Path('/tmp')) and output.resolve() != Path('/tmp'), 'output must be new /tmp path')
    require(not output.exists(), 'output already exists')
    manifest = check_manifest(args.manifest, args.manifest_sha256)
    run(args, manifest)


if __name__ == '__main__':
    main()
