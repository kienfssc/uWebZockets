import copy
import unittest

import expectations
import lifecycle_cases


class DisconnectDouble:
    def __init__(self, defect=None):
        self.old = object()
        self.new = object()
        self.current = self.old
        self.defect = defect
        self.events = []
        self.rows = expectations.records((), 'after')
        for row in self.rows.values():
            row.update(chunks=0, max_span=0)

    def start(self, connection, tag, metadata, policy):
        self.events.append(('start', connection, tag))
        expected_policy = 'clean_disconnect' if tag == 'disconnect' else 'healthy'
        if connection is not self.current or policy != expected_policy:
            raise AssertionError('unexpected connection or policy')
        if metadata != {'method': 'POST', 'path': '/limit/' + tag, 'query': 'case=' + tag,
                        'target': '/limit/' + tag + '?case=' + tag, 'x-case': tag,
                        'content-length': '32'}:
            raise AssertionError('request metadata differs')
        return tag

    def send(self, connection, stream, length, eof):
        self.events.append(('send', connection, stream, length, eof))
        row = self.rows[stream]
        if stream == 'disconnect' and (length, eof) == (32, False):
            row.update(expectations.records(('disconnect',), 'after')[stream])
            row.update(cancel=0, reason='none', active=True, paused=True,
                       stale_resume=0, stale_cancel=0, chunks=1, max_span=32)
            if self.defect == 'pause':
                row['paused'] = False
            if self.defect == 'prehash':
                row['sha256'] = expectations.H32
            if self.defect == 'preidentity':
                row['tag'] = 'wrong'
            return
        if stream == 'disconnect_recovery' and (length, eof) == (7, False):
            row.update(expectations.records(('disconnect',), 'after')[stream])
            row.update(accepted=7, sha256=expectations.H7, end=0, active=True,
                       metadata_end=0, chunks=1, max_span=7)
            if self.defect == 'recovery_paused':
                row['paused'] = True
            return
        if stream == 'disconnect_recovery' and (length, eof) == (25, True):
            if self.rows['disconnect']['stale_resume'] != 2 or self.rows['disconnect']['stale_cancel'] != 2:
                raise AssertionError('recovery tail before both controls')
            row.update(accepted=32, sha256=expectations.H32, end=1, active=False,
                       metadata_end=1, chunks=2, max_span=25)
            return
        raise AssertionError('unexpected send')

    def status(self, connection, tag):
        self.events.append(('status', connection, tag))
        if connection is not self.current:
            raise AssertionError('status on wrong connection')
        return copy.deepcopy(self.rows[tag])

    def close(self, connection):
        self.events.append(('close', connection))
        if not self.events[-2] == ('status', self.old, 'disconnect'):
            raise AssertionError('close before barrier')
        evidence = {'method': 'ssl_unwrap', 'tls_shutdown': 'success', 'tcp_eof': True,
                    'trailing_bytes': 0, 'close': 'normal'}
        if self.defect == 'close_fail':
            evidence['tls_shutdown'] = 'timeout'
        if self.defect == 'reset':
            evidence['tls_shutdown'] = 'reset'
        if self.defect == 'no_eof':
            evidence['tcp_eof'] = False
        if self.defect == 'bytes':
            evidence['trailing_bytes'] = 1
        if self.defect == 'abrupt':
            evidence['close'] = 'abrupt'
        if self.defect not in ('local_only', 'missing_server'):
            self.rows['disconnect'].update(cancel=1, reason='reset' if self.defect == 'cause' else 'peer_closed',
                                           active=False, paused=False)
        return evidence

    def replacement(self):
        self.events.append(('replacement',))
        if self.events[-2] != ('close', self.old):
            raise AssertionError('replacement before close')
        self.current = self.new
        if self.defect == 'replacement_same':
            return {'connection': self.old, 'owned': True, 'tls': 'TLSv1.3', 'alpn': 'h2'}
        if self.defect == 'replacement_unowned':
            return {'connection': self.new, 'owned': False, 'tls': 'TLSv1.3', 'alpn': 'h2'}
        return {'connection': self.new, 'owned': True, 'tls': 'TLSv1.3', 'alpn': 'h2'}

    def control(self, connection, operation, tag):
        self.events.append(('control', connection, operation, tag))
        if connection is not self.new:
            raise AssertionError('control on departed connection')
        self.rows[tag]['stale_' + operation] += 1
        if self.defect == 'old_mutation':
            self.rows[tag]['accepted'] += 1
        if self.defect == 'current_mutation' and self.rows['disconnect_recovery']['active']:
            self.rows['disconnect_recovery']['accepted'] += 1
        return 'wrong' if self.defect == 'control' else 'BodyControlExpired'

    def finish(self, connection, stream):
        self.events.append(('finish', connection, stream))
        row = copy.deepcopy(self.rows[stream])
        if self.defect == 'recovery':
            row['sha256'] = expectations.H7
        if self.defect == 'recovery_terminal':
            row['cancel'] = 1
        if self.defect == 'recovery_identity':
            row['tag'] = 'wrong'
        if self.defect == 'recovery_status':
            return {'status': 503, 'record': row}
        return {'status': 200, 'record': row}

    def api(self):
        return {name: getattr(self, name) for name in ('start', 'send', 'status', 'close', 'replacement', 'control', 'finish')}


class DisconnectTests(unittest.TestCase):
    def test_clean_close_then_replacement_and_independent_recovery(self):
        double = DisconnectDouble()
        result = lifecycle_cases.disconnect(double.api(), double.old)
        self.assertEqual((result['stale_resume'], result['stale_cancel']), (2, 2))
        self.assertEqual(len(result['evidence_sha256']), 64)
        self.assertLess(double.events.index(('close', double.old)), double.events.index(('replacement',)))
        self.assertEqual(sum(event[0] == 'control' for event in double.events), 4)
        positions = [i for i, event in enumerate(double.events) if event[0] == 'control']
        controls = [double.events[i] for i in positions]
        self.assertEqual([event[2] for event in controls], ['resume', 'cancel', 'resume', 'cancel'])
        recovery_start = double.events.index(('start', double.new, 'disconnect_recovery'))
        self.assertLess(positions[1], recovery_start)
        self.assertGreater(positions[2], recovery_start)
        self.assertLess(positions[3], double.events.index(('send', double.new, 'disconnect_recovery', 25, True)))

    def test_rejects_bad_observations(self):
        for defect in ('pause', 'prehash', 'preidentity', 'close_fail', 'reset', 'no_eof', 'bytes', 'abrupt',
                       'local_only', 'missing_server', 'cause', 'control', 'old_mutation',
                       'current_mutation', 'replacement_same', 'replacement_unowned', 'recovery_paused',
                       'recovery', 'recovery_terminal', 'recovery_identity', 'recovery_status'):
            with self.subTest(defect=defect):
                double = DisconnectDouble(defect)
                with self.assertRaises(ValueError):
                    lifecycle_cases.disconnect(double.api(), double.old)


if __name__ == '__main__':
    unittest.main()
