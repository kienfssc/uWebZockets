import copy
import unittest

import expectations
import lifecycle_cases


class CaseTests(unittest.TestCase):
    def test_expired_control_requires_no_other_mutation(self):
        old = {'accepted': 32, 'stale_resume': 0, 'stale_cancel': 0}
        active = {'accepted': 7, 'active': True}
        state = {'old': copy.deepcopy(old), 'active': copy.deepcopy(active)}

        def control(operation, tag):
            state[tag]['stale_' + operation] += 1
            return 'BodyControlExpired'

        lifecycle_cases.expired_pair(lambda tag: copy.deepcopy(state[tag]), control, 'old', 'active')
        self.assertEqual(state['old']['stale_resume'], 1)
        self.assertEqual(state['old']['stale_cancel'], 1)

        def bad_control(operation, tag):
            state[tag]['accepted'] += 1
            return control(operation, tag)

        with self.assertRaises(ValueError):
            lifecycle_cases.expired_pair(lambda tag: copy.deepcopy(state[tag]), bad_control, 'old', 'active')

    def test_active_record_mutation_rejected(self):
        state = {'old': {'stale_resume': 0, 'stale_cancel': 0}, 'active': {'accepted': 7}}

        def control(operation, tag):
            state[tag]['stale_' + operation] += 1
            state['active']['accepted'] += 1
            return 'BodyControlExpired'

        with self.assertRaises(ValueError):
            lifecycle_cases.expired_pair(lambda tag: copy.deepcopy(state[tag]), control, 'old', 'active')


class ReuseDouble:
    def __init__(self, defect=None):
        self.rows = expectations.records((), 'after')
        for row in self.rows.values():
            row.update(chunks=0, max_span=0)
        self.calls = []
        self.defect = defect
        self.current = None

    def start(self, tag, metadata, policy):
        self.calls.append(('start', tag, metadata, policy))
        self.current = tag
        if policy != 'healthy':
            raise AssertionError('policy differs')
        if metadata != {'method': 'POST', 'path': '/limit/' + tag, 'query': 'case=' + tag,
                        'target': '/limit/' + tag + '?case=' + tag, 'x-case': tag,
                        'content-length': '32'}:
            raise AssertionError('metadata differs')
        return tag

    def send(self, tag, length, eof):
        self.calls.append(('send', tag, length, eof))
        row = self.rows[tag]
        if length == 7 and not eof:
            row.update(expectations.records(('reuse',), 'after')[tag])
            row.update(accepted=7, sha256=expectations.H7, end=0, active=True,
                       metadata_end=0, stale_resume=0, stale_cancel=0, chunks=1, max_span=7)
            if self.defect == 'barrier':
                row['paused'] = True
            return
        if length != 25 or not eof:
            raise AssertionError('unexpected send')
        index = int(tag[-1])
        controls = [item for item in self.calls if item[0] == 'control' and item[3] == tag]
        if len(controls) != index * 2:
            raise AssertionError('suffix before stale checks')
        row.update(accepted=32, sha256=expectations.H32, end=1, active=False,
                   metadata_end=1, chunks=2, max_span=25)

    def status(self, tag):
        return copy.deepcopy(self.rows[tag])

    def control(self, operation, tag):
        self.calls.append(('control', operation, tag, self.current))
        self.rows[tag]['stale_' + operation] += 1
        if self.defect == 'old_mutation':
            self.rows[tag]['accepted'] -= 1
        if self.defect == 'current_mutation':
            self.rows[self.current]['accepted'] -= 1
        return 'unexpected' if self.defect == 'control' else 'BodyControlExpired'

    def finish(self, tag):
        self.calls.append(('finish', tag))
        row = copy.deepcopy(self.rows[tag])
        if self.defect == 'identity':
            row['tag'] = 'reuse_wrong'
        elif self.defect == 'hash':
            row['sha256'] = expectations.H7
        elif self.defect == 'terminal':
            row['cancel'] = 1
        elif self.defect == 'status':
            return {'status': 503, 'record': row}
        return {'status': 200, 'record': row}

    def api(self):
        return {name: getattr(self, name) for name in ('start', 'send', 'status', 'control', 'finish')}


class ReuseTests(unittest.TestCase):
    def test_nine_sequential_requests_and_ordered_controls(self):
        double = ReuseDouble()
        result = lifecycle_cases.reuse(double.api())
        self.assertEqual(result['requests'], 9)
        self.assertEqual(result['stale_resume'], 36)
        self.assertEqual(result['stale_cancel'], 36)
        self.assertEqual(len(result['evidence_sha256']), 64)
        self.assertEqual(sum(item[0] == 'finish' for item in double.calls), 9)
        for i in range(9):
            tag = 'reuse_' + str(i)
            row = double.rows[tag]
            self.assertEqual((row['stale_resume'], row['stale_cancel']), (8 - i, 8 - i))
            controls = [item[1:3] for item in double.calls if item[0] == 'control' and item[3] == tag]
            expected = [(operation, 'reuse_' + str(j)) for j in range(i) for operation in ('resume', 'cancel')]
            self.assertEqual(controls, expected)
            sends = [item[2:] for item in double.calls if item[0] == 'send' and item[1] == tag]
            self.assertEqual(sends, [(7, False), (25, True)])

    def test_rejects_invalid_observations(self):
        for defect in ('control', 'barrier', 'old_mutation', 'current_mutation',
                       'identity', 'hash', 'terminal', 'status'):
            with self.subTest(defect=defect):
                with self.assertRaises(ValueError):
                    lifecycle_cases.reuse(ReuseDouble(defect).api())


if __name__ == '__main__':
    unittest.main()
