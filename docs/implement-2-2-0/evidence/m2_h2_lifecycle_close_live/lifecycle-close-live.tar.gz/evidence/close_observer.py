"""Strict bounded post-signal HTTP/2 frame observation."""


def new_state(stream_id):
    if stream_id <= 0 or stream_id > 0x7fffffff or stream_id % 2 == 0:
        raise ValueError('invalid active stream')
    return {'stream': stream_id, 'pending': bytearray(), 'frames': 0, 'bytes': 0}


def observe(state, data):
    if len(data) > 8192 or state['bytes'] + len(data) > 65536:
        raise ValueError('closing byte bound')
    state['bytes'] += len(data)
    state['pending'].extend(data)
    while len(state['pending']) >= 9:
        data = state['pending']
        length = int.from_bytes(data[:3], 'big')
        if length != 4 or data[3] != 8 or data[4] != 0:
            raise ValueError('unexpected closing frame')
        stream = int.from_bytes(data[5:9], 'big')
        if stream not in (0, state['stream']):
            raise ValueError('unexpected closing stream')
        if len(data) < 13:
            return
        increment = int.from_bytes(data[9:13], 'big')
        if increment == 0 or increment > 0x7fffffff:
            raise ValueError('invalid closing credit')
        del data[:13]
        state['frames'] += 1
        if state['frames'] > 4096:
            raise ValueError('closing frame bound')


def finish(state, signal_sent, outcome):
    if not signal_sent or outcome not in ('eof', 'tls_eof'):
        raise ValueError('invalid closing phase or outcome')
    if state['pending']:
        raise ValueError('trailing closing bytes')
