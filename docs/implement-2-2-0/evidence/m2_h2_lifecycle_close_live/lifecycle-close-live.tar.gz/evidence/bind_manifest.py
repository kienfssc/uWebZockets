"""Bind the current reviewed-base dependency and final guarded tools."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'application-error/manifest-v3.json'
BASE_HASH = 'd2bb368da8f912f3b37ed97376d8d73a11259570b44aae893981609e3ac5a62f'
V1_HASH = 'd8e754635a3cdf0d030d4997e5873e1174d209946a36b418fcd2ef664dc0e070'
RUNNER = Path('/tmp/uwz-task5c3-runtime-v1/run_live.py')


def digest(path):
    value = hashlib.sha256()
    with open(path, 'rb') as source:
        while block := source.read(1048576):
            value.update(block)
    return value.hexdigest()


def main():
    output = HERE / 'manifest-v2.json'
    if output.exists():
        raise ValueError('current manifest already exists')
    spec = importlib.util.spec_from_file_location('binding_runner', RUNNER)
    if spec is None or spec.loader is None:
        raise ValueError('runner loader unavailable')
    module = importlib.util.module_from_spec(spec)
    sys.modules['binding_runner'] = module
    spec.loader.exec_module(module)
    manifest = module.check_manifest(HERE / 'manifest-v1.json', V1_HASH)
    if digest(BASE) != BASE_HASH:
        raise ValueError('reviewed base manifest differs')
    manifest['inputs'][str(BASE)] = BASE_HASH
    for name in ('bind_manifest.py', 'check_closure_v2.py', 'test_bind_import.py'):
        path = HERE / name
        manifest['inputs'][str(path)] = digest(path)
    output.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    result = digest(output)
    module.check_manifest(output, result)
    print('v1 closure accepted; current closure accepted')
    print('direct inputs:', len(manifest['inputs']))
    print('manifest sha256:', result)


if __name__ == '__main__':
    main()
