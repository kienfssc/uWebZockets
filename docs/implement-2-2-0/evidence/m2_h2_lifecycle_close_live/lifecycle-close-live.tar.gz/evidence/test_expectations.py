import copy
import unittest

import expectations


class ExpectationTests(unittest.TestCase):
    def test_full_totals_and_independent_transition(self):
        before = expectations.records(('disconnect', 'reuse', 'shutdown_active'), 'before')
        after = expectations.records(('disconnect', 'reuse', 'shutdown_active'), 'after')
        self.assertEqual(expectations.totals(before), (12, 12, 10, 1, 334, 1))
        self.assertEqual(expectations.totals(after), (12, 12, 10, 2, 334, 0))
        self.assertEqual(before['shutdown_active']['reason'], 'none')
        self.assertEqual(after['shutdown_active']['reason'], 'shutdown')
        self.assertTrue(before['shutdown_active']['paused'])
        self.assertFalse(after['shutdown_active']['paused'])
        self.assertEqual(before['disconnect']['reason'], 'peer_closed')

    def test_reuse_counts_and_identity(self):
        records = expectations.records(('reuse',), 'after')
        for i in range(9):
            record = records['reuse_' + str(i)]
            self.assertEqual(record['stale_resume'], 8 - i)
            self.assertEqual(record['stale_cancel'], 8 - i)
            self.assertEqual(record['sha256'], expectations.H32)
        changed = copy.deepcopy(records)
        changed['reuse_0']['sha256'] = expectations.H7
        with self.assertRaises(ValueError):
            expectations.verify(changed, records)
        changed = copy.deepcopy(records)
        changed['reuse_0'], changed['reuse_1'] = changed['reuse_1'], changed['reuse_0']
        with self.assertRaises(ValueError):
            expectations.verify(changed, records)

    def test_wrong_close_and_transition_rejected(self):
        expected = expectations.records(('disconnect', 'shutdown_active'), 'after')
        for tag, field, value in (('disconnect', 'reason', 'reset'),
                                  ('shutdown_active', 'reason', 'peer_closed'),
                                  ('shutdown_active', 'active', True),
                                  ('shutdown_active', 'cancel', 2)):
            actual = copy.deepcopy(expected)
            actual[tag][field] = value
            with self.assertRaises(ValueError):
                expectations.verify(actual, expected)

    def test_actual_chunk_evidence_is_bounded(self):
        expected = expectations.records(('reuse',), 'after')
        actual = copy.deepcopy(expected)
        for record in actual.values():
            record['chunks'] = int(record['accepted'] > 0)
            record['max_span'] = record['accepted']
        expectations.verify(actual, expected)
        actual['reuse_0']['max_span'] = 8193
        with self.assertRaises(ValueError):
            expectations.verify(actual, expected)


if __name__ == '__main__':
    unittest.main()
