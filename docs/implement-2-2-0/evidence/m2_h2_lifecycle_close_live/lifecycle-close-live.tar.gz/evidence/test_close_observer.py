import unittest

import close_observer


def frame(kind, stream, payload, flags=0):
    return len(payload).to_bytes(3, 'big') + bytes((kind, flags)) + stream.to_bytes(4, 'big') + payload


class CloseObserverTests(unittest.TestCase):
    def test_fragmented_credit_and_post_signal_eof(self):
        state = close_observer.new_state(1)
        encoded = frame(8, 0, b'\x00\x00\x00\x07')
        close_observer.observe(state, encoded[:10])
        close_observer.observe(state, encoded[10:])
        close_observer.finish(state, True, 'tls_eof')
        self.assertEqual(state['frames'], 1)

    def test_rejects_invalid_frames_and_early_close(self):
        for encoded in (frame(0, 1, b''), frame(3, 1, bytes(4)),
                        frame(7, 0, bytes(8)), frame(8, 1, bytes(4)),
                        frame(8, 3, b'\x00\x00\x00\x01')):
            with self.assertRaises(ValueError):
                close_observer.observe(close_observer.new_state(1), encoded)
        with self.assertRaises(ValueError):
            close_observer.finish(close_observer.new_state(1), False, 'eof')
        with self.assertRaises(ValueError):
            close_observer.finish(close_observer.new_state(1), True, 'timeout')
        state = close_observer.new_state(1)
        close_observer.observe(state, frame(8, 0, b'\x00\x00\x00\x01')[:10])
        with self.assertRaises(ValueError):
            close_observer.finish(state, True, 'eof')


if __name__ == '__main__':
    unittest.main()
