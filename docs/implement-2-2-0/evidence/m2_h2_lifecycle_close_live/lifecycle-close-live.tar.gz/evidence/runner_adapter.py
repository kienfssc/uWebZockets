"""Caller-owned bounded request and flow adapter for lifecycle cases."""
import json


def require(condition, message):
    if not condition:
        raise ValueError(message)


def metadata_headers(tag, metadata):
    require(set(metadata) == {'method', 'path', 'query', 'target', 'x-case', 'content-length'}, 'metadata fields differ')
    require(metadata['method'] == 'POST' and metadata['path'] == '/limit/' + tag and
            metadata['query'] == 'case=' + tag and metadata['target'] == metadata['path'] + '?' + metadata['query'] and
            metadata['x-case'] == tag and metadata['content-length'] == '32', 'metadata identity differs')
    return [('content-length', '32'), ('x-case', tag)]


def start(context, connection, tag, metadata, policy):
    require(not connection['closed'] and not context['sealed'], 'connection closed or requests sealed')
    headers = metadata_headers(tag, metadata)
    require(policy in ('healthy', 'clean_disconnect', 'owned_shutdown'), 'invalid request policy')
    ops, wire, flow = context['ops'], context['wire'], context['flow']
    stream = ops.start(connection['protocol'], connection['records'], connection['raw'], 'POST',
                       metadata['target'], headers, False, 1024 if policy == 'healthy' else 0,
                       wire, policy=policy)
    flow.open_stream(connection['trace']['ledger'], stream)
    connection['offsets'][stream] = 0
    ops.flush_headers(connection['socket'], connection['protocol'], context['deadline'], context['capture'], stream)
    return stream


def send(context, connection, stream, length, end_stream):
    require(type(length) is int and 0 <= length <= 8192 and type(end_stream) is bool, 'invalid DATA span')
    offset = connection['offsets'][stream]
    require(offset + length <= len(context['payload']), 'payload offset bound')
    data = context['payload'][offset:offset + length]
    protocol, ledger, flow = connection['protocol'], connection['trace']['ledger'], context['flow']
    flow.check_public(ledger, protocol.outbound_flow_control_window, {stream: protocol.local_flow_control_window(stream)})
    flow.send_data(ledger, stream, len(data), None, protocol.max_outbound_frame_size, end_stream)
    protocol.send_data(stream, data, end_stream=end_stream)
    context['ops'].flush(connection['socket'], protocol, context['deadline'], context['capture'])
    connection['offsets'][stream] = offset + length


def request(context, connection, path, limit=1024):
    require(not connection['closed'] and not context['sealed'], 'requests are sealed')
    context['buffered_requests'] += 1
    return context['ops'].request(connection['socket'], connection['protocol'], connection['records'], connection['raw'],
                                  connection['trace'], path, context['deadline'], context['wire'], context['capture'], limit)


def status(context, connection, tag):
    response = request(context, connection, '/status/' + tag)
    return json.loads(response['body'])


def metrics(context, connection):
    response = request(context, connection, '/metrics')
    context['sealed'] = True
    return json.loads(response['body'])


def control(context, connection, operation, tag):
    require(operation in ('resume', 'cancel'), 'invalid control')
    response = request(context, connection, '/control/' + operation + '/' + tag, 64)
    return response['body']


def finish(context, connection, stream):
    result = context['ops'].complete(connection['socket'], connection['protocol'], connection['records'], connection['raw'],
                                     connection['trace'], stream, context['deadline'], context['wire'], context['capture'])
    record = json.loads(result['body'])
    statuses = [value for name, value in result['headers'] if name == ':status']
    require(statuses == ['200'], 'healthy response status differs')
    ledger = connection['trace']['ledger']
    require(not ledger.streams[stream].open, 'upload stream still open')
    context['flow'].retire_stream(ledger, stream)
    del connection['offsets'][stream]
    return {'status': int(statuses[0]), 'record': record}


def clean_close(context, connection):
    require(not connection['closed'] and len(connection['records']) == 1, 'invalid disconnect state')
    stream = next(iter(connection['records']))
    wire = context['wire']
    wire.begin_termination(connection['records'], connection['raw'], stream, 'clean_disconnect', 'pre_unwrap')
    proof = context['strict_close'].unwrap_eof(connection['socket'], context['deadline'], context['clock'])
    wire.finish_termination(connection['records'], connection['raw'], stream, 'clean_disconnect', 'pre_unwrap', proof)
    connection['socket'] = None
    connection['closed'] = True
    return proof


def reuse_api(context, connection):
    return {'start': lambda tag, metadata, policy: start(context, connection, tag, metadata, policy),
            'send': lambda stream, length, end: send(context, connection, stream, length, end),
            'status': lambda tag: status(context, connection, tag),
            'control': lambda operation, tag: control(context, connection, operation, tag),
            'finish': lambda stream: finish(context, connection, stream)}


def disconnect_api(context):
    return {'start': lambda connection, tag, metadata, policy: start(context, connection, tag, metadata, policy),
            'send': lambda connection, stream, length, end: send(context, connection, stream, length, end),
            'status': lambda connection, tag: status(context, connection, tag),
            'control': lambda connection, operation, tag: control(context, connection, operation, tag),
            'finish': lambda connection, stream: finish(context, connection, stream),
            'close': lambda connection: clean_close(context, connection),
            'replacement': context['replacement']}


def shutdown_api(context):
    def preconditions(connection):
        return {'prior_complete': context['prior_complete'] and not connection['records'],
                'client_open': not connection['closed'] and connection['socket'] is not None}

    def termination(connection, deadline):
        require(context['sealed'] and not connection['closed'], 'shutdown termination phase differs')
        stream = next(iter(connection['records']))
        evidence, observed = context['strict_close'].observe_shutdown(
            connection['socket'], connection['protocol'], connection['records'], connection['raw'],
            connection['trace']['events'], stream, context['signal_evidence'], deadline, context['clock'])
        updates = [(stream_id, amount) for stream_id, amount in
                   ((0, observed['connection_credit']), (stream, observed['stream_credit'])) if amount]
        context['flow'].receive_batch(connection['trace']['ledger'], updates)
        context['flow'].check_public(connection['trace']['ledger'], connection['protocol'].outbound_flow_control_window, {})
        connection['closing_observation'] = observed
        return evidence

    def signal(connection, deadline):
        require(context['sealed'] and not connection['closed'] and connection['socket'] is not None, 'client not open at signal')
        evidence = context['signal'](connection, deadline)
        context['signal_evidence'] = evidence
        return evidence

    return {'preconditions': preconditions,
            'start': lambda connection, tag, metadata, policy: start(context, connection, tag, metadata, policy),
            'send': lambda connection, stream, length, end: send(context, connection, stream, length, end),
            'status': lambda connection, tag: status(context, connection, tag),
            'metrics': lambda connection: metrics(context, connection),
            'request_count': lambda: context['buffered_requests'],
            'graceful_deadline': context['graceful_deadline'], 'signal': signal, 'termination': termination,
            'wait': context['wait'], 'post': context['post']}
