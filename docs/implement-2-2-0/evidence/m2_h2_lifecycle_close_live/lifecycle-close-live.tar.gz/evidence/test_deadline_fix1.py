import unittest
from unittest.mock import patch

import lifecycle_cases
import run_live
from test_shutdown_case import ShutdownDouble


class DeadlineTests(unittest.TestCase):
    def test_case_whole_grace_and_idle_bounds(self):
        self.assertEqual(run_live.choose_graceful_deadline(900.0, 30.0, 29.0), 30.0)
        self.assertEqual(run_live.choose_graceful_deadline(35.0, 100.0, 29.0), 35.0)
        self.assertEqual(run_live.choose_graceful_deadline(900.0, 100.0, 29.0), 44.0)
        self.assertEqual(run_live.choose_graceful_deadline(900.0, None, 29.0), 44.0)
        self.assertEqual(run_live.choose_graceful_deadline(35.0, None, 29.0), 35.0)

    def test_expired_boundary_is_not_extended(self):
        deadline = run_live.choose_graceful_deadline(900.0, 30.0, 30.0)
        with patch.object(run_live.time, 'monotonic', return_value=30.0):
            with self.assertRaises(RuntimeError):
                run_live.remaining(deadline)

    def test_actual_shutdown_api_uses_one_clipped_deadline(self):
        selected = ('shutdown_active',)
        double = ShutdownDouble(selected)
        case_deadline = 30.0
        double.deadline = case_deadline
        api = double.api()
        api['graceful_deadline'] = lambda: run_live.choose_graceful_deadline(900.0, case_deadline, 29.0)
        result = lifecycle_cases.shutdown_active(api, double.connection, selected)
        self.assertEqual(result['termination']['phase'], 'post_signal')
        self.assertEqual(double.events[-4:], ['signal', 'termination', 'wait', 'post'])


if __name__ == '__main__':
    unittest.main()
