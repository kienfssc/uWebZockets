"""Verify archive safety, exact member bytes and the current proof bindings."""

import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tarfile


ROOT = Path('/workspaces/uWebZockets')


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    output = ROOT / 'docs/implement-2-2-0/evidence/m2_h2_lifecycle_close_live'
    manifest = json.loads((output / 'manifest.json').read_text())
    archive = output / manifest['archive']
    require(sha(archive.read_bytes()) == manifest['archive_sha256'] and archive.stat().st_size == manifest['archive_bytes'], 'archive identity')
    with tarfile.open(archive, 'r:gz') as package:
        members = package.getmembers()
        require(len(members) == manifest['safe_regular_members'] and len({m.name for m in members}) == len(members), 'member count')
        data = {}
        for item in members:
            name = PurePosixPath(item.name)
            require(item.isfile() and not name.is_absolute() and '..' not in name.parts, 'unsafe member')
            content = package.extractfile(item).read()
            require(not content.startswith((b'\x7fELF', b'\0asm')), 'compiled executable')
            require(not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[0-9A-Z]{16}', content), 'private material')
            content.decode('utf-8')
            data[item.name] = content
    inventory = json.loads(data['inventory.json'])['files']
    require(len(inventory) == manifest['inventory_entries'] == len(members) - 1, 'inventory count')
    require({x['path'] for x in inventory} == set(data) - {'inventory.json'}, 'inventory coverage')
    for item in inventory:
        require(len(data[item['path']]) == item['bytes'] and sha(data[item['path']]) == item['sha256'], 'member bytes:' + item['path'])
    current = json.loads(data['evidence/manifest-v4.json'])
    require(sha(data['evidence/manifest-v4.json']) == manifest['review_manifest_sha256'] == 'fc64a55cb7de3f1473a1883d12911366fe26aea745ec424cba4f0ff863258da9', 'review subject')
    for prefix, absolute in [('runtime-v2', '/tmp/uwz-task5c3-runtime-v2'), ('fixture-v1', '/tmp/uwz-task5c3-fixture-v1')]:
        for name, expected in current['trees'][absolute].items():
            require(sha(data['source/' + prefix + '/' + name]) == expected, 'frozen source')
            require(data['source/' + prefix + '/' + name] == data['evidence/' + name], 'owned source')
    result = json.loads(data['evidence/stage-b/result.json'])
    audit = json.loads(data['evidence/stage-b/root-result-audit.json'])
    require(sha(data['evidence/stage-b/result.json']) == manifest['result_sha256'] == audit['result_sha256'], 'actual result')
    require(sha(data['evidence/stage-b/root-result-audit.json']) == manifest['root_result_audit_sha256'], 'host audit')
    require(result['success'] is True and result['error'] is None and audit['status'] == 'PASS' and audit['host_executor'] is True, 'completed owned run')
    require(result['cleanup'] == {'signal': 'SIGTERM', 'exit_code': 0, 'reaped': True, 'forced': False, 'errors': []}, 'cleanup')
    require(sha(data['evidence/stage-b/server.log']) == audit['server_log_sha256'], 'server log')
    require(data['evidence/stage-b/preflight-before.json'] == data['evidence/stage-b/preflight-after.json'], 'pre/post identities')
    require(sha(data['evidence/stage-b/preflight-before.json']) == manifest['pre_post_identity_sha256'], 'preflight hash')
    require(sha(data['evidence/stage-b-authorization.json']) == manifest['authorization_sha256'], 'exact release')
    require(data['reports/component.md'] == (ROOT / 'docs/implement-2-2-0/m2_h2_lifecycle_close_live.md').read_bytes(), 'report bytes')
    prior = json.loads((ROOT / 'docs/implement-2-2-0/evidence/m2_h2_application_error_live/manifest.json').read_text())
    require(manifest['all_verified_case_ids'] == sorted(set(prior['all_verified_case_ids'] + ['disconnect', 'reuse', 'shutdown_active'])), 'case union')
    require(len(manifest['all_verified_case_ids']) == 35 and manifest['planned_unimplemented'] == ['producer_reuse', 'output_pressure_window', 'output_pressure_ready', 'stream_file', 'early_final_order'], 'remaining scope')
    outcome = {'status': 'PASS', 'archive_sha256': manifest['archive_sha256'], 'members': len(members), 'inventory_entries': len(inventory), 'source_versions': 3, 'verified_case_ids': 35, 'remaining_case_ids': 5, 'native_rerun': False}
    path = ROOT / '.superpowers/sdd/h2_streaming_plan/task-5c3-publication-audit.json'
    path.write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps(outcome))


if __name__ == '__main__':
    main()
