"""Package the reviewed lifecycle sources and one completed owned run."""

import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import tarfile


ROOT = Path('/workspaces/uWebZockets')
OWNED = ROOT / '.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close'
WORKSPACE = ROOT / '.superpowers/sdd/h2_streaming_plan'


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def add(members, name, path):
    require(name not in members and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts, 'member path')
    require(path.is_file() and not path.is_symlink(), 'regular source required')
    data = path.read_bytes()
    require(not data.startswith((b'\x7fELF', b'\0asm')), 'compiled executable')
    require(not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[0-9A-Z]{16}', data), 'private material')
    data.decode('utf-8')
    members[name] = data


def main():
    audit = json.loads((OWNED / 'stage-b-root-result-audit.json').read_text())
    require(audit['status'] == 'PASS' and audit['owned_child_absent'] and audit['key_absent'], 'host result audit')
    require(audit['records'] == 32 and audit['accepted'] == 334 and audit['client_data'] == 384, 'actual totals')
    members = {}
    for path in sorted(OWNED.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.suffix in ('.pyc', '.bin'):
            continue
        add(members, 'evidence/' + path.relative_to(OWNED).as_posix(), path)
    for label, location in (
        ('fixture-v1', Path('/tmp/uwz-task5c3-fixture-v1')),
        ('runtime-v1', Path('/tmp/uwz-task5c3-runtime-v1')),
        ('runtime-v2', Path('/tmp/uwz-task5c3-runtime-v2')),
    ):
        for path in sorted(location.iterdir()):
            add(members, 'source/' + label + '/' + path.name, path)
    for pattern in ('task-5c3-*.md', 'task-5c3-*.json', 'task-5c3-*.py', 'task-5c3-*.diff'):
        for path in sorted(WORKSPACE.glob(pattern)):
            add(members, 'reports/' + path.name, path)
    for name in ('task-5-plan.md', 'task-5c-lifecycle-architecture.md'):
        add(members, 'reports/' + name, WORKSPACE / name)
    add(members, 'reports/component.md', ROOT / 'docs/implement-2-2-0/m2_h2_lifecycle_close_live.md')
    for name, location in {
        'h2_client.py': '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py',
        'c-native.zig': '.uwz-work/evidence/h1-transport/r2/c-native.zig',
        'immutable-libxev-input.json': '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json',
        'focused-final-ReleaseSafe.command.json': '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json',
    }.items():
        add(members, 'inputs/' + name, ROOT / location)
    for name in ('publish-h2-lifecycle-close-live.py', 'audit-h2-lifecycle-close-publication.py'):
        add(members, 'publication/' + name, ROOT / '.uwz-work/tools' / name)
    inventory = [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(members.items())]
    members['inventory.json'] = (json.dumps({'scope': 'Current fixture-v1/runtime-v2/manifest-v4 and completed owned run; runtime-v1 and older preparation are history.', 'files': inventory}, indent=2) + '\n').encode()
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name, data in sorted(members.items()):
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mode = 0o644
            archive.addfile(item, io.BytesIO(data))
    output = ROOT / 'docs/implement-2-2-0/evidence/m2_h2_lifecycle_close_live'
    output.mkdir(parents=True, exist_ok=True)
    path = output / 'lifecycle-close-live.tar.gz'
    path.write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
    prior = json.loads((ROOT / 'docs/implement-2-2-0/evidence/m2_h2_application_error_live/manifest.json').read_text())
    cases = ['disconnect', 'reuse', 'shutdown_active']
    proved = sorted(set(prior['all_verified_case_ids'] + cases))
    remaining = [name for name in prior['planned_unimplemented'] if name not in cases]
    require(len(proved) == 35 and len(remaining) == 5 and not set(proved) & set(remaining), 'case inventory')
    manifest = {
        'scope': 'One owned Linux ReleaseSafe TLS1.3/h2 ordinary disconnect/recovery, nine reuse bodies and active installed-handler SIGTERM run; full M2/adoption open.',
        'archive': path.name, 'archive_sha256': digest(path.read_bytes()), 'archive_bytes': path.stat().st_size,
        'safe_regular_members': len(members), 'inventory_entries': len(inventory),
        'source_digest': 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de', 'source_files': 1031,
        'source_checkpoint': '../m2_h2_native_tcp/README.md', 'source_delta_checkpoint': '../m2_h2_metadata_live/README.md',
        'current_source_versions': ['fixture-v1', 'runtime-v2'], 'historical_source_versions': ['runtime-v1'],
        'profile_sha256': '3336d93a5684d88c6a4373d305838ff646b89173abcfb4999a0fd7b1eb951920',
        'binary_sha256': '768598a27e0a22445b9dac740c4c3ce4309351f2124e90590a851b1fa1f80495',
        'review_manifest_sha256': digest((OWNED / 'manifest-v4.json').read_bytes()), 'direct_inputs': 2452, 'trees': 7,
        'authorization_sha256': digest((OWNED / 'stage-b-authorization.json').read_bytes()),
        'result_sha256': audit['result_sha256'], 'root_result_audit_sha256': digest((OWNED / 'stage-b-root-result-audit.json').read_bytes()),
        'pre_post_identity_sha256': audit['pre_post_identity_sha256'],
        'cases_passed': cases, 'all_verified_case_ids': proved, 'planned_unimplemented': remaining,
        'totals': {name: audit[name] for name in ('attempts', 'begin', 'end', 'cancel', 'accepted', 'buffered_middleware')},
        'records': 32, 'untouched_spares': 20, 'client_data_flow_sent': 384,
        'observed_connection_credit_refund': audit['observed_connection_refund'], 'closed_connection_exact_refund_oracle': False,
        'fresh_tls_connections': 4, 'server_log_bytes': 15918, 'exit_status': 0, 'runtime_mode': 'ReleaseSafe',
        'owned_attempts': 1, 'completed_successful_runs': 1, 'automatic_retries': 0,
        'child_exit_zero_reaped': True, 'private_key_removed': True, 'postrun_preflight_identical': True,
        'active_shutdown_tls_outcome': 'tls_eof', 'closing_h2_frames': 0,
        'remaining': ['5 H2 IDs and combined matrix', 'H3/multipart/genuine early data', 'Full quality/platform/compliance/physical gates', 'Maintained publication, production adoption and original milestones'],
    }
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (output / 'README.md').write_text(f'''# Owned HTTP/2 lifecycle-close evidence

The [archive](lifecycle-close-live.tar.gz) retains the actual current/historical
fixture and runtime sources, compile commands/receipts/input maps, offline
regressions and failures, source reviews, Root audits, exact authorization and
execution receipt, actual result/log/public certificate, and independent host
result audit. Its {len(members)} safe regular members have {len(inventory)} inventory
entries. No private key, credential, compiled executable or Python cache is included.

Archive SHA-256: `{manifest['archive_sha256']}` ({manifest['archive_bytes']} bytes).
See [manifest](manifest.json) and [component report](../../m2_h2_lifecycle_close_live.md).

One owned Linux ReleaseSafe run passes strict TLS unwrap/normal EOF followed by
actual peer_closed cancellation and recovery, nine same-connection requests with
72 expired-control checks while later bodies remain active, and active-upload
SIGTERM with actual shutdown cancellation. All32rows/metrics match post-deinit
logs. The active target intentionally changes cancel/active/paused/reason after
signal; other rows remain unchanged. Four owned TLS1.3/h2 handshakes, 12begins,
10ends, 2cancels,334accepted,384clientDATA,zeroerrors/activebindings, exit0/reaped/
keyremoved and no forced cleanup. Buffered middleware count436 derives from
issued requests. Observed connection refund334 is recorded without an exact
refund oracle on departed connections. Active shutdown records TLS EOF and zero
closing H2 frames; only the disconnect case requires successful TLS unwrap.

Current fixture-v1 and runtime-v2 bind to manifest-v4
`{manifest['review_manifest_sha256']}` with2452inputs/7trees. Native Debug and
ReleaseSafe builds remain unchanged. Review caught active shutdown extending
the30-second case budget; the corrected clip preserves case/whole/15-second
grace and independent idle teardown. Raw failing clock tests,14covering passes,
3optimized passes, normal/optimized actual-input mutation rejection/restoration,
initial/scoped reviews and oldruntime/oldmanifests are retained. Preparation's
53ordinary and8optimized adapter checks remain evidence for unchanged modules.

The unchanged1031-file [candidate](../m2_h2_native_tcp/README.md), reviewedC223
override, originalC/sixarchives and [pinned client](../m2_h2_client/README.md) are
the source/tool basis. Complete changed candidate src bytes are in the
[metadata archive](../m2_h2_metadata_live/README.md). Paths/recipes record the
original run; restoring a new native environment requires the recorded sources,
dependencies and fresh validation. This package does not activate candidate
code or unpublished dependency pins.

35H2IDs are proved; five output IDs and the full combined matrix remain.
H3/multipart/genuineearlydata, fullquality/platform/compliance/physical,
provenance/adoption/release and all original milestone requirements remain open.
No performance/RSS/leak/general native-safety claim, automatic retry, native
fault injection or reconstruction of stopped/denied cases is made.
''')
    print(json.dumps({key: manifest[key] for key in ('archive_sha256', 'archive_bytes', 'safe_regular_members', 'inventory_entries', 'result_sha256')}))


if __name__ == '__main__':
    main()
