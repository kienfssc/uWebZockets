# Task5c3 next pass: fixture and actual compilation

Continue SAMEtask/ownership from task-5c3-brief.md. Partial model/threepuretests/
uncompiledprofile are retained, not restarted or accepted as StageA. Root read
the actual report and handling-reports. Reduce the immediate working set to
the ACTUAL configured-App fixture and new Debug/ReleaseSafe compile-only proof.
Driver/observer/finalclosure follow as a separate pass with you before review.
This changes work sequencing, not any original acceptance requirement.

Finish the12tag/32record/twobinding profile for disconnect, its recovery,
reuse_0..8,shutdown_active. Use original exactprofile/independentmetadata/hash/
pause7/ready/terminal/control/status/metrics/postdeinit contracts. Cancellation
reason comes from actual public callback, never manufactured by fixture mode.
Record/pre-signalactive state is exposed normally; after deinit serializer
emits actual terminal rows/metrics, not patched favorable model values.
No globalerror/source/pin/capacity changes or inapplicable app-error behavior.

Freeze native source before actual Debug/RS compilation, reuse sharedcontent
caches/-j2/tmpoutputs, retain exactargv/env/currentinputs/source1031/override93/
fixture beforeafter maps/logs/exit/binaryhashes. Formatting alone isn't build
proof. This intermediate nativefixture proof is not final runtime closure.
Do not repeat unchanged model tests unless changed. Append schema/routes/
commands/rawresults/hash/selfreview/remainingdriverwork to originalreport.

NO native executable/test/constructor/client/socket/cert/live selfcheck,
schedules/fault/FDprobes, previousevidence/product/docs/pin/refs/commit/push/
subagents. You are not alone; all original stop boundaries remain. Finish this
bounded fixture pass or identify a concrete contract/context blocker.
