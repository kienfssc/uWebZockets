# Task5c3 bounded continuation: actual close policies and TLS adapter

Continue SAMEtask/ownership and full task-5c3-brief.md acceptance. Root read
shutdown/disconnect/reuse reports and raw outcomes. This pass completes the
actual raw/wire terminal-policy integration and strict clean-close helper with
inert doubles/codecs only. Retain completed case APIs/models/fixture/builds.
Real process-runner integration and final closure still follow. You are not alone.

Only lifecycle-close/, /tmp/uwz-task5c3-* and original report may change. No
other evidence/common helper/product/docs/pins/refs/commit/push/subagents.
No native executable/test/constructor/socket/cert/realprocess/FD/fault activity
or generic project test invocation. Actual close-helper tests use ordinary
caller-data objects/doubles only, no real SSLSocket/socket construction.

Implement explicit clean_disconnect and owned_shutdown policies in ACTUAL
wire.py/raw_observer.py APIs so case start can register them. Healthy and
public_cancel8/application_failure2/refusal_after_final0/peer_reset8 retain
their existing strict semantics. Before termination, the two new policies
reject primary response HEADERS/DATA/final/end/reset; local close or connection
EOF is never counted as a server cancellation proof. Cases separately require
actual persistent server callback records. Do not allow a new policy to retire
as healthy or silently drop an incomplete primary record.

Connection-finalization APIs must explicitly check intended policy and phase,
registered active primary/at-most8response records, full-frame/trailing-byte
accounting and absence of any successful target response/reset. Do not discard
partial raw headers/payload or bypass framing by swapping parser instances.
Use explicit bounded handoff/state if needed; incomplete trailing frames fail.
No unrelated in-flight healthy response may be hidden by a closing primary.

For disconnect, implement a real callable strict helper that later receives
the actual owned SSLSocket and absolute deadline: set remaining timeout, invoke
PUBLIC unwrap, require success, read ordinary returned socket up to8192 and
require immediate normalEOF, then normal close. Return the exact case evidence
only after all steps succeed. No GOAWAY/RST/linger/shutdown flags/options or
abrupt-close fallback. Error/bytes/timeout/reset propagates and cannot become
success. Resource cleanup on failure must not erase original failure or invent
evidence. The caller still owns process/listener/TLS identity verification.

For active shutdown, finish the actual post-owned-SIGTERM observer, not a model-
only helper. Source paths app657-676/tcp_upload403-416/tcp3212-3289 establish
shutdown cause then cancel IO/TLS teardown/socket close, not a clean TLS alert.
Accept only the documented eof/tls_eof termination phase after signal under the
shared absolute deadline, with no successful target response and no pending
frame. A timeout, early EOF before signal, reset or unclassified exception is
failure. Derive and record the exact bounded closing-control policy from source;
the draft WINDOW_UPDATE-only policy is not automatically accepted. Preserve
actual outcome for future result auditing; never manufacture an alert/code.
No client close before owned signal, and no post-metrics request.

Meaningful pure regressions must exercise the actual changed raw/wire/helper
APIs: legal bounded fragmented closure, wrong phase/local-only retirement,
wrong target/healthy stream, headers/data/reset/GOAWAY after closure or partial
trailing frames, zero/invalid credit, excess bounds, valid strict unwrap+EOF,
unwrap error/timeout/reset/extra bytes and ownership-preserving failure cleanup.
Keep existing observer/credit policies covered where shared modules change and
previous inert import guarantees. Do not rerun unrelated unchanged case suites
or fixture compilation. Keep all tools inert and use explicit proof failures;
Python optimization must not disable checks. Append API/source justification,
exact commands/raw failures/results/hashes/self-review/remaining adapter work
to task-5c3-report.md. Scoped DONE only when actual policies/helper can be used
by real runner; no native behavior/current closure/StageA completion claim yet.
