# Task 5c3 incomplete preparation

Status: INCOMPLETE. The bounded Stage A closure is not prepared for review or execution. No native executable, test, constructor, server, client, socket, certificate, or live selfcheck ran. The three files under `integration-owned/lifecycle-close/` are working drafts, not frozen or bound evidence. No product source, pins, prior evidence or common helpers were edited.

`expectations.py` independently describes the 32 identities, selected-subset rows, planned shutdown before/after transitions, and derived reuse stale-control counts. `test_expectations.py` exercises full totals, transitions, hash/identity swaps and wrong terminal causes. The draft fixture copies task5c2's profile, changes the 12 usable tags and pause behavior, and removes the three application-error modes. It has not been compiled or integrated with a driver; no claim of correctness is made. In particular the pure model does not establish server behavior, observer correctness, client closure, signal ordering, or stale-control nonmutation in a running fixture.

Commands and raw results:

```
cd .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close
/home/codespace/.python/current/bin/python3 -B -S -m unittest test_expectations
```

First execution, exit 1: `ModuleNotFoundError: No module named 'expectations'`; `Ran 1 test`, `FAILED (errors=1)`. After adding the draft expectation model, exit 0:

```
...
----------------------------------------------------------------------
Ran 3 tests in 0.002s

OK
```

`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/profile.zig` exited 0 with no output. This is formatting only, not compilation. The initial attempt to modify the copied read-only fixture failed with `PermissionError`; after setting its owner write bit the draft edit succeeded.

Current hashes (unfrozen):

```
85dde796d9789b8b47ae50a8ec7ecaa1efb7ff74a16802d550c248ef32b929cf  expectations.py
c508d4f3df01854a3005702965a94b7b195799f41d5df1e0901722de586ef8bf  profile.zig
3967e6ab6f9fc0b760c096ac2e6f7aa9359c8dc1c563ee6216db10ea96ca3e68  test_expectations.py
```

Source context reviewed: the frozen `tcp.zig` maps `SSL_ERROR_ZERO_RETURN` to `peer_closed` before close-after-flush; `app.zig` begins shutdown by closing active connections with `shutdown`. Those mappings do not establish a live outcome. `graphify query "H2 streaming lifecycle disconnect reuse shutdown architecture"` and a focused shutdown query exited 0. Graph update was not run because its output is outside assigned ownership.

Remaining required work: finish and independently review fixture semantics; implement and test explicit disconnect and shutdown observer policies, strict clean unwrap/normal EOF and replacement recovery, nine same-connection requests and stale-control nonmutation, active client ownership until SIGTERM and independent pre/post assertions; preserve previous 20 offline tests and inert checker regression; freeze native fixture source and execute actual compile-only Debug and ReleaseSafe builds with retained inventories, inputs, logs, and binaries; freeze runtime separately; bind the actual builds and tools; test current closure acceptance, actual-input mutation rejection and restoration; capture AST, formatting, inventories and self-review. All ordinary live tests, later matrix milestones and project gates remain open. No current manifest or reviewable Stage A closure exists.

## Fixture and compile-only pass

This section supersedes the earlier description of the fixture as uncompiled. The bounded fixture pass is complete; the complete Stage A and runtime closure remain incomplete and are not authorized for execution or independent review yet.

`profile.zig` uses the original configured `Server.preset(...).build_https` profile, eight connections, unchanged native stream and receive capacities, two caller-owned sink slots, and 32 fixed records. The first 12 identities are `disconnect`, `disconnect_recovery`, `reuse_0` through `reuse_8`, and `shutdown_active`; the 20 spare tags are refused by middleware/begin and remain observable through status. Each accepted tag has separate literal path, query, target and `x-case` expectations, plus POST, capture and Content-Length 32 checks. Metadata is checked at middleware, begin and successful end. The two interrupted tags pause after accepting at most the first seven bytes without depending on callback span; the reuse and recovery tags remain ready. The actual public cancellation callback records its supplied reason and clears the slot. There is no application-error mode or active cancellation route. Saved public control values remain in persistent records, and the control route only accepts expired resume/cancel operations on inactive records, counting successful expiry checks. Hash state and counters are owned by stable records, not by reusable slots.

Routes are quota-one POST `/limit/:tag`, GET `/health`, POST `/echo`, GET `/status/:tag`, GET `/metrics`, and GET `/control/:op/:tag`. Status fields are tag, middleware, attempts, begin, end, cancel, failure, end_errors, chunk_errors, invalid_progress, accepted, sha256, chunks, max_span, active, paused, reason, metadata_middleware, metadata_begin, metadata_end, stale_resume, stale_cancel and errors. Metrics contain the aggregate corresponding counts, active, errors, buffered_middleware, slot0_active and slot1_active. The error counters retained from the previous profile explicitly expose zero invariants. After `run` and deferred public deinit, actual records and totals are serialized in `H2_RECORD` and `H2_DEINIT` logs; no expected values are substituted.

Frozen source `/tmp/uwz-task5c3-fixture-v1/profile.zig` and the retained owned copy both have SHA-256 `3336d93a5684d88c6a4373d305838ff646b89173abcfb4999a0fd7b1eb951920`. The snapshot was made read-only before either build. The adapted, guarded compile tool has SHA-256 `f86e05471742dc7ed0787d7a3067a444f04b3097f33cd3c47c42505b1b6a7fd9`. It retains the reviewed source, binding and six static archive inputs, uses the shared content-addressed caches and `-j2`, and writes complete argv/environment and before/after input maps into each receipt.

Exact commands, both exit 0:

```
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/compile_fixture.py /tmp/uwz-task5c3-fixture-v1 debug fixture-debug-v1
mode: debug exit: 0 stdout bytes: 0 stderr bytes: 0 unchanged: True binary sha256: 99750d37a7445550014ff4303818fc4ea66ac72a1aea46b2be165f411e0cc7e3
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/compile_fixture.py /tmp/uwz-task5c3-fixture-v1 release fixture-release-v1
mode: release exit: 0 stdout bytes: 0 stderr bytes: 0 unchanged: True binary sha256: 768598a27e0a22445b9dac740c4c3ce4309351f2124e90590a851b1fa1f80495
```

Modes are Debug and ReleaseSafe respectively. Both receipts report 13 direct inputs, 1,031 candidate files, 93 override files, and one fixture source; all before/after identities match. Receipt SHA-256 values are `bd86fecce08a88db5db17b3e62ae3f4a1463c5c05cece8e0d3fac6a07c50cf37` and `88998c09ce54cf4137a647ec11cc8cefde4747527132bd3b111f022f82431897`. Empty compiler stdout/stderr files and the receipts are retained in the owned directory, along with copies of the exact built binaries whose hashes match the build outputs. Neither binary was executed. `zig fmt --check` on the fixture exited 0 with no output.

Self-review: the chunk callback hashes only accepted bytes, uses fixed storage, and pauses the two interrupted records at seven even if a larger span is supplied. Successful end checks the fixed 32-byte digest and independently enumerated metadata before releasing the slot and writing a bounded record. Cancellation stores the callback cause; shutdown does not synthesize a record. The persistent records retain copied public controls rather than callback-local request, view, response or chunk pointers. Serializing after the scoped server deinit preserves the actual transition. This is source and compilation evidence only; no timing, native behavior, lifecycle cause, slot reuse, socket close, or performance result is measured. The independently modeled expectations and their earlier three pure tests were unchanged and not rerun.

Still required: the strict clean-disconnect and owned-shutdown observer and driver, replacement recovery and all nine reuse requests with stale-control checks, independent pre/post expectation comparisons and bounded termination parsing, meaningful pure codec/double regressions including prior coverage, runtime freeze and current closure with actual-input mutation rejection/restoration, complete AST/inert checks, final self-review and independent review. Stage B requires separate exact Root authorization. No full project or protocol gate is claimed.

## Driver pass in progress: not ready

The actual driver, observer integration and closure remain unfinished; do not execute the copied task5c2 `run_live.py` as task5c3. It still has task5c2 selections and behavior. No runtime freeze, current manifest, acceptance/mutation/restoration proof, native execution or new fixture build occurred in this pass.

The expectation model now checks actual fixture `chunks` and `max_span` fields instead of rejecting them, including the 8192 bound. A behavioral red was recorded for `/home/codespace/.python/current/bin/python3 -B -S -m unittest test_expectations.ExpectationTests.test_actual_chunk_evidence_is_bounded`: exit 1, `ValueError: record expectations differ`; after the fix the full expectation suite had four tests passing. `lifecycle_cases.expired_pair` is a draft pure API which checks the old record changes only its applicable stale counter, and the active record remains exactly unchanged. Against an intentionally incomplete initial implementation, `/home/codespace/.python/current/bin/python3 -B -S -m unittest test_lifecycle_cases` exited 1, `Ran 2 tests`, `FAILED (failures=2)`, because it failed to reject mutations. After the fix:

```
/home/codespace/.python/current/bin/python3 -B -S -m unittest test_lifecycle_cases test_expectations
......
----------------------------------------------------------------------
Ran 6 tests in 0.004s

OK
```

A draft independent `close_observer.py` rejects target DATA/HEADERS, reset, GOAWAY, wrong stream, zero credit, partial trailing frame, premature EOF and timeout. It permits bounded fragmented WINDOW_UPDATE on the active stream or connection after the caller establishes signal ordering; `/home/codespace/.python/current/bin/python3 -B -S -m unittest test_close_observer` exited 0, `Ran 2 tests in 0.000s`, `OK`. This module is not wired into the actual driver and its accepted frame policy requires source review before use. `tcp_upload.zig:403` and `tcp.zig:3212` show shutdown claims the cause and cancels active I/O; they do not promise a TLS alert. These pure checks prove no server behavior.

Working hashes, not frozen or bound:

```
78c68579a93da9302cb0ede5a6d401f414144f0cc3ba2d1e1ae726b41d70b996  expectations.py
3ea2f6e1be43a3cb074e87daf3ef75260a78fa53e306b3a75bed528707614bac  test_expectations.py
30fa0790b204959898108110ae1c1803f4779ee524d67ecda9d71ac48f3e402a  lifecycle_cases.py
f4e9bea0f90946e338824425e086b646702b7241d445b19bdf931a3e80494dd2  test_lifecycle_cases.py
4139f5be33063286ff8742ea0e82e6f586a53d2e57101a943015518a18907a24  close_observer.py
ef9e7e1a13458311b74e791635e27579fdb6c03a6c833f5f1c2b92d152b0c220  test_close_observer.py
```

Remaining work includes the actual disconnect/reuse/shutdown runner and its bounded observations, prior regression and inert import integration, validation of post-signal frame policy, offline identity/AST checks, frozen runtime/current closure and real mutation rejection/restoration. The current partial code is not a substitute for any of those gates. No concrete production defect or source contract blocker has been established.

## Bounded reuse orchestration pass

This pass completes the callable reuse case and inert API-double checks only. It does not complete Stage A, integrate the real runner, validate live behavior, or change/rebuild the frozen fixture. No native executable, socket, certificate, constructor, or live runner was invoked.

`lifecycle_cases.reuse(api)` uses a single caller-provided connection through five explicit functions: `start(tag, metadata, 'healthy') -> stream`, `send(stream, length, end_stream)`, `status(tag) -> actual_record`, `control(operation, tag) -> response_body`, and `finish(stream) -> {'status': 200, 'record': actual_record}`. The adapter must use its independently validated P32 and per-stream upload offset; start must send exactly the supplied method/path/query/target/x-case/content-length metadata, and finish must consume the complete healthy response/framing and validate its middleware header before returning the parsed record. The function supplies nine independent literal metadata tuples and requires first 7 bytes without EOF; an actual full-schema active/ready/7/H7/B1/E0/C0 record is checked before further traffic.

For each later request, every earlier tag receives resume and cancel. The case checks the independent expected old count before each operation, requires the actual `BodyControlExpired` body, then compares all old and current fields around that individual operation, allowing only the requested old stale counter increment. Only afterward does it send the remaining 25 bytes with EOF. It checks HTTP status 200 and the full actual terminal record, including 32/H32/B1/E1/C0, metadata and bounded chunk fields. Finally it independently checks each tag's derived 8-j stale counts. The return is bounded to nine admissions, 36 checks for each operation, nine final count pairs, and a SHA-256 over length-prefixed canonical barrier, complete, and before/after control observations. It does not retain 72 control reply bodies, read native allocation indices or claim runtime slot identity.

The initial actual case stub was exercised with `/home/codespace/.python/current/bin/python3 -B -S -m unittest test_lifecycle_cases.ReuseTests.test_nine_sequential_requests_and_ordered_controls`: exit 1, `ValueError: reuse orchestration is not implemented`, `Ran 1 test`, `FAILED (errors=1)`. After implementation an intermediate run failed the active barrier because the double incorrectly initialized reuse_0 with its final stale counts; correcting the double to zero on admission fixed that test data. The final command, from `integration-owned/lifecycle-close`, exited 0:

```
/home/codespace/.python/current/bin/python3 -B -S -m unittest test_lifecycle_cases
....
----------------------------------------------------------------------
Ran 4 tests in 0.021s

OK
```

The actual case double covers the legal nine-request sequence and checks the exact order of all 72 control operations and both DATA sends. It rejects a wrong expiry response, paused current barrier, old/current mutation, wrong final identity, digest, terminal and HTTP status. The double asserts no 25-byte EOF send occurs until both controls have been checked for every earlier tag. Two unchanged small helper tests also pass. Python AST parsing of the two changed files exited 0, `AST parsed: 2`.

Working hashes, not yet frozen or closure-bound:

```
8a191d34cc36506e2e1b67f229a3c553c76cd074349dfd0dd4b64c0da56d3d16  lifecycle_cases.py
9e9691da3011b5d5e9d980ef4dc0fdc0c02add4b0089c054e6ee6284de21db1e  test_lifecycle_cases.py
```

Self-review: no borrowed response state or per-operation reply body is retained by the case; one event at a time is hashed under a 4096-byte bound. Expected final counts come from the independent expectation model, not observed rows. Current-record equality includes chunk evidence across each operation. The API is not yet connected to `run_live.py`, so its adapter obligations and actual HTTP framing are unverified. Disconnect, active shutdown, process ownership, observer integration, remaining pure regressions, runtime freeze and current closure remain open; the previous compiled binaries are unchanged.

## Bounded disconnect orchestration pass

This pass completes `lifecycle_cases.disconnect(api, connection)` and inert API-double checks only. The frozen fixture and Debug/ReleaseSafe builds were unchanged. No native executable, test, socket, certificate, constructor, runner, or process was invoked. Complete Stage A remains open.

The case uses `start(connection, tag, metadata, policy) -> stream`, `send(connection, stream, length, end_stream)`, `status(connection, tag) -> actual_record`, `close(connection) -> evidence`, `replacement() -> evidence`, `control(connection, operation, tag) -> response_body`, and `finish(connection, stream) -> {'status': 200, 'record': actual_record}`. `start` receives distinct literal metadata; its primary policy is explicitly `clean_disconnect`, and the recovery is `healthy`. The adapter must implement that named observer policy and consume complete status and recovery response framing, enforce the middleware header and 200 status, use P32 with per-stream offsets, and preserve the same owned original connection until strict close. The close adapter must use public `SSLSocket.unwrap()` within the remaining absolute deadline, require success and a normal TCP EOF without application bytes, and normally close the returned socket. It reports exactly `{'method': 'ssl_unwrap', 'tls_shutdown': 'success', 'tcp_eof': True, 'trailing_bytes': 0, 'close': 'normal'}`; any other evidence fails. The replacement adapter must establish a fresh owned TLS 1.3/h2 connection with verified listener and certificate identity and report its distinct connection plus `owned=True`, `tls='TLSv1.3'`, `alpn='h2'`.

After sending all 32 bytes without EOF, the case checks the full actual 7/H7/active-paused/B1/E0/C0 same-connection status before close. It does not equate local close with server cancellation: only a replacement-connection status proving the persistent 7/H7/B1/E0/C1/peer_closed/inactive record is accepted. Both old controls are checked before recovery, then again while recovery is active and ready at 7/H7. For each call, the full old record is compared around the call with only the applicable counter allowed to change; during recovery the full active record must also be unchanged. The final 25+EOF is sent only afterward. The complete healthy recovery record must show 32/H32/B1/E1/C0, all metadata and bounded chunk evidence, and the final primary record must show stale counts 2/2. A bounded SHA-256 commits to distinct original-preclose and replacement-postclose observations, strict-close evidence, all before/after stale checks, and recovery records. The result labels original versus replacement observation and does not claim connection-credit refund or a native pool index.

Initial actual-case test against the deliberately incomplete case stub exited 1 with `ValueError: disconnect orchestration is not implemented`, `Ran 1 test`, `FAILED (errors=1)`. The later ordering-test expansion initially failed because Python `list.index` returned the first of two equal control events; the test was corrected to use event positions rather than changing case behavior. Final command from `integration-owned/lifecycle-close`, exit 0:

```
/home/codespace/.python/current/bin/python3 -B -S -m unittest test_disconnect_case test_lifecycle_cases.ReuseTests
....
----------------------------------------------------------------------
Ran 4 tests in 0.019s

OK
```

The actual-case doubles check legal close/replacement/recovery ordering and reject wrong preclose pause, hash or identity; TLS timeout or reset, missing EOF, extra bytes or abrupt close; local-only/missing server proof or wrong server cause; wrong expiry response, old/current mutation; same or unowned replacement; paused recovery, and wrong recovery identity, hash, terminal or status. The double requires the preclose status immediately before close, replacement immediately after close, and both active-recovery controls before the suffix. The two reuse tests were rerun because their shared module changed. AST parse of the two changed/new files exited 0, `AST parsed: 2`.

Working hashes, not frozen or closure-bound:

```
0aabf810ceb0b3f0f68372624855883dfbdcd9c3a10cb77036441798bae73610  lifecycle_cases.py
133b569fa77e0906561fe48335cefca1738dee4e9c49206a9338fa38085db911  test_disconnect_case.py
```

Self-review: neither the raw closed connection nor actual callback pointers are retained by the case. No response body history is accumulated; each checked observation is included in bounded length-prefixed evidence. Strict local-close evidence and actual persistent server cause are separate requirements. The `clean_disconnect` policy, strict adapter and connection identity checks are not yet implemented in the actual runner/observer, so no real socket or TLS behavior is proven. Active shutdown, process orchestration, actual client integration and limits, prior regression coverage, runtime freeze and current closure remain open, as do independent review and separate runtime authorization.

## Bounded active-shutdown orchestration pass

This pass completes `shutdown_active(api, connection, selection)` and `verify_final(records, metrics, selection, phase, buffered_count)` with inert doubles. Full Stage A, actual runner/observer integration, current closure and future native authorization remain open. No native executable/test, socket, certificate, constructor, real process, FD or fault activity ran; frozen fixture and builds were unchanged.

The case rejects unsupported, duplicate, or non-last shutdown selection and requires independently reported completed prior requests and an open owned client. It starts the literal POST `/limit/shutdown_active?case=shutdown_active` with `x-case: shutdown_active`, Content-Length 32 and the named `owned_shutdown` policy; sends all P32 without EOF; and validates the actual same-connection active/paused 7/H7/B1/E0/C0 barrier. It then reads every one of 32 actual records and metrics LAST. The verifier regenerates all expected records from selected cases and phase, validates full schema and bounded chunk evidence, derives aggregate arithmetic from those expected rows, and compares buffered middleware to the adapter's independent issued-request count. It accepts either sink slot for the one active binding without claiming an index. Every subsequent API call is a non-request operation.

API contract: `preconditions(connection)` proves completed earlier cases/client open; `start(connection, tag, metadata, 'owned_shutdown')`, `send(connection, stream, 32, False)`, `status(connection, tag)` and `metrics(connection)` are normal complete-framing request operations; `request_count()` independently counts buffered requests including the just-completed metrics request. `graceful_deadline()` creates one absolute deadline; `signal(connection, deadline)` verifies exact child PID/start/nonce and installed signal watcher and reports SIGTERM plus client still open; `termination(connection, deadline)` consumes bounded actual TLS/H2 termination under an explicit post-signal policy and reports phase, EOF/TLS EOF outcome, no successful primary response, valid frames and no trailing bytes; `wait(deadline)` checks successful run/deinit markers, exit 0, exact reaping, key removal and no force; `post(deadline)` reads actual bounded post-deinit records and metrics. All use the same deadline. The adapter must independently enforce identities, listener, clock/deadline, framing, bounded output and source-backed closing policy; this pure case cannot establish them. Process evidence and termination alone do not replace the actual server cancellation row.

After signal, the case derives new expected rows independently for `after` and requires shutdown target 7/H7/B1/E0/C1/shutdown/inactive/not paused and zero aggregate active. All other semantic fields, unused spares and metrics are independently checked; chunk count and maximum-span diagnostics are compared across snapshots because no subsequent body callback is expected. It returns bounded actual before/after 32-row snapshots, metrics, signal, actual termination and process evidence. No request is issued after the metrics call, and no arbitrary alert or reset is accepted by this case.

Full-selection expected totals are before `(attempts, begin, end, cancel, accepted, active) = (12, 12, 10, 1, 334, 1)` and after `(12, 12, 10, 2, 334, 0)`. Inert doubles also check shutdown alone `(1,1,0,0,7,1)` to `(1,1,0,1,7,0)`, disconnect plus shutdown `(3,3,1,1,46,1)` to `(3,3,1,2,46,0)`, and reuse plus shutdown `(10,10,9,0,295,1)` to `(10,10,9,1,295,0)`. These are planned expectations, not measurements.

Initial behavioral red for the callable case was the unimplemented-case error, exit 1: `Ran 1 test`, `FAILED (errors=3)` across the first three legal selections. The final command, from `integration-owned/lifecycle-close`, exited 0:

```
/home/codespace/.python/current/bin/python3 -B -S -m unittest test_shutdown_case test_disconnect_case test_lifecycle_cases.ReuseTests test_expectations
...........
----------------------------------------------------------------------
Ran 11 tests in 0.051s

OK
```

The doubles reject wrong barrier or type, premature closure before signal, incomplete prior cases, unowned child or missing watcher, wrong untouched spare or other semantic row, incorrect metrics, wrong cause/hash/identity, missing or duplicate cancel, changed chunk diagnostics, unexpected primary response, timeout, force, failed run/deinit, nonzero exit, missing reap or key proof. They enforce one metrics-last boundary, the same connection at signal, and one shared deadline through signal, termination, wait and post. The disconnect, reuse and expectation suites were rerun because their shared modules changed. Expected scalar types now reject JSON boolean/integer substitution. AST parsing of the three changed files exited 0, `AST parsed: 3`.

Working hashes, not frozen or closure-bound:

```
602c640b917f520f43570a098d4a583925b7fc0f104ee59f13636a33334c9504  lifecycle_cases.py
33ea092f6e5f67b8cfb8fc61dcab425228f284bf77880b0c96ff537299af8324  expectations.py
f0b59c0137632a4271ec680d4ab2ce71d6697dd2c674c1da15a768a5fe562854  test_shutdown_case.py
```

Self-review: before and after targets come from separate model calls, not from copying the actual pre-signal snapshot; only known stable chunk diagnostics are compared directly. Actual rows remain bounded to 32 per snapshot and request accounting is supplied separately. `app.zig:657-676`, `tcp_upload.zig:403-416` and `tcp.zig:3212-3289` establish shutdown-cause ordering and eventual socket close, not a promised TLS alert. The actual post-signal parser and process adapter still require implementation and source review; the `owned_shutdown` policy is not yet integrated. No live result or verified gate is claimed.

## Bounded actual observer and close-helper pass

The actual `raw_observer.py` and `wire.py` now register `clean_disconnect` and `owned_shutdown`. They reject target HEADERS/DATA and incoming resets, and do not allow these policies through ordinary stream completion/retirement. `wire.begin_termination(records, raw, stream, policy, phase)` requires exactly the named unfinished target and no other in-flight response, full-frame boundary and phase `pre_unwrap` for clean disconnect or `post_signal` for owned shutdown. `wire.finish_termination(..., outcome)` independently checks target and phase, strict clean-close evidence or an actual EOF/TLS EOF outcome, no pending header/payload and no other response, then explicitly finalizes the same raw state. Its result is labeled `local_transport_only`; neither local termination nor record removal claims a server cancellation. The earlier standalone `close_observer.py` remains historical draft material and is not the integrated policy.

In the post-signal phase the same parser permits only complete four-byte WINDOW_UPDATE frames with flags zero, positive 31-bit increments, and stream ID zero or the active target. It rejects GOAWAY, RST, HEADERS, DATA, other-stream credit and incomplete trailing bytes. It retains frame/byte counts and actual connection/target credit totals for the later independent ledger rather than imposing an exact refund. Reads are bounded at 8192 bytes, frames at 16384 generally, closing bytes at 65536 and closing frames at 4096. This conservative policy follows frozen `server.zig:1723-1755` and `2116-2124`, which emit connection and stream credit for received body data; the active-shutdown connection carries DATA only on its target. `app.zig:657-676`, `tcp_upload.zig:403-416` and `tcp.zig:3212-3289` claim the shutdown cause before canceling I/O and closing the socket; they do not promise a TLS close alert. The observer is deliberately strict about any other pending control traffic and retains a failure rather than widening accepted causes.

`strict_close.unwrap_eof(tls, deadline, clock)` sets the remaining absolute timeout, calls public `unwrap()`, sets the remaining timeout on the returned ordinary socket, reads at most 8192 bytes and requires immediate `b''`, then normally closes it and only then returns the exact clean-disconnect evidence. On unwrap failure the original TLS object stays caller-owned. On subsequent read/deadline failure it attempts to close the now-owned plain socket; cleanup failure is attached to the original exception and never converts failure to success. No GOAWAY, reset, shutdown flags, linger, or socket options are used. `strict_close.observe_shutdown(tls, protocol, records, raw, trace, stream, signal, deadline, clock)` requires exact owned/post-signal/open-client evidence, begins termination on the actual existing parser, reads bounded spans under the same deadline, processes frames through actual `wire.accept`, accepts only normal EOF or `ssl.SSLEOFError`, and explicitly finishes. It returns the exact case evidence plus the actual bounded raw frame/credit observation. Timeout, reset, other exceptions, target response, partial frame and invalid signal propagate or fail. Later runner integration must check actual process identity and signal evidence, apply ledger accounting to returned credits, and retain observed closure; these helpers do not perform process ownership checks themselves.

Behavioral reds against the previous actual observer and initial helper: the command selecting fragmented shutdown and clean unwrap exited 1 with `ValueError: invalid terminal policy` and `ValueError: strict close is not implemented`, `Ran 2 tests`, `FAILED (errors=2)`. A second actual-path red for `test_actual_shutdown_observer_fragmented_then_tls_eof` exited 1 with `ValueError: shutdown observation is not implemented`, `Ran 1 test`, `FAILED (errors=1)`. Final commands from `integration-owned/lifecycle-close`, both exit 0:

```
env PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S -m unittest test_close_paths test_observer test_credit_case test_listener
................................
----------------------------------------------------------------------
Ran 32 tests in 0.034s

OK
env PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S -O -m unittest test_close_paths
............
----------------------------------------------------------------------
Ran 12 tests in 0.045s

OK
```

The codec/double checks exercise fragmented credit and TLS EOF, normal EOF, early phase and in-flight healthy response, invalid target, headers/data/reset/GOAWAY, zero/reserved/other-stream credit, frame and read bounds, partial tails, invalid close outcome, operation after finalization, public unwrap plus ordinary EOF, exception identity, timeout/reset/extra bytes, deadline and failed cleanup. Inert import checks trap attempted socket construction, process launch and file writes for all three changed modules. The existing observer/credit/listener regressions were rerun because their shared observer changed. Python `-O` results demonstrate checks do not depend on asserts. AST parsing of all four changed/new files exited 0, `AST parsed: 4`.

Working hashes, not frozen or closure-bound:

```
05e6565ab4939843d94e1c39df21d8ab85942b76cd237bcb116285f01cc049a7  raw_observer.py
c11c54602b5e46bd7dadfdeaa4a330b1b8a4661ebe4ee2709e5460e5d438cb5a  wire.py
3e3dd20197f2d07e2c44afba0ef0deddad100012c8b33c9d116b8798b2e29866  strict_close.py
a4ede50076ab77486b9aab3555bb398b092cd5865b739dc67a1d0c41962d697d  test_close_paths.py
```

Self-review: new termination cannot bypass existing parser state, silently retire as healthy, discard a partial frame or hide another response; explicit transport evidence does not stand in for the server callback. Legacy terminal policies and their exact codes remain unchanged. The actual runner/ownership, accounting adapter and full current closure still need integration and independent review. No native executable, socket, certificate, constructor, real process or fault probe ran; Stage A remains incomplete.

## Bounded runner-integration pass

The runner is now wired in source to actual `lifecycle_cases.disconnect`, `reuse`, and `shutdown_active`, the independent expectation verifier, the actual raw/wire policies, `strict_close`, and the flow ledger through `runner_adapter.py`. Its supported default selection is `disconnect reuse shutdown_active`; unsupported or duplicate cases and a non-last shutdown are rejected. It is still unbound to a current reviewed manifest. Neither `run_live.py` nor any native executable, socket, certificate, constructor, real process, FD probe or fault path was invoked in this pass. The full Stage A closure and independent review remain open.

The adapter owns the concrete request bounds and state: literal case metadata validation, per-stream P32 offset, 8192-byte DATA limit, actual status/control bodies, full healthy response decoding, independent buffered-request count, and sealing after metrics. It checks actual 200 response headers rather than inventing a successful status. It routes disconnect through the same raw parser's explicit close boundary, the public unwrap/normal-EOF helper, and explicit parser finalization. The replacement uses a newly verified TLS connection object, allowing OS descriptor reuse without equating TLS connections. The case result now retains bounded actual preclose, replacement postclose, active recovery and final recovery records as well as the observation digest. Reuse calls the existing case function with one connection, and shutdown calls the existing case function with a fresh connection and its real process adapter. The shutdown adapter feeds actual post-signal connection and stream credit into the independent ledger once and retains the observed close summary.

The runner retains PID/start/listener/nonce/certificate-before-health guards, TLS 1.3/h2 checks, ready 15 seconds, case 30 seconds, whole run 900 seconds, and one shared graceful 15-second deadline for signal/termination/wait/collector/post observations. Full selection establishes four fresh verified handshakes; selected subsets use the needed connections. All 32 records and metrics are checked against independently generated expectations; the no-active-shutdown selection performs separate idle final snapshot, normal owned SIGTERM and post-deinit verification. A bounded flow digest and count replace per-receive snapshot retention. It independently checks client DATA totals derived from selection: 64 disconnect, 288 reuse, 32 shutdown, or 384 for full selection. Actual closed-connection refunds are retained observations, not required exact values. Continuous child output remains capped at 65536 bytes; failures retain stage, filename and traceback, and forced cleanup fails the result.

The flow ledger retains at most eight active stream entries and nine fixed retired credit entries so nine completed reuse uploads can be followed by late stream credit without losing accounting. Retired entries still enforce per-stream refund not greater than sent; new stream IDs cannot alias them. This is runner-owned accounting storage, not an increase to the eight response-record or production slot bounds. The actual runner imports neither copied historical `cases.py` nor the superseded standalone `close_observer.py`; the former remains test support for the prior credit regression and both remain historical unfrozen artifacts until the closure pass.

Final commands from `integration-owned/lifecycle-close`, exit 0:

```
env PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S -m unittest test_runner_adapter test_lifecycle_cases test_disconnect_case test_shutdown_case test_expectations test_close_paths test_observer test_credit_case test_listener
.....................................................
----------------------------------------------------------------------
Ran 53 tests in 0.194s

OK
env PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S -O -m unittest test_runner_adapter
........
----------------------------------------------------------------------
Ran 8 tests in 0.029s

OK
```

The inert adapter tests run the actual reuse case across nine fake streams, independently check 378 buffered control/status requests, prove the 7+25 payload offsets and 288 sent bytes, exercise late retired-stream/connection credit, call the actual strict close and post-signal helpers with caller-data doubles on the same parser, and test signal-open state, request sealing, unsupported order, expired deadline, wrong owned identity and cleanup continuing after a client failure. Other shared case, observer, prior credit and ownership tests were rerun because shared modules changed. Import tests also trap socket construction, process launch and file writes for the runner and adapter. AST parsing of the six changed/new sources exited 0, `AST parsed: 6`. These checks do not invoke the real runner or establish native lifecycle behavior.

Working hashes, not frozen or closure-bound:

```
3053be5dd3a32f497058dad2eccf3742d7a3a05140127dc4d0bae5b9de348277  run_live.py
d053e1eff83cb0384c5186988c18b21c2b7e5a2e0e75817abb3b3c3f45d88b01  runner_adapter.py
6530aaed4837b02da784dbf43b09cb8e7614dcb3af319efa5bcbd15416531770  flow_ledger.py
e680eafa5791e7e0521e508e236098d8a3ef167dc4c3daa473b71f085e0772d9  lifecycle_cases.py
373331d1df32fa1f0d083174fe5d50f4201a50c3667da0e35fafe3e97cb58ecf  test_runner_adapter.py
106934e5e9d42a04e8c1da10201611da64cadc6165319611bd91adb994b14db3  test_close_paths.py
```

Self-review: request issuance stops at metrics; the original active TLS client remains open until the guarded signal; termination cannot be mistaken for the independently checked callback cause; only bounded actual data is retained. This pass has not proven the live runner's integration, frozen these runtime inputs, validated a current manifest, demonstrated mutation rejection/restoration, or received independent review. Those gates and explicit future native authorization remain required.

## Final Stage A runtime freeze and current closure

Status: **ready for independent Stage A review**, not authorized for live execution. This section supersedes the earlier incomplete status for the bounded preparation only. The real runner was never invoked; no native executable/test, constructor, socket, certificate, TLS context, real process, FD or fault activity occurred. Independent source review and a separate exact Root release remain prerequisites to any ordinary owned attempt. No native behavior, product adoption, h1spec/Autobahn/sanitizer/full local matrix, performance measurement, or completion of the remaining producer/file/output/full combined milestones is claimed.

The current manifest is `.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/manifest-v3.json`, SHA-256 `4f0a3b803912c84f340b954c00d23eb1e3cb07ab9369f3de9281a29c9f628bc1`. It binds **2,456 direct inputs** and seven complete tree inventories: Zig library 19,542 files; pinned client 42; candidate 1,031; reviewed libxev override 93; zslay 14; native fixture snapshot 1; actual runtime snapshot 9. It binds the actual two build receipts and binaries and their persistent copies, original native C/module and six archives, compiler, source/override/fixture maps, current Python runtime and owned source copies, preparation and check tools, current tests, the unchanged helper, interpreter/stdlib, loaders, dependency objects, OpenSSL/config, and future environment. It does not claim the later Python sources were native compile dependencies. The prior reviewed application-error manifest and both intermediate preparation manifests are bound as actual preparation inputs; previous evidence was read only.

Native fixture snapshot `/tmp/uwz-task5c3-fixture-v1/profile.zig` and persistent `profile.zig`: `3336d93a5684d88c6a4373d305838ff646b89173abcfb4999a0fd7b1eb951920`. Actual Debug binary `99750d37a7445550014ff4303818fc4ea66ac72a1aea46b2be165f411e0cc7e3`, receipt `bd86fecce08a88db5db17b3e62ae3f4a1463c5c05cece8e0d3fac6a07c50cf37`; actual ReleaseSafe binary `768598a27e0a22445b9dac740c4c3ce4309351f2124e90590a851b1fa1f80495`, receipt `88998c09ce54cf4137a647ec11cc8cefde4747527132bd3b111f022f82431897`. Both original compile-only receipts contain 13 direct inputs, unchanged 1,031/93/1 source maps, exact argv/environment, empty compiler output and exit 0. Neither compilation nor a binary was rerun. Candidate `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`, override `c223bd886c6a51d2cd60def39dd9a68d701fea73`, pinned client digest `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`, and helper SHA-256 `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00` remain the actual input cohort. Root HEAD `f2ea5e3` changed docs only after fixture compilation; the frozen candidate remains the build source.

The separate read-only runtime snapshot `/tmp/uwz-task5c3-runtime-v1` contains exactly nine actual runtime modules (directory mode 555, files 444), with owned persistent source copies bound separately:

```
33ea092f6e5f67b8cfb8fc61dcab425228f284bf77880b0c96ff537299af8324  expectations.py
6530aaed4837b02da784dbf43b09cb8e7614dcb3af319efa5bcbd15416531770  flow_ledger.py
e680eafa5791e7e0521e508e236098d8a3ef167dc4c3daa473b71f085e0772d9  lifecycle_cases.py
05e6565ab4939843d94e1c39df21d8ab85942b76cd237bcb116285f01cc049a7  raw_observer.py
3053be5dd3a32f497058dad2eccf3742d7a3a05140127dc4d0bae5b9de348277  run_live.py
d053e1eff83cb0384c5186988c18b21c2b7e5a2e0e75817abb3b3c3f45d88b01  runner_adapter.py
3e3dd20197f2d07e2c44afba0ef0deddad100012c8b33c9d116b8798b2e29866  strict_close.py
5083a58d5ebb1748efe400f8f186e4e661194450abf27842610c8d6be0a15532  validate_builds.py
c11c54602b5e46bd7dadfdeaa4a330b1b8a4661ebe4ee2709e5460e5d438cb5a  wire.py
```

The current runtime excludes historical task5c2 `cases.py` and draft `close_observer.py`; the former is retained and bound only as support for the previous credit regression. Guarded preparation tool SHA-256 values are `9912e72a35389772c93f0ec43e1c40acff088c57f6ce0e98c4c125459898f500` for `freeze_runtime.py`, `e69731534c56fae9f333bc92fda961d88be5eb196e5efb7e76e45b1a2d8e6414` for `check_closure.py`, `91498df14f9d23827c9352f46ce91000a791186e1e1491e97255aeffbfb2e7ee` for `bind_manifest.py`, `c61b3162484398aaa10f58969f59b7a482ebb223183ea986e4dfc542c1896649` for `check_closure_v2.py`, `a90670738d32c9a15b538b163d3bbbd5d395a8d7fded7a3b54132182fe752011` for `bind_manifest_v3.py`, and `525340a8e345ae8bd6d5ac940725aa90f1084028d86266068755ef87b2f1c40c` for current `check_closure_v3.py`. All are manifest inputs. The guarded final binder and checker import-test SHA-256 is `7fc659d607fe1015f41026b5257c5244117fdca5165eb97485f3a4f0520f2193`.

Actual preparation and validation commands, all exit 0, with raw outputs retained beside the owned sources:

```
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/freeze_runtime.py
frozen runtime files: 9
tree counts: {'/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/lib': 19542, '/tmp/uwz-h2-client-tooling/packages': 42, '/tmp/uwz-reviewed-libxev-c223-loop-callbacks': 93, '/tmp/uwz-task4d-fix1-frozen': 1031, '/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy': 14, '/tmp/uwz-task5c3-fixture-v1': 1, '/tmp/uwz-task5c3-runtime-v1': 9}
direct inputs: 2447
manifest sha256: d8e754635a3cdf0d030d4997e5873e1174d209946a36b418fcd2ef664dc0e070
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/bind_manifest.py
v1 closure accepted; current closure accepted
direct inputs: 2451
manifest sha256: 1ab3d608d353410afd3eb871ff83ec607bd212d58ebf03d816be3f79f0b69a43
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/bind_manifest_v3.py
v2 closure accepted; current closure accepted
direct inputs: 2456
manifest sha256: 4f0a3b803912c84f340b954c00d23eb1e3cb07ab9369f3de9281a29c9f628bc1
```

V2 added the verified reviewed-base manifest and guarded tools. V3 added the actual v1/v2 preparation manifests and final guarded tools, making that preparation chain explicit; it does not alter the frozen runtime or native builds. The current checker was invoked against the fixed, externally supplied current hash, first normally and then under Python optimization:

```
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/check_closure_v3.py --manifest-sha256 4f0a3b803912c84f340b954c00d23eb1e3cb07ab9369f3de9281a29c9f628bc1
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/check_closure_v3.py --manifest-sha256 4f0a3b803912c84f340b954c00d23eb1e3cb07ab9369f3de9281a29c9f628bc1
```

Each exited 0 with the same raw output:

```
current closure: accepted
mutated actual input: rejected: input identity differs: /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/runner_adapter.py
restored closure: accepted
```

The mutation appended one byte to the actual owned runtime-source input, required the specific identity failure, restored exact original bytes and mode in `finally`, checked both, and validated the complete closure again. No candidate, override, helper, archive, binary or earlier evidence was mutated. `closure-v3.stdout`, `closure-v3-opt.stdout` and their empty stderr files retain the outcomes. The earlier v1/v2 acceptance/mutation/restoration receipts are retained too. The first attempted copy of a read-only validator produced `Permission denied`; its owner write bit was enabled before adapting the owned copy. No gate or source expectation was weakened.

The pinned Zig command `/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/profile.zig /tmp/uwz-task5c3-fixture-v1/profile.zig` exited 0 with no output. Python AST parsing exited 0 for the 23 original owned bound Python files plus six newly added v2/v3 guarded tool files and all nine frozen runtime files. `test_inert_modules` exited 0, `Ran 1 test`, `OK`, trapping socket construction, connection, TLS context, process launch, signal and writes for the 12 original runtime/preparation modules. `test_bind_import` and `test_bind_v3_import` each exited 0, `Ran 1 test`, `OK`, trapping effects for the additional binder/checker pairs. A separate env-i import of all nine actual frozen modules under the same traps exited 0 with `frozen runtime inert imports: 9`. Raw AST, formatting, inert-test and frozen-import stdout/stderr are retained in `ast-*.stdout`, `fmt-v1.*`, `inert-*.stdout` and corresponding stderr files. The 53 ordinary and 8 optimized covering tests from the runner pass remain the actual prior results; they were not repeated without a source change.

The intended future invocation, shown only to specify the bound interface and **not authorized or executed here**, is:

```
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5c3-runtime-v1/run_live.py --run --manifest /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/manifest-v3.json --manifest-sha256 4f0a3b803912c84f340b954c00d23eb1e3cb07ab9369f3de9281a29c9f628bc1 --output /tmp/uwz-task5c3-NEW-PRIVATE-OUTPUT
```

Omitting `--cases` selects disconnect, reuse, shutdown_active in that order; supported subsets are explicit and shutdown must be last. The actual routes/schema and 32 records, 20 spares, two bindings and full 12-history/B12/E10/C2/334 accepted/384 client DATA planned expectations are documented in the fixture and case sections above. These numbers are independent planned oracles, not measurements. The runtime keeps the same 65536 continuous-output cap, eight response records, 8192 read/send, bounded framing/header/status/INFO limits, owned PID/start/nonce/listener/certificate verification and single graceful deadline. Full selection requires four distinct verified TLS connections.

Self-review: actual input identities, current test/preparation tools, full tree inventories and both real compile receipts are bound to the final manifest; current source and snapshot hashes match, mutation rejection was proved on an actual bound source and restoration checked, all tool entry points are guarded, critical proof checks are explicit under `-O`, and prior artifacts and source cohort remain intact. Strict close and shutdown observation do not manufacture server cancellation; independently generated pre/post expectations require actual callback rows. The current closure is a review artifact only: Root's independent review may still identify defects, and no live attempt or remaining project milestone is authorized or reported as passed by this preparation.

## Review fix 1: active case deadline

Status: **fix prepared for scoped independent re-review**, with no live authorization. The prior Stage A review found that active shutdown could run past its absolute 30-second case deadline: at case time 29 the old code selected 44 (now + 15), rather than 30. The actual `run_live.py` now routes both callers through `choose_graceful_deadline(overall, case_deadline, now)`. Active shutdown supplies its already established case deadline and gets `min(overall, case_deadline, now + 15)`; idle teardown supplies `None` and retains `min(overall, now + 15)`. The resulting single absolute deadline is passed unchanged through signal, termination, child wait, collector and post-deinit observations; no timer is restarted. Existing `remaining()` rejects an expired deadline. No case, expectation, production capacity, native source, fixture or timeout limit changed.

The exact pre-fix mutable source bytes were preserved as `run_live-pre-fix1.py`, SHA-256 `3053be5dd3a32f497058dad2eccf3742d7a3a05140127dc4d0bae5b9de348277`, matching the untouched `/tmp/uwz-task5c3-runtime-v1/run_live.py`. The old v3 manifest and its original logs remain unchanged as historical evidence; its original mutable `run_live.py` input is now superseded, so it is not current executable proof. Only the frozen runtime's `run_live.py` differs between v1 and v2. The new owned source and frozen v2 copy both have SHA-256 `bdc061817d4c9da95015919577a0ff421006d07575089ac39f1ffc8c23c3b593`.

The offline clock regression was written against the actual bound helper and actual active-case callback path. To establish behavioral red without changing behavior, the former calculation was first extracted unchanged into the helper and wired into the real caller. Exact red command from `integration-owned/lifecycle-close`:

```
env PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S -m unittest test_deadline_fix1
```

Exit 1, raw `deadline-fix1-red.stderr`: `Ran 3 tests`, `FAILED (failures=3)`. The 29-second case observed `AssertionError: 44.0 != 30.0`; the expired 30-second boundary did not raise; the actual shutdown-case API double rejected the incorrect shared signal deadline. The corrected calculation then produced:

```
env PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S -m unittest test_deadline_fix1 test_shutdown_case test_runner_adapter
..............
----------------------------------------------------------------------
Ran 14 tests in 0.115s

OK

env PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S -O -m unittest test_deadline_fix1
...
----------------------------------------------------------------------
Ran 3 tests in 0.002s

OK
```

Both exit 0; raw green/optimized files are retained. Tests cover case, overall and 15-second clipping, exact expiration, an independent idle 15-second allowance, and the actual shutdown-case API's identical clipped deadline through signal, termination, wait and post. `test_fix1_import test_inert_modules` also exited 0, `Ran 2 tests in 0.098s`, `OK`; an env-i frozen-v2 import under socket, TLS-context, process, signal and write traps exited 0 with `frozen runtime inert imports: 9`. Five changed/new owned Python files and the frozen changed runtime file AST-parse cleanly (`owned changed/new Python files: 5`, `frozen changed runtime files: 1`).

The **current** independent runtime snapshot is `/tmp/uwz-task5c3-runtime-v2`, nine read-only files, and current manifest is `.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/manifest-v4.json`, SHA-256 `fc64a55cb7de3f1473a1883d12911366fe26aea745ec424cba4f0ff863258da9`. This new closure has **2,452 direct inputs**, with tree counts Zig library 19,542; client 42; libxev override 93; candidate 1,031; zslay 14; native fixture 1; current runtime 9. It binds the current actual runtime/source and new tools/tests, unchanged native receipts and binaries, source cohort, helper, archives, interpreter, loader and environment. It does not add the historical runtime or binaries as a current build union.

Exact freeze command, exit 0, raw `freeze-fix1.stdout`:

```
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/freeze_runtime_fix1.py
frozen runtime files: 9
tree counts: {'/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/lib': 19542, '/tmp/uwz-h2-client-tooling/packages': 42, '/tmp/uwz-reviewed-libxev-c223-loop-callbacks': 93, '/tmp/uwz-task4d-fix1-frozen': 1031, '/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy': 14, '/tmp/uwz-task5c3-fixture-v1': 1, '/tmp/uwz-task5c3-runtime-v2': 9}
direct inputs: 2452
manifest sha256: fc64a55cb7de3f1473a1883d12911366fe26aea745ec424cba4f0ff863258da9
```

The current guarded checker was run both normally and with Python optimization, each exit 0:

```
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/check_closure_fix1.py --manifest-sha256 fc64a55cb7de3f1473a1883d12911366fe26aea745ec424cba4f0ff863258da9
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/check_closure_fix1.py --manifest-sha256 fc64a55cb7de3f1473a1883d12911366fe26aea745ec424cba4f0ff863258da9
```

Both retained the same actual result in `closure-fix1.stdout` and `closure-fix1-opt.stdout`:

```
current closure: accepted
mutated actual input: rejected: input identity differs: /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/run_live.py
restored closure: accepted
```

The checker mutated the actual bound owned `run_live.py`, required the explicit hash rejection, restored its exact original bytes and mode 644 in `finally`, and accepted the full closure again. No candidate, override, helper, archive, binary or prior evidence was mutated. New tool/test hashes: `test_deadline_fix1.py` `e1349b66befafea608516295ee2894c0385b60f18a158554b07427168880d699`; `freeze_runtime_fix1.py` `2f91957527cb37f2fd2f7abf05a2d26cb16dcc702f69a0aaff9f1bf0f9f9a96c`; `check_closure_fix1.py` `3e3155351cc4f5a45a2e86a07bae37e71abcf7a5b8fc2fe689fbf670ef72cd01`; `test_fix1_import.py` `cacbd2d36e749336aa5acb0c7fa52744b8cbe8da85b7ad04e3c2e15fe5811192`. All are actual v4 inputs.

Unchanged native fixture SHA-256 remains `3336d93a5684d88c6a4373d305838ff646b89173abcfb4999a0fd7b1eb951920`; actual Debug binary `99750d37a7445550014ff4303818fc4ea66ac72a1aea46b2be165f411e0cc7e3`, ReleaseSafe `768598a27e0a22445b9dac740c4c3ce4309351f2124e90590a851b1fa1f80495`; their receipts remain `bd86fecce08a88db5db17b3e62ae3f4a1463c5c05cece8e0d3fac6a07c50cf37` and `88998c09ce54cf4137a647ec11cc8cefde4747527132bd3b111f022f82431897`. The new checker validates the two actual 13-input receipts and unchanged 1,031/93/1 maps. No native rebuild or executable occurred.

For later review, the illustrative invocation in the prior section is superseded: use runtime `/tmp/uwz-task5c3-runtime-v2/run_live.py`, `manifest-v4.json` and SHA-256 `fc64a55cb7de3f1473a1883d12911366fe26aea745ec424cba4f0ff863258da9` if separately authorized. Self-review: the clip is applied at the real active/idle choice, all graceful operations share that resulting deadline, idle remains independently capped, proofs are explicit under `-O`, and no runtime behavior has been claimed as observed. Root's scoped re-review and a separate exact future runtime release remain required; native compliance and the remaining full milestones are still unverified.
