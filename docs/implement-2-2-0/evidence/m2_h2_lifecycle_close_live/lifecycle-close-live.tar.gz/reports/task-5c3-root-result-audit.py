"""Independently audit the retained ordinary lifecycle result on its host."""

import base64
import hashlib
import json
from pathlib import Path


ROOT = Path('/workspaces/uWebZockets')
RUN = Path('/tmp/uwz-h2-lifecycle-close-owned-2026-10-29-r1')
OWNED = ROOT / '.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close'
PAYLOAD = bytes(range(1, 11)) + b'final-upload-sentinel!'
H32 = hashlib.sha256(PAYLOAD).hexdigest()
H7 = hashlib.sha256(PAYLOAD[:7]).hexdigest()
EMPTY = hashlib.sha256(b'').hexdigest()
TAGS = ('disconnect', 'disconnect_recovery') + tuple('reuse_' + str(i) for i in range(9)) + ('shutdown_active',) + tuple('spare_%02d' % i for i in range(20))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def expected(tag, phase):
    used = not tag.startswith('spare_')
    interrupted = tag in ('disconnect', 'shutdown_active')
    active = tag == 'shutdown_active' and phase == 'before'
    complete = used and not interrupted
    stale = 8 - int(tag[-1]) if tag.startswith('reuse_') else 2 if tag == 'disconnect' else 0
    return {'tag': tag, 'middleware': int(used), 'attempts': int(used), 'begin': int(used),
            'end': int(complete), 'cancel': int(interrupted and not active), 'failure': 0,
            'end_errors': 0, 'chunk_errors': 0, 'invalid_progress': 0,
            'accepted': 32 if complete else 7 if interrupted else 0,
            'sha256': H32 if complete else H7 if interrupted else EMPTY,
            'active': active, 'paused': active,
            'reason': 'peer_closed' if tag == 'disconnect' else 'shutdown' if interrupted and not active else 'none',
            'metadata_middleware': int(used), 'metadata_begin': int(used), 'metadata_end': int(complete),
            'stale_resume': stale, 'stale_cancel': stale, 'errors': 0}


def record(actual, target):
    require(set(actual) == set(target) | {'chunks', 'max_span'}, 'record schema')
    for key, value in target.items():
        require(type(actual[key]) is type(value) and actual[key] == value, target['tag'] + ':' + key)
    chunks, span = actual['chunks'], actual['max_span']
    require(type(chunks) is int and type(span) is int and chunks >= 0 and 0 <= span <= 8192, 'chunk bounds')
    require((chunks == 0 and span == 0) if target['accepted'] == 0 else (chunks > 0 and span > 0), 'chunk evidence')


def snapshot(actual, phase):
    rows, metrics = actual['records'], actual['metrics']
    require(set(rows) == set(TAGS), '32 distinct records')
    for tag in TAGS:
        record(rows[tag], expected(tag, phase))
    active = phase == 'before'
    target = {'middleware': 12, 'attempts': 12, 'begin': 12, 'end': 10, 'cancel': 1 if active else 2,
              'failure': 0, 'end_errors': 0, 'chunk_errors': 0, 'invalid_progress': 0,
              'accepted': 334, 'active': int(active), 'errors': 0, 'buffered_middleware': 436}
    require(set(metrics) == set(target) | {'slot0_active', 'slot1_active'}, 'metrics schema')
    for key, value in target.items():
        require(type(metrics[key]) is type(value) and metrics[key] == value, 'metrics:' + key)
    require(type(metrics['slot0_active']) is bool and type(metrics['slot1_active']) is bool, 'binding types')
    require(int(metrics['slot0_active']) + int(metrics['slot1_active']) == int(active), 'active bindings')


def main():
    result_path = RUN / 'result.json'
    result = json.loads(result_path.read_text())
    require(result['success'] is True and result['error'] is None and 'failure' not in result, 'run failed')
    require(result['cleanup'] == {'signal': 'SIGTERM', 'exit_code': 0, 'reaped': True, 'forced': False, 'errors': []}, 'cleanup')
    require(set(result['cases']) == {'disconnect', 'reuse', 'shutdown_active'}, 'case selection')
    require(result['manifest_sha256'] == 'fc64a55cb7de3f1473a1883d12911366fe26aea745ec424cba4f0ff863258da9', 'subject')
    require(result['profile'] == '/tmp/uwz-task5c3-fixture-release-v1/profile', 'binary path')
    require(result['child']['binary_sha256'] == digest(result['profile']) == '768598a27e0a22445b9dac740c4c3ce4309351f2124e90590a851b1fa1f80495', 'binary bytes')
    require(result['child_argv'] == [result['profile']], 'child argv')
    require(result['child_environment'] == {'H2_PROFILE_CERT': str(RUN / 'certificate.pem'), 'H2_PROFILE_KEY': str(RUN / 'private-key.pem'), 'H2_PROFILE_NONCE': result['nonce']}, 'child environment')
    require(not (RUN / 'private-key.pem').exists(), 'key remains')
    pem = (RUN / 'certificate.pem').read_bytes()
    der = base64.b64decode(b''.join(line for line in pem.splitlines() if not line.startswith(b'-----')), validate=True)
    require(hashlib.sha256(der).hexdigest() == result['certificate_sha256'], 'certificate identity')
    process = Path('/proc') / str(result['child']['pid'])
    same_process = False
    if process.exists():
        stat = (process / 'stat').read_text()
        same_process = stat[stat.rfind(')') + 2:].split()[19] == result['child']['start']
    require(not same_process, 'owned child remains on host')
    shutdown = result['cases']['shutdown_active']
    snapshot(shutdown['before'], 'before')
    snapshot(shutdown['after'], 'after')
    for tag in TAGS:
        before, after = shutdown['before']['records'][tag], shutdown['after']['records'][tag]
        changed = {key for key in before if before[key] != after[key]}
        require(changed == ({'cancel', 'active', 'paused', 'reason'} if tag == 'shutdown_active' else set()), 'unexpected transition:' + tag)
    require(shutdown['signal'] == {'signal': 'SIGTERM', 'owned_identity': True, 'watcher_installed': True, 'client_open': True}, 'signal evidence')
    require(shutdown['termination'] == {'phase': 'post_signal', 'outcome': 'tls_eof', 'primary_response': False, 'frames_valid': True, 'trailing_bytes': 0}, 'actual TLS termination')
    require(shutdown['process'] == {'exit_code': 0, 'reaped': True, 'forced': False, 'run_ok': True, 'deinit_ok': True, 'key_removed': True}, 'run/deinit evidence')
    disconnect = result['cases']['disconnect']
    require(disconnect['preclose_observation'] == 'original_connection' and disconnect['postclose_observation'] == 'replacement_connection', 'connection observations')
    require(disconnect['close'] == {'method': 'ssl_unwrap', 'tls_shutdown': 'success', 'tcp_eof': True, 'trailing_bytes': 0, 'close': 'normal'}, 'strict close')
    primary = expected('disconnect', 'after')
    primary.update(cancel=0, active=True, paused=True, reason='none', stale_resume=0, stale_cancel=0)
    record(disconnect['preclose_record'], primary)
    primary.update(cancel=1, active=False, paused=False, reason='peer_closed')
    record(disconnect['postclose_record'], primary)
    recovery = expected('disconnect_recovery', 'after')
    recovery.update(end=0, accepted=7, sha256=H7, active=True, metadata_end=0)
    record(disconnect['recovery_active_record'], recovery)
    record(disconnect['recovery_record'], expected('disconnect_recovery', 'after'))
    require(disconnect['stale_resume'] == disconnect['stale_cancel'] == 2, 'disconnect controls')
    reuse = result['cases']['reuse']
    require(reuse['requests'] == 9 and reuse['stale_resume'] == reuse['stale_cancel'] == 36, '72 old-control checks')
    require(reuse['final_stale'] == [[8 - i, 8 - i] for i in range(9)], 'independent reuse stale counts')
    connections = result['connections']
    require([c['label'] for c in connections] == ['disconnect', 'disconnect_replacement', 'reuse', 'shutdown_active'], 'four handshakes')
    require([c['sent_flow'] for c in connections] == [32, 32, 288, 32] and result['sent_flow'] == 384, 'client DATA')
    for item in connections:
        require(item['tls'] == 'TLSv1.3' and item['alpn'] == 'h2', 'TLS/ALPN')
        require(type(item['refunded_flow']) is int and 0 <= item['refunded_flow'] <= item['sent_flow'], 'observed credit bound')
    require(connections[-1]['closing'] == {'kind': 'local_transport_only', 'frames': 0, 'bytes': 0, 'connection_credit': 0, 'stream_credit': 0, 'outcome': 'tls_eof'}, 'observed closing frames')
    log = (RUN / 'server.log').read_bytes()
    require(len(log) == 15918 and len(log) <= 65536, 'bounded output')
    lines = log.decode().splitlines()
    require(not any(line.startswith(('warn', 'error', 'panic', 'thread ')) for line in lines), 'unexpected diagnostic')
    require(sum('H2_READY ' + result['nonce'] in line for line in lines) == 1, 'ready nonce')
    parsed, aggregate = {}, []
    for line in lines:
        marker = 'H2_RECORD ' + result['nonce'] + ' '
        if marker in line:
            item = json.loads(line.split(marker, 1)[1])
            require(item['tag'] not in parsed, 'duplicate deinit record')
            parsed[item['tag']] = item
        marker = 'H2_DEINIT ' + result['nonce'] + ' '
        if marker in line:
            aggregate.append(json.loads(line.split(marker, 1)[1]))
    require(len(aggregate) == 1, 'deinit aggregate count')
    require(parsed == shutdown['after']['records'] and aggregate[0] == shutdown['after']['metrics'], 'actual log/result match')
    before = (OWNED / 'stage-b-preflight-before.json').read_bytes()
    current = (ROOT / '.superpowers/sdd/h2_streaming_plan/task-5c3-root-identity-audit-v4.json').read_bytes()
    require(before == current, 'pre/post identities changed')
    (OWNED / 'stage-b-preflight-after.json').write_bytes(current)
    output = {'status': 'PASS', 'host_executor': True, 'scope': 'One ordinary owned three-case functional proof only',
              'result_sha256': digest(result_path), 'server_log_sha256': digest(RUN / 'server.log'),
              'manifest_sha256': result['manifest_sha256'], 'pre_post_identity_sha256': hashlib.sha256(before).hexdigest(),
              'child_pid': result['child']['pid'], 'child_start': result['child']['start'], 'owned_child_absent': True,
              'key_absent': True, 'exit_code': 0, 'forced': False, 'records': 32, 'spares': 20,
              'attempts': 12, 'begin': 12, 'end': 10, 'cancel': 2, 'accepted': 334,
              'buffered_middleware': 436, 'client_data': 384,
              'observed_connection_refund': sum(c['refunded_flow'] for c in connections),
              'tls_connections': 4, 'server_log_bytes': len(log), 'shutdown_termination': 'tls_eof'}
    target = OWNED / 'stage-b-root-result-audit.json'
    target.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps(output))


if __name__ == '__main__':
    main()
