# Task5c3 bounded continuation: actual runner integration

Continue SAMEtask/ownership and full task-5c3-brief.md acceptance. Root read the
observer/helper report, source references, actual commands and32ordinary/12-O
checks. This pass wires the REAL runner to completed case/model/wire/strict_close
APIs and verifies integration using inert doubles. Final runtime freeze/input
closure remains a separate pass; no native execution or StageA review yet.

Only lifecycle-close/, /tmp/uwz-task5c3-* and original report may change. You are
not alone; preserve others. No prior evidence/common helper/product/docs/pins/
refs/commit/push/subagents. No native executable/test/constructor/socket/cert/
realprocess/FD/fault activity or generic native gates. Do not invoke run_live.py.

Replace the copied task5c2 behavior with the actual supported disconnect,reuse,
shutdown_active selections; reject unsupported/duplicate/non-last shutdown.
Default full selection in that order, no silent omitted-case success. Bind and
call ACTUAL lifecycle_cases functions rather than reimplementing them or using
models as server results. Remove stale task5c2 modes/draft close_observer from
the current runtime; earlier artifacts remain in previous checkpoint ownership.
Keep relevant regression coverage without dead application-error runtime code.

Retain original safe owned PID/start/nonce/listener/certbeforehealth guards,
TLS1.3/h2 verification, explicit --run/current-reviewed-manifest flag, fresh
private output directory, env-i/pinnedclient/interpreter, ready15/case30/whole900/
onegraceful15 absolute deadlines, bounded continuousstdout/stderr65536 and
stage/filename/traceback failures, no auto retries/fallback, normal wait/deinit/
reap/keyabsence/noforce evidence. Inert imports for every tool/runtime module.

Connection adapter: explicit caller-owned data and existing at-most8active
records/high-water raw state, bounded reads/sends8192, headers32/4096, JSON<4096,
INFO16/16384, frames16384. Avoid growing run_live into a second giant ownership
module; one concrete adapter seam must own a real bound/invariant, no speculative
framework or forwarding-only layer. Do not retain all completed reply bodies.

Implement actual start/send/status/control/finish using distinct literal case
metadata and actual decoded full-schema record JSON, one middleware header,
healthy response200/framing. Independently verify P32 bytes and H32/H7 once;
per-stream offsets ensure 7 then25 uses P32[0:7] thenP32[7:32], never restarted
payload generation. Request-count accounting counts each issued buffered request
exactly once, including metrics LAST. All32actual rows/spares and complete
metrics go through independent before/after verifier. No favorable substitution.

Disconnect original connection closes only through wire.begin_termination ->
strict_close.unwrap_eof -> wire.finish_termination on SAME parser. Fresh owned
replacement TLS handshake precedes all postclose status/control/recovery, with
honest distinct identity (ordinary fd reuse must not be mistaken for same TLS
connection). Require actual peer_closed record, not local close. Recovery uses
replacement and completes. Retain actual local close and server cause evidence.

Reuse has one fresh connection and nine requests, with all72oldcontrol calls
while later body active. Bind actual adapter to completed reuse(api). Check all
prior requests/responses complete before moving to next selected case.

Shutdown has a fresh owned connection and stays open through owned SIGTERM.
All32status rows then metricsLAST; no later requests. Implement completed case's
preconditions/deadline/signal/termination/wait/post APIs truthfully. Signal guard
uses actual current owned process identity/start/nonce/watcher/listener/client,
then public installed handler. strict_close.observe_shutdown uses same raw/wire
state and one shared absolute graceful deadline. Preserve actual outcome/frames/
credits and actual postrun/deinit records/metrics. Full selection requires four
fresh verified TLS handshakes; no native-slot index claim. If shutdown omitted,
normal idle final snapshot+teardown is still required, not a substitute case.

Wire independent flow_ledger into ACTUAL sends/receives, including raw closing
WINDOW_UPDATE observations without double counting H2 events. Full-selection
clientDATA384, actual sinkaccepted334,12histories/B12/E10/C2/F0/errors0 after
shutdown. Other subselect counts derive independently. Closed-connection refund
amounts are measured observations, not exact-success oracles. No pretend sibling
traffic or outgoing reset. Expose bounded perconnection and total accounting.

Use actual-runner/API inert tests for supported ordering/subsets, metadata and
per-stream suffix offset, actual helper use/parser continuity, independent
buffered-request counts and flow accounting, client staysopen until signal,
normal/failed cleanup, wrong identity and expired deadline. All filesystem/
process/socket/SSL/cert interactions in tests are pure doubles or owned temp
caller-data; no real objects/operations. Run only covering shared regressions;
keep critical assertions explicit even under Python optimization. Current
manifest checker can remain unbound draft until next closure pass; clearly
report no runnable authorization. Append API, source changes, exact commands/
raw outcomes/hash/self-review/remaining closure work to task-5c3-report.md.
