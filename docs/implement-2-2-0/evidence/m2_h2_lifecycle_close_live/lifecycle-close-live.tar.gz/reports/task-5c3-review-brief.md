# Task5c3 independent StageA review

Read original task-5c3-brief.md first: it is the full requirements/spec. Then
task-5c3-report.md (final StageA section supersedes incomplete sections),
task-5c3-stage-a-review.diff (all29current source/prep/test files,191003B) and
task-5c3-root-identity-audit.json. This is task-scoped SPEC and QUALITY review,
not whole-branch or completion review. No committed Root product change here;
basef2ea5e3, new standalone lifecycle-close harness over unchangedfc69/C223.

Current manifest owned lifecycle-close/manifest-v3.json:
4f0a3b803912c84f340b954c00d23eb1e3cb07ab9369f3de9281a29c9f628bc1,
2456directinputs/7trees, actualfixture1/runtime9. Root independently hashes all
inputs/complete tree inventories, both actual Debug/ReleaseSafe receipt maps,
actual/retained binaries, owned/frozen copies and actual current validation logs.
Initial Root audit used the wrong aggregate encoding; v1script is preserved.
Corrected audit uses the exact sorted-Path JSON-pair encoding from the build
receipt, with unchangedfc69expected digest; all checksPASS, no subject import/
execution. No weakened source expectation, native build repeat or runtime run.

Raw report covers53ordinary+8optimized runner checks, earlier codecdouble
regressions, inert/AST/fmt and actual bound-source mutation rejection/restoration
normaland-O. Current sourcepackage3c621a2e95e072d03405e43cf0ae693ae2531154504addc2ed461c51462fb61f,
40536B,29files/184870sourceB/3853lines, nofileover1000. The diff is your changed-
source view. Actual manifest/maps/receipts/logs under the owned directory are
data-only inputs for concrete identity risks, not permission to rerun anything.

Global constraints copied from original brief:
"Keep32 fixed history records:12used/20untouchedspares. No128ledger or raised
production/output bound. Exact used tags: disconnect,disconnect_recovery,
reuse_0 through reuse_8,shutdown_active."
"Fixed owned127.0.0.1:28443/localhostTLS1.3h2, PID/start/nonce/listener/certbefore
health. Ready15/case30/whole900/graceful15 absolute deadlines; no retry/fallback."
"Same65536continuousoutput,8response records,8192read/send, statusJSON
<4096,32/4096headers,16/16384INFO,16384frames and explicit remaining bounds."
"No local clientclose counted as serverproof."

Review actual strict unwrap+normalEOF/same-parser local termination versus
replacement actualpeer_closed callback, nine sequential bodies/each old token
while later active/nonmutation, activeclientthroughownedSIGTERM/metricsLAST/
independentbeforeafterrecords and normal process deinit/reap/keyproof. Planned
full12histories/B12/E10/C2/F0/334accepted/384clientDATA are not measurements.
Refunds on departed connections are observations, not exact oracles. Preserve
legacy healthy/cancel8/reset8/appfailure2/refusal0 and current fixed capacities.
The native8stream bound is exceeded by9requests; no private slot-index claim.

The root explicitly requests the thermo-nuclear-code-quality-review lens for
the structural harness changes alongside code-review-and-quality. Apply the
AGENTS override:1000lines is an inspection flag, not a mechanical split; no
emojis or preference-only blockers, no wrappers without an invariant/bound.
Focus on actionable correctness/security/compatibility/evidence and structural
regressions, ordered by severity with sourcefile/line and concrete failure.

READONLY: no file/index/ref/source/fixture modifications, no subagents, no
native executable/test/constructor/server/client/socket/TLScontext/certificate/
process/FD/faultprobe, no runner/tool/checker invocation or rerun of checks.
Do not reconstruct stopped experiments/denied socket cases. No whole-suite/
race/high-count validation. Existing evidence is read-only. Use graphify before
new searches; paths above and original brief are already located. Read source
outside the diff only for a named concrete risk; list that focused check.
Avoid dumping large maps, use bounded hash/count/key summaries.

Return SPEC PASS/CHANGES and QUALITY APPROVED/NEEDS FIXES, actionable findings
with severity/path:line, focused evidence inspections and unverified gates.
No maintainer merge/tag/release or goal completion is implied by StageA approval.
