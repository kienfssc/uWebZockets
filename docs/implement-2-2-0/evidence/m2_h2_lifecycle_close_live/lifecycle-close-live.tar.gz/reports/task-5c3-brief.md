# Task5c3: ordinary disconnect, reuse and active shutdown preparation

Read this first; exact requirements for the next adopted lifecycle slice.
Use task-5-plan.md and task-5c-lifecycle-architecture.md for source-backed
contracts, not a redesign. Implement only disconnect, reuse and shutdown_active
plus the disconnect recovery. Preserve producer/file/output and full combined
matrix and every original milestone. No runtime authorization follows.

## Ownership and phase

Own NEW .uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/,
/tmp/uwz-task5c3-* and task-5c3-report.md in this plan workspace. You are not
alone; preserve others. No Root product/pin/docs/prior evidence/common helper
edits, commits/push, subagents or external model CLI. Root owns independent
review, exact later host release, publication and immediate fork pushes.

StageA only: source, Python AST/inert identity/offline codec checks and actual
compile-only Debug/ReleaseSafe fixture builds. NO native executable/test/
constructor/client/server/socket/certificate/live selfcheck. Do not reconstruct
the stopped native cancellation/fault experiment or denied socket cases. No
native schedules/interleavings/races, realFD/resource/kernel/registration/
completion/error injection, panic/leak/crash probes or socket-option changes.
The later cases are ordinary public TLS closure, request reuse and owned SIGTERM,
not a native fault experiment. Report exact contract conflicts; do not broaden
allowed causes or manufacture a favorable close outcome.

Use graphify before new searches; below and cited architecture paths are located.
Apply project/verification/narrow skills, no new markers/dead scaffolding,
explicit types, shallow functions and zero-allocation server chunk handling.

## Current source/tool basis

Root6dd82957121ec8775efa3093b38837cf0641e17e is clean/pushedfork. Task5c2 DONE;
do not redo it. Adapt NEW copies of /tmp/uwz-task5c2-runtime-v2 (9files),
/tmp/uwz-task5c2-fixture-v2/profile.zig and persistent application-error/
recipes/guardedtools/currentmanifest-v3(d2bb368da8f912f3b37ed97376d8d73a11259570b44aae893981609e3ac5a62f).
Keep safe ownership scanning, structured failure stage/filename/traceback,
high-water observer, inert tool imports and independent credit policies.
Remove inapplicable fixture modes in the new copy; retain schema counters when
their explicit zero assertions add a real invariant for combined integration.

Immutable candidate /tmp/uwz-task4d-fix1-frozen,1031files,
fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de;
/tmp/uwz-reviewed-libxev-c223-loop-callbacks,93files,
c223bd886c6a51d2cd60def39dd9a68d701fea73. Keep original r2 c-native.zig,
six static archives/actual linkage in body-app/focused-final-ReleaseSafe.command.json,
Root source/ordinary pins and source cohort unchanged.
Zig /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig,-j2,
shared content-addressed /tmp caches preferred; new output/snapshots/tmp only.
Freeze native source before actual new Debug/RS builds and retain argv/env,
13direct inputs/source1031/override93/fixture maps beforeafter/logs/status/hash.
Runtime freezes separately; bind ACTUAL two builds/current runtime/tools, not
historical binary union or pretend Python compile dependencies. No repeat
unchanged native build. Save all actual source/evidence persistently in ownership.

Pinned42-file client /tmp/uwz-h2-client-tooling/packages digest
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473;
unchanged integration-client/h2_client.py
07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00.
Python /home/codespace/.python/current/bin/python3 -B -S, no installs. Future
env-i LC_ALL=C.UTF-8/exact pinned PYTHONPATH only. Imports must remain inert.

## Bounds, records and ordinary process contract

Same configured Server.preset(...).build_https profile as task5c2:8connections,
streamingtrue,reqline512,requestheaders4096/count80,H1body256,H2body4096,
encodedH2headers8192,responseheaders4096/count32,captures24,writequeue65536,
optional features off; native8streams/73728receive payload, two caller sink slots.
Keep32 fixed history records:12used/20untouchedspares. No128ledger or raised
production/output bound. Exact used tags: disconnect,disconnect_recovery,
reuse_0 through reuse_8,shutdown_active. Distinct literal bounded path/target/
query/x-case metadata expected independently; same quota-one /limit/:tag CL32.
Stable records/control copies/owned expectations outlive reusable slots. Retain
no borrowed callback request/view-array/response/chunk pointers, no private
native owner/slot reads. Exceeding8sequential streams proves reuse without
claiming a native allocation index. Preserve public run/deinit/normalreap evidence.

Fixed owned127.0.0.1:28443/localhostTLS1.3h2, PID/start/nonce/listener/certbefore
health. Ready15/case30/whole900/graceful15 absolute deadlines; no retry/fallback.
Explicit run flag/current reviewed manifest hash/supported selections/newprivate
output dir. Same65536continuousoutput,8response records,8192read/send, statusJSON
<4096,32/4096headers,16/16384INFO,16384frames and explicit remaining bounds.
No unbounded per-request snapshots; reuse's many control replies stay bounded.
One shared graceful deadline for wait/collector/termination observations.

## Exact cases and expectations

P32=bytes1through10+literal final-upload-sentinel!,32total.
H32=7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5.
H7=32bbe378a25091502b2baf9f7258c19444e7a43ee4593b08030acd790bd66e6a
ofP32[0..7], NOT a separate seven-byte generator. Track per-stream upload offsets.
Begin/end validate metadata; every successful body has exactly one terminal.

disconnect:
- Fresh connection, uploadP32 WITHOUTEOF, accept7thenpause/25unaccepted. Same-
  connection status barrier requires active/paused/7H7/B1/E0/C0, full control
  response/raw framing consumed. No arbitrary sleeps/schedules.
- Call PUBLIC SSLSocket.unwrap() with remaining absolute deadline; require
  successful TLS shutdown. On returned ordinary socket require normal EOF,
  then normalclose. No GOAWAY/RST/linger/shutdown(how)/flags manipulation or
  abrupt-close fallback. Failure/unexpected application bytes/timeout/reset
  fails and is retained, not success under another cause.
- New owned TLS/H2 connection observes actual persistent server record:
  accepted7/H7/BEC1/0/1/reasonpeer_closed ONLY,activefalse. Source mapping:
  frozen tcp.zig544-554 SSL_ERROR_ZERO_RETURN=>peer_closed;1929-1941,2415-2436
  drains alert;2277-2283,3212-3227 firstcause preserved. Python ssl.py unwrap
  invokes TLS shutdown. Do not infer server cancellation from client localclose.
- Before and during independent same-route recovery on replacement connection,
  both oldresume/cancel returnBodyControlExpired with no terminal mutation.
  RecoveryP32/200/32H32/BEC1/1/0, metadata/header checks. Preclose barrier is
  originalconn; postclose observation necessarily replacement, label honestly.
  No required refund on departed connection and no nativepoolslot-index claim.

reuse:
- Fresh SAMEconnection for9sequential requests reuse_0..8. For each sendFIRST7
  P32/noEOF, observe active/ready/7H7/B1/E0/C0; while this later request is ACTIVE,
  test BOTH oldcontrols for EVERY earlier tag j<i =>BodyControlExpired and no
  mutation of earlier or current record. Then sendremaining25P32+EOF, require
  200/32H32/BEC1/1/0 and exact distinct metadata. No assumed callback sizes.
- This yields per-earlier-record stale_resume/stale_cancel8-j and lasttag0
  when no extra terminal checks are added; retain exact derived counts if an
  explicitly reported additional check is necessary. All9admissions prove more
  than configured8stream slots, without reading private allocation state.

shutdown_active:
- MUST be last selected/fullmatrix case, all prior bodies/responses complete.
  Fresh connection, P32/noEOF, accept7thenpause/25queued; sameconn barrier
  activepaused/7H7/B1/E0/C0. Keep THISCLIENTOPEN until sending SIGTERM to exact
  owned PID/start through installed public catch_shutdown_signals handling.
  Closing the client first would prove peerclose instead and must fail.
- Read all32statusrecords and metrics LAST while target active. No requests
  after this point or after Appdeinit. Pre-signal snapshot has targetactive1,
  C0/reasonnone/pausedtrue; entirefixture active1. Then ownedSIGTERM.
- Postrun/Appdeinit logs require that target7H7/BEC1/0/1/shutdown,activefalse/
  pausedfalse, fixtureactive0, successful run/deinit/postmarker/exit0/reaped and
  keyremoved/noforce. All other semantic records/metrics remain as independently
  expected. Do NOT compare all pre/post rows blindlyequal: these exact terminal
  fields intentionally change. Build independent before/after expectations,
  rather than copying actual before data into a favorable expected result.
- Retain actual client TLS/H2 termination observations; App shutdown does not
  promise a clean TLSalert. Timeout/unexpected successful primary response,
  wrongcause/duplicatecancel/forcedcleanup fails. No arbitrary reset-code/alert
  promise: derive allowed closing control behavior from actual source, explicitly
  bound it to the post-owned-signal phase. Healthy traffic before remainsstrict.

Full selection expectations:12histories/attempts12/B12/E10/C2/F0,
accepted334/active0/errors0; disconnectprimary7+recovery32, reuse9*32,
shutdown7. BeforeSIGTERM C1/active1 and already334accepted; afterward C2/active0.
Allchunk/invalid/enderror counters remain0. ClientDATA384bytes across original/
replacement/reuse/shutdown connections; actualclosed-connectionrefund totals
are observations, not an exact oracle. These are planned, not measured values.
Selected subsets derive independently; if activecase omitted, normal idle
teardown remains valid but is not a new idlecase substitute. No unimplemented
selection counts as success.

## Offline checks and deliverable

Extend actual observer/case APIs only for explicit named clean-disconnect and
owned-shutdown termination. Keep healthy/publiccancel8/applicationfailure2/
refusal-after-final0/peerreset policies intact. Do not globally accept unexpected
GOAWAY/RST/EOF or drop active state on client-close as serverproof. No DATA/
HEADERS after terminal; preserve full-frame parsing and trailing-byte accounting.
Pure doubles/codec tests must reject wrongclosecause, local-only proof, wrong
pre/post transition, prematureclientclose, stale-controlmutation and invalid
closing frames; cover legal sequence. Reuse expectedstale counts and independent
record identity/hash checks need meaningful pure coverage, not AST text matching.
Keep relevant20 prior runtime tests/inertchecker regression where modules change.
No native probes or constructor execution for these tests.

Finish actual newDebug/RS builds, fixture/runtime freezes, current closure
acceptance AND mutatedACTUALinput rejection/restoration, AST/format, bounded
before/after logging and selfreview. All tools, including checker, guarded on
import. Report exact routes/schema/changes/commands/rawresults/failures/hashes/
current file/input/tree counts and limits in task-5c3-report.md. Return DONE
only when full StageA ready for independent review; otherwise a concrete source/
context blocker. No native run until Root reviews frozen source and releases
one exact ordinary owned attempt separately.
