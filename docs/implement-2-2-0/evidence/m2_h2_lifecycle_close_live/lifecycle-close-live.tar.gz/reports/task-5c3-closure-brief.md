# Task5c3 final preparation pass: current runtime/input closure

Continue SAMEtask/ownership from original task-5c3-brief.md. Root read actual
runner report/API/self-review and53ordinary+8optimized covering outcomes.
The real case/helper/ledger runner is complete in source. Finish the actual
runtime freeze, input binding, guarded validation, final AST/inert checks and
complete StageA report. No independent review or native authorization yet.

Own lifecycle-close/, /tmp/uwz-task5c3-* and task-5c3-report.md only. You are
not alone; preserve others. No product/prior evidence/common helper/docs/pins/
refs/commits/push/subagents. No native executable/test/constructor/socket/cert/
realprocess/FD/fault probe or generic native-gate invocation. NEVER invoke the
real runner, create real clients/SSL contexts, generate certificates or launch
the native fixture. Pure codecs/inert doubles/identity/AST checks only.

Freeze only ACTUAL current runtime modules to a new read-only
/tmp/uwz-task5c3-runtime-v1 (or reported new version if needed), separate from
native /tmp/uwz-task5c3-fixture-v1/profile.zig3336d93a... . Retain persistent
exact source copies. No dead task5c2 modes, old cases.py test support or draft
close_observer.py in current runtime. Historical files remain preserved outside
the current snapshot; no relevant prior regression is discarded.

KEEP actual unchanged Debug/ReleaseSafe receipts/binaries: profile3336d93a5684d88c6a4373d305838ff646b89173abcfb4999a0fd7b1eb951920,
Debug99750d37a7445550014ff4303818fc4ea66ac72a1aea46b2be165f411e0cc7e3,
Release768598a27e0a22445b9dac740c4c3ce4309351f2124e90590a851b1fa1f80495.
Both compiled actual13direct/1031candidate/93override/1fixture files with before/
after maps unchanged. Final closure binds BOTH actual builds and final runtime;
do not pretend Python runtime existed during compilation or repeat unchanged
native compilation. Only actual native-source/input changes require a new
snapshot and both builds, preserving old versions. Root HEADf2ea5e3 changed
docs only since native fixture compilation; candidatefc69 andC223 are unchanged.

Adapt NEW guarded bind/check/validation tools from application-error's reviewed
current closure patterns. No old tool/evidence edits. Final current manifest
must bind all final runtime/prep tools, actual originalC/sixarchives/compiler/
source/override/fixture, two receipts+actual binaries, exact pinned client42files/
helper07a5201, interpreter/stdlib/loader/dependency objects/CLI paths/environment
used by future env-i invocation. Retain actual input/tree/file counts; no assumed
9/10runtime files or fixed total count. Hash current sources, not historical
binary unions. Tools/checker imports are inert, every critical proof check is
explicit so Python optimization cannot disable verification.

Run guarded checker to ACCEPT actual current closure. Mutate an ACTUAL bound
runtime input under your ownership, require explicit rejection, restore exact
original bytes/permissions even on error, then require acceptance. A modified
copy/map alone does not prove actual-input binding. Preserve raw accepted/
rejected/restored outcomes and exact commands. Do not mutate common helper,
source candidate, override, pins, archives, binary or prior evidence.

Check inert imports of every current tool/runtime module (file writes/process/
socket/SSL constructor traps, no real actions), Python AST, fixture formatting
with actual pinned Zig path and relevant covering regressions only where new
changes justify rerun. Preserve actual prior53+8 coverage; no blanket test
repeat or generic native gate. Source review remains Root's separate phase.

Append final full StageA summary: exact native/current-runtime snapshots and
file hashes/counts, current manifest/input/tree counts/hash, all new tool inputs,
actual two receipt/binary hashes, commands/raw results/failures/mutation restore,
import/AST checks, API/routes/schema/selected-default/env-i invocation and
bounded process/client accounting, self-review and open native/fullmilestone
limits. Return DONE only when full current frozen StageA is independently
reviewable; no scoped DONE while closure or actual validation is unfinished.
