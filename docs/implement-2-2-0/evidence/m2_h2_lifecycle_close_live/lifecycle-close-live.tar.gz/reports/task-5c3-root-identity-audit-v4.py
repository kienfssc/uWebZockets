"""Read-only independent identity audit; never import or execute the subject."""

import hashlib
import json
from pathlib import Path


ROOT = Path('/workspaces/uWebZockets')
OWNED = ROOT / '.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close'
MANIFEST_SHA = 'fc64a55cb7de3f1473a1883d12911366fe26aea745ec424cba4f0ff863258da9'


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    path = OWNED / 'manifest-v4.json'
    require(digest(path) == MANIFEST_SHA, 'manifest identity')
    manifest = json.loads(path.read_text())
    require(len(manifest['inputs']) == 2452, 'direct input count')
    require(len(manifest['trees']) == 7, 'tree count')
    for name, expected in manifest['inputs'].items():
        require(digest(name) == expected, 'direct input: ' + name)
    for name, expected in manifest['trees'].items():
        root = Path(name)
        actual = {str(p.relative_to(root)): digest(p) for p in root.rglob('*') if p.is_file()}
        require(actual == expected, 'complete tree: ' + name)
        require(len(actual) == manifest['tree_counts'][name], 'tree count: ' + name)
    candidate = manifest['trees']['/tmp/uwz-task4d-fix1-frozen']
    pairs = [(p.as_posix(), candidate[p.as_posix()]) for p in sorted(Path(name) for name in candidate)]
    encoded = json.dumps(pairs).encode()
    require(hashlib.sha256(encoded).hexdigest() == 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de', 'candidate aggregate')
    require(manifest['python_flags'] == ['-B', '-S'], 'future Python flags')
    require(manifest['environment'] == {
        'LC_ALL': 'C.UTF-8',
        'PYTHONPATH': '/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client',
    }, 'future environment')
    runtime = Path('/tmp/uwz-task5c3-runtime-v2')
    require(len(manifest['trees'][str(runtime)]) == 9, 'runtime file count')
    for name, expected in manifest['trees'][str(runtime)].items():
        require(digest(OWNED / name) == expected, 'owned runtime copy: ' + name)
        require((runtime / name).stat().st_mode & 0o222 == 0, 'runtime source writable')
    receipts = []
    for mode, expected_sha in (
        ('debug', '99750d37a7445550014ff4303818fc4ea66ac72a1aea46b2be165f411e0cc7e3'),
        ('release', '768598a27e0a22445b9dac740c4c3ce4309351f2124e90590a851b1fa1f80495'),
    ):
        receipt_path = OWNED / f'fixture-{mode}-v1.json'
        receipt = json.loads(receipt_path.read_text())
        require(receipt['exit_status'] == 0 and receipt['unchanged'] is True, 'compile result')
        require(receipt['optimization'] == ('Debug' if mode == 'debug' else 'ReleaseSafe'), 'compile mode')
        for key, root, count in (
            ('input', None, 13), ('source', '/tmp/uwz-task4d-fix1-frozen', 1031),
            ('override', '/tmp/uwz-reviewed-libxev-c223-loop-callbacks', 93),
            ('snapshot', '/tmp/uwz-task5c3-fixture-v1', 1),
        ):
            before = receipt[key + '_before']
            require(before == receipt[key + '_after'] and len(before) == count, 'compile input maps')
            for name, expected in before.items():
                require(digest(Path(name) if root is None else Path(root) / name) == expected, 'actual compile input')
        require('-j2' in receipt['argv'], 'compile concurrency')
        binary = next(item.split('=', 1)[1] for item in receipt['argv'] if item.startswith('-femit-bin='))
        require(digest(binary) == receipt['binary_sha256'] == expected_sha, 'actual binary')
        require(digest(OWNED / f'profile-{mode}-v1.bin') == expected_sha, 'retained binary')
        for key in ('stdout', 'stderr'):
            require(not (OWNED / receipt[key]).read_bytes(), 'compiler output')
        receipts.append({'mode': receipt['optimization'], 'receipt_sha256': digest(receipt_path), 'binary_sha256': expected_sha})
    expected_log = (
        'current closure: accepted\n'
        'mutated actual input: rejected: input identity differs: '
        + str(OWNED / 'run_live.py') + '\nrestored closure: accepted\n'
    )
    for name in ('closure-fix1', 'closure-fix1-opt'):
        require((OWNED / (name + '.stdout')).read_text() == expected_log, 'closure outcome log')
        require(not (OWNED / (name + '.stderr')).read_bytes(), 'closure error log')
    for name in ('inert-source', 'inert-bind', 'inert-bind-v3'):
        text = (OWNED / (name + '.stderr')).read_text()
        require('Ran 1 test' in text and text.rstrip().endswith('OK'), 'inert test outcome')
    output = {
        'status': 'PASS', 'scope': 'Actual inputs, trees, copies, two builds and retained offline outcomes only; no subject execution',
        'manifest_sha256': MANIFEST_SHA, 'direct_inputs': 2452,
        'trees': manifest['tree_counts'], 'receipts': receipts,
        'runtime_files': 9, 'subject_imported_or_executed': False,
    }
    target = ROOT / '.superpowers/sdd/h2_streaming_plan/task-5c3-root-identity-audit-v4.json'
    target.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps(output))


if __name__ == '__main__':
    main()
