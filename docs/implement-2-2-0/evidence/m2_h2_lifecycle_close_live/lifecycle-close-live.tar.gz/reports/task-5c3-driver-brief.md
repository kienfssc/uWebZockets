# Task5c3 next pass: driver, observer and current input closure

Continue the SAME original task and ownership in task-5c3-brief.md. Read that
brief first; it remains the full acceptance contract. Root read the actual
fixture report and checked both receipts against every current direct input,
the 1,031 candidate files, 93 override files, one frozen fixture source, empty
compiler logs and both actual build/copy binary hashes. Audit is retained in
task-5c3-fixture-root-audit.json. Fixture compilation is complete as scoped;
the full Stage A remains incomplete. This is continuation, not a fix round.

Finish the independently checked Python cases, explicit close observer
policies, owned process runner, offline regressions and current input closure.
Only lifecycle-close/, /tmp/uwz-task5c3-* and the original task report are yours.
You are not alone; preserve other work. No product, prior evidence, common
helper, pins, Root docs, refs, commit/push, subagents or external model CLI.

Keep the existing native snapshot /tmp/uwz-task5c3-fixture-v1/profile.zig
(3336d93a5684d88c6a4373d305838ff646b89173abcfb4999a0fd7b1eb951920)
and actual successful Debug/ReleaseSafe receipts. Freeze the Python runtime
separately after finishing it; bind both real native before/after receipts
and all actual final runtime/tool/client/interpreter/stdlib/loader inputs.
Do not invent compile-time Python inputs or recompile unchanged native code.
If an actual fixture defect requires a change, report it, preserve v1 and
build a new frozen native source in both modes with the same checks.

Use the actual fixture routes, literal identity expectations and complete
32-record schema in the appended task report. Successful upload responses
are bounded record JSON; accepted32 is an upload count, not a 32-byte response
wire size. Independent expectations must match the full selected subset and
all untouched spare records. Observe actual callbacks, no favorable substitution.
Keep the previous high-water retired-response bookkeeping and all bounds,
safe owned-listener scanning, filename/stage/traceback capture and inert tools.

Implement strict successful public TLS unwrap plus ordinary TCP EOF for the
disconnect case. Preserve its same-connection paused barrier; post-close
server cause and recovery are observed on the replacement connection. No
abrupt-close fallback, reset/GOAWAY/shutdown flags or local-close-as-server-proof.
Test old controls before and during independent recovery without record mutation.

Run all nine reuse uploads on one connection. Each later body stays active
after its first7 while both controls for every previous tag are checked expired.
Capture bounded evidence proving old/current record nonmutation; exact derived
stale counts are 8-j for each operation on reuse_j. No private slot-index reads.

The active-shutdown case is LAST. Keep that exact TLS client open through the
owned SIGTERM; all32 status records and metrics LAST are collected while its
body is still active/paused at7. No request follows. Derive independent expected
before/after rows and metrics: only documented shutdown terminal transitions
change. Actual public cancellation must say shutdown, not peer_closed. Retain
bounded actual TLS/H2 termination observations using an explicit post-signal
policy justified from source. Do not weaken healthy, peer-reset, cancel,
application-error or refusal policies. No successful target response, timeout,
forced cleanup, wrong cause or duplicate terminal may count as success. Use one
shared absolute graceful deadline for process/collector/termination observations.

Use pure codecs, caller-data and inert doubles for meaningful regressions on
the actual observer/case APIs: legal termination, bad closing frames, wrong
cause, local-only proof, premature close, pre/post transition, stale mutation,
identity/hash swaps and selected subsets. Preserve relevant previous20 runtime
checks and guarded-checker import regression; no duplicate unchanged test runs.
All prep tools, including bind/check/compile, are inert on import. Capture real
fail-before/fix-after outcomes where a defect is exposed, not missing-import
failures as product behavioral red. Python AST and identity checks may run only
without constructing native objects or invoking sockets/processes/certificates.

Demonstrate validator acceptance of the actual current closure, rejection after
mutating an ACTUAL bound runtime input, and acceptance after exact restoration.
Keep old artifacts and raw failures, no weakened hashes or expected input counts.
Report exact schema, routes, commands, outputs, counts, hashes, source justification,
self-review and limitations in task-5c3-report.md. DONE means full Stage A is ready
for independent review. No native executable/test/constructor/server/client/
socket/certificate/live selfcheck, native scheduling/fault/FD/resource/error
injection, stopped experiment or denied socket case is authorized. Root will
review frozen source and separately release one exact ordinary owned attempt.
