# Task5c3 bounded continuation: complete disconnect orchestration

Continue SAMEtask/ownership; original task-5c3-brief.md governs full acceptance.
Root read the completed reuse API/report/actual pure outcomes. Retain it and
unchanged fixture/builds. This pass finishes the actual disconnect+recovery
case function and inert API-double regressions only. Full runner, shutdown,
observer, closure, review and future runtime proof remain required.

You are not alone; only lifecycle-close/, /tmp/uwz-task5c3-* and original report
may change. No other source/evidence/helper/docs/pin/ref/commit/push/subagent.
No native executable/test/constructor/socket/cert/runner/process or faultprobe.
Keep all original bounds, metadata, P32/H32/H7, selected-subset expectations.

Implement disconnect orchestration callable by the eventual real driver, using
the reuse API style where useful and explicit close/replacement adapter calls.
Send entire P32/noEOF; require full-schema actual same-connection barrier with
accepted7/H7/activepaused/BEC1/0/0 and independent literal request identity.
Finish that status response/framing before the close adapter is called.

The close adapter must later perform public SSLSocket.unwrap with remaining
absolute deadline, require success and ordinary EOF on the returned plain
socket, then normal close. Its exact successful evidence is checked; wrong
result, timeout, bytes, reset, abrupt fallback or local-only proof is rejected.
No GOAWAY/RST/linger/shutdown flags or socket-option calls. Do not invoke it
against real objects now. Replacement adapter must later establish a fresh,
owned TLS/H2 connection before any postclose status/control/recovery request.
The case itself must insist on actual persistent postclose server record
7/H7/BEC1/0/1/peer_closed/inactive, not infer cancellation from local unwrap.
Label preclose and replacement observations distinctly in bounded output.

Check BOTH old controls expired before recovery, allowing only the matching
stale counter increments and no other old-record mutation. Start independent
disconnect_recovery on that replacement, first7/noEOF and actual active-ready
barrier; repeat BOTH old controls during that active recovery, with unchanged
old semantic/current full records. Then remaining25+EOF and complete healthy
response200/full32/H32/BEC1/1/0/metadata/terminal plus middleware header/framing
adapter obligations. Final old stale counts2/2. No departed-connection exact
refund requirement or private slot-index claim. Return compact bounded proof.

Inert doubles must exercise THIS actual complete function: valid order, wrong
preclose pause/hash/identity, failed close/extra bytes/local-only proof, missing
or wrong server terminal cause, wrong expired controls/record mutations and bad
recovery. Assert replacement occurs only after strict close and recovery tail
only after both during-active stale checks. No tests mirroring only helpers.
Capture meaningful failures/fixes, command/raw result, API contract, hashes,
self-review and remaining gates in task-5c3-report.md. No new compile if native
inputs unchanged; no current closure/native claim from this scoped DONE.
