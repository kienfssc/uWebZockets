# Task5c3 fix round1: preserve the active case deadline

Read original task-5c3-brief.md, current task-5c3-report.md and actual review
task-5c3-review.md. Root read the full review, actual frozen run_live.py437/
453-454/control flow and fix-loop.md. This is round1/5; you are the SAME
original implementer. Full original acceptance stays binding.

Reviewer finding verbatim:
P2 — Active shutdown can exceed the30-second case deadline. run_live.py453
creates the graceful deadline from overall and now+15, dropping the case
deadline established at437. If connection setup and metrics take29seconds,
termination can take another14seconds and still pass at43seconds. Clip active-
shutdown teardown to the existing case deadline as well as the15-second graceful
and overall deadlines. Add an offline clock regression covering this boundary;
retain the separate allowance for idle teardown.

Own lifecycle-close/, /tmp/uwz-task5c3-* and append original report only. You
are not alone; preserve others. No Root product/docs/pins/prior artifacts/refs/
commit/push/subagent. No native executable/test/constructor/socket/TLScontext/
cert/realprocess/FD/fault/nativegate or real runner invocation. Use caller-data
clock/inert doubles only; no native deadline/scheduling experiment.

Fix active-shutdown graceful deadline to the minimum of existing absolute case
deadline, whole-run deadline and now+15. All signal/termination/wait/collector/
post observations keep that ONE resulting absolute deadline. Do not reset any
timer between operations. Separate ordinary idle teardown retains its original
15-second allowance capped by whole-run, without a prior case deadline. Do not
broaden30/15/900 limits or change cases/profile/expectations to make tests pass.

Meaningful actual-code offline clock regression must fail before fix for the
29seconds+14seconds scenario and pass after, with case/whole/grace clipping,
expired boundary and preserved independent idle allowance. Exercise actual
deadline implementation/call path with clock doubles, not only AST text or a
disconnected helper. A pure helper is suitable if it owns the real bound and
the real active/idle callers use it correctly. Retain raw RED/GREEN and covering
shared test commands/output. No unrelated unchanged full suite repetition.

Preserve reviewed /tmp/uwz-task5c3-runtime-v1 and currentv3manifest/logs/source
package as superseded history, never overwrite them. Freeze corrected runtime
to a NEW /tmp/uwz-task5c3-runtime-v2 and bind a NEW actual currentmanifest
(e.g.manifest-v4.json). Retain pre-fix mutable owned-source bytes before editing.
Keep actual nativefixture3336d93a..., Debug99750d37..., Release768598a2... and
both compile receipts/maps unchanged: this is Python-only; NO native rebuild.

Use current actual final tool/runtime/source identities and counts, not a
historical runtime/binary union pretending to be current. Original snapshots
and oldmanifest stay retained for source history, not executable currentproof.
All actual new tools/tests are bound; critical checks remain explicit under-O
and all imports inert. Demonstrate new current accept/mutateACTUALboundsource/
reject/exactrestoreaccept normaland-O, preserving bytes/permissions and outcomes.
No candidate/override/helper/archive/binary/prior evidence mutation.

Append exact fix scope, commands/raw RED/GREEN and actual new closure outcomes,
snapshot/file/input/tree counts/hash, source hashes and unchanged nativebuild
proof, self-review and remaining native/fullmilestone limits to original report.
Root will read code/report/covering raw outcomes and issue a scoped re-review
to the original reviewer. No native authorization follows this fix dispatch.
