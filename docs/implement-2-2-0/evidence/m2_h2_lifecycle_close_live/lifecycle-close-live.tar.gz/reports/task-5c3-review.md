SPEC: CHANGES
QUALITY: NEEDS FIXES

P2 — Active shutdown can exceed the30-second case deadline. run_live.py453
creates the graceful deadline from overall and now+15, dropping the case
deadline established at437. If connection setup and metrics take29seconds,
termination can take another14seconds and still pass at43seconds. Clip active-
shutdown teardown to the existing case deadline as well as the15-second graceful
and overall deadlines. Add an offline clock regression covering this boundary;
retain the separate allowance for idle teardown.

Reviewer /root/review_h2_lifecycle_close read all29source files, applicable
instructions/lifecycle contracts/report/Rootidentityaudit, actualmanifest,
twoactualbuildreceipts/maps, normal/optimizedclosure andAST/fmt/inertlogs.
No additional actionable structural findings. No subject/tests/checkers/builds/
native activity rerun. Retained53ordinary/8optimizedtests are author evidence.
LiveTLSclosure/callbackcauses/reuse/shutdown/fullgates remain unverified.
This review grants no native execution or milestone completion.
