# Task5c3 bounded continuation: actual active-shutdown orchestration

Continue SAMEtask/ownership and original task-5c3-brief.md acceptance. Root read
the completed disconnect API/report/actual outcomes; retain it and reuse. This
pass finishes the active-shutdown case's actual orchestration and independent
before/after verification with inert doubles. Runner/observer/closure/review/
future exact native authorization remain separate. You are not alone.

Only lifecycle-close/, /tmp/uwz-task5c3-* and original report may change. No
other source/evidence/common helper/docs/pins/refs/commit/push/subagents. No
native executable/test/constructor/socket/cert/realprocess/FD/fault activity.
Do not run generic full-project gates: Root owns them and the explicit native
stop overrides defaults. Actual fixture/builds remain unchanged.

Implement callable shutdown_active orchestration and pure final verification,
using explicit caller-owned API/connection and selected-subset inputs. This
case is LAST; all earlier cases have completed all requests/responses. Start
its independently literal /limit/shutdown_active identity, P32/noEOF; actual
same-connection status must show activepaused7/H7/BEC1/0/0 and metadata. Keep
that exact client OPEN through the ownedSIGTERM. The process adapter eventually
checks exact PID/start/nonce ownership immediately before signaling through
installed public catch_shutdown_signals; no close-first or replacement proof.

Collect all32actual status rows then metrics LAST while target active. Validate
against independently generated expectations.records(selection,'before') and
independent aggregate arithmetic, with all untouched spares/other cases exact.
No request may occur after metrics or after Appdeinit. Count buffered requests
from actual issued-request accounting in the adapter, not by copying server
metrics. Retain bounded32-record evidence; do not grow production/history bounds.

Then signal and observe actual client TLS/H2 termination, process wait/reap,
postrun/Appdeinit records and finalmetrics under ONE shared absolute graceful
deadline. Terminal proof is the actual server record shutdown_active7/H7/
BEC1/0/1/reasonshutdown/inactive/notpaused, aggregateactive0, successful
run/deinit markers/exit0/reaped/keygone/noforce. Preserve the actual termination
outcome and explicit post-signal ordering. No successful primary response,
timeout, forcedcleanup, duplicatecancel or peer_closed-as-shutdown success.
Client termination alone cannot replace the callback record.

Derive independent expectations.records(selection,'after'), not a mutation of
actual before rows. Other semantic records/metrics unchanged; only the planned
shutdown fields change. Allchunk/invalid/enderror counters0. Full selection
before:attempts12/B12/E10/C1/accepted334/active1; after:C2/active0. Selected
subsets derive independently. Deinit log/chunk diagnostics must be actual and
bounded; no unpromised alert/reset code or native slot-index claim.

Source-backed closure basis located by Root: frozen app.zig657-676 calls
core_tcp_upload.close(conn,.shutdown); tcp_upload.zig403-416 claims cause first;
tcp.zig3212-3243 marks closing/cancels outstanding IO and3247-3289 eventually
deinitializes TLS and closes socket. No TLS alert is promised by this path.
This pass may make explicit termination-adapter obligations; actual observer
policy integration/source review follows. Do not globally weaken healthy/reset/
cancel/applicationerror/refusal policies to accept shutdown traffic.

Inert actual-case API tests must cover legal ordered flow, metricsLAST/no later
request, clientopen until signal, independent full/subset pre/post counts,
wrong active barrier, close-first, wrong server cause/hash/identity, missing or
duplicate cancel, mutated other rows/spares, unexpected target response,
timeout/forcedcleanup/failedrun/reap/keyproof. Capture meaningful failures/fixes
and shared-module covering tests only. Report API, exact raw results, hashes,
self-review and integration obligations in task-5c3-report.md. Scoped DONE is
the real orchestration plus independent verifier, not a helper/model-only pass.
