# Task5c3 bounded continuation: finish the actual reuse case

Original task-5c3-brief.md remains the acceptance authority. Root read the
second partial report and handling-reports. The driver/observer/closure working
set is still too large, so this pass finishes ONE actual case function and its
offline behavioral checks. This is sequencing, not removal of any full task,
disconnect, shutdown, review or runtime requirement. No review/fix round yet.

Continue same ownership; you are not alone. Keep current fixture/builds and
partial helpers/tests. Own lifecycle-close/ and append task-5c3-report.md.
No prior evidence/common helper/product/docs/pins/ref/commit/push/subagent work.
All original native/socket/cert/constructor/stopped-experiment prohibitions hold.

Implement the actual reuse orchestration in lifecycle_cases.py (or replace the
stale task5c2 cases.py with this task's real API), ready for a later run_live.py
integration. Reuse the existing real driver's start/send/status/control/finish
API shape where practical. Make the API contract explicit in the report. Do not
leave it as a helper that nobody can call to run the complete reuse case.

One caller-provided connection, nine sequential tags reuse_0..reuse_8, distinct
literal request metadata from fixture contracts, exact P32 first7/noEOF barrier,
then every older tag's resume and cancel while CURRENT is active/ready/7H7.
Require actual old-control BodyControlExpired and compare old/current records
around EACH operation, allowing only that operation's stale counter increment.
Send remaining25+EOF only after those checks, and verify response200 plus full
bounded actual record32/H32/BEC1/1/0/metadata/terminal fields. No private native
slot reads or claim about an allocation index. Derive stale counts8-j independently
for final verification; do not replace the independent model with actual rows.

Return bounded case evidence needed by the later runtime/result auditor. Avoid
retaining all reply bodies for the 72 old-control operations; use compact
per-step observations/counters/digests where they still prove nonmutation.
Keep 8active responses, 8192chunks, 32records and all original traffic bounds.

Exercise THIS actual complete case function using caller-data/inert API doubles:
legal9request sequence, wrong expired-control result, wrong current-ready barrier,
mutation of old/current records, bad final identity/hash/terminal values, and
proof the last25+EOF is sent only after all required stale checks. No sockets,
native objects, realFD operations or runner invocation. Retain meaningful
behavioral failures and fixes; no fake product red from a missing module.
Do not repeat unchanged fixture builds or prior pure suites. Report exact
commands/raw results/hash/API/self-review/remaining pass boundaries. This pass
is DONE only when the actual reuse orchestration is complete as scoped; the
full Stage A still awaits disconnect/shutdown/process integration/current closure.
