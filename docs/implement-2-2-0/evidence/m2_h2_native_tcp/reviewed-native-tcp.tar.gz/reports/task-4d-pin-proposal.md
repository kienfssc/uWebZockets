# Proposed enabled-H2 completion pin

Artifact: use the existing warm AsyncState.completing phase as a release pin
for enabled/bound H2 only. Eligibility is checked_upload_owner succeeds, owner
initialized, loop_handle/h2_upload non-null and protocol_state==http2. Scan warm
h2_async_states before upload_storage.claim_close and before owner reset in
release_closed_connection; do not dereference Session/Driver for the scan.

Both existing native close cancellation loops invalidate generations and clear
targets using cancel, then restore completing only when the operation is eligible
and the slot was completing. reset_protocol remains after the release gates;
close_http2_stream keeps its existing pending-only cancellation. Ineligible
legacy/disabled paths retain their prior behavior.

wake_http2_async_response uses the same eligibility and calls upload_tail as its
last connection access. Keep common response code unchanged. Every native target
and outer operation receives the planned complete-operation borrow through its
last post-call use, with batch defers before final finish_borrow. The completing
pin covers the interval after a native leaf returns until the common wrapper's
state update and copied wake.

Contract: no release while target/common completion or its enclosing native
operation still accesses connection-owned storage; once pins drain, close must
continue without an unrelated event. Success and every target error/WouldBlock
retain one-shot completion semantics and exactly one wake after final state.
Old tokens expire when native close invalidates generation. No stored fields,
new cancellation scheduling/backend/timer ordering, startup unbound Session reads
or legacy behavior changes. Native runtime safety remains unproven until review
and later specifically authorized ordinary owned clients; no native experiments
are authorized by this proposal.

Source: /tmp/uwz-task4c-final-frozen (9e4ccd66), native functions unchanged from
aa420. Locations: core/tcp.zig checked_upload_owner/bind_upload_owner2068-2080,
cancel loops2309/3080, upload_tail3097, release_closed_connection2480,
complete_http2_async_response1167-1194, wake1196, close_http2_stream654;
http/response.zig240-256 and timer/outer callers described in existing source.
Review only this pin/eligibility/wake/outer-boundary contract; no broad branch
scan, builds, tests, native fault/cancellation/schedule/socket probes or edits.
