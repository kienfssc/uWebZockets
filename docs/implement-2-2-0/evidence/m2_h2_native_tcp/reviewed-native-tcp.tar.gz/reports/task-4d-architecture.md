# Native H2 completion pin: focused source handoff

Architect /root/architect_h2_session_delivery reviewed immutable aa420 source.
This refines native_tcp_handoff_2026_10_28.md; no code/build/test/native action.
The stack admission fact in Task4c does not alter these native source locations.

The existing completing AsyncState phase supplies a pin without a common API
or stored-layout change. Scan before upload_storage.claim_close (tcp.zig3097)
and before cold-owner reset in release_closed_connection (2480). Eligibility:
checked_upload_owner succeeds; owner initialized; loop_handle and h2_upload
non-null; conn.protocol_state == .http2. Only then inspect warm h2_async_states.
No Session/Driver dereference or warm scan in startup owner_pins_drained.
checked_upload_owner alone checks platform eligibility, not initialization/bind.
Native binding publication2068-2080 validates drained ownership/matching loop;
App initializes/resets H2/async state before publication (1237-1266,1367-1368;
TCP234-237). Preserve those invariants.

Both native cancellation loops2309/3080 must invalidate generation and clear
target while retaining completing for an eligible on-stack completion. Existing
close_http2_stream654 cancels pending only and already preserves completing.
reset_protocol cancellation remains unchanged, after all release gates drain.
Root ruling: apply completing preservation and the new wake/release behavior
only to enabled/bound/H2 eligibility, retaining disabled/unbound behavior. The
legacy owner-null H2 path has no new release proof; do not broaden claims or
silently preserve a legacy phase without its matching lifetime pin.

wake_http2_async_response1196 should recover connection, check the same eligibility,
then call upload_tail as its final connection access. Common response.zig240-256
validates before completing; both target success/error finalize state/clear target
and invoke copied wake. Neither branch accesses owner/context after wake. Keep
one-shot WouldBlock/error semantics. complete_http2_async_response1167-1194 still
needs a whole-operation delivery borrow through send/reset/error handling/logging;
a leaf borrow alone cannot cover the common wrapper's later state write.

Outer source boundaries: timer completion2462-2472 copies completion and clears
slot before token call, only logging saved error afterward. on_sleep_expired_slot
2450-2459 finishes connection work before application resume. timer_wheel285-298
unlinks before callback and never touches that node afterward. Receive/TLS callers
441-444/504-515/556-559 already borrow through post-dispatch work; read wrapper
2963-3000 keeps active flag through activity/rearm. Write wrapper3003-3012 keeps
its flag through inner work and retirement; borrow must cover the entire inner
operation, including post-flush producer/file work. New controls/response adapters
finish all post-target accesses before final finish_borrow. No promise covers
application transport-owned pointers retained after completion.

Stamp supplied H2 first causes in tcp_upload.close402-413 under its existing
borrow before generic close. close_upload_connection3064-3090 publishes closing/
native-cancel flags, stamps absent fallback causes, then aborts/terminalizes inputs.
Fallback stamping precedes callback-capable abort_controller.abort3074; current
cancel follows it. Specific timeout2444-2447, shutdownApp673-675, read EOF/reset/
error2976-2988, TLS EOF/source_failure543-548 win. Read errors need cause-bearing
close before notification; write failures2168-2178 need source_failure. Preserve
existing recorded per-stream cause and deferred cancel/quota release.

Acceptance: actual software-callback completion success/error/WouldBlock and
generation invalidation, exactly one wake with finalized state, expired old token
and original error; actual native helper tests must use caller-owned state and
perform no native I/O or injected completion. Review every borrow's final access,
hook preservation and no stored growth. Later owned native clients require Root
source review and scoped authorization. Original stopped experiments stay stopped.
