# Task4d: native TCP composition for H2 request streaming

Read this first: exact requirements. Baseline is immutable
/tmp/uwz-task4c-final-frozen,1029 regular files,
9e4ccd66b9b4c888b97d2d8d39c7f25d700e6d3fe0302ddcf257bb789829d116.
Task4c reviewed/pushed in Root9f0522d5500c5b867162a5b219a507955ad86930.
Verify inventory, copy to a new /tmp candidate, never mutate baseline or Root.

Read native_tcp_handoff_2026_10_28.md under .uwz-work/evidence/h2-streaming and
task-4d-architecture.md, task-4d-pin-proposal.md and task-4d-pin-review.md beside
this brief. They supply exact native caller locations and source obligations;
Task4b's explicit credit_abandoned marker supersedes any earlier closed/no-ID
approximation. Fresh Root adversarial review found no actionable plan disproof;
its remaining conditions must be verified on the actual implementation.

Own seven candidate paths: core/tcp.zig, core/tcp_upload.zig,
core/http1_upload_storage.zig, new core/tcp_http2_upload.zig, test_support.zig,
new tests/tcp_http2_upload_tests.zig and tests/main.zig, all under src/.
The new focused centralized test file/import/export replaces a proposed addition
to the oversized driver fixture: completion-helper coverage is a separate concern.
Do not edit driver/Session/common Response/Router/App/config/TLS/backend/timer
policy or dependency pins. Surface a concrete interface conflict before expanding
ownership. You are not alone; no reverting other work, subagents, commits, pushes,
refs, maintained publication or fetches. Main owns review/adversarial passes.

## Native adapter and response construction

Use existing cold conn.upload_owner.h2_upload, stable Session/connection/slot
binding and Router target. Connect enabled body selection/event/control callbacks.
For head, copy the stack event and derive early_data_forbidden from the existing
connection TLS/method policy (canonical method conversion); never trust a client
header as that fact. No new TLS policy, retained factory or stored pointer.
Use Driver.selects/event and slot-backed BodyControlTarget. Recover connection
from slot.owner.context; resume/cancel retain actual Session terminal/activity/
error handling. No connection-wide read pause for a paused H2 stream.

Extract existing complete dispatch_http2_request Response construction and reuse
it for buffered dispatch/body events, preserving every end/begin/write/finish/
abort/producer/file/compression hook. A returned value must not borrow helper-
local storage. Preserve step_http2_stream's deliberately restricted producer
Response. Enabled buffered dispatch binds indexed capture overflow matrices too.
Do not change the Router context or alias per-stream metadata across siblings.

Before native status/producer/file/async/output ownership mutations, reject native
closing or missing identity and recheck identity after callback-capable operations
when later writes depend on it. Do not blanket reject Session.closed: ordinary
GOAWAY still allows valid pending output. Retired closed events MUST reach Driver
cleanup/cancel/quota; do not suppress them merely because the identity retired.
Build callback-local Response without clobbering borrowed native stream state.

## Complete-operation borrows and asynchronous completion

Apply the exact borrow extents in the handoff: existing receive/TLS outer borrows
remain; on_write_complete_inner covers flush_pending AND all later producer/file/
backpressure work. Cover every native response end/begin/write/finish/abort,
begin stream/file/pump, sleep/sleep-complete/async complete, and body resume/cancel
through their last post-call/status/error/log access. Batch/write cleanup defers
run before final finish_borrow. finish_borrow may recycle conn: copy results first
and perform no later conn/slot/owner/borrowed-data access. Preserve read/write
wrapper active flags until their existing final tails and native retirement ACKs.

Implement the pin proposal with precise eligibility: checked eligible owner,
initialized, loop_handle and h2_upload non-null, protocol_state http2. Warm
h2_async_states.completing scan belongs before claim_close and before cold-owner
reset/release; no Session/Driver reads and none in startup owner_pins_drained.
Eligibility/attachment/init/protocol cannot change while completing. Preserve
completing after cancel invalidates generation/target in both native close loops
ONLY for eligible enabled/bound H2. Ineligible legacy behavior stays unchanged.
Keep pending-only stream cancellation and reset_protocol ordering as specified.

The existing common wrapper publishes completed/clears target then calls copied
wake on BOTH success and every target error, including WouldBlock. Keep its
one-shot/error semantics. Native H2 wake checks the same eligibility then invokes
upload_tail as its last connection access; no unrelated event or retained bridge.
Leaf borrows alone cannot protect the common wrapper's later state write. Prove
all outer caller post-access boundaries in a source table; legacy owner-null
H2 lifetime is outside this scoped proof and must not be claimed repaired.

## Close, drain and reuse

Publish native closing/cancellation intent and stamp first causes before generic
abort or callback-capable close effects. tcp_upload.close records H1/H2 supplied
causes under its borrow. Invoke Session.close_body_inputs before final release;
cancel/quota/metadata cleanup remains once-only and deferred through live callbacks.
Preserve native async/producer/file/cancellation ordering and the completion pin.
Specific shutdown/timeout/EOF/reset/source_failure wins over fallback cancelled.
Classify ordinary read/write/Session output failures through cause-bearing entry
points; never overwrite a recorded stream cause. Keep the genuine SSL_in_init
early EOF abort/open boundary and existing TLS batching unchanged.

Cold owner_pins_drained uses Driver.is_drained; reset uses reset_drained only
after caller-owned Session/response/native quiescence is separately proved.
Preserve associations and generations, no accept-time rebind. Existing reset
assertions are not weakened. Any catch unreachable needs an explicit proof from
same-loop preflight/no intervening callbacks. No new stored fields, capacities,
pool/window growth or startup-disabled layout change is authorized.

## Verification and evidence

Use meaningful caller-owned tests for the actual new invariant helper, not a
reimplementation. If central test access needs an internal module export, the
allowed test_support path supplies it. Cover completion success, target error and
WouldBlock, generation invalidation during software completion, exactly one wake
after final state/cleared target, expired old token, unchanged error result and
disabled behavior. Native I/O, native callbacks/completions or kernel handles
must not be fabricated/injected. An extracted prior cancellation operation may
provide the real behavioral red before phase preservation; declaration failure
is not a behavioral red. Record source/commands/raw hashes before claiming it.

Freeze source for covering Debug/ReleaseSafe roots: new pure helper suite,
driver40, H1 admission7/head12/driver30, H2 refusal15/server40 exact 'http2 server:'
filter, frames17/HPACK8/queue9/width2, config3 and ONLY these eight healthy App
filters: body App: streaming config defaults off; enabled slab contains typed
owners; startup stays unarmed; registration copies path; disabled registration
and limits; middleware policy registration; null upload detach; pure body registry.
Use exact existing full filter strings from prior records, not broad 'body App:'.
Full central native/macOS/Windows semantic compilation, eligible32 selected/
queue/matrix compilation and actual3OS layout/slab/offset comparisons cover source
portability/no growth. Full-driver32 remains limited. Static fmt/conventions/
release/docs and identical-copy Graphify AST refresh are required. Root retains
all original full milestone gates; do not weaken a test, assertion or backend.

No native/live server/client activation in this implementation task. Full native
runtime, sanitizer runtime, live h1spec and stopped EPERM/native experiments stay
unrun. No new native cancellation schedules/races/resource/kernel-error/invalid-fd/
injected-completion/panic probes. Later ordinary owned H2/TLS clients require Root
source review and a separate precise authorization. No native safety/100MB/full-M2
claim follows from pure tests or compilation.

Evidence: .uwz-work/evidence/h2-streaming/native-tcp/. Persist small latest working
changed-file snapshots/inventory there at milestones or before any context request;
/tmp may disappear across goal turns. All heavy source copies/cache/binaries stay
/tmp. Preserve genuine intermediate failures, final preimages/finals, complete
source inventory, reconstruction patch, exact source/compiler/module/library/
override/environment/binary identities and immediate raw-log hashes. Use stable
workspace c bindings, zig-out/lib, zig-pkg/zslay and the reviewed93-file c223
override; never relabel an old command as a new source run. Absolute Graphify with
PYTHONPATH is in prior task. Report complete commands/outcomes, borrow table,
guard/hook/cause/reset/phase proofs, measurements and limits to task-4d-report.md
before requesting review. Return concise status/artifact paths/digest only.

Graphify query before new codebase search if graph exists; supplied source paths
and prior handoff locations are located. No broad inventory/tool-output dumps.
