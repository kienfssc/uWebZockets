# Task4d fix round1/5: reset-output failure cause

Read the finding verbatim below; it is required by the existing first-cause
contract, not a plan change. Root re-read SDD fix-loop before this round.
Same implementer, no restart: preserve immutable final8f2da41b/source inventory,
all old reports/patches/records/reviews and Root review package. Own only the
three core/tcp.zig error catches in a new candidate derivative.

P2 — Preserve source-failure causes when an H2 reset fails. tcp.zig1029,
also1264 and1283: these catches still call generic close_connection. With
streamed siblings A and B active, aborting A can retire A and then fail while
flushing its RST_STREAM, for example with TlsWriteFailed. Generic close stamps
B's previously unset cause as cancelled, violating required source_failure.
Route failure closes through tcp_upload.close(self,.source_failure), retaining
already-recorded causes.

Change these abort/sleep reset-failure call sites only, preserving whole-operation
borrows, defer/final-access boundaries, guards, phases, return/error semantics,
all native cancellation/socket/timer ordering and prior first-cause wins. No API,
fields, capacities, protocol policy or unrelated cleanup. No Root source edits,
subagents, commits/refs/fetches, clients, native/stopped/fault probes or fake reds.

This is source-path classification; do not invent native error injection to
manufacture a behavioral red. Existing caller-owned coverage files are
tcp_http2_upload_tests, http2_upload_driver_tests, http1_upload_driver_tests and
http1_upload_admission_tests: run these covering roots in Debug/ReleaseSafe on
new frozen source. Compile central native/macOS/Windows, run fmt/conventions/
version/docs and identical-copy AST refresh. No need for unchanged parser/HPACK/
queue/config broad reruns absent a new concern. Old layout evidence may be reused
ONLY with the exact three-callsite diff and unchanged type/field/carve proof,
clearly retaining its actual8f2da41b source; never relabel old runs.

Save new evidence under native-tcp/fix1, with preimage/final inventories, scoped
patch, full reconstruction and immediate command/source/input/binary/log hashes.
Persist small snapshots in workspace; heavy files stay/tmp. Append the fix report
to the existing native-tcp/task-4d-report.md and preserve its old bytes as preimage.
Leave SDD's initial report copy and root-review-package.json unchanged so their
historical hashes remain resolvable. Give Root exact covering commands/outcomes
BEFORE re-review. Root will re-review fix diff/new breakage only with both existing
reviewers; original full native/milestone gates remain open.
