# Task 4d fix round 1

Frozen preimage: `/tmp/uwz-task4d-final-freeze`, inventory `8f2da41b42824376c1637599791b2421cec6a9d7dfc70f7d8b6b731d162eecae`. Frozen derivative: `/tmp/uwz-task4d-fix1-frozen`, inventory `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`. The only changed file is `src/core/tcp.zig`; `fix.patch` contains exactly three call-expression substitutions. The prior report bytes are preserved in `task-4d-report-preimage.md` (SHA-256 `1b7764d03718aa7e49da0e5e35a0749a8ab5291d4a126e8004fd7b11c12e0ebc`). Prior inventories, patch, source, SDD copy and Root package remain unchanged.

At abort reset failure and both sleep reset failures, the catch now invokes `tcp_upload.close(self, .source_failure)` instead of generic close. That existing function stamps the supplied H2 cause only where absent and claims the H1 first cause before initiating close. The existing delivery borrows, defers, guards, terminal/error behavior and native cancellation and timer ordering are untouched. Already-recorded stream causes remain first. No native error injection, client, cancellation schedule, fault or fabricated red was used; this is a source-path classification fix.

`layout-proof.json` records that no type, field or carve declaration changed. The existing measured layout comparisons remain attributed to source `8f2da41b`; they were not rerun or relabelled. `reconstruct.json` records the exact patch command, successful exit and full reconstructed inventory match. Initial proof attempt failed only because its comparison assumed equal indentation; `reconstruct-attempt1.log` records the failure and corrected normalized expression check. Source and binary identities, c bindings, reviewed 93-file override and environment are recorded under `inputs.json` and the per-command JSON files. The first completed Debug and semantic records used shared content-addressed caches and are preserved under `shared-cache-intermediate/`; their test run was intentionally interrupted with exit 130. Current covering rerun uses separate Fix 1 cache and binary paths.

The exact command arguments, cwd, source digest and immediate output hashes are in `*-Debug.json`, `*-ReleaseSafe.json`, `compile-central-*.json`, `fmt.json`, `conventions.json`, `version.json`, `docs.json` and `graphify.json`. Full native and milestone gates remain Root-owned; no native lifetime safety or 0-RTT claim follows.

All covering runs below compiled and exited successfully from the final derivative; exact arguments, source, binary and raw-log hashes are in `covering-commands.json` and the individual records.

| Root | Debug | ReleaseSafe |
| --- | --- | --- |
| tcp_http2_upload_tests | All 2 tests passed. | All 2 tests passed. |
| http2_upload_driver_tests | All 40 tests passed. | All 40 tests passed. |
| http1_upload_driver_tests | All 30 tests passed. | All 30 tests passed. |
| http1_upload_admission_tests | All 7 tests passed. | All 7 tests passed. |

Central native, macOS and Windows semantic compilation passed; fmt, conventions, release-version, docs and identical-copy Graphify AST refresh passed. The 3-OS old layout evidence remains tied to the preimage.
