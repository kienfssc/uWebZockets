# Task 4d native H2 candidate

Unreviewed candidate `/tmp/uwz-task4d-final-freeze`: 1,031 regular files, inventory SHA-256 `8f2da41b42824376c1637599791b2421cec6a9d7dfc70f7d8b6b731d162eecae`. The immutable 1,029-file baseline hashes to `9e4ccd66b9b4c888b97d2d8d39c7f25d700e6d3fe0302ddcf257bb789829d116`. Only the seven authorized paths differ; `snapshot-latest/`, preimages, `candidate.patch`, `reconstruction.json` and both inventories preserve the candidate. Applying the patch to a fresh baseline reproduces its complete inventory (`reconstruct-check.json`). Root source, refs and baseline were not changed.

The caller-owned software async cancellation regression was run first against extracted original `state.cancel`: compilation succeeded, the completing-pin assertion failed, and disabled behavior passed (`red.json`, `red-run.log`, `snapshot-red/`). The helper then passed success, target error and WouldBlock cases, generation invalidation, one wake after final state/cleared target, expired old token and disabled behavior (`green.json`, `green-run.log`). These are software callbacks, not native completion injection.

## Composition and source obligations

The bound H2 Driver selects heads and receives stack-copied events, with `early_data_forbidden` derived from `early_data_forbids` and canonical method parsing. Streamed heads increment the existing conditional HTTP request counter. Slot-backed controls recover the connection through the stable driver context. Resume and cancel call Session operations without pausing the connection, and resume saves connection closure/error before final borrow release. Buffered and event dispatch share the extracted full Response construction, retaining end, begin, write, finish, abort, producer, file and compression hooks. Producer-step Response stays restricted. Bound buffered dispatch uses indexed capture matrices.

Output/status/producer/file/async targets guard closing or missing stream identity. Begin response/stream/file recheck identity and close intent after callback-capable begin before native state writes; ordinary Session.closed is not a blanket guard. Retired closed events still enter Driver cleanup. No new stored fields, capacities or native completion storage were added.

Completing pin eligibility requires checked owner, initialized, loop handle and H2 driver non-null, and HTTP/2 protocol. The scan reads only warm async states, before both close claim and cold reset, and is not part of startup owner drain. Both native close loops cancel generation/target and preserve completing only under this eligibility; stream close remains pending-only; reset_protocol remains after release. Common wrapper retains original one-shot semantics and finalizes/clears before copied wake, including errors. Eligible wake calls upload_tail as its final connection access. No legacy owner-null lifetime proof is claimed.

Close publishes intent and cancellation flags, stamps H2 fallback and captures H1 fallback terminal before abort callbacks; terminal callback remains after abort under delivery borrow. tcp_upload.close stamps supplied H2 cause and claims H1 cause before native close. Session.close_body_inputs runs on enabled H2 close, leaving active callback cleanup deferred by Session. Existing cause values are never overwritten: timeout, shutdown, EOF/reset and source failure use cause-bearing paths; TLS clean EOF stamps peer_closed. Driver.is_drained gates cold ownership; reset_drained follows same-loop drained preflight, with associations/generations preserved. Release flags, timer/async/producer/file ordering, socket close branches and retirement acknowledgements remain in their existing framework.

Pre-review audit corrections, each preserved as its own intermediate inventory/log directory: post-callback close_when_drained guard (`pre-guard-verification`); resume closure propagation (`pre-resume-verification`); H1 fallback stamping before abort (`pre-cause-verification`); streamed request counter (`pre-metrics-verification`). Interrupted runs are marked and not counted as final evidence. No native red or probe was invented.

## Last-access source table, subject to independent review

| Operation | Last access and boundary |
| --- | --- |
| TLS process, plaintext drain and decrypted route (tcp 444, 507, 562) | Existing outer borrows cover BIO, receive, dispatch and post-dispatch work; batch defers run before finish_borrow. |
| H2 receive (604) | Inherits decrypted-route borrow through Session receive, close handling and producer pump. |
| H2 event (642) | Response and slot control are callback-local; enclosing Session receive, close or control operation retains its borrow through return. |
| Body resume/cancel (660, 677) | Session, terminal/error, activity and saved result precede final finish_borrow; no later connection or slot access. |
| Response end/begin/write/finish/abort (962, 982, 1002, 1022, 1033) | Borrow spans Session and status/error/log accesses; begin rechecks identity before status write. |
| Producer/file/pump (1054, 1081, 1202) | Borrow spans producer, state and cleanup; file batch defer executes before final finish. |
| Async sleep and completion target (1241, 1269, 1288) | Borrow spans park/reset/error/log handling; completing pin separately covers common wrapper's later state write. |
| Common async wrapper and wake (response 240–256; tcp 1319) | Wrapper publishes completed and clears target before copied wake on success and every error; wake's final connection use is upload_tail. |
| Write inner and wrapper (2292, 3151) | Inner borrow covers flush and later producer/file/backpressure work; wrapper retains active flag through retirement request and final tail. |
| Read wrapper (3114) | Active flag holds through result, receive, activity and rearm; retirement precedes final tail. |
| Timer delayed completion (tcp on_sleep_expired_slot/on_delayed_completion; timer_wheel 285–298) | Slot copied/cleared before token completion; afterward only saved error is logged. Wheel unlinks before callback and does not revisit node. |
| Close/release (3212, 3247, 2625) | Intent and first causes precede abort; completion scan precedes claim_close and owner reset; delivery borrow spans close work. |

## Verification

Full commands, source digests, raw log hashes, compiler/module/library identities, override manifest, environment and binary hashes are in the per-command JSON records and `inputs.json`; scripts `verify.py`, `compile.py`, `static_checks.py` and `measure.py` reproduce the command sets. Results below are filled only from this final freeze. Test and compilation runs do not constitute native runtime safety evidence.

- Semantic compilation: central Linux, macOS and Windows, and selected/queue/matrix 32-bit builds passed (`compile-*.json`). Full-driver 32-bit remains outside this scope.
- Static verification: `zig fmt --check src builds examples tests fuzz`, `sh scripts/check_conventions.sh`, `sh scripts/check_release_version.sh`, and `sh scripts/check_docs.sh` passed. The Graphify AST update on an identical copied source passed and source inventory matched (`graphify.json`).
- Layout: actual compiler-log type/slab/offset outputs for Linux, macOS and Windows match the baseline (`layout-comparison.json`); these intentional compile-log probes exit 1. There is no throughput benchmark or performance improvement claim.
- The Root-owned full build, native runtime, sanitizer runtime, live h1spec and original stopped experiments remain unrun here. No socket, native client, native completion injection, resource fault or cancellation schedule was executed. Native lifetime safety, 100 MB transfer, and full milestone completion remain unproven pending Root independent source review and separately authorized ordinary owned clients.
- Genuine authenticated `SSL_in_init` early EOF remains an abort/open boundary; this work does not establish a 0-RTT native result. Existing TLS batching was preserved. Owner-null legacy H2, physical cancellation order, and native reuse remain outside the scoped proof.

Approved focused software roots, both modes from the final source:

| Root | Debug | ReleaseSafe |
| --- | --- | --- |
| tcp_http2_upload_tests | All 2 tests passed. | All 2 tests passed. |
| http2_upload_driver_tests | All 40 tests passed. | All 40 tests passed. |
| http1_upload_admission_tests | All 7 tests passed. | All 7 tests passed. |
| body_h1_head_tests | All 12 tests passed. | All 12 tests passed. |
| http1_upload_driver_tests | All 30 tests passed. | All 30 tests passed. |
| body_h2_refusal_tests | All 15 tests passed. | All 15 tests passed. |
| http2_server_tests | All 40 tests passed. | All 40 tests passed. |
| http2_tests | All 17 tests passed. | All 17 tests passed. |
| http2_hpack_tests | All 8 tests passed. | All 8 tests passed. |
| http2_body_queue_tests | All 9 tests passed. | All 9 tests passed. |
| body_h2_width_tests | All 2 tests passed. | All 2 tests passed. |
| config_tests | All 3 tests passed. | All 3 tests passed. |
| body_app_tests | All 8 tests passed. | All 8 tests passed. |

The server root used the exact `http2 server:` filter; the App root used only the eight named filters in `body_app_tests-*.json`. All 26 compilations and runs exited 0. No full central test runtime was executed.


---

# Task 4d fix round 1

Frozen preimage: `/tmp/uwz-task4d-final-freeze`, inventory `8f2da41b42824376c1637599791b2421cec6a9d7dfc70f7d8b6b731d162eecae`. Frozen derivative: `/tmp/uwz-task4d-fix1-frozen`, inventory `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`. The only changed file is `src/core/tcp.zig`; `fix.patch` contains exactly three call-expression substitutions. The prior report bytes are preserved in `task-4d-report-preimage.md` (SHA-256 `1b7764d03718aa7e49da0e5e35a0749a8ab5291d4a126e8004fd7b11c12e0ebc`). Prior inventories, patch, source, SDD copy and Root package remain unchanged.

At abort reset failure and both sleep reset failures, the catch now invokes `tcp_upload.close(self, .source_failure)` instead of generic close. That existing function stamps the supplied H2 cause only where absent and claims the H1 first cause before initiating close. The existing delivery borrows, defers, guards, terminal/error behavior and native cancellation and timer ordering are untouched. Already-recorded stream causes remain first. No native error injection, client, cancellation schedule, fault or fabricated red was used; this is a source-path classification fix.

`layout-proof.json` records that no type, field or carve declaration changed. The existing measured layout comparisons remain attributed to source `8f2da41b`; they were not rerun or relabelled. `reconstruct.json` records the exact patch command, successful exit and full reconstructed inventory match. Initial proof attempt failed only because its comparison assumed equal indentation; `reconstruct-attempt1.log` records the failure and corrected normalized expression check. Source and binary identities, c bindings, reviewed 93-file override and environment are recorded under `inputs.json` and the per-command JSON files. The first completed Debug and semantic records used shared content-addressed caches and are preserved under `shared-cache-intermediate/`; their test run was intentionally interrupted with exit 130. Current covering rerun uses separate Fix 1 cache and binary paths.

The exact command arguments, cwd, source digest and immediate output hashes are in `*-Debug.json`, `*-ReleaseSafe.json`, `compile-central-*.json`, `fmt.json`, `conventions.json`, `version.json`, `docs.json` and `graphify.json`. Full native and milestone gates remain Root-owned; no native lifetime safety or 0-RTT claim follows.

All covering runs below compiled and exited successfully from the final derivative; exact arguments, source, binary and raw-log hashes are in `covering-commands.json` and the individual records.

| Root | Debug | ReleaseSafe |
| --- | --- | --- |
| tcp_http2_upload_tests | All 2 tests passed. | All 2 tests passed. |
| http2_upload_driver_tests | All 40 tests passed. | All 40 tests passed. |
| http1_upload_driver_tests | All 30 tests passed. | All 30 tests passed. |
| http1_upload_admission_tests | All 7 tests passed. | All 7 tests passed. |

Central native, macOS and Windows semantic compilation passed; fmt, conventions, release-version, docs and identical-copy Graphify AST refresh passed. The 3-OS old layout evidence remains tied to the preimage.
