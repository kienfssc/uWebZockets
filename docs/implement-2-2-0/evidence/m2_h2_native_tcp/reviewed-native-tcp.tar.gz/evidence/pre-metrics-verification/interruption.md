Suite interrupted with SIGINT (exit 130) after audit found streamed H2 head events bypassed the existing request counter. Buffered in-progress output unavailable and not counted.
