Suite interrupted with SIGINT (exit 130) after source audit found H1 fallback cancellation recorded after abort. Buffered in-progress output unavailable and not counted.
