const std = @import("std");
const support = @import("test_support");
const response = support.http_response;
const native = support.tcp_http2_upload;

const Fixture = struct {
    state: response.AsyncResponseState = .{},
    wakes: usize = 0,
    pinned: bool = false,
    finalized: bool = false,
    failure: ?anyerror = null,

    fn complete(context: *anyopaque, _: []const u8, _: []const u8, _: []const u8) anyerror!void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        native.cancel_async(&self.state, true);
        self.pinned = self.state.state == .completing and self.state.target == null;
        if (self.failure) |err| return err;
    }

    fn wake(context: *anyopaque) void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        self.wakes += 1;
        self.finalized = self.state.state == .completed and self.state.target == null;
    }
};

test "native H2 async completion preserves pin and wakes after final state" {
    for ([_]?anyerror{ null, error.TargetFailure, error.WouldBlock }) |failure| {
        var fixture = Fixture{ .failure = failure };
        const token = fixture.state.arm(.{ .context = &fixture, .complete_fn = Fixture.complete, .wake_fn = Fixture.wake });
        if (failure) |err| {
            try std.testing.expectError(err, token.complete("200 OK", ""));
        } else {
            try token.complete("200 OK", "");
        }
        try std.testing.expect(fixture.pinned);
        try std.testing.expect(fixture.finalized);
        try std.testing.expectEqual(@as(usize, 1), fixture.wakes);
        try std.testing.expectError(error.AsyncResponseExpired, token.complete("200 OK", ""));
    }
}

test "native H2 async cancellation keeps disabled behavior" {
    var state = response.AsyncResponseState{ .state = .completing, .generation = 4 };
    native.cancel_async(&state, false);
    try std.testing.expectEqual(response.AsyncState.cancelled, state.state);
    try std.testing.expectEqual(@as(u64, 5), state.generation);
    try std.testing.expect(state.target == null);
}
