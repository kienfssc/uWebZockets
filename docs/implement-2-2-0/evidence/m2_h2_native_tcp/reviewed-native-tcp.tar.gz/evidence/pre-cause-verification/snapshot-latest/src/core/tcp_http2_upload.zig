const response = @import("../http/response.zig");

/// Invalidates a native async response during connection close.
pub fn cancel_async(state: *response.AsyncResponseState, eligible: bool) void {
    const completing = eligible and state.state == .completing;
    state.cancel();
    if (completing) state.state = .completing;
}
