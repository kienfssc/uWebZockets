# Task4d lifetime review of 8f2da41b

Reviewer /root/review_h2_native_tcp_lifetime, read-only.
Spec verdict: request changes.

P2: preserve source_failure when an H2 reset fails, core/tcp.zig1029-1030,
1264-1265 and1283-1284. These catches call generic close_connection. With streamed
siblings A/B, abort A can retire A and then fail flushing RST_STREAM with e.g.
TlsWriteFailed. Generic close stamps B's unset cause cancelled instead of required
source_failure. Route failure closes through tcp_upload.close(self,.source_failure)
while retaining already-recorded causes.

Quality verdict: no independent structural blocker under1000-line override.
TCP grows3170->3324 lines; shared Response construction removes duplication and
the cancellation helper earns its phase-preservation invariant. No actionable
dramatic simplification found. No additional actionable finding in complete-
operation borrows, defers, both cancel loops/release gates, copied success/error/
WouldBlock wake, wrappers/timer callers or cold drain/reset. Actual binding/reuse
callers preserve eligibility while completing.

No checks/runtime actions. Full native/sanitizer/live h1spec, legacy owner-null
lifetime, physical cancellation/reuse and stopped experiments remain unverified.
