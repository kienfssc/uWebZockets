import hashlib,json,pathlib,shutil,subprocess,os
E=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-tcp')
H=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-terminal/fix1')
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
records=[]
for variant, source in [('before',pathlib.Path('/tmp/uwz-task4c-final-frozen')),('after',pathlib.Path('/tmp/uwz-task4d-final-freeze'))]:
 acc=pathlib.Path('/tmp/uwz-task4d-final-freeze-accounting-'+variant)
 if not acc.exists(): shutil.copytree(source,acc)
 p=acc/'src/router/config.zig'; s=p.read_text(); assert s.count('fn layout_offsets(config: ServerConfig)')==1
 p.chmod(0o644); p.write_text(s.replace('fn layout_offsets(config: ServerConfig)','pub fn layout_offsets(config: ServerConfig)'))
 for osname in ['linux','macos','windows']:
  for kind in ['layout','offsets']:
   template=json.loads((H/f'measure-{kind}-{osname}-after.json').read_text())
   argv=template['argv'][:]
   argv=[('-Mroot='+str(E/(kind+'.zig'))) if x.startswith('-Mroot=') else ('/tmp/uwz-task4d-layout-cache' if x=='/tmp/uwz-task4b-artifacts/cache' else '/tmp/uwz-task4d-layout-global' if x=='/tmp/uwz-task4b-artifacts/global' else x) for x in argv]
   cwd=source if kind=='layout' else acc
   result=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   log=E/f'{kind}-{osname}-{variant}.log'; log.write_bytes(result.stdout)
   rec={'argv':argv,'cwd':str(cwd),'exit':result.returncode,'log_sha256':sha(log),'helper_sha256':sha(E/(kind+'.zig')),'source_tree': '9e4ccd66b9b4c888b97d2d8d39c7f25d700e6d3fe0302ddcf257bb789829d116' if variant=='before' else '8f2da41b42824376c1637599791b2421cec6a9d7dfc70f7d8b6b731d162eecae','accounting_config_sha256':sha(p) if kind=='offsets' else None}
   (E/f'{kind}-{osname}-{variant}.json').write_text(json.dumps(rec,indent=2)+'\n')
   print(kind,osname,variant,result.returncode,'compile log',b'Compile Log Output:' in result.stdout,flush=True)
   records.append(rec)
(E/'environment.json').write_text(json.dumps({k:os.environ.get(k) for k in ['PATH','LANG','LC_ALL','ZIG_GLOBAL_CACHE_DIR']},sort_keys=True,indent=2)+'\n')
