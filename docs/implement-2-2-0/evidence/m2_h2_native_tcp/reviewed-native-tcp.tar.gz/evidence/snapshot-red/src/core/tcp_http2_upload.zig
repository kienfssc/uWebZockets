const response = @import("../http/response.zig");

/// Invalidates a native async response during connection close.
pub fn cancel_async(state: *response.AsyncResponseState, _: bool) void {
    state.cancel();
}
