#!/usr/bin/env python3
"""Capture pinned-client source facts without opening a connection."""
import hashlib
import inspect
import json
from pathlib import Path
import aioquic
import aioquic.h3.connection as h3
import aioquic.quic.packet as packet
import aioquic.quic.logger as logger

base=Path(__file__).resolve().parent
summary={
 'aioquic_version':aioquic.__version__,
 'setting_values':{value.name:hex(value.value) for value in h3.Setting if any(name in value.name for name in ('WEBTRANSPORT','DATAGRAM','CONNECT'))},
 'reset_frame_values':{value.name:hex(value.value) for value in packet.QuicFrameType if 'RESET' in value.name},
 'transport_parameter_fields':list(packet.QuicTransportParameters.__dataclass_fields__),
 'module_sources':{},
 'scope':'Source inspection only. No client connection, native build, behavior test, or runtime adaptation.'}
for module in (h3,packet,logger):
 path=Path(module.__file__)
 summary['module_sources'][module.__name__]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(base/'pinned_client_source.json').write_text(json.dumps(summary,indent=2)+'\n')
(base/'pinned_client_excerpts.txt').write_text(inspect.getsource(h3.H3Connection._get_local_settings)+'\n'+inspect.getsource(logger.QuicLoggerTrace.encode_transport_parameters))
print(json.dumps(summary,indent=2))
