# Roadmap and Boundaries

This page is the honest map of what µWebZockets does, what it deliberately does
not do, and why. It exists so a developer can decide whether a missing feature
is a defect, a scoped decision, or pending work.

## Closed in 1.7.0

| Boundary | Resolution |
| --- | --- |
| No client API | Bounded HTTP/1.1 client over TCP and TLS with fixed slots, timeouts, and loopback tests ([client.md](client.md)) |
| No mutual TLS | `init_https_mtls` with `none` / `optional` / `required` verification against a caller CA bundle ([tls.md](tls.md#client-certificates-mtls)) |
| No auth or rate limiting | `middleware.Auth` (Basic/Bearer, constant-time) and `middleware.RateLimit` (fixed token buckets, rotation-resistant) ([http.md](http.md#middleware)) |
| No graceful shutdown helper | `App.catch_shutdown_signals()` and `Cluster.catch_shutdown_signals()` for SIGINT/SIGTERM and Windows console control |
| HTTP/2 and HTTP/3 were invisible in the dev log | One `http_request` record per completed exchange on both, plus HTTP/2 counter increments |
| Docs could drift | `scripts/check_docs.sh` validates every relative markdown link in CI |
| Stale supported-version policy | [SECURITY.md](../SECURITY.md) tracks the latest released minor line |
| Monolithic protocol documentation | Split into [http.md](http.md), [http2.md](http2.md), [quic.md](quic.md), [websocket.md](websocket.md), and [json_rpc.md](json_rpc.md) |

## Closed in 1.9.0

The 1.9.0 milestone closes or re-declares every limit from the 1.8.5/1.8.9
declared-limits handoff. The full measurement record is in
[`benchmarks/results/h2_tls_scaling_v1/2026_10_19/`](../benchmarks/results/h2_tls_scaling_v1/2026_10_19/README.md).

| Limit | Resolution |
| --- | --- |
| L1a No 256/1,024-connection H2-over-TLS run | Closed with the full 64-2,048 sweep on the repository host. The 4-worker TLS cluster completed 30/30 samples with zero failures; 1,024 connections reached 276,534.80 req/s at one stream and 669,300.80 at eight. Artifacts and host caveats are linked above |
| L4 MemorySanitizer scope | Closed as Option A: the dependency-boundary smoke is the permanent contract, dated 2026-10-19 ([CI_CD_PIPELINE.md](../CI_CD_PIPELINE.md#memorysanitizer-contract-permanent-2026-10-19)) |
| L5 `Cluster.request_shutdown` after `deinit` | Closed docs-only with an explicit internal guard, a call-site doc comment, and a regression test; no public getter was added for that no-op ([ADR 0003](adr/0003-tls-cluster-operational-boundaries.md)). The separate 2.1.5 lifecycle getter is recorded in [ADR 0007](adr/0007-cluster-lifecycle-and-failures.md) |
| L6 TLS credential rotation | Closed as a dated decision: rolling restart remains the supported path; no hot reload ([ADR 0003](adr/0003-tls-cluster-operational-boundaries.md)) |
| L7 Backend stickiness and internal `xev` | Closed as a dated decision: selection is process-sticky, `xev` stays internal, and backend introspection needs an ADR ([architecture.md](architecture.md#event-loop-and-completions)) |
| L8 Shared-port TLS test flake | Closed after repeated focused and full-suite runs stayed green; the eight-reservation scheme remains |
| L9 Cross-worker session resumption | Closed as measured and accepted for the target workload: 1 worker reused 100/120 handshakes, 4 workers reused 23/120, which is the expected per-worker ticket behavior ([ADR 0003](adr/0003-tls-cluster-operational-boundaries.md)) |
| L10 HTTP/2 window tuning | Closed as measured, not needed: the sweep showed worker-count scaling and no timeout, failure, or write-queue stall; no window constants changed |
| L12 Post-merge provenance | v1.8.9 tag `v1.8.9` exists at `2573661d12e573d00ed0036736a68d34955c1339`, `main` is green, and a clean-clone test with an empty cache is archived. The v1.9.0 tag remains maintainer-owned after merge |

## Re-declared in 1.9.0

| Limit | Dated reason and restoration criterion |
| --- | --- |
| L1b HttpArena `baseline-h2` | The adapter and official `/benchmark` run live in `MDA2AV/HttpArena`, which this repository cannot modify or trigger. Restore only after an adapter PR uses the public cluster API, a released tag works from a clean dependency cache, and the official run saves fresh nonzero 256/1,024-connection results |
| L3b / L13 Windows runtime | The auditable libxev accept overlay and the queued-completion submit-before-cancel fix landed, and `windows.yml` now has a native `zig build test --summary all` job. Windows becomes officially supported when that job is green for the release commit; until then the compile gate remains the claim ([ADR 0004](adr/0004-windows-iocp-accept-and-queued-close.md)) |
| L11 H2/TLS benchmark in GitHub Actions | Deliberate exclusion: shared runners cannot satisfy the quiet-host evidence contract. The contract stays out of `benchmark.yml`. A future dedicated quiet runner may add a non-gating `workflow_dispatch` job that uploads raw artifacts and never compares its numbers to shared runners |

## Closed in 2.0.0

The 2.0.0 milestone removes write-amplification and startup races without
changing the cluster lifecycle. Performance numbers in the release checklist
remain evidence-gated; a quiet-host rerun is a 2.1.0 carry-over rather than a
claim.

| Task | Resolution |
| --- | --- |
| P-1 Multi-core scaling | The shipped `build_cluster` / `enable_https` path is unchanged; every worker still owns one `SSL_CTX` and one loop. No second cluster abstraction or shared TLS state was added |
| P-2 Uncapped worker scaling | `worker_count` is a compiled capacity. `ClusterOptions.worker_count` selects an explicit count, and `build_cluster_from_environment` prefers that option, then `UWEBZOCKETS_WORKERS`, then the platform CPU count. Active workers alone allocate slabs, inboxes, and thread handles; the previous fixed dispatch list and 32-worker concern are gone |
| P-3 HTTP/1.1 pipelining | Every complete request in one read is dispatched in order. Multi-request reads append responses to the bounded ring and flush once; a lone request keeps the direct `sendmsg` path |
| P-4 WebSocket batching | Unmasking uses the widest compiled vector (128-bit baseline, 256-bit AVX2) with scalar tails. Consecutive frames from one read share a single write flush |
| P-5 Compressor pooling | Workers pre-open one RFC 7692 `libdeflate` context and, when enabled, one HTTP gzip codec with bounded scratch. `Response.end_gzip` never allocates on the request path |
| P-6 Kernel flags | `TCP_NODELAY`, `TCP_QUICKACK`, and `TCP_DEFER_ACCEPT` are applied on the documented sockets; new tests read the options back. No buffer cap was expanded without evidence |
| P-7 H2/H3 tuning | The 1.9.0 M1 result still closes HTTP/2 window tuning as measured, not needed. Linux UDP transmit uses `UDP_SEGMENT` GSO for equal-sized same-destination batches; receive GRO is deferred |
| P-8 Startup barrier | `App.listen_all` binds up to four TCP endpoints, verifies every local port, and only then arms accepts. Per-endpoint TLS selection is supported with the application certificate |
| P-9 TRACE | First-class opt-in method in `HttpMethod`, `Router`/`App`, the client, C ABI code 9, HTTP/2, HTTP/3 classification, OpenAPI, and TLS 0-RTT safe methods |

## Re-declared in 2.0.0

| Boundary | Dated reason and restoration criterion |
| --- | --- |
| Pipelined RPS, WebSocket echo, and `json-comp` targets | The implementation and unit gates landed, but the designated quiet host was not available for the 10M RPS, WS, and 400K RPS/P99 measurements. Rerun the v1.9.0 host contract before publishing any number; never compare shared-runner data to the quiet host |
| UDP receive GRO | The libxev UDP read completion uses `msghdr.control = null`, so `UDP_GRO` segment boundaries are unavailable. Enabling it would make lsquic parse a coalesced buffer as one datagram. Restore when the loop exposes ancillary data or the transport moves to a raw `recvmsg` path |
| Cross-process listener barrier | `listen_all` is in-process all-or-nothing. A cross-process socket takeover needs a shared-memory protocol and belongs to the v2.9.0 drain/takeover milestone |

## Closed in 2.1.5

The 2.1.5 release hardens the application API without changing the request
path or the shared-nothing ownership model.

| Boundary | Resolution |
| --- | --- |
| Cluster lifecycle was opaque | Atomic `ClusterState`, `state()`, `worker_count()`, and `worker_capacity()` make configured, running, stopped, releasing, and released groups explicit. Lifecycle misuse returns a named error instead of touching drained workers ([ADR 0007](adr/0007-cluster-lifecycle-and-failures.md)) |
| Worker failure lost its index and cause | `FailurePhase`, `WorkerFailure { index, phase, err }`, `first_failure()`, and `failure_count()` retain the first worker, spawn, or cleanup failure; `run` still returns `error.ClusterWorkerFailed` ([ADR 0007](adr/0007-cluster-lifecycle-and-failures.md)) |
| Full inboxes were hidden in one count | `PublishReport { queued, dropped, notify_failed, first_dropped_worker }` and `publish_report()` report per-worker acceptance and wakeup failure; `publish()` keeps its integer return ([ADR 0007](adr/0007-cluster-lifecycle-and-failures.md)) |
| Concurrent `deinit` could double-free | `begin_release` claims the free path once and waits for in-flight supervisor calls. Cleanup stops the watcher and drains loops before `stopped`; a surviving watcher is released by `deinit` after the loops are destroyed ([ADR 0007](adr/0007-cluster-lifecycle-and-failures.md)) |
| Cluster wakeup aliased connection 0's WebSocket buffer | Queue-owned scratch keeps cluster drain separate from fragmented-frame assembly; `pop_copy` checks actual message lengths before copying ([ADR 0007](adr/0007-cluster-lifecycle-and-failures.md)) |
| Thread lifecycle was inline in the application type | `src/router/worker_group.zig` owns lifecycle policy, release claiming, borrowed thread start/join, and first-failure capture; thread storage and compatibility fields stay in `Cluster` |
| Cluster configuration used an untyped callback | `Cluster.configure` accepts the named `ConfigureCallback` function pointer |

## Closed in 2.1.6

The 2.1.6 patch release removes the absolute-timer replay that starved kqueue
and could spin the other absolute-timer backends, pins the libxev kqueue
dispatch fixes, and makes local benchmark evidence fail closed without changing
a public API or a wire format.

| Boundary | Resolution |
| --- | --- |
| The expired timer deadline could starve the loop | `timer.Scheduler` disarms the completed timer and arms a fresh relative five-millisecond tick instead of returning `.rearm`; a stopping scheduler does not re-arm. The spin was observed on macOS kqueue and the mechanism is shared by every absolute-timer backend. Each arm stays inside the current second until libxev normalizes timer timespecs. The per-worker deadline wheel is unchanged |
| `set_nodelay` trapped after a reset peer | The raw `setsockopt` result is ignored as a documented best-effort operation, so Darwin `EINVAL` cannot reach the `std.posix` unreachable branch during accept |
| Benchmark samples could pass with missing data | The HTTP/2 runner fails on missing request counters, invalid p99 values, non-TLSv1.3 samples, exit status 143 on the TLS cluster, an empty RSS sampler, an occupied port, or a listener owned by another process. The HTTP runner fails on invalid rates, socket errors, non-2xx responses, or shutdown and log failures. Both write a completion sentinel; the HTTP/2 runner also persists cohort medians |
| kqueue rearm and queue defects | [libxev_kqueue_findings.md](libxev_kqueue_findings.md) records the investigation. XEV-003, XEV-004, and XEV-005 are merged into `farbenbuilds/libxev` and pinned at `c49f6dfb`; the exact XEV-005 tree passed 65/65 macOS kqueue tests in Debug and ReleaseSafe |

## Carried into 2.2.0

- Quiet-host evidence for the v2.0.0 and v2.1.0 pipeline, WebSocket,
  `json-comp`, and `latency-1m` targets, archived under the v1.9.0 evidence
  contract.
- Receive-side `UDP_GRO` after the loop exposes ancillary segment sizes.
- HttpArena `async` adapter activation for the shipped `/delay/:ms` surface.
- Cross-process `SO_REUSEPORT` / systemd socket-activation handoff.
- Decisions on per-listener certificates, a bounded TRACE reflection example,
  and an optional `uwz_app_listen_all` C entry point.
- A retained fork archive and second-machine resolution for the pinned libxev,
  lsquic, and h1spec commits, plus the native Windows runtime gate
  ([ADR 0005](adr/0005-libxev-fork.md),
  [ADR 0006](adr/0006-dependency-forks.md), [policy](dependency_forks.md)).
- lsquic and h1spec fork gate evidence: the maintained pins are recorded and
  `patches/` plus `vendor/lsquic_overlay` are removed; the HTTP/3 and h1spec
  compliance runs still need fresh artifacts.
- HTTP/3 datagram and WebTransport implementation through the maintained
  lsquic fork, with the live path enabled only after the compliance gate
  ([ADR 0001](adr/0001-http3-datagram-and-webtransport.md)).
- Extract the nested `Cluster` runtime from `src/router/app.zig` into a
  dedicated module with a narrow App-private seam. The 2.1.5 release moved
  lifecycle policy and failure state to `src/router/worker_group.zig`; the
  remaining worker/inbox/TLS plumbing is the next ownership boundary.

## Deliberate boundaries

### 2.2.0 decisions, 2026-10-26

- S-5 official HttpArena 8gbit evidence is re-declared under the plan's explicit
  exception. The external adapter still pins 1.8.0 and lacks the route and
  subscription; this session has read-only access. Restore after the reviewed
  source is available, the real POST echo adapter passes official validation,
  and an authorized official run archives complete results. The
  [source record and exact restoration steps](implement-2-2-0/evidence/httparena/README.md)
  remain separate from local socket correctness proof.
- S-3 kTLS integration stays with v3.5.0 SB-31. Pinned BoringSSL exposes
  traffic-secret and sequence inspection, but the project has no verified
  public TCP record-layer handoff covering queued records, control messages,
  sequence ownership, and KeyUpdate. Retain the standalone caller-managed
  helper, whose default version field is TLS 1.2; TCP server contexts remain
  TLS 1.3 only. Restore through an ADR, audited epoch/key/IV handoff and
  zeroization, real Linux interoperability, sanitizer, and performance evidence.
  See [the secret inspection API](https://github.com/google/boringssl/blob/d3bf4795ad5b79d646cddf2fec687da5b9b502db/include/openssl/ssl.h#L6181),
  [internal KeyUpdate ownership](https://github.com/google/boringssl/blob/d3bf4795ad5b79d646cddf2fec687da5b9b502db/ssl/tls13_both.cc#L680),
  and [the kernel handoff contract](https://docs.kernel.org/networking/tls.html#tls-1-3-key-updates).
  Buffered file delivery needs no handshake, cipher, ALPN, pin, or key change.
- S-3 splice remains conditional on measured benefit. No splice experiment or
  performance improvement is claimed. The existing plaintext sendfile path
  stays in place. Revisit only with a controlled candidate/baseline static
  workload and retained raw evidence showing a repeatable benefit within the
  repository's performance and lifecycle constraints.

### Established boundaries

These are decisions, not omissions. Each has a reason and, where relevant, the
condition that would change it.

| Boundary | Reason |
| --- | --- |
| TLS 1.2 is not supported | TLS 1.3-only is a deliberate security posture; adding 1.2 would re-enable obsolete cipher suites for no functional gain |
| No dynamic capacity overflow | Fixed startup slabs are the architecture. Exhaustion returns a structured error; silently allocating would reintroduce heap behavior on the hot path |
| Request bodies are buffered, not streamed to handlers | Handlers are synchronous; true upload streaming needs an async body-reader contract. Response streaming already exists (`begin_stream`) |
| HTTP/2 server push is not implemented | Deprecated in practice and removed from lsquic upstream; no browser consumes it |
| h2c Upgrade is not implemented | RFC 9113 removed the Upgrade mechanism; cleartext HTTP/2 uses prior knowledge and TLS uses ALPN |
| HTTP/2 caps at 8 concurrent streams and one WebSocket tunnel per connection | Stream and tunnel storage is connection-owned and carved from the slab. Raising the defaults requires specializing the connection type |
| WebTransport is not live yet | ADR 0001 is accepted for implementation through the maintained lsquic fork, but the live path stays capability-gated until extended CONNECT, server-initiated unidirectional streams, reset-at, and the compliance gate land; see [ADR 0001](adr/0001-http3-datagram-and-webtransport.md) |
| HTTP/3 does not advance the metrics registry | The engine has no registry handle without new plumbing through the transport; records are emitted instead |
| kTLS is a standalone helper, not an integrated offload | Secret and sequence inspection exists, but an audited TCP record-layer handoff covering control messages and KeyUpdate has not been established. `uz.ktls` remains available to applications that manage their own records |
| MemorySanitizer does not instrument Zig code | Permanent decision dated 2026-10-19: Zig 0.16 emits no MSan instrumentation, so the MSan gate covers the pinned C/C++ dependency boundary ([CI_CD_PIPELINE.md](../CI_CD_PIPELINE.md#memorysanitizer-contract-permanent-2026-10-19)) |
| BSD targets have no runtime CI | No hosted GitHub runners exist for the BSDs; the shared build graph is compiled but not executed in CI |
| Windows runtime is gated on native CI | The accept overlay and queued-close fixes landed in 1.9.0 and the workflow now runs the test suite, but official support starts only when that job is green for the release commit; see [Windows runtime blocker details](#windows-runtime-blocker-details) and [ADR 0004](adr/0004-windows-iocp-accept-and-queued-close.md). No Windows binaries are published |
| macOS workers are unpinned | The platform exposes no hard-affinity API |
| The client is HTTP/1.1 only | It is deliberately small: no DNS resolution (numeric addresses only), no redirects, no cookies, no proxy support, no connection pooling, no mTLS, and no HTTP/2 or HTTP/3 client |
| The C ABI is a high-level subset | Opaque handles and fixed capacities target C/C++ consumers; the low-level HTTP/2, HPACK, HTTP/3-extension, WebTransport, UDP, and client modules are Zig-only |
| Zig 0.16.0 is the only supported toolchain | It is the latest usable release without known breaking defects for this codebase. Pre-1.0 toolchains churn; pin the exact compiler |

## Windows runtime blocker details

A native Windows runtime gate was attempted on `windows-2025` and traced to two
defects, in order of encounter.

1. **libxev accept lifecycle (upstream).** After a successful `AcceptEx`, the
   IOCP backend returns the accepted socket from the completion but never
   clears `op.accept.internal_accept_socket`. A persistent accept loop re-arms
   the completion, and `start_completion` calls `AcceptEx` again with the
   already-connected socket, which returns `WSAEINVAL (10022)`; libxev then
   panics while mapping that unmapped Winsock code to `Win32Error`. A
   standalone probe confirmed the `AcceptEx` arguments are fine (a zero
   local-address length returns `WSA_IO_PENDING` on `windows-2025`), and a
   local patch that clears the field after taking the socket got the server
   past the panic. The minimal upstream fix is to null the field on both the
   success and error paths of the accept completion.
2. **Queued completions on the Windows close path (this project).** With the
   accept fix applied, `verify_shutdown` failed with `ShutdownIncomplete`
   because a connection stayed in the pool with `is_writing = true`.
   `Completion.state()` maps both `.adding` (queued, not yet submitted) and
   `.active` to `.active`, so the Windows close branch never clears
   `is_writing`/`read_active` for a completion that is canceled before
   submission. libxev marks the unsubmitted target `.dead` and fires only the
   cancel callback, so the write callback never runs and the slot is never
   released. The fix direction is to distinguish queued from submitted
   completions (submit them before canceling, or track submission explicitly)
   and clear the flags for completions whose callback will never fire.

The 1.9.0 work carried the upstream accept fix as a pre-generated overlay
rather than a package-cache edit; the 2.1.0 migration replaced it with the fork
commit. It also submits queued IOCP completions before
canceling them so the target callback clears `read_active`/`is_writing`.
`windows.yml` now runs the full test suite on `windows-2025` in addition to the
compile gates, and a regression test closes a queued write before submission
and asserts that the pool slot returns. The decision, patch, and rollback path
are recorded in [ADR 0004](adr/0004-windows-iocp-accept-and-queued-close.md).
[ADR 0005](adr/0005-libxev-fork.md) selects `farbenbuilds/libxev` as the
maintained fork. The 2.1.0 release pins commit `cbf01bc` on `uwz/zig-0.16`,
carries XEV-001 in the fork, and removes the overlay and audit patch;
2.1.6 advances the pin to `c49f6dfb` with XEV-003 through XEV-005.
[dependency_forks.md](dependency_forks.md) is the policy. The TLS cluster test plumbing already
binds `getsockname` and `SO_RCVTIMEO` through ws2_32, so those tests execute
rather than skip. Windows remains compile-only in the support claim until the
native job is green for the release commit.

## Near-term direction

Candidates for the next minor releases, in rough dependency order:

1. **WebSocket client** over the existing client transport, using the zslay
   client role for framing and masking.
2. **Incremental request bodies** for HTTP/1.1: a bounded, async body reader
   that lets large uploads bypass `max_body_size` per connection.
3. **Configurable HTTP/2 stream and tunnel counts** through connection-type
   specialization.
4. **HTTP/3 counter parity** by threading the metrics registry into the engine.
5. **WebTransport activation** through the maintained lsquic fork, behind the
   capability gate recorded in
   [ADR 0001](adr/0001-http3-datagram-and-webtransport.md), once the fork
   exposes and tests the required server interfaces.
6. **kTLS integration** if BoringSSL gains a supported key-handoff API.

## How to influence the roadmap

Open an issue describing the use case, or a pull request following
[CONTRIBUTE.md](../CONTRIBUTE.md). The project accepts additive changes that
preserve bounded behavior; proposals that add unbounded allocation to the hot
path or weaken a compliance gate are declined by policy, not by preference.
