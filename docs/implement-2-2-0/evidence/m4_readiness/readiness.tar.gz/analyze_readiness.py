#!/usr/bin/env python3
"""Read frozen source and archived results; do not run a server or compiler."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = Path('/workspaces/uWebZockets')
LSQUIC = Path('/tmp/uwz-current-pin-archives-20261026/source_reconstruction/lsquic')
PIN = '85bd081c9103c077a7cc98271d09334d0f1043d4'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def record(label, argv, allowed=(0,)):
    result = subprocess.run(argv, capture_output=True, check=False)
    (BASE / (label + '.stdout')).write_bytes(result.stdout)
    (BASE / (label + '.stderr')).write_bytes(result.stderr)
    (BASE / (label + '.command.json')).write_text(json.dumps({'argv':argv,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':result.returncode},indent=2)+'\n')
    assert result.returncode in allowed, (label, result.returncode)
    return result.stdout


def main():
    manifest = json.loads((BASE / 'manifest.json').read_text())
    revision = manifest['root_commit']
    assert record('lsquic_pin', ['git','-C',str(LSQUIC),'rev-parse','HEAD']).decode().strip() == PIN
    c_files=['include/lsquic.h','src/liblsquic/lsquic_hcso_writer.c','src/liblsquic/lsquic_hcso_writer.h','src/liblsquic/lsquic_enc_sess_ietf.c','CMakeLists.txt','LICENSE']
    manifest['lsquic_source_files']={}
    for name in c_files:
        data=record('lsquic_source_'+name.replace('/','_'),['git','-C',str(LSQUIC),'show',PIN+':'+name])
        target=BASE/'lsquic_sources'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
        manifest['lsquic_source_files'][name]={'sha256':digest(data),'git_blob':record('lsquic_blob_'+name.replace('/','_'),['git','-C',str(LSQUIC),'rev-parse',PIN+':'+name]).decode().strip()}
    record('lsquic_reset_at_symbol_search',['git','-C',str(LSQUIC),'grep','-n','-E','reset_stream_at|RESET_STREAM_AT',PIN,'--','include','src'],allowed=(1,))
    compared=['src/quic/engine.zig','src/quic/stream.zig','src/quic/http3_extensions.zig','builds/vendor/lsquic.zig','build.zig.zon','scripts/http3_compliance/expectations.json','scripts/http3_compliance/aioquic_probe.py','scripts/http3_compliance/run.sh']
    archived_commit='ee4bf1c9180533cd429c75ed427d8766f467e17d'
    unchanged={}
    for name in compared:
        old=record('archived_blob_'+name.replace('/','_'),['git','-C',str(ROOT),'rev-parse',archived_commit+':'+name]).decode().strip()
        unchanged[name]=old == manifest['source_files'][name]['git_blob']
    manifest['archived_gate_equivalence']={'archived_commit':archived_commit,'root_commit':revision,'equal_git_blobs':unchanged,'boundary':'Unchanged relevant source, not a new live run at the later checkpoint.'}
    archive=ROOT/'docs/implement-2-2-0/evidence/m1_file_h3/frozen_verification/http3.tar.gz'
    qlog_name='http3/qlog/5a7e273ea561ab8f.qlog'
    with tarfile.open(archive,'r:gz') as package:
        qlog_bytes=package.extractfile(qlog_name).read()
        qlog=json.loads(qlog_bytes)
        source=package.extractfile('source_commit.txt').read().decode().strip()
        assert source == archived_commit
        remote=[]
        for trace in qlog['traces']:
            for event in trace['events']:
                if event['name'] != 'transport:parameters_set' or event['data']['owner'] != 'remote':continue
                data=event['data']
                remote.append({'owner':'remote','recognized_parameter_names':sorted(data),'max_datagram_frame_size_present':'max_datagram_frame_size' in data})
        assert len(remote)==1 and remote[0]['max_datagram_frame_size_present'] is False
        gate={'source_commit':source,'archive_path':str(archive.relative_to(ROOT)),'archive_sha256':digest(archive.read_bytes()),'qlog_member':qlog_name,'qlog_sha256':digest(qlog_bytes),'remote_transport_parameters':remote,'http3_exit':package.extractfile('http3.exit.txt').read().decode().strip(),'scope':'Existing ordinary HTTP/3 run only; no CONNECT-501 or WebTransport-session probe. No HTTP/3 SETTINGS assertion is inferred from the retained qlog.'}
        (BASE/'archived_gate_summary.json').write_text(json.dumps(gate,indent=2)+'\n')
    manifest['archived_gate_summary']='archived_gate_summary.json'
    manifest['references']=[
        {'url':'https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-3.1','checked_date':'2026-10-26','scope':'Fixed draft-16 requirements: WT/connect/H3-datagram settings, QUIC datagrams and reset-at negotiation.'},
        {'url':'https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-9.2','checked_date':'2026-10-26','scope':'Draft-16 WT_ENABLED codepoint.'},
        {'url':'https://www.rfc-editor.org/rfc/rfc9297.html#section-2.1','checked_date':'2026-10-26','scope':'Quarter-stream-ID framing errors versus unknown/closed-stream drops.'}
    ]
    manifest['permission_observation']='permissions_tool_result.json'
    manifest['proposal_boundary']='Readiness and conditional re-deferral proposal only. Root has not adopted a deferral; ADR0001 stays accepted and original files are unchanged.'
    (BASE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'root_commit':revision,'lsquic_pin':PIN,'archived_relevant_source_equal':unchanged,'archived_remote_max_datagram_frame_size_present':False,'no_new_build_or_probe':True},indent=2))


if __name__=='__main__':
    main()
