# M4/C12 WebTransport readiness

Status: read-only preparation, 2026-10-26. No M4 completion, deferral adoption,
capability change, fork publication, or new runtime proof is claimed. Root owns
integration after M1 and M3. ADR 0001 remains accepted as written.

Source checkpoint: `1488ecc49721dde935ee628b6b5668e99d600836`.
Published lsquic pin: `85bd081c9103c077a7cc98271d09334d0f1043d4`, based on
`a9616720af78b9aab895145c1792d5305c480ae8` with LSQ-001/LSQ-002. The
[manifest](/tmp/uwz-m4-readiness-evidence/manifest.json) binds exact Git blobs and
SHA-256 values. No source file, dependency pin, cache, or remote ref was changed;
no compiler, test runner, server, or live client was started by this preparation.

## Preconditions and observed publication barrier

M4 explicitly requires M3 completion and the maintained-fork policy. M3 remains
open: the lsquic mirror at `413ca7c1acb443b0f9f7aa28611ca723c6738844` differs
from captured upstream `02b10a9e620bc235e40baa8dd0b2d9f32ff96cab`; the pinned
parent records HPACK `cf0f70dd10b352194c97448eb5d00b4aa484f531`, while the
root builds `fda48e02491d865cce00612be8cc10c2622b8e55`. The reviewed gitlink-only
candidate `87e318737657b2c6cde04ad94d583651340d6968` is unpublished and is not
a valid root dependency pin. Current-pin bundles preserve both HPACK revisions
without applying that candidate.

A fresh read-only GitHub API call finished with exit 0: authenticated account
`kienfssc` has `push:false`, `maintain:false`, and `admin:false` for
`farbenbuilds/lsquic`. Its [exact observed tool result](/tmp/uwz-m4-readiness-evidence/permissions_tool_result.json)
is retained. This prevents this account from publishing the required reviewed
fork integration commits or changing protection. It does not prevent local
research and test preparation. Main-repository manual review does not waive the
maintained fork's append-only/review rules. No new GitHub fork is a fallback.

The separate h1spec license-attribution gap is a release-provenance issue,
not a missing WebTransport backend primitive. It must not be silently called
resolved by the current-pin archives.

## Server and binding map

| Required surface | Published/backend fact | Missing integration |
| --- | --- | --- |
| Extended CONNECT and H3 datagram SETTINGS | The native Zig definition list omits `LSQUIC_WEBTRANSPORT_SERVER_SUPPORT`. lsquic's gated writer emits 0x08/0x33 only inside the disabled server block. | Reviewed fork surface, consistent C translation/build defines, negotiated runtime policy, and wire assertions. |
| Draft-16 settings | lsquic's gated writer uses legacy `0x2b603742` and `0x2b603743`; the Zig model uses `SETTINGS_WT_ENABLED=0x2c7cf000`. | Enabling the existing macro alone cannot establish draft-16 compatibility. |
| QUIC DATAGRAM | Public callbacks and want-write APIs exist; the documented default is `LSQUIC_DF_DATAGRAMS=0`. Engine initialization uses those defaults and never enables the setting or callbacks. | Both datagram callbacks, bounded ingress/egress ownership and negotiation, and a session mapping. |
| Application-controlled outgoing unidirectional streams | The public creation API is `lsquic_conn_make_stream`, documented as creating a request stream. No public application-controlled server-uni entry point is present. Internal control/QPACK streams do not satisfy this API requirement. | Ledgered server-side stream creation/association API plus exhaustion and teardown tests. |
| RESET_STREAM_AT | No `reset_stream_at`/`RESET_STREAM_AT` symbol occurs in the pinned public include/src tree; the Zig helper only models its identifiers. | Actual transport-parameter/frame semantics, reliable-size/reset handling, and fork/client tests. |
| Connection identity | `on_new_connection` counts connections and returns the shared engine context; close decrements the count. There is no generation-checked per-connection slot table. | Fixed connection slots, raw-identity lookup, generation invalidation, once-only cleanup, and pointer-reuse tests. |
| CONNECT/session admission | `attach_headers` enters the ordinary body phase; `on_read` buffers until EOF before dispatch; completed CONNECT requests take the explicit 501 branch. | Header-time admission into a long-lived session/capsule phase. Replacing the 501 text alone would still wait for EOF and use the ordinary bounded request body. |
| App/router ownership | UDP/engine start borrow TLS and the HTTP Router. App owns datagram routes/rings, but no engine callback calls `dispatch_datagram`; `session_slab` remains a helper. | Private typed App/UDP/engine binding of connection slot, session handle, registered path, limits and teardown. |
| Outbound datagrams | `dispatch_datagram` copies inbound data into its ring and calls the receive handler; `next_datagram` removes queued data. This is not an implemented QUIC transmit path. | Explicit egress ownership/want-write policy within the accepted public-surface constraint; do not infer automatic echo or recursively redispatch inbound data. |

Source anchors: [native definitions](/workspaces/uWebZockets/builds/vendor/lsquic.zig:199),
[engine defaults](/workspaces/uWebZockets/src/quic/engine.zig:217),
[callback registration](/workspaces/uWebZockets/src/quic/engine.zig:275),
[connection context](/workspaces/uWebZockets/src/quic/engine.zig:500),
[stream intake](/workspaces/uWebZockets/src/quic/stream.zig:433),
[completed CONNECT refusal](/workspaces/uWebZockets/src/quic/stream.zig:656),
[App dispatch](/workspaces/uWebZockets/src/router/app.zig:919), and
[UDP binding](/workspaces/uWebZockets/src/core/udp.zig:102).
Exact pinned C sources and symbol-search exit 1 are retained under
`/tmp/uwz-m4-readiness-evidence/lsquic_sources` and the adjacent command records.

`BackendCapabilities` describes backend primitives, not live listener policy.
The current record intentionally keeps `quic_datagrams=true`; extended CONNECT,
outgoing application-controlled uni streams, reset-at, draft-16, and push bits
remain false. `webtransport.require_backend` therefore returns
`BackendUnsupported`. A deferral must preserve that distinction rather than
set every capability bit false or advertise live datagrams from the raw bit.

## Fixed protocol and client gate

The selected [draft-16 connection contract](https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-3.1)
requires negotiated WebTransport/CONNECT/H3-datagram settings plus QUIC datagram
and reset-at transport support. Its [settings registry](https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-9.2)
uses `0x2c7cf000` for WT_ENABLED. This report targets that fixed work-in-progress
version, not an unspecified latest draft.

Installed pinned aioquic 1.3.0 source has built-in `ENABLE_WEBTRANSPORT=0x2b603742`.
Its WebTransport option emits that legacy setting; its transport-parameter schema
has no reset-at field, and its reset frame enum contains RESET_STREAM 0x04 only.
The [source hashes and inspected facts](/tmp/uwz-m4-readiness-evidence/pinned_client_source.json)
and [implementation excerpts](/tmp/uwz-m4-readiness-evidence/pinned_client_excerpts.txt)
are retained. Merely enabling its stock WebTransport option cannot prove the
full selected draft-16 contract. Keep the existing pinned ordinary HTTP/3 gate
as a regression control and separately choose/review/pin a compatible
WebTransport client or an explicit compatibility design before claiming M4.

One plan phrase needs clarification during implementation: "malformed datagrams
are dropped" must distinguish payload/policy refusal from HTTP-datagram framing.
[RFC 9297 section 2.1](https://www.rfc-editor.org/rfc/rfc9297.html#section-2.1)
requires H3_DATAGRAM_ERROR for truncated or overlarge quarter-stream-ID framing;
unknown/not-yet-created and closed stream cases have different permitted/required
drop behavior. The current disabled listener has no newly discovered live path
for this issue. The future adapter must preserve those error scopes.

## Existing proof and its limits

| Retained evidence | Supported statement | Unsupported inference |
| --- | --- | --- |
| Native 752/752 sidecar checkpoint, including imported phase3 tests | Declarative pinned capability equality and `require_backend` refusal have existing native coverage. The separate WebSocket helper maps an unsupported protocol to 501. | This does not prove live WebTransport rejection, session establishment, datagrams, or a CONNECT wire response. |
| Source at the frozen checkpoint | Completed CONNECT dispatch explicitly emits 501 and no WT session is bound. | A real long-lived CONNECT left open has no header-time 501 proof; the current body-completion gate can leave it pending until EOF/normal bounds. |
| Existing ee4bf1c ordinary HTTP/3 archive | The gate exits 0 and explicitly excludes WebTransport/server push. Its qlog records remote transport parameters without the recognized max_datagram_frame_size field. | It is not a new live run at 1488, a captured WT HTTP/3 SETTINGS assertion, or a compatible WT client gate. |

The archived gate is bound to `ee4bf1c9180533cd429c75ed427d8766f467e17d`.
Eight relevant engine/stream/capability/build/pin/gate blobs are identical at the
later frozen checkpoint; the [equivalence record](/tmp/uwz-m4-readiness-evidence/manifest.json)
is explicit. The [qlog summary](/tmp/uwz-m4-readiness-evidence/archived_gate_summary.json)
binds the original tar SHA-256
`0c96cca12dbbec74ed2cb2a1a240208cc458676526124814ef6f461535eebd34` and qlog
member. Pinned aioquic's logger records recognized integer transport parameters,
so the missing max-datagram field corroborates the disabled QUIC datagram
advertisement in that run. No assertion about an unknown reset-at parameter is
inferred from a client parser that lacks it. Raw traces remain in their original
archive; no new live CONNECT-501 or full negative-capability probe was located.

## Work possible before publication

1. Complete narrowly reviewed source/API/test designs and prepare ledgered fork
   changes in local clones without consuming an unpublished pin or editing
   fetched packages. Canonical fork policy outranks the specialist profile's
   stale local-patch reference.
2. Specify the private connection/session/egress ownership seam and bounded
   lifecycle cases. Coordinate H3 header-time admission with M2 rather than
   growing a second ordinary-body collector. Keep QPACK dynamic decode disabled
   and 0-RTT rejected.
3. Select a draft-compatible client and prepare deterministic gate inputs,
   negotiated-setting/transport assertions, malformed/sibling cases, and qlog
   retention. Do not represent a legacy-client option as the new gate.
4. After root releases the frozen live jobs, an additional negative baseline can
   inspect public `H3Connection.received_settings`, recognized remote transport
   parameters, and a deliberately unsupported completed CONNECT plus healthy
   sibling on one connection. Close the request side for the existing 501 path;
   separately test open-session rejection/admission when that behavior is added.
   These are proposed future probes, not results of this report.

Actual M4 implementation remains serialized after M3 under the supplied plan.
Source preparation is not blocked by GitHub permission; publication and valid
pin acceptance are blocked. No work here bypasses that distinction.

## Proposed dated re-deferral, for root adoption only

If root chooses the plan's M4-3 incomplete-work path, a concrete proposed record
is: "Live C12 activation re-deferred on 2026-10-26 because the published backend
lacks the required server primitives, current provenance alignment/sync remains
open, this account cannot publish reviewed fork work, and the retained client
gate is not draft-16 compatible. Existing helper APIs remain available; no live
WebTransport/application-datagram support is advertised."

The proposed reassessment date is 2026-11-02, or the first authorized maintained
fork review earlier. This is not a user deadline or maintainer commitment until
root adopts it. Do not silently change the accepted ADR or mark M4 complete
from this preparation. If adopted, revise ADR 0001's activation status and the
M4 report, roadmap, SECURITY/quic/protocols/capability documentation together;
retain the primitive raw-datagram bit and all existing false WT requirements.

Restoration owners and ordered acceptance:

1. Build/vendor maintainer: restore reviewed exact mirror equality and required
   protections, publish reviewed HPACK alignment through the existing fork,
   verify all child pins and ledger entries, and finish M3's pinned baseline.
2. Build/vendor plus QUIC owner: implement/test ledgered server APIs, current
   settings and reset-at semantics; publish an immutable integration commit;
   update all four root pin/hash views and native Zig build definitions together.
3. QUIC, transport and router owners: bind fixed generation-checked connection
   slots, header-time session admission, streams/capsules and bidirectional
   datagram ownership, with limits, reset/close/flow-control cleanup and no hot
   allocation/locks. Re-review the combined ownership changes.
4. Verification owner: run compatible pinned WT and ordinary HTTP/3 clients on
   the exact source/pin; retain wire settings/parameters, session setup, both
   datagram directions, streams, reliable reset, close, flow control, capacity,
   malformed/sibling and teardown proof with raw output/qlogs. Repeat required
   sanitizer, platform, package, cold-source and archive gates after pin changes.
5. Root integrator: only after those gates pass, accept the live capability
   change and matching docs in the same reviewed change. Final release review,
   second-machine resolution and native runtime claims remain separate gates.

This restoration chain supplies a reviewable proposal. It neither selects a
release outcome nor creates permission to publish, change protections, or move
a release tag.
