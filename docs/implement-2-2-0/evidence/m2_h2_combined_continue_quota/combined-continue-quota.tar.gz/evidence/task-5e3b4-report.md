# Task 5e3b4: Continue, quota and failed-begin schedules

Status: implemented and checked with synthetic in-memory public codecs. Independent review is required. The implemented selection is 21 of 40; 19 remain unsupported. This is not fixture execution or all40 acceptance.

## Source contracts and changes

The release addendum binds immutable model/catalogue `/tmp/uwz-task5e1-contract-v3`, v9 core `/tmp/uwz-task5e3a-snapshot-v9/source`, the combined fixture `/tmp/uwz-task5e2-Fix1Final2/fixture`, the final admission `fix1` sources and the pinned helper/codecs. Relevant source hashes are in `combined-cases/evidence/b4/source-sha256.txt`; complete bindings are in the input audit and release addendum. The fixture's admission control route is `/resume/:tag`, which returns `ok`; the pause family's `/control/:op/:tag` is a different contract.

`continue_quota_cases.py` uses model request contracts, payload, records and checkpoints. The Continue cases send declared 32 bytes only after a single observed 100. The paused case retains its held stage, validates its single status barrier and pending response, and resumes through the admission route before completing. Quota starts distinct holders, validates four single metrics barriers, refuses the third request with final 503 and ordered NO_ERROR reset, completes the holders, and starts and completes two distinct recoveries. The active barriers check all model counters and current buffered middleware as well as active and slot counts. Failed begin retains the 503/reset while its distinct healthy recovery completes. The final collection checks the selected records, including failed-begin attempts/failures and the refusal records.

`adapter.py` supplies an explicit informational count to the existing wire registration, chooses the primary stream for these cases, and dispatches the new schedules. `cases.py` selects 21 IDs explicitly. `test_pause.py` and `test_admission.py` change only the root-authorized unsupported inventory count from 23 to 19; the rejection loop remains. `test_imports.py` includes both new modules. The current 18-module snapshot, SHA-256s, and comparison with the B3 16-module manifest are under `evidence/b4/snapshot/`, `snapshot-sha256.txt` and `source-comparison.json`: five changed, two new, zero missing. Prior evidence remains intact.

## Proof and history

The initial source is retained as `evidence/b4/initial-test.py`; `red.{stdout,stderr,exit}` records exit 1, `ValueError: case schedule not implemented`. This is a selection-only failure, not a behavioral RED. Intermediate 1 and 2 exposed mistakes in the synthetic test's expected quota request order, both `RuntimeError: request order differs`; intermediate 3 and 4 passed. Intermediate 5 expected the wrong error for a missing-Continue fault: the core rejected the subsequent DATA as `invalid DATA`; intermediate 6 and 7 passed after correcting the sensitivity-control expectation, and intermediate 8 passed with final record isolation controls. All actual intermediate receipts are retained separately.

The focused test decodes request headers and checks method, target, declaration, Expect multiplicity, HEADERS END, request order, DATA ordinal, size, END and digest. It uses four fresh connections with one shared synthetic application, then validates all 67 final statuses plus metrics, including the nine selected records and untouched records. Exact per-case J/C/R are 3/3/32, 5/5/32, 11/11/128 and 4/4/32. The direct pre-Continue action is rejected by the immutable wire seam. Injected sensitivity controls reject missing Continue, unsolicited refusal 100, refusal response DATA, reset before final, incorrect active count, paused accepted bytes, premature paused completion, incorrect begin failure count and mutation of an unrelated record. These are post-implementation synthetic sensitivity controls, not behavioral pre-change REDs or native evidence. The test checks final isolation, not a separate stale-token operation during this unit.

## Final verification

All final runs use the following environment:

```
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

For each of `test_continue_quota test_admission test_pause test_selection test_adapter test_ready test_async test_negative test_time test_large test_shared test_imports test_final`, the exact normal command was `/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/<name>.py`; optimized inserted `-O` after `-S`. All 26 exited 0 and stderr was empty. Individual raw stdout/stderr/exit receipts are `evidence/b4/{normal,optimized}-<name>.*`. The imports check uses empty and foreign argv with rejecting effect doubles. No Zig optimization mode applies to these Python checks.

The focused raw stdout reports:

```
pre-Continue DATA rejected: DATA before Continue or after terminal
continue_ready passed: heads=3 flow=32
continue_paused passed: heads=5 flow=32
quota_refuse passed: heads=11 flow=128
begin_failure_rollback passed: heads=4 flow=32
```

Those four passes repeat for the shared application; the remaining raw lines report the named sensitivity controls. See the full retained stdout rather than treating these excerpts as native results.

## Self-review and remaining facts

The core stages and both ledgers remain the sole action/observation path. No capacities, deadlines, model, fixture or dependency were changed. Fixed bounded reads, caller-supplied integer clocks and the paired final/reset retirement are retained. The synthetic application derives records from the same model, so it does not independently establish fixture correctness. Independent review must assess the changed code and evidence, including whether the active counter barriers and isolation tests satisfy the full brief.

Process deviation: several editing scripts used workspace `python3` rather than the brief's pinned Python 3.14.2 with `-B -S`; all behavioral test commands used the pinned interpreter. One `rg` search of the supplied fixture/source paths preceded the release-addendum graphify query. These deviations are disclosed for root review. No native build, server, socket, TLS, process, transfer, fault, cancellation, scheduler, race, leak or real-clock experiment was run. The full Zig matrix and protocol gates were not run because this release expressly prohibits native/build execution. Independent review, 19 schedules, all40/default, later live and native gates remain open.

Parent note: Please review the process deviations, synthetic evidence and retained B4 snapshot before accepting this unit. No Git or public delivery action was taken.

## Completion cleanup

Removed the unused `continue_quota_cases.CASES` tuple; the independently exercised `test_continue_quota.NAMES` remains unchanged. This dead-code deletion has no invented RED. Current `continue_quota_cases.py` SHA-256 is `da533ef0fde4179c00427d11b689cba1fdf248e41ba01c98a47f37a08ec99e95`. `evidence/b4/completion/snapshot/` contains all 18 current modules; `source-comparison.json` and `snapshot-sha256.txt` show exactly that file changed from the preceding B4 snapshot, with none added or missing. The prior 26 results and snapshot remain evidence for the preceding source; they were not rerun for this cleanup.

The four commands below used the same exact `PYTHONPATH` documented above:

```
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Each exited 0 with empty stderr; separate raw stdout, stderr and exit receipts are under `evidence/b4/completion/`. These remain in-memory Python checks, with no Zig optimization mode or native execution.

Root's current metadata check finds that workspace `python3` resolves to the same Python 3.14.2 binary and hash as the pinned path (`4c275e98...`). The earlier disclosure remains: those editing invocations omitted the exact path and `-B -S` discipline, and the historical commands were not replayed. The earlier search-order disclosure also remains. Independent review and all40/native acceptance remain open.
