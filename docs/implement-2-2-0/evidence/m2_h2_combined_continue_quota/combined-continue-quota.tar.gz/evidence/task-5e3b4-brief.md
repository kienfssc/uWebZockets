# Task5e3b4: Continue, quota and failed-begin recovery

Continue the unchanged all40 combined-client plan from reviewed/pushed B3
61c68cf7f22c235d7844872c01646327c18824eb. Seventeen schedules are earned;
implement the next four using the existing bound adapter/core. Read
task-5e3b-release-addendum.md and linked original brief for binding global
interfaces and no-native limits. Preserve completed B1/B2/B3 and their proof.

## Ownership and authority

Own the concrete four-case schedule/test source in the existing combined-cases
directory, minimal adapter.py/cases.py/test_imports.py changes and necessary
reuse of current schedule helpers. Root authorizes precise unsupported-count
assertion updates23->19 in test_pause.py and test_admission.py; preserve their
assertions and rejection checks. Include every changed module in snapshots
and covering checks. Do not expand old tests by using an implementation list
as a replacement for this task's independent four-case requirements.

Own evidence/b4/ and this plan's task-5e3b4-report.md. Root owns Git/public
delivery. You are not alone; preserve all others' edits and earlier evidence.
No agents or external model CLI. Current16-module B3map is its committed
manifest/task-5e3b3-root-final-audit.json; B2 introduced tag-based private-token
control, B3 introduced exact status/policy, complete reset wait and keep/retire.
Reuse these earned seams rather than rewriting the adapter.

Immutable model/catalogue: /tmp/uwz-task5e1-contract-v3; v9core:
/tmp/uwz-task5e3a-snapshot-v9/source. Pinned codecs/helper/Python paths are in
the release addendum. Combined fixture source-only routes/schemas:
/tmp/uwz-task5e2-Fix1Final2/fixture. Final admission source-only contracts:
.uwz-work/evidence/h2-streaming/integration-owned/admission/fix1/cases.py,
profile.zig and run_live.py, hashes in task-5e3b-input-audit.json. Use the
combined model's current schema/request contract, not older field aliases.
Do not invoke old live/close entrypoints or invent public generation fields.

## Exact schedules

| Case | Heads J | Small C | Request flow R | Body records |
| --- | ---: | ---: | ---: | --- |
| continue_ready | 3 | 3 | 32 | continue_ready |
| continue_paused | 5 | 5 | 32 | continue_paused |
| quota_refuse | 11 | 11 | 128 | quota_holder_one, quota_holder_two, quota_refuse, quota_recovery_one, quota_recovery_two |
| begin_failure_rollback | 4 | 4 | 32 | begin_failure, begin_recovery |

Both Continue paths preserve exact Expect/declaration and one source-supported
100 before any positive DATA. Continue-paused then sends32 with END, proves
accepted0/no chunk/end while paused using the finite status barrier, resumes
through the actual fixture route and completes normally. Keep held-stage
ordering and source-specific control result; do not assume the pause family's
control endpoint is the admission family's endpoint.

Quota starts two distinct holders and proves the admitted active count through
one same-connection metrics barrier. The additional request receives the
source-selected503 with no100 or request DATA and ordered final/reset. Finish
the holders, observe release, admit both distinct recovery uploads, observe
their active state and final release. Preserve exact11 requests,128DATA bytes,
five independent persistent records, admission/counter semantics and retained
refusal diagnostics. This tests the application quota, not a reduced HTTP/2
stream limit; keep all capacities unchanged.

Failed begin preserves Expect/final503/no100 and the exact attempt/failure/
no-begin/no-cancel record. Reservation rollback must permit its distinct healthy
32-byte recovery on the same connection. Preserve source-selected NO_ERROR
reset ordering/retirement and all nine new persistent records for this unit.

Import unchanged model/catalogue validators, payload generator and request
contracts. Add only actual-used named adapter parameters/seams needed for
informational observation/held control; preserve explicit status/reset policy,
fresh caller integer time, case/whole deadlines, bounds and paired retirement.
Every HEADERS/DATA/grant/reset/observation goes through the existing wire/raw/
both-ledgers/stage path exactly once. No bypass parser, duplicate refund,
unbounded poll, new capacity/count/budget/deadline, second expected-state model,
core/model/fixture/product/dependency mutation or fake successful handler.

Dispatch the earned21-case subset explicitly; all19 unsupported IDs fail before
actions. Full40/default/aggregate/native acceptance stays open. A shared
synthetic application must retain the four cases' nine records across fresh
connections and current final67-status-plus-metrics collection, with correct
selected-before state and exact counters.

## Proof and delivery

Use behavior-first focused RED/GREEN and actual in-memory public codecs.
Qualify selection-only/missing-API failures accurately; missing test files or
deliberate mutations are not behavioral REDs. Preserve initial test source
and actual intermediate failures alongside final receipts, rather than losing
history. Do not invent a failure just to meet a narrative.

Check exact serialized method/path/query/header multiplicity/declarations/
Expect/END/DATA sizes/digests and request order. Independently prove no positive
DATA precedes100, no completion precedes resume, exact active-count barriers,
no100/primaryDATA on refusals, stale/other-record isolation, rollback and final
reset order. Use bounded ordinal checks, not retained frame/read histories.
Negatives should target those named invariants, with honest sensitivity-control
qualification. Existing B3 no-100 refusals and B1/B2 regressions must stay valid.

Use pinned Python3.14.2 -B -S normal/-O only. Capture each final covering
command's separate stdout/stderr/exit under evidence/b4 after the last edit,
including relevant prior regressions for adapter/selection changes. No unrelated
suite reruns. Snapshot every directly owned module with hashes and comparison
against16-module B3. Every authored helper has a main guard and actual silent/
inert empty/foreign-argv import proof with rejecting effect doubles. No authored
classes/custom exception classes/inheritance/assert proof statements, hidden
mutable globals, dead code or nesting beyond3 control-flow levels.

No native build/server/socket/SSLContext/TLS-close/process ownership/transfer/
descriptor/kernel/fault/cancel/scheduling/race/panic/leak/real-clock experiment
is released. Pure serialized request/control/reset tests are allowed. Stopped
native experiments remain stopped. An actual immutable-seam contradiction goes
to Root as the smallest failing pure call; continue independent work without
weakening or bypassing the seam.

Write full task-5e3b4-report.md with source contracts/APIs, changed files, exact
commands/raw outcomes, failure history, identities, self-review and remaining
facts. Append a short parent note; all40 stays incomplete. Return concise DONE/
concerns/report location/verification summary. Root independently reviews
before publication/commit/next unit.
