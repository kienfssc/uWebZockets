"""Checks for the released Continue, quota, and failed-begin schedules."""
import cases


def main():
    for case in ('continue_ready', 'continue_paused', 'quota_refuse', 'begin_failure_rollback'):
        if cases.select((case,)) != (case,):
            raise ValueError('selection differs')
    print('four selections accepted')


if __name__ == '__main__':
    main()
