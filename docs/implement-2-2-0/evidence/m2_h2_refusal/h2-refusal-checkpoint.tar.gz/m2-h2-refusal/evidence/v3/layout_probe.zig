const support = @import("test_support");
const server = support.http2_server;
export const h2_session_size: usize = @sizeOf(support.tcp.Http2Session);
export const h2_session_align: usize = @alignOf(support.tcp.Http2Session);
export const h2_callbacks_size: usize = @sizeOf(server.Callbacks);
export const h2_callbacks_align: usize = @alignOf(server.Callbacks);
export const h2_tcp_size: usize = @sizeOf(support.tcp.TcpConnection);
export const h2_tcp_align: usize = @alignOf(support.tcp.TcpConnection);
