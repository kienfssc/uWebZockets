from pathlib import Path
import json,re,hashlib
out=Path(__file__).resolve().parent;base=out.parent
expected={'h2_session_size','h2_session_align','h2_callbacks_size','h2_callbacks_align','h2_tcp_size','h2_tcp_align'}
def decode(path):
 text=path.read_text();glob=dict(re.findall(r'^@([^ =]+) = (.+)$',text,re.M));values={}
 def read(name,seen=()):
  if name in values:return values[name]
  assert name not in seen and name in glob,name
  line=glob[name];v=re.search(r'constant i(?:32|64) ([0-9]+)',line)
  if v:n=int(v.group(1))
  else:
   a=re.search(r'alias .*?, ptr @([^ ,]+)',line);assert a,(name,line);n=read(a.group(1),seen+(name,))
  values[name]=n;return n
 result={n:read(n) for n in expected};assert set(result)==expected
 for label in ['session','callbacks','tcp']:
  size=result['h2_'+label+'_size'];align=result['h2_'+label+'_align'];assert size>0 and align>0 and align&(align-1)==0 and size%align==0
 return result
result={};hashes={}
for phase,folder in [('baseline','v3'),('after','v4')]:
 result[phase]={};hashes[phase]={}
 for target in ['native','x86_64-linux-musl','aarch64-linux-musl','aarch64-macos','x86_64-windows-gnu','x86-linux-musl']:
  p=base/folder/('layout-'+target+'-'+phase+'.ll');result[phase][target]=decode(p);hashes[phase][target]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'layouts-resolved.json').write_text(json.dumps({'values':result,'ir_sha256':hashes,'extraction':'Resolve exported LLVM aliases to typed integer constants; require all six names per target','initial_extractor':'Direct exported-constant regex produced empty dictionaries; no size claim from that extraction'},indent=2)+'\n')
