from pathlib import Path
import json,subprocess,re,hashlib,sys
root=Path('/workspaces/uWebZockets');out=Path(__file__).resolve().parent;results={'baseline':json.loads((out.parent/'v3/layouts.json').read_text())['baseline']}
for phase,name in [('after','m2-h2-body-refusal')]:
 d=root/'.uwz-work/drafts'/name;results[phase]={}
 for target in ['native','x86_64-linux-musl','aarch64-linux-musl','aarch64-macos','x86_64-windows-gnu','x86-linux-musl']:
  c=json.loads((root/('.uwz-work/evidence/body-app/layout-'+target+'-after.command.json')).read_text());a=[('-Mroot='+str(out.parent/'v3/layout_probe.zig') if v.startswith('-Mroot=') else v) for v in c['argv']];a[a.index('--cache-dir')+1]='/tmp/uwz-h2-refusal-layout-cache';a[a.index('--global-cache-dir')+1]='/tmp/uwz-multipart-integrated-global';label='layout-'+target+'-'+phase;a[-1]='-femit-llvm-ir='+str(out/(label+'.ll'));rec={'argv':a,'cwd':str(d),'sources':{n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in ['src/http2/server.zig','src/http2/connection.zig','src/core/tcp.zig']}}
  r=subprocess.run(a,cwd=d,capture_output=True);(out/(label+'.log')).write_bytes(r.stdout+r.stderr);rec['exit_status']=r.returncode;(out/(label+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(label,r.returncode,flush=True)
  if r.returncode:print(r.stderr.decode()[-3000:],flush=True);sys.exit(r.returncode)
  ir=(out/(label+'.ll')).read_text();results[phase][target]={n:int(v) for n,v in re.findall(r'@(h2_\w+) = .*?constant i\d+ (\d+)',ir)}
  (out/'layouts.json').write_text(json.dumps(results,indent=2)+'\n')
