from pathlib import Path
import json,subprocess,time,hashlib,sys
out=Path(__file__).resolve().parent
for target in ['native','x86-linux-musl']:
 c=json.loads((out.parent/'v4'/('width-'+target+'-compile.json')).read_text());d=Path(c['cwd']);a=c['argv'];a[-1]='-femit-bin=/tmp/uwz-h2-width-v5-'+target
 rec={'argv':a,'cwd':str(d),'sources':{n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in ['src/http2/server.zig','src/http2/connection.zig','src/tests/body_h2_width_tests.zig','src/h2_width_support.zig']}};start=time.monotonic()
 with (out/('width-'+target+'-compile.log')).open('wb') as f:r=subprocess.run(a,cwd=d,stdout=f,stderr=subprocess.STDOUT)
 rec.update(exit_status=r.returncode,elapsed_seconds=time.monotonic()-start);(out/('width-'+target+'-compile.json')).write_text(json.dumps(rec,indent=2)+'\n');print(target,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
