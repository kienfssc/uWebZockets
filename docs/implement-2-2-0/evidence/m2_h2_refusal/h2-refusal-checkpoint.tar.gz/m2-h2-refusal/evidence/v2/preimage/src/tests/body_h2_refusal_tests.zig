const std = @import("std");
const support = @import("test_support");
const http2 = support.http2;
const hpack = support.http2_hpack;
const radix = support.radix;
const body = support.request_body;
const Request = support.http_request.Request;
const Response = support.http_response.Response;
const Session = support.tcp.Http2Session;
const RouterBundle = radix.Bundle(.{ .stream_request_bodies = true });
const SessionBundle = Session.Bundle(.{ .body_size = 32 });

/// Counts every application effect so refusal proves no admission or delivery.
const Sink = struct {
    calls: usize = 0,
    response_error: ?anyerror = null,

    fn definition(self: *Sink) body.BodyRoute {
        return .{
            .sink = .{ .context = self, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel },
            .limits = .{ .max_body_bytes = std.math.maxInt(u64), .max_active = 1 },
            .middleware_policy = .headers_only,
        };
    }

    fn begin(context: *anyopaque, _: *const support.streaming_request.StreamingRequest, _: body.BodyControl) !body.BodyBinding {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
        return .{ .context = self };
    }

    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
        return .{ .consumed = bytes.len, .readiness = .ready };
    }

    fn end(context: *anyopaque, _: *const support.streaming_request.StreamingRequest, _: *Response) !void {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
    }

    fn cancel(context: *anyopaque, _: body.BodyCancelReason) void {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
    }

    fn middleware(context: *anyopaque, _: *Request, _: *Response) radix.MiddlewareResult {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
        return .continue_dispatch;
    }

    fn handler(context: *anyopaque, _: *Request, response: *Response) void {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
        response.end("200 OK", "") catch |err| {
            self.response_error = err;
        };
    }
};

/// Uses the production TCP callbacks with its ordinary caller-owned write ring.
const Fixture = struct {
    router_bundle: RouterBundle = .{},
    router: radix.Router = .{},
    session_bundle: SessionBundle = .{},
    connection: support.tcp.TcpConnection = .{ .socket = undefined },
    output: [4096]u8 = undefined,
    block_headers: bool = false,
    block_reset: bool = false,

    fn init(self: *Fixture) !void {
        self.router = try radix.Router.init(self.router_bundle.storage());
        self.connection.router = &self.router;
        self.connection.write_queue = &self.output;
        self.connection.is_writing = true;
        self.connection.h2 = try Session.init(self.session_bundle.storage());
        try self.connection.reset_protocol();
        try self.connection.h2.receive(http2.client_preface, self.connection.http2_callbacks());
        try self.frame(.settings, 0, 0, "");
        self.drain();
    }

    fn drain(self: *Fixture) void {
        self.connection.write_head = 0;
        self.connection.write_len = 0;
    }

    fn frame(self: *Fixture, kind: http2.FrameType, flags: u8, id: u32, payload: []const u8) !void {
        var input: [16384 + 9]u8 = undefined;
        try (http2.FrameHeader{ .payload_length = @intCast(payload.len), .frame_type = @intFromEnum(kind), .flags = flags, .stream_id = id }).encode(input[0..9]);
        @memcpy(input[9..][0..payload.len], payload);
        try self.connection.h2.receive(input[0 .. 9 + payload.len], self.callbacks());
    }

    fn callbacks(self: *Fixture) support.http2_server.Callbacks {
        var result = self.connection.http2_callbacks();
        result.write_fn = write;
        return result;
    }

    fn write(context: *anyopaque, parts: []const []const u8) !void {
        const connection: *support.tcp.TcpConnection = @ptrCast(@alignCast(context));
        const self: *Fixture = @fieldParentPtr("connection", connection);
        const head = try http2.FrameHeader.parse(parts[0][0..9]);
        if (self.block_headers and head.frame_type == @intFromEnum(http2.FrameType.headers)) return error.WouldBlock;
        if (self.block_reset and head.frame_type == @intFromEnum(http2.FrameType.rst_stream)) return error.WouldBlock;
        try connection.http2_callbacks().write_fn(context, parts);
    }

    fn headers(self: *Fixture, method: []const u8, path: []const u8, fields: []const hpack.Header, eos: bool) !void {
        var block: [15000]u8 = undefined;
        var length: usize = 0;
        try literal(&block, &length, ":method", method);
        try literal(&block, &length, ":scheme", "https");
        try literal(&block, &length, ":path", path);
        for (fields) |field| try literal(&block, &length, field.name, field.value);
        try self.frame(.headers, 4 | @as(u8, @intFromBool(eos)), 1, block[0..length]);
    }

    fn bytes(self: *const Fixture) []const u8 {
        return self.output[0..self.connection.write_len];
    }
};

fn literal(output: []u8, length: *usize, name: []const u8, value: []const u8) !void {
    output[length.*] = 0;
    length.* += 1;
    try string(output, length, name);
    try string(output, length, value);
}

fn string(output: []u8, length: *usize, value: []const u8) !void {
    var remaining = value.len;
    output[length.*] = @intCast(@min(remaining, 127));
    length.* += 1;
    if (remaining >= 127) {
        remaining -= 127;
        while (remaining >= 128) {
            output[length.*] = @as(u8, @intCast(remaining % 128)) | 128;
            length.* += 1;
            remaining /= 128;
        }
        output[length.*] = @intCast(remaining);
        length.* += 1;
    }
    if (value.len > output.len - length.*) return error.OutputTooSmall;
    @memcpy(output[length.*..][0..value.len], value);
    length.* += value.len;
}

fn expect_refusal(output: []const u8, reset_expected: bool) !void {
    try std.testing.expect(output.len >= 9);
    const head = try http2.FrameHeader.parse(output[0..9]);
    try std.testing.expectEqual(@intFromEnum(http2.FrameType.headers), head.frame_type);
    try std.testing.expectEqual(@as(u8, 5), head.flags);
    var table = try hpack.DynamicTable.init(&.{}, &.{}, 0);
    var decoder = hpack.Decoder.init(&table, 512);
    var fields: [4]hpack.Header = undefined;
    var storage: [512]u8 = undefined;
    const decoded = try decoder.decode_fields(output[9..][0..head.payload_length], &fields, &storage);
    try std.testing.expectEqualStrings(":status", decoded[0].name);
    try std.testing.expectEqualStrings("503", decoded[0].value);
    try std.testing.expectEqualStrings("content-length", decoded[1].name);
    try std.testing.expectEqualStrings("0", decoded[1].value);
    const offset = 9 + head.payload_length;
    if (!reset_expected) return std.testing.expectEqual(offset, output.len);
    try std.testing.expectEqual(offset + 13, output.len);
    const reset = try http2.FrameHeader.parse(output[offset..][0..9]);
    try std.testing.expectEqual(@intFromEnum(http2.FrameType.rst_stream), reset.frame_type);
    try std.testing.expectEqual(@as(u32, 0), std.mem.readInt(u32, output[offset + 9 ..][0..4], .big));
}

test "body H2: selected body route refuses from headers without application effects" {
    var fixture = Fixture{};
    try fixture.init();
    var sink = Sink{};
    const definition = sink.definition();
    try fixture.router.route_body(.post, "/upload", &definition);
    try fixture.router.use(&sink, Sink.middleware);
    try fixture.headers("POST", "/upload", &.{.{ .name = "content-length", .value = "18446744073709551615" }}, false);
    try expect_refusal(fixture.bytes(), true);
    try std.testing.expectEqual(@as(usize, 0), sink.calls);
    for (fixture.router.body.active) |active| try std.testing.expectEqual(@as(u16, 0), active);
    for (fixture.connection.h2.body_lengths) |length| try std.testing.expectEqual(@as(usize, 0), length);
}
