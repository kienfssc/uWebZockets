const std = @import("std");
const support = @import("test_support");
const http2 = support.http2;
const hpack = support.http2_hpack;
const radix = support.radix;
const body = support.request_body;
const Request = support.http_request.Request;
const Response = support.http_response.Response;
const Session = support.tcp.Http2Session;
const RouterBundle = radix.Bundle(.{ .stream_request_bodies = true });
const SessionBundle = Session.Bundle(.{ .body_size = 32 });

/// Counts every application effect so refusal proves no admission or delivery.
const Sink = struct {
    calls: usize = 0,
    response_error: ?anyerror = null,

    fn definition(self: *Sink) body.BodyRoute {
        return .{
            .sink = .{ .context = self, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel },
            .limits = .{ .max_body_bytes = std.math.maxInt(u64), .max_active = 1 },
            .middleware_policy = .headers_only,
        };
    }

    fn begin(context: *anyopaque, _: *const support.streaming_request.StreamingRequest, _: body.BodyControl) !body.BodyBinding {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
        return .{ .context = self };
    }

    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
        return .{ .consumed = bytes.len, .readiness = .ready };
    }

    fn end(context: *anyopaque, _: *const support.streaming_request.StreamingRequest, _: *Response) !void {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
    }

    fn cancel(context: *anyopaque, _: body.BodyCancelReason) void {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
    }

    fn middleware(context: *anyopaque, _: *Request, _: *Response) radix.MiddlewareResult {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
        return .continue_dispatch;
    }

    fn handler(context: *anyopaque, _: *Request, response: *Response) void {
        const self: *Sink = @ptrCast(@alignCast(context));
        self.calls += 1;
        response.end("200 OK", "") catch |err| {
            self.response_error = err;
        };
    }
};

/// Uses the production TCP callbacks with its ordinary caller-owned write ring.
const Fixture = struct {
    router_bundle: RouterBundle = .{},
    router: radix.Router = .{},
    session_bundle: SessionBundle = .{},
    connection: support.tcp.TcpConnection = .{ .socket = undefined },
    output: [4096]u8 = undefined,
    block_headers: bool = false,
    block_reset: bool = false,

    fn init(self: *Fixture) !void {
        self.router = try radix.Router.init(self.router_bundle.storage());
        self.connection.router = &self.router;
        self.connection.write_queue = &self.output;
        self.connection.is_writing = true;
        self.connection.h2 = try Session.init(self.session_bundle.storage());
        try self.connection.reset_protocol();
        try self.connection.h2.receive(http2.client_preface, self.connection.http2_callbacks());
        try self.frame(.settings, 0, 0, "");
        self.drain();
    }

    fn drain(self: *Fixture) void {
        self.connection.write_head = 0;
        self.connection.write_len = 0;
    }

    fn frame(self: *Fixture, kind: http2.FrameType, flags: u8, id: u32, payload: []const u8) !void {
        var input: [16384 + 9]u8 = undefined;
        try (http2.FrameHeader{ .payload_length = @intCast(payload.len), .frame_type = @intFromEnum(kind), .flags = flags, .stream_id = id }).encode(input[0..9]);
        @memcpy(input[9..][0..payload.len], payload);
        try self.connection.h2.receive(input[0 .. 9 + payload.len], self.callbacks());
    }

    fn callbacks(self: *Fixture) support.http2_server.Callbacks {
        var result = self.connection.http2_callbacks();
        result.write_fn = write;
        return result;
    }

    fn write(context: *anyopaque, parts: []const []const u8) !void {
        const connection: *support.tcp.TcpConnection = @ptrCast(@alignCast(context));
        const self: *Fixture = @fieldParentPtr("connection", connection);
        const head = try http2.FrameHeader.parse(parts[0][0..9]);
        if (self.block_headers and head.frame_type == @intFromEnum(http2.FrameType.headers)) return error.WouldBlock;
        if (self.block_reset and head.frame_type == @intFromEnum(http2.FrameType.rst_stream)) return error.WouldBlock;
        try connection.http2_callbacks().write_fn(context, parts);
    }

    fn headers(self: *Fixture, stream_id: u32, method: []const u8, path: []const u8, fields: []const hpack.Header, eos: bool) !void {
        var block: [15000]u8 = undefined;
        var length: usize = 0;
        try literal(&block, &length, ":method", method);
        try literal(&block, &length, ":scheme", "https");
        try literal(&block, &length, ":path", path);
        for (fields) |field| try literal(&block, &length, field.name, field.value);
        try self.frame(.headers, 4 | @as(u8, @intFromBool(eos)), stream_id, block[0..length]);
    }

    fn bytes(self: *const Fixture) []const u8 {
        return self.output[0..self.connection.write_len];
    }
};

fn literal(output: []u8, length: *usize, name: []const u8, value: []const u8) !void {
    output[length.*] = 0;
    length.* += 1;
    try string(output, length, name);
    try string(output, length, value);
}

fn string(output: []u8, length: *usize, value: []const u8) !void {
    var remaining = value.len;
    output[length.*] = @intCast(@min(remaining, 127));
    length.* += 1;
    if (remaining >= 127) {
        remaining -= 127;
        while (remaining >= 128) {
            output[length.*] = @as(u8, @intCast(remaining % 128)) | 128;
            length.* += 1;
            remaining /= 128;
        }
        output[length.*] = @intCast(remaining);
        length.* += 1;
    }
    if (value.len > output.len - length.*) return error.OutputTooSmall;
    @memcpy(output[length.*..][0..value.len], value);
    length.* += value.len;
}

fn expect_response(output: []const u8, stream_id: u32, status: []const u8, reset_expected: bool) !void {
    try std.testing.expect(output.len >= 9);
    const head = try http2.FrameHeader.parse(output[0..9]);
    try std.testing.expectEqual(@intFromEnum(http2.FrameType.headers), head.frame_type);
    try std.testing.expectEqual(@as(u8, 5), head.flags);
    var table = try hpack.DynamicTable.init(&.{}, &.{}, 0);
    var decoder = hpack.Decoder.init(&table, 512);
    var fields: [4]hpack.Header = undefined;
    var storage: [512]u8 = undefined;
    const decoded = try decoder.decode_fields(output[9..][0..head.payload_length], &fields, &storage);
    try std.testing.expectEqualStrings(":status", decoded[0].name);
    try std.testing.expectEqualStrings(status, decoded[0].value);
    try std.testing.expectEqual(stream_id, head.stream_id);
    try std.testing.expectEqualStrings("content-length", decoded[1].name);
    try std.testing.expectEqualStrings("0", decoded[1].value);
    const offset = 9 + head.payload_length;
    if (!reset_expected) return std.testing.expectEqual(offset, output.len);
    try std.testing.expectEqual(offset + 13, output.len);
    const reset = try http2.FrameHeader.parse(output[offset..][0..9]);
    try std.testing.expectEqual(@intFromEnum(http2.FrameType.rst_stream), reset.frame_type);
    try std.testing.expectEqual(stream_id, reset.stream_id);
    try std.testing.expectEqual(@as(u32, 0), std.mem.readInt(u32, output[offset + 9 ..][0..4], .big));
}

test "body H2: selected body route refuses from headers without application effects" {
    var fixture = Fixture{};
    try fixture.init();
    var sink = Sink{};
    const definition = sink.definition();
    try fixture.router.route_body(.post, "/upload", &definition);
    try fixture.router.use(&sink, Sink.middleware);
    try fixture.headers(1, "POST", "/upload", &.{.{ .name = "content-length", .value = "18446744073709551615" }}, false);
    try expect_response(fixture.bytes(), 1, "503", true);
    try std.testing.expectEqual(@as(usize, 0), sink.calls);
    for (fixture.router.body.active) |active| try std.testing.expectEqual(@as(u16, 0), active);
    for (fixture.connection.h2.body_lengths) |length| try std.testing.expectEqual(@as(usize, 0), length);
}

const LengthCase = struct {
    value: ?[]const u8,
    end_stream: bool,
};

test "body H2: valid length and Expect refuse before route limits or quota" {
    const cases = [_]LengthCase{
        .{ .value = null, .end_stream = false },
        .{ .value = null, .end_stream = true },
        .{ .value = "0", .end_stream = true },
        .{ .value = "0", .end_stream = false },
        .{ .value = "1", .end_stream = false },
        .{ .value = "33", .end_stream = false },
        .{ .value = "4294967296", .end_stream = false },
        .{ .value = "18446744073709551615", .end_stream = false },
    };
    for (cases) |case| {
        var fixture = Fixture{};
        try fixture.init();
        var sink = Sink{};
        var definition = sink.definition();
        definition.limits.max_body_bytes = 1;
        try fixture.router.route_body(.post, "/upload", &definition);
        try fixture.router.use(&sink, Sink.middleware);
        const record = fixture.router.match("/upload", .post).?.body_match.?.record_index;
        fixture.router.body.active[record] = 1;
        if (case.value) |value| {
            try fixture.headers(1, "POST", "/upload", &.{
                .{ .name = "content-length", .value = value },
                .{ .name = "expect", .value = "100-continue" },
            }, case.end_stream);
        } else {
            try fixture.headers(1, "POST", "/upload", &.{.{ .name = "expect", .value = "100-continue" }}, case.end_stream);
        }
        try expect_response(fixture.bytes(), 1, "503", true);
        try std.testing.expectEqual(@as(usize, 0), sink.calls);
        try std.testing.expectEqual(@as(u16, 1), fixture.router.body.active[record]);
    }
}

fn expect_reset(output: []const u8, code: support.http2_server.ErrorCode) !void {
    try std.testing.expectEqual(@as(usize, 13), output.len);
    const head = try http2.FrameHeader.parse(output[0..9]);
    try std.testing.expectEqual(@intFromEnum(http2.FrameType.rst_stream), head.frame_type);
    try std.testing.expectEqual(@as(u32, 1), head.stream_id);
    try std.testing.expectEqual(@intFromEnum(code), std.mem.readInt(u32, output[9..13], .big));
}

test "body H2: known EOS length mismatch precedes temporary refusal" {
    var fixture = Fixture{};
    try fixture.init();
    var sink = Sink{};
    const definition = sink.definition();
    try fixture.router.route_body(.post, "/upload", &definition);
    try fixture.headers(1, "POST", "/upload", &.{.{ .name = "content-length", .value = "1" }}, true);
    try expect_reset(fixture.bytes(), .protocol_error);
    try std.testing.expectEqual(@as(usize, 0), sink.calls);
}

test "body H2: malformed and duplicate lengths remain stream errors" {
    const invalid = [_][]const u8{ "", "x", "-1", "18446744073709551616" };
    for (invalid) |value| {
        var fixture = Fixture{};
        try fixture.init();
        var sink = Sink{};
        const definition = sink.definition();
        try fixture.router.route_body(.post, "/upload", &definition);
        try fixture.headers(1, "POST", "/upload", &.{.{ .name = "content-length", .value = value }}, false);
        try expect_reset(fixture.bytes(), .protocol_error);
        try std.testing.expectEqual(@as(usize, 0), sink.calls);
    }
    var fixture = Fixture{};
    try fixture.init();
    var sink = Sink{};
    const definition = sink.definition();
    try fixture.router.route_body(.post, "/upload", &definition);
    try fixture.headers(1, "POST", "/upload", &.{
        .{ .name = "content-length", .value = "1" },
        .{ .name = "content-length", .value = "1" },
    }, false);
    try expect_reset(fixture.bytes(), .protocol_error);
    try std.testing.expectEqual(@as(usize, 0), sink.calls);
}

test "body H2: rejected copy retains the first buffered cap error" {
    var fixture = Fixture{};
    try fixture.init();
    var sink = Sink{};
    const definition = sink.definition();
    try fixture.router.route_body(.post, "/upload", &definition);
    try fixture.headers(1, "POST", "/upload", &.{
        .{ .name = "content-length", .value = "33" },
        .{ .name = "content-length", .value = "bad" },
    }, false);
    try expect_reset(fixture.bytes(), .enhance_your_calm);
    try std.testing.expectEqual(@as(usize, 0), sink.calls);
}

test "body H2: final headers precede one reset across blocked output" {
    var fixture = Fixture{};
    try fixture.init();
    var sink = Sink{};
    const definition = sink.definition();
    try fixture.router.route_body(.post, "/upload", &definition);
    fixture.block_headers = true;
    try fixture.headers(1, "POST", "/upload", &.{.{ .name = "content-length", .value = "100" }}, false);
    const index = fixture.connection.h2.connection.streams.find(1).?;
    try std.testing.expectEqual(@as(usize, 0), fixture.bytes().len);
    try std.testing.expect(fixture.connection.h2.pending_header_ready[index]);
    try std.testing.expectEqual(@as(usize, 0), fixture.connection.h2.pending_reset_count);
    const payload = [_]u8{'x'} ** 64;
    try fixture.frame(.data, 0, 1, &payload);
    try std.testing.expectEqual(@as(usize, 0), fixture.connection.h2.body_lengths[index]);
    try std.testing.expectEqual(@as(usize, 0), fixture.connection.h2.requests[index].body.len);
    try std.testing.expectEqual(@as(i32, 65535), fixture.connection.h2.connection.connection_receive_window);
    try std.testing.expectEqual(@as(i32, 65535), fixture.connection.h2.connection.streams.receive_windows[index]);
    try std.testing.expectEqual(@as(usize, 26), fixture.bytes().len);
    for ([_]u32{ 0, 1 }, 0..) |stream_id, i| {
        const offset = i * 13;
        const update = try http2.FrameHeader.parse(fixture.bytes()[offset..][0..9]);
        try std.testing.expectEqual(@intFromEnum(http2.FrameType.window_update), update.frame_type);
        try std.testing.expectEqual(stream_id, update.stream_id);
        try std.testing.expectEqual(@as(u32, 64), std.mem.readInt(u32, fixture.bytes()[offset + 9 ..][0..4], .big));
    }
    fixture.drain();
    fixture.block_reset = true;
    fixture.block_headers = false;
    try fixture.connection.h2.flush_pending(fixture.callbacks());
    try expect_response(fixture.bytes(), 1, "503", false);
    try std.testing.expectEqual(@as(usize, 1), fixture.connection.h2.pending_reset_count);
    try std.testing.expect(fixture.connection.h2.connection.streams.find(1) == null);
    fixture.block_reset = false;
    try fixture.connection.h2.flush_pending(fixture.callbacks());
    try expect_response(fixture.bytes(), 1, "503", true);
    try fixture.connection.h2.flush_pending(fixture.callbacks());
    try expect_response(fixture.bytes(), 1, "503", true);
    try std.testing.expectEqual(@as(usize, 0), sink.calls);
}

test "body H2: late DATA restores connection credit after refusal and sibling completes" {
    var fixture = Fixture{};
    try fixture.init();
    var sink = Sink{};
    const definition = sink.definition();
    try fixture.router.route_body(.post, "/upload", &definition);
    try fixture.router.route_context(.get, "/plain", &sink, Sink.handler);
    try fixture.headers(1, "POST", "/upload", &.{}, false);
    try expect_response(fixture.bytes(), 1, "503", true);
    fixture.drain();
    try fixture.frame(.data, 0, 1, "late");
    try std.testing.expectEqual(@as(usize, 13), fixture.bytes().len);
    const update = try http2.FrameHeader.parse(fixture.bytes()[0..9]);
    try std.testing.expectEqual(@intFromEnum(http2.FrameType.window_update), update.frame_type);
    try std.testing.expectEqual(@as(u32, 0), update.stream_id);
    try std.testing.expectEqual(@as(u32, 4), std.mem.readInt(u32, fixture.bytes()[9..13], .big));
    try std.testing.expectEqual(@as(i32, 65535), fixture.connection.h2.connection.connection_receive_window);
    fixture.drain();
    try fixture.headers(3, "GET", "/plain", &.{}, true);
    try expect_response(fixture.bytes(), 3, "200", false);
    try std.testing.expectEqual(@as(usize, 1), sink.calls);
    try std.testing.expect(sink.response_error == null);
    try std.testing.expect(!fixture.connection.h2.closed);
}

test "body H2: canonical HEAD fallback and ANY preserve explicit buffered methods" {
    var fixture = Fixture{};
    try fixture.init();
    var sink = Sink{};
    const definition = sink.definition();
    try fixture.router.route_body(.get, "/head", &definition);
    try fixture.router.route_body(.any, "/shared", &definition);
    try fixture.router.route_context(.get, "/shared", &sink, Sink.handler);
    try fixture.headers(1, "HEAD", "/head", &.{}, true);
    try expect_response(fixture.bytes(), 1, "503", true);
    fixture.drain();
    try fixture.headers(3, "GET", "/shared", &.{}, true);
    try expect_response(fixture.bytes(), 3, "200", false);
    try std.testing.expectEqual(@as(usize, 1), sink.calls);
    fixture.drain();
    try fixture.headers(5, "POST", "/shared", &.{}, false);
    try expect_response(fixture.bytes(), 5, "503", true);
    fixture.drain();
    try fixture.headers(7, "BREW", "/shared", &.{}, false);
    try expect_response(fixture.bytes(), 7, "503", true);
    try std.testing.expectEqual(@as(usize, 1), sink.calls);
    try std.testing.expect(sink.response_error == null);
}

test "body H2: pattern selection imposes no registration-sized incoming path cap" {
    var fixture = Fixture{};
    try fixture.init();
    var sink = Sink{};
    const definition = sink.definition();
    try fixture.router.route_body(.post, "/:id", &definition);
    var path: [4097]u8 = [_]u8{'x'} ** 4097;
    path[0] = '/';
    try std.testing.expect(path.len > fixture.router.max_route_path_size);
    try fixture.headers(1, "POST", &path, &.{}, false);
    try expect_response(fixture.bytes(), 1, "503", true);
    try std.testing.expectEqual(@as(usize, 0), sink.calls);
}

test "body H2: buffered selection preserves declared cap and first-error precedence" {
    var fixture = Fixture{};
    try fixture.init();
    var sink = Sink{};
    const definition = sink.definition();
    try fixture.router.route_body(.post, "/upload", &definition);
    try fixture.router.route_context(.post, "/plain", &sink, Sink.handler);
    try fixture.headers(1, "POST", "/plain", &.{
        .{ .name = "content-length", .value = "33" },
        .{ .name = "content-length", .value = "bad" },
    }, false);
    try expect_reset(fixture.bytes(), .enhance_your_calm);
    try std.testing.expectEqual(@as(usize, 0), sink.calls);
    fixture.drain();
    try fixture.headers(3, "POST", "/plain", &.{.{ .name = "content-length", .value = "0" }}, true);
    try expect_response(fixture.bytes(), 3, "200", false);
    try std.testing.expectEqual(@as(usize, 1), sink.calls);
}

test "body H2: blocked reset keeps a buffered sibling response queued in order" {
    var fixture = Fixture{};
    try fixture.init();
    var sink = Sink{};
    const definition = sink.definition();
    try fixture.router.route_body(.post, "/upload", &definition);
    try fixture.router.route_context(.get, "/plain", &sink, Sink.handler);
    fixture.block_reset = true;
    try fixture.headers(1, "POST", "/upload", &.{}, false);
    try expect_response(fixture.bytes(), 1, "503", false);
    fixture.drain();
    try fixture.headers(3, "GET", "/plain", &.{}, true);
    try std.testing.expectEqual(@as(usize, 1), sink.calls);
    try std.testing.expectEqualSlices(u8, &.{}, fixture.bytes());
    try std.testing.expectEqual(@as(usize, 1), fixture.connection.h2.pending_reset_count);
    fixture.block_reset = false;
    try fixture.connection.h2.flush_pending(fixture.callbacks());
    try std.testing.expect(fixture.bytes().len >= 13);
    const reset = try http2.FrameHeader.parse(fixture.bytes()[0..9]);
    try std.testing.expectEqual(@intFromEnum(http2.FrameType.rst_stream), reset.frame_type);
    try std.testing.expectEqual(@as(u32, 1), reset.stream_id);
    try expect_response(fixture.bytes()[13..], 3, "200", false);
    const length = fixture.bytes().len;
    try fixture.connection.h2.flush_pending(fixture.callbacks());
    try std.testing.expectEqual(length, fixture.bytes().len);
    try std.testing.expect(sink.response_error == null);
    try std.testing.expect(!fixture.connection.h2.closed);
}
