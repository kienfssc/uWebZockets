# H2 refusal completion scope

Continue the accepted header-only refusal plan in this isolated draft. Keep
production root untouched and preserve all prior source/evidence freezes.
Valid canonical body routes receive empty503 before effects, even over quota
or declared bounds. Known EOS/length mismatch and malformed headers fail
closed. Ordinary buffered routing/error precedence remains unchanged.

Add observable frame-order, pending reset, discarded-DATA credit, route and
sibling tests. Preserve first legacy copy error when deferring valid u64 body
limits. Run the unchanged HTTP2 suite, compiler/layout/closed-consumer checks,
then freeze for independent review. The component cannot land without H1.
No native cancellation/fault/race/crash probe, backend patch, pin or public
capability change is part of this scope.
