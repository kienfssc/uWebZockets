# Output-pressure fixture correction

The first eleven-case run passed ten cases and failed a new blocked-reset/sibling
assertion with 27 output bytes. The diagnostic empty-slice assertion retains the
wire bytes: a reset and a sibling final header were actually accepted.

The initial fixture replaced receive's write callback, while an application
response gets fresh production TCP callbacks. The artificial block_reset flag
therefore did not constrain that response path. The production send_frame gate
already flushes pending resets before HEADERS/DATA; no production defect was
established by this run.

The corrected fixture fills the actual caller-owned write ring until only twelve
bytes remain. Both callback paths now face real capacity backpressure. It asserts
no new queued bytes, then drains that prefix and verifies the reset precedes the
sibling response exactly once. No assertion or production gate is weakened.
