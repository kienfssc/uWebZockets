from pathlib import Path
import json,subprocess,time,hashlib,sys
root=Path('/workspaces/uWebZockets');out=Path(__file__).resolve().parent;c=json.loads((out/'expanded-Debug.command.json').read_text());base=c['argv'];d=Path(c['cwd'])
paths=['src/http2/server.zig','src/core/tcp.zig','src/tests/body_h2_refusal_tests.zig','src/tests/http2_server_tests.zig']
def hashes():return {n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in paths}
for label,module,mode in [('focused-Debug-final','src/tests/body_h2_refusal_tests.zig','Debug'),('focused-ReleaseSafe-final','src/tests/body_h2_refusal_tests.zig','ReleaseSafe'),('legacy-http2-Debug','src/tests/http2_server_tests.zig','Debug')]:
 a=[('-O'+mode if x=='-ODebug' else '-Mroot='+module if x.startswith('-Mroot=') else '-femit-bin=/tmp/uwz-h2-'+label if x.startswith('-femit-bin=') else x) for x in base];start=time.monotonic();rec={'argv':a,'cwd':str(d),'source_before':hashes()};(out/(label+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print('START',label,flush=True)
 with (out/(label+'.log')).open('wb') as f:r=subprocess.run(a,cwd=d,stdout=f,stderr=subprocess.STDOUT)
 rec.update(exit_status=r.returncode,elapsed_seconds=time.monotonic()-start,source_after=hashes());(out/(label+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print('END',label,r.returncode,round(rec['elapsed_seconds'],2),flush=True)
 if r.returncode:print((out/(label+'.log')).read_text()[-8000:],flush=True);sys.exit(r.returncode)
