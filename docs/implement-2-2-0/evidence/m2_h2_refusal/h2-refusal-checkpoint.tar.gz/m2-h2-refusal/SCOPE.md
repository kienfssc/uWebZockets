# Isolated HTTP/2 body-route refusal checkpoint

No production integration or live uploads. Independent review remains pending.
Restore m2-transport-preparation.tar.gz (SHA256 a079931a4c13dac96546390f316e708a8f491c4a2392c6c19be6f1dbcd6a968b), then copy overlay/drafts/m2-h2-body-refusal/ over that archive's corresponding draft directory. All other archived source bytes match. The delta manifest and patch bind the exact replacements and new files. The four-alias src/h2_width_support.zig is verification-only; central tests use ordinary test_support.

The final v5 command records are authoritative for the final source. v2/v3/v4 retain earlier source states, intentional red cases and fixture corrections. An exploratory v5 green record inherited stale hashes; green-binding-note.json explains this and points to final immutable-source runs. The first v5 unchanged legacy suite encountered sandbox EPERM; socket-access runs pass all 69 tests in both modes. No test was skipped or weakened.

Layout extraction must resolve exported LLVM aliases. Initial empty dictionaries are not measurements; layouts-resolved.json requires six complete fields per target. Baseline is the separate prepared App/R2 draft, not current production. Full combined gates, independent review, live clients, H1 consumer, H3 refusal and actual H2 upload driver remain required.
