from pathlib import Path
import tarfile,hashlib,io,json,gzip,re,os
root=Path('/workspaces/uWebZockets');e=root/'.uwz-work/evidence/h2-body-refusal';out=root/'docs/implement-2-2-0/evidence/m2_h2_refusal';out.mkdir(parents=True,exist_ok=True);d=root/'.uwz-work/drafts/m2-h2-body-refusal'
m=json.loads((e/'v5/delta-source-manifest.json').read_text());files={}
for n in m['changed']:files['overlay/drafts/m2-h2-body-refusal/'+n]=(d/n).read_bytes()
for v in ['v2','v3','v4','v5']:
 for p in (e/v).rglob('*'):
  if p.is_file():files['evidence/'+str(p.relative_to(e))]=p.read_bytes()
files['SCOPE.md']=b'''# Isolated HTTP/2 body-route refusal checkpoint

No production integration or live uploads. Independent review remains pending.
Restore m2-transport-preparation.tar.gz (SHA256 a079931a4c13dac96546390f316e708a8f491c4a2392c6c19be6f1dbcd6a968b), then copy overlay/drafts/m2-h2-body-refusal/ over that archive's corresponding draft directory. All other archived source bytes match. The delta manifest and patch bind the exact replacements and new files. The four-alias src/h2_width_support.zig is verification-only; central tests use ordinary test_support.

The final v5 command records are authoritative for the final source. v2/v3/v4 retain earlier source states, intentional red cases and fixture corrections. An exploratory v5 green record inherited stale hashes; green-binding-note.json explains this and points to final immutable-source runs. The first v5 unchanged legacy suite encountered sandbox EPERM; socket-access runs pass all 69 tests in both modes. No test was skipped or weakened.

Layout extraction must resolve exported LLVM aliases. Initial empty dictionaries are not measurements; layouts-resolved.json requires six complete fields per target. Baseline is the separate prepared App/R2 draft, not current production. Full combined gates, independent review, live clients, H1 consumer, H3 refusal and actual H2 upload driver remain required.
'''
files['package_checkpoint.py']=Path(__file__).read_bytes()
patterns=[re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}'),re.compile(rb'github_pat_[A-Za-z0-9_]{20,}')]
secrets=[v.encode() for k,v in os.environ.items() if re.search('TOKEN|SECRET|PASSWORD|API_KEY',k) and len(v)>=16]
for n,b in files.items():
 if any(p.search(b) for p in patterns) or any(s in b for s in secrets):raise SystemExit('credential scan match in '+n)
inv={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in sorted(files.items())};files['INVENTORY.json']=(json.dumps(inv,indent=2)+'\n').encode()
a=out/'h2-refusal-checkpoint.tar.gz'
with a.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for n,b in sorted(files.items()):
    ti=tarfile.TarInfo('m2-h2-refusal/'+n);ti.size=len(b);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(b))
with tarfile.open(a) as t:
 for ti in t.getmembers():
  assert ti.isfile() and not ti.name.startswith('/') and '..' not in Path(ti.name).parts
  n=ti.name.removeprefix('m2-h2-refusal/');assert t.extractfile(ti).read()==files[n]
summary={'date':'2026-10-27','scope':'Isolated HTTP/2 header refusal; not integrated, independent review pending','archive':a.name,'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'archive_bytes':a.stat().st_size,'safe_regular_members':len(files),'inventory_entries':len(inv),'base_archive_sha256':m['recovery_archive_sha256'],'final_sources':m['changed'],'final_results':{'focused_Debug':14,'focused_ReleaseSafe':14,'unchanged_HTTP2_Debug':69,'unchanged_HTTP2_ReleaseSafe':69,'pure_native_and_Linux32':{'tests_per_target':1,'wire_cases_per_test':7},'target_layout_compiles':6,'fmt':0,'conventions':0,'release':0},'credential_scan':'No retained byte matches to environment credential values or GitHub token patterns','files':inv}
(out/'manifest.json').write_text(json.dumps(summary,indent=2)+'\n');print({k:v for k,v in summary.items() if k not in ['files','final_sources']})
