# Task4a: native startup storage and stable H2 owner binding

Task3 is independently reviewed: F1-F4 all addressed, no actionable scoped
re-review findings. Continue the full H2 plan through the startup slice of
native_handoff_2026_10_28.md. This task is actual implementation of required
startup ownership, not final native H2 activation or a replacement acceptance.

Use a NEW regular-byte source copy /tmp/uwz-m2-h2-native-startup from immutable
/tmp/uwz-m2-h2-session-delivery,1029files,digest
1d53c6704d8f31c333052998a85a293834276f386b4239fdbf44556496a5342e.
Verify every file against fix1/final-source.json before editing. Never mutate
that baseline, prior copies, Root source or prior evidence. All large artifacts,
copies, caches, binaries and IR stay /tmp. Small records/snapshots/patches go in
.uwz-work/evidence/h2-streaming/native-startup; report task-4a-report.md here.

Own only these five candidate paths:

- src/router/config.zig
- src/core/http1_upload_storage.zig
- src/router/app.zig
- src/tests/config_tests.zig
- src/tests/body_app_tests.zig

Read the native handoff, original H2 plan/ADR0008, relevant dx_router and
transport_io instructions and narrow applicable skills. Existing plan is approved;
do not start a new user interview, broad scan, dependency task or agent team.
If a genuine extra path/field is necessary, explain it to Root before mutation.

## Implemented boundary and storage permission

1. Propagate existing stream_request_bodies into config.h2_capacities. Extend
   actual layout offsets, typed SlabLayout and carving with enabled-only
   concrete H2 driver owners and two per-stream capture overflow matrices.
   Use Session's existing enabled pool/receive carving exactly once. Check
   products, bounds and alignment; overflow is max_route_params-16 only when
   positive, eight streams per connection. Disabled regions are empty/null.
2. Root authorizes one optional typed H2-driver pointer in the existing H1 cold
   owner, no extra TcpConnection pointer. Initialize each driver at its stable
   slab address once during App.init_from_slab and attach that pointer. Driver.bind
   is startup-only: never repeat it in connection accept/reset/reuse. Keep Session
   and native contexts at stable connection-slab addresses. Bind App/router/Loop
   associations late in App.loop_handle beside existing guarded H1 association.
   Pre-binding drain/rollback must inspect initialized slot state only and never
   dereference undefined/unbound late pointers. Preserve the cold pointer and
   generation state through existing inert/drained reset paths.
3. Keep native body_select_fn/body_event_fn activation gated. TCP adapter,
   early-data-aware native resolver, whole-Session borrows, no-output terminal
   operation and active generation-preserving reset belong to the next native
   composition slice. Do not edit TCP/Session/driver here or claim native delivery.
   Existing legacy H2 refusal and all H1/TLS/constructor behavior must survive.

Those typed owner/capture descriptors and the planned cold pointer are approved.
Any other stored field/region, capacity increase or API/error change needs Root's
fresh ruling. No speculative wrapper, stored Response/factory or allocator on
request/IO paths. Preserve default-disabled warm growth8192 relative to composed
pre-Session baseline. Measure final actual types/descriptors/offsets/carved totals
on Linux/macOS/Windows before updating exact expectations. Explain enabled growth
using actual Session pool74336, driver1288, cold-owner delta, capture matrices and
alignment. Do not assume an eight-byte owner delta or proposed profile totals.

## Evidence and acceptance

Add meaningful failing-first pure coverage with actual caller-owned buffers.
The old existing h2_capacities flag can demonstrate a behavioral red; missing
new declarations are declaration evidence only. Cover disabled/explicitly enabled
plans, complete bounds/disjointness/alignment, positive body stride independence,
multiple connection/stream ownership and capture overflow at20 params. Preserve
all real failures; no bad stubs, fake huge slices or fabricated native outcomes.
Use existing approved healthy App startup fixtures to add stable-pointer/late-
binding/inert-reset assertions; no new socket/client/scheduler/native-fault cases.
Inspect their source before execution and keep prebinding pointer reads valid.

Freeze before final recorded checks. Run covering pure config/carve checks and
affected approved healthy App/H1/H2 regressions in Debug/ReleaseSafe. Compile the
whole central graph on the three targets and eligible32-bit declarations/plans;
retain existing complete-driver32 blockers as such. Run formatting, conventions,
version/docs, exact three-target accounting and independent identical-copy AST.
Broaden checks only for changed paths or actual unresolved concerns.

Runtime H2-server filter remains exactly http2 server: (40/69), healthy App remains
the eight positive filters in Task3's report (8/31), with their added assertions.
Allocation-failure/resource/native timer/cancellation and socket cases remain
compile-only. Do not run full isolated native central runtime, reconstruct or
retry the stopped experiment or the two sandbox-denied socket cases. No native
cancellation schedule/interleaving/race/crash/leak/invalid-fd/kernel/registration/
resource-exhaustion/injected-completion/panic probes, new clients or live servers.
Ordinary owned client verification waits reviewed native composition and scoped
Root authorization. Keep assertions, errors, thresholds and backend expectations.

Use original r2 modules, c223 immutable93-file override, existing libraries and
Zig0.16 compiler -j2 with two affinity CPUs. Inherited tool paths/input identities
from Task3 remain binding. No dependency fetch/pin/ref/publication, Root commits,
pushes, subagents, client artifacts or other-agent reverts. You are not alone.

Provide commands/raw statuses, exact source/input/binary/environment hashes,
preimages/final snapshots, full source inventory, Git patch reconstruction and
source-only review package. Report actual measured growth and remaining native
acceptance explicitly. Root independently reviews before composition/activation.
Graph rule: query first before new codebase search/source reads. Use root's
existing graphify prefix; supplied/previously located paths can be read directly.
Refresh after code edits on an independent identical copy; graph output ignored.

## Capacity continuation and scoped rulings

The first worker stopped with an authoritative model-capacity error after
preparing the copy and asking scope questions. Root verified all1029 files in
/tmp/uwz-m2-h2-native-startup still match1d53 exactly, with zero changed paths;
native-startup/root-capacity-checkpoint.json preserves that complete inventory.
The replacement continues this existing copy, never recreates it. No Task4a
behavior/tests have completed, and no Task3 sequence is to be repeated.

Ruling: cold-owner drain checks may inspect initialized H2 slot phase/reservation/
callback fields now, and inert reset preserves the H2 pointer and generations.
They must not read unbound target/session context; active reset/no-output closure
composition remains next-slice work. This adds the required storage drain bound
without changing native release ordering.

Ruling: allow a named opaque-context-to-Router admission callback adapter for
late Target binding that invokes existing neutral policy. The explicit cast and
stable router association earn its type/lifetime guarantee; no generic factory,
new stored field or policy duplication is permitted. Preserve the caller's
early_data_forbidden input unchanged. The future native TCP adapter must derive
that flag from actual connection policy before invoking this target. Body
callbacks remain gated, so this slice advertises no native admission/delivery.
