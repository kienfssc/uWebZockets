# SDD ledger — plan: .uwz-work/evidence/h2-streaming/h2_streaming_plan.md

Plan .uwz-work/evidence/h2-streaming/h2_streaming_plan.md.
Root source baseline89dce088f5684c9173c45c572e785e7ff9c57991eb152ec76c46a58db481479d.

| Task pair/self | Interface checked | Finding and ruling |
| --- | --- | --- |
| Queue/Session next task | Blocks and credit amounts | Pure executable core first; actual Session output acceptance and startup storage integration follow, no H2 delivery claim from core alone. |
| Queue/App/TCP next tasks | Separate ownership | No edits outside four assigned paths. Native glue waits stable reviewed TLS; source copy is independent of active TLS clients. |
| Queue self | Formula and fragmentation | Canonical ADR bound73728 at8streams; Root's erroneous2W+2F dispatch was withdrawn before changes. No extra pool or ADR amendment. |
| Queue self | Tests versus effects | Caller-owned byte/data operations are meaningful; no fake native outcomes, huge fabricated slices or polling probes. |
| Credit self | Pending versus accepted scope | Prepare/validate does not restore windows; separate accepted-scope commits preserve retry/reset accounting. No invented transaction framework. |
| Task1 self | Standalone foundation versus dead code | Core is required by accepted concrete H2 driver; integration is a dependent gate before adoption, not a capability milestone. |

Root authorizes only Task1 pure queue/credit core now. No Connection/Session/App/
config/TCP integration or stored layout change is authorized in this slice.
Project independent-copy parallel workflow applies; Root commits/pushes verified
recovery checkpoints and serializes eventual test/source promotion.

- [x] Task1 core, meaningful checks and independent review.
- [ ] Concrete Session/storage/admission/driver/TCP composition and actual H2 proof.

Task 1: complete (commit 7766d26, independent protocol/spec/quality review clean).
Source remains an isolated component pending concrete integration and adoption.

2026-10-28 resume: previous turn made progress (commits and verified disk cleanup).
Temporary source copies were cleared while paused. Root restored all 1025 files
to the exact 580199bc digest: 982 current-worktree matches and 43 preserved
snapshots. The 93-file c223 override was restored from existing local Git objects
with exact tree and per-file hashes. Recovery records are in body-queue and
loop-callbacks evidence. No completed Task 1 implementation or tests were repeated.

Architect /root/architect_h2_session_delivery is preparing the concrete successor
handoff against this restored source. No new field or layout change is authorized
until Root rules on its explicit storage/interface growth proposal.

Architect completed the concrete Session-to-registered-sink handoff, preserved
as session_handoff_2026_10_28.md. Root has not adopted its arithmetic estimates
as measured sizes. Task2 is declaration-only three-target layout measurement;
Task3 will implement actual vertical delivery after Root approves the results.

| Task pair/self | Interface checked | Finding and ruling |
| --- | --- | --- |
| Task1/Task2 | Baseline and queue shape | Restore verified complete580199bc source and immutable93-file c223 override; no completed code/tests repeated. |
| Task2/next delivery | Field versus behavior ownership | Ruling: permit a disposable declaration-only prototype; final behavior source and assertion changes wait Root's measured-growth approval. |
| Task2/self | Real types versus unavailable shared target | Ruling: measure actual existing types; label pointee/callback/shared-target proxies and proposed cold arithmetic, never report them as final implementation facts. |
| Task2/global paths | Task1-only source/output names | Ruling: Task2's fresh /tmp source and layout evidence paths override old Task1 paths; all safety/storage/compiler constraints persist. |

- [x] Task2 actual baseline and declaration-only proposal layouts on three targets.

Task 2: complete (declaration-only evidence, independent spec/quality review clean).
All3 real measurements confirm Session/TCP+8, Callbacks+16, Storage+8, Capacities+8;
disabled1024-connection slab+8192. Cold-state shapes are measured proxies, while
enabled-region carving remains proposed. Raw compiler exit1 is solely compileLog,
never a test pass. Review is preserved in layout/review-layout.md.

Ruling: approve those additive warm fields for Task3; require actual final-type
and three-target accounting before changing exact layout expectations. Large
queue/state allocation must stay disabled by default. The H1 cold owner pointer
and native startup binding belong to the later startup/native slice, not unused
fields in Task3. Any actual additional stored field/descriptor growth requires
fresh accounting and Root ruling before adoption.

Ruling: BodyDataEvent.delivery_allowed distinguishes observe-only protocol holds
from real sink pause. Architect adversarial review approves. Continue gates end
as well as chunk; resume during blocked100 clears sink pause without opening
delivery. Fresh DATA with older queue data is observed-only then appended FIFO.
See the preserved handoff correction for exact semantics/tests.

Task3 implementation began in /tmp/uwz-m2-h2-session-delivery. Original agent
/root/implement_h2_session_delivery errored with model-capacity failure after
15 Debug encoded-frame/sink tests passed. Root confirmed terminal agent state,
interrupted it, and checked all runner records are terminal with no orphan logs.
Actual1029-file candidate remains955c27982ec2c9a1373f3d6a7a8cc826e58e5030d0d62788c33ef0939a3c94d2,
identical to the successful expanded-debug run's before/after identities.
Root preserved all9 changed source paths in session-delivery/capacity-checkpoint
and the complete source manifest in capacity-checkpoint.json before handoff.
No completed source/test sequence is to be restarted. A standard-model successor
will continue this exact partial implementation, remaining coverage and gates.

Independent client preparation: Root's helper is not native/live evidence. A pure
hyper-h2 pair and bounded100M generator passed corrected selfcheck; earlier expected
literal33vs32 mistakes are preserved and excluded as red proof. Reviewer found
P2 unbounded informational-header retention. Fix-loop references read before R1.
Ruling: fix with16-response/16384-byte aggregate budget (32-byte per-field overhead
plus UTF8 lengths) before live use. A separate verification worker owns only the
client artifact paths; product Task3 ownership remains untouched. This independent
assignment follows user's team rule and avoids controller self-fixing review.

Client preparation: fix round1/5 (1 addressed,0 open; no product source changes).
Frozen helper07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00,
budget regression64a56bbb091cb3a44fd003b0e6e9634722c5cb65e5f3867ca94e02008d3b0c8c.
Actual behavior-red proves prior unbounded count/bytes; final pure regression and
existing selfcheck0. Bad HeaderTuple deepcopy snapshot preserved, corrected via
canonicalJSON without weakening equality. Scratch AST2files/36nodes/100edges0;
source hashes unchanged. Scoped re-review originalP2 ADDRESSED, spec/quality clean.
Prepared source remains no socket/TLS/uWebZockets/native/live evidence.

Task3 v3 frozen7062cbc4/1029files/11paths;169 selected tests per Debug/RS, central3
targets/static/eligible32/AST passed within reported scope. Root approved explicit
alignment of existing Bundle arrays after actual2stream/nonaligned failures, with
natural-alignment dominance assertion and no capacity/newfield/threshold change.
All source/default/private8 budgets match. Historical socket EPERM batch stays
stopped, final safe filters explicit; full native/complete-driver32 gates remain.

Task3 reviews request changes: F1P1 peer-reset reclaimed credit unflushed;
F2P1 legacy reset/close-then-error deferred cleanup skipped; F3P2 current DATA refund
stranded after reset-and-error; F4P2 saved middleware omitted from limit413.
Root inspected cited actual source; findings agree with binding contracts.
Fix-loop references re-read before round1. Resume same successor implementer with
task-3-fix-1-brief.md; no native activation or source promotion until re-review.

Cleanup continuation made concrete progress: removed generated inactive-worktree/
compiler caches and deduplicated identical immutable archives, reclaiming
1202933760 bytes. All1066 tracked regular files were byte-identical; h1spec was
clean/exact and pending client archive identity verified. Root verified all53
safe client archive members/52 inventories and docs links, then committed and
immediately pushed preparation as a08d8d0 to the authorized fork.

Task3 fix1: all four genuine-v3 regressions failed for the reviewed causes;
Root inspected raw logs and production-identity proof. Root approved minimal
default-false stack-only BodyClosedEvent.final_body_too_large, with no stored
field/factory/native activation. Final checks/review remain pending. Existing
architect completed read-only native follow-up on an independent immutable v3
copy; native_handoff_2026_10_28.md names enabled-only storage/late binding,
whole-Session operation borrows, no-output closure and generation-preserving
drained reset. Implementation waits clean Task3 re-review.

Task3 fix round1 clean: final1029-file source1d53c6704d8f31c333052998a85a293834276f386b4239fdbf44556496a5342e;
relative-v3 patchefdd584ac992b1167d9f927047f8d5cb79355cb251741a7850a8228cb3416682.
All173 selected tests per Debug/RS pass, central3target/eligible32/static/AST
checks pass; compileLog-only layouts preserve stored sizes/offsets/carves/totals.
Same protocol reviewer marks F1/F2/F3 ADDRESSED with no new fix-diff finding;
same admission reviewer marks F4 ADDRESSED, spec/quality pass. No checks rerun
by reviewers. Root persists both scoped reviews in fix1 and prepares complete
Task3 recovery checkpoint; native activation/live/full M2 acceptance remain open.

Task3 committed and immediately pushed as d1527b1 (client preparation a08d8d0).
Public report m2_h2_session_delivery.md and archive SHA
73aa9ec4fef2734e04b3ace670949194910167084101b322bf77c31a92c9cdf3
preserve773 regular members/772 inventories, all changed source and reviews.
Root independently reconstructed all1029 files from580199bc. Initial contextual
patch publication failed whitespace checks on30 empty context markers; preserved
the rejection and original patch/proof, generated public zero-context patch
955196085dffdf6114dc32f67acf087380c52097580f7f52fb915d2ab38dbb1f,
and re-proved identical full reconstruction with git apply --unidiff-zero. No
source/test/lint policy changed. Final docs/working/staged whitespace checks and
all773 member/772 hashes passed before commit/push.

Task4a dispatched to the same developer via task-4a-brief.md after clean Task3
reviews and checkpoint. New /tmp/uwz-m2-h2-native-startup source, five owned paths,
enabled-only pool/driver/capture startup, planned cold pointer and stable late
binding. Native TCP/body callbacks/lifetime/active drained reuse remain gated
for next composition slice. Original experiment and two socket cases stay stopped.

Task4a continuation: /root/finish_h2_session_delivery terminated with model-capacity
error after baseline-copy preparation and scope questions. Root confirmed terminal
agent status and exact1029-file1d53 copy, zero source changes; saved complete
root-capacity-checkpoint.json before replacement. Ruling: initialized slot-only
drain checks/inert pointer-preserving reset are allowed now; opaque-to-Router
neutral admission adapter is allowed at stable late binding, preserving supplied
early_data_forbidden. Native policy derivation and callback activation stay gated.
Use an available standard-model replacement on the same source, no clone/Task3
restart. Root performs read-only next-slice preparation while one developer runs.

Replacement identity: /root/implement_h2_native_startup, standard
gpt-6.1-terra/high, BASE d1527b1df0fef5e57775ba3f3c846da3229c64d8.
It independently verified exact1029 files/no extras before edits and authored
the first real existing-API capacity-propagation red. Root reused the existing
architect read-only to refine the later no-output Session closure and driver
drained-reset contract. Implementation assignments remain serialized.

Task4a corrected red: initial compile overlapped source edits, so its interrupted
attempt is invalid evidence. Developer preserved it; a separate frozen baseline
with only the focused existing-API test compiles0 and fails at enabled H2 capacity
propagation (red-runtime.log inspected by Root). Preliminary candidatefbfd66eb
passes diagnostics; all are nonfinal. Developer self-review identified missing
all-region pairwise disjointness coverage and will strengthen it only after the
current frozen run terminates, then re-freeze/verify affected checks.

Native terminalization architect refinement saved as
native_terminal_handoff_2026_10_28.md. Root challenged blanket closed-state flush
guards: architect confirmed they would break pending response completion after
GOAWAY and withdrew them. Ruling: explicit bulk-close retires all IDs/abandons
intents and skips new unwind credit; preserve ordinary GOAWAY/flush semantics.
Whole-notification borrow, retire-before-notify reset, unconditional error cleanup
and generation-preserving slot reset are next serial prerequisite, not implemented
or native-activated yet. Require exact GOAWAY buffered-output regression.

Task4a final1029-file source d69d1fb4f318f660ec5163315b1e70824a4a112803ad980bdcda7572b6d2c13f
changes five assigned paths; final.patch7d8efe23880b9bbc1aab8091831ae45d67cc37d2a7c06293f221a8907a7d0fe1.
140 selected tests per Debug/RS pass; central3target/eligible32/static/AST pass.
Measurements preserve disabled totals; enabled increment overTask3 is75632 bytes
per connection before nonzero capture overflow. Cold owner adds8 on each target.
Offset diagnostic has distinct210dbcc1 source and exact visibility-only delta;
actual public-plan totals cross-check it. Root approved only that diagnostic
copy's visibility exposure; final production visibility stays unchanged.

Root found the original corrected-red compile lacked saved exact command/raw
record. Required one later uniquely bound genuine8876d88 compile/run (0/1) with
complete identities/logs; original gap and interrupted attempt stay explicit.
Candidate d69 did not change. Fresh /root/review_h2_native_startup independently
reviews spec/quality/security/compatibility and requested scoped strict structural
lens: no actionable findings. Root persists review-startup.md and audits source/
command/probe identities before publishing the startup checkpoint.
