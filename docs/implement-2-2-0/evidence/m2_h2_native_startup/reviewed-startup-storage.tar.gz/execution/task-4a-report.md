# Task 4a: startup storage and stable HTTP/2 owner binding

Status: frozen for independent Root review. Native body callbacks remain gated; this is not native H2 delivery or acceptance. No TCP, Session, driver, dependency, Root source, client or static library was changed.

## Source and scope

The existing `/tmp/uwz-m2-h2-native-startup` was checked against `session-delivery/fix1/final-source.json` before editing: 1,029 files, zero mismatches and zero extras. Baseline digest is `1d53c6704d8f31c333052998a85a293834276f386b4239fdbf44556496a5342e`. The five changed files are:

- `src/router/config.zig`: forwards the existing H2 streaming flag; adds checked, aligned, enabled-only driver and two capture matrix regions to slab planning/carving.
- `src/core/http1_upload_storage.zig`: adds the approved cold H2 pointer; drain checks inspect only initialized slot state. Reset leaves the pointer and H2 generations intact.
- `src/router/app.zig`: initializes drivers once at their stable slab addresses, attaches them to cold owners, and binds the Router target beside existing late H1 binding. The named adapter forwards the original neutral input, including `early_data_forbidden`.
- `src/tests/config_tests.zig`: exercises capacity propagation, enabled/disabled carving, every populated region pair's bounds/disjointness, alignment, real short/misaligned buffers, two connections/eight streams/four overflow captures and independent positive body strides.
- `src/tests/body_app_tests.zig`: extends the existing healthy startup fixture for stable owner/session/context/slot addresses, prebinding drain checks, inert reset/generation preservation and late Router association.

No active reset, TCP callback adapter or early-data derivation was added. Driver binding is startup-only and native callbacks stay gated. The future composition slice must handle whole-Session borrows, callback activation, active generation-preserving reset and no-output closure.

Frozen final source: 1,029 files, digest `d69d1fb4f318f660ec5163315b1e70824a4a112803ad980bdcda7572b6d2c13f`; complete inventory and file hashes are in `.uwz-work/evidence/h2-streaming/native-startup/final-source.json`. Source-only archive `/tmp/uwz-m2-h2-native-startup-artifacts/final-source.tar.gz` SHA-256 `4cd7e0b30461a5cf9e504beb9c2c4eac046fb29370772bf216fb4a514689ff95`. Git-format patch `.uwz-work/evidence/h2-streaming/native-startup/final.patch` SHA-256 `7d8efe23880b9bbc1aab8091831ae45d67cc37d2a7c06293f221a8907a7d0fe1`; `git apply --check` and `git apply` against an independent baseline copy succeeded, and its resulting 1,029-file digest matched the frozen source. Preimages and final five-file snapshots are in `native-startup/preimages` and `native-startup/final`.

## Red and final checks

The first attempted focused compile was interrupted after the candidate source changed concurrently. Its result is invalid evidence: neither a red nor green result is claimed. A corrected fresh regular-byte baseline copy had exactly one delta, the existing-API capacity propagation test (`config_tests.zig` SHA-256 `486679be15530792036afb1d096cd27fee91d66d7b981b6159b0b0d97ce26dd1`; full red source digest `8876d88d2675acfc633c15c8eb45b1d4b05ef2d4d48804ce8e518c644d3df877`). Zig Debug compile exited 0; runtime exited 1 on the enabled `h2_capacities().stream_request_bodies` assertion. The binary SHA-256 is `7ef2e8a5be723ee587190fef14e6938013bb4ba59a40d399f070475bab40b8df`; a repeat raw runtime is `native-startup/red-runtime.log`. The initial compile command used the recorded Task3 Debug module/link argv, `-j2`, and affinity CPUs 0 and 1, changing only the test root, cache/binary paths and filter. Its tool output was not saved as a separate compile log; the compiler exit and failing output are recorded here, and the repeat runtime log is retained.

An earlier frozen candidate `fbfd66ebb14d3d3651bfce674db713109b922147693a4cde017fc4a4bdd16c83` passed the selected suites, but its carve test did not cover every populated region pair. Coverage was expanded and the final digest above was frozen before the final checks. Each final compile/run record under `native-startup/final-*.json` records exact argv, environment, before/after source and input hashes, the 93-file c223 override hashes and binary hash. The records and raw logs are indexed by `native-startup/review-package.json`. They use Zig 0.16.0 compiler SHA-256 `2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c`, the inherited r2 modules/static libraries and c223 override, `-j2`, and affinity CPUs 0 and 1. All recorded final source/input/override before/after identities agree.

Final filtered runtime results, each in Debug and ReleaseSafe, compile exit 0 and run exit 0:

| Suite | Tests per mode |
| --- | ---: |
| focused config H2 | 3 |
| approved healthy App filters | 8 |
| `http2 server:` | 40 |
| HTTP/1 head | 12 |
| HTTP/1 admission | 7 |
| HTTP/1 upload driver | 30 |
| H2 refusal | 15 |
| concrete H2 upload driver | 25 |

The complete central test graph compiled semantically for native Linux, aarch64 macOS and x86_64 Windows GNU (Debug, compile-only, exit 0). Eligible x86 32-bit ReleaseSafe queue, selected width and driver `Bundle and carve` checks compiled with exit 0. The existing complete-driver 32-bit blockers in `http/abort.zig` atomic-u64 and `ws/mask.zig` u64-to-usize remain; these selected checks do not establish complete 32-bit support. `zig fmt --check src builds examples tests fuzz`, then `zig fmt src builds examples tests fuzz`, conventions, release version and documentation-link scripts exited 0. The requested full `zig build test` runtime was not run because the assigned brief expressly prohibits the full isolated native runtime and the stopped/socket/resource/timer/cancellation cases; no gate was weakened. No socket, native fault/cancellation experiment, client or live server was run.

The independent AST refresh copied the exact frozen source, verified its manifest before and after, and ran graphify update with exit 0. It fell back from parallel to sequential extraction after OS permission refusal; the graph was updated in the scratch copy only. Its record is `final-ast-refresh.json` and source digest remains d69d1fb4. A preliminary shell search from `/tmp` reported `rg: command not found`; the subsequent root-based absolute-path search succeeded. A first accounting-summary parser failed with `AttributeError` because it matched the compileLog source line; the corrected parser compared all results successfully.

## Three-target accounting

Final frozen-candidate compileLog probes intentionally exit 1 due to `@compileLog`; they are measurements, not passing tests. Full type/descriptor and planning outputs are `final-layout-{linux,macos,windows}.log`. The separately identified diagnostic offset scratch started byte-identical to d69d1fb4 and differs only by `fn layout_offsets` to `pub fn layout_offsets`. Its full digest is `210dbcc153bc80fe3d9b0317690c884f5454dac5de41f55e60218d9967aa14e3`; unchanged original function body SHA-256 `dc799122959c54e041d534ecdf4eedfb5ff35766ba04ca506f08c576d675ef95`. The exact sole delta is verified in `accounting-identity.json`; its `final-offsets-*` compileLog exit 1 records identify the scratch, not the frozen candidate. Every offset total matches the corresponding public frozen-candidate plan total for all four measured configurations on all three targets.

| Target | cold H1 owner bytes (prior -> final) | default disabled slab | default enabled slab | 8-connection small enabled slab | 2-connection, 20-param enabled slab |
| --- | ---: | ---: | ---: | ---: | ---: |
| Linux | 2,880 -> 2,888 | 684,185,216 | 764,591,744 | 5,431,552 | 2,378,336 |
| macOS | 2,848 -> 2,856 | 684,103,296 | 764,477,056 | 5,430,656 | 2,378,080 |
| Windows | 3,040 -> 3,048 | 684,684,928 | 765,255,296 | 5,436,736 | 2,379,616 |

Driver size is 1,288 bytes, alignment 8; `SlabLayout` is 424 bytes, alignment 8 on all three. Session storage is 517,648 disabled and 591,984 enabled: a 74,336-byte increment per connection. Relative to the Task3 enabled plan the added per-connection growth is 74,336 Session + 1,288 driver + 8 cold-owner bytes = 75,632 bytes for the zero-overflow profiles; the 1,024-connection total grows by 77,447,168 and the 8-connection total by 605,056. At 20 route parameters each capture matrix adds `connections * 8 * 4 * 16` bytes, and two matrices add 2,048 bytes for two connections. Actual offset and alignment outputs are recorded, including zero-length matrix regions. The disabled default totals equal Task3 and preserve its documented 8,192-byte warm increase relative to the composed pre-Session baseline. No exact expectation or threshold was changed.

## Remaining acceptance

Root review and any review-driven corrections remain. Native adapter/composition, real H2/TLS client proof, genuine 0-RTT policy derivation, active retirement/reset and full compliance/platform acceptance are outside this slice and remain open. No claim is made about unrun fault, scheduling, cancellation, kernel, resource, client, or full-runtime tests.

## Later fully recorded red verification

After the final candidate checks, the same frozen 8876d88 baseline regression was compiled and run again under a new bound wrapper. This is a later verification; it does not replace or backfill the first red compile's missing raw record, and the interrupted changed-source attempt remains invalid. The compile exited 0 and the run exited 1 at the existing `enabled.h2_capacities().stream_request_bodies` assertion. The compiled binary SHA-256 is `ef566a7ff1bd5c5f151c6cc726b7c5deba27cd3d529b7b274ecdd22e317bcb89`; the run record verifies that exact binary hash. The compile's empty raw log SHA-256 is `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`, and the failing runtime raw log SHA-256 is `4900357cb3ac959ecc2d103518fa2ab8190b08976d73324732fc83b255f9d89c`.

`native-startup/red-recorded-propagation-Debug.json` and `red-recorded-propagation-Debug-run.json` bind exact argv, cwd, environment, compiler, modules, static libraries, the 93-file override, before/after source and inputs, terminal statuses and binary identity; adjacent `.log` files retain the raw output. Both source before/after digests are `8876d88d2675acfc633c15c8eb45b1d4b05ef2d4d48804ce8e518c644d3df877`. These records are indexed under `later_red_verification` in `review-package.json`. A fresh full inventory of the candidate after this verification still hashes to d69d1fb4; no candidate source or final check was rerun or changed.
