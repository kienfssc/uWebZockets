import hashlib, json, os, subprocess, sys
from pathlib import Path

here = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata')
out = here / 'recovery-2026-10-29'
manifest_path = here / 'review-manifest-v2.json'
manifest = json.loads(manifest_path.read_text())
binaries = {'/tmp/uwz-task5b4-final-debug/profile', '/tmp/uwz-task5b4-final-release/profile'}
def digest(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        while b := f.read(1048576): h.update(b)
    return h.hexdigest()
def inventory(root):
    root = Path(root)
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file()}
def check():
    assert digest(manifest_path) == '5a47148bd2c9857a0cbe9b5b5ea8760c4eeadefbdf3651cb583d154373e73b07'
    for path, expected in manifest['inputs'].items():
        if path not in binaries: assert digest(path) == expected, path
    for path, expected in manifest['trees'].items(): assert inventory(path) == expected, path
    receipts = [json.loads((here / ('fixture-' + mode + '-final.json')).read_text()) for mode in ('debug', 'release')]
    reviewed = json.loads((here.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
    for r in receipts:
        assert len(r['input_sha256']) == 13 and r['input_sha256'] == r['input_after']
        for path, expected in r['input_sha256'].items():
            assert digest(path) == expected, path
            if path.endswith('.a'): assert reviewed[path] == expected, path
        assert sum(p.endswith('.a') for p in r['input_sha256']) == 6
        assert inventory('/tmp/uwz-reviewed-libxev-c223-loop-callbacks') == r['override_before'] == r['override_after']
        source = inventory(r['cwd'])
        assert hashlib.sha256(json.dumps(list(source.items())).encode()).hexdigest() == r['source_tree_sha256'] == r['source_after_sha256'] == r['expected_source_digest']
        assert source == json.loads((here / ('fixture-' + ('debug' if r['optimization'] == 'Debug' else 'release') + '-final-source-inputs.json')).read_text())
        for name, expected in r['fixture_before'].items(): assert digest(here / name) == expected == r['fixture_after'][name]
    return receipts
receipts = check()
print('preflight: manifest inputs excluding two absent binaries, 6 trees, both 13-input maps, six reviewed archives, source and override: OK', flush=True)
for r in receipts:
    mode = 'debug' if r['optimization'] == 'Debug' else 'release'
    if len(sys.argv) > 1 and mode != sys.argv[1]: continue
    argv = r['argv']; target = Path(next(x.split('=', 1)[1] for x in argv if x.startswith('-femit-bin=')))
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    for flag in ('--cache-dir', '--global-cache-dir'): Path(argv[argv.index(flag)+1]).mkdir(parents=True, exist_ok=True)
    before = {p: digest(p) for p in r['input_sha256']}
    proc = subprocess.run(argv, cwd=r['cwd'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out / (mode + '.log')).write_bytes(proc.stdout)
    after = {p: digest(p) for p in r['input_sha256']}
    check()
    actual = digest(target) if target.exists() else None
    record = {'argv': argv, 'cwd': r['cwd'], 'optimization': r['optimization'], 'environment': 'inherited; original receipt explicit_environment={}', 'before': before, 'after': after, 'source_tree_before_after': r['source_tree_sha256'], 'override_before_after': r['override_before'], 'exit_status': proc.returncode, 'raw_output_file': mode + '.log', 'binary_sha256': actual, 'expected_binary_sha256': r['binary_sha256']}
    (out / (mode + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(mode, 'exit', proc.returncode, 'sha256', actual, 'expected', r['binary_sha256'], 'output bytes', len(proc.stdout), flush=True)
    if proc.returncode or actual != r['binary_sha256'] or before != after: break
