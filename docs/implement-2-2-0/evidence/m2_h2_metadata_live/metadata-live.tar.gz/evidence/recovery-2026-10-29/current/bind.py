"""Bind and verify current compile-only artifacts without executing them."""
import copy
import hashlib
import importlib.util
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
RECOVERY = HERE.parent
META = RECOVERY.parent
ORIGINAL = META / 'review-manifest-v2.json'
MANIFEST = HERE / 'manifest.json'
FROZEN = Path('/tmp/uwz-task5b4-frozen-v2')
EXPECTED_ORIGINAL = '5a47148bd2c9857a0cbe9b5b5ea8760c4eeadefbdf3651cb583d154373e73b07'
EXPECTED = {'debug': '7ec029babf71b0335cf2b5f0fc83774d21a3692ec1de0580413063ae617ca388', 'release': '30d443388a5a178be447150c3701ad912eed3c9dc27014122b91390cb2381b5a'}

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while data := f.read(1048576): h.update(data)
    return h.hexdigest()

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

def validate_builds():
    closure = module('build_closure', FROZEN / 'build_closure.py')
    old = [json.loads((META / ('fixture-' + mode + '-final.json')).read_text()) for mode in ('debug', 'release')]
    fresh = [json.loads((RECOVERY / (mode + '.json')).read_text()) for mode in ('debug', 'release')]
    receipts, commands = [], []
    current = {}
    for mode, historical, actual in zip(('debug', 'release'), old, fresh):
        assert actual['argv'] == historical['argv'] and actual['cwd'] == historical['cwd']
        assert actual['optimization'] == historical['optimization'] and actual['exit_status'] == 0
        assert actual['before'] == historical['input_sha256'] and actual['after'] == historical['input_after']
        assert actual['source_tree_before_after'] == historical['source_tree_sha256'] == historical['source_after_sha256']
        assert actual['override_before_after'] == historical['override_before'] == historical['override_after']
        assert actual['binary_sha256'] == EXPECTED[mode] and actual['expected_binary_sha256'] == historical['binary_sha256']
        assert (RECOVERY / actual['raw_output_file']).read_bytes() == b''
        original_binary = Path('/tmp/uwz-task5b4-final-' + mode + '/profile')
        destination = Path('/tmp/uwz-task5b4-current-' + mode + '/profile')
        assert digest(original_binary) == digest(destination) == actual['binary_sha256']
        assert destination.stat().st_mode & 0o111 and destination.stat().st_mode & 0o777 == original_binary.stat().st_mode & 0o777
        # Explicit canonical mapping from the recovery receipt schema.
        mapped = {'argv': actual['argv'], 'optimization': actual['optimization'], 'exit_status': actual['exit_status'], 'inputs_unchanged': actual['before'] == actual['after'], 'input_sha256': actual['before'], 'input_after': actual['after']}
        receipts.append(mapped)
        commands.append({'argv': actual['argv'], 'input_sha256': actual['before']})
        current.update({p: digest(p) for p in actual['before']})
    reviewed = json.loads((META.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
    archives = {p: reviewed[p] for p in closure.ARCHIVES}
    merged = closure.validate_receipts(receipts, commands, current, archives)
    broken = copy.deepcopy(receipts)
    broken[0]['input_after'][next(iter(broken[0]['input_after']))] = '0' * 64
    try:
        closure.validate_receipts(broken, commands, current, archives)
    except ValueError:
        pass
    else:
        raise AssertionError('validator accepted mutated after map')
    return merged

def main():
    assert digest(ORIGINAL) == EXPECTED_ORIGINAL
    base = json.loads(ORIGINAL.read_text())
    if sys.argv[1] == 'create':
        assert not MANIFEST.exists()
        for mode in ('debug', 'release'):
            src = Path('/tmp/uwz-task5b4-final-' + mode + '/profile')
            dest = Path('/tmp/uwz-task5b4-current-' + mode + '/profile')
            assert digest(src) == EXPECTED[mode]
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                assert digest(dest) == EXPECTED[mode] and dest.stat().st_mode & 0o777 == src.stat().st_mode & 0o777
            else:
                shutil.copy2(src, dest)
        merged = validate_builds()
        for mode in ('debug', 'release'):
            del base['inputs']['/tmp/uwz-task5b4-final-' + mode + '/profile']
            path = '/tmp/uwz-task5b4-current-' + mode + '/profile'
            base['inputs'][path] = EXPECTED[mode]
        base['inputs'].update(merged)
        for path in [ORIGINAL, RECOVERY / 'restored-source.json', RECOVERY / 'replay.py', RECOVERY / 'environment.json', RECOVERY / 'debug.json', RECOVERY / 'release.json', RECOVERY / 'debug.log', RECOVERY / 'release.log', Path(__file__).resolve()]:
            base['inputs'][str(path)] = digest(path)
        base['binary'] = '/tmp/uwz-task5b4-current-release/profile'
        base['build_input_receipts'] = [str(RECOVERY / 'debug.json'), str(RECOVERY / 'release.json')]
        base['scope'] = 'fresh current builds and runtime closure; historical binary reproduction unproved'
        base['historical_binary_mismatch'] = {mode: {'recorded': old, 'current': EXPECTED[mode]} for mode, old in [('debug', '5f480df3ebe4914a4e111e1afeb4c9a8d1285cab1cd77ac11cb67a756552f9b9'), ('release', 'b65535456c7ea43a30d1370b54f4747a672a5f8db4a69c348cec99cf17cc81c2')]}
        MANIFEST.write_text(json.dumps(base, sort_keys=True, indent=2) + '\n')
        print('created manifest sha256:', digest(MANIFEST))
    elif sys.argv[1] == 'check':
        merged = validate_builds()
        current_manifest = json.loads(MANIFEST.read_text())
        assert all(current_manifest['inputs'][k] == v for k, v in merged.items())
        assert not any('/tmp/uwz-task5b4-final-' in p for p in current_manifest['inputs'])
        runner = module('inert_runner', FROZEN / 'run_live.py')
        checked = runner.check_manifest(MANIFEST, digest(MANIFEST))
        assert checked['binary'] == '/tmp/uwz-task5b4-current-release/profile'
        assert len(checked['inputs']) == len(base['inputs']) + 9
        print('validated both actual receipts: 13 direct inputs, 6 reviewed archives; mutated after-map rejected')
        print('inert runner manifest check:', len(checked['inputs']), 'inputs,', len(checked['trees']), 'trees')
        print('manifest sha256:', digest(MANIFEST))
        print('current debug sha256:', digest('/tmp/uwz-task5b4-current-debug/profile'))
        print('current release sha256:', digest('/tmp/uwz-task5b4-current-release/profile'))
    else:
        raise ValueError('expected create or check')

if __name__ == '__main__': main()
