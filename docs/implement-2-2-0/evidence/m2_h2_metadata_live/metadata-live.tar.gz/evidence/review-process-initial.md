SPEC PASS for Stage A source preparation. QUALITY REQUEST CHANGES.

P2 — Remove inactive credit-case scaffolding. Frozen run_live.py402 retains
credit helpers/API entries neither selectable case calls;330 hashes65536unrelated
payloadbytes, then passes digest to unused cases.expected parameter atcases.py11.
Impossible concurrent_refused branch and profile.zig74 partial_done are further
leftovers. Mandatory no-dead-code contract violated; remove in fresh revision
while preserving active flow accounting and immutable evidence.

No additional correctness/security/ownership/compatibility/currentbinding
finding. Independent metadata and helper checks, pre-send headerbound, current
artifact-vs-historical mismatch qualification and cleanupfailure rejection are
strengths. No tests/builds/validators/native rerun; callbacks/deinit/cleanup
remain unproved; fullgates/adoption open.

Root transcription of final /root/review_h2_metadata_process initial review.
