"""Validate current direct build inputs using caller-provided receipt maps."""
ARCHIVES = tuple('/workspaces/uWebZockets/zig-out/lib/' + name for name in (
    'libuWebZockets.a', 'libssl.a', 'libcrypto.a', 'liblsquic.a', 'libdeflate.a', 'libz.a'))


def argv_inputs(argv):
    if not argv or not argv[0].startswith('/'):
        raise ValueError('missing compiler')
    modules = [arg.split('=', 1)[1] for arg in argv if arg.startswith('-M') and '=' in arg]
    archives = [arg for arg in argv if arg.endswith('.a')]
    if len(archives) != len(ARCHIVES) or set(archives) != set(ARCHIVES):
        raise ValueError('archive list differs')
    if len(modules) != 6 or len(set(modules)) != len(modules):
        raise ValueError('module input list differs')
    return set(modules + archives + [argv[0]])


def validate_receipts(receipts, commands, current, approved_archives):
    merged = {}
    if len(receipts) != 2 or len(commands) != 2:
        raise ValueError('both build receipts are required')
    for receipt, command, mode in zip(receipts, commands, ('Debug', 'ReleaseSafe')):
        before = receipt['input_sha256']
        if receipt['optimization'] != mode or receipt['exit_status'] != 0 or not receipt['inputs_unchanged']:
            raise ValueError('build receipt status differs')
        if receipt['argv'] != command['argv'] or before != command['input_sha256']:
            raise ValueError('build command receipt differs')
        if set(before) != argv_inputs(receipt['argv']) or before != receipt['input_after']:
            raise ValueError('build input map is incomplete or changed')
        for path, value in before.items():
            if current.get(path) != value or (path in merged and merged[path] != value):
                raise ValueError('current or cross-build input differs: ' + path)
            merged[path] = value
    if set(approved_archives) != set(ARCHIVES):
        raise ValueError('reviewed archive map is incomplete')
    for path in ARCHIVES:
        if merged[path] != approved_archives[path]:
            raise ValueError('archive differs from reviewed identity: ' + path)
    return merged
