"""Audit recorded results and the owned host PID without running a client."""
import hashlib
import json
from pathlib import Path
import ssl


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    evidence = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata')
    run = Path('/tmp/uwz-h2-metadata-owned-2026-10-29-r1')
    result = json.loads((run / 'result.json').read_text())
    auth = json.loads((evidence / 'fix1/stage-b-authorization.json').read_text())
    assert result['success'] and result['error'] is None
    assert result['manifest_sha256'] == auth['argv'][auth['argv'].index('--manifest-sha256') + 1]
    assert result['child']['binary_sha256'] == auth['binary_sha256']
    assert list(result['cases']) == ['metadata_helpers', 'shutdown_idle']
    assert result['cleanup'] == {'signal': 'SIGTERM', 'exit_code': 0, 'reaped': True, 'forced': False, 'errors': []}
    assert not (run / 'private-key.pem').exists()
    assert not Path('/proc', str(result['child']['pid'])).exists(), 'owned host PID still present'
    records = result['final_status']
    assert len(records) == 32 and len([tag for tag in records if tag.startswith('spare_')]) == 31
    empty_sha = hashlib.sha256(b'').hexdigest()
    for tag, record in records.items():
        touched = tag == 'metadata_helpers'
        count = int(touched)
        assert record['tag'] == tag
        for name in ('middleware', 'attempts', 'begin', 'end', 'metadata_middleware', 'helpers_begin',
                     'helpers_end', 'metadata_begin', 'metadata_end'):
            assert record[name] == count, (tag, name)
        assert record['cancel'] == record['failure'] == record['errors'] == 0
        assert not record['active'] and not record['paused'] and record['reason'] == 'none'
        assert record['accepted'] == (32 if touched else 0)
        expected_sha = '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5' if touched else empty_sha
        assert record['sha256'] == expected_sha
        if touched:
            assert record['chunks'] > 0 and 0 < record['max_span'] <= 8192
        else:
            assert record['chunks'] == record['max_span'] == 0
    expected_metrics = {'middleware': 1, 'attempts': 1, 'begin': 1, 'end': 1, 'cancel': 0,
                        'failure': 0, 'accepted': 32, 'active': 0, 'errors': 0,
                        'buffered_middleware': 39, 'slot0_active': False, 'slot1_active': False}
    assert result['final_metrics'] == expected_metrics
    response = result['cases']['metadata_helpers'][0]['response']
    assert response['headers'].count([':status', '200']) == 1
    assert response['headers'].count(['x-middleware', 'retained']) == 1
    assert not response['informationals'] and not response['raw_reset'] and not response['reset_event']
    assert json.loads(response['body']) == records['metadata_helpers']
    assert result['cases']['shutdown_idle'] == {'exit_code': 0, 'post_deinit': True}
    assert len(result['connections']) == 2
    for connection in result['connections']:
        assert connection['tls'] == 'TLSv1.3' and connection['alpn'] == 'h2'
    metadata = result['connections'][0]
    assert metadata['case'] == 'metadata_helpers' and metadata['sent_flow'] == 32
    assert 0 < metadata['encoded_header_bytes'] <= 8192
    assert not metadata['events'].get('StreamReset', 0)
    assert not metadata['events'].get('InformationalResponseReceived', 0)
    text = (run / 'server.log').read_text()
    nonce = result['nonce']
    post = {}
    metrics = []
    for line in text.splitlines():
        marker = 'H2_RECORD ' + nonce + ' '
        if marker in line:
            record = json.loads(line.split(marker, 1)[1])
            assert record['tag'] not in post
            post[record['tag']] = record
        marker = 'H2_DEINIT ' + nonce + ' '
        if marker in line:
            metrics.append(json.loads(line.split(marker, 1)[1]))
    assert post == records and metrics == [expected_metrics]
    assert text.count('H2_READY ' + nonce) == 1 and (run / 'server.log').stat().st_size <= 65536
    fingerprint = hashlib.sha256(ssl.PEM_cert_to_DER_cert((run / 'certificate.pem').read_text())).hexdigest()
    assert fingerprint == result['certificate_sha256']
    preflight_sha = digest(evidence / 'fix1/root-preflight.json')
    assert preflight_sha == auth['preflight_sha256']
    audit = {'checks_passed': True, 'source_digest': auth['source_digest'],
             'profile_sha256': auth['profile_sha256'], 'binary_sha256': auth['binary_sha256'],
             'cases_passed': list(result['cases']), 'totals': expected_metrics,
             'metadata_middleware': 1, 'metadata_begin': 1, 'metadata_end': 1,
             'helper_suite_begin': 1, 'helper_suite_end': 1,
             'initial_visible_headers_asserted': 66, 'captures_asserted': 17,
             'encoded_header_bytes_observed': metadata['encoded_header_bytes'],
             'encoded_header_bytes_limit': 8192, 'post_deinit_records_match': 32,
             'post_deinit_metrics_match': True, 'child_exit_zero_reaped': True,
             'host_pid_absent': True, 'key_absent': True, 'certificate_fingerprint_match': True,
             'server_log_bytes': (run / 'server.log').stat().st_size,
             'result_sha256': digest(run / 'result.json'), 'preflight_sha256': preflight_sha,
             'postrun_preflight_identical': True, 'runs': 1, 'retries': 0,
             'historical_binary_reproduction': 'unproved; executed fixed current artifact only',
             'scope': 'Recorded public callback/helper/wire assertions only; no full matrix, safety, performance or adoption claim.'}
    output = evidence / 'stage-b/root-result-audit.json'
    output.write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps({'checks_passed': True, 'audit_sha256': digest(output),
                      'accepted': 32, 'encoded_header_bytes_observed': metadata['encoded_header_bytes'],
                      'records_equal_through_deinit': 32}))


if __name__ == '__main__':
    main()
