"""Pure codec and caller-data checks, no transport or fixture execution."""
import hashlib
import h2.config
import h2.connection
import run_live
import cases

path = '/meta/metadata_helpers/' + '/'.join('a%02d' % i for i in range(1, 17))
target = path + '?q=alpha&n=17'
ordinary = [('content-length', '32'), ('x-mode', 'begin_paused')] + [('x-h%02d' % i, 'v%02d' % i) for i in range(63)]
headers = [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', target)] + ordinary
assert len(path) == 86 and len(target) == 99 and len(ordinary) == 65 and len(headers) == 69
assert sum(len(n) + len(v) for n, v in headers) == 684
assert sum(len(n) + len(v) + 32 for n, v in headers) == 2892
protocol = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True))
protocol.initiate_connection()
protocol.data_to_send()
protocol.send_headers(1, headers, end_stream=False)
pending = protocol.data_to_send()
size = run_live.encoded_headers_size(pending, 1)
assert 0 < size <= 8192
assert len(cases.TAGS) == 32 and len(set(cases.TAGS)) == 32
print('fields=69 decoded_bytes=684 list_cost=2892 path=86 target=99')
print('actual fresh pinned codec encoded header bytes=%d' % size)
print('case tags=32 unique=32')
