"""Read-only identity audit for the exact reviewed metadata subject."""
import hashlib
import json
from pathlib import Path


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as source:
        while block := source.read(65536):
            value.update(block)
    return value.hexdigest()


def covered(manifest, name, expected):
    if manifest['inputs'].get(name) == expected:
        return True
    path = Path(name)
    for root, files in manifest['trees'].items():
        if path.is_relative_to(root):
            return files.get(path.relative_to(root).as_posix()) == expected
    return False


def main():
    base = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1')
    path = base / 'manifest.json'
    manifest_sha = digest(path)
    assert manifest_sha == '1cc2e55ec90df730ddb8b0765225dc4e8c8191c76452a899564a1bbd96ff6fd7'
    manifest = json.loads(path.read_text())
    for name, expected in manifest['inputs'].items():
        assert digest(Path(name)) == expected, name
    trees = []
    for root, expected in manifest['trees'].items():
        actual = {p.relative_to(root).as_posix(): digest(p)
                  for p in sorted(Path(root).rglob('*')) if p.is_file()}
        assert actual == expected, root
        assert len(actual) == manifest['tree_counts'][root]
        trees.append({'path': root, 'files': len(actual)})
    frozen = Path(manifest['runner']).parent
    profile_sha = digest(frozen / 'profile.zig')
    assert profile_sha == '5d96ef21b7a2b758cd285b648699df5b1bbbbe9c33d1fa7c274e4d30e6d004fd'
    builds = []
    archives = set()
    for name, mode in (('debug', 'Debug'), ('release', 'ReleaseSafe')):
        receipt = json.loads((base / (name + '.json')).read_text())
        assert receipt['optimization'] == mode and receipt['exit_status'] == 0
        assert receipt['inputs_unchanged'] and receipt['input_sha256'] == receipt['input_after']
        assert receipt['trees_before'] == receipt['trees_after']
        assert receipt['fixed_before'] == receipt['fixed_after'] == manifest['trees'][str(frozen)]
        for source, expected in receipt['input_sha256'].items():
            assert digest(Path(source)) == expected and covered(manifest, source, expected), source
            if source.endswith('.a'):
                archives.add(source)
        binary = Path(next(arg.split('=', 1)[1] for arg in receipt['argv'] if arg.startswith('-femit-bin=')))
        source = Path(next(arg.split('=', 1)[1] for arg in receipt['argv'] if arg.startswith('-Mroot=')))
        assert digest(source) == profile_sha
        assert digest(binary) == receipt['binary_sha256']
        assert covered(manifest, str(binary), receipt['binary_sha256'])
        assert binary.stat().st_mode & 0o111 and (base / (name + '.log')).stat().st_size == 0
        builds.append({'mode': mode, 'binary': str(binary), 'sha256': receipt['binary_sha256'],
                       'direct_inputs': len(receipt['input_sha256'])})
    assert len(archives) == 6
    source = '/tmp/uwz-task4d-fix1-frozen'
    source_sha = hashlib.sha256(json.dumps(list(manifest['trees'][source].items())).encode()).hexdigest()
    assert source_sha == 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de'
    assert digest(path) == manifest_sha
    result = {'checks_passed': True, 'manifest_sha256': manifest_sha,
              'inputs_checked': len(manifest['inputs']), 'trees_checked': trees,
              'builds': builds, 'archives_checked': len(archives),
              'profile_sha256': profile_sha, 'source_digest': source_sha,
              'source_files': 1031, 'native_execution': False,
              'historical_binary_reproduction': 'unproved; current fix builds are separate actual artifacts'}
    output = base / 'root-preflight.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'checks_passed': True, 'inputs': result['inputs_checked'], 'trees': len(trees),
                      'archives': len(archives), 'audit_sha256': digest(output)}))


if __name__ == '__main__':
    main()
