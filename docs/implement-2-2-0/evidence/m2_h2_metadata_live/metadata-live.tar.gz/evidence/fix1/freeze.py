"""Freeze the actual current test-only inputs; never starts native code."""
import hashlib
import json
from pathlib import Path
import shutil
import build_closure

HERE = Path(__file__).resolve().parent
HIST = HERE.parent / 'credit/fix1/review-manifest-v2.json'
ADMISSION = HERE.parent / 'admission/fix1/review-manifest.json'
FROZEN = Path('/tmp/uwz-task5b4-frozen-v2')
OLD_FROZEN = '/tmp/uwz-task5b3-fix1-frozen-v2'
NAMES = ('profile.zig', 'prepare.py', 'run_live.py', 'cases.py', 'wire.py', 'raw_observer.py', 'flow_ledger.py', 'pure_codec_checks.py', 'build_closure.py', 'freeze.py')


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        while data := f.read(8192):
            h.update(data)
    return h.hexdigest()


def inventory(root):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file()}


def main():
    base = json.loads(HIST.read_text())
    expected_hist = '952c497fb60c4af72f1d8024e142c20ad82c65a3d9ca2de91dc47cb628d00d94'
    if digest(HIST) != expected_hist:
        raise ValueError('historical reviewed manifest changed')
    if digest(ADMISSION) != base['historical_manifest_sha256'][str(ADMISSION)]:
        raise ValueError('reviewed admission manifest changed')
    receipts, commands = [], []
    for mode in ('debug', 'release'):
        label = 'fixture-' + mode + '-final'
        receipts.append(json.loads((HERE / (label + '.json')).read_text()))
        commands.append(json.loads((HERE / (label + '.command.json')).read_text()))
    paths = set().union(*(build_closure.argv_inputs(r['argv']) for r in receipts))
    current = {path: digest(path) for path in paths}
    reviewed = json.loads(ADMISSION.read_text())['inputs']
    merged = build_closure.validate_receipts(receipts, commands, current, {p: reviewed[p] for p in build_closure.ARCHIVES})
    for mode, receipt in zip(('debug', 'release'), receipts):
        if digest('/tmp/uwz-task5b4-final-' + mode + '/profile') != receipt['binary_sha256']:
            raise ValueError('binary differs: ' + mode)
        for name, value in receipt['fixture_before'].items():
            if digest(HERE / name) != value or receipt['fixture_after'][name] != value:
                raise ValueError('fixture or recipe changed: ' + name)
    trees = {path: values for path, values in base['trees'].items() if path != OLD_FROZEN}
    for path, values in trees.items():
        if inventory(Path(path)) != values:
            raise ValueError('reviewed tree changed: ' + path)
    inputs = {p: h for p, h in base['inputs'].items() if not (p.startswith(OLD_FROZEN + '/') or p.startswith('/tmp/uwz-task5b3-') or '/integration-owned/credit/' in p)}
    for path, value in inputs.items():
        if digest(path) != value:
            raise ValueError('current inherited dependency changed: ' + path)
    if FROZEN.exists():
        raise ValueError('destination already exists')
    FROZEN.mkdir(mode=0o700)
    for name in NAMES:
        shutil.copyfile(HERE / name, FROZEN / name)
    trees[str(FROZEN)] = inventory(FROZEN)
    inputs.update(merged)
    for mode in ('debug', 'release'):
        label = 'fixture-' + mode + '-final'
        for suffix in ('.json', '.command.json', '.log', '-source-inputs.json', '-source-after.json'):
            path = str(HERE / (label + suffix))
            inputs[path] = digest(path)
        binary = '/tmp/uwz-task5b4-final-' + mode + '/profile'
        inputs[binary] = digest(binary)
    for name, value in trees[str(FROZEN)].items():
        inputs[str(FROZEN / name)] = value
    manifest = dict(base)
    manifest.update(state='ready-for-independent-review', trees=trees, tree_counts={k: len(v) for k, v in trees.items()}, inputs=inputs,
                    binary='/tmp/uwz-task5b4-final-release/profile', runner=str(FROZEN/'run_live.py'), cases=str(FROZEN/'cases.py'), wire=str(FROZEN/'wire.py'), raw=str(FROZEN/'raw_observer.py'), flow=str(FROZEN/'flow_ledger.py'),
                    historical_manifest_sha256={str(HIST): digest(HIST), str(ADMISSION): digest(ADMISSION)}, build_input_receipts=['fixture-debug-final.json', 'fixture-release-final.json'], scope='current actual build and runtime closure; prior proofs linked by identity')
    output = HERE / 'review-manifest-v2.json'
    if output.exists():
        raise ValueError('manifest already exists')
    output.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    print('both builds: 13 current inputs match before, after and reviewed archives')
    print('frozen files:', len(trees[str(FROZEN)]))
    print('manifest sha256:', digest(output))


if __name__ == '__main__':
    main()
