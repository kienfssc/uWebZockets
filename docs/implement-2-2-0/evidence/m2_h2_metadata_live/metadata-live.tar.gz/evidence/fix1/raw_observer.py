"""Bounded raw HTTP/2 frame-order observation; transport is external."""

READ_BOUND = 8192
STREAM_LIMIT = 8


def require(condition, message):
    if not condition:
        raise ValueError(message)


def new_state():
    return {"header": bytearray(), "remaining": 0, "frame": None,
            "reset_payload": bytearray(), "streams": {}}


def register(state, stream_id, expect_reset):
    streams = state["streams"]
    require(0 < stream_id <= 0x7fffffff and stream_id not in streams, "invalid stream")
    require(len(streams) < STREAM_LIMIT, "stream bound")
    streams[stream_id] = {"expect_reset": expect_reset, "end": False, "reset": False}


def retire(state, stream_id):
    record = state["streams"][stream_id]
    require(record["end"] and record["reset"] == record["expect_reset"], "incomplete stream")
    del state["streams"][stream_id]


def finish_frame(state):
    frame = state["frame"]
    stream_id = frame["stream"]
    if frame["type"] == 3:
        record = state["streams"].get(stream_id)
        require(record is not None, "reset on unregistered stream")
        require(record["expect_reset"], "reset on healthy stream")
        require(record["end"], "reset before final end")
        require(not record["reset"], "duplicate reset")
        require(state["reset_payload"] == b'\0\0\0\0', "wrong reset code")
        record["reset"] = True
    elif frame["type"] in (0, 1) and frame["flags"] & 1:
        record = state["streams"].get(stream_id)
        if record is not None:
            require(not record["end"], "duplicate final end")
            record["end"] = True
    state["frame"] = None
    state["reset_payload"].clear()


def observe(state, data):
    require(len(data) <= READ_BOUND, "read bound")
    offset = 0
    while offset < len(data):
        if state["frame"] is None:
            header = state["header"]
            count = min(9 - len(header), len(data) - offset)
            header.extend(data[offset:offset + count])
            offset += count
            if len(header) < 9:
                continue
            length = int.from_bytes(header[:3], "big")
            frame_type = header[3]
            stream_id = int.from_bytes(header[5:9], "big") & 0x7fffffff
            if frame_type == 3:
                require(length == 4 and stream_id != 0, "invalid reset frame")
            state["frame"] = {"type": frame_type, "flags": header[4], "stream": stream_id}
            state["remaining"] = length
            header.clear()
            if length == 0:
                finish_frame(state)
            continue
        count = min(state["remaining"], len(data) - offset)
        if state["frame"]["type"] == 3:
            state["reset_payload"].extend(data[offset:offset + count])
        offset += count
        state["remaining"] -= count
        if state["remaining"] == 0:
            finish_frame(state)
