"""Pure checks for the metadata-only caller and case interface."""
import ast
import importlib.util
import sys
from pathlib import Path

root = Path(sys.argv[1])
runner = ast.parse((root / 'run_live.py').read_text())
cases_ast = ast.parse((root / 'cases.py').read_text())
expected = next(n for n in cases_ast.body if isinstance(n, ast.FunctionDef) and n.name == 'expected')
assert [x.arg for x in expected.args.args] == ['tag', 'selected', 'empty_hash']
assert not any(isinstance(n, ast.Name) and n.id in {'credit_hash', 'initial_credit', 'zero_credit', 'settled_credit', 'refund_bound', 'active'} for n in ast.walk(runner))
assert 'concurrent_refused' not in (root / 'run_live.py').read_text()
assert 'partial_done' not in (root / 'profile.zig').read_text()
assert 'get_metrics()[\'active\'] == 0' in (root / 'run_live.py').read_text()
api = next(n.value for n in ast.walk(runner) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'api' for t in n.targets))
assert {k.value for k in api.keys} == {'start', 'finish', 'send', 'trailers', 'status', 'resume', 'pending'}
spec = importlib.util.spec_from_file_location('metadata_cases', root / 'cases.py')
cases = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cases)
assert cases.expected('metadata_helpers', {'metadata_helpers'}, 'empty')['accepted'] == 32
assert cases.expected('spare_00', {'metadata_helpers'}, 'empty')['sha256'] == 'empty'
assert len(cases.TAGS) == 32 and len(set(cases.TAGS)) == 32
print('metadata-only interface, inactive scaffolding removal, retained active guard and record expectations: OK')
