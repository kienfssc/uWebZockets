"""Compile fixed source with reviewed argv, capturing complete identities."""
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
META = HERE.parent
BASE = META / 'recovery-2026-10-29/current/manifest.json'
FROZEN = Path('/tmp/uwz-task5b4-fix1-frozen')
BASE_HASH = '4c24ae205154e1ffda807e2d10083488051ce13a9544f776748a04659f1852ea'

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while data := f.read(1048576): h.update(data)
    return h.hexdigest()

def inventory(path):
    path = Path(path)
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}

def snapshot(manifest):
    trees = {p: inventory(p) for p in manifest['trees']}
    assert trees == manifest['trees']
    assert all(digest(p) == v for p, v in manifest['inputs'].items())
    fixed = inventory(FROZEN)
    assert len(fixed) == 10
    assert all(digest(HERE / n) == value for n, value in fixed.items())
    return trees, fixed

def main():
    assert digest(BASE) == BASE_HASH
    manifest = json.loads(BASE.read_text())
    trees, fixed = snapshot(manifest)
    print('preflight original current closure: OK; fixed frozen files:', len(fixed), flush=True)
    reviewed = json.loads((META.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
    spec = importlib.util.spec_from_file_location('build_closure', FROZEN / 'build_closure.py')
    closure = importlib.util.module_from_spec(spec); spec.loader.exec_module(closure)
    for mode in ('debug', 'release'):
        old = json.loads((META / ('fixture-' + mode + '-final.json')).read_text())
        argv = old['argv'].copy()
        index = next(i for i, x in enumerate(argv) if x.startswith('-Mroot='))
        argv[index] = '-Mroot=' + str(FROZEN / 'profile.zig')
        output = Path('/tmp/uwz-task5b4-fix1-' + mode + '/profile')
        assert not output.exists()
        output.parent.mkdir(parents=True, exist_ok=True)
        argv[-1] = '-femit-bin=' + str(output)
        assert all(Path(argv[argv.index(flag) + 1]).is_dir() for flag in ('--cache-dir', '--global-cache-dir'))
        before = {p: digest(p) for p in sorted(closure.argv_inputs(argv))}
        assert len(before) == 13 and all(before[p] == reviewed[p] for p in closure.ARCHIVES)
        for p, value in old['input_sha256'].items():
            if p != str(META / 'profile.zig'): assert before[p] == value
        proc = subprocess.run(argv, cwd=old['cwd'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (HERE / (mode + '.log')).write_bytes(proc.stdout)
        after = {p: digest(p) for p in before}
        trees_after, fixed_after = snapshot(manifest)
        record = {'argv': argv, 'cwd': old['cwd'], 'optimization': old['optimization'], 'input_sha256': before, 'input_after': after, 'inputs_unchanged': before == after and trees == trees_after and fixed == fixed_after, 'trees_before': trees, 'trees_after': trees_after, 'fixed_before': fixed, 'fixed_after': fixed_after, 'exit_status': proc.returncode, 'binary_sha256': digest(output) if output.exists() else None, 'raw_output': str(HERE / (mode + '.log'))}
        (HERE / (mode + '.json')).write_text(json.dumps(record, indent=2) + '\n')
        print(mode, 'exit', proc.returncode, 'output bytes', len(proc.stdout), 'sha256', record['binary_sha256'], 'unchanged', record['inputs_unchanged'], flush=True)
        assert proc.returncode == 0 and record['inputs_unchanged']

if __name__ == '__main__': main()
