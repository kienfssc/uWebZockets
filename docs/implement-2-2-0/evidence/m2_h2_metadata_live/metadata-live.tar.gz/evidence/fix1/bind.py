"""Bind fixed current artifacts and verify complete inert closure."""
import importlib.util
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
META = HERE.parent
BASE = META / 'recovery-2026-10-29/current/manifest.json'
FROZEN = Path('/tmp/uwz-task5b4-fix1-frozen')
OLD_FROZEN = '/tmp/uwz-task5b4-frozen-v2'
MANIFEST = HERE / 'manifest.json'
spec = importlib.util.spec_from_file_location('compile_helpers', HERE / 'compile.py')
helpers = importlib.util.module_from_spec(spec); spec.loader.exec_module(helpers)
digest = helpers.digest

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result

def validate(base):
    closure = module('build_closure', FROZEN / 'build_closure.py')
    receipts, commands = [], []
    for mode in ('debug', 'release'):
        actual = json.loads((HERE / (mode + '.json')).read_text())
        old = json.loads((META / ('fixture-' + mode + '-final.json')).read_text())
        expected = old['argv'].copy()
        expected[next(i for i, x in enumerate(expected) if x.startswith('-Mroot='))] = '-Mroot=' + str(FROZEN / 'profile.zig')
        expected[-1] = '-femit-bin=/tmp/uwz-task5b4-fix1-' + mode + '/profile'
        assert actual['argv'] == expected and actual['cwd'] == old['cwd']
        assert actual['trees_before'] == actual['trees_after'] == base['trees']
        assert actual['fixed_before'] == actual['fixed_after'] == helpers.inventory(FROZEN)
        assert actual['inputs_unchanged'] and actual['exit_status'] == 0
        assert Path(actual['raw_output']).read_bytes() == b''
        assert digest('/tmp/uwz-task5b4-fix1-' + mode + '/profile') == actual['binary_sha256']
        receipts.append(actual)
        commands.append({'argv': expected, 'input_sha256': actual['input_sha256']})
    current = {p: digest(p) for p in receipts[0]['input_sha256']}
    reviewed = json.loads((META.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
    merged = closure.validate_receipts(receipts, commands, current, {p: reviewed[p] for p in closure.ARCHIVES})
    return receipts, merged

def main():
    assert digest(BASE) == helpers.BASE_HASH
    base = json.loads(BASE.read_text())
    receipts, merged = validate(base)
    if sys.argv[1] == 'create':
        assert not MANIFEST.exists()
        del base['trees'][OLD_FROZEN]
        del base['tree_counts'][OLD_FROZEN]
        base['inputs'] = {p: h for p, h in base['inputs'].items() if not p.startswith(OLD_FROZEN + '/') and not p.startswith('/tmp/uwz-task5b4-current-')}
        fixed = helpers.inventory(FROZEN)
        base['trees'][str(FROZEN)] = fixed
        base['tree_counts'][str(FROZEN)] = len(fixed)
        for n, h in fixed.items():
            base['inputs'][str(FROZEN / n)] = h
            assert digest(HERE / n) == h
            base['inputs'][str(HERE / n)] = h
        base['inputs'].update(merged)
        for mode, receipt in zip(('debug', 'release'), receipts):
            base['inputs']['/tmp/uwz-task5b4-fix1-' + mode + '/profile'] = receipt['binary_sha256']
        for path in (BASE, HERE / 'compile.py', HERE / 'bind.py', HERE / 'check_contract.py', HERE / 'debug.json', HERE / 'release.json', HERE / 'debug.log', HERE / 'release.log'):
            base['inputs'][str(path)] = digest(path)
        for key, name in (('runner', 'run_live.py'), ('cases', 'cases.py'), ('wire', 'wire.py'), ('raw', 'raw_observer.py'), ('flow', 'flow_ledger.py')):
            base[key] = str(FROZEN / name)
        base['binary'] = '/tmp/uwz-task5b4-fix1-release/profile'
        base['build_input_receipts'] = [str(HERE / (mode + '.json')) for mode in ('debug', 'release')]
        base['scope'] = 'fix1 current actual build and runtime closure; historical binary reproduction unproved'
        MANIFEST.write_text(json.dumps(base, sort_keys=True, indent=2) + '\n')
        print('created fix1 manifest sha256:', digest(MANIFEST))
    elif sys.argv[1] == 'check':
        manifest = json.loads(MANIFEST.read_text())
        assert all(manifest['inputs'][p] == h for p, h in merged.items())
        assert not any(p.startswith('/tmp/uwz-task5b4-current-') or p.startswith(OLD_FROZEN + '/') for p in manifest['inputs'])
        runner = module('inert_runner', FROZEN / 'run_live.py')
        checked = runner.check_manifest(MANIFEST, digest(MANIFEST))
        assert checked['binary'] == '/tmp/uwz-task5b4-fix1-release/profile'
        print('validated two actual receipts, 13 direct inputs and six reviewed archives')
        print('inert manifest check:', len(checked['inputs']), 'inputs,', len(checked['trees']), 'trees')
        print('fix1 manifest sha256:', digest(MANIFEST))
    else:
        raise ValueError('expected create or check')

if __name__ == '__main__': main()
