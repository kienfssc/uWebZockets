"""Recover exact reviewed inputs from retained bytes without executing them."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_exact(destination, relative, expected, data):
    name = PurePosixPath(relative)
    assert not name.is_absolute() and '..' not in name.parts
    assert digest(data) == expected
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == data
        return
    target.write_bytes(data)
    target.chmod(0o444)


def accept_bytes(destination, needed, provenance, data, origin):
    identity = digest(data)
    matches = needed.pop(identity, ())
    for relative in matches:
        write_exact(destination, relative, identity, data)
        provenance[relative] = origin


def inventory(destination):
    return {p.relative_to(destination).as_posix(): digest(p.read_bytes())
            for p in sorted(destination.rglob('*')) if p.is_file()}


def restore_source(root, destination, expected):
    destination.mkdir(exist_ok=True)
    actual = inventory(destination)
    assert all(expected.get(name) == identity for name, identity in actual.items())
    previous = json.loads((root / '.uwz-work/evidence/h2-streaming/body-queue/restored-2026-10-28.json').read_text())['provenance']
    needed = {}
    provenance = {}
    for relative, identity in expected.items():
        if relative in actual:
            provenance[relative] = 'verified partial recovery from first pass'
            continue
        candidates = [root / relative]
        origin = previous.get(relative, '')
        if origin.startswith('preserved-snapshot:'):
            candidates.append(root / origin.removeprefix('preserved-snapshot:'))
        for source in candidates:
            if source.is_file() and not source.is_symlink() and digest(source.read_bytes()) == identity:
                write_exact(destination, relative, identity, source.read_bytes())
                provenance[relative] = str(source)
                break
        else:
            needed.setdefault(identity, []).append(relative)
    names = ('m2_h2_native_tcp', 'm2_h2_native_admission', 'm2_h2_terminal_inputs',
             'm2_h2_native_startup', 'm2_h2_session_delivery')
    for name in names:
        if not needed:
            break
        folder = root / 'docs/implement-2-2-0/evidence' / name
        manifest = json.loads((folder / 'manifest.json').read_text())
        archive = folder / manifest['archive']
        with tarfile.open(archive, 'r:gz') as reader:
            for member in reader:
                if member.isfile():
                    accept_bytes(destination, needed, provenance, reader.extractfile(member).read(),
                                 str(archive) + ':' + member.name)
    candidates = (root / '.uwz-work/evidence').rglob('*')
    for source in candidates:
        if not needed:
            break
        if source.is_file() and not source.is_symlink() and source.stat().st_size <= 2 * 1024 * 1024:
            accept_bytes(destination, needed, provenance, source.read_bytes(), str(source))
    assert not needed, {'missing_hashes': list(needed)}
    assert inventory(destination) == expected
    return provenance


def restore_override(root, destination, expected):
    destination.mkdir()
    repository = root / '.uwz-work/drafts/libxev-udp-fix'
    commit = 'c223bd886c6a51d2cd60def39dd9a68d701fea73'
    for relative, identity in expected.items():
        data = subprocess.run(['git', '-C', str(repository), 'show', commit + ':' + relative],
                              check=True, capture_output=True).stdout
        write_exact(destination, relative, identity, data)
    assert inventory(destination) == expected


def main():
    root = Path('/workspaces/uWebZockets')
    manifest_path = root / '.uwz-work/evidence/h2-streaming/integration-owned/metadata/review-manifest-v2.json'
    assert digest(manifest_path.read_bytes()) == '5a47148bd2c9857a0cbe9b5b5ea8760c4eeadefbdf3651cb583d154373e73b07'
    manifest = json.loads(manifest_path.read_text())
    source = Path('/tmp/uwz-task4d-fix1-frozen')
    override = Path('/tmp/uwz-reviewed-libxev-c223-loop-callbacks')
    frozen = Path('/tmp/uwz-task5b4-frozen-v2')
    assert not override.exists() and not frozen.exists()
    provenance = restore_source(root, source, manifest['trees'][str(source)])
    restore_override(root, override, manifest['trees'][str(override)])
    frozen.mkdir()
    fixture = manifest_path.parent
    for relative, identity in manifest['trees'][str(frozen)].items():
        write_exact(frozen, relative, identity, (fixture / relative).read_bytes())
    assert inventory(frozen) == manifest['trees'][str(frozen)]
    pairs = list(inventory(source).items())
    source_sha = digest(json.dumps(pairs).encode())
    assert source_sha == 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de'
    for directory in (source, override, frozen):
        for path in sorted(directory.rglob('*'), reverse=True):
            if path.is_dir():
                path.chmod(0o555)
        directory.chmod(0o555)
    output = fixture / 'recovery-2026-10-29'
    output.mkdir()
    result = {'source_digest': source_sha, 'source_files': len(pairs), 'source_provenance': provenance,
              'override_files': 93, 'fixture_files': len(manifest['trees'][str(frozen)]),
              'network_contact': False, 'native_execution': False,
              'prior_receipts_manifests_unchanged': True}
    (output / 'restored-source.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'source_provenance'}))


if __name__ == '__main__':
    main()
