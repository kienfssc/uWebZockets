const std = @import("std");
const body = @import("../http/request_body.zig");
const radix = @import("radix.zig");
const Request = @import("../http/request.zig").Request;
const Response = @import("../http/response.zig").Response;

/// Caller-owned parallel metadata slots, borrowed for admission and response life.
pub const Slots = struct { names: [][]const u8, values: [][]const u8 };
/// Validated neutral facts; wire framing remains with each protocol owner.
pub const Input = struct {
    request: *Request,
    method: ?radix.HttpMethod,
    headers: Slots,
    captures: Slots,
    declared: ?u64,
    ingress_available: bool,
    pending_header_capacity: usize,
    early_data_forbidden: bool,
    upgrade_intent: bool,
};
/// Refusals precede reservation and begin.
pub const AdmissionRefusal = enum { too_early, invalid_query, body_too_large, unavailable };
/// A selected route is still unreserved.
pub const Decision = union(enum) { buffered, final, reject: AdmissionRefusal, stream: radix.BodyMatch };
/// Explicit application policy borrows its Response only through return.
pub const ResolveFn = *const fn (*anyopaque, *const Input, *Response) Decision;
/// Stable application and router ownership, independent of a sink binding.
pub const Target = struct { context: *anyopaque, router: *radix.Router, resolve: ResolveFn };
/// Existing reservation and lifecycle failures, including rollback ownership.
pub const ArmError = radix.BodyAdmissionError || body.BodyStateError || error{BodyAdmissionMissing};

/// Shared App policy keeps middleware ordering and quota checks identical.
pub fn resolve_router(router: *radix.Router, input: *const Input, response: *Response) Decision {
    const request = input.request;
    if (input.method == .options and std.mem.eql(u8, request.path, "*")) return .buffered;
    const route = router.match(request.path, input.method) orelse return .buffered;
    if (route.ws_behavior != null and input.upgrade_intent) return .buffered;
    const selected = route.body_match orelse return .buffered;
    if (input.early_data_forbidden) return .{ .reject = .too_early };

    request.extra_header_names = input.headers.names;
    request.extra_header_values = input.headers.values;
    request.extra_header_count = @min(input.headers.names.len, input.headers.values.len);
    request.body = "";
    if (!request.valid_query_content_type()) return .{ .reject = .invalid_query };
    request.extra_param_names = input.captures.names;
    request.extra_param_values = input.captures.values;
    request.extra_param_count = 0;
    _ = router.match_request(request, input.method) orelse return .{ .reject = .unavailable };
    router.check_body_route(selected) catch |err| switch (err) {
        // Authorized globals precede quota refusal, even when already full.
        error.BodyAdmissionFull => {},
        else => return .{ .reject = .unavailable },
    };
    response.request_body_complete = false;
    if (router.run_middleware(request, response) == .stop) return .final;
    if ((input.declared orelse 0) > selected.definition.limits.max_body_bytes)
        return .{ .reject = .body_too_large };
    if (!input.ingress_available) return .{ .reject = .unavailable };
    if (response.pending_header_length > input.pending_header_capacity) return .{ .reject = .unavailable };
    router.check_body_route(selected) catch return .{ .reject = .unavailable };
    return .{ .stream = selected };
}

/// Transfers one router reservation to common state without callbacks or I/O.
/// Router, route definition and state must stay stable on the owning loop.
/// After success, only BodyState's terminal/reject booleans authorize release.
pub fn reserve_and_arm(
    router: *radix.Router,
    selected: radix.BodyMatch,
    state: *body.BodyState,
    target: body.BodyControlTarget,
    declared: ?u64,
) ArmError!body.BodyControl {
    if (state.phase != .inactive or state.reserved) return error.BodyStateBusy;
    try router.reserve_body_route(selected);
    return state.arm(target, selected.definition.limits, declared) catch |err| {
        // No callback can intervene: this reservation never entered BodyState.
        try router.release_body_route(selected.record_index);
        return err;
    };
}
