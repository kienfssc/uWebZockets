const std = @import("std");
const support = @import("test_support");
const http2 = support.http2;
const hpack = support.http2_hpack;
const server = support.http2_server;
const Session = server.server_session(2);
const Bundle = Session.Bundle(.{ .body_size = 32 });

const WidthCase = struct {
    length: []const u8,
    duplicate: ?[]const u8 = null,
    selector: bool = true,
    refuse: bool = true,
    reset: ?server.ErrorCode = null,
};

const Context = struct {
    bytes: [1024]u8 = undefined,
    length: usize = 0,
    deliveries: usize = 0,
    refuse: bool,

    fn write(context: *anyopaque, parts: []const []const u8) !void {
        const state: *Context = @ptrCast(@alignCast(context));
        for (parts) |part| {
            if (part.len > state.bytes.len - state.length) return error.OutputTooSmall;
            @memcpy(state.bytes[state.length..][0..part.len], part);
            state.length += part.len;
        }
    }

    fn request(context: *anyopaque, _: *support.http_request.Request, _: u32) !void {
        const state: *Context = @ptrCast(@alignCast(context));
        state.deliveries += 1;
    }

    fn select(context: *anyopaque, _: *const support.http_request.Request) server.HeaderDecision {
        const state: *const Context = @ptrCast(@alignCast(context));
        return if (state.refuse) .refuse_body else .buffered;
    }
};

fn literal(output: []u8, length: *usize, name: []const u8, value: []const u8) !void {
    if (name.len >= 127 or value.len >= 127) return error.TestFieldTooLong;
    const needed = 3 + name.len + value.len;
    if (needed > output.len - length.*) return error.OutputTooSmall;
    const start = length.*;
    output[start] = 0;
    output[start + 1] = @intCast(name.len);
    @memcpy(output[start + 2 ..][0..name.len], name);
    output[start + 2 + name.len] = @intCast(value.len);
    @memcpy(output[start + 3 + name.len ..][0..value.len], value);
    length.* += needed;
}

fn frame(session: *Session, kind: http2.FrameType, flags: u8, stream_id: u32, payload: []const u8, callbacks: server.Callbacks) !void {
    var bytes: [512]u8 = undefined;
    if (payload.len > bytes.len - 9) return error.OutputTooSmall;
    try (http2.FrameHeader{ .payload_length = @intCast(payload.len), .frame_type = @intFromEnum(kind), .flags = flags, .stream_id = stream_id }).encode(bytes[0..9]);
    @memcpy(bytes[9..][0..payload.len], payload);
    try session.receive(bytes[0 .. 9 + payload.len], callbacks);
}

fn expect_outcome(bytes: []const u8, reset: ?server.ErrorCode) !void {
    const header = try http2.FrameHeader.parse(bytes[0..9]);
    try std.testing.expectEqual(@as(u32, 1), header.stream_id);
    if (reset) |code| {
        try std.testing.expectEqual(@as(usize, 13), bytes.len);
        try std.testing.expectEqual(@intFromEnum(http2.FrameType.rst_stream), header.frame_type);
        try std.testing.expectEqual(@intFromEnum(code), std.mem.readInt(u32, bytes[9..13], .big));
        return;
    }
    try std.testing.expectEqual(@intFromEnum(http2.FrameType.headers), header.frame_type);
    try std.testing.expectEqual(@as(u8, 5), header.flags);
    var table = try hpack.DynamicTable.init(&.{}, &.{}, 0);
    var decoder = hpack.Decoder.init(&table, 512);
    var fields: [4]hpack.Header = undefined;
    var storage: [512]u8 = undefined;
    const decoded = try decoder.decode_fields(bytes[9..][0..header.payload_length], &fields, &storage);
    try std.testing.expectEqualStrings("503", decoded[0].value);
    const offset = 9 + header.payload_length;
    try std.testing.expectEqual(offset + 13, bytes.len);
    const last = try http2.FrameHeader.parse(bytes[offset..][0..9]);
    try std.testing.expectEqual(@intFromEnum(http2.FrameType.rst_stream), last.frame_type);
    try std.testing.expectEqual(@as(u32, 0), std.mem.readInt(u32, bytes[offset + 9 ..][0..4], .big));
}

test "body H2: wire lengths remain u64 before buffered machine-width policy" {
    const width_error: server.ErrorCode = if (@sizeOf(usize) == 4) .protocol_error else .enhance_your_calm;
    const cases = [_]WidthCase{
        .{ .length = "4294967296" },
        .{ .length = "18446744073709551615" },
        .{ .length = "33", .duplicate = "1", .reset = .protocol_error },
        .{ .length = "18446744073709551616", .reset = .protocol_error },
        .{ .length = "33", .duplicate = "1", .refuse = false, .reset = .enhance_your_calm },
        .{ .length = "4294967296", .refuse = false, .reset = width_error },
        .{ .length = "4294967296", .selector = false, .refuse = false, .reset = width_error },
    };
    for (cases) |case| {
        var bundle = Bundle{};
        var session = try Session.init(bundle.storage());
        var state = Context{ .refuse = case.refuse };
        const callbacks = server.Callbacks{
            .context = &state,
            .write_fn = Context.write,
            .request_fn = Context.request,
            .header_fn = if (case.selector) Context.select else null,
        };
        try session.receive(http2.client_preface, callbacks);
        try frame(&session, .settings, 0, 0, "", callbacks);
        state.length = 0;
        var block: [256]u8 = undefined;
        var length: usize = 0;
        try literal(&block, &length, ":method", "POST");
        try literal(&block, &length, ":scheme", "https");
        try literal(&block, &length, ":path", "/upload");
        try literal(&block, &length, "content-length", case.length);
        if (case.duplicate) |value| try literal(&block, &length, "content-length", value);
        try frame(&session, .headers, 4, 1, block[0..length], callbacks);
        try expect_outcome(state.bytes[0..state.length], case.reset);
        try std.testing.expectEqual(@as(usize, 0), state.deliveries);
        try std.testing.expect(!session.closed);
    }
}

const SelectedContext = struct {
    output: Context = .{ .refuse = false },
    declared: ?u64 = null,
    heads: usize = 0,
    ends: usize = 0,
    closes: usize = 0,

    fn write(context: *anyopaque, parts: []const []const u8) !void {
        const state: *SelectedContext = @ptrCast(@alignCast(context));
        try Context.write(&state.output, parts);
    }

    fn request(_: *anyopaque, _: *support.http_request.Request, _: u32) !void {
        return error.UnexpectedBufferedDispatch;
    }

    fn select(_: *anyopaque, _: *const support.http_request.Request) bool {
        return true;
    }

    fn event(context: *anyopaque, input: server.BodyEvent) !server.BodyEventResult {
        const state: *SelectedContext = @ptrCast(@alignCast(context));
        switch (input) {
            .head => |head| {
                state.heads += 1;
                state.declared = head.declared;
                return .{ .head = .{ .accepted = .paused } };
            },
            .data => return error.UnexpectedBodyData,
            .end => state.ends += 1,
            .closed => state.closes += 1,
        }
        return .done;
    }
};

test "body H2: selected encoded Session preserves full u64 declaration without claiming EOF" {
    const lengths = [_][]const u8{ "4294967296", "18446744073709551615" };
    for (lengths) |length_text| {
        var bundle = Session.Bundle(.{ .body_size = 32, .stream_request_bodies = true }){};
        var session = try Session.init(bundle.storage());
        var state = SelectedContext{};
        const callbacks = server.Callbacks{ .context = &state, .write_fn = SelectedContext.write, .request_fn = SelectedContext.request, .body_select_fn = SelectedContext.select, .body_event_fn = SelectedContext.event };
        try session.receive(http2.client_preface, callbacks);
        try frame(&session, .settings, 0, 0, "", callbacks);
        state.output.length = 0;
        var block: [256]u8 = undefined;
        var length: usize = 0;
        try literal(&block, &length, ":method", "POST");
        try literal(&block, &length, ":scheme", "https");
        try literal(&block, &length, ":path", "/upload");
        try literal(&block, &length, "content-length", length_text);
        try frame(&session, .headers, 4, 1, block[0..length], callbacks);
        try std.testing.expectEqual(@as(usize, 1), state.heads);
        try std.testing.expectEqual(try std.fmt.parseInt(u64, length_text, 10), state.declared.?);
        try std.testing.expect(session.expected_content_lengths[0] == null);
        try std.testing.expectEqual(@as(usize, 0), state.ends);
        try std.testing.expectEqual(@as(usize, 0), state.output.length);
        try std.testing.expect(session.connection.streams.find(1) != null);
        try session.cancel_body(1, .cancelled, callbacks);
        try std.testing.expectEqual(@as(usize, 1), state.closes);
        try std.testing.expectEqual(@as(usize, 0), state.ends);
        try std.testing.expect(!session.closed);
    }
}
