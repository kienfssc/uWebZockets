# Task 5b4 Stage A preparation

Status: prepared for independent review, not behavioral proof or authorization to execute. The frozen v2 driver and current closure are at `/tmp/uwz-task5b4-frozen-v2` and `.uwz-work/evidence/h2-streaming/integration-owned/metadata/review-manifest-v2.json` respectively. Manifest SHA-256: `5a47148bd2c9857a0cbe9b5b5ea8760c4eeadefbdf3651cb583d154373e73b07`. The earlier frozen directory and manifest are preserved as intermediates; v2 corrects its manifest state to match the driver's identity gate.

The test-only fixture registers the real metadata route, keeps 32 records and two sink slots, independently checks all initial headers and captures in middleware, begin and end, calls both empty body accessors and all five fallible helpers in both callbacks, and tracks separate comparison counters. The driver selects `metadata_helpers` and `shutdown_idle`, uses the existing process and H2 machinery, and measures actual generated HEADERS/CONTINUATION data before sending, requiring at most 8192 bytes. Runtime encoding depends on the real connection's encoder state; the pure observation below is not a runtime expectation. The full case, status barriers, ownership and deinit behavior remain unproved without a separate authorized host run. No native executable, server, client, socket, certificate or binary help was executed.

## Compile-only results

Commands (the receipts contain the complete actual Zig argv, all 13 input hashes, before/after frozen source and c223 maps, and binary hashes):

```
python3 .uwz-work/evidence/h2-streaming/integration-owned/metadata/prepare.py --optimization Debug --output /tmp/uwz-task5b4-final-debug --cache-root /tmp/uwz-task5a-debug --record fixture-debug-final
Exit status: 0
python3 .uwz-work/evidence/h2-streaming/integration-owned/metadata/prepare.py --optimization ReleaseSafe --output /tmp/uwz-task5b4-final-release --cache-root /tmp/uwz-task5a-release --record fixture-release-final
Exit status: 0
```

Both compile logs were empty. Debug binary SHA-256 `5f480df3ebe4914a4e111e1afeb4c9a8d1285cab1cd77ac11cb67a756552f9b9`; ReleaseSafe binary `b65535456c7ea43a30d1370b54f4747a672a5f8db4a69c348cec99cf17cc81c2`. The profile SHA-256 is `c12ecc91a886f015f46bc809284666d46195d786536a28a8de49e548d6fe85b1`. Builds used `-j2`, frozen source `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`, reviewed c223, and unchanged six reviewed archives. Receipt hashes: Debug `617932888a2ca611e7ba41a6caee2fa5ddcd50648cc87f7fcc12c6f50607b503`; ReleaseSafe `4f5b3ff51d669814dce3ec2c394c7364dac1efc009f9a2139a5c923c53ee1fc9`.

## Pure and identity checks

```
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5b4-frozen-v2/pure_codec_checks.py
fields=69 decoded_bytes=684 list_cost=2892 path=86 target=99
actual fresh pinned codec encoded header bytes=732
case tags=32 unique=32
```

Exit status 0. This exercises real pinned H2/HPACK frame generation and pure caller-data arithmetic only; it does not exercise transport, callbacks or the fixture.

```
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check .uwz-work/evidence/h2-streaming/integration-owned/metadata/profile.zig
```

Exit status 0, no output. Frozen Python sources parsed with `ast.parse`: `AST parsed: 9`, exit 0. Running the frozen runner's `check_manifest` as an inert import with the v2 manifest and hash returned `frozen manifest and current inputs verified: 2428 inputs, 6 trees`, exit 0. The freeze script independently checked both receipts against actual current input hashes and the reviewed archive map, and emitted `both builds: 13 current inputs match before, after and reviewed archives` and `frozen files: 10`. Its full command is `python3 .uwz-work/evidence/h2-streaming/integration-owned/metadata/freeze.py`; the current script was used for the v2 frozen destination. Historical manifests remain referenced by identity rather than inherited binary-input unions.

## Scope and gaps

The profile preserves the documented eight connections, eight native H2 streams, 73728 receive payload, 512 request line, 4096/80 header bounds, 256 H1 and 4096 H2 body bounds, 8192 encoded block bound, 4096/32 response headers, 24 captures, 65536 write queue and 4098304-byte slab. Initial metadata is 65 ordinary plus four pseudo fields; after synthesized Host it has 66 visible fields (64 inline and two extra), with 17 captures (16 inline and one extra). Trailer bytes and behavior, final 32-byte accepted digest and post-deinit equality remain runtime assertions, not observations.

The prior independent public manifest audit counts 25 proved H2 IDs and 15 remaining, including this one and 14 Task 5c IDs, for 40 IDs total. Combined pre-output body history requires at least 60 records including the two core uploads; this isolated 32-record fixture is not a combined history solution. H3, multipart runtime, physical/platform/full-quality gates, genuine early data, maintained publication, production adoption and all original milestone requirements remain open. Independent review must audit the fixture, driver, live encoded-header observation and current manifest before any separately authorized execution. The full local matrix and protocol compliance runners were not run because Stage A permits compile and pure checks only.

## Fix round 1

The new scoped subject removes inactive credit scaffolding identified in the initial process review. See `task-5b4-fix-1-report.md` for exact fixed-source identities, fresh Debug and ReleaseSafe compile-only receipts, focused pure checks and the new complete manifest. Historical artifacts and mismatch remain preserved; this subject awaits scoped independent re-review and does not establish native behavior.
