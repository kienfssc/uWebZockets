# Task5b4 bind fresh current builds

Continue the SAME recovery worker after reading task-5b4-recovery-report.md.
Root has read handling-reports, actual new receipts/logs and independently hashed
both fresh executables. No code or manifest correction has yet been attempted.

Ruling: byte reproduction of the lost historical executables is unproved;
neither current binary equals its historical SHA. Preserve that result and the
original manifests/receipts unchanged. Adopt the TWO ACTUAL fresh successful
builds as a NEW current review subject. This is not recovery of historical
binary identity or permission to claim historical native proof. Source/profile/
compiler/library/override/client identities match exactly before/after; actual
new artifacts can be independently bound and reviewed without changing any
source, threshold, capacity, assertion, tool or backend. Cost if wrong: only
the new current functional proof can be accepted; no reproducibility or old-
artifact-execution claim follows. Exact reason for binary differences remains
unproved; do not guess or run further compiler/native experiments to force it.

Use fresh Debug7ec029babf71b0335cf2b5f0fc83774d21a3692ec1de0580413063ae617ca388
and ReleaseSafe30d443388a5a178be447150c3701ad912eed3c9dc27014122b91390cb2381b5a,
from recovery-2026-10-29/{debug,release}.json, both exit0/emptylogs. Thirteen
direct inputs, six archives, fc69/c223/fulltrees and profilec12ecc91... match.
No further compile is needed or authorized for this unchanged source.

Own NEW recovery-2026-10-29/current/ files and update your recovery report.
You are not alone; preserve Rootrestored-source.json, ALL original/fresh source,
receipts/logs/manifests/artifacts. No product/old-source edits, subagents,
refs/push/download/external CLI. Keep all original task5b4 scope and bounds.

1. Copy exact fresh executable bytes to new clearly CURRENT paths:
   /tmp/uwz-task5b4-current-debug/profile and
   /tmp/uwz-task5b4-current-release/profile; executable permissions retained.
   Record source/destination hashes matching actual new receipts. Do not
   overwrite an existing different file or claim those are original artifacts.
2. Write a NEW current manifest, preserving originalv2 SHA5a47148b... . Keep
   original restored frozen10source bytes/paths unchanged; runtime source
   identities, inert imports, locale guard and all current protocol/metadata/
   process assertions must remain exact. Bind new copied binaries and NEW actual
   replay receipts/rawlogs/replay script/environment/restoration provenance.
   Derive and validate actual current 13-input before/after maps/argv, current
   archive identities and complete source/tool/runtime closure. Historical
   receipt/manifest data used by replay can remain bound AS DATA; their missing
   historical binary identities must not masquerade as current artifacts.
   Remove old binary paths from current runtime inputs, replace with actual
   current paths/hashes. No blind union of unrelated old test binary history.
3. Use existing pure build_closure validator where appropriate with explicit
   canonical mapping of the new before/after schema; also validate BOTH actual
   current binary outputs against their new receipts. Do not rely on hashing
   receipt bytes alone. All source/compiler/archive/tool identities stay strict.
4. Run source/AST/current manifest identity checks and focused pure checks only
   for newly amended closure-binding logic. Existing pure codec/AST just passed
   on exact source, no broad/repeated checks or builds. If importing the runner's
   manifest checker, keep it inert; never invoke its main/run or any socket/TLS
   constructor. Bound all exact commands/raw results and artifact identities.

Write task-5b4-current-build-report.md; append a pointer and honest supersession
note to recovery report without rewriting the historical mismatch. DONE means
coherent NEW current subject with both actual passing compile receipts and
strict complete closure, ready for FIRST independent source review. Native
behavior remains unproved, future exact host release is separate. No new fixture/
client/server/socket/certificate/binary-help/fulltests/fault/race/resource/
kernel/fd/completion/panic/leak/crash/stopped probes are authorized. All other
40-ID/full-matrix/H3/multipart/gates/adoption/original-goal requirements remain.
