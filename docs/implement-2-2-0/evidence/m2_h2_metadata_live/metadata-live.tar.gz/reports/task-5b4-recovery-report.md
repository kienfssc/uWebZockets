# Task 5b4 recovery: binary identity differs

Status: recovery is incomplete. Both compiler invocations succeeded and their outputs are preserved, but neither output has the historical binary hash. The original v2 manifest therefore does not describe the current binary files and the original closure cannot pass. The cause of the difference is unproved. No manifest or receipt was rebased. Root must decide the next subject for review; no native execution is authorized by this report.

## Fresh compile-only replay

The new replay script and records are under `.uwz-work/evidence/h2-streaming/integration-owned/metadata/recovery-2026-10-29/`. The script reads the original receipt argv and cwd verbatim, creates the original absent cache and output directories, invokes only the compiler, and records each full argv, cwd, optimization, direct input before/after hashes, source/override identities, exit status and binary hash in `debug.json` and `release.json`. Complete merged stdout/stderr is in `debug.log` and `release.log`, both zero bytes. `restored-source.json` is Root-owned and was not edited.

Commands and raw output:

```text
python3 .uwz-work/evidence/h2-streaming/integration-owned/metadata/recovery-2026-10-29/replay.py
preflight: manifest inputs excluding two absent binaries, 6 trees, both 13-input maps, six reviewed archives, source and override: OK
debug exit 0 sha256 7ec029babf71b0335cf2b5f0fc83774d21a3692ec1de0580413063ae617ca388 expected 5f480df3ebe4914a4e111e1afeb4c9a8d1285cab1cd77ac11cb67a756552f9b9 output bytes 0

python3 .uwz-work/evidence/h2-streaming/integration-owned/metadata/recovery-2026-10-29/replay.py release
preflight: manifest inputs excluding two absent binaries, 6 trees, both 13-input maps, six reviewed archives, source and override: OK
release exit 0 sha256 30d443388a5a178be447150c3701ad912eed3c9dc27014122b91390cb2381b5a expected b65535456c7ea43a30d1370b54f4747a672a5f8db4a69c348cec99cf17cc81c2 output bytes 0
```

The first command used Debug and stopped after the mismatch; the second used ReleaseSafe. Their respective original `zig build-exe` argv include `-j2`, original output paths, and original `/tmp/uwz-task5a-{debug,release}/{cache,global}` paths; the full exact argv and cwd are retained in the new JSON records and original receipts. No compiler retries, flags or other recipe changes were made. Both fresh binaries remain at `/tmp/uwz-task5b4-final-debug/profile` and `/tmp/uwz-task5b4-final-release/profile` respectively.

Preflight and post-compile checks each verified all original v2 manifest input hashes except the two binary paths, all six full tree inventories, both 13-input before/after maps, and all six archives against the reviewed admission manifest. The source inventory and digest `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`, c223 override inventory, fixture inputs, compiler and direct library hashes matched before and after both compiles. The compiled profile source remains `c12ecc91a886f015f46bc809284666d46195d786536a28a8de49e548d6fe85b1`. Existing receipt hashes remain Debug `617932888a2ca611e7ba41a6caee2fa5ddcd50648cc87f7fcc12c6f50607b503` and ReleaseSafe `4f5b3ff51d669814dce3ec2c394c7364dac1efc009f9a2139a5c923c53ee1fc9`; manifest remains `5a47148bd2c9857a0cbe9b5b5ea8760c4eeadefbdf3651cb583d154373e73b07`. Root's restoration record remains `391b6356b5e6189f31d6ae083372982621e452fecd5e3df5d2315296edc74193`.

The original cache contents were lost and empty directories were recreated at the original paths. The compiler executable hash matches the old direct input map; its library tree matches the manifest inventory. Current relevant environment is captured in `environment.json`: `LC_ALL` and `LANG` are `C.UTF-8`; `ZIG_LIB_DIR`, Zig cache overrides, `CC`, `CXX`, `AR`, `SOURCE_DATE_EPOCH`, and `TMPDIR` are unset. Host was `Linux codespaces-6c54c2 6.8.0-1064-azure #72~22.04.1-Ubuntu SMP Wed Jul 22 23:39:45 UTC 2026 x86_64`; replay Python was 3.14.2. Original receipts specify `explicit_environment: {}` but do not retain the full inherited environment. These facts do not establish the cause of the byte differences.

## Fresh pure checks

```text
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5b4-frozen-v2/pure_codec_checks.py
fields=69 decoded_bytes=684 list_cost=2892 path=86 target=99
actual fresh pinned codec encoded header bytes=732
case tags=32 unique=32
```

Exit 0. This is pinned codec and caller-data arithmetic, not a live H2 result. Nine frozen Python files were also parsed with `ast.parse`, exit 0, output `AST parsed: 9`.

Historical proof and earlier test results are not fresh recovery runs. No fixture, client, server, socket, certificate, binary help, full tests, or fault/stopped experiments were run. The 40-ID plan remains 25 proved and 15 remaining (including this metadata case and 14 later Task 5c IDs); full combined coverage, H3, multipart, all quality/platform gates, adoption and original milestones remain open. Independent source review and a separate exact Root release are required before any ordinary host run.

## Subsequent current-build ruling

Root accepted the two fresh builds as a new review subject without claiming historical byte reproduction. The original mismatch and evidence above remain valid. See `task-5b4-current-build-report.md` for the new manifest, fresh artifact identities and current closure checks; it supersedes the incomplete-recovery status only for readiness of that new subject for first independent review, not for historical artifact recovery or native behavior proof.
