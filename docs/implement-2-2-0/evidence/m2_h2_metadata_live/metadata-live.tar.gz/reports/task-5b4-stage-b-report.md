# Task5b4 owned metadata run

metadata_helpers and shutdown_idle pass once in an owned host Linux ReleaseSafe
TLS1.3/h2 run. Native execution used ONLY fixed current artifact64d71a53344a840bf2d33786a3b0c4757257406f6bb91ae848ad70f33d24a998,
profile5d96ef21b7a2b758cd285b648699df5b1bbbbe9c33d1fa7c274e4d30e6d004fd,
manifest1cc2e55ec90df730ddb8b0765225dc4e8c8191c76452a899564a1bbd96ff6fd7.
No historical metadata executable was recovered or run. Sourcefc69/c223/client/
binding/sixlibraries/profilecapacities remain unchanged except removed dead
fixturestate; Root production and ordinary dependency pins are unchanged.

## Exact released command

```sh
env -i LC_ALL=C.UTF-8 PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5b4-fix1-frozen/run_live.py --run --manifest /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/manifest.json --manifest-sha256 1cc2e55ec90df730ddb8b0765225dc4e8c8191c76452a899564a1bbd96ff6fd7 --output /tmp/uwz-h2-metadata-owned-2026-10-29-r1 --cases metadata_helpers shutdown_idle
```

Root exactrelease10247b0f9eb81048035ab6e8fbf8a394f6b5f4db031a76b23f880d4ac0b71482,
require_escalated toolapproved; session31920/finalchunk8f2468/exit0/emptyoutput.
One run/no retry or default-executor attempt. No stopped/historical denied
socket/native cancellation/fault/resource/kernel/fd/race/completion/panic/leak/
crash experiment was reconstructed or run.

## Current artifact and verification history

Userpause cleared/tmp. Root restored1031fc69,93c223,42client and10originalmetadata
source bytes from retained archives/provenance/localGit/wheels. All persistent
inputs matched. Two actual original-argv replay builds exited0 but SHA values
differed from historical artifacts; cause unproved. Original receipts/manifests
and mismatch preserved. Root binds ACTUAL fresh builds as separatecurrentsubject,
not exacthistoricalbyte recovery. FirstindependentprotocolSPEC/QUALITYPASS;
processSPECPASS/QUALITYP2deadcredit scaffolding. Sameownerremovesdeadhelpers/hash/
arg/impossiblebranch/partial_done, keepsget_metricszeroactive/liveflow checks.
FreshfixedDebug7c59ee53... andRelease64d71a53... compile0/emptylogs, bothscoped
re-reviewsPASS. Staticinterfacehygienered/green is notproductbehavioralred.

FinalRootaudit4acb391e936bab538ef29b3263ced1c6e1033b9d62529e68e406f3c8f512a036
checks2455individualinputs/6trees/6archives/bothactualfixbuilds and allmaps.
Identical after run. Initialaggregateaudit usedJSONkeyorderinstead ofdocumented
sortedPathpairs; allper-file/receipt checks passed. Rootpreservesv1auditor,
fixesencodingonly and retains samefc69 expectedhash/allchecks. ScopedASTrefresh
10codefiles exit0,133nodes/269edges/10communities,noAPI. No broadergate claim.

## Actual observations

- TwofreshownedTLS1.3/h2 connections,metadata andidle, samechild46991/start536455.
  PID/start/nonce/listener/certificate checkedbeforehealth. Actual initial HPACK
  block725bytes<=8192 BEFOREflush; purefresh-encoder732 is notnativeexpectation.
- Sixty-fiveordinary+fourpseudo wireheaders decode to66visibleheaders after
  Host synthesis;17captures. Middleware/begin/end independentmetadata checks
  eachpassonce,includingoverflowx-h62/Host/p16,method/path/target/query/empty
  protocol andcase-sensitiveP16absence. Trailersdiscarded/unmerged.
- Bothsameconn16-byte+16-byte/trailerEOF pausedbarrierspass:0accepted/chunks/end
  beforecopiedpublicresume. Final200/32bytes/H32
  7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5;
  M1/A1/B1/E1/C0/F0,0errors/active. Actualchunkcount1/maxspan32 areobservations,
  notcallback-segmentation requirements. Normalmiddlewareheaderonce.
- helpers_begin/helpers_end each1 mean a FULLsuite: fiveexactBodyNotBuffered
  errors,json/schema/detailedschema/form/multipart,emptytext/bytes,unchanged
  zeroallocator andIssuepointer/len/content/kind,successfulqueryhelpers. All
  checks mustfinishbeforeincrement; no per-methodcounterclaim is invented.
- All32records,including31untouchedspares,and finalmetrics equalafterdeinit.
  Bodymiddleware1+bufferedmiddleware39 account40heads. Idletraceomitseventsfield;
  no fabricated aggregateStreamEndedcounter is inferred. Source completion
  predicates and raw observation through statedbarriers remain explicit.
- OwnedSIGTERMexit0/reaped/noforce/cleanuperrors; keyremoved. RootHOSTread-only
  audit confirmsoriginalPIDabsent. Log14129B below65536cap. CertificateDER hash
  is recorded in rawresult and independently matches publiccertificate.

Rawresult47372B SHAb9b2c3f84b8c19abac82fa9ebe0e2a53db16fe16b3456234c46bc883c9d83209;
Rootresultaudit53fd1b8f91ba1b024aea637c10913b2114862690b385bb736db5d90e17882c26
independently checksrecords/headers/helperflags/counters/postlogs/TLS/encodedbound/
fingerprint/PID/keycleanup/preflight equality. stage-b holdsrawfiles/execution;
fix1 holdsauthorization/auditors/reviews and actualcompileoutputs/identities.

The full40ID inventory is26proved/14remaining, combinedmatrixunrun. Native
selectable-subsets, H3/multipart/genuineearlydata,allquality/platform/physical/
compliance/performance/provenance/maintainedpublication/adoption/original
milestones remainopen. Thisfunctionalrun provesnoRSS/leak/generalnative safety.
Publicreport/archive and publicationreview precedecommit/immediateforkpush.
