# Task5b4 fix round1/5: remove inactive metadata scaffolding

Resume /root/recover_h2_metadata_live, owner of the current subject. Original
pre-pause metadata worker is unavailable; preserve its source/evidence. Read
task-5b4-brief.md/current-build-report.md and both metadata/review-*-initial.md.
Root reads actual final reviews, covering source and fix-loop.md before this
round. Protocol SPEC/QUALITYPASS; process SPECPASS/QUALITYREQUESTCHANGES.

Exact open finding:

**P2 — Remove inactive credit-case scaffolding.** `run_live.py:402` retains
credit helpers and API entries that neither selectable case calls. Every
invocation also generates and hashes 65536 unrelated payload bytes at line330,
then passes the digest to an explicitly unused parameter in `cases.py:11`.
The impossible `concurrent_refused` branch and unused `profile.zig:74` field
are further leftovers. This violates the mandatory no-dead-code contract and
unnecessarily enlarges the metadata review surface. Remove these in a fresh
source revision while preserving the active flow accounting and immutable
evidence.

Own ONLY new metadata/fix1/ sources/evidence and appended task5b4 reports. You
are not alone; no reverts/old bound inputs/product edits/subagents/refs/commits/
pushes/downloads/external CLI. Preserve ALL original/current/recovery sources,
manifests,receipts,binaries,Rootrestorationrecord and the unproved historical
binary mismatch. New frozen subject /tmp/uwz-task5b4-fix1-frozen and fresh
build outputs /tmp/uwz-task5b4-fix1-{debug,release}/profile. Current base is
frozen-v2/currentmanifest4c24ae20...; originalmanifest5a47148b... stays historical.

Remove genuinely unused credit hash/argument, helpers/API entries, impossible
branch and partial_done state. Keep all ACTIVE metadata case orchestration,
wire/public flow checks, response accounting, post-case zeroactive check and
process guards. Root notes get_metrics is used by the post-case zeroactive
guard even though its API-map entry is unused by cases.execute; preserve its
used functionality. Do not erase live invariants merely because similarly
named inactive helpers are removed. Do not broaden into arbitrary refactoring.

Keep all original metadata/legacy/helper/Issue/allocator/trailer/pause/encoded
header/ownership/process assertions and exact case/profile/capacity requirements.
Both current source APIs/checks are unchanged by this cleanup. No native
behavioral red is fabricated for dead-code removal. Add focused pure data/AST/
interface checks for amended caller/callee contract as needed, and actual
fixedZig0.16 Debug+ReleaseSafe COMPILE ONLY(-j2) because profile.zig changes.
Reuse existing warm compiler caches. Profileformat and complete before/after/
current maps/source trees/sixreviewedarchives must pass. No wider/full/native
test or stopped/fault/race/resource/kernel/fd/panic/leak/crash probe.

Create coherent NEW current manifest binding the actual two new builds/receipts/
recipes and complete actual source/tool/runtime closure. Use exact current
binary hashes from real builds, not any historical value. Do not reintroduce
missingarchives/locale/purecoverage bugs. Historical identities remain evidence,
not unrelated binary dependencies. Freeze all runtime modules with exact loaded
path/hash checks and keepinertimports/explicit--run. No candidate/server/client/
socket/certificate/binaryhelp execution or runflag use is permitted here.

Append exact fix paths,actualcommands/rawoutcomes,histories/hashes,covering tests,
both compile receipts and scope to task-5b4-report.md (use a scopedfixreport
pointer if any report is bound; do not overwrite bound bytes). Return coherent
DONE for scoped re-review. Root reads actual report/commands/results, generates
frozen-v2-to-fix1 diff and asks original reviewers to judge the finding/fix only.
No later exact host release is granted. M2/all40 IDs/fullmatrix/H3/multipart/
allquality/platform/physical/maintainedpublication/adoption/originalgoal remain.
