# Task5b4 initial source and current-build review
Root base/head30f27ab80f0471437c34adcdf7b2d42f58227b74; product and ordinary dependency pins unchanged. These are new test-only files, not production adoption.
Current manifest /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata/recovery-2026-10-29/current/manifest.json, SHA4c24ae205154e1ffda807e2d10083488051ce13a9544f776748a04659f1852ea; 2437current inputs/6trees.
Temporary artifacts were lost during user pause. Source/override/client/frozen bytes were restored exactly; two actual fresh compile-only replays passed but did not match historical binary hashes. Reason unproved. Current manifest binds the two ACTUAL new artifacts; original manifest/receipts and mismatch remain preserved. No native metadata run has occurred.

## /tmp/uwz-task5b4-frozen-v2/build_closure.py (39 lines; SHAb67b37b2b0d7c3111980ad4c9f59fdafff26e4b7f35b0c6ba33737b357b5592c)
--- /dev/null
+++ /tmp/uwz-task5b4-frozen-v2/build_closure.py
@@ -0,0 +1,39 @@
+"""Validate current direct build inputs using caller-provided receipt maps."""
+ARCHIVES = tuple('/workspaces/uWebZockets/zig-out/lib/' + name for name in (
+    'libuWebZockets.a', 'libssl.a', 'libcrypto.a', 'liblsquic.a', 'libdeflate.a', 'libz.a'))
+
+
+def argv_inputs(argv):
+    if not argv or not argv[0].startswith('/'):
+        raise ValueError('missing compiler')
+    modules = [arg.split('=', 1)[1] for arg in argv if arg.startswith('-M') and '=' in arg]
+    archives = [arg for arg in argv if arg.endswith('.a')]
+    if len(archives) != len(ARCHIVES) or set(archives) != set(ARCHIVES):
+        raise ValueError('archive list differs')
+    if len(modules) != 6 or len(set(modules)) != len(modules):
+        raise ValueError('module input list differs')
+    return set(modules + archives + [argv[0]])
+
+
+def validate_receipts(receipts, commands, current, approved_archives):
+    merged = {}
+    if len(receipts) != 2 or len(commands) != 2:
+        raise ValueError('both build receipts are required')
+    for receipt, command, mode in zip(receipts, commands, ('Debug', 'ReleaseSafe')):
+        before = receipt['input_sha256']
+        if receipt['optimization'] != mode or receipt['exit_status'] != 0 or not receipt['inputs_unchanged']:
+            raise ValueError('build receipt status differs')
+        if receipt['argv'] != command['argv'] or before != command['input_sha256']:
+            raise ValueError('build command receipt differs')
+        if set(before) != argv_inputs(receipt['argv']) or before != receipt['input_after']:
+            raise ValueError('build input map is incomplete or changed')
+        for path, value in before.items():
+            if current.get(path) != value or (path in merged and merged[path] != value):
+                raise ValueError('current or cross-build input differs: ' + path)
+            merged[path] = value
+    if set(approved_archives) != set(ARCHIVES):
+        raise ValueError('reviewed archive map is incomplete')
+    for path in ARCHIVES:
+        if merged[path] != approved_archives[path]:
+            raise ValueError('archive differs from reviewed identity: ' + path)
+    return merged

## /tmp/uwz-task5b4-frozen-v2/cases.py (52 lines; SHAd823af892f7ee77377cdd2d22686971e1cffd1c57788ca924c47efaf4ab53585)
--- /dev/null
+++ /tmp/uwz-task5b4-frozen-v2/cases.py
@@ -0,0 +1,52 @@
+"""Bounded metadata case; import performs no I/O."""
+CASES = ('metadata_helpers', 'shutdown_idle')
+TAGS = ('metadata_helpers',) + tuple('spare_%02d' % i for i in range(31))
+GROUPS = {'metadata_helpers': ('metadata_helpers',)}
+
+
+def selected_tags(cases):
+    return {'metadata_helpers'} if 'metadata_helpers' in cases else set()
+
+
+def expected(tag, selected, empty_hash, _credit_hash):
+    touched = tag in selected
+    return {'tag': tag, 'middleware': int(touched), 'attempts': int(touched), 'begin': int(touched),
+            'end': int(touched), 'cancel': 0, 'failure': 0, 'accepted': 32 if touched else 0,
+            'sha256': '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5' if touched else empty_hash,
+            'active': False, 'paused': False, 'reason': 'none', 'metadata_middleware': int(touched),
+            'helpers_begin': int(touched), 'helpers_end': int(touched), 'metadata_begin': int(touched),
+            'metadata_end': int(touched), 'errors': 0}
+
+
+def verify_record(actual, expected_record):
+    for key, value in expected_record.items():
+        if actual.get(key) != value:
+            raise ValueError('record ' + expected_record['tag'] + ' field ' + key + ' differs')
+    if set(actual) != set(expected_record) | {'chunks', 'max_span'}:
+        raise ValueError('record fields differ')
+    chunks, span = actual['chunks'], actual['max_span']
+    if not isinstance(chunks, int) or not isinstance(span, int) or chunks < 0 or not 0 <= span <= 8192:
+        raise ValueError('chunk statistics out of bounds')
+    if expected_record['accepted'] == 0 and (chunks or span):
+        raise ValueError('unexpected empty record chunk')
+    if expected_record['accepted'] and (not chunks or not span):
+        raise ValueError('missing accepted chunk')
+
+
+def execute(api, case):
+    if case != 'metadata_helpers':
+        raise ValueError('unsupported case')
+    tag = case
+    target = '/meta/metadata_helpers/' + '/'.join('a%02d' % i for i in range(1, 17)) + '?q=alpha&n=17'
+    headers = [('x-mode', 'begin_paused')] + [('x-h%02d' % i, 'v%02d' % i) for i in range(63)]
+    stream = api['start']('meta', tag, 32, target, headers)
+    for offset in (0, 16):
+        api['send'](stream, 32, offset, 16, False)
+        if offset == 16:
+            api['trailers'](stream, [('x-h62', 'changed'), ('x-trailer-only', 'discarded')])
+        observed = api['status'](tag)
+        if (observed['begin'], observed['accepted'], observed['chunks'], observed['end'], observed['cancel'], observed['paused']) != (1, 0, 0, 0, 0, True):
+            raise ValueError('paused barrier differs')
+        api['pending'](stream)
+    api['resume'](tag)
+    api['finish'](stream)

## /tmp/uwz-task5b4-frozen-v2/flow_ledger.py (81 lines; SHAf71787b310255802111876b66eb31ee1a5d341001ea5289e8745dd224465feff)
--- /dev/null
+++ /tmp/uwz-task5b4-frozen-v2/flow_ledger.py
@@ -0,0 +1,81 @@
+"""Caller-owned HTTP/2 outbound credit accounting; no transport effects."""
+from dataclasses import dataclass, field
+
+INITIAL = 65535
+MAX_STREAMS = 8
+
+
+@dataclass
+class StreamCredit:
+    window: int
+    sent: int = 0
+    refunded: int = 0
+    open: bool = True
+
+
+@dataclass
+class FlowLedger:
+    connection: int = INITIAL
+    initial_stream: int = INITIAL
+    sent: int = 0
+    refunded: int = 0
+    streams: dict[int, StreamCredit] = field(default_factory=dict)
+    unchanged_settings: bool = True
+
+
+def open_stream(ledger: FlowLedger, stream_id: int) -> None:
+    if stream_id in ledger.streams or len(ledger.streams) >= MAX_STREAMS:
+        raise ValueError('duplicate stream or stream capacity exceeded')
+    ledger.streams[stream_id] = StreamCredit(ledger.initial_stream)
+
+
+def send_data(ledger: FlowLedger, stream_id: int, payload: int, padding: int | None, max_frame: int, finished: bool = False) -> int:
+    stream = ledger.streams[stream_id]
+    if not stream.open or payload < 0 or padding is not None and not 0 <= padding <= 255:
+        raise ValueError('invalid DATA request')
+    flow = payload + (padding + 1 if padding is not None else 0)
+    if flow > min(ledger.connection, stream.window, max_frame):
+        raise ValueError('DATA exceeds public credit or frame limit')
+    ledger.connection -= flow
+    ledger.sent += flow
+    stream.window -= flow
+    stream.sent += flow
+    stream.open = not finished
+    return flow
+
+
+def receive_batch(ledger: FlowLedger, updates: list[tuple[int, int]], new_initial: int | None = None) -> None:
+    if new_initial is not None:
+        if not 0 <= new_initial <= 2147483647:
+            raise ValueError('invalid initial window')
+        change = new_initial - ledger.initial_stream
+        ledger.initial_stream = new_initial
+        ledger.unchanged_settings = ledger.unchanged_settings and change == 0
+        for stream in ledger.streams.values():
+            if stream.open:
+                stream.window += change
+    for stream_id, delta in updates:
+        if delta <= 0:
+            raise ValueError('invalid window update')
+        if stream_id == 0:
+            ledger.connection += delta
+            ledger.refunded += delta
+        else:
+            stream = ledger.streams[stream_id]
+            stream.window += delta
+            stream.refunded += delta
+    if ledger.unchanged_settings:
+        if not 0 <= ledger.connection <= INITIAL or ledger.refunded > ledger.sent:
+            raise ValueError('invalid connection refund')
+        for stream in ledger.streams.values():
+            if stream.refunded > stream.sent or stream.open and not 0 <= stream.window <= INITIAL:
+                raise ValueError('invalid stream refund')
+
+
+def check_public(ledger: FlowLedger, connection_window: int, stream_windows: dict[int, int]) -> None:
+    if connection_window != ledger.connection:
+        raise ValueError('connection window differs')
+    for stream_id, public_window in stream_windows.items():
+        stream = ledger.streams[stream_id]
+        if not stream.open or public_window != min(ledger.connection, stream.window):
+            raise ValueError('stream minimum differs or stream closed')

## /tmp/uwz-task5b4-frozen-v2/freeze.py (88 lines; SHA7dee88f48c69f3d97e74268f210c9f3477a73cc7abfbd809926e5bcc860516e6)
--- /dev/null
+++ /tmp/uwz-task5b4-frozen-v2/freeze.py
@@ -0,0 +1,88 @@
+"""Freeze the actual current test-only inputs; never starts native code."""
+import hashlib
+import json
+from pathlib import Path
+import shutil
+import build_closure
+
+HERE = Path(__file__).resolve().parent
+HIST = HERE.parent / 'credit/fix1/review-manifest-v2.json'
+ADMISSION = HERE.parent / 'admission/fix1/review-manifest.json'
+FROZEN = Path('/tmp/uwz-task5b4-frozen-v2')
+OLD_FROZEN = '/tmp/uwz-task5b3-fix1-frozen-v2'
+NAMES = ('profile.zig', 'prepare.py', 'run_live.py', 'cases.py', 'wire.py', 'raw_observer.py', 'flow_ledger.py', 'pure_codec_checks.py', 'build_closure.py', 'freeze.py')
+
+
+def digest(path):
+    h = hashlib.sha256()
+    with Path(path).open('rb') as f:
+        while data := f.read(8192):
+            h.update(data)
+    return h.hexdigest()
+
+
+def inventory(root):
+    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file()}
+
+
+def main():
+    base = json.loads(HIST.read_text())
+    expected_hist = '952c497fb60c4af72f1d8024e142c20ad82c65a3d9ca2de91dc47cb628d00d94'
+    if digest(HIST) != expected_hist:
+        raise ValueError('historical reviewed manifest changed')
+    if digest(ADMISSION) != base['historical_manifest_sha256'][str(ADMISSION)]:
+        raise ValueError('reviewed admission manifest changed')
+    receipts, commands = [], []
+    for mode in ('debug', 'release'):
+        label = 'fixture-' + mode + '-final'
+        receipts.append(json.loads((HERE / (label + '.json')).read_text()))
+        commands.append(json.loads((HERE / (label + '.command.json')).read_text()))
+    paths = set().union(*(build_closure.argv_inputs(r['argv']) for r in receipts))
+    current = {path: digest(path) for path in paths}
+    reviewed = json.loads(ADMISSION.read_text())['inputs']
+    merged = build_closure.validate_receipts(receipts, commands, current, {p: reviewed[p] for p in build_closure.ARCHIVES})
+    for mode, receipt in zip(('debug', 'release'), receipts):
+        if digest('/tmp/uwz-task5b4-final-' + mode + '/profile') != receipt['binary_sha256']:
+            raise ValueError('binary differs: ' + mode)
+        for name, value in receipt['fixture_before'].items():
+            if digest(HERE / name) != value or receipt['fixture_after'][name] != value:
+                raise ValueError('fixture or recipe changed: ' + name)
+    trees = {path: values for path, values in base['trees'].items() if path != OLD_FROZEN}
+    for path, values in trees.items():
+        if inventory(Path(path)) != values:
+            raise ValueError('reviewed tree changed: ' + path)
+    inputs = {p: h for p, h in base['inputs'].items() if not (p.startswith(OLD_FROZEN + '/') or p.startswith('/tmp/uwz-task5b3-') or '/integration-owned/credit/' in p)}
+    for path, value in inputs.items():
+        if digest(path) != value:
+            raise ValueError('current inherited dependency changed: ' + path)
+    if FROZEN.exists():
+        raise ValueError('destination already exists')
+    FROZEN.mkdir(mode=0o700)
+    for name in NAMES:
+        shutil.copyfile(HERE / name, FROZEN / name)
+    trees[str(FROZEN)] = inventory(FROZEN)
+    inputs.update(merged)
+    for mode in ('debug', 'release'):
+        label = 'fixture-' + mode + '-final'
+        for suffix in ('.json', '.command.json', '.log', '-source-inputs.json', '-source-after.json'):
+            path = str(HERE / (label + suffix))
+            inputs[path] = digest(path)
+        binary = '/tmp/uwz-task5b4-final-' + mode + '/profile'
+        inputs[binary] = digest(binary)
+    for name, value in trees[str(FROZEN)].items():
+        inputs[str(FROZEN / name)] = value
+    manifest = dict(base)
+    manifest.update(state='ready-for-independent-review', trees=trees, tree_counts={k: len(v) for k, v in trees.items()}, inputs=inputs,
+                    binary='/tmp/uwz-task5b4-final-release/profile', runner=str(FROZEN/'run_live.py'), cases=str(FROZEN/'cases.py'), wire=str(FROZEN/'wire.py'), raw=str(FROZEN/'raw_observer.py'), flow=str(FROZEN/'flow_ledger.py'),
+                    historical_manifest_sha256={str(HIST): digest(HIST), str(ADMISSION): digest(ADMISSION)}, build_input_receipts=['fixture-debug-final.json', 'fixture-release-final.json'], scope='current actual build and runtime closure; prior proofs linked by identity')
+    output = HERE / 'review-manifest-v2.json'
+    if output.exists():
+        raise ValueError('manifest already exists')
+    output.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
+    print('both builds: 13 current inputs match before, after and reviewed archives')
+    print('frozen files:', len(trees[str(FROZEN)]))
+    print('manifest sha256:', digest(output))
+
+
+if __name__ == '__main__':
+    main()

## /tmp/uwz-task5b4-frozen-v2/prepare.py (79 lines; SHA3d944c3f70e123386177b070230df2b09a16f10184b9ded272de95a5bb25829e)
--- /dev/null
+++ /tmp/uwz-task5b4-frozen-v2/prepare.py
@@ -0,0 +1,79 @@
+"""Explicit compile-only replay. Never starts a server or client."""
+import argparse
+import hashlib
+import json
+import subprocess
+from pathlib import Path
+
+ROOT = Path('/workspaces/uWebZockets')
+HERE = Path(__file__).resolve().parent
+ZIG = '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig'
+
+
+def digest(path):
+    result = hashlib.sha256()
+    with Path(path).open('rb') as source:
+        while data := source.read(8192):
+            result.update(data)
+    return result.hexdigest()
+
+
+def main():
+    parser = argparse.ArgumentParser()
+    parser.add_argument('--source', type=Path, default=Path('/tmp/uwz-task4d-fix1-frozen'))
+    parser.add_argument('--output', type=Path, default=Path('/tmp/uwz-task5a-compile'))
+    parser.add_argument('--record', default='compile')
+    parser.add_argument('--optimization', choices=['Debug', 'ReleaseSafe'], required=True)
+    parser.add_argument('--cache-root', type=Path)
+    parser.add_argument('--expected-source-digest', default='fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de')
+    args = parser.parse_args()
+    if args.output.exists() and any(args.output.iterdir()):
+        raise RuntimeError('select a fresh output/cache directory')
+    args.output.mkdir(parents=True, exist_ok=True)
+    if (HERE / (args.record + '.json')).exists():
+        raise RuntimeError('compile record already exists; select a fresh record label')
+    cache_root = args.output if args.cache_root is None else args.cache_root
+    if args.cache_root is not None and not ((cache_root / 'cache').is_dir() and (cache_root / 'global').is_dir()):
+        raise RuntimeError('explicit cache reuse requires this task existing compiler cache directories')
+    argv = [ZIG, 'build-exe', '-O' + args.optimization, '--dep', 'uWebZockets', '-Mroot=' + str(HERE / 'profile.zig'), '-O' + args.optimization, '--dep', 'c', '--dep', 'xev', '--dep', 'zslay', '-MuWebZockets=' + str(args.source / 'src/root.zig'), '-Mc=' + str(ROOT / '.uwz-work/evidence/h1-transport/r2/c-native.zig'), '--dep', 'xev_impl', '-Mxev=' + str(args.source / 'src/core/xev.zig'), '-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig']
+    seed = json.loads((ROOT / '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json').read_text())['argv']
+    zslay = next(value.split('=', 1)[1] for value in seed if value.startswith('-Mzslay='))
+    argv += ['-Mzslay=' + str(ROOT / zslay), '-lc++', '-lc']
+    argv += [str(ROOT / 'zig-out/lib' / name) for name in ('libuWebZockets.a', 'libssl.a', 'libcrypto.a', 'liblsquic.a', 'libdeflate.a', 'libz.a')]
+    argv += ['-j2', '--cache-dir', str(cache_root / 'cache'), '--global-cache-dir', str(cache_root / 'global'), '-femit-bin=' + str(args.output / 'profile')]
+    inputs = [Path(value.split('=', 1)[1]) for value in argv if value.startswith('-M')]
+    inputs += [Path(value) for value in argv if value.endswith('.a')]
+    inputs += [Path(ZIG)]
+    source_inputs = {str(path.relative_to(args.source)): digest(path) for path in sorted(args.source.rglob('*')) if path.is_file()}
+    (HERE / (args.record + '-source-inputs.json')).write_text(json.dumps(source_inputs, indent=2) + '\n')
+    source_digest = hashlib.sha256(json.dumps(list(source_inputs.items())).encode()).hexdigest()
+    if source_digest != args.expected_source_digest:
+        raise RuntimeError('combined source digest differs from Root supplied coherent source')
+    override_manifest = ROOT / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json'
+    override = json.loads(override_manifest.read_text())
+    override_inputs = {name: digest(Path(override['path']) / name) for name in override['files_sha256']}
+    if override_inputs != override['files_sha256']:
+        raise RuntimeError('c223 override differs from immutable input manifest')
+    fixture_inputs = {path.name: digest(path) for path in (HERE / 'profile.zig', HERE / 'prepare.py')}
+    record = {'qualification': 'H2 fixture compile only; no runtime claim', 'expected_source_digest': args.expected_source_digest, 'fixture_before': fixture_inputs, 'override_manifest_sha256': digest(override_manifest), 'override_before': override_inputs, 'source_tree_sha256': hashlib.sha256(json.dumps(list(source_inputs.items())).encode()).hexdigest(), 'source_tree_encoding': 'sha256(json.dumps(relative_path, file_sha256 pairs in sorted pathlib path order))', 'argv': argv, 'cwd': str(args.source), 'optimization': args.optimization, 'explicit_environment': {}, 'input_sha256': {str(path): digest(path) for path in inputs}, 'execution': 'compile only; no server/client execution'}
+    (HERE / (args.record + '.command.json')).write_text(json.dumps(record, indent=2) + '\n')
+    with (HERE / (args.record + '.log')).open('wb') as log:
+        result = subprocess.run(argv, cwd=args.source, stdout=log, stderr=subprocess.STDOUT)
+    record['exit_status'] = result.returncode
+    record['input_after'] = {str(path): digest(path) for path in inputs}
+    record['fixture_after'] = {name: digest(HERE / name) for name in fixture_inputs}
+    source_after = {str(path.relative_to(args.source)): digest(path) for path in sorted(args.source.rglob('*')) if path.is_file()}
+    (HERE / (args.record + '-source-after.json')).write_text(json.dumps(source_after, indent=2) + '\n')
+    record['source_after_sha256'] = hashlib.sha256(json.dumps(list(source_after.items())).encode()).hexdigest()
+    record['override_after'] = {name: digest(Path(override['path']) / name) for name in override_inputs}
+    record['inputs_unchanged'] = record['input_after'] == record['input_sha256'] and record['fixture_after'] == fixture_inputs and source_after == source_inputs and record['override_after'] == override_inputs
+    if result.returncode == 0:
+        record['binary_sha256'] = digest(args.output / 'profile')
+    (HERE / (args.record + '.json')).write_text(json.dumps(record, indent=2) + '\n')
+    print((HERE / (args.record + '.log')).read_text(), end='')
+    print('Exit status:', result.returncode)
+    raise SystemExit(result.returncode if record['inputs_unchanged'] else 1)
+
+
+if __name__ == '__main__':
+    main()

## /tmp/uwz-task5b4-frozen-v2/profile.zig (480 lines; SHAc12ecc91a886f015f46bc809284666d46195d786536a28a8de49e548d6fe85b1)
--- /dev/null
+++ /tmp/uwz-task5b4-frozen-v2/profile.zig
@@ -0,0 +1,480 @@
+const std = @import("std");
+const uz = @import("uWebZockets");
+const Hash = std.crypto.hash.sha2.Sha256;
+const config: uz.ServerConfig = .{
+    .max_connections = 8,
+    .stream_request_bodies = true,
+    .max_request_line_size = 512,
+    .max_header_size = 4096,
+    .max_header_count = 80,
+    .max_body_size = 256,
+    .max_h2_body_size = 4096,
+    .max_h2_header_block_size = 8192,
+    .max_h2_response_header_size = 4096,
+    .max_h2_response_header_count = 32,
+    .max_route_params = 24,
+    .write_queue_size = 65536,
+    .enable_dev_log = false,
+};
+const tags = [_][]const u8{
+    "metadata_helpers",
+    "spare_00",
+    "spare_01",
+    "spare_02",
+    "spare_03",
+    "spare_04",
+    "spare_05",
+    "spare_06",
+    "spare_07",
+    "spare_08",
+    "spare_09",
+    "spare_10",
+    "spare_11",
+    "spare_12",
+    "spare_13",
+    "spare_14",
+    "spare_15",
+    "spare_16",
+    "spare_17",
+    "spare_18",
+    "spare_19",
+    "spare_20",
+    "spare_21",
+    "spare_22",
+    "spare_23",
+    "spare_24",
+    "spare_25",
+    "spare_26",
+    "spare_27",
+    "spare_28",
+    "spare_29",
+    "spare_30",
+};
+const Record = struct {
+    token: ?uz.BodyControl = null,
+    hash: Hash = Hash.init(.{}),
+    bytes: u64 = 0,
+    chunks: u32 = 0,
+    max_span: usize = 0,
+    middleware: u32 = 0,
+    attempts: u32 = 0,
+    begins: u32 = 0,
+    ends: u32 = 0,
+    cancels: u32 = 0,
+    failures: u32 = 0,
+    errors: u32 = 0,
+    active: bool = false,
+    paused: bool = false,
+    reason: ?uz.BodyCancelReason = null,
+    metadata_middleware: u32 = 0,
+    helpers_begin: u32 = 0,
+    helpers_end: u32 = 0,
+    metadata_begin: u32 = 0,
+    metadata_end: u32 = 0,
+    partial_done: bool = false,
+};
+const Slot = struct { record: ?*Record = null, owner: *State = undefined, index: usize = 0 };
+const State = struct {
+    slots: [2]Slot = [_]Slot{.{}} ** 2,
+    records: [32]Record = [_]Record{.{}} ** 32,
+    buffered_middleware: u32 = 0,
+    errors: u32 = 0,
+};
+fn tag_index(tag: []const u8) ?usize {
+    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
+    return null;
+}
+fn account_body_head(state: *State, request: *const uz.Request) void {
+    const tag = request.get_param("tag") orelse {
+        state.errors += 1;
+        return;
+    };
+    const index = tag_index(tag) orelse {
+        state.errors += 1;
+        return;
+    };
+    if (index != 0) {
+        state.errors += 1;
+        return;
+    }
+    state.records[index].middleware += 1;
+    if (!legacy_metadata_matches(request)) {
+        state.records[index].errors += 1;
+        return;
+    }
+    state.records[index].metadata_middleware += 1;
+}
+fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
+    const state: *State = @ptrCast(@alignCast(context));
+    if (std.mem.startsWith(u8, request.path, "/meta/")) {
+        account_body_head(state, request);
+    } else state.buffered_middleware += 1;
+    response.append_header("X-Middleware", "retained") catch {
+        state.errors += 1;
+        return .stop;
+    };
+    return .continue_dispatch;
+}
+const Pair = struct { name: []const u8, value: []const u8 };
+const Payload = union { value: []const u8, count: u64 };
+const expected_path = "/meta/metadata_helpers/a01/a02/a03/a04/a05/a06/a07/a08/a09/a10/a11/a12/a13/a14/a15/a16";
+const expected_target = expected_path ++ "?q=alpha&n=17";
+const expected_headers = [_]Pair{
+    .{ .name = "content-length", .value = "32" },
+    .{ .name = "x-mode", .value = "begin_paused" },
+    .{ .name = "x-h00", .value = "v00" },
+    .{ .name = "x-h01", .value = "v01" },
+    .{ .name = "x-h02", .value = "v02" },
+    .{ .name = "x-h03", .value = "v03" },
+    .{ .name = "x-h04", .value = "v04" },
+    .{ .name = "x-h05", .value = "v05" },
+    .{ .name = "x-h06", .value = "v06" },
+    .{ .name = "x-h07", .value = "v07" },
+    .{ .name = "x-h08", .value = "v08" },
+    .{ .name = "x-h09", .value = "v09" },
+    .{ .name = "x-h10", .value = "v10" },
+    .{ .name = "x-h11", .value = "v11" },
+    .{ .name = "x-h12", .value = "v12" },
+    .{ .name = "x-h13", .value = "v13" },
+    .{ .name = "x-h14", .value = "v14" },
+    .{ .name = "x-h15", .value = "v15" },
+    .{ .name = "x-h16", .value = "v16" },
+    .{ .name = "x-h17", .value = "v17" },
+    .{ .name = "x-h18", .value = "v18" },
+    .{ .name = "x-h19", .value = "v19" },
+    .{ .name = "x-h20", .value = "v20" },
+    .{ .name = "x-h21", .value = "v21" },
+    .{ .name = "x-h22", .value = "v22" },
+    .{ .name = "x-h23", .value = "v23" },
+    .{ .name = "x-h24", .value = "v24" },
+    .{ .name = "x-h25", .value = "v25" },
+    .{ .name = "x-h26", .value = "v26" },
+    .{ .name = "x-h27", .value = "v27" },
+    .{ .name = "x-h28", .value = "v28" },
+    .{ .name = "x-h29", .value = "v29" },
+    .{ .name = "x-h30", .value = "v30" },
+    .{ .name = "x-h31", .value = "v31" },
+    .{ .name = "x-h32", .value = "v32" },
+    .{ .name = "x-h33", .value = "v33" },
+    .{ .name = "x-h34", .value = "v34" },
+    .{ .name = "x-h35", .value = "v35" },
+    .{ .name = "x-h36", .value = "v36" },
+    .{ .name = "x-h37", .value = "v37" },
+    .{ .name = "x-h38", .value = "v38" },
+    .{ .name = "x-h39", .value = "v39" },
+    .{ .name = "x-h40", .value = "v40" },
+    .{ .name = "x-h41", .value = "v41" },
+    .{ .name = "x-h42", .value = "v42" },
+    .{ .name = "x-h43", .value = "v43" },
+    .{ .name = "x-h44", .value = "v44" },
+    .{ .name = "x-h45", .value = "v45" },
+    .{ .name = "x-h46", .value = "v46" },
+    .{ .name = "x-h47", .value = "v47" },
+    .{ .name = "x-h48", .value = "v48" },
+    .{ .name = "x-h49", .value = "v49" },
+    .{ .name = "x-h50", .value = "v50" },
+    .{ .name = "x-h51", .value = "v51" },
+    .{ .name = "x-h52", .value = "v52" },
+    .{ .name = "x-h53", .value = "v53" },
+    .{ .name = "x-h54", .value = "v54" },
+    .{ .name = "x-h55", .value = "v55" },
+    .{ .name = "x-h56", .value = "v56" },
+    .{ .name = "x-h57", .value = "v57" },
+    .{ .name = "x-h58", .value = "v58" },
+    .{ .name = "x-h59", .value = "v59" },
+    .{ .name = "x-h60", .value = "v60" },
+    .{ .name = "x-h61", .value = "v61" },
+    .{ .name = "x-h62", .value = "v62" },
+    .{ .name = "host", .value = "localhost" },
+};
+const expected_params = [_]Pair{
+    .{ .name = "tag", .value = "metadata_helpers" },
+    .{ .name = "p01", .value = "a01" },
+    .{ .name = "p02", .value = "a02" },
+    .{ .name = "p03", .value = "a03" },
+    .{ .name = "p04", .value = "a04" },
+    .{ .name = "p05", .value = "a05" },
+    .{ .name = "p06", .value = "a06" },
+    .{ .name = "p07", .value = "a07" },
+    .{ .name = "p08", .value = "a08" },
+    .{ .name = "p09", .value = "a09" },
+    .{ .name = "p10", .value = "a10" },
+    .{ .name = "p11", .value = "a11" },
+    .{ .name = "p12", .value = "a12" },
+    .{ .name = "p13", .value = "a13" },
+    .{ .name = "p14", .value = "a14" },
+    .{ .name = "p15", .value = "a15" },
+    .{ .name = "p16", .value = "a16" },
+};
+fn optional_equal(actual: ?[]const u8, expected: []const u8) bool {
+    return if (actual) |a| std.mem.eql(u8, a, expected) else false;
+}
+fn metadata_matches(request: *const uz.StreamingRequest) bool {
+    if (!std.mem.eql(u8, request.method, "POST") or !std.mem.eql(u8, request.target, expected_target) or
+        !std.mem.eql(u8, request.path, expected_path) or !std.mem.eql(u8, request.query, "q=alpha&n=17") or request.protocol.len != 0) return false;
+    if (request.headers.names.len != 64 or request.headers.extra_names.len != 2 or request.params.names.len != 16 or request.params.extra_names.len != 1) return false;
+    var entries = request.headers.entries();
+    for (expected_headers) |expected| {
+        const entry = entries.next() orelse return false;
+        if (!std.ascii.eqlIgnoreCase(entry.name, expected.name) or !std.mem.eql(u8, entry.value, expected.value) or !optional_equal(request.headers.get(expected.name), expected.value)) return false;
+    }
+    if (entries.next() != null or request.headers.get("x-trailer-only") != null or request.params.get("P16") != null) return false;
+    for (expected_params, 0..) |expected, index| {
+        const names = if (index < 16) request.params.names else request.params.extra_names;
+        const values = if (index < 16) request.params.values else request.params.extra_values;
+        const offset = if (index < 16) index else index - 16;
+        if (!std.mem.eql(u8, names[offset], expected.name) or !std.mem.eql(u8, values[offset], expected.value) or !optional_equal(request.params.get(expected.name), expected.value)) return false;
+    }
+    return true;
+}
+fn legacy_metadata_matches(request: *const uz.Request) bool {
+    if (!metadata_matches(&uz.StreamingRequest.from_request(request))) return false;
+    var entries = request.header_entries();
+    for (expected_headers) |expected| {
+        const entry = entries.next() orelse return false;
+        if (!std.ascii.eqlIgnoreCase(entry.name, expected.name) or !std.mem.eql(u8, entry.value, expected.value) or !optional_equal(request.get_header(expected.name), expected.value)) return false;
+    }
+    if (entries.next() != null) return false;
+    for (expected_params) |expected| if (!optional_equal(request.get_param(expected.name), expected.value)) return false;
+    return request.get_param("P16") == null;
+}
+fn helpers_match(request: *const uz.StreamingRequest) bool {
+    if (request.text().len != 0 or request.bytes().len != 0) return false;
+    var storage: [0]u8 = .{};
+    var allocator = std.heap.FixedBufferAllocator.init(&storage);
+    const memory = allocator.allocator();
+    var issue = uz.schema.Issue{ .field = "untouched", .kind = .too_deep };
+    const pointer = issue.field.ptr;
+    const length = issue.field.len;
+    const json: uz.BodyReadError!std.json.Parsed(Payload) = request.json(Payload, memory);
+    const validated: uz.BodyReadError!std.json.Parsed(Payload) = request.validate_json(Payload, memory);
+    const detailed: uz.BodyReadError!std.json.Parsed(Payload) = request.validate_json_detailed(Payload, memory, &issue);
+    const form: uz.BodyReadError!uz.query.QueryParams = request.form();
+    const multipart: uz.BodyReadError!uz.multipart.Parser = request.multipart();
+    if (json != error.BodyNotBuffered or validated != error.BodyNotBuffered or detailed != error.BodyNotBuffered or form != error.BodyNotBuffered or multipart != error.BodyNotBuffered) return false;
+    if (issue.field.ptr != pointer or issue.field.len != length or !std.mem.eql(u8, issue.field, "untouched") or issue.kind != .too_deep or allocator.end_index != 0) return false;
+    const query = request.query_params() catch return false;
+    const query_two = request.query_params_of(2) catch return false;
+    return optional_equal(query.get("q"), "alpha") and optional_equal(query.get("n"), "17") and optional_equal(query_two.get("q"), "alpha") and optional_equal(query_two.get("n"), "17");
+}
+fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
+    const state: *State = @ptrCast(@alignCast(context));
+    const tag = request.params.get("tag") orelse {
+        state.errors += 1;
+        return error.MissingTag;
+    };
+    const index = tag_index(tag) orelse {
+        state.errors += 1;
+        return error.InvalidTag;
+    };
+    if (index != 0) {
+        state.errors += 1;
+        return error.SpareTag;
+    }
+    const record = &state.records[index];
+    record.attempts += 1;
+    if (!metadata_matches(request)) {
+        record.errors += 1;
+        record.failures += 1;
+        return error.MetadataMismatch;
+    }
+    record.metadata_begin += 1;
+    if (!helpers_match(request)) {
+        record.errors += 1;
+        record.failures += 1;
+        return error.HelpersMismatch;
+    }
+    record.helpers_begin += 1;
+    if (record.attempts != 1 or record.middleware != 1) {
+        record.errors += 1;
+        record.failures += 1;
+        return error.DuplicateTag;
+    }
+    for (&state.slots) |*slot| {
+        if (slot.record != null) continue;
+        slot.* = .{ .owner = state, .record = record, .index = index };
+        record.token = token;
+        record.begins += 1;
+        record.active = true;
+        record.paused = true;
+        return .{ .context = slot, .readiness = if (record.paused) .paused else .ready };
+    }
+    record.failures += 1;
+    record.errors += 1;
+    return error.NoFixtureSlot;
+}
+fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
+    const slot: *Slot = @ptrCast(@alignCast(context));
+    const record = slot.record orelse return error.MissingRecord;
+    record.max_span = @max(record.max_span, input.len);
+    record.chunks += 1;
+    const consumed = input.len;
+    record.hash.update(input[0..consumed]);
+    record.bytes += consumed;
+    return .{ .consumed = consumed, .readiness = if (record.paused) .paused else .ready };
+}
+fn format_record(record: *const Record, tag: []const u8, output: []u8) ![]const u8 {
+    var copy = record.hash;
+    var digest: [Hash.digest_length]u8 = undefined;
+    copy.final(&digest);
+    const hex = std.fmt.bytesToHex(digest, .lower);
+    const reason = if (record.reason) |value| @tagName(value) else "none";
+    return std.fmt.bufPrint(output, "{{\"tag\":\"{s}\",\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"accepted\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":\"{s}\",\"metadata_middleware\":{d},\"helpers_begin\":{d},\"helpers_end\":{d},\"metadata_begin\":{d},\"metadata_end\":{d},\"errors\":{d}}}", .{ tag, record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.metadata_middleware, record.helpers_begin, record.helpers_end, record.metadata_begin, record.metadata_end, record.errors });
+}
+fn end(context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response) !void {
+    const slot: *Slot = @ptrCast(@alignCast(context));
+    const record = slot.record orelse return error.MissingRecord;
+    if (!metadata_matches(request)) {
+        record.errors += 1;
+        return error.MetadataMismatch;
+    }
+    record.metadata_end += 1;
+    if (!helpers_match(request)) {
+        record.errors += 1;
+        return error.HelpersMismatch;
+    }
+    record.helpers_end += 1;
+    record.ends += 1;
+    record.active = false;
+    record.paused = false;
+    record.token = null;
+    slot.record = null;
+    var output: [1024]u8 = undefined;
+    try response.text(try format_record(record, tags[slot.index], &output));
+}
+fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
+    const slot: *Slot = @ptrCast(@alignCast(context));
+    const record = slot.record orelse {
+        slot.owner.errors += 1;
+        return;
+    };
+    record.cancels += 1;
+    record.reason = reason;
+    record.active = false;
+    record.paused = false;
+    record.token = null;
+    slot.record = null;
+}
+fn health(_: *uz.Request, response: *uz.Response) void {
+    response.text("ok") catch |err| std.log.err("health: {}", .{err});
+}
+fn status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
+    const state: *State = @ptrCast(@alignCast(context));
+    const tag = request.get_param("tag") orelse {
+        state.errors += 1;
+        return;
+    };
+    const index = tag_index(tag) orelse {
+        state.errors += 1;
+        return;
+    };
+    var output: [1024]u8 = undefined;
+    const body = format_record(&state.records[index], tags[index], &output) catch {
+        state.errors += 1;
+        return;
+    };
+    response.text(body) catch {
+        state.errors += 1;
+    };
+}
+const Totals = struct {
+    middleware: u64 = 0,
+    attempts: u64 = 0,
+    begins: u64 = 0,
+    ends: u64 = 0,
+    cancels: u64 = 0,
+    failures: u64 = 0,
+    accepted: u64 = 0,
+    active: u32 = 0,
+    errors: u64 = 0,
+};
+fn totals(state: *const State) Totals {
+    var result: Totals = .{ .errors = state.errors };
+    for (state.records) |record| {
+        result.middleware += record.middleware;
+        result.attempts += record.attempts;
+        result.begins += record.begins;
+        result.ends += record.ends;
+        result.cancels += record.cancels;
+        result.failures += record.failures;
+        result.accepted += record.bytes;
+        result.errors += record.errors;
+        result.active += @intFromBool(record.active);
+    }
+    return result;
+}
+fn format_totals(state: *const State, output: []u8) ![]const u8 {
+    const t = totals(state);
+    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"accepted\":{d},\"active\":{d},\"errors\":{d},\"buffered_middleware\":{d},\"slot0_active\":{any},\"slot1_active\":{any}}}", .{ t.middleware, t.attempts, t.begins, t.ends, t.cancels, t.failures, t.accepted, t.active, t.errors, state.buffered_middleware, state.slots[0].record != null, state.slots[1].record != null });
+}
+fn metrics(context: *anyopaque, _: *uz.Request, response: *uz.Response) void {
+    const state: *State = @ptrCast(@alignCast(context));
+    var output: [1024]u8 = undefined;
+    const body = format_totals(state, &output) catch {
+        state.errors += 1;
+        return;
+    };
+    response.text(body) catch {
+        state.errors += 1;
+    };
+}
+fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
+    const state: *State = @ptrCast(@alignCast(context));
+    const tag = request.get_param("tag") orelse {
+        state.errors += 1;
+        return;
+    };
+    const index = tag_index(tag) orelse {
+        state.errors += 1;
+        return;
+    };
+    const token = state.records[index].token orelse {
+        state.errors += 1;
+        return;
+    };
+    if (!state.records[index].paused) {
+        state.errors += 1;
+        return;
+    }
+    state.records[index].paused = false;
+    token.@"resume"() catch {
+        state.errors += 1;
+        response.text("error") catch {
+            state.errors += 1;
+        };
+        return;
+    };
+    response.text("ok") catch {
+        state.errors += 1;
+    };
+}
+pub fn main(init: std.process.Init) !void {
+    const certificate = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_CERT") orelse return error.MissingCertificate);
+    const key = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_KEY") orelse return error.MissingKey);
+    const nonce = init.environ_map.get("H2_PROFILE_NONCE") orelse return error.MissingNonce;
+    if (nonce.len == 0 or nonce.len > 64) return error.InvalidNonce;
+    var state: State = .{};
+    const sink: uz.BodySink = .{ .context = &state, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel };
+    var upload: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 100000000, .max_active = 2 }, .middleware_policy = .headers_only };
+    {
+        var server = try uz.Server.preset(init.io, config).build_https(init.arena.allocator(), certificate, key);
+        defer server.deinit();
+        _ = try server.use(&state, middleware);
+        _ = try server.route_body(.post, "/meta/:tag/:p01/:p02/:p03/:p04/:p05/:p06/:p07/:p08/:p09/:p10/:p11/:p12/:p13/:p14/:p15/:p16", &upload);
+        _ = try server.get("/health", health);
+        _ = try server.get_context("/status/:tag", &state, status);
+        _ = try server.get_context("/metrics", &state, metrics);
+        _ = try server.get_context("/resume/:tag", &state, control);
+        std.log.info("H2_CAPACITY config={f} request_stride={d} h2_bytes={d} h2_stride={d} slab={d} router={d}", .{ std.json.fmt(config, .{}), try config.request_buffer_stride(), try config.h2_session_bytes(), try config.h2_session_stride(), try config.slab_bytes(), try config.router_storage_bytes() });
+        try server.listen("127.0.0.1", 28443);
+        try server.catch_shutdown_signals();
+        std.log.info("H2_READY {s}", .{nonce});
+        try server.run();
+    }
+    for (&state.records, 0..) |*record, i| {
+        var output: [1024]u8 = undefined;
+        std.log.info("H2_RECORD {s} {s}", .{ nonce, try format_record(record, tags[i], &output) });
+    }
+    var output: [1024]u8 = undefined;
+    std.log.info("H2_DEINIT {s} {s}", .{ nonce, try format_totals(&state, &output) });
+}

## /tmp/uwz-task5b4-frozen-v2/pure_codec_checks.py (25 lines; SHA13fed0d061e4c89e436e2435f870f37bce6ef7dd52c63a0749b5c1325b0aa878)
--- /dev/null
+++ /tmp/uwz-task5b4-frozen-v2/pure_codec_checks.py
@@ -0,0 +1,25 @@
+"""Pure codec and caller-data checks, no transport or fixture execution."""
+import hashlib
+import h2.config
+import h2.connection
+import run_live
+import cases
+
+path = '/meta/metadata_helpers/' + '/'.join('a%02d' % i for i in range(1, 17))
+target = path + '?q=alpha&n=17'
+ordinary = [('content-length', '32'), ('x-mode', 'begin_paused')] + [('x-h%02d' % i, 'v%02d' % i) for i in range(63)]
+headers = [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', target)] + ordinary
+assert len(path) == 86 and len(target) == 99 and len(ordinary) == 65 and len(headers) == 69
+assert sum(len(n) + len(v) for n, v in headers) == 684
+assert sum(len(n) + len(v) + 32 for n, v in headers) == 2892
+protocol = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True))
+protocol.initiate_connection()
+protocol.data_to_send()
+protocol.send_headers(1, headers, end_stream=False)
+pending = protocol.data_to_send()
+size = run_live.encoded_headers_size(pending, 1)
+assert 0 < size <= 8192
+assert len(cases.TAGS) == 32 and len(set(cases.TAGS)) == 32
+print('fields=69 decoded_bytes=684 list_cost=2892 path=86 target=99')
+print('actual fresh pinned codec encoded header bytes=%d' % size)
+print('case tags=32 unique=32')

## /tmp/uwz-task5b4-frozen-v2/raw_observer.py (78 lines; SHA13f686ffcfa3ba2b0d13c12d52f317e54e691f36d8e7474aea76da96a88bfc48)
--- /dev/null
+++ /tmp/uwz-task5b4-frozen-v2/raw_observer.py
@@ -0,0 +1,78 @@
+"""Bounded raw HTTP/2 frame-order observation; transport is external."""
+
+READ_BOUND = 8192
+STREAM_LIMIT = 8
+
+
+def require(condition, message):
+    if not condition:
+        raise ValueError(message)
+
+
+def new_state():
+    return {"header": bytearray(), "remaining": 0, "frame": None,
+            "reset_payload": bytearray(), "streams": {}}
+
+
+def register(state, stream_id, expect_reset):
+    streams = state["streams"]
+    require(0 < stream_id <= 0x7fffffff and stream_id not in streams, "invalid stream")
+    require(len(streams) < STREAM_LIMIT, "stream bound")
+    streams[stream_id] = {"expect_reset": expect_reset, "end": False, "reset": False}
+
+
+def retire(state, stream_id):
+    record = state["streams"][stream_id]
+    require(record["end"] and record["reset"] == record["expect_reset"], "incomplete stream")
+    del state["streams"][stream_id]
+
+
+def finish_frame(state):
+    frame = state["frame"]
+    stream_id = frame["stream"]
+    if frame["type"] == 3:
+        record = state["streams"].get(stream_id)
+        require(record is not None, "reset on unregistered stream")
+        require(record["expect_reset"], "reset on healthy stream")
+        require(record["end"], "reset before final end")
+        require(not record["reset"], "duplicate reset")
+        require(state["reset_payload"] == b'\0\0\0\0', "wrong reset code")
+        record["reset"] = True
+    elif frame["type"] in (0, 1) and frame["flags"] & 1:
+        record = state["streams"].get(stream_id)
+        if record is not None:
+            require(not record["end"], "duplicate final end")
+            record["end"] = True
+    state["frame"] = None
+    state["reset_payload"].clear()
+
+
+def observe(state, data):
+    require(len(data) <= READ_BOUND, "read bound")
+    offset = 0
+    while offset < len(data):
+        if state["frame"] is None:
+            header = state["header"]
+            count = min(9 - len(header), len(data) - offset)
+            header.extend(data[offset:offset + count])
+            offset += count
+            if len(header) < 9:
+                continue
+            length = int.from_bytes(header[:3], "big")
+            frame_type = header[3]
+            stream_id = int.from_bytes(header[5:9], "big") & 0x7fffffff
+            if frame_type == 3:
+                require(length == 4 and stream_id != 0, "invalid reset frame")
+            state["frame"] = {"type": frame_type, "flags": header[4], "stream": stream_id}
+            state["remaining"] = length
+            header.clear()
+            if length == 0:
+                finish_frame(state)
+            continue
+        count = min(state["remaining"], len(data) - offset)
+        if state["frame"]["type"] == 3:
+            state["reset_payload"].extend(data[offset:offset + count])
+        offset += count
+        state["remaining"] -= count
+        if state["remaining"] == 0:
+            finish_frame(state)

## /tmp/uwz-task5b4-frozen-v2/run_live.py (542 lines; SHA0b09f172583067bde4373b7d58d9e663ecd837b363066ab3c278cbc588833747)
--- /dev/null
+++ /tmp/uwz-task5b4-frozen-v2/run_live.py
@@ -0,0 +1,542 @@
+"""Explicitly gated ordinary owned H2 fixture runner; importing is inert."""
+import argparse
+import hashlib
+import importlib.util
+import json
+import os
+from pathlib import Path
+import signal
+import socket
+import ssl
+import subprocess
+import sys
+import threading
+import time
+
+HERE = Path(__file__).resolve().parent
+PORT = 28443
+PYTHON = '/home/codespace/.python/current/bin/python3'
+PACKAGES = '/tmp/uwz-h2-client-tooling/packages'
+HELPER = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'
+OPENSSL = '/opt/conda/bin/openssl'
+CASES = ('metadata_helpers', 'shutdown_idle')
+
+
+def require(condition, message):
+    if not condition:
+        raise RuntimeError(message)
+
+
+def digest(path):
+    value = hashlib.sha256()
+    with open(path, 'rb') as source:
+        while block := source.read(8192):
+            value.update(block)
+    return value.hexdigest()
+
+
+def check_manifest(path, expected):
+    require(digest(path) == expected, 'review manifest identity differs')
+    manifest = json.loads(path.read_text())
+    for root, expected_files in manifest['trees'].items():
+        actual = {str(p.relative_to(root)) for p in Path(root).rglob('*') if p.is_file()}
+        require(actual == set(expected_files), 'tree inventory differs: ' + root)
+        for name, value in expected_files.items():
+            require(digest(Path(root) / name) == value, 'tree input identity differs: ' + name)
+    for name, value in manifest['inputs'].items():
+        require(digest(name) == value, 'input identity differs: ' + name)
+    require(manifest['state'] == 'ready-for-independent-review', 'manifest not review ready')
+    checked_path(__file__, manifest['runner'], manifest['inputs'])
+    checked_path(manifest['wire'], manifest['wire'], manifest['inputs'])
+    checked_path(manifest['raw'], manifest['raw'], manifest['inputs'])
+    checked_path(manifest['cases'], manifest['cases'], manifest['inputs'])
+    checked_path(manifest['flow'], manifest['flow'], manifest['inputs'])
+    checked_path(manifest['helper'], manifest['helper'], manifest['inputs'])
+    return manifest
+
+
+def checked_path(actual, expected, inputs):
+    require(Path(actual).absolute() == Path(expected).absolute(), 'executing source path differs')
+    require(Path(actual).resolve() == Path(expected).absolute(), 'source path resolves elsewhere')
+    require(expected in inputs and digest(actual) == inputs[expected], 'executing source hash differs')
+
+
+def load_bound(name, path, inputs):
+    checked_path(path, path, inputs)
+    spec = importlib.util.spec_from_file_location(name, path)
+    require(spec is not None and spec.loader is not None, 'module loader unavailable')
+    module = importlib.util.module_from_spec(spec)
+    sys.modules[name] = module
+    spec.loader.exec_module(module)
+    checked_path(module.__file__, path, inputs)
+    return module
+
+
+def new_capture():
+    return {'lock': threading.Lock(), 'bytes': bytearray(), 'overflow': False, 'error': None}
+
+
+def capture_fragment(capture, data):
+    with capture['lock']:
+        room = 65536 - len(capture['bytes'])
+        capture['bytes'].extend(data[:room])
+        if len(data) > room:
+            capture['overflow'] = True
+
+
+def capture_snapshot(capture):
+    with capture['lock']:
+        return bytes(capture['bytes']), capture['overflow'], capture['error']
+
+
+def check_capture(capture):
+    _, overflow, error = capture_snapshot(capture)
+    require(not overflow, 'server output exceeds 65536 bytes')
+    require(error is None, 'server output collector failed: ' + str(error))
+
+
+def drain_capture(pipe, capture):
+    try:
+        while data := os.read(pipe.fileno(), 8192):
+            capture_fragment(capture, data)
+    except BaseException as exc:
+        with capture['lock']:
+            capture['error'] = repr(exc)
+    finally:
+        try:
+            pipe.close()
+        except BaseException as exc:
+            with capture['lock']:
+                capture['error'] = repr(exc)
+
+
+def cleanup_actions(actions):
+    errors = []
+    for name, action in actions:
+        try:
+            action()
+        except BaseException as exc:
+            errors.append({'action': name, 'error': repr(exc)})
+    return errors
+
+
+def remaining(deadline):
+    seconds = deadline - time.monotonic()
+    require(seconds > 0, 'absolute deadline expired')
+    return seconds
+
+
+def child_start(pid):
+    # comm can contain spaces or parentheses; the final ')' ends that field.
+    text = Path('/proc', str(pid), 'stat').read_text()
+    return text[text.rfind(')') + 2:].split()[19]
+
+
+def owned_listener(pid):
+    inodes = set()
+    for entry in Path('/proc', str(pid), 'fd').iterdir():
+        target = os.readlink(entry)
+        if target.startswith('socket:['):
+            inodes.add(target[8:-1])
+    rows = Path('/proc/net/tcp').read_text().splitlines()[1:]
+    return [row.split()[9] for row in rows if row.split()[1] == '0100007F:6F1B'
+            and row.split()[3] == '0A' and row.split()[9] in inodes]
+
+
+def wait_marker(child, capture, nonce, deadline):
+    marker = ('H2_READY ' + nonce).encode()
+    while True:
+        check_capture(capture)
+        require(child.poll() is None, 'child exited before readiness')
+        data, _, _ = capture_snapshot(capture)
+        if marker in data:
+            listeners = owned_listener(child.pid)
+            require(len(listeners) == 1, 'owned loopback listener not uniquely identified')
+            return listeners[0]
+        time.sleep(min(0.05, remaining(deadline)))
+
+
+def flush(sock, protocol, deadline, capture):
+    check_capture(capture)
+    pending = protocol.data_to_send()
+    if pending:
+        sock.settimeout(remaining(deadline))
+        sock.sendall(pending)
+
+
+def encoded_headers_size(pending, stream):
+    from hyperframe.frame import Frame, HeadersFrame, ContinuationFrame
+    offset = 0
+    total = 0
+    ended = False
+    while offset < len(pending):
+        require(len(pending) - offset >= 9, 'truncated generated frame header')
+        frame, length = Frame.parse_frame_header(memoryview(pending)[offset:offset + 9])
+        offset += 9
+        require(offset + length <= len(pending), 'truncated generated frame payload')
+        frame.parse_body(memoryview(pending)[offset:offset + length])
+        offset += length
+        require(isinstance(frame, (HeadersFrame, ContinuationFrame)) and frame.stream_id == stream and not ended, 'unexpected generated header frame')
+        total += len(frame.data)
+        require(total <= 8192, 'encoded header block exceeds bound')
+        ended = 'END_HEADERS' in frame.flags
+    require(ended, 'missing generated END_HEADERS')
+    return total
+
+
+def flush_headers(sock, protocol, deadline, capture, stream):
+    check_capture(capture)
+    pending = protocol.data_to_send()
+    total = encoded_headers_size(pending, stream)
+    sock.settimeout(remaining(deadline))
+    sock.sendall(pending)
+    return total
+
+
+def receive(sock, protocol, records, raw, trace, deadline, wire, capture):
+    check_capture(capture)
+    sock.settimeout(remaining(deadline))
+    data = sock.recv(8192)
+    require(data, 'TLS EOF before response completion')
+    events = wire.accept(protocol, data, records, raw, trace['events'])
+    import h2.events
+    import h2.settings
+    updates = [(event.stream_id, event.delta) for event in events if isinstance(event, h2.events.WindowUpdated)]
+    initial = None
+    for event in events:
+        if isinstance(event, h2.events.RemoteSettingsChanged):
+            changed = event.changed_settings.get(h2.settings.SettingCodes.INITIAL_WINDOW_SIZE)
+            if changed is not None:
+                initial = changed.new_value
+                require(initial == 65535, 'peer stream initial window changed')
+    ledger = trace['ledger']
+    trace['flow'].receive_batch(ledger, updates, initial)
+    windows = {stream_id: protocol.local_flow_control_window(stream_id)
+               for stream_id, item in ledger.streams.items() if item.open}
+    trace['flow'].check_public(ledger, protocol.outbound_flow_control_window, windows)
+    require(len(trace['snapshots']) < 4096, 'flow snapshot bound exceeded')
+    trace['snapshots'].append({'connection': ledger.connection, 'sent': ledger.sent,
+                               'refunded': ledger.refunded, 'windows': windows, 'updates': updates})
+    flush(sock, protocol, deadline, capture)
+
+
+def start(protocol, records, raw, method, path, headers, end_stream, limit, wire, status=200, info=0, reset=False):
+    stream = protocol.get_next_available_stream_id()
+    wire.register(records, raw, stream, limit, status, info, reset)
+    protocol.send_headers(stream, [(':method', method), (':scheme', 'https'),
+                                  (':authority', 'localhost'), (':path', path)] + headers,
+                          end_stream=end_stream)
+    return stream
+
+
+def complete(sock, protocol, records, raw, trace, stream, deadline, wire, capture, keep=False):
+    flush(sock, protocol, deadline, capture)
+    record = records[stream]
+    while not (record['ended'] and (not record['expect_reset'] or raw['streams'][stream]['reset'])
+               and not raw['header'] and raw['frame'] is None):
+        receive(sock, protocol, records, raw, trace, deadline, wire, capture)
+    wire.complete(records, raw, stream)
+    result = {'headers': record['headers'], 'bytes': record['bytes'],
+              'sha256': record['hash'].hexdigest(), 'body': bytes(record['body']).decode('utf-8'),
+              'informationals': record['informationals'], 'raw_reset': raw['streams'][stream]['reset'],
+              'reset_event': record['reset_event']}
+    if not keep:
+        wire.retire(records, raw, stream)
+    return result
+
+
+def request(sock, protocol, records, raw, trace, path, deadline, wire, capture, limit=1024):
+    stream = start(protocol, records, raw, 'GET', path, [], True, limit, wire)
+    return complete(sock, protocol, records, raw, trace, stream, deadline, wire, capture)
+
+
+def status(sock, protocol, records, raw, trace, tag, deadline, wire, capture):
+    response = request(sock, protocol, records, raw, trace, '/status/' + tag, deadline, wire, capture)
+    return json.loads(response['body'])
+
+
+def metrics(sock, protocol, records, raw, trace, deadline, wire, capture):
+    response = request(sock, protocol, records, raw, trace, '/metrics', deadline, wire, capture)
+    return json.loads(response['body'])
+
+
+def health(sock, protocol, records, raw, trace, deadline, wire, capture):
+    response = request(sock, protocol, records, raw, trace, '/health', deadline, wire, capture, 2)
+    require(response['body'] == 'ok', 'health differs')
+    return response
+
+
+def run(args, manifest):
+    helper = load_bound('h2_client', manifest['helper'], manifest['inputs'])
+    raw_module = load_bound('raw_observer', manifest['raw'], manifest['inputs'])
+    sys.modules['raw_observer'] = raw_module
+    wire = load_bound('admission_wire', manifest['wire'], manifest['inputs'])
+    require(wire.raw_observer is raw_module, 'raw observer binding differs')
+    cases = load_bound('credit_cases', manifest['cases'], manifest['inputs'])
+    flow = load_bound('credit_flow', manifest['flow'], manifest['inputs'])
+    require(cases.CASES == CASES, 'case catalogue differs')
+    import h2
+    import hpack
+    import hyperframe
+    for module in (h2, hpack, hyperframe):
+        require(Path(module.__file__).resolve().is_relative_to(Path(PACKAGES)), 'client module origin differs')
+    require(Path(helper.__file__).resolve() == Path(HELPER) / 'h2_client.py', 'helper origin differs')
+    overall = time.monotonic() + 900
+    run_dir = Path(args.output).resolve()
+    run_dir.mkdir(mode=0o700)
+    cert, key, log = run_dir / 'certificate.pem', run_dir / 'private-key.pem', run_dir / 'server.log'
+    nonce = os.urandom(16).hex()
+    result = {'nonce': nonce, 'cases': {}, 'success': False, 'cleanup': {},
+              'python': sys.executable, 'python_path': sys.path, 'openssl': OPENSSL,
+              'profile': manifest['binary'], 'manifest_sha256': args.manifest_sha256}
+    child = None
+    sock = None
+    start_id = None
+    error = None
+    capture = new_capture()
+    collector = None
+    try:
+        command = [OPENSSL, 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
+                   '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost',
+                   '-keyout', str(key), '-out', str(cert)]
+        result['certificate_command'] = command
+        certificate_env = {'OPENSSL_CONF': '/opt/conda/ssl/openssl.cnf'}
+        result['certificate_environment'] = certificate_env
+        subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True,
+                       env=certificate_env, timeout=remaining(overall))
+        os.chmod(key, 0o600)
+        cert_der = ssl.PEM_cert_to_DER_cert(cert.read_text())
+        result['certificate_sha256'] = hashlib.sha256(cert_der).hexdigest()
+        env = {'H2_PROFILE_CERT': str(cert), 'H2_PROFILE_KEY': str(key), 'H2_PROFILE_NONCE': nonce}
+        result['child_argv'] = [manifest['binary']]
+        result['child_environment'] = env.copy()
+        child = subprocess.Popen([manifest['binary']], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
+        collector = threading.Thread(target=drain_capture, args=(child.stdout, capture), daemon=True)
+        collector.start()
+        start_id = child_start(child.pid)
+        result['child'] = {'pid': child.pid, 'start': start_id, 'binary_sha256': digest(manifest['binary'])}
+        deadline = min(overall, time.monotonic() + 15)
+        result['listener_inode'] = wait_marker(child, capture, nonce, deadline)
+        ready_output = capture_snapshot(capture)[0].decode('utf-8')
+        capacity = [line for line in ready_output.splitlines() if 'H2_CAPACITY ' in line]
+        require(len(capacity) == 1 and 'slab=4098304' in capacity[0], 'fixture capacity differs')
+        result['capacity'] = capacity[0]
+        require(child_start(child.pid) == start_id and child.poll() is None, 'owned child changed')
+        context = ssl.create_default_context(cafile=str(cert))
+        context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_3
+        context.set_alpn_protocols(['h2'])
+        p32 = helper.payload_block(32, 0, 32)
+        require(hashlib.sha256(p32).hexdigest() == '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5', 'payload digest differs')
+        credit_hash = hashlib.sha256()
+        for offset in range(0, 65536, 8192):
+            credit_hash.update(helper.payload_block(65536, offset, min(8192, 65536 - offset)))
+        responses = {}
+        result['connections'] = []
+        connection_cases = args.cases
+        for case in connection_cases:
+            if sock is not None:
+                require(not records and not raw_state['streams'], 'records remain on previous connection')
+                sock.close()
+                sock = None
+            deadline = min(overall, time.monotonic() + 30)
+            require(child.poll() is None and child_start(child.pid) == start_id, 'owned child changed')
+            require(owned_listener(child.pid) == [result['listener_inode']], 'owned listener changed')
+            raw = socket.create_connection(('127.0.0.1', PORT), timeout=remaining(deadline))
+            try:
+                raw.settimeout(remaining(deadline))
+                sock = context.wrap_socket(raw, server_hostname='localhost', suppress_ragged_eofs=False)
+            except BaseException:
+                raw.close()
+                raise
+            require(sock.version() == 'TLSv1.3' and sock.selected_alpn_protocol() == 'h2', 'TLS/ALPN differs')
+            require(hashlib.sha256(sock.getpeercert(binary_form=True)).hexdigest() == result['certificate_sha256'], 'peer certificate identity differs')
+            require(child.poll() is None and child_start(child.pid) == start_id, 'owned child died')
+            protocol, records, raw_state = helper.new_protocol(), {}, raw_module.new_state()
+            trace = {'events': {}, 'ledger': flow.FlowLedger(), 'flow': flow, 'snapshots': []}
+            flush(sock, protocol, deadline, capture)
+            health(sock, protocol, records, raw_state, trace, deadline, wire, capture)
+            require(protocol.remote_settings.initial_window_size == 65535, 'initial stream window differs')
+            observed, stream_tags = [], {}
+            if case == 'shutdown_idle':
+                result['connections'].append({'case': case, 'tls': sock.version(), 'alpn': sock.selected_alpn_protocol(), 'snapshots': trace['snapshots']})
+                continue
+            def begin(route, tag, length, query, extra, status=200, reset=False):
+                headers = [('content-length', str(length))] + extra
+                stream = start(protocol, records, raw_state, 'POST', query,
+                               headers, False, 0 if reset else 1024, wire, status, 0, reset)
+                stream_tags[stream] = tag
+                if not reset: flow.open_stream(trace['ledger'], stream)
+                encoded = flush_headers(sock, protocol, deadline, capture, stream)
+                trace['encoded_header_bytes'] = encoded
+                return stream
+            def finish(stream, keep=False):
+                item = complete(sock, protocol, records, raw_state, trace, stream, deadline, wire, capture, keep)
+                tag = stream_tags[stream]
+                responses[tag] = item
+                observed.append({'tag': tag, 'response': item})
+                return item
+            def send(stream, total, offset, length, end_stream, padding=None):
+                require(length <= 8192, 'generated data exceeds bound')
+                data = helper.payload_block(total, offset, length)
+                ledger = trace['ledger']
+                flow.check_public(ledger, protocol.outbound_flow_control_window, {stream: protocol.local_flow_control_window(stream)})
+                flow.send_data(ledger, stream, len(data), padding, protocol.max_outbound_frame_size, end_stream)
+                protocol.send_data(stream, data, end_stream=end_stream, pad_length=padding)
+                require(len(trace['snapshots']) < 4096, 'flow snapshot bound exceeded')
+                trace['snapshots'].append({'send_stream': stream, 'logical': len(data), 'padding': padding, 'connection': ledger.connection, 'stream': ledger.streams[stream].window, 'sent': ledger.sent})
+                flush(sock, protocol, deadline, capture)
+            def trailers(stream, headers):
+                protocol.send_headers(stream, headers, end_stream=True)
+                # The stream may still receive WINDOW_UPDATE; no public stream query after END_STREAM.
+                trace['ledger'].streams[stream].open = False
+                trace['trailer_encoded_header_bytes'] = flush_headers(sock, protocol, deadline, capture, stream)
+            def get_status(tag):
+                return status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture)
+            def get_metrics():
+                return metrics(sock, protocol, records, raw_state, trace, deadline, wire, capture)
+            def do_resume(tag):
+                item = request(sock, protocol, records, raw_state, trace, '/resume/' + tag, deadline, wire, capture, 64)
+                require(item['body'] == 'ok', 'resume failed')
+            def pending(stream):
+                require(records[stream]['headers'] is None and not records[stream]['ended'], 'final before resume')
+            def active(count):
+                require(get_metrics()['active'] == count, 'active binding count differs')
+            def initial_credit(stream):
+                ledger = trace['ledger']
+                require(ledger.initial_stream == ledger.connection == ledger.streams[stream].window == 65535, 'initial credit differs')
+                flow.check_public(ledger, protocol.outbound_flow_control_window, {stream: protocol.local_flow_control_window(stream)})
+            def zero_credit(stream):
+                ledger = trace['ledger']
+                require(ledger.connection == ledger.streams[stream].window == ledger.refunded == ledger.streams[stream].refunded == 0, 'zero credit differs')
+                flow.check_public(ledger, protocol.outbound_flow_control_window, {stream: protocol.local_flow_control_window(stream)})
+            def settled_credit(stream, amount):
+                ledger = trace['ledger']
+                while ledger.refunded < amount or ledger.streams[stream].refunded < amount:
+                    receive(sock, protocol, records, raw_state, trace, deadline, wire, capture)
+                require(ledger.refunded == ledger.streams[stream].refunded == amount, 'settled credit differs')
+            def refund_bound(stream, maximum):
+                ledger = trace['ledger']
+                require(ledger.refunded <= maximum and ledger.streams[stream].refunded <= maximum, 'early refund exceeds bound')
+            api = {'start': begin, 'finish': finish, 'send': send, 'trailers': trailers, 'status': get_status,
+                   'metrics': get_metrics, 'resume': do_resume, 'pending': pending, 'active': active,
+                   'initial_credit': initial_credit, 'zero_credit': zero_credit, 'settled_credit': settled_credit,
+                   'refund_bound': refund_bound, 'health': lambda: health(sock, protocol, records, raw_state, trace, deadline, wire, capture),
+                   'retire': lambda stream: wire.retire(records, raw_state, stream)}
+            cases.execute(api, case)
+            require(not records and not raw_state['streams'], 'response records remain after case')
+            require(get_metrics()['active'] == 0, 'case has active bindings')
+            expected_flow = 32
+            require(trace['ledger'].sent == expected_flow, 'case flow total differs')
+            result['cases'][case] = observed
+            result['connections'].append({'case': case, 'tls': sock.version(), 'alpn': sock.selected_alpn_protocol(),
+                                          'events': trace['events'], 'snapshots': trace['snapshots'], 'encoded_header_bytes': trace['encoded_header_bytes'], 'sent_flow': trace['ledger'].sent})
+        deadline = min(overall, time.monotonic() + 30)
+        final = {tag: status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture) for tag in cases.TAGS}
+        aggregate = metrics(sock, protocol, records, raw_state, trace, deadline, wire, capture)
+        selected = cases.selected_tags(args.cases)
+        empty_hash = hashlib.sha256(b'').hexdigest()
+        for tag in cases.TAGS:
+            cases.verify_record(final[tag], cases.expected(tag, selected, empty_hash, credit_hash.hexdigest()))
+            if tag in selected and tag != 'concurrent_refused':
+                require(json.loads(responses[tag]['body']) == final[tag], 'final response differs from status')
+        for field in ('middleware', 'attempts', 'begin', 'end', 'cancel', 'failure', 'accepted', 'errors'):
+            require(aggregate[field] == sum(record[field] for record in final.values()), 'aggregate ' + field + ' differs')
+        require(aggregate['active'] == 0 and not aggregate['slot0_active'] and not aggregate['slot1_active'], 'active fixture')
+        result['final_status'] = final
+        result['final_metrics'] = aggregate
+        sock.close()
+        sock = None
+        require(child_start(child.pid) == start_id and child.poll() is None, 'child identity changed')
+        os.kill(child.pid, signal.SIGTERM)
+        exit_code = child.wait(timeout=remaining(min(overall, time.monotonic() + 15)))
+        result['cleanup'] = {'signal': 'SIGTERM', 'exit_code': exit_code, 'reaped': True, 'forced': False}
+        require(exit_code == 0, 'owned server exit differs')
+        collector.join(timeout=remaining(overall))
+        require(not collector.is_alive(), 'server output collector did not finish')
+        check_capture(capture)
+        text = capture_snapshot(capture)[0].decode('utf-8')
+        post = {}
+        post_metrics = None
+        for line in text.splitlines():
+            marker = 'H2_RECORD ' + nonce + ' '
+            if marker in line:
+                item = json.loads(line.split(marker, 1)[1])
+                require(item['tag'] not in post, 'duplicate post-deinit tag')
+                post[item['tag']] = item
+            marker = 'H2_DEINIT ' + nonce + ' '
+            if marker in line:
+                require(post_metrics is None, 'duplicate post-deinit aggregate')
+                post_metrics = json.loads(line.split(marker, 1)[1])
+        require(post == final and post_metrics == aggregate, 'post-deinit state differs')
+        if 'shutdown_idle' in args.cases:
+            result['cases']['shutdown_idle'] = {'exit_code': exit_code, 'post_deinit': True}
+        result['success'] = True
+    except BaseException as exc:
+        error = repr(exc)
+    finally:
+        def close_socket():
+            if sock is not None:
+                sock.close()
+
+        def signal_child():
+            if child is None or child.poll() is not None:
+                return
+            require(start_id is None or child_start(child.pid) == start_id, 'child identity changed during cleanup')
+            result['cleanup']['forced'] = True
+            child.kill()
+
+        def wait_child():
+            if child is None:
+                return
+            child.wait(timeout=15)
+            result['cleanup']['exit_code'] = child.returncode
+            result['cleanup']['reaped'] = True
+
+        def delete_key():
+            key.unlink(missing_ok=True)
+
+        def save_log():
+            if collector is not None:
+                collector.join(timeout=15)
+            data, overflow, collector_error = capture_snapshot(capture)
+            log.write_bytes(data)
+            require(collector is None or not collector.is_alive(), 'server output collector did not finish')
+            require(not overflow and collector_error is None, 'server output collection failed or overflowed')
+
+        def close_pipe():
+            if child is not None and child.stdout is not None:
+                child.stdout.close()
+
+        errors = cleanup_actions((('socket', close_socket), ('child_signal', signal_child),
+                                  ('child_wait', wait_child), ('key', delete_key), ('log', save_log),
+                                  ('pipe', close_pipe)))
+        if errors or result['cleanup'].get('forced', False):
+            result['success'] = False
+        result['cleanup']['errors'] = errors
+        result['error'] = error
+        (run_dir / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
+    require(result['success'], 'owned run failed: ' + str(error))
+
+
+def main():
+    parser = argparse.ArgumentParser()
+    parser.add_argument('--run', action='store_true', required=True)
+    parser.add_argument('--manifest', type=Path, required=True)
+    parser.add_argument('--manifest-sha256', required=True)
+    parser.add_argument('--output', required=True)
+    parser.add_argument('--cases', nargs='+', choices=CASES, required=True)
+    args = parser.parse_args()
+    require(dict(os.environ) == {'PYTHONPATH': PACKAGES + ':' + HELPER, 'LC_ALL': 'C.UTF-8'},
+            'runner environment must contain only the pinned locale and PYTHONPATH')
+    require(sys.executable == PYTHON and sys.dont_write_bytecode and sys.flags.no_site and os.environ.get('PYTHONPATH') == PACKAGES + ':' + HELPER,
+            'Python interpreter or PYTHONPATH differs')
+    require(len(set(args.cases)) == len(args.cases) and ('shutdown_idle' not in args.cases or args.cases[-1] == 'shutdown_idle'), 'invalid case order')
+    output = Path(args.output)
+    require(output.is_absolute() and output.resolve().is_relative_to(Path('/tmp')) and output.resolve() != Path('/tmp'), 'output must be new /tmp path')
+    require(not output.exists(), 'output already exists')
+    manifest = check_manifest(args.manifest, args.manifest_sha256)
+    run(args, manifest)
+
+
+if __name__ == '__main__':
+    main()

## /tmp/uwz-task5b4-frozen-v2/wire.py (97 lines; SHA41394947f72bbf25eb3d00eb82c46204c3b0e8c732aff56159bba1eb6da42d11)
--- /dev/null
+++ /tmp/uwz-task5b4-frozen-v2/wire.py
@@ -0,0 +1,97 @@
+"""Bounded HTTP/2 response event and raw reset observation."""
+import hashlib
+import h2.events
+import raw_observer
+
+READ_BOUND = 8192
+STREAM_LIMIT = 8
+HEADER_FIELDS = 32
+HEADER_BYTES = 4096
+INFO_COUNT = 16
+INFO_BYTES = 16384
+EVENT_LIMIT = 64
+
+
+def require(condition, message):
+    if not condition:
+        raise ValueError(message)
+
+
+def register(records, raw, stream_id, body_limit, final_status, info_count, expect_reset):
+    require(len(records) < STREAM_LIMIT and stream_id not in records, 'stream record bound')
+    require(0 <= body_limit < 4096 and info_count in (0, 1), 'invalid expectation')
+    raw_observer.register(raw, stream_id, expect_reset)
+    records[stream_id] = {'headers': None, 'informationals': 0, 'info_bytes': 0,
+                          'bytes': 0, 'hash': hashlib.sha256(), 'body': bytearray(),
+                          'limit': body_limit, 'ended': False, 'reset_event': False,
+                          'status': str(final_status), 'expected_info': info_count,
+                          'expect_reset': expect_reset}
+
+
+def checked_headers(headers):
+    require(len(headers) <= HEADER_FIELDS, 'header field count bound')
+    size = sum(len(k.encode('utf-8')) + len(v.encode('utf-8')) + 32 for k, v in headers)
+    require(size <= HEADER_BYTES, 'header byte bound')
+    return size
+
+
+def accept(protocol, data, records, raw, trace):
+    require(len(data) <= READ_BOUND, 'read exceeds bound')
+    raw_observer.observe(raw, data)
+    events = protocol.receive_data(data)
+    for event in events:
+        name = type(event).__name__
+        require(name in trace or len(trace) < EVENT_LIMIT, 'event type bound')
+        trace[name] = trace.get(name, 0) + 1
+        if isinstance(event, h2.events.ConnectionTerminated):
+            raise ValueError('HTTP/2 connection terminated')
+        if not isinstance(event, (h2.events.InformationalResponseReceived, h2.events.ResponseReceived,
+                                  h2.events.TrailersReceived, h2.events.DataReceived,
+                                  h2.events.StreamEnded, h2.events.StreamReset)):
+            continue
+        require(event.stream_id in records, 'unregistered response stream')
+        record = records[event.stream_id]
+        if isinstance(event, h2.events.InformationalResponseReceived):
+            size = checked_headers(event.headers)
+            require(record['informationals'] < INFO_COUNT and record['info_bytes'] + size <= INFO_BYTES,
+                    'informational bound')
+            require(record['headers'] is None and [v for k, v in event.headers if k == ':status'] == ['100'] and not any(k == 'x-middleware' for k, _ in event.headers), 'unexpected informational')
+            record['informationals'] += 1
+            record['info_bytes'] += size
+            require(record['informationals'] <= record['expected_info'], 'extra informational')
+        elif isinstance(event, h2.events.ResponseReceived):
+            checked_headers(event.headers)
+            require(record['headers'] is None, 'duplicate response headers')
+            require([v for k, v in event.headers if k == ':status'] == [record['status']], 'wrong final status')
+            require([v for k, v in event.headers if k == 'x-middleware'] == ['retained'], 'middleware header')
+            record['headers'] = list(event.headers)
+        elif isinstance(event, h2.events.TrailersReceived):
+            raise ValueError('unexpected trailers')
+        elif isinstance(event, h2.events.DataReceived):
+            require(not record['ended'] and record['bytes'] + len(event.data) <= record['limit'], 'response body bound')
+            record['bytes'] += len(event.data)
+            record['hash'].update(event.data)
+            record['body'].extend(event.data)
+            protocol.acknowledge_received_data(event.flow_controlled_length, event.stream_id)
+        elif isinstance(event, h2.events.StreamEnded):
+            require(not record['ended'], 'duplicate end')
+            record['ended'] = True
+        elif isinstance(event, h2.events.StreamReset):
+            require(record['expect_reset'] and raw['streams'][event.stream_id]['reset'], 'unexpected reset event')
+            require(not record['reset_event'] and int(event.error_code) == 0, 'invalid reset event')
+            record['reset_event'] = True
+
+    return events
+
+
+def complete(records, raw, stream_id):
+    record = records[stream_id]
+    require(record['headers'] is not None and record['ended'], 'missing final')
+    require(record['informationals'] == record['expected_info'], 'missing informational')
+    require(raw['streams'][stream_id]['reset'] == record['expect_reset'], 'missing reset')
+
+
+def retire(records, raw, stream_id):
+    complete(records, raw, stream_id)
+    raw_observer.retire(raw, stream_id)
+    del records[stream_id]

## /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata/recovery-2026-10-29/replay.py (54 lines; SHA68f8b939d7ad24401c7ca9e8a36936b0900c4ef08d50013957f3985ee5b09920)
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata/recovery-2026-10-29/replay.py
@@ -0,0 +1,54 @@
+import hashlib, json, os, subprocess, sys
+from pathlib import Path
+
+here = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata')
+out = here / 'recovery-2026-10-29'
+manifest_path = here / 'review-manifest-v2.json'
+manifest = json.loads(manifest_path.read_text())
+binaries = {'/tmp/uwz-task5b4-final-debug/profile', '/tmp/uwz-task5b4-final-release/profile'}
+def digest(p):
+    h = hashlib.sha256()
+    with open(p, 'rb') as f:
+        while b := f.read(1048576): h.update(b)
+    return h.hexdigest()
+def inventory(root):
+    root = Path(root)
+    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file()}
+def check():
+    assert digest(manifest_path) == '5a47148bd2c9857a0cbe9b5b5ea8760c4eeadefbdf3651cb583d154373e73b07'
+    for path, expected in manifest['inputs'].items():
+        if path not in binaries: assert digest(path) == expected, path
+    for path, expected in manifest['trees'].items(): assert inventory(path) == expected, path
+    receipts = [json.loads((here / ('fixture-' + mode + '-final.json')).read_text()) for mode in ('debug', 'release')]
+    reviewed = json.loads((here.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
+    for r in receipts:
+        assert len(r['input_sha256']) == 13 and r['input_sha256'] == r['input_after']
+        for path, expected in r['input_sha256'].items():
+            assert digest(path) == expected, path
+            if path.endswith('.a'): assert reviewed[path] == expected, path
+        assert sum(p.endswith('.a') for p in r['input_sha256']) == 6
+        assert inventory('/tmp/uwz-reviewed-libxev-c223-loop-callbacks') == r['override_before'] == r['override_after']
+        source = inventory(r['cwd'])
+        assert hashlib.sha256(json.dumps(list(source.items())).encode()).hexdigest() == r['source_tree_sha256'] == r['source_after_sha256'] == r['expected_source_digest']
+        assert source == json.loads((here / ('fixture-' + ('debug' if r['optimization'] == 'Debug' else 'release') + '-final-source-inputs.json')).read_text())
+        for name, expected in r['fixture_before'].items(): assert digest(here / name) == expected == r['fixture_after'][name]
+    return receipts
+receipts = check()
+print('preflight: manifest inputs excluding two absent binaries, 6 trees, both 13-input maps, six reviewed archives, source and override: OK', flush=True)
+for r in receipts:
+    mode = 'debug' if r['optimization'] == 'Debug' else 'release'
+    if len(sys.argv) > 1 and mode != sys.argv[1]: continue
+    argv = r['argv']; target = Path(next(x.split('=', 1)[1] for x in argv if x.startswith('-femit-bin=')))
+    assert not target.exists()
+    target.parent.mkdir(parents=True, exist_ok=True)
+    for flag in ('--cache-dir', '--global-cache-dir'): Path(argv[argv.index(flag)+1]).mkdir(parents=True, exist_ok=True)
+    before = {p: digest(p) for p in r['input_sha256']}
+    proc = subprocess.run(argv, cwd=r['cwd'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
+    (out / (mode + '.log')).write_bytes(proc.stdout)
+    after = {p: digest(p) for p in r['input_sha256']}
+    check()
+    actual = digest(target) if target.exists() else None
+    record = {'argv': argv, 'cwd': r['cwd'], 'optimization': r['optimization'], 'environment': 'inherited; original receipt explicit_environment={}', 'before': before, 'after': after, 'source_tree_before_after': r['source_tree_sha256'], 'override_before_after': r['override_before'], 'exit_status': proc.returncode, 'raw_output_file': mode + '.log', 'binary_sha256': actual, 'expected_binary_sha256': r['binary_sha256']}
+    (out / (mode + '.json')).write_text(json.dumps(record, indent=2) + '\n')
+    print(mode, 'exit', proc.returncode, 'sha256', actual, 'expected', r['binary_sha256'], 'output bytes', len(proc.stdout), flush=True)
+    if proc.returncode or actual != r['binary_sha256'] or before != after: break

## /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata/recovery-2026-10-29/current/bind.py (112 lines; SHAda8ebb6272c03a51428c1044fd25af634cbffab3b15e8affde66b0598728c0f1)
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata/recovery-2026-10-29/current/bind.py
@@ -0,0 +1,112 @@
+"""Bind and verify current compile-only artifacts without executing them."""
+import copy
+import hashlib
+import importlib.util
+import json
+import shutil
+import sys
+from pathlib import Path
+
+HERE = Path(__file__).resolve().parent
+RECOVERY = HERE.parent
+META = RECOVERY.parent
+ORIGINAL = META / 'review-manifest-v2.json'
+MANIFEST = HERE / 'manifest.json'
+FROZEN = Path('/tmp/uwz-task5b4-frozen-v2')
+EXPECTED_ORIGINAL = '5a47148bd2c9857a0cbe9b5b5ea8760c4eeadefbdf3651cb583d154373e73b07'
+EXPECTED = {'debug': '7ec029babf71b0335cf2b5f0fc83774d21a3692ec1de0580413063ae617ca388', 'release': '30d443388a5a178be447150c3701ad912eed3c9dc27014122b91390cb2381b5a'}
+
+def digest(path):
+    h = hashlib.sha256()
+    with open(path, 'rb') as f:
+        while data := f.read(1048576): h.update(data)
+    return h.hexdigest()
+
+def module(name, path):
+    spec = importlib.util.spec_from_file_location(name, path)
+    obj = importlib.util.module_from_spec(spec)
+    spec.loader.exec_module(obj)
+    return obj
+
+def validate_builds():
+    closure = module('build_closure', FROZEN / 'build_closure.py')
+    old = [json.loads((META / ('fixture-' + mode + '-final.json')).read_text()) for mode in ('debug', 'release')]
+    fresh = [json.loads((RECOVERY / (mode + '.json')).read_text()) for mode in ('debug', 'release')]
+    receipts, commands = [], []
+    current = {}
+    for mode, historical, actual in zip(('debug', 'release'), old, fresh):
+        assert actual['argv'] == historical['argv'] and actual['cwd'] == historical['cwd']
+        assert actual['optimization'] == historical['optimization'] and actual['exit_status'] == 0
+        assert actual['before'] == historical['input_sha256'] and actual['after'] == historical['input_after']
+        assert actual['source_tree_before_after'] == historical['source_tree_sha256'] == historical['source_after_sha256']
+        assert actual['override_before_after'] == historical['override_before'] == historical['override_after']
+        assert actual['binary_sha256'] == EXPECTED[mode] and actual['expected_binary_sha256'] == historical['binary_sha256']
+        assert (RECOVERY / actual['raw_output_file']).read_bytes() == b''
+        original_binary = Path('/tmp/uwz-task5b4-final-' + mode + '/profile')
+        destination = Path('/tmp/uwz-task5b4-current-' + mode + '/profile')
+        assert digest(original_binary) == digest(destination) == actual['binary_sha256']
+        assert destination.stat().st_mode & 0o111 and destination.stat().st_mode & 0o777 == original_binary.stat().st_mode & 0o777
+        # Explicit canonical mapping from the recovery receipt schema.
+        mapped = {'argv': actual['argv'], 'optimization': actual['optimization'], 'exit_status': actual['exit_status'], 'inputs_unchanged': actual['before'] == actual['after'], 'input_sha256': actual['before'], 'input_after': actual['after']}
+        receipts.append(mapped)
+        commands.append({'argv': actual['argv'], 'input_sha256': actual['before']})
+        current.update({p: digest(p) for p in actual['before']})
+    reviewed = json.loads((META.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
+    archives = {p: reviewed[p] for p in closure.ARCHIVES}
+    merged = closure.validate_receipts(receipts, commands, current, archives)
+    broken = copy.deepcopy(receipts)
+    broken[0]['input_after'][next(iter(broken[0]['input_after']))] = '0' * 64
+    try:
+        closure.validate_receipts(broken, commands, current, archives)
+    except ValueError:
+        pass
+    else:
+        raise AssertionError('validator accepted mutated after map')
+    return merged
+
+def main():
+    assert digest(ORIGINAL) == EXPECTED_ORIGINAL
+    base = json.loads(ORIGINAL.read_text())
+    if sys.argv[1] == 'create':
+        assert not MANIFEST.exists()
+        for mode in ('debug', 'release'):
+            src = Path('/tmp/uwz-task5b4-final-' + mode + '/profile')
+            dest = Path('/tmp/uwz-task5b4-current-' + mode + '/profile')
+            assert digest(src) == EXPECTED[mode]
+            dest.parent.mkdir(parents=True, exist_ok=True)
+            if dest.exists():
+                assert digest(dest) == EXPECTED[mode] and dest.stat().st_mode & 0o777 == src.stat().st_mode & 0o777
+            else:
+                shutil.copy2(src, dest)
+        merged = validate_builds()
+        for mode in ('debug', 'release'):
+            del base['inputs']['/tmp/uwz-task5b4-final-' + mode + '/profile']
+            path = '/tmp/uwz-task5b4-current-' + mode + '/profile'
+            base['inputs'][path] = EXPECTED[mode]
+        base['inputs'].update(merged)
+        for path in [ORIGINAL, RECOVERY / 'restored-source.json', RECOVERY / 'replay.py', RECOVERY / 'environment.json', RECOVERY / 'debug.json', RECOVERY / 'release.json', RECOVERY / 'debug.log', RECOVERY / 'release.log', Path(__file__).resolve()]:
+            base['inputs'][str(path)] = digest(path)
+        base['binary'] = '/tmp/uwz-task5b4-current-release/profile'
+        base['build_input_receipts'] = [str(RECOVERY / 'debug.json'), str(RECOVERY / 'release.json')]
+        base['scope'] = 'fresh current builds and runtime closure; historical binary reproduction unproved'
+        base['historical_binary_mismatch'] = {mode: {'recorded': old, 'current': EXPECTED[mode]} for mode, old in [('debug', '5f480df3ebe4914a4e111e1afeb4c9a8d1285cab1cd77ac11cb67a756552f9b9'), ('release', 'b65535456c7ea43a30d1370b54f4747a672a5f8db4a69c348cec99cf17cc81c2')]}
+        MANIFEST.write_text(json.dumps(base, sort_keys=True, indent=2) + '\n')
+        print('created manifest sha256:', digest(MANIFEST))
+    elif sys.argv[1] == 'check':
+        merged = validate_builds()
+        current_manifest = json.loads(MANIFEST.read_text())
+        assert all(current_manifest['inputs'][k] == v for k, v in merged.items())
+        assert not any('/tmp/uwz-task5b4-final-' in p for p in current_manifest['inputs'])
+        runner = module('inert_runner', FROZEN / 'run_live.py')
+        checked = runner.check_manifest(MANIFEST, digest(MANIFEST))
+        assert checked['binary'] == '/tmp/uwz-task5b4-current-release/profile'
+        assert len(checked['inputs']) == len(base['inputs']) + 9
+        print('validated both actual receipts: 13 direct inputs, 6 reviewed archives; mutated after-map rejected')
+        print('inert runner manifest check:', len(checked['inputs']), 'inputs,', len(checked['trees']), 'trees')
+        print('manifest sha256:', digest(MANIFEST))
+        print('current debug sha256:', digest('/tmp/uwz-task5b4-current-debug/profile'))
+        print('current release sha256:', digest('/tmp/uwz-task5b4-current-release/profile'))
+    else:
+        raise ValueError('expected create or check')
+
+if __name__ == '__main__': main()

## /workspaces/uWebZockets/.uwz-work/tools/restore-metadata-inputs-2026-10-29.py (131 lines; SHA8c99c647dddf9806795c9d63b7a8757b11659886266b5edc8dfe6cc6977197a2)
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/tools/restore-metadata-inputs-2026-10-29.py
@@ -0,0 +1,131 @@
+"""Recover exact reviewed inputs from retained bytes without executing them."""
+import hashlib
+import json
+from pathlib import Path, PurePosixPath
+import subprocess
+import tarfile
+
+
+def digest(data):
+    return hashlib.sha256(data).hexdigest()
+
+
+def write_exact(destination, relative, expected, data):
+    name = PurePosixPath(relative)
+    assert not name.is_absolute() and '..' not in name.parts
+    assert digest(data) == expected
+    target = destination / relative
+    target.parent.mkdir(parents=True, exist_ok=True)
+    if target.exists():
+        assert target.read_bytes() == data
+        return
+    target.write_bytes(data)
+    target.chmod(0o444)
+
+
+def accept_bytes(destination, needed, provenance, data, origin):
+    identity = digest(data)
+    matches = needed.pop(identity, ())
+    for relative in matches:
+        write_exact(destination, relative, identity, data)
+        provenance[relative] = origin
+
+
+def inventory(destination):
+    return {p.relative_to(destination).as_posix(): digest(p.read_bytes())
+            for p in sorted(destination.rglob('*')) if p.is_file()}
+
+
+def restore_source(root, destination, expected):
+    destination.mkdir(exist_ok=True)
+    actual = inventory(destination)
+    assert all(expected.get(name) == identity for name, identity in actual.items())
+    previous = json.loads((root / '.uwz-work/evidence/h2-streaming/body-queue/restored-2026-10-28.json').read_text())['provenance']
+    needed = {}
+    provenance = {}
+    for relative, identity in expected.items():
+        if relative in actual:
+            provenance[relative] = 'verified partial recovery from first pass'
+            continue
+        candidates = [root / relative]
+        origin = previous.get(relative, '')
+        if origin.startswith('preserved-snapshot:'):
+            candidates.append(root / origin.removeprefix('preserved-snapshot:'))
+        for source in candidates:
+            if source.is_file() and not source.is_symlink() and digest(source.read_bytes()) == identity:
+                write_exact(destination, relative, identity, source.read_bytes())
+                provenance[relative] = str(source)
+                break
+        else:
+            needed.setdefault(identity, []).append(relative)
+    names = ('m2_h2_native_tcp', 'm2_h2_native_admission', 'm2_h2_terminal_inputs',
+             'm2_h2_native_startup', 'm2_h2_session_delivery')
+    for name in names:
+        if not needed:
+            break
+        folder = root / 'docs/implement-2-2-0/evidence' / name
+        manifest = json.loads((folder / 'manifest.json').read_text())
+        archive = folder / manifest['archive']
+        with tarfile.open(archive, 'r:gz') as reader:
+            for member in reader:
+                if member.isfile():
+                    accept_bytes(destination, needed, provenance, reader.extractfile(member).read(),
+                                 str(archive) + ':' + member.name)
+    candidates = (root / '.uwz-work/evidence').rglob('*')
+    for source in candidates:
+        if not needed:
+            break
+        if source.is_file() and not source.is_symlink() and source.stat().st_size <= 2 * 1024 * 1024:
+            accept_bytes(destination, needed, provenance, source.read_bytes(), str(source))
+    assert not needed, {'missing_hashes': list(needed)}
+    assert inventory(destination) == expected
+    return provenance
+
+
+def restore_override(root, destination, expected):
+    destination.mkdir()
+    repository = root / '.uwz-work/drafts/libxev-udp-fix'
+    commit = 'c223bd886c6a51d2cd60def39dd9a68d701fea73'
+    for relative, identity in expected.items():
+        data = subprocess.run(['git', '-C', str(repository), 'show', commit + ':' + relative],
+                              check=True, capture_output=True).stdout
+        write_exact(destination, relative, identity, data)
+    assert inventory(destination) == expected
+
+
+def main():
+    root = Path('/workspaces/uWebZockets')
+    manifest_path = root / '.uwz-work/evidence/h2-streaming/integration-owned/metadata/review-manifest-v2.json'
+    assert digest(manifest_path.read_bytes()) == '5a47148bd2c9857a0cbe9b5b5ea8760c4eeadefbdf3651cb583d154373e73b07'
+    manifest = json.loads(manifest_path.read_text())
+    source = Path('/tmp/uwz-task4d-fix1-frozen')
+    override = Path('/tmp/uwz-reviewed-libxev-c223-loop-callbacks')
+    frozen = Path('/tmp/uwz-task5b4-frozen-v2')
+    assert not override.exists() and not frozen.exists()
+    provenance = restore_source(root, source, manifest['trees'][str(source)])
+    restore_override(root, override, manifest['trees'][str(override)])
+    frozen.mkdir()
+    fixture = manifest_path.parent
+    for relative, identity in manifest['trees'][str(frozen)].items():
+        write_exact(frozen, relative, identity, (fixture / relative).read_bytes())
+    assert inventory(frozen) == manifest['trees'][str(frozen)]
+    pairs = list(inventory(source).items())
+    source_sha = digest(json.dumps(pairs).encode())
+    assert source_sha == 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de'
+    for directory in (source, override, frozen):
+        for path in sorted(directory.rglob('*'), reverse=True):
+            if path.is_dir():
+                path.chmod(0o555)
+        directory.chmod(0o555)
+    output = fixture / 'recovery-2026-10-29'
+    output.mkdir()
+    result = {'source_digest': source_sha, 'source_files': len(pairs), 'source_provenance': provenance,
+              'override_files': 93, 'fixture_files': len(manifest['trees'][str(frozen)]),
+              'network_contact': False, 'native_execution': False,
+              'prior_receipts_manifests_unchanged': True}
+    (output / 'restored-source.json').write_text(json.dumps(result, indent=2) + '\n')
+    print(json.dumps({k: v for k, v in result.items() if k != 'source_provenance'}))
+
+
+if __name__ == '__main__':
+    main()
