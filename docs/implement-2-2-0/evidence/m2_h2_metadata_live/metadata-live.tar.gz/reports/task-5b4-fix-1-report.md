# Task 5b4 fix round 1

Ready for scoped independent re-review of P2. The fresh fix removes inactive 65536-byte credit hash generation and unused `cases.expected` argument, unused credit helpers and API entries, impossible `concurrent_refused` condition and unused `partial_done` field. It retains `get_metrics` and its post-case zero-active assertion, active flow ledger, public-window checks, response accounting and other metadata/process assertions. Fixed sources are in `.uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/`; the frozen 10-file subject is `/tmp/uwz-task5b4-fix1-frozen`.

The fixed subject's current manifest is `.uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/manifest.json`, SHA-256 `1cc2e55ec90df730ddb8b0765225dc4e8c8191c76452a899564a1bbd96ff6fd7`. It binds actual Debug `/tmp/uwz-task5b4-fix1-debug/profile` SHA-256 `7c59ee53ba461f2270274fa5183a877d312da8be9974c4098975e88dcbb83c46` and ReleaseSafe `/tmp/uwz-task5b4-fix1-release/profile` SHA-256 `64d71a53344a840bf2d33786a3b0c4757257406f6bb91ae848ad70f33d24a998`, both from real `-j2` compiler invocations with the warm original cache paths. Complete actual argv, cwd, optimization, 13 direct hashes before/after, source and six tree maps before/after, status and binary hashes are in fix1 `debug.json` (SHA-256 `0e9becfecb43b456e9409665b9d9bdcfc22fbcd5e15d3c8bb402828186403de2`) and `release.json` (SHA-256 `43d79650b07cb794370410958b871dc88bf6cc0cf521a4cc23f14aa15487a0c5`). Their raw combined logs are each empty. The command takes original compile argv and changes only the profile module path and output path; no compiler/backend/capacity/assertion change.

Fresh commands and raw outcomes:

```text
python3 -B .uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/check_contract.py .uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/check_contract.py", line 11, in <module>
    assert [x.arg for x in expected.args.args] == ['tag', 'selected', 'empty_hash']
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError
```

The initial check failed before the change because `expected` still had the obsolete fourth argument; no fake runtime failure was introduced. After the edit:

```text
python3 -B .uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/check_contract.py /tmp/uwz-task5b4-fix1-frozen
metadata-only interface, inactive scaffolding removal, retained active guard and record expectations: OK

python3 -B .uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/compile.py
preflight original current closure: OK; fixed frozen files: 10
debug exit 0 output bytes 0 sha256 7c59ee53ba461f2270274fa5183a877d312da8be9974c4098975e88dcbb83c46 unchanged True
release exit 0 output bytes 0 sha256 64d71a53344a840bf2d33786a3b0c4757257406f6bb91ae848ad70f33d24a998 unchanged True

python3 -B .uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/bind.py create
created fix1 manifest sha256: 1cc2e55ec90df730ddb8b0765225dc4e8c8191c76452a899564a1bbd96ff6fd7

python3 -B .uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/bind.py check
validated two actual receipts, 13 direct inputs and six reviewed archives
inert manifest check: 2455 inputs, 6 trees
fix1 manifest sha256: 1cc2e55ec90df730ddb8b0765225dc4e8c8191c76452a899564a1bbd96ff6fd7
```

All post-edit commands exited 0. `/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check /tmp/uwz-task5b4-fix1-frozen/profile.zig` exited 0 without output. Parsing the nine frozen Python files with `ast.parse` exited 0, printing `frozen Python AST parsed: 9`. The pure contract check covers amended caller/callee signature, selected and spare record data, explicit metadata API keys, absence of inactive scaffolding and retention of the post-case active guard. It does not simulate network or callbacks.

The build scripts validate the prior current closure and full trees before and after both compiles; the binder validates both actual receipts and current 13-input maps with the existing build-closure validator, including six reviewed archives, then binds fixed frozen modules, actual binaries, receipts/logs and complete tool/runtime closure. The frozen runner was imported inertly only for `check_manifest`. Frozen profile, runner and cases SHA-256 are respectively `5d96ef21b7a2b758cd285b648699df5b1bbbbe9c33d1fa7c274e4d30e6d004fd`, `f5553e9da9ac83cd14c9d0ea25ba48d2f2d26c764deb6177f49080b06d3064e7`, and `d5f26f9a6c53b82e3b2c3ba176e178065613f753b5d30b95e19918da094a0dbb`. Previous current manifest remains `4c24ae205154e1ffda807e2d10083488051ce13a9544f776748a04659f1852ea`; historical evidence and its unproved binary reproduction remain unchanged. No prior binary is a runtime input in the new manifest.

No native execution, fixtures, client, server, socket, certificate, binary help, full tests or forbidden probes were run. Independent re-review and a separate Root release are needed before a host run. Metadata native behavior remains unproved. The 40-ID plan remains 25 proved and 15 remaining, including this case and 14 later Task 5c IDs. M2, full combined matrix, H3, multipart, full quality/platform/physical gates, maintained publication, adoption and original milestones remain open.
