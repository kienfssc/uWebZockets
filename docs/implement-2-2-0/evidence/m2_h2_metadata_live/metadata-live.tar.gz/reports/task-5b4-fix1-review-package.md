# Task5b4 round1 scoped fix diff
Base: frozen-v2/currentmanifest4c24ae20…; new frozenfix1/manifest1cc2e55ec90df730ddb8b0765225dc4e8c8191c76452a899564a1bbd96ff6fd7. Root30f27ab unchanged. Only new test-only metadata package; no product/pin edit or native run.
--- /tmp/uwz-task5b4-frozen-v2/cases.py
+++ /tmp/uwz-task5b4-fix1-frozen/cases.py
@@ -1,21 +1,21 @@
 """Bounded metadata case; import performs no I/O."""
 CASES = ('metadata_helpers', 'shutdown_idle')
 TAGS = ('metadata_helpers',) + tuple('spare_%02d' % i for i in range(31))
 GROUPS = {'metadata_helpers': ('metadata_helpers',)}
 
 
 def selected_tags(cases):
     return {'metadata_helpers'} if 'metadata_helpers' in cases else set()
 
 
-def expected(tag, selected, empty_hash, _credit_hash):
+def expected(tag, selected, empty_hash):
     touched = tag in selected
     return {'tag': tag, 'middleware': int(touched), 'attempts': int(touched), 'begin': int(touched),
             'end': int(touched), 'cancel': 0, 'failure': 0, 'accepted': 32 if touched else 0,
             'sha256': '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5' if touched else empty_hash,
             'active': False, 'paused': False, 'reason': 'none', 'metadata_middleware': int(touched),
             'helpers_begin': int(touched), 'helpers_end': int(touched), 'metadata_begin': int(touched),
             'metadata_end': int(touched), 'errors': 0}
 
 
 def verify_record(actual, expected_record):
--- /tmp/uwz-task5b4-frozen-v2/profile.zig
+++ /tmp/uwz-task5b4-fix1-frozen/profile.zig
@@ -64,21 +64,20 @@
     failures: u32 = 0,
     errors: u32 = 0,
     active: bool = false,
     paused: bool = false,
     reason: ?uz.BodyCancelReason = null,
     metadata_middleware: u32 = 0,
     helpers_begin: u32 = 0,
     helpers_end: u32 = 0,
     metadata_begin: u32 = 0,
     metadata_end: u32 = 0,
-    partial_done: bool = false,
 };
 const Slot = struct { record: ?*Record = null, owner: *State = undefined, index: usize = 0 };
 const State = struct {
     slots: [2]Slot = [_]Slot{.{}} ** 2,
     records: [32]Record = [_]Record{.{}} ** 32,
     buffered_middleware: u32 = 0,
     errors: u32 = 0,
 };
 fn tag_index(tag: []const u8) ?usize {
     for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
--- /tmp/uwz-task5b4-frozen-v2/run_live.py
+++ /tmp/uwz-task5b4-fix1-frozen/run_live.py
@@ -320,23 +320,20 @@
         ready_output = capture_snapshot(capture)[0].decode('utf-8')
         capacity = [line for line in ready_output.splitlines() if 'H2_CAPACITY ' in line]
         require(len(capacity) == 1 and 'slab=4098304' in capacity[0], 'fixture capacity differs')
         result['capacity'] = capacity[0]
         require(child_start(child.pid) == start_id and child.poll() is None, 'owned child changed')
         context = ssl.create_default_context(cafile=str(cert))
         context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_3
         context.set_alpn_protocols(['h2'])
         p32 = helper.payload_block(32, 0, 32)
         require(hashlib.sha256(p32).hexdigest() == '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5', 'payload digest differs')
-        credit_hash = hashlib.sha256()
-        for offset in range(0, 65536, 8192):
-            credit_hash.update(helper.payload_block(65536, offset, min(8192, 65536 - offset)))
         responses = {}
         result['connections'] = []
         connection_cases = args.cases
         for case in connection_cases:
             if sock is not None:
                 require(not records and not raw_state['streams'], 'records remain on previous connection')
                 sock.close()
                 sock = None
             deadline = min(overall, time.monotonic() + 30)
             require(child.poll() is None and child_start(child.pid) == start_id, 'owned child changed')
@@ -392,59 +389,38 @@
                 trace['trailer_encoded_header_bytes'] = flush_headers(sock, protocol, deadline, capture, stream)
             def get_status(tag):
                 return status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture)
             def get_metrics():
                 return metrics(sock, protocol, records, raw_state, trace, deadline, wire, capture)
             def do_resume(tag):
                 item = request(sock, protocol, records, raw_state, trace, '/resume/' + tag, deadline, wire, capture, 64)
                 require(item['body'] == 'ok', 'resume failed')
             def pending(stream):
                 require(records[stream]['headers'] is None and not records[stream]['ended'], 'final before resume')
-            def active(count):
-                require(get_metrics()['active'] == count, 'active binding count differs')
-            def initial_credit(stream):
-                ledger = trace['ledger']
-                require(ledger.initial_stream == ledger.connection == ledger.streams[stream].window == 65535, 'initial credit differs')
-                flow.check_public(ledger, protocol.outbound_flow_control_window, {stream: protocol.local_flow_control_window(stream)})
-            def zero_credit(stream):
-                ledger = trace['ledger']
-                require(ledger.connection == ledger.streams[stream].window == ledger.refunded == ledger.streams[stream].refunded == 0, 'zero credit differs')
-                flow.check_public(ledger, protocol.outbound_flow_control_window, {stream: protocol.local_flow_control_window(stream)})
-            def settled_credit(stream, amount):
-                ledger = trace['ledger']
-                while ledger.refunded < amount or ledger.streams[stream].refunded < amount:
-                    receive(sock, protocol, records, raw_state, trace, deadline, wire, capture)
-                require(ledger.refunded == ledger.streams[stream].refunded == amount, 'settled credit differs')
-            def refund_bound(stream, maximum):
-                ledger = trace['ledger']
-                require(ledger.refunded <= maximum and ledger.streams[stream].refunded <= maximum, 'early refund exceeds bound')
             api = {'start': begin, 'finish': finish, 'send': send, 'trailers': trailers, 'status': get_status,
-                   'metrics': get_metrics, 'resume': do_resume, 'pending': pending, 'active': active,
-                   'initial_credit': initial_credit, 'zero_credit': zero_credit, 'settled_credit': settled_credit,
-                   'refund_bound': refund_bound, 'health': lambda: health(sock, protocol, records, raw_state, trace, deadline, wire, capture),
-                   'retire': lambda stream: wire.retire(records, raw_state, stream)}
+                   'resume': do_resume, 'pending': pending}
             cases.execute(api, case)
             require(not records and not raw_state['streams'], 'response records remain after case')
             require(get_metrics()['active'] == 0, 'case has active bindings')
             expected_flow = 32
             require(trace['ledger'].sent == expected_flow, 'case flow total differs')
             result['cases'][case] = observed
             result['connections'].append({'case': case, 'tls': sock.version(), 'alpn': sock.selected_alpn_protocol(),
                                           'events': trace['events'], 'snapshots': trace['snapshots'], 'encoded_header_bytes': trace['encoded_header_bytes'], 'sent_flow': trace['ledger'].sent})
         deadline = min(overall, time.monotonic() + 30)
         final = {tag: status(sock, protocol, records, raw_state, trace, tag, deadline, wire, capture) for tag in cases.TAGS}
         aggregate = metrics(sock, protocol, records, raw_state, trace, deadline, wire, capture)
         selected = cases.selected_tags(args.cases)
         empty_hash = hashlib.sha256(b'').hexdigest()
         for tag in cases.TAGS:
-            cases.verify_record(final[tag], cases.expected(tag, selected, empty_hash, credit_hash.hexdigest()))
-            if tag in selected and tag != 'concurrent_refused':
+            cases.verify_record(final[tag], cases.expected(tag, selected, empty_hash))
+            if tag in selected:
                 require(json.loads(responses[tag]['body']) == final[tag], 'final response differs from status')
         for field in ('middleware', 'attempts', 'begin', 'end', 'cancel', 'failure', 'accepted', 'errors'):
             require(aggregate[field] == sum(record[field] for record in final.values()), 'aggregate ' + field + ' differs')
         require(aggregate['active'] == 0 and not aggregate['slot0_active'] and not aggregate['slot1_active'], 'active fixture')
         result['final_status'] = final
         result['final_metrics'] = aggregate
         sock.close()
         sock = None
         require(child_start(child.pid) == start_id and child.poll() is None, 'child identity changed')
         os.kill(child.pid, signal.SIGTERM)
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/check_contract.py
@@ -0,0 +1,24 @@
+"""Pure checks for the metadata-only caller and case interface."""
+import ast
+import importlib.util
+import sys
+from pathlib import Path
+
+root = Path(sys.argv[1])
+runner = ast.parse((root / 'run_live.py').read_text())
+cases_ast = ast.parse((root / 'cases.py').read_text())
+expected = next(n for n in cases_ast.body if isinstance(n, ast.FunctionDef) and n.name == 'expected')
+assert [x.arg for x in expected.args.args] == ['tag', 'selected', 'empty_hash']
+assert not any(isinstance(n, ast.Name) and n.id in {'credit_hash', 'initial_credit', 'zero_credit', 'settled_credit', 'refund_bound', 'active'} for n in ast.walk(runner))
+assert 'concurrent_refused' not in (root / 'run_live.py').read_text()
+assert 'partial_done' not in (root / 'profile.zig').read_text()
+assert 'get_metrics()[\'active\'] == 0' in (root / 'run_live.py').read_text()
+api = next(n.value for n in ast.walk(runner) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'api' for t in n.targets))
+assert {k.value for k in api.keys} == {'start', 'finish', 'send', 'trailers', 'status', 'resume', 'pending'}
+spec = importlib.util.spec_from_file_location('metadata_cases', root / 'cases.py')
+cases = importlib.util.module_from_spec(spec)
+spec.loader.exec_module(cases)
+assert cases.expected('metadata_helpers', {'metadata_helpers'}, 'empty')['accepted'] == 32
+assert cases.expected('spare_00', {'metadata_helpers'}, 'empty')['sha256'] == 'empty'
+assert len(cases.TAGS) == 32 and len(set(cases.TAGS)) == 32
+print('metadata-only interface, inactive scaffolding removal, retained active guard and record expectations: OK')
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/compile.py
@@ -0,0 +1,64 @@
+"""Compile fixed source with reviewed argv, capturing complete identities."""
+import hashlib
+import importlib.util
+import json
+import subprocess
+from pathlib import Path
+
+HERE = Path(__file__).resolve().parent
+META = HERE.parent
+BASE = META / 'recovery-2026-10-29/current/manifest.json'
+FROZEN = Path('/tmp/uwz-task5b4-fix1-frozen')
+BASE_HASH = '4c24ae205154e1ffda807e2d10083488051ce13a9544f776748a04659f1852ea'
+
+def digest(path):
+    h = hashlib.sha256()
+    with open(path, 'rb') as f:
+        while data := f.read(1048576): h.update(data)
+    return h.hexdigest()
+
+def inventory(path):
+    path = Path(path)
+    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}
+
+def snapshot(manifest):
+    trees = {p: inventory(p) for p in manifest['trees']}
+    assert trees == manifest['trees']
+    assert all(digest(p) == v for p, v in manifest['inputs'].items())
+    fixed = inventory(FROZEN)
+    assert len(fixed) == 10
+    assert all(digest(HERE / n) == value for n, value in fixed.items())
+    return trees, fixed
+
+def main():
+    assert digest(BASE) == BASE_HASH
+    manifest = json.loads(BASE.read_text())
+    trees, fixed = snapshot(manifest)
+    print('preflight original current closure: OK; fixed frozen files:', len(fixed), flush=True)
+    reviewed = json.loads((META.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
+    spec = importlib.util.spec_from_file_location('build_closure', FROZEN / 'build_closure.py')
+    closure = importlib.util.module_from_spec(spec); spec.loader.exec_module(closure)
+    for mode in ('debug', 'release'):
+        old = json.loads((META / ('fixture-' + mode + '-final.json')).read_text())
+        argv = old['argv'].copy()
+        index = next(i for i, x in enumerate(argv) if x.startswith('-Mroot='))
+        argv[index] = '-Mroot=' + str(FROZEN / 'profile.zig')
+        output = Path('/tmp/uwz-task5b4-fix1-' + mode + '/profile')
+        assert not output.exists()
+        output.parent.mkdir(parents=True, exist_ok=True)
+        argv[-1] = '-femit-bin=' + str(output)
+        assert all(Path(argv[argv.index(flag) + 1]).is_dir() for flag in ('--cache-dir', '--global-cache-dir'))
+        before = {p: digest(p) for p in sorted(closure.argv_inputs(argv))}
+        assert len(before) == 13 and all(before[p] == reviewed[p] for p in closure.ARCHIVES)
+        for p, value in old['input_sha256'].items():
+            if p != str(META / 'profile.zig'): assert before[p] == value
+        proc = subprocess.run(argv, cwd=old['cwd'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
+        (HERE / (mode + '.log')).write_bytes(proc.stdout)
+        after = {p: digest(p) for p in before}
+        trees_after, fixed_after = snapshot(manifest)
+        record = {'argv': argv, 'cwd': old['cwd'], 'optimization': old['optimization'], 'input_sha256': before, 'input_after': after, 'inputs_unchanged': before == after and trees == trees_after and fixed == fixed_after, 'trees_before': trees, 'trees_after': trees_after, 'fixed_before': fixed, 'fixed_after': fixed_after, 'exit_status': proc.returncode, 'binary_sha256': digest(output) if output.exists() else None, 'raw_output': str(HERE / (mode + '.log'))}
+        (HERE / (mode + '.json')).write_text(json.dumps(record, indent=2) + '\n')
+        print(mode, 'exit', proc.returncode, 'output bytes', len(proc.stdout), 'sha256', record['binary_sha256'], 'unchanged', record['inputs_unchanged'], flush=True)
+        assert proc.returncode == 0 and record['inputs_unchanged']
+
+if __name__ == '__main__': main()
--- /dev/null
+++ /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/metadata/fix1/bind.py
@@ -0,0 +1,85 @@
+"""Bind fixed current artifacts and verify complete inert closure."""
+import importlib.util
+import json
+import sys
+from pathlib import Path
+
+HERE = Path(__file__).resolve().parent
+META = HERE.parent
+BASE = META / 'recovery-2026-10-29/current/manifest.json'
+FROZEN = Path('/tmp/uwz-task5b4-fix1-frozen')
+OLD_FROZEN = '/tmp/uwz-task5b4-frozen-v2'
+MANIFEST = HERE / 'manifest.json'
+spec = importlib.util.spec_from_file_location('compile_helpers', HERE / 'compile.py')
+helpers = importlib.util.module_from_spec(spec); spec.loader.exec_module(helpers)
+digest = helpers.digest
+
+def module(name, path):
+    spec = importlib.util.spec_from_file_location(name, path)
+    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
+    return result
+
+def validate(base):
+    closure = module('build_closure', FROZEN / 'build_closure.py')
+    receipts, commands = [], []
+    for mode in ('debug', 'release'):
+        actual = json.loads((HERE / (mode + '.json')).read_text())
+        old = json.loads((META / ('fixture-' + mode + '-final.json')).read_text())
+        expected = old['argv'].copy()
+        expected[next(i for i, x in enumerate(expected) if x.startswith('-Mroot='))] = '-Mroot=' + str(FROZEN / 'profile.zig')
+        expected[-1] = '-femit-bin=/tmp/uwz-task5b4-fix1-' + mode + '/profile'
+        assert actual['argv'] == expected and actual['cwd'] == old['cwd']
+        assert actual['trees_before'] == actual['trees_after'] == base['trees']
+        assert actual['fixed_before'] == actual['fixed_after'] == helpers.inventory(FROZEN)
+        assert actual['inputs_unchanged'] and actual['exit_status'] == 0
+        assert Path(actual['raw_output']).read_bytes() == b''
+        assert digest('/tmp/uwz-task5b4-fix1-' + mode + '/profile') == actual['binary_sha256']
+        receipts.append(actual)
+        commands.append({'argv': expected, 'input_sha256': actual['input_sha256']})
+    current = {p: digest(p) for p in receipts[0]['input_sha256']}
+    reviewed = json.loads((META.parent / 'admission/fix1/review-manifest.json').read_text())['inputs']
+    merged = closure.validate_receipts(receipts, commands, current, {p: reviewed[p] for p in closure.ARCHIVES})
+    return receipts, merged
+
+def main():
+    assert digest(BASE) == helpers.BASE_HASH
+    base = json.loads(BASE.read_text())
+    receipts, merged = validate(base)
+    if sys.argv[1] == 'create':
+        assert not MANIFEST.exists()
+        del base['trees'][OLD_FROZEN]
+        del base['tree_counts'][OLD_FROZEN]
+        base['inputs'] = {p: h for p, h in base['inputs'].items() if not p.startswith(OLD_FROZEN + '/') and not p.startswith('/tmp/uwz-task5b4-current-')}
+        fixed = helpers.inventory(FROZEN)
+        base['trees'][str(FROZEN)] = fixed
+        base['tree_counts'][str(FROZEN)] = len(fixed)
+        for n, h in fixed.items():
+            base['inputs'][str(FROZEN / n)] = h
+            assert digest(HERE / n) == h
+            base['inputs'][str(HERE / n)] = h
+        base['inputs'].update(merged)
+        for mode, receipt in zip(('debug', 'release'), receipts):
+            base['inputs']['/tmp/uwz-task5b4-fix1-' + mode + '/profile'] = receipt['binary_sha256']
+        for path in (BASE, HERE / 'compile.py', HERE / 'bind.py', HERE / 'check_contract.py', HERE / 'debug.json', HERE / 'release.json', HERE / 'debug.log', HERE / 'release.log'):
+            base['inputs'][str(path)] = digest(path)
+        for key, name in (('runner', 'run_live.py'), ('cases', 'cases.py'), ('wire', 'wire.py'), ('raw', 'raw_observer.py'), ('flow', 'flow_ledger.py')):
+            base[key] = str(FROZEN / name)
+        base['binary'] = '/tmp/uwz-task5b4-fix1-release/profile'
+        base['build_input_receipts'] = [str(HERE / (mode + '.json')) for mode in ('debug', 'release')]
+        base['scope'] = 'fix1 current actual build and runtime closure; historical binary reproduction unproved'
+        MANIFEST.write_text(json.dumps(base, sort_keys=True, indent=2) + '\n')
+        print('created fix1 manifest sha256:', digest(MANIFEST))
+    elif sys.argv[1] == 'check':
+        manifest = json.loads(MANIFEST.read_text())
+        assert all(manifest['inputs'][p] == h for p, h in merged.items())
+        assert not any(p.startswith('/tmp/uwz-task5b4-current-') or p.startswith(OLD_FROZEN + '/') for p in manifest['inputs'])
+        runner = module('inert_runner', FROZEN / 'run_live.py')
+        checked = runner.check_manifest(MANIFEST, digest(MANIFEST))
+        assert checked['binary'] == '/tmp/uwz-task5b4-fix1-release/profile'
+        print('validated two actual receipts, 13 direct inputs and six reviewed archives')
+        print('inert manifest check:', len(checked['inputs']), 'inputs,', len(checked['trees']), 'trees')
+        print('fix1 manifest sha256:', digest(MANIFEST))
+    else:
+        raise ValueError('expected create or check')
+
+if __name__ == '__main__': main()
