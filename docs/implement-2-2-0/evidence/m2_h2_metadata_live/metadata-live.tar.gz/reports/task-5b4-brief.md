# Task5b4 StageA: overflow metadata and body-helper refusals

Read this first, then task-5b4-architecture.md for exact public signatures and
source locations. Root30f27ab80f0471437c34adcdf7b2d42f58227b74 is clean and
immediately pushed to the existing fork. Task5b3's new native proof is complete
as a scoped checkpoint, not M2/adoption. Preserve all original task-5-plan.md
and other milestone requirements; only metadata_helpers is the new case here.

Own ONLY new .uwz-work/evidence/h2-streaming/integration-owned/metadata/ sources,
evidence and task-5b4 reports. You are not alone; do not revert other edits or
change any old bound source/manifest/build/receipt/tool. No subagents, refs,
commits/push/fetch/downloads/external model CLI or product edits. Graphify before
new source searches; provided immutable paths may be read for named API risks.
Read relevant verification/Zig/testing/API instructions and narrow skills.

Use unchanged /tmp/uwz-task4d-fix1-frozen,1031files,
fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de;
reviewed /tmp/uwz-reviewed-libxev-c223-loop-callbacks,93files; pinned42-file client
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473 and
helper07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00.
Originalr2 c-native binding/six static libs stay unchanged. Source/production
adoption is not authorized. Start from reviewed test-only credit fix1-v2 source
if useful, copying into your new directory, not mutating it.

Keep exact profile8connections,8nativeH2streams,73728receive payload,two reusable
sinkslots,requestline512,headers4096/count80,H1body256,H2body4096,encodedheader8192,
responseheaders4096/count32,captures24,writequeue65536,streamingtrue,unrelated
features/devlogoff. Use real Server.preset(...).build_https; slab4098304 unchanged.
Register the long /meta route as a real BodyRoute with limit100000000/quota2 and
headers_only middleware. Keep32persistent results: one metadata_helpers and
31explicit untouched spares. Record history/owned expectations separately from
reused slots through deinit, no full-body storage, no callback-borrowed request/
view-array/Response/chunk pointers retained. Expected metadata is independently
owned/constants, never copied from actual begin to establish expected end.

Pattern:
/meta/:tag/:p01/:p02/:p03/:p04/:p05/:p06/:p07/:p08/:p09/:p10/:p11/:p12/:p13/:p14/:p15/:p16
POST target:
/meta/metadata_helpers/a01/a02/a03/a04/a05/a06/a07/a08/a09/a10/a11/a12/a13/a14/a15/a16?q=alpha&n=17
Ordinary initial headers in order: content-length:32,x-mode:begin_paused,
x-h00:v00 through x-h62:v62 (63fields). Plus four normal pseudoheaders including
:authority localhost; no extended CONNECT.17captures,pattern90,path86,query12,
target99;65ordinary+4pseudo=69decoded fields,684decoded name/valuebytes,
RFC header-list cost2892,copiedrequest654. All fit existing profile.
Actual HPACK encoded payload length depends on codec state. Record and require
actual cumulative HEADERS/CONTINUATION block payload<=8192 BEFORE flushing those
bytes. Use actual pinned codec output, not a second encoding or decoded cost.
Prefer bounded public hyperframe/codecs to a speculative external parser.

Session synthesizes Host:localhost:66visibleheaders,64inline+2extra (x-h62/Host),
17captures16inline+1extra(p16). Compare all independent method/target/path/query/
protocol(emptyordinaryPOST)/66headerpairs/17capturepairs in middleware, begin
and end using real public accessors/iterators. Legacy Request get_header,
headers/header_entries/get_param already include overflow; inline-only loops
truncate. params.get("P16")null; queryq=alpha,n=17; end stillinitialx-h62:v62,
Host,p16:a16 and no x-trailer-only. Metadata middleware remains metadata-only;
do not apply StreamingRequest BodyNotBuffered semantics to legacy Request.
Append real X-Middleware:retained once and account real bodyhead/metadata checks.

Beginpaused. Send first16 P32/noEOF; SAMEconnection status barrier proves
B1/accepted0/chunks0/E0/C0/paused/no finalHEADERS/end. Send remaining16/noEOF,
then valid trailerHEADERS+EOF x-h62:changed,x-trailer-only:discarded (2fields,
35name/valuebytes,99listcost). Second same barrier unchanged, then publicresume.
Copied controls run on owningloop and can retire binding inline; read only
persistent results and the fresh control Response after call. Final200/32/H32,
BEC1/1/0,A1,F0,M1,0active/errors. H32 is
7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5,
P32 bytes1..10+22-byte final-upload-sentinel!, generated with original helper.
No informational/reset/GOAWAY/response-trailer/earlyEOF, header exactlyonce.

In BOTH begin and end call actual StreamingRequest.text/bytes (empty[]constu8),
json(T,allocator),validate_json(T,allocator),
validate_json_detailed(T,allocator,*uz.schema.Issue),form(),multipart().
All five fallible methods must return exact BodyNotBuffered. Use explicit
uz.BodyReadError result annotations, zero-length caller-ownedFixedBufferAllocator
and Issue{field="untouched",kind=.too_deep}; preserve issue pointer/len/content/
kind and allocator.end_index0. query_params and query_params_of(2) succeed.
Use named untagged-union payload compile-guard pattern at immutable
src/tests/streaming_request_tests.zig35-63 in reachable fixture helper calls;
instantiating actual JSON parsing would fail compilation. No orphan product
support root. Expose meaningful independent metadata/helper counters and errors;
all32records and finalmetrics must match through deinit. Producer-era retention
and >8reuse remain later Task5c, not this callback-only observation.

Selectable unique subsets: metadata_helpers,shutdown_idle (idle last). Fresh
ordinary H2/TLS connection for EACH selectedcase, same owned child. Final32status
snapshots then finalmetrics LAST; no more bufferedrequests before shutdown.
Reuse approved inert imports/explicit--run and exact loaded custommodule/helper
path/hash checks, current true flow/window accounting if needed, ownedPID/start/
nonce/listener/certificate beforehealth on everyconnection. Fixed127.0.0.1:28443,
TLS1.3/h2,privatefresh/tmp output,15ready/30case/900total/15graceful deadlines,
continuouscombinedoutput65536,8192read/generatedspan,body<4096,headers32/4096,
info16/16384,<=8active responses, bounded events/frame/records. Independent
socket/signal/reap/key/log/pipecleanup; forcedcleanup/errorsnever success.

Pin launch env exactly LC_ALL=C.UTF-8 plus fixed package:helperPYTHONPATH and
pinned /home/codespace/.python/current/bin/python3 -B -S; explicit OpenSSLconfig.
Do not reintroduce the single-key locale bug. New manifest binds COMPLETE CURRENT
closure including both actual build recipes/receipts, all13direct inputs/six
archives (verify before/after/current/reviewed hashes), actual frozen modules,
fc69/c223/client/zslay/compiler+library/interpreter+stdlib/loader/TLS/helper.
Historical proofs remain linked by identity, not growing old binary dependency
unions. No assumption that hashing receipt JSON validates named inputs.

StageA allows source, -j2 actual fixedZig0.16 Debug/ReleaseSafe COMPILE ONLY,
format/AST/identity and meaningful pure actual pinned-codec/caller-data checks.
Reuse compiler caches; outputs/source/graph/temp copies stay/tmp. Preserve all
intermediates/failures/commands. Do not manufacture behavioral red with fake I/O,
nativecallbacks/results; qualify pure coverage exactly. No native fixture/client/
server/socket/certificate execution, binary--help/fulltests or stopped/native
cancellation/race/fault/resource/kernel/fd/completion/panic/leak/crash probes.
The earlier default credit startup and historical denied/stopped cases stay
preserved; do not repeat them. Any future ordinary host run requires independent
review and separate exact Root authorization, not this source-preparation brief.

Work in bounded internal pieces: fixture/helper contract+bothcompile receipts,
then coherent driver/encoded-header observation/freeze/currentclosure. Continue
until StageA DONE; do not stop at generic partial progress. Write
task-5b4-report.md (plus scoped step reports if useful) with exactcommands/raw
outputs/hashes/bounds/remaininggaps. StageA DONE requires actual both builds and
coherent frozen selectable driver/current manifest, ready for independent review.
Prior25proved H2 IDs, this one unproved case, remaining14Task5c IDs and full
combinedmatrix stay explicit as data. Eventual combined history needs>=34 before
Task5c (plus core records if not yet counted); no silent32historyreuse or
productioncapacity increase. H3/multipart/physical/platform/fullquality/genuine
earlydata/maintainedpublication/adoption and original milestones all remain open.
