# Task5b4 current-artifact recovery after pause

Read this first, then task-5b4-brief.md and task-5b4-report.md. Original worker
completed StageA before the user paused. Goal is active again on2026-10-29;
Rootbranch30f27ab is clean/synced. Original worker handle is authoritatively
missing, so this is a fresh bounded recovery assignment, not repeated feature
implementation. No independent review or native metadata run has happened.

Temporary storage was cleared. Root restored exact bytes, WITHOUT executing
candidate code, for:
- /tmp/uwz-task4d-fix1-frozen,1031files,
  fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de;
- /tmp/uwz-reviewed-libxev-c223-loop-callbacks,93files from local Git objects;
- /tmp/uwz-task5b4-frozen-v2,10files matching original manifest;
- /tmp/uwz-h2-client-tooling/packages,42files,
  0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473,
  using retained wheels/no network/package scripts.
Root restoration record is metadata/recovery-2026-10-29/restored-source.json;
new Root script .uwz-work/tools/restore-metadata-inputs-2026-10-29.py. Firstpass
restored1016files, then remaining15 from preserved provenance snapshots. No old
receipt/manifest/source was rewritten. All2413non-/tmp individual inputs match
the old manifest now; no missing or changed persistent inputs were found.

Own ONLY new files under integration-owned/metadata/recovery-2026-10-29/ and a
new task-5b4-recovery-report.md. Root owns restored-source.json; preserve it.
You are not alone. No product/old-source/old-receipt/old-manifest/tool edits,
reverts, subagents, refs/commit/push/fetch/download/external CLI. All original
scope/capacities/API/metadata/helper/process bounds remain exactly binding.
Graphify before new code exploration; given located files may be read.

The TWO original binaries were lost:
/tmp/uwz-task5b4-final-debug/profile (expectedSHA
5f480df3ebe4914a4e111e1afeb4c9a8d1285cab1cd77ac11cb67a756552f9b9),
/tmp/uwz-task5b4-final-release/profile (expectedSHA
b65535456c7ea43a30d1370b54f4747a672a5f8db4a69c348cec99cf17cc81c2).
Rebuild both using the exact actual argv/cwd from existing
metadata/fixture-{debug,release}-final.json, fixedZig0.16 and-j2. Original output
paths are absent. Cache folders are also absent; create their specified cache/
global directories or document a separately chosen cache-only relocation. Do
not overwrite original compile receipts or invoke prepare.py in a way that
rewrites them. A new narrow replay script may read the receipts and record its
actual command, current before/after source/input hashes, complete raw output,
exit status and binary hash in the NEW recovery directory.

Validate every source/tree/directinput/archive against original reviewed
identities before compilation; preserve the old13-input maps and six archives.
Do not change source, capacities, assertions, compiler/backend or dependency
pins to make reproduction pass. After successful compile, compare actual new
binary against expected original hash. If a hash differs, preserve the result
and report the exact difference and environment/recipe evidence to Root before
rebasing any manifest; do not silently change expected identities.

When both artifacts match, verify the original v2 manifest/current closure and
compiled profile c12ecc91a886f015f46bc809284666d46195d786536a28a8de49e548d6fe85b1
remain coherent. Original manifest SHA
5a47148bd2c9857a0cbe9b5b5ea8760c4eeadefbdf3651cb583d154373e73b07.
Record the fresh audit and one scoped pure pinned-codec/AST check if needed for
the reconstructed package. Distinguish historical checks from fresh recovery
commands. No already completed unrelated test/suite or historical binary needs
rebuilding. Focus on this COMPLETE CURRENT closure only.

Allowed: source/identity/file copying, compiler execution ONLY, AST and actual
pure codec/caller-data checks. Forbidden: native fixture/client/server/socket/
certificate execution, binary--help, fulltests, fault/resource/kernel/fd/race/
injectedcompletion/panic/leak/crash probes or stopped/denied experiments. Old
credit default startup remains preserved; no retry. This authorizes NO live
execution. Future ordinary host run requires independent source review and a
separate exact Root release.

Write task-5b4-recovery-report.md with exact commands, raw outcomes, hashes,
source/old-evidence preservation and concerns. DONE requires both actual restored
artifacts plus current original closure passing, ready for first independent
review. If reproduction differs, return the evidence without guessing. Full
40ID plan,25proved/15remaining,14laterTask5c IDs/fullcombined/H3/multipart/all
gates/adoption/original milestones remain open. Keep memory/cache/output under
/tmp; never delete code/history/evidence for disk space.
