# Task 5b4 fresh current build binding

The new current subject is ready for its first independent source review. It binds the two actual successful fresh compile-only artifacts; it does not reproduce or replace the historical binary identities, and does not prove native behavior. Root ruled that the fresh builds may form a new subject after reading the mismatch evidence. The cause of the historical mismatch remains unproved.

Current manifest: `.uwz-work/evidence/h2-streaming/integration-owned/metadata/recovery-2026-10-29/current/manifest.json`, SHA-256 `4c24ae205154e1ffda807e2d10083488051ce13a9544f776748a04659f1852ea`. Its runtime binary is `/tmp/uwz-task5b4-current-release/profile` SHA-256 `30d443388a5a178be447150c3701ad912eed3c9dc27014122b91390cb2381b5a`; the separately bound Debug copy is `/tmp/uwz-task5b4-current-debug/profile` SHA-256 `7ec029babf71b0335cf2b5f0fc83774d21a3692ec1de0580413063ae617ca388`. Each copy matches its fresh output and fresh receipt, including executable mode. No compiler rerun occurred.

The new manifest derives from the original v2 complete input and tree closure, replaces only the two old binary paths with the two current paths, and adds the original manifest and recovery provenance, actual fresh receipts and empty logs, replay script, environment record, Root restoration record and current binding script. The old receipts remain included as historical data, and the old binary hashes are explicitly labeled as historical mismatches. No unrelated old binaries were added. Frozen source paths and hashes, current runtime assertions, source/tool/compiler/library trees and process bounds remain unchanged.

The binding script explicitly maps fresh receipt `before` and `after` maps to the pinned `build_closure.validate_receipts` schema, checks each actual argv and cwd against the original recipe, checks both actual output hashes against the fresh receipts, hashes all 13 current direct inputs and compares the six archives to the reviewed admission manifest. It checks both compiler modes, success status, empty logs, source and override identities, and verifies rejection of a changed after-map. The frozen runner is imported inertly solely to call its identity checker; no main, run, socket or TLS constructor was called.

Fresh commands and raw output:

```text
python3 .uwz-work/evidence/h2-streaming/integration-owned/metadata/recovery-2026-10-29/current/bind.py create
created manifest sha256: 4c24ae205154e1ffda807e2d10083488051ce13a9544f776748a04659f1852ea

python3 -B .uwz-work/evidence/h2-streaming/integration-owned/metadata/recovery-2026-10-29/current/bind.py check
validated both actual receipts: 13 direct inputs, 6 reviewed archives; mutated after-map rejected
inert runner manifest check: 2437 inputs, 6 trees
manifest sha256: 4c24ae205154e1ffda807e2d10083488051ce13a9544f776748a04659f1852ea
current debug sha256: 7ec029babf71b0335cf2b5f0fc83774d21a3692ec1de0580413063ae617ca388
current release sha256: 30d443388a5a178be447150c3701ad912eed3c9dc27014122b91390cb2381b5a
```

Both commands exited 0. `python3 -B` with `ast.parse` on `current/bind.py` exited 0 and printed `current binding AST parsed: 1`. The source script SHA-256 is `da8ebb6272c03a51428c1044fd25af634cbffab3b15e8affde66b0598728c0f1`. The inert checker verifies full inventories and hashes including the 10 frozen sources, 1031-file source tree, 93-file override, client package and Zig library tree, plus every manifest input. The original v2 manifest remains SHA-256 `5a47148bd2c9857a0cbe9b5b5ea8760c4eeadefbdf3651cb583d154373e73b07`; Root's restoration record remains `391b6356b5e6189f31d6ae083372982621e452fecd5e3df5d2315296edc74193`.

The prior recovery report records exact fresh Debug and ReleaseSafe compile commands, empty raw compiler output, exit statuses and historical mismatch. Its codec and AST observations were not rerun here. No native binary, fixture, server, client, socket, certificate, binary-help, full test or prohibited probe was executed. First independent source review and a separate exact Root release remain prerequisites for a future host run. The 40-ID plan remains 25 proved and 15 remaining, including this case and 14 Task 5c IDs; full combined matrix, H3, multipart, platform and quality gates, adoption and all original milestones remain open.
