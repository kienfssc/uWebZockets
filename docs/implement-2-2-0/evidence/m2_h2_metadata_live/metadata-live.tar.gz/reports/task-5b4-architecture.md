# Task5b4: source-backed metadata and helper coverage

Root adopts the read-only architect result for later preparation. No code,
compilation or runtime follows from this plan. All references are in immutable
/tmp/uwz-task4d-fix1-frozen. Production/profile/two sink slots remain unchanged.

## Public contract

StreamingRequest.text()/bytes() return empty []const u8. json(T,allocator),
validate_json(T,allocator), validate_json_detailed(T,allocator,*uz.schema.Issue)
return uz.BodyReadError!std.json.Parsed(T); form() returns
uz.BodyReadError!uz.query.QueryParams; multipart() returns
uz.BodyReadError!uz.multipart.Parser. BodyReadError is exactly BodyNotBuffered.
query_params() and query_params_of(capacity) are ordinary metadata helpers.
Issue has field:[]constu8 and kind:IssueKind; there is no separate schema argument
to these streaming helper calls. Source streaming_request8-97,schema3-48,
root35-41/105/113.

Metadata fields: method,target,path,protocol,query. Headers get/entries include
case-insensitive lookup; params.get is case-sensitive. Query values are raw
borrowed byte slices (fetch77-99,query1-6/98-104). The protocol field is the
extended-CONNECT token, empty for ordinary POST, not an HTTP-version string.

## One exact case

Register /meta/:tag/:p01/:p02/:p03/:p04/:p05/:p06/:p07/:p08/:p09/:p10/:p11/:p12/:p13/:p14/:p15/:p16.
POST /meta/metadata_helpers/a01/a02/a03/a04/a05/a06/a07/a08/a09/a10/a11/a12/a13/a14/a15/a16?q=alpha&n=17.
Initial ordinary headers, in order: content-length:32; x-mode:begin_paused;
x-h00:v00 through x-h62:v62 (63 fields). Freeze this mode spelling or recompute
all arithmetic if an equivalent fixture tag policy changes it.

Bounds:17 captures(tag+p01..p16), pattern90 bytes,path86,query12,target99,
65ordinary wire fields+4pseudo=69decoded fields,684decoded name/value bytes,
RFC header-list cost2892, copied-request bytes654. All fit80/4096/512 limits.
Actual HPACK encoded block length depends on encoder state: record actual
cumulative header-block payload and require<=8192 before flushing, rather than
calling decoded2892 the encoded size (hpack456-480).

Session synthesizes host:localhost from authority: public metadata has66headers,
64inline+2extra, not65. Overflow fields are x-h62 and synthesizedHost. Captures
are16inline+1extra(p16). Source server1873-1906.

Begin is paused. Send first16 P32 bytes withoutEOF; same-connection status proves
begin1/accepted0/chunks0/end0/cancel0. Send remaining16 withoutEOF, then trailing
HEADERS+EOF x-h62:changed and x-trailer-only:discarded. Trailers have2fields,
35name/value bytes,99listcost. Second status is still0accepted/0chunks/noend,
then publicresume. Final200/32/H32, B/E/C1/1/0,A1,F0,M1; final middlewareheader
exactlyonce. No info/reset/GOAWAY/response-trailer/earlyEOF. Begin/end both compare
all independent initial expectations, overflowx-h62:v62,Host andp16:a16; trailer-only
absent andx-h62 unchanged. params.get("P16")null, queryq=alpha,n=17. Source trailer
EOF/discard retains initial Request atserver1254-1296.

## Legacy middleware and ownership

Legacy Request already supports overflow through get_header,headers(),
header_entries() andget_param. body_admission41-56 installs extras/captures before
middleware; radix1100-1108 passes that same pointer. Accessors include overflow
(request77-134/393-405; streaming_request43-60). Inline-only iteration truncates.
Middleware can verify64+2headers and16+1captures through accessors/iterators.
Keep it metadata-only; its empty legacy body does not have StreamingRequest's
BodyNotBuffered helper semantics. No unsupported legacy-overflow conflict found.

Prepare independent expected method/target/path/query/all66header pairs/all17
capture pairs once in stable owned storage. Never use actual begin metadata as
the expected end snapshot. Store check results/owned expected bytes only; no
Request/StreamingRequest/Response/view-array/chunk pointers retained beyond their
callback. Producer-era metadata retention remainsTask5c.

Run all helper refusals in both begin and end with a zero-length caller-owned
FixedBufferAllocator, explicit BodyReadError result annotations and
Issue{field="untouched",kind=.too_deep}. Require all five exact BodyNotBuffered,
unchanged issue field pointer/length/content/kind and allocator.end_index0;
text/bytes empty and query helpers succeed. Reuse the named untagged-union
payload compile-guard pattern from src/tests/streaming_request_tests.zig35-63:
actual JSON parser instantiation would fail to compile. Put calls in reachable
fixture helper checks, not a new orphan product support root. Do not execute a
compiler probe or native fixture merely from this planning result.

One persistent body record adds to the prior combined minimum33, yielding34
beforeTask5c. Explicitly resolve the eventual combined fixed-record/log bound;
isolated case fits current capacities. All later5c/fullmilestone gates remain.
