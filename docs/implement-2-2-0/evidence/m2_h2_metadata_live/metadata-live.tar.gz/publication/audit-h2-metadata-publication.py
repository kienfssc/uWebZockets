"""Independently check the publication against retained result and source bytes."""
import hashlib
import json
import re
import subprocess
import tarfile
from pathlib import Path, PurePosixPath


root = Path('/workspaces/uWebZockets')
output = root / 'docs/implement-2-2-0/evidence/m2_h2_metadata_live'
manifest = json.loads((output / 'manifest.json').read_text())
archive = output / manifest['archive']
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(archive.read_bytes()) == manifest['archive_sha256']
assert archive.stat().st_size == manifest['archive_bytes']
with tarfile.open(archive, 'r:gz') as tar:
    entries = tar.getmembers()
    assert len(entries) == manifest['safe_regular_members'] == len({e.name for e in entries})
    data = {}
    for entry in entries:
        path = PurePosixPath(entry.name)
        assert entry.isfile() and entry.mode == 0o644
        assert not path.is_absolute() and '..' not in path.parts and '__pycache__' not in path.parts
        payload = tar.extractfile(entry).read()
        payload.decode('utf-8')
        assert not payload.startswith((b'\x7fELF', b'\0asm'))
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[0-9A-Z]{16}', payload)
        data[entry.name] = payload
inventory = json.loads(data['inventory.json'])['files']
assert len(inventory) == manifest['inventory_entries']
assert {row['path'] for row in inventory} == set(data) - {'inventory.json'}
for row in inventory:
    assert row['bytes'] == len(data[row['path']])
    assert row['sha256'] == sha(data[row['path']])
audit = json.loads(data['evidence/stage-b/root-result-audit.json'])
assert audit['checks_passed'] and audit['postrun_preflight_identical']
assert sha(data['evidence/stage-b/result.json']) == manifest['result_sha256'] == audit['result_sha256']
assert sha(data['evidence/stage-b/root-result-audit.json']) == manifest['root_result_audit_sha256']
assert audit['totals'] == manifest['totals']
assert len(manifest['all_verified_case_ids']) == 26 and len(manifest['planned_unimplemented']) == 14
assert not set(manifest['all_verified_case_ids']) & set(manifest['planned_unimplemented'])
delta = json.loads(data['candidate/delta.json'])
assert delta['base_commit'] == manifest['candidate_delta_base']
assert delta['candidate_source_digest'] == manifest['source_digest']
assert len(delta['files']) == manifest['candidate_delta_files']
for row in delta['files']:
    if row['base_sha256'] is not None:
        original = subprocess.check_output(['git', 'show', delta['base_commit'] + ':' + row['path']], cwd=root)
        assert sha(original) == row['base_sha256']
    if row['candidate_sha256'] is not None:
        name = 'candidate/source/' + row['path']
        assert sha(data[name]) == row['candidate_sha256']
        assert data[name] == (Path('/tmp/uwz-task4d-fix1-frozen') / row['path']).read_bytes()
for prefix, location in [('source/original/', '/tmp/uwz-task5b4-frozen-v2'),
                         ('source/fix1/', '/tmp/uwz-task5b4-fix1-frozen')]:
    names = {name[len(prefix):] for name in data if name.startswith(prefix)}
    assert names == {path.name for path in Path(location).iterdir()}
    for name in names:
        assert data[prefix + name] == (Path(location) / name).read_bytes()
result = {'checks_passed': True, 'archive_sha256': manifest['archive_sha256'],
          'safe_regular_members': len(entries), 'inventory_entries': len(inventory),
          'candidate_delta_files': len(delta['files']), 'current_fixture_files': 10,
          'raw_result_sha256': manifest['result_sha256'], 'scope': 'Publication integrity only; no native rerun.'}
target = root / '.uwz-work/evidence/h2-streaming/metadata-publication-audit.json'
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
