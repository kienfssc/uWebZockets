"""Archive the reviewed metadata fixture, current evidence and candidate delta."""
import gzip
import importlib.util
import json
import subprocess
from pathlib import Path


def main():
    root = Path('/workspaces/uWebZockets')
    evidence = root / '.uwz-work/evidence/h2-streaming/integration-owned/metadata'
    common_path = root / '.uwz-work/tools/publish-h2-admission-live.py'
    spec = importlib.util.spec_from_file_location('publication_common', common_path)
    assert spec is not None and spec.loader is not None
    common = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(common)
    audit = json.loads((evidence / 'stage-b/root-result-audit.json').read_text())
    auth = json.loads((evidence / 'fix1/stage-b-authorization.json').read_text())
    assert audit['checks_passed'] and audit['host_pid_absent'] and audit['key_absent']
    assert audit['child_exit_zero_reaped'] and audit['postrun_preflight_identical']
    assert audit['post_deinit_records_match'] == 32 and audit['post_deinit_metrics_match']
    assert audit['cases_passed'] == ['metadata_helpers', 'shutdown_idle']
    assert audit['encoded_header_bytes_observed'] == 725
    assert common.digest((evidence / 'stage-b/result.json').read_bytes()) == audit['result_sha256']
    assert common.digest((evidence / 'fix1/root-preflight.json').read_bytes()) == audit['preflight_sha256']
    assert auth['preflight_sha256'] == audit['preflight_sha256']
    members = {}
    for path in sorted(evidence.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            common.add_file(members, 'evidence/' + path.relative_to(evidence).as_posix(), path)
    for label, location in [('original', '/tmp/uwz-task5b4-frozen-v2'),
                            ('fix1', '/tmp/uwz-task5b4-fix1-frozen')]:
        paths = sorted(Path(location).iterdir())
        assert len(paths) == 10 and all(path.is_file() for path in paths)
        for path in paths:
            common.add_file(members, 'source/' + label + '/' + path.name, path)
    reports = sorted((root / '.superpowers/sdd/h2_streaming_plan').glob('task-5b4-*.md'))
    assert len(reports) == 12
    for path in reports:
        common.add_file(members, 'reports/' + path.name, path)
    common.add_file(members, 'reports/component.md', root / 'docs/implement-2-2-0/m2_h2_metadata_live.md')
    inputs = {
        'h2_client.py': '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py',
        'immutable-libxev-input.json': '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json',
        'focused-final-ReleaseSafe.command.json': '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json',
        'c-native.zig': '.uwz-work/evidence/h1-transport/r2/c-native.zig',
        'restoration-provenance.json': '.uwz-work/evidence/h2-streaming/body-queue/restored-2026-10-28.json',
    }
    for name, location in inputs.items():
        common.add_file(members, 'inputs/' + name, root / location)
    for path in sorted((root / '.uwz-work/tools').glob('restore-metadata-inputs-2026-10-29*.py')):
        common.add_file(members, 'restoration/' + path.name, path)
    base = '30f27ab80f0471437c34adcdf7b2d42f58227b74'
    candidate = Path('/tmp/uwz-task4d-fix1-frozen')
    base_paths = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', base, '--', 'src'], cwd=root, text=True).splitlines())
    candidate_paths = {p.relative_to(candidate).as_posix() for p in (candidate / 'src').rglob('*') if p.is_file()}
    delta = []
    for name in sorted(base_paths | candidate_paths):
        old = subprocess.check_output(['git', 'show', base + ':' + name], cwd=root) if name in base_paths else None
        new = (candidate / name).read_bytes() if name in candidate_paths else None
        if old == new:
            continue
        delta.append({'path': name, 'change': 'added' if old is None else 'deleted' if new is None else 'modified',
                      'base_sha256': common.digest(old) if old is not None else None,
                      'candidate_sha256': common.digest(new) if new is not None else None})
        if new is not None:
            common.add_file(members, 'candidate/source/' + name, candidate / name)
    members['candidate/delta.json'] = (json.dumps({'base_commit': base, 'candidate_source_digest': audit['source_digest'],
        'scope': 'Full replacement bytes for changed src paths only; review/recovery material. Production adoption and dependency pin publication remain open.',
        'files': delta}, indent=2) + '\n').encode()
    common.add_file(members, 'publication/publish-h2-metadata-live.py', Path(__file__).resolve())
    common.add_file(members, 'publication/publish-h2-admission-live.py', common_path)
    common.add_file(members, 'publication/audit-h2-metadata-publication.py', root / '.uwz-work/tools/audit-h2-metadata-publication.py')
    for name, data in members.items():
        data.decode('utf-8')
        assert not data.startswith(b'\0asm'), name
    inventory = [{'path': name, 'bytes': len(data), 'sha256': common.digest(data)} for name, data in sorted(members.items())]
    members['inventory.json'] = (json.dumps({'scope': 'Publication bytes. Current executed fixture is source/fix1; original/recovery artifacts retain their historical identities.', 'files': inventory}, indent=2) + '\n').encode()
    output = root / 'docs/implement-2-2-0/evidence/m2_h2_metadata_live'
    output.mkdir(parents=True, exist_ok=True)
    archive = output / 'metadata-live.tar.gz'
    archive.write_bytes(gzip.compress(common.tar_bytes(members), mtime=0))
    prior_manifest = json.loads((root / 'docs/implement-2-2-0/evidence/m2_h2_credit_live/manifest.json').read_text())
    proved = sorted(set(prior_manifest['previously_verified'] + prior_manifest['cases_passed'] + audit['cases_passed']))
    remaining = [name for name in prior_manifest['planned_unimplemented'] if name != 'metadata_helpers']
    assert len(proved) == 26 and len(remaining) == 14 and not set(proved) & set(remaining)
    manifest = {
        'scope': 'One owned Linux ReleaseSafe TLS1.3/h2 metadata/helper run and idle shutdown. Full M2 and production adoption remain open.',
        'archive': archive.name, 'archive_sha256': common.digest(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
        'safe_regular_members': len(members), 'inventory_entries': len(inventory),
        'source_digest': audit['source_digest'], 'source_files': 1031, 'source_checkpoint': '../m2_h2_native_tcp/README.md',
        'candidate_delta_base': base, 'candidate_delta_files': len(delta),
        'binary_sha256': audit['binary_sha256'], 'profile_sha256': audit['profile_sha256'],
        'review_manifest_sha256': common.digest((evidence / 'fix1/manifest.json').read_bytes()),
        'preflight_sha256': audit['preflight_sha256'], 'postrun_preflight_identical': True,
        'authorization_sha256': common.digest((evidence / 'fix1/stage-b-authorization.json').read_bytes()),
        'result_sha256': audit['result_sha256'], 'root_result_audit_sha256': common.digest((evidence / 'stage-b/root-result-audit.json').read_bytes()),
        'cases_passed': audit['cases_passed'], 'all_verified_case_ids': proved, 'planned_unimplemented': remaining,
        'totals': audit['totals'], 'metadata': {k: audit[k] for k in ('metadata_middleware', 'metadata_begin', 'metadata_end', 'helper_suite_begin', 'helper_suite_end', 'initial_visible_headers_asserted', 'captures_asserted', 'encoded_header_bytes_observed', 'encoded_header_bytes_limit')},
        'post_deinit_records_equal': 32, 'post_deinit_metrics_equal': True, 'fresh_tls_connections': 2,
        'server_log_bytes': audit['server_log_bytes'], 'runtime_mode': 'ReleaseSafe', 'exit_status': 0,
        'runs': 1, 'automatic_retries': 0, 'child_exit_zero_reaped': True, 'private_key_removed': True,
        'historical_binary_reproduction': audit['historical_binary_reproduction'],
        'remaining': ['14 further H2 IDs and combined matrix', 'H3, multipart transport and genuine early data',
                      'Full native, sanitizer, physical lifetime, compliance and platform gates',
                      'Maintained publication, production adoption and original milestones'],
    }
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (output / 'README.md').write_text(f'''# Owned HTTP/2 metadata and helper evidence

The [archive](metadata-live.tar.gz) contains the actual original and fixed
fixture sources, compile recipes and receipts, complete input maps, recovery
records, independent reviews, authorization, raw results/logs, public
certificate and independent result audit. Its {len(members)} safe regular
members have {len(inventory)} independently checkable inventory entries.
No private key, compiled executable or generated Python cache is included.

Archive SHA-256: `{manifest['archive_sha256']}` ({manifest['archive_bytes']} bytes).
See the [manifest](manifest.json) and [component report](../../m2_h2_metadata_live.md).

One owned Linux ReleaseSafe TLS1.3/h2 run passes metadata_helpers and idle
shutdown: 66 visible headers, 17 captures, five BodyNotBuffered helpers in
each begin/end callback, unchanged caller allocator/Issue and initial metadata
retained despite conflicting trailers. Actual initial HPACK size is 725 bytes
within 8192. Both paused zero-consumption barriers precede public resume;
exactly 32 bytes arrive with the independently expected hash. All 32 records
and final metrics match after deinit; the child exits zero, is reaped and its
key is removed. The process log is 14129 bytes below the unchanged 65536 cap.

The pause removed temporary artifacts. Restored sources match recorded bytes;
fresh original-argv builds succeeded but did not reproduce historical binary
hashes. Their cause remains unproved. Original records and mismatches remain
intact. Current execution uses separately bound fresh fixed builds, manifest
`{manifest['review_manifest_sha256']}`, not a recovered historical executable.
Independent review removed dead fixture scaffolding; both Debug/ReleaseSafe
compiles and scoped re-reviews pass. The exact one-run command and environment
are in evidence/fix1/stage-b-authorization.json and reports/task-5b4-stage-b-report.md.

The archive also includes complete replacement bytes for {len(delta)} changed
candidate src paths against Root commit `{base}` in candidate/source, with
base/new hashes in candidate/delta.json. These support review and recovery;
they do not activate the candidate in the library. The unchanged 1031-file
[native candidate](../m2_h2_native_tcp/README.md), reviewed c223 override,
original binding/six static libraries and [pinned offline client](../m2_h2_client/README.md)
remain the source/tool basis. Current closure checks 2455 inputs and six trees
before/after execution. The restoration scripts preserve the actual recovery
history; they are not a new requirement to reconstruct unrelated old binaries.

The independent case inventory is 26 proved IDs and 14 remaining. All remaining
H2 lifecycle/output cases, combined matrix, H3/multipart/genuine early data,
quality/platform/physical/compliance gates, maintained publication, production
adoption and original milestones stay open. This is functional evidence,
with no performance, RSS, leak or general native-safety claim. No stopped
experiment or historical denied socket case was resumed.
''')
    print(json.dumps({k: manifest[k] for k in ('archive_sha256', 'archive_bytes', 'safe_regular_members', 'inventory_entries', 'candidate_delta_files', 'result_sha256')}, indent=2))


if __name__ == '__main__':
    main()
