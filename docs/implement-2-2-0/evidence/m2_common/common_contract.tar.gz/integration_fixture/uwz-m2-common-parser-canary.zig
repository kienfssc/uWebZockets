const std = @import("std");
const Payload = union { value: []const u8, count: u64 };
export fn probe() void {
    var memory: [4096]u8 = undefined;
    var allocator = std.heap.FixedBufferAllocator.init(&memory);
    const parsed = std.json.parseFromSlice(Payload, allocator.allocator(), "{}", .{}) catch return;
    parsed.deinit();
}
