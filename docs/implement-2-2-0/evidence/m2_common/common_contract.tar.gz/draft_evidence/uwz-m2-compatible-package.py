from pathlib import Path
import shlex,subprocess
args=shlex.split(Path('/tmp/uwz-m2-compatible-streaming_request.command.txt').read_text())
args[1]='build-exe'
idx=args.index('--test-filter');del args[idx:idx+2]
idx=args.index('--name');args[idx+1]='m2_compatible_consumer'
idx=next(i for i,x in enumerate(args) if x.startswith('-Mroot='))
args[idx]='-Mroot=/tmp/uwz-m2-compatible-draft/tests/package_consumer/main.zig'
args[idx:idx]=['--dep','uWebZockets']
args+=['-ODebug','--dep','c','--dep','xev','--dep','zslay','-MuWebZockets=/tmp/uwz-m2-compatible-draft/src/root.zig','-fno-emit-bin']
Path('/tmp/uwz-m2-compatible-package.command.txt').write_text(shlex.join(args)+'\n')
raise SystemExit(subprocess.call(args,cwd='/tmp/uwz-m2-compatible-draft'))
