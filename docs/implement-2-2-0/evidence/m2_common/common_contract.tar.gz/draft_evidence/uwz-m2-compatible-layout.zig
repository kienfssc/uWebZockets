const builtin = @import("builtin");
const support = @import("test_support");
const Tcp = support.tcp;
const Session = Tcp.Http2Session;
const RequestSlot = @typeInfo(@FieldType(Session, "requests")).pointer.child;
const Config = support.config.ServerConfig;
const config = Config{};
comptime {
    if (@hasDecl(support, "streaming_request")) {
        @compileLog("StreamingRequest", @sizeOf(support.streaming_request.StreamingRequest), @alignOf(support.streaming_request.StreamingRequest));
        @compileLog("OwnedStreamingRequest", @sizeOf(support.streaming_request.OwnedStreamingRequest), @alignOf(support.streaming_request.OwnedStreamingRequest));
        @compileLog("BodyState", @sizeOf(support.request_body.BodyState), @alignOf(support.request_body.BodyState));
        @compileLog("BodyControl", @sizeOf(support.request_body.BodyControl), @alignOf(support.request_body.BodyControl));
        @compileLog("BodyRoute", @sizeOf(support.request_body.BodyRoute), @alignOf(support.request_body.BodyRoute));
    }
    @compileLog("target", builtin.target.cpu.arch, builtin.os.tag);
    @compileLog("Request", @sizeOf(support.http_request.Request), @alignOf(support.http_request.Request));
    @compileLog("OwnedRequest", @sizeOf(support.http_request.OwnedRequest), @alignOf(support.http_request.OwnedRequest));
    @compileLog("TcpConnection", @sizeOf(Tcp.TcpConnection), @alignOf(Tcp.TcpConnection));
    @compileLog("Http2Session", @sizeOf(Session), @alignOf(Session));
    @compileLog("H2RequestSlot", @sizeOf(RequestSlot), @alignOf(RequestSlot), Tcp.max_http2_streams);
    @compileLog("H2Storage", config.h2_session_bytes() catch @compileError("h2 storage overflow"), config.h2_session_stride() catch @compileError("h2 stride overflow"), Session.storage_alignment);
    @compileLog("H2Bundle", @sizeOf(Session.bundle(config.h2_capacities())), @alignOf(Session.bundle(config.h2_capacities())));
    @compileLog("QuicStream", @sizeOf(support.quic_stream.QuicStream), @alignOf(support.quic_stream.QuicStream));
    @compileLog("HeaderSet", @sizeOf(support.quic_stream.HeaderSet), @alignOf(support.quic_stream.HeaderSet));
    @compileLog("DefaultSlab", config.slab_bytes() catch @compileError("slab overflow"), config.max_connections, support.config.slab_alignment);
    @compileLog("h3_byte_slabs_only", config.h3_engine_bytes() catch @compileError("h3 bytes overflow"));
    @compileLog("HeaderSetPool", 2 * config.max_connections * @sizeOf(support.quic_stream.HeaderSet));
}
