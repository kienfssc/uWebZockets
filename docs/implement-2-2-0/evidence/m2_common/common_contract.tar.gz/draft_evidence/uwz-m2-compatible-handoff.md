# Revised M2 common contract handoff

Ready for integration review; no live streaming capability claimed. All owned
jobs are terminal. No original or first-draft edits, commits, pushes, full native
suite, SAN, target build graph or new C build was performed.

Clone: `/tmp/uwz-m2-compatible-draft`, detached base
`b26a94d5205f02f27c1cb46504e963a0659af6da`.
Final eight-file freeze: `/tmp/uwz-m2-compatible-frozen.sha256`.
Final patch including all four new files: `/tmp/uwz-m2-compatible-draft.patch`
(SHA256625fe67a87362cd08c97ac275feeb3346c3e26c59bfaf654be4e32decdcf755f).

## Files and boundary

- New `src/http/streaming_request.zig`: metadata-only projection, bounded
  case-sensitive captures, closed helper refusals, flat moved-safe owned clone.
- New `src/http/request_body.zig`: reviewed pure lifecycle/inline controls,
  const StreamingRequest callback aliases, BodyMiddlewarePolicy reject_legacy.
- New `src/tests/streaming_request_tests.zig`: eight compatibility/ownership tests.
- New `src/tests/request_body_tests.zig`:21 retained/adapted lifecycle/type tests.
- `src/root.zig`, `src/test_support.zig`, `src/tests/main.zig`: additive exports
  and serialized test imports only.
- `tests/package_consumer/main.zig`: public callback/owned-view/control references
  and unchanged four-error narrow/exhaustive form consumers. Its old swallowed
  hello write now uses the existing best-effort helper with equivalent headers.

Request/OwnedRequest source is byte-unchanged:
SHA25639aa4255656dc31e588852d9fe46ae7bb92d58bd278338a70582fb9d08774142.
No framework, config, parser, transport, route or response behavior edits. The
M1 source and frozen rejected runtime-mode prototype remain untouched.

## Commands and raw results

Focused launcher: `python /tmp/uwz-m2-compatible-focused.py` (view) or append
`request_body` (lifecycle). Exact complete compiler argv:
`/tmp/uwz-m2-compatible-streaming_request.command.txt` and
`/tmp/uwz-m2-compatible-request_body.command.txt`.

- Missing public API RED: `/tmp/uwz-m2-compatible-api-red.log`, status1,
  session77181 terminal; before new production additions.
- Pointer assertion setup diagnostic: `/tmp/uwz-m2-compatible-pointer-compare-setup-red.log`;
  fixed test-only single/many-pointer equality, not a runtime defect.
- Final view **8/8**, status0, session34427 terminal:
  `/tmp/uwz-m2-compatible-json-alias-green.log` and `.status`.
- Lifecycle **21/21**, status0, session18405 terminal:
  `/tmp/uwz-m2-compatible-final-lifecycle.log` and `.status`.
  It was not repeated after the unrelated parser-canary naming correction.
- Convention RED retained `/tmp/uwz-m2-compatible-conventions.log`, status1.
  Root approved fixed external `pub const @"jsonParse" = reject_parse` with
  private snake_case function and pinned-Zig protocol comment; no lint changes.
  Prior freeze `/tmp/uwz-m2-compatible-frozen-before-json-alias.sha256`.
  Final convention `/tmp/uwz-m2-compatible-conventions-final.log`, status0.
- Public consumer Debug frontend compile **0**, session39867 terminal:
  `python /tmp/uwz-m2-compatible-package.py`, exact argv
  `/tmp/uwz-m2-compatible-package.command.txt`, raw `.package.log/.status`
  (full filenames `/tmp/uwz-m2-compatible-package.log` and `.status`).
  This uses -fno-emit-bin and unchanged cached native C libraries; it is not a
  canonical clean-package build. No live app was run.
- Owned-file fmt and all-tree fmt-check0, convention0, release0, docs0 and diff0:
  `/tmp/uwz-m2-compatible-{final-fmt,full-fmt-check,conventions-final,release,docs,diff-check}.log`.
  No fetched/cache tree was formatted. Root owns integration's canonical gates.
- Graph refresh new clone only: session27948 terminal0,
  `/tmp/uwz-m2-compatible-graph-update.log`; exact command
  `env PYTHONPATH=/tmp/uwz-graphify /tmp/uwz-graphify/bin/graphify update .`.
  AST-only6420nodes/9185edges; retained existing C-header extractor warning,
 23symbol-free files, sandbox sequential fallback and aggregated >5000 view.

## Actual layout measurements

Driver `python /tmp/uwz-m2-measure-compatible-layout.py`, session39508 terminal0.
Probe `/tmp/uwz-m2-compatible-layout.zig`. Exact eight commands/raw diagnostics/
statuses: `/tmp/uwz-m2-compatible-layout-{before,after}-{target}.{command.txt,log,status}`,
with targets `native`, `x86_64-windows-gnu`, `aarch64-macos`, `x86_64-macos`.
Driver log `/tmp/uwz-m2-compatible-layout-driver.log`; explicit intentional-exit
classification `/tmp/uwz-m2-compatible-layout-results.json`; parsed actual values
`/tmp/uwz-m2-compatible-layout-values.json`. All underlying compileLog exits1 are
intentional measurements, with no unexpected compilation error.

All four targets: Request2752,OwnedRequest2848,H2Session1376,H2RequestSlot2752,
H2carvedstorage/stride517648, unchanged. New actual types/alignment8:
StreamingRequest208,OwnedStreamingRequest176,BodyState120,BodyControl16,BodyRoute64.

| Target | TcpConnection unchanged | QuicStream/HeaderSet unchanged | Default slab unchanged |
| --- | --- | --- | --- |
| Linux x86_64 |25624|880/2992|684160640|
| macOS arm64 and x86_64 |25544|880/2992|684078720|
| WindowsGNU x86_64 |26112|888/3000|684660352|

No old +8/+73728 expectations were applied; no equality assertion was changed.
Read-only baseline src at cdd7ff7bfce45dccc1e64ff0d6c8d8cc2c675129 matches b26
via gitdiff--quiet0 (saved baseline-head/source-status artifacts). Source hashes
were rechecked after the final jobs; `/tmp/uwz-m2-compatible-manifest-check.log`
and `/tmp/uwz-m2-compatible-legacy-unchanged.{log,status}` retain the checks.

Root/reviewer can close source/evidence review now. Full integrated native,
ReleaseSafe/SAN/target/package/protocol/fuzz gates and all actual upload adapters
remain separate; no route, middleware admission, framing or flow-control behavior
is implemented by this common checkpoint.
