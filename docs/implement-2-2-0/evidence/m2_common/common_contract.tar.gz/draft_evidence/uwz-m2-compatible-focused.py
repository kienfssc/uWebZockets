from pathlib import Path
import shlex,subprocess,sys
args=shlex.split(Path('/tmp/uwz-m2-common-focused.command.txt').read_text())
args=[x.replace('/tmp/uwz-m2-common-draft','/tmp/uwz-m2-compatible-draft') for x in args]
args[args.index('--cache-dir')+1]='/tmp/uwz-m2-compatible-cache'
args[args.index('--global-cache-dir')+1]='/tmp/uwz-m2-compatible-global-cache'
suite=sys.argv[1] if len(sys.argv)>1 else 'streaming_request'
args=[x.replace('src/tests/request_body_tests.zig','src/tests/'+suite+'_tests.zig') for x in args]
args[args.index('--test-filter')+1]='streaming request:' if suite=='streaming_request' else 'request body:'
Path('/tmp/uwz-m2-compatible-'+suite+'.command.txt').write_text(shlex.join(args)+'\n')
raise SystemExit(subprocess.call(args,cwd='/tmp/uwz-m2-compatible-draft'))
