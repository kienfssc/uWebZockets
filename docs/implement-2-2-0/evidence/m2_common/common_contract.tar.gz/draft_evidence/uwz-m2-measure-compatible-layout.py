from pathlib import Path
import subprocess,shlex,json
roots={'before':Path('/workspaces/uWebZockets'),'after':Path('/tmp/uwz-m2-compatible-draft')}
cs={
 'native':Path('/tmp/uwz-original-zig-cache/o/7b7ffad1d9d39b035e1106062a5a1c5e/c.zig'),
 'x86_64-windows-gnu':Path('/tmp/uwz-frozen-m1a-cache/o/4e542cdb71cb338faf5e39ddd518bffb/c.zig'),
 'aarch64-macos':Path('/tmp/uwz-frozen-m1a-cache/o/66c722f968ab197ab62fc94a4dee5b29/c.zig'),
 'x86_64-macos':Path('/tmp/uwz-frozen-m1a-cache/o/a06c238eb37979c0be88add276fcc2fa/c.zig'),
}
results=[]
for version,base in roots.items():
 for target,c in cs.items():
  if not c.is_file(): raise SystemExit('missing read-only translated c:'+str(c))
  pkg=Path('/tmp/uwz-m2-compatible-draft/zig-pkg')
  args=['/tmp/zig-x86_64-linux-0.16.0/zig','build-obj','-fno-emit-bin','-lc']
  if target!='native': args+=['-target',target]
  args+=['--dep','test_support','-Mroot=/tmp/uwz-m2-compatible-layout.zig','--dep','c','--dep','xev','--dep','zslay','-Mtest_support='+str(base/'src/test_support.zig'),'--dep','xev_impl','-Mxev='+str(base/'src/core/xev.zig'),'-Mxev_impl='+str(pkg/'libxev-0.0.0-86vtcxpPFAA24HJL5_3vLiEzmdArsxVM5YtX91O6hGPt/src/main.zig'),'-Mc='+str(c),'-Mzslay='+str(pkg/'zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy/src/root.zig'),'--cache-dir','/tmp/uwz-m2-compatible-layout-cache','--global-cache-dir','/tmp/uwz-m2-compatible-global-cache']
  stem=Path('/tmp/uwz-m2-compatible-layout-'+version+'-'+target)
  stem.with_suffix('.command.txt').write_text(shlex.join(args)+'\n')
  with stem.with_suffix('.log').open('w') as out: result=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,cwd=base)
  stem.with_suffix('.status').write_text(str(result.returncode)+'\n')
  log=stem.with_suffix('.log').read_text()
  intentional=result.returncode==1 and 'error: found compile log statement' in log and 'Compile Log Output:' in log and '\"DefaultSlab\"' in log
  results.append({'source':version,'target':target,'exit':result.returncode,'intentional_compilelog':intentional})
  print(results[-1],flush=True)
  if not intentional:
   print(log,flush=True)
   raise SystemExit('unexpected declaration-probe failure')
Path('/tmp/uwz-m2-compatible-layout-results.json').write_text(json.dumps(results,indent=2)+'\n')
