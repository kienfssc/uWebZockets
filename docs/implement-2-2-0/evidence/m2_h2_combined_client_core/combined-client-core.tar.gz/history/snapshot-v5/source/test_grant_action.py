"""Actual public grants are paired to finite output case policy."""
import h2_client
import h2.settings
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def check():
    protocol = h2_client.new_protocol()
    protocol.data_to_send(amount=8192)
    ledger = response_credit.new_state()
    response_credit.settings_sent(ledger, 65535, initial=True)
    ack = b'\0\0\0\4\1\0\0\0\0'
    events = protocol.receive_data(b'\0\0\0\4\0\0\0\0\0' + ack)
    for event in events:
        if type(event).__name__ == 'SettingsAcknowledged':
            response_credit.settings_acknowledged(ledger, event)
    protocol.data_to_send(amount=8192)
    protocol.update_settings({h2.settings.SettingCodes.INITIAL_WINDOW_SIZE: 0})
    response_credit.settings_sent(ledger, 0)
    protocol.data_to_send(amount=8192)
    events = protocol.receive_data(ack)
    response_credit.settings_acknowledged(ledger, events[0])
    protocol.send_headers(1, [(':method', 'GET'), (':scheme', 'https'),
                              (':authority', 'localhost'), (':path', '/x')], end_stream=True)
    response_credit.open_stream(ledger, 1)
    stage = output_stage.new_stage(output_stage.new_case('output_pressure_window'), 1, 2, 10, 100)
    raw = raw_observer.new_state()
    request = request_credit.new_state(request_credit.new_case('output_pressure_window'))
    wire.bind_connection(stage, protocol, raw, request, ledger, {})
    output_stage.register(stage, 1, 'special', primary=True)
    policy = wire.new_grants(stage)
    protocol.data_to_send(amount=8192)
    wire.grant(protocol, ledger, policy, stage, 1, 8192, 'special')
    if ledger['stream_granted'] != 8192 or len(protocol.data_to_send(amount=8192)) != 13:
        raise RuntimeError('grant action differs')
    try:
        wire.grant(protocol, ledger, policy, stage, 1, 1, 'special')
    except ValueError:
        if ledger['stream_granted'] != 8192 or protocol.data_to_send(amount=8192):
            raise RuntimeError('rejected grant mutated state')
    else:
        raise RuntimeError('incorrect special grant accepted')
    print('bounded codec grant checks passed')


if __name__ == '__main__':
    check()
