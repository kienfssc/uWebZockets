"""Actual codec early final and reset order with bounded response grants."""
import h2_client
import h2.settings
import hpack
import model
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def frame(kind, flags, stream, payload):
    return len(payload).to_bytes(3, 'big') + bytes((kind, flags)) + stream.to_bytes(4, 'big') + payload


def check():
    protocol = h2_client.new_protocol()
    request = request_credit.new_state(request_credit.new_case('early_final_order'))
    response = response_credit.new_state()
    stage = output_stage.new_stage(output_stage.new_case('early_final_order'), 1, 2, 10, 100)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, response, records)
    wire.startup(stage)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    wire.accept(protocol, frame(4, 0, 0, settings) + frame(4, 1, 0, b''), records, raw, trace,
                credit=response, request=request, stage=stage)
    wire.drain(stage)
    wire.update_settings(stage, 0)
    wire.drain(stage)
    wire.accept(protocol, frame(4, 1, 0, b''), records, raw, trace, credit=response, request=request, stage=stage)
    stream, chunks = wire.start_request(stage, 'POST', 'localhost', '/limit/early_final_order', (), False,
                                        role='special', primary=True, held=False, body_limit=17, final_status=403,
                                        info_count=0, policy='refusal_after_final', mode='hash_only',
                                        expected_sha256=model.EARLY_RESPONSE['sha256'], middleware_policy='required')
    if stream != 1 or not chunks:
        raise RuntimeError('early request differs')
    grant_policy = wire.new_grants(stage)
    wire.grant(protocol, response, grant_policy, stage, 0, 33554432 - 65535, 'bootstrap')
    headers = hpack.Encoder().encode([(':status', '403'), ('x-middleware', 'retained')])
    wire.accept(protocol, frame(1, 4, 1, headers), records, raw, trace, credit=response, request=request, stage=stage)
    wire.grant(protocol, response, grant_policy, stage, 1, 8, 'special')
    protocol.data_to_send(amount=8192)
    wire.accept(protocol, frame(0, 0, 1, b'early-fi'), records, raw, trace, credit=response, request=request, stage=stage)
    wire.grant(protocol, response, grant_policy, stage, 0, 8, 'replenish')
    if len(protocol.data_to_send(amount=8192)) != 13:
        raise RuntimeError('connection replenishment missing')
    try:
        wire.grant(protocol, response, grant_policy, stage, 0, 1, 'replenish')
    except ValueError as error:
        if str(error) != 'unearned connection grant':
            raise
    else:
        raise RuntimeError('duplicate connection grant accepted')
    try:
        wire.grant(protocol, response, grant_policy, stage, 1, 1, 'replenish')
    except ValueError as error:
        if str(error) != 'invalid stream replenishment':
            raise
    else:
        raise RuntimeError('special grant bypass accepted')
    wire.grant(protocol, response, grant_policy, stage, 1, 9, 'special')
    protocol.data_to_send(amount=8192)
    packet = frame(0, 1, 1, b'nal-order') + frame(3, 0, 1, b'\0\0\0\0')
    for part in (packet[:5], packet[5:]):
        wire.accept(protocol, part, records, raw, trace, credit=response, request=request, stage=stage)
    wire.retire(records, raw, 1, request=request, credit=response, stage=stage)
    if raw['streams'] or records or response['streams']:
        raise RuntimeError('early final not retired')
    bad = raw_observer.new_state()
    raw_observer.register(bad, 1, 'refusal_after_final')
    try:
        raw_observer.observe(bad, frame(3, 0, 1, b'\0\0\0\0'))
    except ValueError as error:
        if str(error) != 'reset order':
            raise
    else:
        raise RuntimeError('reset before END accepted')
    print('early END before reset checks passed')


if __name__ == '__main__':
    check()
