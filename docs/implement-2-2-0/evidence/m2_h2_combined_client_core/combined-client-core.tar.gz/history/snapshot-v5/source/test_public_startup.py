"""Pure serialization proof using the authenticated helper and public codec."""

import h2_client
import h2.settings
import output_stage
import raw_observer
import request_credit
import wire
import response_credit


def require(condition, message):
    if not condition:
        raise ValueError(message)


def check():
    protocol = h2_client.new_protocol()
    ledger = response_credit.new_state()
    stage = output_stage.new_stage(output_stage.new_case('output_pressure_window'), 3, 2, 10, 100)
    raw = raw_observer.new_state()
    request = request_credit.new_state(request_credit.new_case('output_pressure_window'))
    records, trace = {}, {}
    wire.bind_connection(stage, protocol, raw, request, ledger, records)
    startup = wire.startup(stage)
    try:
        wire.startup(stage)
    except ValueError as error:
        require(str(error) == 'invalid startup order', 'wrong startup rejection')
    else:
        raise RuntimeError('duplicate startup accepted')
    require(startup[:24] == b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n', 'preface')
    require(startup[27] == 4 and len(startup) == 24 + 9 + int.from_bytes(startup[24:27], 'big'), 'settings frame')
    # The fixture server emits IDs 1, 2, 3, 6 and 8; this is a source-shaped frame.
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    payload = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in pairs)
    settings = len(payload).to_bytes(3, 'big') + b'\x04\x00\x00\x00\x00\x00' + payload
    ack = b'\x00\x00\x00\x04\x01\x00\x00\x00\x00'
    wire.accept(protocol, settings + ack, records, raw, trace, credit=ledger, request=request, stage=stage)
    require(ledger['initial_acked'], 'initial ACK')
    auto_ack = wire.drain(stage)
    require(auto_ack == ack, 'server settings ACK')
    wire.update_settings(stage, 0)
    try:
        wire.update_settings(stage, 0)
    except ValueError as error:
        require(str(error) == 'invalid settings action', 'wrong settings rejection')
    else:
        raise RuntimeError('duplicate settings accepted')
    wire.drain(stage)
    wire.accept(protocol, ack, records, raw, trace, credit=ledger, request=request, stage=stage)
    protocol.send_headers(1, [(':method', 'GET'), (':scheme', 'https'),
                              (':authority', 'localhost'), (':path', '/health')], end_stream=True)
    request_credit.open_stream(request, 1)
    request_credit.end_request(request, 1)
    response_credit.open_stream(ledger, 1)
    wire.drain(stage)
    output_stage.register(stage, 1, 'small')
    wire.register(records, raw, 1, 0, 200, 0, 'healthy', stage=stage, credit_policy='manual')
    grants_policy = wire.new_grants(stage)
    wire.grant(protocol, ledger, grants_policy, stage, 0, 33554432 - 65535, 'bootstrap')
    wire.grant(protocol, ledger, grants_policy, stage, 1, 65535, 'auxiliary')
    grants = wire.drain(stage)
    response_credit.compare_public(ledger, protocol, [1])
    require(len(grants) == 26 and ledger['connection_granted'] == 33554432 - 65535 and ledger['stream_granted'] == 65535, 'grant accounting')
    print('startup_bytes=%d startup_settings_payload=%d server_settings_bytes=%d ack_bytes=%d grant_bytes=%d' %
          (len(startup), len(startup) - 33, len(settings), len(auto_ack), len(grants)))


if __name__ == '__main__':
    check()
