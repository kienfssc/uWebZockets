"""Request actions reject pending bytes and oversize headers before registration."""
import h2_client
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def check():
    protocol = h2_client.new_protocol()
    request = request_credit.new_state(request_credit.new_case('ready_buffered'))
    credit = response_credit.new_state()
    stage = output_stage.new_stage(output_stage.new_case('ready_buffered'), 1, 1, 10, 100)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, credit, records)
    wire.startup(stage)
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in pairs)
    ack = b'\0\0\0\4\1\0\0\0\0'
    settings = len(payload).to_bytes(3, 'big') + b'\4\0\0\0\0\0' + payload
    wire.accept(protocol, settings + ack, records, raw, trace, credit=credit, request=request, stage=stage)
    args = ('GET', 'localhost', '/health', (), True)
    options = dict(role='small', primary=True, held=False, body_limit=0, final_status=200, info_count=0,
                   policy='healthy', mode='small_body', expected_sha256=None, middleware_policy='required')
    try:
        wire.start_request(stage, *args, **options)
    except ValueError as error:
        if str(error) != 'pending outbound bytes before request':
            raise
    else:
        raise RuntimeError('unflushed settings ACK accepted')
    if not stage['failed'] or stage['blocked_outbound'] != ack or records or request['streams']:
        raise RuntimeError('failed ordering lost bytes or registered stream')
    try:
        wire.start_request(stage, *args, **options)
    except ValueError as error:
        if str(error) != 'invalid request action':
            raise
    else:
        raise RuntimeError('failed connection reused')
    print('request action ordering checks passed')


if __name__ == '__main__':
    check()
