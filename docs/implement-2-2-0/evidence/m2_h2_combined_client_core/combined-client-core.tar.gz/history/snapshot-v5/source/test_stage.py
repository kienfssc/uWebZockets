"""Final collection preserves inherited accounting and a held active stream."""
import output_stage as stage
import model


def rejects(call, *args):
    try:
        call(*args)
    except ValueError:
        return
    raise RuntimeError('expected ValueError')


def check():
    item = stage.new_stage(stage.new_case('shutdown_active'), 1, 1, 10, 100)
    stage.register(item, 1, 'transport', primary=True, held=True)
    item['initial_settings'] = 1
    item['acks'] = 1
    raw = {'streams': {1: {}}, 'header': bytearray(b'\0'), 'frame': None, 'remaining': 0}
    request = {'connection_debt': 32, 'streams': {1: {'debt': 32}}, 'final': False}
    response = {'initial_acked': True, 'pending': None, 'streams': {1: {}}}
    stage.read(item, b'a')
    for stream in (3, 5):
        stage.register(item, stream, 'small')
        stage.frame(item, 0, 1, 5, stream, False)
        stage.finished(item, 1, 5, stream)
        stage.retire(item, stream)
    stage.enter_final(item, raw, request, response, 1)
    if stage.remaining(item, 4) != 6:
        raise RuntimeError('remaining deadline differs')
    rejects(stage.remaining, item, 10)
    rejects(stage.remaining, item, True)
    if item['reads'] != 1 or item['case_deadline'] != 10 or item['whole_deadline'] != 100 or raw['header'] != bytearray(b'\0'):
        raise RuntimeError('lost inherited state')
    paths = ['/status/' + row[0] for row in model.BODY_SPECS] + ['/metrics']
    try:
        stage.register(item, 7, 'small', path='/metrics')
    except ValueError as error:
        if str(error) != 'invalid final observation':
            raise
    else:
        raise RuntimeError('early metrics accepted')
    for index, path in enumerate(paths):
        stream = 7 + index * 2
        stage.register(item, stream, 'small', path=path)
        if index == 0:
            try:
                stage.register(item, stream + 2, 'small', path=path)
            except ValueError as error:
                if str(error) != 'invalid final observation':
                    raise
            else:
                raise RuntimeError('duplicate status accepted')
        stage.frame(item, 0, 1, 5, stream, False)
        stage.finished(item, 1, 5, stream)
        stage.retire(item, stream)
    raw['header'].clear()
    stage.finish_final(item, raw)
    stage.signal(item)
    rejects(stage.register, item, 143, 'small')
    if set(item['active']) != {1}:
        raise RuntimeError('held request lost')
    capped = stage.new_stage(stage.new_case('shutdown_idle'), 1, 1, 10, 100)
    for _ in range(4096):
        stage.read(capped, b'x')
    rejects(stage.read, capped, b'x')
    rejects(stage.frame, capped, True, 4, 0, 0, False)
    print('stage final checks passed')


if __name__ == '__main__':
    check()
