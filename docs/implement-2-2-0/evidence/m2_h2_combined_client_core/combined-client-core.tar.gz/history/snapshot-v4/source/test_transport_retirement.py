"""Pure terminal observation keeps request debt on its original connection."""
import h2_client
import raw_observer
import request_credit
import response_credit
import wire


def check():
    protocol = h2_client.new_protocol()
    protocol.data_to_send(amount=8192)
    response = response_credit.new_state()
    response_credit.settings_sent(response, 65535, initial=True)
    request = request_credit.new_state(request_credit.new_case('disconnect'))
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.accept(protocol, b'\0\0\0\4\0\0\0\0\0\0\0\0\4\1\0\0\0\0', records, raw, trace, credit=response, request=request)
    protocol.data_to_send(amount=8192)
    protocol.send_headers(1, [(':method', 'POST'), (':scheme', 'https'),
                              (':authority', 'localhost'), (':path', '/upload/x')])
    request_credit.open_stream(request, 1)
    response_credit.open_stream(response, 1)
    wire.register(records, raw, 1, 0, 200, 0, 'clean_disconnect', credit_policy='manual')
    wire.send_data(protocol, records, request, 1, b'abcdefgh', end_stream=False, pad_length=None)
    protocol.data_to_send(amount=8192)
    wire.begin_termination(records, raw, 1, 'clean_disconnect', 'pre_unwrap')
    outcome = {'method': 'ssl_unwrap', 'tls_shutdown': 'success', 'tcp_eof': True,
               'trailing_bytes': 0, 'close': 'normal'}
    result = wire.finish_termination(records, raw, 1, 'clean_disconnect', 'pre_unwrap', outcome,
                                     request=request, credit=response)
    if result['response_terminal'] != 'transport' or response['streams'] or not request['transport_closed']:
        raise RuntimeError('transport retirement differs')
    if request['connection_debt'] != 8 or request['streams'][1]['debt'] != 8:
        raise RuntimeError('old connection debt lost')
    replacement = request_credit.new_state(request['case'])
    if replacement['connection_debt'] != 0:
        raise RuntimeError('debt transferred')
    print('transport retirement checks passed')


if __name__ == '__main__':
    check()
