"""Pure serialization proof using the authenticated helper and public codec."""

import h2_client
import response_credit


def require(condition, message):
    if not condition:
        raise ValueError(message)


def check():
    protocol = h2_client.new_protocol()
    ledger = response_credit.new_state()
    response_credit.settings_sent(ledger, 65535, initial=True)
    startup = protocol.data_to_send(amount=8192)
    require(startup[:24] == b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n', 'preface')
    require(startup[27] == 4 and len(startup) == 24 + 9 + int.from_bytes(startup[24:27], 'big'), 'settings frame')
    # The fixture server emits IDs 1, 2, 3, 6 and 8; this is a source-shaped frame.
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    payload = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in pairs)
    settings = len(payload).to_bytes(3, 'big') + b'\x04\x00\x00\x00\x00\x00' + payload
    ack = b'\x00\x00\x00\x04\x01\x00\x00\x00\x00'
    events = protocol.receive_data(settings + ack)
    for event in events:
        if type(event).__name__ == 'SettingsAcknowledged':
            response_credit.settings_acknowledged(ledger, event)
    require(ledger['initial_acked'], 'initial ACK')
    auto_ack = protocol.data_to_send(amount=8192)
    require(auto_ack == ack, 'server settings ACK')
    protocol.send_headers(1, [(':method', 'GET'), (':scheme', 'https'),
                              (':authority', 'localhost'), (':path', '/health')], end_stream=True)
    response_credit.open_stream(ledger, 1)
    protocol.data_to_send(amount=8192)
    protocol.increment_flow_control_window(1000)
    response_credit.grant(ledger, 0, 1000)
    protocol.increment_flow_control_window(2000, stream_id=1)
    response_credit.grant(ledger, 1, 2000)
    grants = protocol.data_to_send(amount=8192)
    response_credit.compare_public(ledger, protocol, [1])
    require(len(grants) == 26 and ledger['connection_granted'] == 1000 and ledger['stream_granted'] == 2000, 'grant accounting')
    print('startup_bytes=%d startup_settings_payload=%d server_settings_bytes=%d ack_bytes=%d grant_bytes=%d' %
          (len(startup), len(startup) - 33, len(settings), len(auto_ack), len(grants)))


if __name__ == '__main__':
    check()
