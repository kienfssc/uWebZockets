"""Final collection preserves inherited accounting and a held active stream."""
import output_stage as stage


def rejects(call, *args):
    try:
        call(*args)
    except ValueError:
        return
    raise RuntimeError('expected ValueError')


def check():
    item = stage.new_stage('shutdown_active', 1, 1, 10, 100)
    stage.register(item, 1, primary=True, held=True)
    item['initial_settings'] = 1
    item['acks'] = 1
    raw = {'streams': {1: {}}, 'header': bytearray(b'\0'), 'frame': None, 'remaining': 0}
    request = {'connection_debt': 32, 'streams': {1: {'debt': 32}}, 'final': False}
    response = {'initial_acked': True, 'pending': None}
    stage.read(item, b'a')
    stage.enter_final(item, raw, request, response, 1)
    if item['reads'] != 1 or item['case_deadline'] != 10 or item['whole_deadline'] != 100 or raw['header'] != bytearray(b'\0'):
        raise RuntimeError('lost inherited state')
    for stream in range(3, 139, 2):
        stage.register(item, stream)
        stage.frame(item, 0, 1, 5, stream, False)
        stage.finished(item, 1, 5, stream)
        stage.retire(item, stream)
    raw['header'].clear()
    stage.finish_final(item, raw)
    stage.signal(item)
    rejects(stage.register, item, 139)
    if set(item['active']) != {1}:
        raise RuntimeError('held request lost')
    print('stage final checks passed')


if __name__ == '__main__':
    check()
