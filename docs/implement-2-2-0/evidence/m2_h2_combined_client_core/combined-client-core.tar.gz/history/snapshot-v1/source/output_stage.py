"""Catalogue-bound response stage accounting with an inherited final boundary."""
import catalogue

MAX_STREAM = 2147483647
SPECIAL_LIMIT = {'producer_reuse': 2050, 'output_pressure_window': 2050,
                 'output_pressure_ready': 2050, 'stream_file': 24594,
                 'early_final_order': 2}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def new_stage(case, primary, expected_acks, case_deadline, whole_deadline):
    limits = catalogue.case_budget(case)
    require(type(primary) is int and 0 < primary <= MAX_STREAM and primary & 1 and
            type(expected_acks) is int and 0 <= expected_acks <= 2 and
            type(case_deadline) is int and type(whole_deadline) is int and
            0 < case_deadline <= whole_deadline, 'invalid stage')
    return {'case': case, 'limits': limits, 'primary': primary, 'budget': limits['receive_bytes'],
            'bytes': 0, 'reads': 0, 'case_deadline': case_deadline, 'whole_deadline': whole_deadline,
            'active': {}, 'auxiliary': 0, 'initial_settings': 0, 'acks': 0,
            'expected_acks': expected_acks, 'resets': 0, 'final': False, 'high_water': 0,
            'primary_complete': False, 'final_registered': 0, 'final_bytes': 0,
            'final_budget': 0, 'held': None, 'final_complete': False, 'signaled': False}


def register(stage, stream_id, primary=False, held=False):
    require(not stage['signaled'], 'observation after signal')
    require(type(stream_id) is int and stage['high_water'] < stream_id <= MAX_STREAM and stream_id & 1 and
            type(primary) is bool and type(held) is bool and len(stage['active']) < 8, 'invalid stage registration')
    require(primary == (not stage['final'] and stream_id == stage['primary']), 'invalid primary')
    require(not held or (primary and stage['case'] in ('shutdown_active', 'final_pause', 'begin_pause_empty', 'continue_paused')), 'invalid held stream')
    if stage['final']:
        require(stage['final_registered'] < 68, 'final response count')
        stage['final_registered'] += 1
    elif not primary:
        require(stage['auxiliary'] < stage['limits']['heads'] - 1, 'auxiliary bound')
        stage['auxiliary'] += 1
    stage['active'][stream_id] = {'headers': 0, 'data': 0, 'primary': primary,
                                  'terminal': False, 'held': held}
    stage['high_water'] = stream_id



def resume(stage, stream_id):
    require(stream_id in stage['active'] and stage['active'][stream_id]['held'] and not stage['final'], 'invalid resume')
    stage['active'][stream_id]['held'] = False

def retire(stage, stream_id):
    require(stream_id in stage['active'], 'unknown stage stream')
    record = stage['active'][stream_id]
    require(record['terminal'], 'stage response incomplete')
    if record['primary']:
        stage['primary_complete'] = True
    del stage['active'][stream_id]


def enter_final(stage, raw, request, response_credit, held=None):
    require(not stage['final'] and response_credit['initial_acked'] and response_credit['pending'] is None and
            stage['acks'] == stage['expected_acks'] and stage['initial_settings'] == 1 and
            stage['resets'] == stage['limits']['resets'], 'invalid final boundary')
    if held is None:
        require(stage['primary_complete'] and not stage['active'] and not raw['streams'], 'unfinished primary')
    else:
        require(stage['case'] == 'shutdown_active' and set(stage['active']) == {held} and
                set(raw['streams']) == {held} and stage['active'][held]['held'] and
                not stage['active'][held]['terminal'], 'invalid held request')
    debt = request['connection_debt'] + sum(item['debt'] for item in request['streams'].values())
    require(type(debt) is int and 0 <= debt <= (64 if stage['case'] == 'shutdown_active' else 131070), 'invalid carried debt')
    stage['final_budget'] = catalogue.final_budget(debt)
    stage['held'] = held
    stage['final'] = True
    request['final'] = True


def read(stage, data):
    require(type(data) is bytes and len(data) <= 8192, 'invalid read')
    if not data:
        return
    next_reads = stage['reads'] + 1
    cap = stage['limits']['legacy_receive_cap']
    if cap is None:
        cap = stage['limits']['receive_calls'] + (stage['final_budget'] if stage['final'] else 0)
    require(next_reads <= cap, 'read cap exceeded')
    if stage['final']:
        require(stage['final_bytes'] + len(data) <= stage['final_budget'], 'final byte budget exceeded')
        if stage['limits']['final_included']:
            require(stage['bytes'] + len(data) <= stage['budget'], 'case byte budget exceeded')
        stage['final_bytes'] += len(data)
    else:
        require(stage['bytes'] + len(data) <= stage['budget'], 'case byte budget exceeded')
    stage['bytes'] += len(data)
    stage['reads'] = next_reads


def frame(stage, length, kind, flags, stream_id, reserved):
    require(type(length) is int and 0 <= length <= 16384 and type(reserved) is bool and not reserved, 'invalid frame')
    if kind == 4:
        require(not stage['final'] and stream_id == 0, 'invalid settings')
        if flags == 0:
            require(length == 30 and stage['initial_settings'] == 0, 'invalid initial settings')
            stage['initial_settings'] += 1
        else:
            require(flags == 1 and length == 0 and stage['initial_settings'] == 1 and stage['acks'] < stage['expected_acks'], 'invalid settings ACK')
            stage['acks'] += 1
        return
    require(stage['initial_settings'] == 1, 'missing initial settings')
    if kind == 8:
        require(flags == 0 and length == 4, 'invalid WINDOW_UPDATE')
        return
    if kind == 3:
        require(not stage['final'] and flags == 0 and length == 4 and stream_id in stage['active'] and
                stage['resets'] < stage['limits']['resets'], 'invalid reset')
        stage['resets'] += 1
        return
    require(kind in (0, 1) and stream_id in stage['active'], 'invalid response frame')
    record = stage['active'][stream_id]
    require(not record['terminal'] and not (record['held'] and flags & 1), 'invalid terminal')
    if kind == 1:
        info = int(record['primary'] and stage['case'] in ('continue_ready', 'continue_paused'))
        require(flags in (4, 5) and length <= 4096 and record['headers'] < 1 + info and
                (not info or record['headers'] > 0 or flags == 4), 'invalid HEADERS')
        record['headers'] += 1
        return
    info = int(record['primary'] and stage['case'] in ('continue_ready', 'continue_paused'))
    require(flags in (0, 1) and record['headers'] == 1 + info, 'invalid DATA')
    limit = SPECIAL_LIMIT.get(stage['case'], 4096) if record['primary'] else 4096
    require(record['data'] < limit, 'DATA frame count exceeded')
    record['data'] += 1


def finish_final(stage, raw):
    held = set() if stage['held'] is None else {stage['held']}
    require(stage['final'] and stage['final_registered'] == 68 and set(stage['active']) == held and
            set(raw['streams']) == held and not raw['header'] and raw['frame'] is None and raw['remaining'] == 0,
            'incomplete final collection')
    stage['final_complete'] = True


def signal(stage):
    require(stage['case'] == 'shutdown_active' and stage['held'] is not None and
            stage['final_complete'] and not stage['signaled'], 'invalid shutdown signal')
    stage['signaled'] = True


def finished(stage, kind, flags, stream_id):
    if (kind in (0, 1) and flags & 1) or kind == 3:
        stage['active'][stream_id]['terminal'] = True
