"""Catalogue-bound request credit regression checks."""

import request_credit as credit


def rejects(call, *args):
    try:
        call(*args)
    except ValueError:
        return
    raise RuntimeError('expected ValueError')


def checks():
    case = credit.new_case('large_declared')
    state = credit.new_state(case)
    credit.open_stream(state, 1)
    remaining = 100000000
    while remaining:
        count = min(8192, remaining, state['connection'], state['streams'][1]['window'])
        if count == 0:
            debt = state['connection_debt']
            credit.refund(state, 0, debt)
            credit.refund(state, 1, debt)
            continue
        credit.send_data(state, 1, count, count)
        remaining -= count
    if case['sent'] != 100000000:
        raise RuntimeError('large flow accounting')
    rejects(credit.send_data, state, 1, 1, 1)
    rejects(credit.refund, state, 0, True)
    credit.incoming_reset(state, 1)
    credit.retire(state, 1)
    debt = state['streams'][1]['debt']
    if credit.refund(state, 1, debt):
        raise RuntimeError('closed stream must suppress codec update')
    rejects(credit.refund, state, 1, debt)
    padding = credit.new_case('queued_trailers_padding')
    first = credit.new_state(padding)
    second = credit.new_state(padding)
    credit.open_stream(first, 1)
    credit.open_stream(second, 1)
    credit.send_data(first, 1, 4097, 4105)
    credit.send_data(second, 1, 8192, 8192)
    rejects(credit.send_data, first, 1, 1, 1)
    rejects(credit.refund, second, 0, 8193)
    rejects(credit.open_stream, first, 1)
    rejects(credit.open_stream, first, 2)
    rejects(credit.send_data, first, 3, 0, 0)
    zero = credit.new_state(credit.new_case('empty_data'))
    credit.open_stream(zero, 1)
    credit.send_data(zero, 1, 0, 0)
    rejects(credit.send_data, zero, 1, 0, 0)
    rejects(credit.new_case, 'unknown')
    rejects(credit.new_case, True)
    rejects(credit.send_data, first, 1, True, 1)
    rejects(credit.send_data, second, 1, 8193, 8193)


if __name__ == '__main__':
    checks()
    print('request-credit checks passed')
