"""Public codec and raw ordered refund/reset accounting in one input."""
import h2_client
import raw_observer
import request_credit
import response_credit
import wire


def frame(kind, stream, payload):
    return len(payload).to_bytes(3, 'big') + bytes((kind, 0)) + stream.to_bytes(4, 'big') + payload


def check():
    protocol = h2_client.new_protocol()
    protocol.data_to_send(amount=8192)
    response = response_credit.new_state()
    response_credit.settings_sent(response, 65535, initial=True)
    request = request_credit.new_state(request_credit.new_case('cancel_ready'))
    raw = raw_observer.new_state()
    records, trace = {}, {}
    settings = frame(4, 0, b'')
    ack = b'\0\0\0\4\1\0\0\0\0'
    wire.accept(protocol, settings + ack, records, raw, trace, credit=response, request=request)
    protocol.data_to_send(amount=8192)
    protocol.send_headers(1, [(':method', 'POST'), (':scheme', 'https'),
                              (':authority', 'localhost'), (':path', '/upload/x')])
    request_credit.open_stream(request, 1)
    response_credit.open_stream(response, 1)
    wire.register(records, raw, 1, 0, 200, 0, 'public_cancel', credit_policy='manual')
    protocol.send_data(1, b'abcdefgh')
    request_credit.send_data(request, 1, 8, 8)
    protocol.data_to_send(amount=8192)
    update = (4).to_bytes(4, 'big')
    reset = (8).to_bytes(4, 'big')
    packet = frame(8, 0, update) + frame(8, 1, update) + frame(3, 1, reset) + frame(8, 1, update)
    for chunk in (packet[:11], packet[11:]):
        wire.accept(protocol, chunk, records, raw, trace, credit=response, request=request)
    if response['streams'][1]['terminal'] != 'incoming_reset':
        raise RuntimeError('response reset not paired')
    if request['connection_debt'] != 4 or request['streams'][1]['debt'] != 0:
        raise RuntimeError('refund accounting')
    wire.complete(records, raw, 1)
    protocol = h2_client.new_protocol()
    protocol.data_to_send(amount=8192)
    response = response_credit.new_state()
    response_credit.settings_sent(response, 65535, initial=True)
    request = request_credit.new_state(request_credit.new_case('peer_reset'))
    raw = raw_observer.new_state()
    records, trace = {}, {}
    wire.accept(protocol, settings + ack, records, raw, trace, credit=response, request=request)
    protocol.data_to_send(amount=8192)
    protocol.send_headers(1, [(':method', 'POST'), (':scheme', 'https'),
                              (':authority', 'localhost'), (':path', '/upload/x')])
    request_credit.open_stream(request, 1)
    response_credit.open_stream(response, 1)
    wire.register(records, raw, 1, 0, 200, 0, 'peer_reset', credit_policy='manual')
    protocol.send_data(1, b'abcdefgh')
    request_credit.send_data(request, 1, 8, 8)
    protocol.data_to_send(amount=8192)
    wire.send_peer_reset(protocol, records, raw, request, response, 1)
    serialized = protocol.data_to_send(amount=8192)
    if serialized != frame(3, 1, reset) or response['streams'][1]['terminal'] != 'outgoing_reset':
        raise RuntimeError('outgoing reset differs')
    wire.accept(protocol, frame(8, 1, update), records, raw, trace, credit=response, request=request)
    if request['streams'][1]['debt'] != 4:
        raise RuntimeError('late peer reset refund')
    wire.complete(records, raw, 1)
    print('ordered codec reset/refund checks passed')


if __name__ == '__main__':
    check()
