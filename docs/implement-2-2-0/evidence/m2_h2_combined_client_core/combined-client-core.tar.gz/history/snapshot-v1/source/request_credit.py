"""Bounded request-send debt; callers pair actions with public codec calls."""
import catalogue

MAX_DATA_SPAN = 8192
MAX_DATA_FLOW = MAX_DATA_SPAN + 256
MAX_RETAINED_STREAMS = 802
MAX_WINDOW = 2147483647
INITIAL = 65535


def require(condition, message):
    if not condition:
        raise ValueError(message)


def number(value, low, high):
    require(type(value) is int and low <= value <= high, 'invalid integer')


def new_case(case):
    limits = catalogue.case_budget(case)
    return {'case': case, 'limit': limits['request_flow'], 'sent': 0,
            'positive_frames': 0, 'zero_frames': 0,
            'zero_limit': limits['zero_data_frames']}


def new_state(case):
    require(type(case) is dict and type(case.get('case')) is str, 'invalid case')
    return {'case': case, 'connection': INITIAL, 'connection_debt': 0, 'sent': 0, 'high_water': 0,
            'streams': {}, 'settings_seen': False, 'client_settings': 0, 'final': False}


def bind_case(state, case):
    require(type(case) is dict and type(case.get('case')) is str and
            state['case']['sent'] == state['case']['limit'] and not state['final'], 'invalid case transition')
    state['case'] = case


def open_stream(state, stream_id):
    number(stream_id, 1, MAX_WINDOW)
    active = sum(not closed(x) for x in state['streams'].values())
    require(stream_id & 1 and stream_id > state['high_water'] and active < 8 and len(state['streams']) < MAX_RETAINED_STREAMS, 'invalid stream opening')
    state['streams'][stream_id] = {'window': INITIAL, 'debt': 0, 'request_end': False,
                                   'response_end': False, 'reset': False, 'retired': False}
    state['high_water'] = stream_id


def stream(state, stream_id):
    number(stream_id, 1, MAX_WINDOW)
    require(stream_id in state['streams'], 'unknown stream')
    return state['streams'][stream_id]


def send_data(state, stream_id, logical, flow):
    number(logical, 0, MAX_DATA_SPAN)
    number(flow, 0, MAX_DATA_FLOW)
    record = stream(state, stream_id)
    case = state['case']
    require(not state['final'] and not record['request_end'] and not record['reset'] and
            not record['retired'] and logical <= flow and flow - logical <= 256 and
            case['sent'] + flow <= case['limit'] and
            flow <= state['connection'] and flow <= record['window'], 'invalid request DATA')
    if flow == 0:
        require(case['zero_frames'] < case['zero_limit'], 'zero DATA frame bound')
        case['zero_frames'] += 1
    else:
        require(case['positive_frames'] < case['limit'], 'positive DATA frame bound')
        case['positive_frames'] += 1
    case['sent'] += flow
    state['sent'] += flow
    state['connection'] -= flow
    state['connection_debt'] += flow
    record['window'] -= flow
    record['debt'] += flow


def end_request(state, stream_id):
    record = stream(state, stream_id)
    require(not record['request_end'] and not record['reset'], 'invalid request end')
    record['request_end'] = True
    if record['retired'] and record['response_end'] and record['debt'] == 0:
        del state['streams'][stream_id]


def reset_request(state, stream_id):
    record = stream(state, stream_id)
    require(not state['final'] and not record['reset'], 'invalid request reset')
    record['reset'] = True
    record['request_end'] = True
    record['response_end'] = True
    if record['retired'] and record['debt'] == 0:
        del state['streams'][stream_id]


def incoming_reset(state, stream_id):
    record = stream(state, stream_id)
    require(not record['reset'], 'duplicate incoming reset')
    record['reset'] = True
    record['request_end'] = True
    record['response_end'] = True


def end_response(state, stream_id):
    record = stream(state, stream_id)
    require(not record['response_end'], 'duplicate response terminal')
    record['response_end'] = True


def closed(record):
    return record['reset'] or (record['request_end'] and record['response_end'])


def retire(state, stream_id):
    record = stream(state, stream_id)
    require(record['response_end'] and not record['retired'], 'invalid retirement')
    record['retired'] = True
    if closed(record) and record['debt'] == 0:
        del state['streams'][stream_id]


def refund(state, stream_id, increment):
    number(stream_id, 0, MAX_WINDOW)
    number(increment, 1, MAX_WINDOW)
    if stream_id == 0:
        require(increment <= state['connection_debt'] and state['connection'] + increment <= MAX_WINDOW, 'invalid connection refund')
        state['connection_debt'] -= increment
        state['connection'] += increment
        return True
    record = stream(state, stream_id)
    require(increment <= record['debt'], 'invalid stream refund')
    emits = not closed(record)
    if emits:
        require(record['window'] + increment <= MAX_WINDOW, 'stream credit overflow')
        record['window'] += increment
    record['debt'] -= increment
    if record['retired'] and closed(record) and record['debt'] == 0:
        del state['streams'][stream_id]
    return emits


def compare_public(state, protocol, query_streams):
    require(type(query_streams) in (list, tuple), 'invalid query list')
    value = protocol.outbound_flow_control_window
    require(type(value) is int and value == state['connection'], 'connection credit differs')
    seen = set()
    for stream_id in query_streams:
        record = stream(state, stream_id)
        require(stream_id not in seen and not closed(record), 'invalid stream query')
        seen.add(stream_id)
        value = protocol.local_flow_control_window(stream_id)
        require(type(value) is int and value == min(state['connection'], record['window']), 'stream credit differs')


def server_initial_settings(state, initial_window):
    number(initial_window, 0, MAX_WINDOW)
    require(not state['final'] and not state['settings_seen'] and initial_window == INITIAL, 'unexpected server settings')
    state['settings_seen'] = True


def client_settings_sent(state):
    require(not state['final'] and state['client_settings'] < 2, 'invalid outgoing settings')
    state['client_settings'] += 1
