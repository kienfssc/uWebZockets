"""Bounded HTTP/2 response event and raw reset observation."""
import hashlib
import re
import h2.events
import raw_observer
import request_credit
import response_credit

READ_BOUND = 8192
STREAM_LIMIT = 8
HEADER_FIELDS = 32
HEADER_BYTES = 4096
INFO_COUNT = 16
INFO_BYTES = 16384
EVENT_LIMIT = 64


def require(condition, message):
    if not condition:
        raise ValueError(message)


def register(records, raw, stream_id, body_limit, final_status, info_count, policy, *,
             mode="small_body", credit_policy="auto", expected_sha256=None):
    require(len(records) < STREAM_LIMIT and stream_id not in records, 'stream record bound')
    require(type(stream_id) is int and type(body_limit) is int and type(info_count) is int,
            'invalid integer expectation')
    require(type(final_status) in (str, int) and re.fullmatch(r'[1-5][0-9]{2}', str(final_status)) is not None,
            'invalid status')
    require(type(mode) is str and mode in ('small_body', 'hash_only') and
            type(credit_policy) is str and credit_policy in ('auto', 'manual'), 'invalid mode or credit policy')
    require(info_count in (0, 1) and 0 <= body_limit <= 16777313, 'invalid expectation')
    if mode == 'small_body':
        require(body_limit < 4096 and expected_sha256 is None, 'invalid small body expectation')
    else:
        require(type(expected_sha256) is str and re.fullmatch(r'[0-9a-f]{64}', expected_sha256) is not None,
                'invalid expected digest')
        require(policy in ('healthy', 'refusal_after_final'), 'hash-only requires a final response')
    if policy in raw_observer.CLOSE_POLICIES:
        require(body_limit == 0 and info_count == 0, 'invalid close expectation')
    raw_observer.register(raw, stream_id, policy)
    records[stream_id] = {'headers': None, 'informationals': 0, 'info_bytes': 0,
                          'bytes': 0, 'hash': hashlib.sha256(), 'body': bytearray(),
                          'limit': body_limit, 'ended': False, 'reset_event': False,
                          'status': str(final_status), 'expected_info': info_count,
                          'policy': policy, 'mode': mode, 'credit_policy': credit_policy,
                          'expected_sha256': expected_sha256}


def checked_headers(headers):
    require(len(headers) <= HEADER_FIELDS, 'header field count bound')
    size = sum(len(k.encode('utf-8')) + len(v.encode('utf-8')) + 32 for k, v in headers)
    require(size <= HEADER_BYTES, 'header byte bound')
    return size


def accept(protocol, data, records, raw, trace, *, credit=None, request=None, stage=None):
    if stage is not None:
        require(credit is not None and request is not None, 'stage requires both credit ledgers')
    if credit is not None:
        require(all(record['credit_policy'] == 'manual' for record in records.values()), 'credit ledger requires manual mode')
    require(len(data) <= READ_BOUND, 'read exceeds bound')
    expected_updates = raw_observer.observe(raw, data, request=request, stage=stage)
    events = protocol.receive_data(data)
    if request is not None:
        actual_updates = [(event.stream_id, event.delta) for event in events if isinstance(event, h2.events.WindowUpdated)]
        require(actual_updates == expected_updates, 'WINDOW_UPDATE event sequence differs')
    for event in events:
        name = type(event).__name__
        require(name in trace or len(trace) < EVENT_LIMIT, 'event type bound')
        trace[name] = trace.get(name, 0) + 1
        if isinstance(event, h2.events.SettingsAcknowledged) and credit is not None:
            response_credit.settings_acknowledged(credit, event)
        if isinstance(event, h2.events.ConnectionTerminated):
            raise ValueError('HTTP/2 connection terminated')
        if not isinstance(event, (h2.events.InformationalResponseReceived, h2.events.ResponseReceived,
                                  h2.events.TrailersReceived, h2.events.DataReceived,
                                  h2.events.StreamEnded, h2.events.StreamReset)):
            continue
        require(event.stream_id in records, 'unregistered response stream')
        record = records[event.stream_id]
        if isinstance(event, h2.events.InformationalResponseReceived):
            size = checked_headers(event.headers)
            require(record['informationals'] < INFO_COUNT and record['info_bytes'] + size <= INFO_BYTES,
                    'informational bound')
            require(record['headers'] is None and not record['ended'] and not record['reset_event'] and [v for k, v in event.headers if k == ':status'] == ['100'] and not any(k == 'x-middleware' for k, _ in event.headers), 'unexpected informational')
            record['informationals'] += 1
            record['info_bytes'] += size
            require(record['informationals'] <= record['expected_info'], 'extra informational')
        elif isinstance(event, h2.events.ResponseReceived):
            checked_headers(event.headers)
            require(record['headers'] is None and not record['ended'] and not record['reset_event'], 'duplicate response headers')
            require([v for k, v in event.headers if k == ':status'] == [record['status']], 'wrong final status')
            require([v for k, v in event.headers if k == 'x-middleware'] == ['retained'], 'middleware header')
            record['headers'] = list(event.headers)
        elif isinstance(event, h2.events.TrailersReceived):
            raise ValueError('unexpected trailers')
        elif isinstance(event, h2.events.DataReceived):
            require(record['headers'] is not None and not record['ended'] and not record['reset_event'], 'DATA outside final response')
            require(record['bytes'] + len(event.data) <= record['limit'], 'response body bound')
            if credit is not None:
                response_credit.receive(credit, event.stream_id, len(event.data), event.flow_controlled_length)
            record['bytes'] += len(event.data)
            record['hash'].update(event.data)
            if record['mode'] == 'small_body':
                record['body'].extend(event.data)
            if record['credit_policy'] == 'auto':
                protocol.acknowledge_received_data(event.flow_controlled_length, event.stream_id)
        elif isinstance(event, h2.events.StreamEnded):
            require(record['headers'] is not None and not record['ended'] and not record['reset_event'], 'invalid end')
            if credit is not None:
                response_credit.end_response(credit, event.stream_id)
            record['ended'] = True
        elif isinstance(event, h2.events.StreamReset):
            require(record['policy'] in ('public_cancel', 'refusal_after_final', 'application_failure') and raw['streams'][event.stream_id]['reset'], 'unexpected reset event')
            code = {'public_cancel': 8, 'refusal_after_final': 0, 'application_failure': 2}[record['policy']]
            require(not record['reset_event'] and int(event.error_code) == code, 'invalid reset event')
            record['reset_event'] = True
            if credit is not None:
                response_credit.terminal(credit, event.stream_id, 'incoming_reset')

    return events




def send_data(protocol, records, request, stream_id, data, *, end_stream, pad_length):
    require(type(data) is bytes and type(end_stream) is bool and
            (pad_length is None or type(pad_length) is int and 0 <= pad_length <= 255), 'invalid DATA action')
    require(stream_id in records, 'unregistered request')
    record = records[stream_id]
    flow = len(data) + (0 if pad_length is None else pad_length + 1)
    require(not record['ended'] and not record['reset_event'] and
            (flow == 0 or record['informationals'] == record['expected_info']), 'DATA before Continue or after terminal')
    request_credit.validate_data(request, stream_id, len(data), flow)
    request_credit.compare_public(request, protocol, [stream_id])
    protocol.send_data(stream_id, data, end_stream=end_stream, pad_length=pad_length)
    request_credit.send_data(request, stream_id, len(data), flow)
    if end_stream:
        request_credit.end_request(request, stream_id)
    request_credit.compare_public(request, protocol, [] if end_stream and record['ended'] else [stream_id])

def send_peer_reset(protocol, records, raw, request, credit, stream_id, stage=None):
    require(stream_id in records and stream_id in raw['streams'], 'unregistered peer reset')
    record = records[stream_id]
    observed = raw['streams'][stream_id]
    outbound = request_credit.stream(request, stream_id)
    inbound = response_credit.stream(credit, stream_id)
    require(record['policy'] == 'peer_reset' and observed['policy'] == 'peer_reset' and
            not observed['end'] and not observed['peer_reset'] and not observed['reset'] and
            not outbound['reset'] and not request['final'] and not inbound['ended'], 'invalid peer reset')
    if stage is not None:
        require(stream_id in stage['active'] and not stage['active'][stream_id]['terminal'], 'invalid stage reset')
    protocol.reset_stream(stream_id, error_code=8)
    raw_observer.mark_peer_reset(raw, stream_id, 8)
    request_credit.reset_request(request, stream_id)
    response_credit.terminal(credit, stream_id, 'outgoing_reset')
    if stage is not None:
        stage['active'][stream_id]['terminal'] = True

def complete(records, raw, stream_id):
    record = records[stream_id]
    policy = record['policy']
    require(policy not in raw_observer.CLOSE_POLICIES, 'closing target requires explicit transport finalization')
    if policy in ('healthy', 'refusal_after_final'):
        require(record['headers'] is not None and record['ended'] and raw['streams'][stream_id]['end'], 'missing final')
        if record['mode'] == 'hash_only':
            require(record['bytes'] == record['limit'] and record['hash'].hexdigest() == record['expected_sha256'],
                    'body length or digest differs')
    else:
        require(record['headers'] is None and not record['ended'], 'unexpected final')
    require(record['informationals'] == record['expected_info'], 'missing informational')
    require(raw['streams'][stream_id]['reset'] == (policy in ('public_cancel', 'refusal_after_final', 'application_failure')), 'missing reset')
    if policy in ('public_cancel', 'application_failure'):
        require(record['reset_event'], 'missing reset event')
    if policy == 'peer_reset':
        require(raw['streams'][stream_id]['peer_reset'], 'missing outgoing reset')


def retire(records, raw, stream_id):
    complete(records, raw, stream_id)
    raw_observer.retire(raw, stream_id)
    del records[stream_id]


def begin_termination(records, raw, stream_id, policy, phase):
    require(set(records) == {stream_id}, 'other response remains in flight')
    record = records[stream_id]
    require(record['policy'] == policy and record['headers'] is None and record['informationals'] == 0 and
            record['bytes'] == 0 and not record['ended'] and not record['reset_event'], 'unexpected target response')
    raw_observer.begin_termination(raw, stream_id, policy, phase)


def finish_termination(records, raw, stream_id, policy, phase, outcome):
    require(set(records) == {stream_id}, 'other response remains in flight')
    record = records[stream_id]
    require(record['policy'] == policy and record['headers'] is None and record['informationals'] == 0 and
            record['bytes'] == 0 and not record['ended'] and not record['reset_event'], 'unexpected target response')
    if policy == 'clean_disconnect':
        proof = {'method': 'ssl_unwrap', 'tls_shutdown': 'success', 'tcp_eof': True,
                 'trailing_bytes': 0, 'close': 'normal'}
        require(outcome == proof and type(outcome.get('tcp_eof')) is bool and type(outcome.get('trailing_bytes')) is int,
                'strict close evidence differs')
    else:
        require(policy == 'owned_shutdown' and phase == 'post_signal' and outcome in ('eof', 'tls_eof'), 'invalid shutdown outcome')
    result = raw_observer.finish_termination(raw, stream_id, policy, phase, outcome)
    result['outcome'] = outcome
    del records[stream_id]
    return result
