"""Reject malformed server SETTINGS at the raw observation boundary."""
import output_stage
import raw_observer
import request_credit


def make_settings(ids):
    payload = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in ids)
    return len(payload).to_bytes(3, 'big') + b'\x04\0\0\0\0\0' + payload


def observe(ids):
    stage = output_stage.new_stage('ready_buffered', 1, 1, 10, 100)
    request = request_credit.new_state(request_credit.new_case('ready_buffered'))
    raw_observer.observe(raw_observer.new_state(), make_settings(ids), request=request, stage=stage)


def check():
    valid = ((1, 4096), (2, 0), (3, 8), (6, 8192), (8, 1))
    observe(valid)
    try:
        observe(((1, 4096), (2, 0), (3, 8), (6, 8192), (9, 1)))
    except ValueError as error:
        if str(error) != 'server settings shape differs':
            raise
    else:
        raise RuntimeError('server settings shape accepted')
    print('server settings shape checks passed')


if __name__ == '__main__':
    check()
