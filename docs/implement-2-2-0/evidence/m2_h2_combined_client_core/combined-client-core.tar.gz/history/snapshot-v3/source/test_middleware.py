"""Async completion makes no middleware-header guarantee."""
import h2_client
import hpack
import raw_observer
import request_credit
import response_credit
import wire


def check():
    protocol = h2_client.new_protocol()
    protocol.data_to_send(amount=8192)
    response = response_credit.new_state()
    response_credit.settings_sent(response, 65535, initial=True)
    request = request_credit.new_state(request_credit.new_case('async_delayed'))
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.accept(protocol, b'\0\0\0\4\0\0\0\0\0\0\0\0\4\1\0\0\0\0', records, raw, trace, credit=response, request=request)
    protocol.data_to_send(amount=8192)
    protocol.send_headers(1, [(':method', 'GET'), (':scheme', 'https'),
                              (':authority', 'localhost'), (':path', '/delayed')], end_stream=True)
    request_credit.open_stream(request, 1)
    request_credit.end_request(request, 1)
    response_credit.open_stream(response, 1)
    wire.register(records, raw, 1, 0, 200, 0, 'healthy', credit_policy='manual', middleware_policy='optional')
    protocol.data_to_send(amount=8192)
    block = hpack.Encoder().encode([(':status', '200')])
    packet = len(block).to_bytes(3, 'big') + b'\x01\x05\0\0\0\x01' + block
    wire.accept(protocol, packet, records, raw, trace, credit=response, request=request)
    wire.complete(records, raw, 1)
    print('async middleware policy checks passed')


if __name__ == '__main__':
    check()
