# Task 5e3a connection topology ruling

Ruling: preserve the accepted fresh-connection-per-case topology. The main
child keeps one App and the shared67 records/two reusable application slots;
it does not share one H2 connection across all39 main cases. Each main case
opens one fresh connection and disconnect additionally opens its replacement.
The idle child uses one connection:39+1+1=41 across the new combined run.

Authority: `task-5e-combined-architecture.md`, Topology and fixed constraints,
the per-case K counts, and unchanged v3 `catalogue.case_budget`/ROWS. This is
a clarification of the accepted plan, not a changed count or weaker test.

A fresh case's connection starts fresh parser, SETTINGS/ACK and connection
credit state. The final68 collection remains on the last case's existing
connection, retaining its parser, both ledgers, SETTINGS/ACK history, cumulative
read cap and remaining case/whole deadlines. No final-stage counter reset or
new deadline is allowed. Disconnect's replacement has independent protocol
state and never inherits old debt; its enclosing case's exact request/response,
DATA, byte/read, connection and SETTINGS budgets stay cumulative.

The worker's proposed redesign for a single shared connection across cases
would enforce a different topology and is unnecessary. Reversible correction:
remove any unneeded cross-case bind API and unsupported test, explain why in
the report, and keep all required same-connection final/replacement tests.
Cost if wrong: a revised topology would require new source-backed counts,
budgets and independent review; no such topology is authorized here.

Shutdown observation distinction: the source barrier contract forbids new
status/metrics/other observation requests after the shutdown signal. The later
owned close adapter must still consume the permitted final transport outcome
through the authoritative wire path; a pure codec transport-finalization test
does not claim a real EOF, TLS unwrap, child exit or native shutdown proof.
The current task remains source/pure-public-codec only.
