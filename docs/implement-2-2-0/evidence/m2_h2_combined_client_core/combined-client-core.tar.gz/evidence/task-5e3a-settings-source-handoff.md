# Task 5e3a exact server SETTINGS source binding

Root read these current frozen sources on 2026-10-30. This is a pure
source derivation; no compiler, native server, socket or TLS operation ran.

Root subsequently re-hashed all1031 frozen candidate files using the recorded
pathlib-sorted JSON pair encoding: aggregate
`fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`
matches the reviewed candidate. Current source and fixture identities are
retained in `task-5e3a-root-settings-audit.json` (actual audit exit0).

The combined fixture's initial server SETTINGS entries, in wire order, are
`[(1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)]`.

Source chain:

- `/tmp/uwz-task5e2-Fix1Final2/fixture/profile.zig:19` sets
  `max_header_size = 4096` and uses this `config` in `Server.preset` at251.
  SHA256 `6293bd687848b69a500206211eba155b0b7cdd67d35c61c7b9fd02974e10ac8e`
  matches both current fixture maps in `task-5e2-root-fix-1-audit.json` and
  `task-5e2-publication-source.json`.
- `/tmp/uwz-task4d-fix1-frozen/src/router/config.zig:35` aliases the TCP
  Http2Session. `h2_capacities` at512 maps request_header_size to
  max_header_size and dynamic_table_size to Http2Session.default_capacities.
  SHA256 `82fe3491b43a5122aa2024a74f270c6d52550a7db730d8085b3f024e031dc9a3`.
- `/tmp/uwz-task4d-fix1-frozen/src/core/tcp.zig:50` sets max_http2_streams8;
  at68 Http2Session is server_session(max_http2_streams).
  SHA256 `fb387a01c7cb29f7aa312801c42991edaacd3733584328ee488361760864873f`.
- `/tmp/uwz-task4d-fix1-frozen/src/http2/server.zig:128` gives the
  Capacities dynamic_table_size default4096; at566 default_capacities is
  Capacities{}. The storage plan at323 reserves exactly dynamic_table_size
  bytes, carved at443. Request_header_stride is set at466 to
  capacities.request_header_size. Session.init at645/653 retains these
  dynamic_bytes/request_header_stride values.
- The same server source at1927 advertises dynamic_bytes.len as SETTINGS1;
  send_settings at1930 serializes the five entries above into30 payload bytes.
  SETTINGS6 is request_header_stride; SETTINGS3 is max_streams.
  SHA256 `243a7768d8e4e1640b515bfa11824484bea0146b5fb28eb4ade3969969832b78`.

Thus the initial server SETTINGS frame is39 bytes. A SETTINGS ACK is9 bytes.
This does not establish arrival order, live startup success, per-case grant
counts or the complete wire budget. Retain the authenticated helper's actual
75-byte client startup and prove the remaining public-codec actions separately.
No model bound, case count, deadline or native-execution boundary changes.
