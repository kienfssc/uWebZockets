# Task5e3a: combined client credit and bounded stage core

RELEASED by Root after Task5e2 source/fix/publication reviews passed and commit
47717efb30b8c26a2d63c14d5da860bff937f215 was immediately pushed to fork.
This is ordered client preparation item3's first cohesive slice, not the full
combined cases/runner/closure or native run. Read saved task-5e-combined-architecture.md,
task-5e-barrier-source-handoff.md and the final reviewed Task5e1 v3 model notes.
Do not repeat whole architecture or prior output native proof.

Ownership: NEW .uwz-work/evidence/h2-streaming/integration-owned/combined-client/
core modules/tests, NEW /tmp/uwz-task5e3a-* and task-5e3a-report.md in this plan
workspace only. Preserve old12 client core files, runtime19, fixtures, model, public evidence
and immutable candidate. One implementer at a time; no agents/commits/pushes.
No case driver, live runner, process ownership/close adapter or runtime-closure
implementation in this slice. Root owns independent review/publication/releases.

## Immutable inputs and final fixture interfaces

Current reviewed model /tmp/uwz-task5e1-contract-v3, source identity map
task-5e1-publication-source.json. Use catalogue.py/model.py as immutable sources;
if copied into your new directory, preserve bytes/identities, not a second model.
Current fixture /tmp/uwz-task5e2-Fix1Final2/fixture,25files; exact source maps and
both compile receipts at task-5e2-root-fix-1-audit.json. Archive
docs/implement-2-2-0/evidence/m2_h2_combined_fixture/combined-fixture.tar.gz,
SHA c731e84571477286905ed9116fe8f3e6d820d492e6696fb3382947def8cb38c9.
The fixture is compiled/reviewed only; no full40 native evidence follows.
Status and metrics are canonical model keys/types, including paused totals;
pre/post formatting shares the same aggregation. Separate output producer/file
diagnostics and B binding preserve their existing schemas. Public routes are
/health, POST /echo, GET /delayed, POST /upload/:tag, /limit/:tag, /empty/:tag,
the model's metadata capture route, /status/:tag, /metrics, /resume/:tag,
/control/:op/:tag and /output/:tag. Setup nonce is1..32ASCII alphanumeric/_;
same safe32-byte nonce policy will apply to later runner, without native work now.

Read-only client12foundation /tmp/uwz-task5d1-round3-current, digest
4cc0b57f0347845f582d1f7e2621ee8ec0701fb83b0762590e7959370ecca81e;
runtime19 /tmp/uwz-task5d3-runtime-v5. Helper
.uwz-work/evidence/h2-streaming/integration-client/h2_client.py SHA
07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00
is source-only: do not call real connect/close/TLS/socket functions.
Pinned public codec packages /tmp/uwz-h2-client-tooling/packages,42files/digest
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Their provenance/licenses are retained in client-tooling and prior public archives.
Use pinnedPython /home/codespace/.python/current/bin/python3 with -B -S; tests
may explicitly add only these authenticated package paths, no installs/network.

Known source gaps requiring actual implementation, not relabeling:

1. request_credit.py currently fixes MAX_REQUEST_FLOW65 for both per-call and
   total flow. Replace the new copy's implicit output-only policy with explicit
   validated per-case catalogue limits, exact connection/stream debt and positive
   refund accounting. Cover 100000000 logical bytes in <=8192 chunks without big
   retained bodies, padding8, zero DATA allowance, duplicate/unknown/out-of-order
   streams, credits/overflow/types and connection separation. Preserve <=8 live
   streams, high-water ordering, known closed debt through late refunds, and the
   reviewed incoming-reset full closure rule. Don't loosen into unrestricted flow
   or keep an invisible default65 compatibility policy.
2. response_credit.py currently retires only END. Add explicit paired incoming
   reset, outgoing peer reset and normal transport retirement semantics. Known
   late request refunds remain separate from response-stream lifetime and public
   codec suppression on closed streams. No phantom WINDOW_UPDATE event, double
   debt application, transfer to replacement connection or reset-as-success.
   Preserve strict grants/initial-settings ACK and public-window comparisons.
3. output_stage.py currently assumes output kind, A32/final33/debt130, one reset,
   empty active/parser state at final and resets its read count. Implement finite
   explicit ordinary/Continue/special-output/reset/transport policies from current
   catalogue, preserving raw frame limits and exact reset counts. Final collection
   is67statuses+metrics once; active shutdown retains its one held request while
   collecting, and observes nothing after signal. Full final debt<=64, partial
   ending large<=131070; use actual remaining known debt with checked bounds.
   Carry parser/both ledgers, remaining case/whole deadline and cumulative inherited
   4096connection-read cap through the boundary, including shutdown_idle. Do not
   clear cumulative cap or create a new case deadline. Primary response limits,
   small response count, output DATA frames and public no-END-before-resume checks
   require explicit per-case policy, not generic unbounded flags.
4. wire.py currently provides earned raw-order/request+response+codec checks.
   Extend that same authoritative path for new policies and retirement actions;
   retain occurrence order/duplicate refund detection, raw END-before-NO_ERROR
   early-final rule and closed-codec suppression. strict_close's later runner
   adaptation must consume this path once, not raw observer then old aggregate
   refunds again. Expose a concrete narrow action/observation seam for later
   cases/close adapter rather than a forwarding wrapper or alternate raw parser.
5. Prove actual pure public-codec startup serialization and response grants using
   the authenticated helper's exact configuration/actions, without calling its
   real connect/socket/TLS entrypoints. Retain source-shaped server SETTINGS
   IDs1/2/3/6/8 and actual header/payload sizes. K=S=1 normally, disconnectK=S2,
   outputsK1/S2, ContinueI1. Keep all grants accounted once/bounded; partial/final
   stages preserve existing parser/ledger state. If pure source facts contradict
   proposed counts/bytes, report exact smallest correction to Root before any
   budget/deadline change. Model currently states startup unproved honestly.

Use existing reviewed sources /tmp/uwz-task5d1-round3-current and runtime-v5
and known pinned public h2/hpack/hyperframe codecs as read-only foundations; copy
cohesive modules into new owned directory. Do not author classes, unittest
inheritance, custom exception classes or assert proof statements. Imported public
codec objects and standard-library doubles are allowed with visible caller data.
Keep data types named/explicit/flat, state caller-owned, functions pure except
the later earned action seam's explicit public-codec calls. No native operation.

Focused pure public-codec tests must demonstrate real action/observation pairing,
new behavior RED/GREEN, legitimate large-flow/late-credit/Continue/reset/EOF/
final68/held-active/default cases, wrong action/event ordering and malformed type/
counter/budget rejection. Include splits/coalescence that address named ordering
risks, not native scheduling experiments. Retain true -B -S normal/-O outcomes,
AST/noClass/noAssert and inert imports under empty/foreign argv. No passing old
suite reruns without a source-specific need; no test mirrors of copied constants.

## Execution, evidence and delivery

Allowed: source reads/hashes, pure caller-owned data/AST/inert imports, and explicitly
in-memory public H2Connection/H2Configuration codec operations with the pinned
packages. These Python protocol objects are permitted; no real networking or
native constructor is implied. No permission to edit combined fixture, product or dependency
files, build or run a native binary/server/socket/SSLContext/cert/transfer file,
or perform descriptor/kernel/resource/fault/cancel/schedule/race/panic/leak probes.
Later combined cases, driver/close adapter, closure and separate Root exact
two-child native release remain required. No full40/milestone completion claim.

Before work load AGENTS/CODING and narrow TDD/API/source/verification skills.
Do not dispatch agents or an external model CLI. No classes/inheritance/assert
proof statements in authored tests or helpers, including auxiliary /tmp recorders.
Every reusable Python helper/recorder has a main guard and is covered by actual
silent/inert import proof with empty/foreign argv and rejecting caller-owned
doubles. Record exact new behavioral RED/GREEN and final normal/O commands,
stdout/stderr/exits in separate versioned evidence files. Keep snapshots immutable
and small. Do not turn a known unsupported action into silent success or weaken
existing frame/read/deadline/capacity bounds. Pure fixtures may use known valid
stream IDs and controlled bytes, never dummy/native descriptors or fault injection.

Keep modules cohesive; don't make a framework or one-function forwarding layers.
Build up actual per-case policy, paired accounting and pure proof incrementally.
Report concrete source disagreements to Root while completing independent work;
routine reversible API/data choices within this accepted plan need no user question.
Write full task-5e3a-report.md with changed files/APIs/source bindings, exact
commands/raw results/mutations/failure history, snapshot identities, self-review
and remaining facts. Return short status/report/check summary/concerns. Root reads
actual source/report/results before fresh independent review. No commits/pushes.

Graphify before new codebase questions; provided/earlier located files may be read:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
