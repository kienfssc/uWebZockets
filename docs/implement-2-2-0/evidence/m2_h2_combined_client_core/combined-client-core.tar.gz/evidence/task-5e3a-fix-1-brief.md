# Task 5e3a fix round1 of5: small-response role bound

Resume the original implementation ownership and all original requirements.
Fix only R1 below plus regression proof; preserve immutable v8 and historical
results. No source model/fixture/dependency/budget/count/deadline change, no
case driver, native/build/socket/TLS/transfer/probe release and no agents/Git.
You are not alone; do not edit Root's public draft, audit or review artifacts.

Root read the complete independent report in task-5e3a-review-report.md and
the fix-loop instructions before this round. R1 is the only Important finding.
Verbatim finding:

> Important — Small-response bounds can be bypassed through the storage mode.
> The `<4096` body limit applies only when `mode == 'small_body'`. Registration also accepts a stream with `role='small'`, `mode='hash_only'`, `body_limit=4096`, and a valid digest. A 4096-byte response then passes the receive and completion checks while remaining within an ordinary case’s aggregate byte budget.
>
> This violates the catalogue’s 4095-byte small-response ceiling and the requirement that response limits follow explicit case policy. Storage mode should not determine the protocol bound. Enforce the small-response ceiling from the staged role independently of mode. Add a focused regression proving this combination is rejected before registration or codec mutation, while special-output limits remain accepted. Existing tests do not cover this combination; I did not execute a new check.

Keep storage selection distinct from the staged protocol bound; do not reduce
any special-output limit or raise any small-response allowance. Add focused
test_small_response_bound.py (or a cohesive existing test extension) proving
actual RED on v8, then rejection before public codec output/stream allocation
or raw/request/response/stage registration changes. Include a valid4095-byte
hash-only small response positive control through real in-memory codec
observation/completion/paired retirement, not only a duplicated constant.

Covering checks: the focused bound regression, existing test_output_grants.py
for all special-output descriptors/policies, and test_structure.py for every
current file, in pinned -B -S normal and -O modes. No full passing-suite/native
rerun is needed for this scoped fix. Preserve exact commands, stdout/stderr/
exits and RED/GREEN source identities. If another covering test is needed,
state the concrete amended-code risk it addresses.

Guard all authored executable helpers and include actual inert import proof;
no reusable /tmp recorder outside coverage. Append the fix report to the same
task-5e3a-report.md with changed APIs/files, proof, final snapshot/map and exact
remaining facts. Clearly separate v8's40 outcomes from current covering runs;
do not relabel old receipts as covering changed wire.py. Freeze a new current
small snapshot, preserving v1-v8. Root will audit the amended code/evidence and
send an R1-only diff to the same reviewer. Do not implement additional future
case-driver policy in this fix; Root retains that later scope unchanged.
