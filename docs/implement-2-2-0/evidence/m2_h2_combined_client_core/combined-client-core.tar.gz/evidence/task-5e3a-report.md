# Task 5e3a combined client core: implementation for independent review

This is the source-only, pure-codec preparation slice. It is ready for Root to inspect and independently review; it is not a native combined40 run, a release, or a milestone-completion claim. It has not received the fresh independent source review or publication review. The later case driver, live runner, close adapter, process ownership/closure, and separately authorized native execution are still required.

Working source: `.uwz-work/evidence/h2-streaming/integration-owned/combined-client/`. Immutable small snapshot: `/tmp/uwz-task5e3a-snapshot-v8/` (1.9 MiB reported by `du -sh`); SHA-256 of its `SHA256SUMS` is `35353f7176ca38a84986446961e7c175d42986731c7ff197f4d8ba9e74a149a6`. It includes the current 25 Python source/test files, exact final normal/optimized receipts, and retained behavioral RED/GREEN receipts. Older v1–v7 snapshots and `/tmp/uwz-task5e3a-evidence-v1/` were preserved. Root's earlier audit of v4 is historical and does not establish correctness of v8.

## Source identities and scope

The immutable model is `/tmp/uwz-task5e1-contract-v3/catalogue.py` SHA-256 `7fa639c9372c8f01002fefba3647b2f82381e798484441d4b46c20d5d732453d` and `model.py` SHA-256 `ebb6164c01617045b6120a00977aeae88609053318f89b1891d9ede5c89b8175`; they are imported by path and were not copied or edited. The read-only prior client foundation is `/tmp/uwz-task5d1-round3-current`, release identity `4cc0b57f0347845f582d1f7e2621ee8ec0701fb83b0762590e7959370ecca81e`; the read-only runtime foundation is `/tmp/uwz-task5d3-runtime-v5`. The exact authenticated helper `.uwz-work/evidence/h2-streaming/integration-client/h2_client.py` SHA-256 is `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`. The pinned public package path `/tmp/uwz-h2-client-tooling/packages` has release identity `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`; no installation or network was used. Fixture/source maps and audited compile receipts remain those identified in the release brief; no fixture was changed or executed here.

The five new owned core modules and their v8 SHA-256 values:

```
03816bea5aa9cf2e7e6d9510befbd3060f97f034335bde66c01d63e98ee72444  request_credit.py
56bc8b2e5d13de574f4fd823c5e70daf3271e5cdeb9109e9f6eef720a59a1a17  response_credit.py
b2325893b79af82164f85d0b84596f1e6eb7f9e9fda14556478eec6c437f1291  output_stage.py
ac6847c7d88c8c7517c953555391637067b1b694d0789452c72fec569e42876c  raw_observer.py
6d3ff2e2f3019bbf390ef4fb0ca99189747d83f9e4016434d06dec7066e60dc1  wire.py
```

Source binding for the server's exact SETTINGS is `.superpowers/sdd/h2_streaming_plan/task-5e3a-settings-source-handoff.md`: frozen profile, router config, TCP and server sources derive ordered `(1,4096),(2,0),(3,8),(6,4096),(8,1)` and a 30-byte payload/39-byte frame. Root's topology ruling is `task-5e3a-topology-ruling.md`: a fresh connection per case, two for disconnect, same-connection final collection, and no post-signal observation requests. Root confirmed that no accepted schedule requires aggregate outstanding stream debt above the catalogue's 65535 bound: only the two large uploads and receive_credit have R > 65535 and each has one DATA-bearing upload stream. No model, limit, case count, deadline or dependency was changed.

## Owned APIs and accounting

`request_credit.new_case(case)` derives R, zero-DATA allowance and frame bounds from the immutable catalogue. `new_state(case)` keeps connection and stream credit/debt separate, allows eight active streams with increasing odd IDs, retains closed stream debt for late refunds, and accounts positive DATA flow including up to 256 padding bytes. Logical DATA spans are at most 8192 and total outstanding stream debt at most 65535. A shared case object makes both disconnect connections consume one R limit; each connection retains its own debts. Incoming reset closes both request/response sides. `transport_end` marks the original connection terminal and retains its debt; refunds after that terminal are rejected. The 802 retained-stream bound comes from the full reviewed 802-head topology, not the old implicit 65-byte policy.

`response_credit` tracks initial SETTINGS/ACK, public window values, grants, received logical and flow lengths, and distinct `end`, `incoming_reset`, `outgoing_reset`, and `transport` terminals. Normal end and incoming reset are not applied twice: the early-final codec test found that hyper-h2 may emit StreamReset after an END when the request side is still open, and the paired path now preserves the already-earned normal response terminal while validating the ordered NO_ERROR reset.

`output_stage.new_case` holds per-case counts and limits; separate `new_stage` connection states carry parser-adjacent counters, per-connection SETTINGS/ACK history, read counts and explicit case/whole deadlines. Disconnect's stages share case head/small/reset/bytes/reads totals and exact action/debt budget but have separate codec/raw/ledger identities; replacement creation is rejected until the original transport terminal. `remaining(stage, now)` is pure and rejects expired/invalid caller-supplied time. `enter_final` retains the existing parser, both ledgers, read counts and deadlines, checks actual debt and distinct response/request lifetime, and applies the model's 68-response budget. It accepts the one held shutdown request and enforces the 64 full-shutdown or 131070 partial limit. Final paths are the 67 distinct model status tags followed by metrics exactly once. `signal` rejects further observation registrations; permitted later terminal observation remains possible. Explicit roles and holds constrain ordinary, reset, transport, Continue and output streams, response DATA frame limits and no END before the required resume/full special-output grant.

`wire` is the bound action/observation seam. `bind_connection` ties codec, raw state, both credit ledgers and caller-owned response records to one stage and rejects a replacement using the old codec, old ledger, or a separate case budget. `startup` serializes the authenticated helper's actual 75-byte client preface/SETTINGS (24 + 9 + 42), checks its seven emitted SETTINGS values, and pairs both initial ledgers. `update_settings` pairs the second public SETTINGS action for the output policies. `start_request` preflights stage and both ledgers, validates the 8192-byte header bound, emits the public codec HEADERS, returns at most 8192-byte chunks and rejects unflushed preceding output. `send_data`, `send_trailers`, `send_peer_reset`, `grant`, `drain`, `accept`, `retire`, `enter_final`, `finish_final`, and staged transport termination pair their public codec actions or observations to the appropriate caller-owned state. `drain` is limited to 8192 bytes. The public response path requires manual paired grants and mandatory raw observer/stage/request/response ledgers; it does not use the old auto-ack or aggregate-refund path. Invalid decoded input marks the action path failed. A pending-output ordering error fails the stage and retains the first bounded pending chunk; a later runner must abort that failed connection rather than continue it.

`new_grants(stage)` installs one per-connection grant policy. Output bootstrap reaches 33554432 once, credits any prior received bytes only once, and ordinary connection replenishment cannot exceed uncredited received flow. Stream grants are restricted to a single 65535 auxiliary grant when the acknowledged initial stream window is zero, or the case-specific special sequence: producer 16777313, pressure 8192 then 16769121, file 24593, early final 8 then 9, and no primary stream grant for pressure-ready. Special output remains held until its final prescribed grant. The early 8+9 test also proves the 8192/8 prefix requirement before the second grant. Grant frames and public windows are checked in memory; no live server behavior is inferred.

## Final commands and raw results

All commands used `/home/codespace/.python/current/bin/python3` and:

```
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client
```

For each `test_*.py` under the owned directory, the exact command form was:

```
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S "$file"
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -O -B -S "$file"
```

Each of 20 scripts exited 0 in both modes; each stderr was empty. The exact per-command stdout, stderr and exit files are `final22-{normal,optimized}-<test>.{stdout,stderr,exit}` under the evidence directory and snapshot. The raw stdout in each mode, in filename order, was:

```
bootstrap credit accounting checks passed
disconnect case counters passed
early END before reset checks passed
public codec final 68 checks passed
public codec held final 68 checks passed
bounded codec grant checks passed
request action ordering checks passed
public codec large flow checks passed bytes=100000000 frames=12208
async middleware policy checks passed
special output grant schedules passed
startup_bytes=75 startup_settings_payload=42 server_settings_bytes=39 ack_bytes=9 grant_bytes=26
request-credit checks passed
response retirement checks passed
no END before resume checks passed
server settings shape checks passed
all output settings variants passed
stage final checks passed
AST and inert imports passed for 25 files
padded trailer action checks passed
transport retirement checks passed
ordered codec reset/refund checks passed
```

The 100000000-byte test sends actual public-codec DATA in bounded spans and drains at most 8192 bytes at a time, without retaining the body. Its 12208 is an observed frame count in that controlled pure test, not a throughput measurement. The final68 tests pass synthetic model-generated JSON through the actual public codec, decode it, and validate default/held records and metrics against the immutable model; they do not establish that a native fixture emitted those bytes. Pure termination tests supply outcome records and prove state handling only; they do not establish real TLS unwrap, socket EOF, child exit, or native shutdown.

`test_structure.py` parses all 25 files and executes actual silent imports under both empty and foreign argv using caller-owned rejecting stdout/stderr, socket and TLS-context doubles. It checks no authored class or `assert` statements and main guards for all authored tests. Public codec and standard-library objects are imported as allowed. No reusable `/tmp` Python recorder was authored.

## Failure history and review notes

Actual REDs and subsequent GREENs are preserved separately in v7. Representative raw first failures: missing per-case `new_case`, missing response `terminal`, old three-argument stage, missing paired reset and HEADERS/trailer/startup actions; accepting wrong SETTINGS ID/value; accepting duplicate bootstrap credit; accepting special-grant bypass; failing to enforce aggregate stream debt; accepting disconnect's cumulative 4097th read; allowing replacement before old transport terminal; and not failing closed after END-before-resume. The actual early-final public codec first failed with `ValueError: duplicate response terminal`; the corrected paired END/reset test passes in both modes. The trial stage-ledger boundary initially accepted a missing held response ledger; its RED and GREEN are retained. A trial malformed 100 test used a 10-byte rather than 9-byte frame header and was corrected. A temporary refactor caused a Python `SyntaxError` and a subsequent name-binding mistake, both corrected before final evidence. An abandoned cross-case transition test had a local-variable error; Root's topology ruling established that its premise was wrong, so it and the speculative cross-case bind API were removed. Earlier a copied file was read-only until its new owned copy was made writable; an initial read command misspelled `CONTRIBUTE.md` and was corrected.

Self-review: the stage and wire APIs are deliberately fail-closed and require the later adapter to use this one path. The later runner must flush returned header chunks before observation, use bounded `drain`, supply checked remaining time, call `enter_final`/`finish_final`, consume post-signal transport data once through `accept`, and never replay aggregate refunds. It must choose the actual primary stream and exact response expectations from the released case schedule; case drivers, barrier ordering and native lifecycle are outside this slice. The synthetic final records validate codec/state/model handling only; full fixture data, source-selected status values, producer/file hashes, callback evidence and two-child behavior remain later work. The required independent reviewer should specifically assess per-case role/hold selection, 8-stream and 802-retained bounds, disconnect shared counters, frame ordering, failure atomicity, grant totals, and exact source policy before accepting this work.

No native builds, binaries, sockets, TLS contexts, certificates, descriptors, servers, transfers, scheduling/fault probes, installs, commits, or pushes were performed. The full Zig matrix, sanitizers, fuzz, compliance and package gates were not run because this release authorizes only source and pure public-codec work. Graphify was queried for the admission reset source; its graph was not updated because this slice owns only the new client directory, `/tmp/uwz-task5e3a-*`, and this report. No measured performance claim is made.

## Fix round 1: R1 small-response role bound

Independent review identified one Important finding: a `small` staged response could choose `hash_only` storage and a 4096-byte limit, bypassing the protocol's 4095-byte small-response ceiling. The only core change is in `wire.register`: after validating `body_limit` and before `raw_observer.register`, it requires `body_limit < 4096` whenever the staged role is `small`, independently of storage mode. Special-output descriptors and limits are unchanged. `wire.start_request` preflights registration on caller-owned copies before codec HEADERS serialization or stream registration, so rejection happens before public codec output and caller state mutation. No APIs, model, fixture, budget, deadline, dependency, native code or case-driver policy changed.

The new `test_small_response_bound.py` first tries a hash-only small response with a 4096-byte limit and a valid SHA-256, then verifies the rejected action leaves codec output/next stream ID, raw/request/response/stage registration, counters, trace and caller-owned records unchanged. The positive control sends a 4095-byte hash-only small response through actual public in-memory codec observation, verifies its digest and non-retained body, and performs paired retirement. The retained `test_output_grants.py` covers the unchanged special-output descriptors/policies. `test_structure.py` checks all 26 current files, including the new guarded test, with actual silent imports under empty/foreign argv and rejecting doubles.

Actual RED was run against v8 `wire.py` SHA-256 `6d3ff2e2f3019bbf390ef4fb0ca99189747d83f9e4016434d06dec7066e60dc1` and test source SHA-256 `1f3b77518d0ccca6ce91a2159cad85e07bda3603626869586ca20b05014cac8a`. Exact command:

```
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-client/test_small_response_bound.py
```

It exited 1 with empty stdout and stderr ending in `RuntimeError: 4096-byte hash-only small response accepted`. The exact original RED test text is retained as inert `evidence/red-test-source.txt` in v9; its hash is the RED identity above. The final test additionally compares pre/post counters and has SHA-256 `d4e75c18f3bad643ca869240b4b0304235367b407e5ffbc143845337b685ec48`; amended `wire.py` SHA-256 is `25d32260dabf3d7a603bf9a2269f7bd4f80bb07ce10f7127e7689242e52b6a86`.

For each `test` in `small_response_bound output_grants structure`, the following exact command form was run in both modes:

```
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-client/test_${test}.py
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -O -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-client/test_${test}.py
```

All six current covering commands exited 0 with empty stderr. Each mode's exact stdout, in the stated test order, was:

```
small response role bound checks passed
special output grant schedules passed
AST and inert imports passed for 26 files
```

The exact separate stdout/stderr/exit receipts are `final-{normal,optimized}-<test>.{stdout,stderr,exit}` under `/tmp/uwz-task5e3a-fix1-evidence/` and the immutable v9 snapshot. The earlier v8 40 successful full focused outcomes above describe the previous `wire.py`; they are historical and are not claimed as covering the amended module. No broader suite or native gate was run in this scoped fix.

Current immutable snapshot: `/tmp/uwz-task5e3a-snapshot-v9/` (256 KiB reported by `du -sh`); its `SHA256SUMS` SHA-256 is `300cd10d7076daa04feb374186f14e9ed7c1ed4d936eaef46670da6a68382d42`. It contains all 26 current source/test files, current covering receipts, and the v8 RED receipt/source text. V1–v8 and their evidence remain unchanged. Root must inspect the amended source and receipts and obtain the specified R1-only independent re-review; later case-driver, runtime closure, native two-child combined execution and full project gates remain outstanding.
