# Task 5e3a fresh source/spec/quality review

Read `task-5e3a-client-core-brief.md` first: it is the implementation's exact
requirements, including all five gaps. Then read `task-5e3a-report.md` and the
complete `task-5e3a-review-source.diff` once. The report is a claim to check.
Also read the two Root clarifications: `task-5e3a-settings-source-handoff.md`
and `task-5e3a-topology-ruling.md`. All paths here are in this plan workspace.

## Frozen review input

Git base and HEAD are both47717efb30b8c26a2d63c14d5da860bff937f215. The new
owned sources are ignored preparation files, not a committed product change;
the review package is their complete added-file diff, not an empty Git range.
It includes all25 source/test files and2667 lines from the frozen v8 snapshot.
Diff SHA2567426f9666ad17f77ba6c016cbd3834bb908b56c9fef213f7f89ebae880cd859f,
137542 bytes. Do not issue Git commands to regenerate a different diff.

Immutable source/evidence: `/tmp/uwz-task5e3a-snapshot-v8`, SHA256SUMS SHA256
35353f7176ca38a84986446961e7c175d42986731c7ff197f4d8ba9e74a149a6.
Root's actual `sha256sum -c` exited0 across625 entries. All25 frozen sources
equal current owned bytes. Root read the complete86-line final report, the
core API implementation and the large/final68/held/header proof source; all40
final22 normal/O raw stdout/stderr/exit receipts are recorded in
`task-5e3a-root-v8-audit.json`, each0 with empty stderr. The audit also checks
old12 client and pinned42 codec input digests, model and helper source hashes.
Historical v4/v5 audits do not cover v8. Evidence is source/pure-codec only.

## Binding constraints

The following is copied from the released requirements:

> Allowed: source reads/hashes, pure caller-owned data/AST/inert imports, and explicitly
> in-memory public H2Connection/H2Configuration codec operations with the pinned
> packages. These Python protocol objects are permitted; no real networking or
> native constructor is implied. No permission to edit combined fixture, product or dependency
> files, build or run a native binary/server/socket/SSLContext/cert/transfer file,
> or perform descriptor/kernel/resource/fault/cancel/schedule/race/panic/leak probes.
> Later combined cases, driver/close adapter, closure and separate Root exact
> two-child native release remain required. No full40/milestone completion claim.

> No classes/inheritance/assert
> proof statements in authored tests or helpers, including auxiliary /tmp recorders.
> Every reusable Python helper/recorder has a main guard and is covered by actual
> silent/inert import proof with empty/foreign argv and rejecting caller-owned
> doubles. Record exact new behavioral RED/GREEN and final normal/O commands,
> stdout/stderr/exits in separate versioned evidence files. Keep snapshots immutable
> and small. Do not turn a known unsupported action into silent success or weaken
> existing frame/read/deadline/capacity bounds.

All five original gaps remain binding: explicit catalogue R/zero/padding/debt
bounds; explicit response/reset/transport retirement; ordinary/Continue/output/
reset/transport stage policy and final68 with inherited parser/ledgers/deadlines/
read cap; one earned ordered wire path; actual helper startup/settings/grants.
Read exact numeric requirements in the original brief. The model/fixture and
prior native results remain unchanged inputs. Final synthetic model JSON and
supplied transport records establish pure handling, not fixture/native output.

Topology and debt clarification: idle1+main39+disconnect replacement1=41 fresh
connections in two sequential children. Only final collection shares its
preceding case connection. Disconnect totals remain cumulative across its two
independent connections. No accepted case needs aggregate stream debt>65535:
only the two100M cases and receive_credit have R>65535, each on one DATA stream.
No case count, capacity, receive ceiling or deadline changed.

## Review contract

You are read-only. Do not edit sources, evidence, index, refs or branch; do
not dispatch agents or external model CLIs. Read AGENTS/CODING, the reviewer
role and applicable HTTP/verification instructions. Apply code-review-and-quality.
Root explicitly requests the thermo-nuclear-code-quality-review structural
lens under the AGENTS override; this is a scoped review, not a repository scan.

Judge spec compliance, correctness/ownership/security, compatibility,
conventions, actual evidence and maintainability. Review the diff once; its
full added files are the source view. Inspect outside it only for a named
concrete risk, using a focused existing locator. Graphify first before a new
codebase search (provided paths are already located). Never re-run passed
tests or import/run native or client entrypoints. If a specific unresolved
doubt needs execution, state the focused proposed check and why existing
evidence does not answer it. No new execution release is granted here.

Return both SPEC COMPLIANCE and TASK QUALITY verdicts, strengths with locators,
actionable Critical/Important/Minor findings with file:line and concrete failure
scenario, and explicit cannot-verify items. Keep severity technical. The final
message is the report itself; Root stores it in the plan workspace. No review
file write is required. No merge, PR, push or milestone-completion claim.
