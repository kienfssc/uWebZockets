"""Validate actual runtime, tools, source trees and two compile receipts."""
import hashlib
import json
from pathlib import Path


ROOT = Path('/workspaces/uWebZockets')
SOURCE = ROOT / '.uwz-work/evidence/h2-streaming/integration-owned/output-driver'
BASE = ROOT / '.uwz-work/evidence/h2-streaming/integration-owned/lifecycle-close/manifest-v4.json'
PUBLIC = ROOT / 'docs/implement-2-2-0/evidence/m2_h2_output_fixture/manifest.json'
RUNTIME = Path('/tmp/uwz-task5d3-runtime-v3')
CLIENT = Path('/tmp/uwz-task5d1-round3-current')
FIXTURE = Path('/tmp/uwz-task5d2-fix2-final-snapshot')
COMPILE = Path('/tmp/uwz-task5d2-fix1final/fixture')
CANDIDATE = Path('/tmp/uwz-task4d-fix1-frozen')
OVERRIDE = Path('/tmp/uwz-reviewed-libxev-c223-loop-callbacks')
HELPER = ROOT / '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py'
PACKAGES = '/tmp/uwz-h2-client-tooling/packages'
PYTHON = '/home/codespace/.python/current/bin/python3'
BASE_HASH = 'fc64a55cb7de3f1473a1883d12911366fe26aea745ec424cba4f0ff863258da9'
PUBLIC_HASH = '03b5ea790e9b61d361053eed0b7650a0acf7499b5da01c34442cb517e5a9b20a'
CAPACITY = 'H2_CAPACITY config={"max_connections":8,"max_ws_message_size":16384,"write_queue_size":65536,"stream_request_bodies":true,"max_body_size":256,"max_request_line_size":512,"max_header_size":4096,"max_header_count":80,"max_route_nodes":256,"max_pattern_routes":64,"max_middleware":32,"max_route_path_size":2048,"max_route_params":24,"max_route_registry_size":65536,"max_h2_header_block_size":8192,"max_h2_body_size":4096,"max_h2_response_header_size":4096,"max_h2_response_header_count":32,"max_h3_body_size":16384,"max_h3_response_header_size":4096,"max_h3_response_header_count":64,"idle_timeout_ms":120000,"header_read_timeout_ms":30000,"compression":false,"http_compression":false,"transport":"standard","max_datagram_size":0,"datagram_slots":0,"xdp_frame_size":2048,"xdp_frame_count":1024,"observability":false,"metrics_path":"/metrics","enable_dev_log":false,"watch_paths":[]} request_stride=5888 h2_bytes=281200 h2_stride=281200 slab=4098304 router=884352'
HELPER_HASH = '07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00'
SOURCE_HASH = 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de'
RECEIPTS = (Path('/tmp/uwz-task5d2-fix1final/debug-receipt.json'), Path('/tmp/uwz-task5d2-fix1final/release-receipt.json'))
RUNTIME_NAMES = ('capture.py', 'case_adapter.py', 'cases.py', 'connection.py', 'diagnostics.py', 'driver.py',
                 'identity.py', 'orchestration.py', 'owned_io.py', 'post.py', 'process_cleanup.py',
                 'process_io.py', 'process_setup.py', 'process_shutdown.py', 'protocol.py', 'records.py',
                 'sessions.py', 'closure.py', 'run_live.py')


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        while data := stream.read(1048576):
            h.update(data)
    return h.hexdigest()


def inventory(path):
    return {str(item.relative_to(path)): digest(item) for item in sorted(path.rglob('*')) if item.is_file()}


def aggregate(items):
    pairs = [(name, items[name]) for name in sorted(items, key=Path)]
    return hashlib.sha256(json.dumps(pairs).encode()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate(path, expected):
    require(digest(path) == expected, 'manifest identity differs')
    require(digest(BASE) == BASE_HASH and digest(PUBLIC) == PUBLIC_HASH and digest(HELPER) == HELPER_HASH,
            'approved source anchor differs')
    base = json.loads(BASE.read_text())
    public = json.loads(PUBLIC.read_text())
    manifest = json.loads(Path(path).read_text())
    require(manifest['state'] == 'ready-for-independent-review' and manifest['python'] == PYTHON and
            manifest['python_flags'] == ['-B', '-S'] and manifest['capacity'] == CAPACITY and
            manifest['environment'] == {'LC_ALL': 'C.UTF-8', 'PYTHONPATH': PACKAGES + ':' + str(CLIENT)},
            'runtime configuration differs')
    trees = manifest['trees']
    retained = {name: value for name, value in base['trees'].items()
                if name not in ('/tmp/uwz-task5c3-fixture-v1', '/tmp/uwz-task5c3-runtime-v2')}
    required_roots = set(retained) | {str(SOURCE), str(RUNTIME), str(CLIENT), str(FIXTURE), str(COMPILE)}
    require(set(trees) == required_roots, 'tree roots differ')
    for name, files in trees.items():
        require(inventory(Path(name)) == files, 'tree identity differs: ' + name)
    for name, files in retained.items():
        require(trees[name] == files, 'reviewed tree differs: ' + name)
    require(trees[str(CLIENT)] == public['current_client_files'] and
            aggregate(trees[str(CLIENT)]) == public['current_client_digest'] and
            trees[str(FIXTURE)] == public['current_fixture_files'], 'reviewed fixture or client differs')
    require(aggregate(trees[str(CANDIDATE)]) == SOURCE_HASH and
            len(trees[str(CANDIDATE)]) == 1031 and len(trees[str(OVERRIDE)]) == 93, 'source cohort differs')
    require(set(trees[str(RUNTIME)]) == set(RUNTIME_NAMES), 'runtime file set differs')
    for name in RUNTIME_NAMES:
        require(trees[str(SOURCE)].get(name) == trees[str(RUNTIME)][name], 'runtime source differs: ' + name)
    retained_prefix = ('/home/codespace/.python/current/', '/lib/', '/lib64/', '/opt/conda/')
    inputs = {name: value for name, value in base['inputs'].items() if name.startswith(retained_prefix)}
    inputs.update({str(BASE): BASE_HASH, str(PUBLIC): PUBLIC_HASH, str(HELPER): HELPER_HASH})
    builds = public['builds']
    for path_receipt, label, optimize in zip(RECEIPTS, ('debug', 'release'), ('-ODebug', '-OReleaseSafe')):
        expected_receipt = builds[label]['receipt_sha256']
        require(digest(path_receipt) == expected_receipt, 'receipt identity differs')
        receipt = json.loads(path_receipt.read_text())
        require(receipt['exit_status'] == 0 and receipt['execution'] == 'compile only; binary not executed' and
                receipt['environment'] == {'LC_ALL': 'C.UTF-8'} and receipt['cwd'] == str(CANDIDATE) and
                receipt['inputs_before'] == receipt['inputs_after'] and receipt['fixture_before'] == receipt['fixture_after'] and
                receipt['source_before'] == receipt['source_after'] == trees[str(CANDIDATE)] and
                receipt['override_before'] == receipt['override_after'] == trees[str(OVERRIDE)] and
                receipt['fixture_before'] == trees[str(COMPILE)] and receipt['source_before_sha256'] == SOURCE_HASH and
                receipt['source_after_sha256'] == SOURCE_HASH and optimize in receipt['argv'] and '-j2' in receipt['argv'],
                'compile receipt differs')
        require(all(trees[str(COMPILE)][name] == trees[str(FIXTURE)][name] for name in
                    ('profile.zig', 'output.zig', 'file_observer.zig', 'prepare.py')), 'compile snapshot differs')
        for name, value in receipt['inputs_before'].items():
            require(name not in inputs or inputs[name] == value, 'conflicting build input')
            inputs[name] = value
        inputs[str(path_receipt)] = expected_receipt
        binary = next(item.split('=', 1)[1] for item in receipt['argv'] if item.startswith('-femit-bin='))
        require(receipt['binary_sha256'] == builds[label]['binary_sha256'] and manifest['binaries'][label] == binary,
                'binary identity differs')
        inputs[binary] = receipt['binary_sha256']
        for suffix in ('stdout', 'stderr'):
            log = path_receipt.parent / (label + '.' + suffix)
            require(log.read_bytes() == b'', 'compiler log differs')
            inputs[str(log)] = digest(log)
    require(manifest['inputs'] == inputs, 'direct input set differs')
    for name, value in inputs.items():
        require(digest(name) == value, 'input identity differs: ' + name)
    return manifest
