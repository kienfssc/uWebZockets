"""Best-effort cleanup after a failed owned run, retaining each error."""


def emergency(state, clock, ops):
    errors = []
    deadline = clock() + 15
    child = state.get('child')
    if child is not None and not state.get('reaped'):
        try:
            if ops['poll'](child) is None:
                if state.get('start') is None or ops['start'](child['pid']) != state['start']:
                    raise ValueError('child start identity changed')
                ops['kill'](child)
                state['forced'] = True
        except BaseException as exc:
            errors.append({'action': 'child_kill', 'error': repr(exc)})
        try:
            state['exit_status'] = ops['wait'](child, deadline)
            state['reaped'] = True
        except BaseException as exc:
            errors.append({'action': 'child_wait', 'error': repr(exc)})
    if state.get('capture') is not None and not state.get('collector_joined'):
        try:
            ops['join'](state['capture'], deadline)
            state['collector_joined'] = True
        except BaseException as exc:
            errors.append({'action': 'collector_join', 'error': repr(exc)})
    if child is not None and state.get('capture') is None:
        try:
            ops['close_pipe'](child)
        except BaseException as exc:
            errors.append({'action': 'pipe_close', 'error': repr(exc)})
    for name in ('key', 'transfer'):
        if name not in state:
            continue
        try:
            ops['unlink'](state[name])
            if ops['absent'](state[name]) is not True:
                raise ValueError('temporary file remains')
            state[name + '_removed'] = True
        except BaseException as exc:
            errors.append({'action': name, 'error': repr(exc)})
    return errors
