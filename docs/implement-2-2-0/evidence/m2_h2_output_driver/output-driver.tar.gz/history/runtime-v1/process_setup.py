"""Order certificate creation and the owned fixture's readiness checks."""
import posixpath
import re


OPENSSL = '/opt/conda/bin/openssl'


def prepare(state, directory, binary, nonce, capacity, overall, clock, ops):
    if (type(state) is not dict or state or type(directory) is not str or
            not directory.startswith('/tmp/') or posixpath.normpath(directory) != directory or
            type(binary) is not str or not binary.startswith('/') or
            type(nonce) is not str or re.fullmatch(r'[a-zA-Z0-9_-]{1,64}', nonce) is None):
        raise ValueError('invalid fixture setup inputs')
    cert = directory + '/certificate.pem'
    key = directory + '/private-key.pem'
    transfer = directory + '/transfer.bin'
    state.update(directory=directory, cert=cert, key=key, transfer=transfer, child=None, capture=None)
    ops['directory'](directory, 0o700)
    command = [OPENSSL, 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
               '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost',
               '-keyout', key, '-out', cert]
    certificate_env = {'OPENSSL_CONF': '/opt/conda/ssl/openssl.cnf'}
    state['certificate_argv'] = command
    state['certificate_environment'] = certificate_env
    try:
        result = ops['certificate'](command, certificate_env, overall)
    except BaseException as exc:
        for name in ('stdout', 'stderr'):
            data = getattr(exc, name, None)
            if type(data) is bytes:
                state['certificate_' + name + '_hex'] = data.hex()
        raise
    for name in ('stdout', 'stderr'):
        data = getattr(result, name, None)
        if type(data) is not bytes or len(data) > 65536:
            raise ValueError('certificate output bound')
        state['certificate_' + name + '_hex'] = data.hex()
    ops['chmod'](key, 0o600)
    state['cert_hash'] = ops['digest'](cert)
    if type(state['cert_hash']) is not str or re.fullmatch(r'[0-9a-f]{64}', state['cert_hash']) is None:
        raise ValueError('invalid certificate digest')
    env = {'H2_PROFILE_CERT': cert, 'H2_PROFILE_KEY': key, 'H2_PROFILE_NONCE': nonce,
           'H2_PROFILE_FILE': transfer}
    state['child_argv'] = [binary]
    state['child_environment'] = env
    child = ops['spawn']([binary], env)
    state['child'] = child
    state['start'] = ops['start'](child['pid'])
    state['capture'] = ops['collector'](child)
    deadline = min(overall, clock() + 15)
    state['listener'] = ops['ready'](child, state['start'], state['capture'], nonce, capacity, deadline)
    return state
