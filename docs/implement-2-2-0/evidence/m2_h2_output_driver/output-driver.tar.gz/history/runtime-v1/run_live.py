"""Explicitly gated owned output fixture entrypoint; importing is inert."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import closure


CASES = ('output_pressure_window', 'output_pressure_ready', 'producer_reuse', 'stream_file', 'early_final_order')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true', required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--mode', choices=('debug', 'release'), required=True)
    parser.add_argument('--cases', nargs='+', choices=CASES, required=True)
    args = parser.parse_args()
    require(sys.executable == closure.PYTHON and sys.dont_write_bytecode and sys.flags.no_site,
            'interpreter or flags differ')
    require(dict(os.environ) == {'LC_ALL': 'C.UTF-8', 'PYTHONPATH': closure.PACKAGES + ':' + str(closure.CLIENT)},
            'runtime environment differs')
    require(bool(args.cases) and len(set(args.cases)) == len(args.cases), 'invalid case selection')
    output = Path(args.output)
    require(output.is_absolute() and output.resolve().is_relative_to(Path('/tmp')) and output.resolve() != Path('/tmp') and
            not os.path.lexists(output), 'output path differs')
    manifest = closure.validate(args.manifest, args.manifest_sha256)
    require(Path(__file__).resolve() == closure.RUNTIME / 'run_live.py' and
            Path(closure.__file__).resolve() == closure.RUNTIME / 'closure.py', 'runtime origin differs')
    import contracts
    require(Path(contracts.__file__).resolve() == closure.CLIENT / 'contracts.py', 'contract origin differs')
    import driver
    import process_cleanup
    import process_io
    for module in (driver, process_cleanup, process_io):
        require(Path(module.__file__).resolve().parent == closure.RUNTIME, 'runtime import differs')
    spec = importlib.util.spec_from_file_location('bound_h2_client', closure.HELPER)
    require(spec is not None and spec.loader is not None, 'helper loader unavailable')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    require(helper.payload_block(32, 0, 32) == contracts.P32, 'payload identity differs')
    import h2
    import hpack
    import hyperframe
    for module in (h2, hpack, hyperframe):
        require(Path(module.__file__).resolve().is_relative_to(Path(closure.PACKAGES)), 'codec origin differs')
    nonce = os.urandom(16).hex()
    evidence = {'nonce': nonce, 'selection': args.cases, 'manifest_sha256': args.manifest_sha256,
                'binary_mode': args.mode}
    ops = process_io.operations(time.monotonic)
    error = None
    try:
        driver.run(tuple(args.cases), str(output), manifest['binaries'][args.mode], nonce, manifest['capacity'],
                   time.monotonic, ops, lambda state, clock: process_cleanup.emergency(state, clock, ops), evidence)
    except BaseException as exc:
        error = exc
    try:
        if output.is_dir():
            raw = bytes.fromhex(evidence.get('server_output_hex', ''))
            (output / 'server.log').write_bytes(raw)
            (output / 'result.json').write_text(json.dumps(evidence, indent=2, sort_keys=True) + '\n')
    except BaseException as persistence_error:
        if error is None:
            raise
        error.add_note('result persistence failed: ' + repr(persistence_error))
    if error is not None:
        raise error


if __name__ == '__main__':
    main()
