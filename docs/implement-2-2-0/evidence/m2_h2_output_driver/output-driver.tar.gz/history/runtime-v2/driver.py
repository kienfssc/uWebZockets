"""Compose owned setup, case sessions, shutdown and failure cleanup."""
import traceback
import connection
import process_setup
import process_shutdown
import sessions


def run(selection, directory, binary, nonce, capacity, clock, ops, cleanup, evidence=None):
    if evidence is None:
        evidence = {}
    state = {}
    overall = clock() + 900
    stage = 'setup'
    try:
        process_setup.prepare(state, directory, binary, nonce, capacity, overall, clock, ops)
        stage = 'tls'
        tls = connection.tls_context(state['cert'])
        def owned():
            ops['owned'](state['child'], state['start'], state['listener'])
        def check_capture():
            ops['snapshot'](state['capture'])
        connect = connection.factory(tls, state['cert_hash'], owned, clock, check_capture)
        stage = 'sessions'
        result = sessions.run(selection, overall, clock, connect)
        stage = 'shutdown'
        post = process_shutdown.graceful(state, result, selection, nonce, capacity, overall, clock, ops)
        evidence.update(success=True, sessions=result, post=post,
                        server_output_hex=ops['snapshot'](state['capture']).hex())
        evidence['setup'] = {name: value for name, value in state.items() if name.startswith('certificate_') or name in ('cert_hash', 'child_argv', 'child_environment', 'pid', 'start', 'listener', 'signalled', 'reaped', 'exit_status', 'collector_joined', 'forced', 'key_removed', 'transfer_removed')}
        return evidence
    except BaseException as exc:
        evidence.update(success=False, stage=stage, error=repr(exc),
                        traceback=''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))[-16384:])
        try:
            failures = cleanup(state, clock)
            evidence['cleanup_errors'] = failures
            if failures:
                exc.add_note('cleanup errors: ' + repr(failures))
        except BaseException as cleanup_error:
            evidence['cleanup_errors'] = [repr(cleanup_error)]
            exc.add_note('cleanup failed: ' + repr(cleanup_error))
        if state.get('capture') is not None:
            try:
                raw = ops['snapshot_raw'](state['capture'])
                evidence['server_output_hex'] = raw['bytes'].hex()
                evidence['capture_status'] = {name: raw[name] for name in ('overflow', 'error', 'finished')}
            except BaseException as capture_error:
                evidence['capture_error'] = repr(capture_error)
                exc.add_note('capture failed: ' + repr(capture_error))
        evidence['forced'] = state.get('forced', False)
        evidence['setup'] = {name: value for name, value in state.items() if name.startswith('certificate_') or name in ('cert_hash', 'child_argv', 'child_environment', 'pid', 'start', 'listener', 'signalled', 'reaped', 'exit_status', 'collector_joined', 'forced', 'key_removed', 'transfer_removed')}
        raise
