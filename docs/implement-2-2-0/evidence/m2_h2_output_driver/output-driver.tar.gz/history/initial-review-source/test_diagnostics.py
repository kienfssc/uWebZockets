"""Check the output fixture's observable producer and file diagnostics."""
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
import contracts
import diagnostics


def rejected(function, item):
    try:
        function(item)
    except ValueError:
        return
    raise RuntimeError('bad diagnostic accepted')


def main():
    held = {'tag': 'producer_reuse', 'armed': True, 'done': False, 'offset': 0,
            'sha256': contracts.EMPTY_HASH, 'invocations': 1, 'attempts': 1,
            'writes': 0, 'blocked': 1, 'pending': 1, 'terminal_attempts': 0,
            'terminals': 0, 'checks': 1, 'after_reuse': 0, 'errors': 0,
            'binding_index': 0, 'binding_generation': 1}
    diagnostics.producer(held, 'producer_reuse', 0, held=True)
    for field, value in (('blocked', 0), ('offset', 1), ('binding_generation', True),
                         ('sha256', 'f' * 64), ('errors', 1)):
        rejected(lambda item: diagnostics.producer(item, 'producer_reuse', 0, held=True),
                 {**held, field: value})
    complete = {**held, 'done': True, 'offset': contracts.TOTAL,
                'sha256': contracts.PRODUCER_HASH, 'invocations': 2,
                'attempts': 2050, 'writes': 2049, 'terminal_attempts': 1,
                'terminals': 1, 'checks': 2, 'after_reuse': 1}
    diagnostics.producer(complete, 'producer_reuse', contracts.TOTAL, after_reuse=True)
    diagnostics.progress(held, complete)
    rejected(lambda item: diagnostics.progress(held, item), {**complete, 'blocked': 0})
    rejected(lambda item: diagnostics.producer(item, 'producer_reuse', contracts.TOTAL),
             {**complete, 'writes': 2048})
    file = {'tag': 'stream_file', 'reads': 4, 'requested': 24593, 'returned': 24593,
            'read_errors': 0, 'close_calls': 1, 'closed_files': 1, 'invalid_spans': 0,
            'min_offset': 37, 'max_end': 24630, 'arms': 1, 'arm_errors': 0,
            'transferred': True, 'caller_owned': False}
    diagnostics.file_complete(file)
    for field, value in (('close_calls', 2), ('invalid_spans', 1), ('min_offset', 36),
                         ('caller_owned', True), ('returned', True)):
        rejected(diagnostics.file_complete, {**file, field: value})
    print('diagnostic checks: PASS')


if __name__ == '__main__':
    main()
