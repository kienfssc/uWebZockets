"""Zero-credit producer must hit both blocking checkpoints before completion."""
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
import contracts
import cases
from test_cases import body


def main():
    state = {'phase': 0, 'echo': False}
    def start_echo(stream):
        if stream != 3:
            raise ValueError('echo ID')
        return stream
    def start_upload(tag, stream, **options):
        if tag != 'output_pressure_window' or stream != 5 or options != {'mode': 'producer'}:
            raise ValueError('primary identity')
        return stream
    def send(stream, data, end):
        if (stream, data, end) == (3, b's', True):
            state['echo'] = True
        elif (stream, data, end) != (5, contracts.P32, True):
            raise ValueError('unexpected DATA')
    def output(tag):
        if tag != 'output_pressure_window':
            raise ValueError('output tag')
        phase = state['phase']
        offset = (0, 8192, contracts.TOTAL)[phase]
        return {'tag': tag, 'armed': True, 'done': phase == 2, 'offset': offset,
                'sha256': contracts.PRODUCER_HASH if phase == 2 else contracts.digest(contracts.TOTAL, 0, offset),
                'invocations': phase + 1, 'attempts': (1, 3, 2051)[phase],
                'writes': (0, 1, 2049)[phase], 'blocked': (1, 2, 2)[phase],
                'pending': (1, 2, 2)[phase], 'terminal_attempts': int(phase == 2),
                'terminals': int(phase == 2), 'checks': phase + 1, 'after_reuse': 0,
                'errors': 0, 'binding_index': 0, 'binding_generation': 1}
    def grant(stream, amount):
        if stream != 5 or not state['echo'] or amount != (8192 if state['phase'] == 0 else contracts.TOTAL - 8192):
            raise ValueError('grant order or size')
        state['phase'] += 1
    def checkpoint(stream, count):
        if stream != 5 or (count, state['phase']) not in ((0, 0), (8192, 1)):
            raise ValueError('checkpoint order')
        return {'bytes': count, 'sha256': contracts.digest(contracts.TOTAL, 0, count), 'end': False, 'reset': False}
    def finish(stream):
        if stream == 3:
            if not state['echo']:
                raise ValueError('echo unfinished')
            return {'body': b's'}
        if stream != 5 or state['phase'] != 2:
            raise ValueError('early primary completion')
        return {'bytes': contracts.TOTAL, 'sha256': contracts.PRODUCER_HASH, 'end': True, 'reset': False}
    api = {'start_echo': start_echo, 'start_upload': start_upload, 'send': send,
           'body_status': body, 'output_status': output, 'grant': grant,
           'checkpoint': checkpoint, 'finish': finish, 'health': lambda: None}
    cases.output_pressure_window(api)
    if state['phase'] != 2:
        raise RuntimeError('missing prefix grant')
    print('window schedule checks: PASS')


if __name__ == '__main__':
    main()
