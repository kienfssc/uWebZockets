"""Post-deinit markers must represent the same fixture observations."""
import json
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
import contracts
import post
from test_records import fixture_record


def main():
    rows = [fixture_record(item) for item in contracts.expected_records([])]
    totals = {'middleware': 0, 'attempts': 0, 'begin': 0, 'end': 0, 'cancel': 0,
              'failure': 0, 'end_errors': 0, 'chunk_errors': 0, 'invalid_progress': 0,
              'accepted': 0, 'active': 0, 'errors': 0, 'buffered_middleware': 33,
              'slot0_active': False, 'slot1_active': False}
    def producer(tag):
        return {'tag': tag, 'armed': False, 'done': False, 'offset': 0, 'sha256': contracts.EMPTY_HASH,
                'invocations': 0, 'attempts': 0, 'writes': 0, 'blocked': 0, 'pending': 0,
                'terminal_attempts': 0, 'terminals': 0, 'checks': 0, 'after_reuse': 0,
                'errors': 0, 'binding_index': 0, 'binding_generation': 0}
    outputs = [producer(tag) for tag in ('producer_reuse', 'output_pressure_window', 'output_pressure_ready')]
    outputs.append({'tag': 'stream_file', 'reads': 0, 'requested': 0, 'returned': 0,
                    'read_errors': 0, 'close_calls': 0, 'closed_files': 0, 'invalid_spans': 0,
                    'min_offset': 24630, 'max_end': 0, 'arms': 0, 'arm_errors': 0,
                    'transferred': False, 'caller_owned': True})
    lines = ['info: H2_CAPACITY expected', 'info: H2_READY nonce',
             'info: H2_BINDING nonce tag=producer_reuse_next index=0 generation=0']
    lines.extend('info: H2_OUTPUT nonce ' + json.dumps(item) for item in outputs)
    lines.extend('info: H2_RECORD nonce ' + json.dumps(item) for item in rows)
    lines.append('info: H2_DEINIT nonce ' + json.dumps(totals))
    evidence = '\n'.join(lines).encode()
    result = post.validate(evidence, 'nonce', [], 'H2_CAPACITY expected', rows, totals, None, {})
    if result['records'] != rows:
        raise RuntimeError('records differ')
    for altered in (evidence + b'\n' + lines[-1].encode(), evidence.replace(b'"caller_owned": true', b'"caller_owned": false')):
        try:
            post.validate(altered, 'nonce', [], 'H2_CAPACITY expected', rows, totals, None, {})
        except ValueError:
            continue
        raise RuntimeError('altered post evidence accepted')
    selected = ['output_pressure_window']
    rows = [fixture_record(item) for item in contracts.expected_records(selected)]
    totals = {**totals, 'middleware': 1, 'attempts': 1, 'begin': 1, 'end': 1,
              'accepted': 32, 'buffered_middleware': 40}
    outputs[1] = {**outputs[1], 'armed': True, 'done': True, 'offset': contracts.TOTAL,
                  'sha256': contracts.PRODUCER_HASH, 'invocations': 1, 'attempts': 2049,
                  'writes': 2049, 'terminal_attempts': 1, 'terminals': 1, 'checks': 1,
                  'binding_generation': 1}
    lines = lines[:3] + ['info: H2_OUTPUT nonce ' + json.dumps(item) for item in outputs]
    lines += ['info: H2_RECORD nonce ' + json.dumps(item) for item in rows]
    lines.append('info: H2_DEINIT nonce ' + json.dumps(totals))
    evidence = '\n'.join(lines).encode()
    before = {'output_pressure_window': outputs[1]}
    post.validate(evidence, 'nonce', selected, 'H2_CAPACITY expected', rows, totals, None, before)
    bad = {'output_pressure_window': {**outputs[1], 'after_reuse': 1}}
    try:
        post.validate(evidence, 'nonce', selected, 'H2_CAPACITY expected', rows, totals, None, bad)
    except ValueError:
        pass
    else:
        raise RuntimeError('changed pre-deinit output accepted')
    bad = {'output_pressure_window': {**outputs[1], 'checks': True}}
    try:
        post.validate(evidence, 'nonce', selected, 'H2_CAPACITY expected', rows, totals, None, bad)
    except ValueError:
        pass
    else:
        raise RuntimeError('mistyped pre-deinit output accepted')
    print('post-deinit evidence checks: PASS')


if __name__ == '__main__':
    main()
