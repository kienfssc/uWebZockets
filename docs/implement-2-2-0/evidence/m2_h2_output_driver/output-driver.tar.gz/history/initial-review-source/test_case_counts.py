"""Case completion checks exact response and upload counts."""
import sys
from unittest import mock
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import orchestration
import raw_observer


def main():
    state = {'records': {}, 'raw': raw_observer.new_state(),
             'stage': {'auxiliary': 8, 'primary_complete': True, 'active': {}, 'acks': 2},
             'request': {'sent': 64, 'client_settings': 2}, 'response': {'pending': None, 'streams': {}}}
    item = ('producer', 3, 0, lambda api: 'case-result')
    with mock.patch.dict(orchestration.CASE_INFO, {'producer_reuse': item}):
        if orchestration.run_case('producer_reuse', state, {}) != 'case-result':
            raise RuntimeError('case result lost')
        state['stage']['auxiliary'] = 7
        try:
            orchestration.run_case('producer_reuse', state, {})
        except ValueError:
            pass
        else:
            raise RuntimeError('missing auxiliary response accepted')
        state['stage']['auxiliary'] = 8
        state['request']['sent'] = 63
        try:
            orchestration.run_case('producer_reuse', state, {})
        except ValueError:
            pass
        else:
            raise RuntimeError('wrong upload count accepted')
    print('case accounting checks: PASS')


if __name__ == '__main__':
    main()
