"""Failed runs must retain cleanup errors and mark forced termination."""
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import process_cleanup


def main():
    calls = []
    state = {'directory_created': True, 'child': {'pid': 51}, 'start': 'start', 'capture': 'capture', 'key': 'key', 'transfer': 'file'}
    def action(name, result=None):
        def invoke(*args):
            calls.append((name, args))
            return result
        return invoke
    ops = {'poll': action('poll', None), 'start': action('start', 'start'),
           'kill': action('kill'), 'wait': action('wait', -9), 'join': action('join'), 'close_pipe': action('close_pipe'),
           'unlink': action('unlink'), 'absent': action('absent', True)}
    errors = process_cleanup.emergency(state, lambda: 100, ops)
    if errors or not state.get('forced') or not state.get('reaped'):
        raise RuntimeError('cleanup evidence differs')
    if [item[0] for item in calls] != ['poll', 'start', 'kill', 'wait', 'join', 'unlink', 'absent', 'unlink', 'absent']:
        raise RuntimeError('cleanup order differs')
    state = {'directory_created': True, 'child': {'pid': 51}, 'start': 'start', 'key': 'key', 'transfer': 'file'}
    ops['start'] = action('start', 'changed')
    errors = process_cleanup.emergency(state, lambda: 100, ops)
    if ('close_pipe', ({'pid': 51},)) not in calls:
        raise RuntimeError('uncollected pipe not closed')
    if not errors or state.get('forced'):
        raise RuntimeError('changed child identity accepted')
    calls.clear()
    state = {'directory_created': True, 'child': {'pid': 52}, 'key': 'key', 'transfer': 'file'}
    ops['start'] = action('start', 'unused')
    errors = process_cleanup.emergency(state, lambda: 100, ops)
    if errors or not state.get('forced') or ('kill', ({'pid': 52},)) not in calls:
        raise RuntimeError('unidentified owned child was not reaped')
    calls.clear()
    errors = process_cleanup.emergency({'directory_created': False, 'key': 'key', 'transfer': 'file'}, lambda: 100, ops)
    if errors or calls:
        raise RuntimeError('unowned directory cleanup attempted')
    print('failure cleanup checks: PASS')


if __name__ == '__main__':
    main()
