"""Focused checks for the fixture record boundary."""
import copy
import sys

sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
import contracts
import records


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def rejected(function, value):
    try:
        function(value)
    except ValueError:
        return
    raise RuntimeError('invalid fixture record accepted')


def fixture_record(record):
    result = dict(record)
    for old, new in (('bytes', 'accepted'), ('begins', 'begin'), ('ends', 'end'),
                     ('cancels', 'cancel'), ('failures', 'failure')):
        result[new] = result.pop(old)
    if result['chunks'] is None:
        result['chunks'] = 1
        result['max_span'] = 32
    if result['reason'] is None:
        result['reason'] = 'none'
    return result


def main():
    literal = {'tag': 'early_final_order', 'middleware': 1, 'attempts': 0,
               'begin': 0, 'end': 0, 'cancel': 0, 'failure': 0,
               'end_errors': 0, 'chunk_errors': 0, 'invalid_progress': 0,
               'accepted': 0, 'sha256': contracts.EMPTY_HASH, 'chunks': 0,
               'max_span': 0, 'active': False, 'paused': False, 'reason': 'none',
               'metadata_middleware': 1, 'metadata_begin': 0, 'metadata_end': 0,
               'stale_resume': 0, 'stale_cancel': 0, 'errors': 0}
    normalized = records.normalize(literal)
    require(normalized == contracts.record('early_final_order', {'early_final_order'}),
            'actual fixture field normalization')
    selected = ['early_final_order', 'stream_file']
    raw = [fixture_record(item) for item in contracts.expected_records(selected)]
    records.validate(selected, raw)
    for field, value in (('accepted', True), ('sha256', '0' * 64),
                         ('reason', 'cancelled'), ('middleware', 2)):
        altered = copy.deepcopy(raw)
        altered[contracts.TAGS.index('stream_file')][field] = value
        rejected(lambda items: records.validate(selected, items), altered)
    altered = copy.deepcopy(raw)
    altered[0]['extra'] = 0
    rejected(lambda items: records.validate(selected, items), altered)
    rejected(records.normalize, {**literal, 'active': 0})
    rejected(records.parse_json, b'{\"tag\":1,\"tag\":2}')
    rejected(records.parse_json, b'{\"value\":NaN}')
    totals = {'middleware': 3, 'attempts': 2, 'begin': 2, 'end': 2,
              'cancel': 0, 'failure': 0, 'end_errors': 0, 'chunk_errors': 0,
              'invalid_progress': 0, 'accepted': 64, 'active': 0, 'errors': 0,
              'buffered_middleware': 44, 'slot0_active': False, 'slot1_active': False}
    records.validate_totals(selected, totals)
    for field, value in (('buffered_middleware', 45), ('accepted', True),
                         ('slot0_active', True)):
        altered = dict(totals)
        altered[field] = value
        rejected(lambda item: records.validate_totals(selected, item), altered)
    print('record boundary checks: PASS')


if __name__ == '__main__':
    main()
