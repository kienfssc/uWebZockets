"""Check ready and file schedules through deterministic caller-owned probes."""
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
import contracts
import cases
from test_cases import body


def main():
    state = {'case': 'output_pressure_ready', 'echo': False, 'granted': False, 'paired': False, 'duplicate_length': False}
    def start_echo(stream):
        if stream != 3:
            raise ValueError('echo stream')
        return stream
    def start(tag, stream, **options):
        mode = 'producer' if state['case'] == 'output_pressure_ready' else 'file'
        if tag != state['case'] or stream != 5 or options != {'mode': mode}:
            raise ValueError('primary stream')
        return stream
    def send(stream, data, end):
        if (stream, data, end) == (3, b's', True):
            state['echo'] = True
        elif (stream, data, end) != (5, contracts.P32, True):
            raise ValueError('bad DATA')
    def output(tag):
        if tag != state['case']:
            raise ValueError('bad output tag')
        if tag == 'stream_file':
            complete = state['granted']
            return {'tag': tag, 'reads': 4, 'requested': 24593, 'returned': 24593,
                    'read_errors': 0, 'close_calls': int(complete), 'closed_files': int(complete),
                    'invalid_spans': 0, 'min_offset': 37, 'max_end': 24630,
                    'arms': 1, 'arm_errors': 0, 'transferred': True, 'caller_owned': False}
        return {'tag': tag, 'armed': True, 'done': True, 'offset': contracts.TOTAL,
                'sha256': contracts.PRODUCER_HASH, 'invocations': 1, 'attempts': 2049,
                'writes': 2049, 'blocked': 0, 'pending': 0, 'terminal_attempts': 1,
                'terminals': 1, 'checks': 1, 'after_reuse': 0, 'errors': 0,
                'binding_index': 0, 'binding_generation': 1}
    def grant(stream, amount):
        if stream != 5 or amount != contracts.FILE_LENGTH or not state['echo']:
            raise ValueError('bad file grant')
        state['granted'] = True
    def checkpoint(stream, count):
        if stream != 5 or count != 0 or state['granted']:
            raise ValueError('file held checkpoint')
        return {'bytes': 0, 'sha256': contracts.EMPTY_HASH, 'end': False, 'reset': False}
    def finish(stream):
        if stream == 3 and state['echo']:
            return {'body': b's'}
        if stream == 5 and state['granted']:
            return {'bytes': contracts.FILE_LENGTH, 'sha256': contracts.RANGE_HASH, 'end': True, 'reset': False,
                    'headers': [('content-length', '24593')] * (2 if state['duplicate_length'] else 1)}
        raise ValueError('bad completion')
    def finish_pair(first, second):
        if (first, second) != (3, 5) or not state['echo']:
            raise ValueError('not simultaneously ready')
        state['paired'] = True
        return ({'body': b's'}, {'bytes': contracts.TOTAL, 'sha256': contracts.PRODUCER_HASH, 'end': True, 'reset': False})
    api = {'start_echo': start_echo, 'start_upload': start, 'send': send, 'body_status': body,
           'output_status': output, 'grant': grant, 'finish': finish, 'finish_pair': finish_pair, 'checkpoint': checkpoint,
           'health': lambda: None}
    cases.output_pressure_ready(api)
    if not state['paired']:
        raise RuntimeError('missing concurrent completion')
    state.update(case='stream_file', echo=False, granted=False)
    cases.stream_file(api)
    if not state['granted']:
        raise RuntimeError('file not released')
    state.update(echo=False, granted=False, duplicate_length=True)
    try:
        cases.stream_file(api)
    except ValueError:
        pass
    else:
        raise RuntimeError('duplicate file content-length accepted')
    print('ready and file schedule checks: PASS')


if __name__ == '__main__':
    main()
