"""Owned shutdown must reap before checking post-deinit and removing the key."""
from unittest import mock
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import process_shutdown
import post


def main():
    calls = []
    state = {'child': {'pid': 51}, 'start': 'start-id', 'listener': 'inode',
             'capture': 'capture', 'key': '/tmp/run/key', 'transfer': '/tmp/run/file'}
    def owned(child, start, listener):
        calls.append(('owned', child['pid'], start, listener))
    def signal(child):
        calls.append(('signal', child['pid']))
    def wait(child, deadline):
        calls.append(('wait', child['pid'], deadline))
        return 0
    def join(capture, deadline):
        calls.append(('join', capture, deadline))
    def snapshot(capture):
        calls.append(('snapshot', capture))
        return b'log'
    def unlink(path):
        calls.append(('unlink', path))
    def absent(path):
        calls.append(('absent', path))
        return True
    def validate(*args):
        calls.append(('validate', args[0]))
        return {'validated': True}
    ops = {'owned': owned, 'signal': signal, 'wait': wait, 'join': join,
           'snapshot': snapshot, 'unlink': unlink, 'absent': absent}
    result = {'final': {'records': [], 'totals': {}}, 'binding': None, 'outputs': {}}
    with mock.patch.object(post, 'validate', validate):
        observed = process_shutdown.graceful(state, result, [], 'nonce', 'capacity', 900, lambda: 100, ops)
    if observed != {'validated': True} or [item[0] for item in calls] != ['owned', 'signal', 'wait', 'join', 'snapshot', 'validate', 'unlink', 'absent', 'unlink', 'absent']:
        raise RuntimeError('shutdown order differs')
    if calls[2][-1] != 115 or calls[3][-1] != 115:
        raise RuntimeError('graceful deadline differs')
    print('process shutdown checks: PASS')


if __name__ == '__main__':
    main()
