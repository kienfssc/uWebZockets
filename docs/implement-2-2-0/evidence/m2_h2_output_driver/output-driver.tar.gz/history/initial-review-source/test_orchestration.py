"""Use public codecs and callback I/O to check connection setup order."""
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import h2.config
import h2.connection
import h2.events
import orchestration
from test_protocol import source_settings


def main():
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server.initiate_connection()
    server.data_to_send()
    incoming = [source_settings()]
    paths = []
    def write(data):
        if len(data) > 8192:
            raise ValueError('send bound')
        for event in server.receive_data(data):
            if isinstance(event, h2.events.RequestReceived):
                path = dict(event.headers)[':path']
                paths.append(path)
                if path != '/health':
                    raise ValueError('unexpected request before setup completed')
                server.send_headers(event.stream_id, [(':status', '200'), ('x-middleware', 'retained')])
                server.send_data(event.stream_id, b'ok', end_stream=True)
        data = server.data_to_send()
        if data:
            incoming.append(data)
    def read():
        if not incoming:
            raise ValueError('unexpected receive')
        return incoming.pop(0)
    state, api = orchestration.setup(client, 'output_pressure_window', write, read)
    if paths != ['/health'] or state['response']['initial'] != 0 or state['response']['pending'] is not None:
        raise RuntimeError('setup ordering differs')
    if state['response']['connection'] != 33554432 or state['stage']['acks'] != 2:
        raise RuntimeError('setup credit differs')
    if not callable(api['start_upload']):
        raise RuntimeError('missing case API')
    print('orchestration setup checks: PASS')


if __name__ == '__main__':
    main()
