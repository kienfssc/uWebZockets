"""The refusal response must end before its NO_ERROR reset."""
import hashlib
import json
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
import contracts
import cases
from test_cases import body


def main():
    state = {'phase': 0, 'holder_done': False}
    active = body('early_final_recovery')
    active.update(accepted=0, sha256=contracts.EMPTY_HASH, chunks=0, max_span=0,
                  end=0, metadata_end=0, active=True)
    refusal = body('early_final_order')
    refusal.update(accepted=0, sha256=contracts.EMPTY_HASH, chunks=0, max_span=0,
                   attempts=0, begin=0, end=0, metadata_begin=0, metadata_end=0)
    def start(tag, stream, **options):
        if (tag, stream, options) not in (('early_final_recovery', 3, {'mode': 'small'}),
                                         ('early_final_order', 7, {'mode': 'early'})):
            raise ValueError('upload identity')
        return stream
    def status(tag):
        return active if tag == 'early_final_recovery' else refusal
    def headers(stream):
        if stream != 7 or state['phase'] != 0:
            raise ValueError('early headers ordering')
        return {'status': 403, 'informationals': 0, 'bytes': 0, 'end': False, 'reset': False}
    def grant(stream, amount):
        if stream != 7 or (state['phase'], amount) not in ((0, 8), (1, 9)):
            raise ValueError('bad grant')
        state['phase'] += 1
    def checkpoint(stream, count):
        if stream != 7 or count != 8 or state['phase'] != 1:
            raise ValueError('prefix order')
        return {'bytes': 8, 'sha256': hashlib.sha256(b'early-fi').hexdigest(), 'end': False, 'reset': False}
    def send(stream, data, end):
        if stream != 3 or data != contracts.P32 or end is not True or state['phase'] != 2:
            raise ValueError('holder finished too early')
        state['holder_done'] = True
    def finish(stream):
        if stream == 7 and state['phase'] == 2:
            return {'bytes': 17, 'sha256': contracts.EARLY_HASH, 'end': True, 'reset': True}
        if stream == 3 and state['holder_done']:
            return {'body': json.dumps(body('early_final_recovery')).encode()}
        raise ValueError('incorrect completion')
    api = {'start_upload': start, 'body_status': status, 'headers': headers, 'grant': grant,
           'checkpoint': checkpoint, 'send': send, 'finish': finish, 'health': lambda: None}
    cases.early_final_order(api)
    if not state['holder_done']:
        raise RuntimeError('holder not completed')
    print('early schedule checks: PASS')


if __name__ == '__main__':
    main()
