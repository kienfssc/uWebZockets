"""Listener identity must be the fixture's exact live process and inode."""
import identity


def main():
    stat = '7 (name with ) parentheses) S ' + ' '.join(str(i) for i in range(1, 25))
    table = ('sl local_address rem_address st tx rx tr tm retr uid timeout inode\n'
             '0: 0100007F:6F1B 00000000:0000 0A 0 0 0 0 0 101\n'
             '1: 0100007F:6F1B 00000000:0000 0A 0 0 0 0 0 202\n')
    if identity.start_id(stat) != '19':
        raise RuntimeError('process start parsing differs')
    if identity.match_listeners(table, ['socket:[101]', 'socket:[999]']) != ['101']:
        raise RuntimeError('listener matching differs')
    identity.require_owned(None, '19', '19', ['101'], '101')
    for args in ((0, '19', '19', ['101'], '101'), (None, '20', '19', ['101'], '101'),
                 (None, '19', '19', ['101', '202'], '101')):
        try:
            identity.require_owned(*args)
        except ValueError:
            continue
        raise RuntimeError('foreign process or listener accepted')
    print('process identity checks: PASS')


if __name__ == '__main__':
    main()
