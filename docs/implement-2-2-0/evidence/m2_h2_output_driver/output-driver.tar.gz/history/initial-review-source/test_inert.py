"""Source imports must not execute the future runner or depend on argv."""
import ast
import importlib.util
import pathlib
import sys
from unittest import mock

sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')


def main():
    root = pathlib.Path(__file__).resolve().parent
    files = sorted(root.glob('*.py'))
    for path in files:
        tree = ast.parse(path.read_text(), filename=str(path))
        if any(isinstance(item, (ast.ClassDef, ast.Assert)) for item in ast.walk(tree)):
            raise RuntimeError('forbidden class or assert: ' + path.name)
    for arguments in ([], ['foreign', '--unknown']):
        sys.argv = arguments
        with mock.patch('socket.socket', side_effect=RuntimeError('socket construction')):
            with mock.patch('ssl.SSLContext', side_effect=RuntimeError('TLS construction')):
                with mock.patch('subprocess.Popen', side_effect=RuntimeError('process construction')):
                    for path in files:
                        if path.name == pathlib.Path(__file__).name:
                            continue
                        spec = importlib.util.spec_from_file_location('inert_' + path.stem, path)
                        if spec is None or spec.loader is None:
                            raise RuntimeError('missing loader')
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
    print('AST and inert import checks: PASS')


if __name__ == '__main__':
    main()
