"""Verify case adapter actions use the paired protocol state."""
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import h2.config
import h2.connection
import h2.events
import protocol
import case_adapter
from test_protocol import source_settings


def require(value, message):
    if not value:
        raise RuntimeError(message)


def main():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    server.initiate_connection()
    server.data_to_send()
    sent, incoming = [], []
    state = protocol.new(client, 'producer', 3, sent.append)
    protocol.initiate(state)
    server.receive_data(b''.join(sent)); sent.clear()
    protocol.accept(state, source_settings() + server.data_to_send())
    server.receive_data(b''.join(sent)); sent.clear()
    api = case_adapter.api(state, lambda: incoming.pop(0))
    health = api['start_get']('/health', 2)
    server.receive_data(b''.join(sent)); sent.clear()
    server.send_headers(health, [(':status', '200'), ('x-middleware', 'retained')])
    server.send_data(health, b'ok', end_stream=True)
    incoming.append(server.data_to_send())
    require(api['finish'](health)['body'] == b'ok', 'health mismatch')
    require(state['completions'][0]['body_hex'] == b'ok'.hex() and state['completions'][0]['stream'] == 1,
            'completed response evidence missing')
    protocol.settings(state, 0)
    server.receive_data(b''.join(sent)); sent.clear()
    protocol.accept(state, server.data_to_send())
    primary = api['start_upload']('producer_reuse', 3, mode='producer')
    api['send'](primary, bytes(range(1, 11)) + b'final-upload-sentinel!', True)
    events = server.receive_data(b''.join(sent)); sent.clear()
    requests = [event for event in events if isinstance(event, h2.events.RequestReceived)]
    require(len(requests) == 1, 'upload headers missing')
    headers = dict(requests[0].headers)
    require(headers.get(':method') == 'POST' and headers.get(':path') == '/limit/producer_reuse?case=producer_reuse'
            and headers.get('x-case') == 'producer_reuse' and headers.get('content-length') == '32'
            and ':protocol' not in headers, 'upload metadata differs')
    server.send_headers(primary, [(':status', '200'), ('x-middleware', 'retained')])
    incoming.append(server.data_to_send())
    held = api['checkpoint'](primary, 0)
    require(held['bytes'] == 0 and not held['end'], 'zero-credit checkpoint')
    require(state['request']['sent'] == 32, 'upload accounting')
    print('case adapter checks: PASS')


if __name__ == '__main__':
    main()
