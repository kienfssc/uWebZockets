"""The reuse schedule must observe both bindings before releasing A."""
import sys
import json
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
import contracts
import cases


def body(tag):
    item = contracts.record(tag, {tag})
    item['chunks'], item['max_span'] = 1, 32
    item['reason'] = 'none'
    for old, new in (('bytes', 'accepted'), ('begins', 'begin'), ('ends', 'end'),
                     ('cancels', 'cancel'), ('failures', 'failure')):
        item[new] = item.pop(old)
    return item


def main():
    calls = []
    held = {'tag': 'producer_reuse', 'armed': True, 'done': False, 'offset': 0,
            'sha256': contracts.EMPTY_HASH, 'invocations': 1, 'attempts': 1,
            'writes': 0, 'blocked': 1, 'pending': 1, 'terminal_attempts': 0,
            'terminals': 0, 'checks': 1, 'after_reuse': 0, 'errors': 0,
            'binding_index': 0, 'binding_generation': 1}
    done = {**held, 'done': True, 'offset': contracts.TOTAL, 'sha256': contracts.PRODUCER_HASH,
            'invocations': 2, 'attempts': 2050, 'writes': 2049, 'terminal_attempts': 1,
            'terminals': 1, 'checks': 2, 'after_reuse': 1}
    state = {'released': False, 'b_observed': False}
    def start(tag, stream, **kwargs):
        calls.append(('start', tag, stream))
        if tag == 'producer_reuse_next' and state['released']:
            raise ValueError('B started after A was released')
        return stream
    def send(stream, data, end):
        if data != contracts.P32 or end is not True:
            raise ValueError('wrong upload')
        calls.append(('send', stream))
    def status(tag):
        return body(tag)
    def output(tag):
        if tag == 'producer_reuse_next':
            state['b_observed'] = True
            return {'tag': tag, 'binding_index': 0, 'binding_generation': 2}
        return done if state['released'] else held
    def checkpoint(stream, count):
        if stream != 3 or count != 0 or state['released']:
            raise ValueError('invalid held checkpoint')
        return {'bytes': 0, 'sha256': contracts.EMPTY_HASH, 'end': False, 'reset': False}
    def grant(stream, amount):
        if stream != 3 or amount != contracts.TOTAL or not state['b_observed']:
            raise ValueError('invalid release')
        state['released'] = True
    def finish(stream):
        return {'body': json.dumps(body('producer_reuse_next')).encode()} if stream == 5 else {
            'bytes': contracts.TOTAL, 'sha256': contracts.PRODUCER_HASH, 'end': True, 'reset': False}
    api = {'start_upload': start, 'send': send, 'body_status': status, 'output_status': output,
           'grant': grant, 'finish': finish, 'checkpoint': checkpoint, 'health': lambda: calls.append(('health',))}
    result = cases.producer_reuse(api)
    if result != (0, 2):
        raise RuntimeError('online binding evidence missing')
    if not state['released'] or not state['b_observed'] or calls[-1] != ('health',):
        raise RuntimeError('reuse observations missing')
    state.update(released=False, b_observed=False)
    original = api['output_status']
    def wrong_binding(tag):
        item = original(tag)
        return {**item, 'binding_generation': 3} if tag == 'producer_reuse_next' else item
    api['output_status'] = wrong_binding
    try:
        cases.producer_reuse(api)
    except ValueError:
        if state['released']:
            raise RuntimeError('released A despite incorrect binding')
    else:
        raise RuntimeError('incorrect B generation accepted')
    print('case scheduling checks: PASS')


if __name__ == '__main__':
    main()
