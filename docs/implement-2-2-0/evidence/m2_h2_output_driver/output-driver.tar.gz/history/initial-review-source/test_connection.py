"""Connection setup uses only supplied TLS and socket doubles."""
import hashlib
import sys
from types import SimpleNamespace
from unittest import mock
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import connection


def main():
    calls = []
    peer = b'certificate'
    def close():
        calls.append('close')
    raw = SimpleNamespace(settimeout=lambda value: calls.append(('timeout', value)), close=close)
    tls = SimpleNamespace(version=lambda: 'TLSv1.3', selected_alpn_protocol=lambda: 'h2',
                          getpeercert=lambda binary_form: peer, close=close,
                          settimeout=lambda value: calls.append(('tls_timeout', value)),
                          sendall=lambda data: calls.append(('send', data)), recv=lambda n: b'data')
    context = SimpleNamespace(wrap_socket=lambda sock, **kw: tls)
    def connect(address, timeout):
        calls.append(('connect', address, timeout))
        return raw
    def owned():
        calls.append('owned')
    factory = connection.factory(context, hashlib.sha256(peer).hexdigest(), owned, lambda: 10, lambda: None)
    with mock.patch.object(connection.socket, 'create_connection', connect):
        result = factory('producer_reuse', 20)
    if calls[:4] != ['owned', ('connect', ('127.0.0.1', 28443), 10), ('timeout', 10), 'owned']:
        raise RuntimeError('connection identity order differs')
    result['close']()
    if calls[-1] != 'close':
        raise RuntimeError('TLS close missing')
    tls.version = lambda: 'TLSv1.2'
    with mock.patch.object(connection.socket, 'create_connection', connect):
        try:
            factory('producer_reuse', 20)
        except ValueError:
            pass
        else:
            raise RuntimeError('wrong TLS version accepted')
    if calls[-1] != 'close':
        raise RuntimeError('failed TLS connection not closed')
    print('connection setup checks: PASS')


if __name__ == '__main__':
    main()
