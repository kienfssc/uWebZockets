"""Deadline and byte bounds use caller-visible socket doubles."""
from types import SimpleNamespace
import owned_io


def main():
    calls = []
    def timeout(value):
        calls.append(('timeout', value))
    def send(data):
        calls.append(('send', data))
    def recv(size):
        calls.append(('recv', size))
        return b'x'
    sock = SimpleNamespace(settimeout=timeout, sendall=send, recv=recv)
    clock = lambda: 10
    owned_io.write(sock, b'abc', 12, clock)
    if owned_io.read(sock, 12, clock) != b'x':
        raise RuntimeError('receive differs')
    if calls != [('timeout', 2), ('send', b'abc'), ('timeout', 2), ('recv', 8192)]:
        raise RuntimeError('I/O bounds differ')
    for action in (lambda: owned_io.write(sock, b'a' * 8193, 12, clock),
                   lambda: owned_io.read(sock, 10, clock)):
        try:
            action()
        except ValueError:
            continue
        raise RuntimeError('bad I/O accepted')
    print('owned I/O checks: PASS')


if __name__ == '__main__':
    main()
