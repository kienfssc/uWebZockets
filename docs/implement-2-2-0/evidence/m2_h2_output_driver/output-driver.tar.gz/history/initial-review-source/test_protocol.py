"""Exercise paired public H2 actions against source-shaped server frames."""
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import h2.config
import h2.connection
import h2.settings
import protocol
import output_stage


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def source_settings():
    payload = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                       ((1, 4096), (3, 100), (4, 65535), (5, 16384), (6, 65536)))
    return len(payload).to_bytes(3, 'big') + b'\x04\x00\x00\x00\x00\x00' + payload


def main():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    server.initiate_connection()
    server.data_to_send()
    sent = []
    state = protocol.new(client, 'producer', 3, sent.append)
    protocol.initiate(state)
    server.receive_data(b''.join(sent))
    sent.clear()
    protocol.accept(state, source_settings() + server.data_to_send())
    require(state['response']['initial_acked'], 'initial ACK was not observed')
    server.receive_data(b''.join(sent))
    sent.clear()
    stream = protocol.start(state, 'GET', '/health', [], True, 2, 200)
    require(stream == 1, 'health ID differs')
    server.receive_data(b''.join(sent))
    sent.clear()
    server.send_headers(1, [(':status', '200'), ('x-middleware', 'retained')])
    server.send_data(1, b'ok', end_stream=True)
    protocol.accept(state, server.data_to_send())
    result = protocol.complete(state, 1)
    require(result['body'] == b'ok' and result['bytes'] == 2, 'health response differs')
    protocol.settings(state, 0)
    server.receive_data(b''.join(sent))
    sent.clear()
    protocol.accept(state, server.data_to_send())
    require(state['response']['pending'] is None, 'custom ACK was not observed')
    stream = protocol.start(state, 'POST', '/limit/example?case=example',
                            [('content-length', '32'), ('x-case', 'example')], False,
                            3, 200, mode='hash_only', digest='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
    require(stream == 3, 'primary ID differs')
    protocol.send_data(state, stream, b'x' * 32, True)
    protocol.grant(state, stream, 3)
    server.receive_data(b''.join(sent))
    sent.clear()
    server.send_headers(3, [(':status', '200'), ('x-middleware', 'retained')])
    server.send_data(3, b'abc', end_stream=True)
    protocol.accept(state, server.data_to_send())
    result = protocol.complete(state, 3)
    require(result['bytes'] == 3 and result['sha256'] == 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'
            and 'body' not in result, 'hash-only completion retained a body')
    require(state['request']['connection_debt'] == 32, 'request debt lost')
    output_stage.enter_final(state['stage'], state['raw'], state['request'], state['response'])
    require(state['stage']['budget'] == 1487112 + 13 * 64, 'late refund budget differs')
    refund = lambda stream: b'\x00\x00\x04\x08\x00' + stream.to_bytes(4, 'big') + (32).to_bytes(4, 'big')
    protocol.accept(state, refund(3) + refund(0))
    require(state['request']['connection_debt'] == 0 and 3 not in state['request']['streams'],
            'late closed-stream debt was not retired')
    print('protocol pairing checks: PASS')


if __name__ == '__main__':
    main()
