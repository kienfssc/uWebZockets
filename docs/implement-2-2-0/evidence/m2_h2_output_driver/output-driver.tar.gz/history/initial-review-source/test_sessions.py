"""Verify case connection count, deadline and final collection ordering."""
import sys
from unittest import mock
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import orchestration
import sessions


def main():
    actions = []
    clock_values = iter([10, 12, 14])
    def clock():
        return next(clock_values)
    def connect(case, deadline):
        actions.append(('connect', case, deadline))
        return {'codec': case, 'write': None, 'read': None, 'close': lambda: actions.append(('close', case))}
    def setup(codec, case, write, read):
        return ({'case': case, 'request': {'connection_debt': 1, 'streams': {}}, 'output_observations': {case: {'tag': case}}, 'checkpoints': [], 'events': {}, 'body_history': [], 'output_history': [], 'completions': [], 'stage': {'bytes': 0, 'reads': 0, 'budget': 1, 'auxiliary': 0, 'acks': 2}}, {})
    def run_case(case, state, api):
        actions.append(('case', case))
        return (0, 2) if case == 'producer_reuse' else None
    def collect(state, api, selection):
        actions.append(('final', state['case'], selection))
        return {'records': [], 'totals': {}}
    with mock.patch.object(orchestration, 'setup', setup), mock.patch.object(orchestration, 'run_case', run_case), mock.patch.object(orchestration, 'collect_final', collect):
        result = sessions.run(('producer_reuse', 'stream_file'), 900, clock, connect)
    expected = [('connect', 'producer_reuse', 40), ('case', 'producer_reuse'), ('close', 'producer_reuse'),
                ('connect', 'stream_file', 42), ('case', 'stream_file'),
                ('final', 'stream_file', ('producer_reuse', 'stream_file')), ('close', 'stream_file')]
    if actions != expected or result['binding'] != (0, 2):
        raise RuntimeError('connection schedule differs')
    print('session scheduling checks: PASS')


if __name__ == '__main__':
    main()
