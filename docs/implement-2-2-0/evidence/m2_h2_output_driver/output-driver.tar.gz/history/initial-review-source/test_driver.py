"""Whole-run ordering and failure cleanup with all external actions doubled."""
import sys
from unittest import mock
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import connection
import driver
import process_setup
import process_shutdown
import sessions


def main():
    actions = []
    def prepare(state, directory, binary, nonce, capacity, overall, clock, ops):
        actions.append(('prepare', overall))
        state.update(cert='cert', cert_hash='hash', child='child', start='start', listener='listener', capture='capture')
    def tls(cert):
        actions.append(('tls', cert))
        return 'tls'
    def factory(context, digest, owned, clock, check):
        actions.append(('factory', context, digest))
        return 'factory'
    def run_sessions(selection, overall, clock, factory):
        actions.append(('sessions', selection, overall, factory))
        return {'final': {'records': [], 'totals': {}}, 'binding': None, 'outputs': {}}
    def graceful(state, result, selection, nonce, capacity, overall, clock, ops):
        actions.append(('graceful', overall))
        return {'post': True}
    def cleanup(state, clock):
        actions.append(('cleanup',))
        return []
    ops = {'owned': lambda *args: None, 'snapshot': lambda capture: b'',
           'snapshot_raw': lambda capture: {'bytes': b'', 'overflow': False, 'error': None, 'finished': True}}
    with mock.patch.object(process_setup, 'prepare', prepare), mock.patch.object(connection, 'tls_context', tls), \
         mock.patch.object(connection, 'factory', factory), mock.patch.object(sessions, 'run', run_sessions), \
         mock.patch.object(process_shutdown, 'graceful', graceful):
        result = driver.run(('stream_file',), '/tmp/run', '/tmp/binary', 'nonce', 'capacity', lambda: 10, ops, cleanup)
    if [a[0] for a in actions] != ['prepare', 'tls', 'factory', 'sessions', 'graceful'] or result['post'] != {'post': True}:
        raise RuntimeError('successful run order differs')
    actions.clear()
    def fail(*args):
        actions.append(('sessions',))
        raise ValueError('injected failure')
    with mock.patch.object(process_setup, 'prepare', prepare), mock.patch.object(connection, 'tls_context', tls), \
         mock.patch.object(connection, 'factory', factory), mock.patch.object(sessions, 'run', fail):
        try:
            driver.run(('stream_file',), '/tmp/run', '/tmp/binary', 'nonce', 'capacity', lambda: 10, ops, cleanup)
        except ValueError as exc:
            if str(exc) != 'injected failure':
                raise
        else:
            raise RuntimeError('failed run accepted')
    if actions[-1] != ('cleanup',):
        raise RuntimeError('failure cleanup missing')
    print('whole-run orchestration checks: PASS')


if __name__ == '__main__':
    main()
