"""Host setup operations must pass exact inputs to doubled filesystem and process APIs."""
import sys
from types import SimpleNamespace
from unittest import mock
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import process_io


def main():
    calls = []
    def mkdir(path, mode):
        calls.append(('mkdir', path, mode))
    def chmod(path, mode):
        calls.append(('chmod', path, mode))
    def run(argv, **kw):
        calls.append(('run', argv, kw))
    def popen(argv, **kw):
        calls.append(('popen', argv, kw))
        return SimpleNamespace(pid=51, stdout='pipe')
    with mock.patch.object(process_io.os, 'mkdir', mkdir), mock.patch.object(process_io.os, 'chmod', chmod), \
         mock.patch.object(process_io.subprocess, 'run', run), mock.patch.object(process_io.subprocess, 'Popen', popen):
        ops = process_io.operations(lambda: 100)
        ops['directory']('/tmp/run', 0o700)
        ops['certificate'](['openssl'], {'OPENSSL_CONF': 'conf'}, 110)
        ops['chmod']('/tmp/run/key', 0o600)
        child = ops['spawn'](['/tmp/binary'], {'H2_PROFILE_FILE': '/tmp/run/file'})
    if child['pid'] != 51 or [item[0] for item in calls] != ['mkdir', 'run', 'chmod', 'popen']:
        raise RuntimeError('host operation ordering differs')
    if calls[1][2]['env'] != {'OPENSSL_CONF': 'conf'} or calls[1][2]['timeout'] != 10 or not calls[1][2]['check']:
        raise RuntimeError('certificate invocation differs')
    if calls[3][2]['env'] != {'H2_PROFILE_FILE': '/tmp/run/file'}:
        raise RuntimeError('fixture environment differs')
    print('host operation checks: PASS')


if __name__ == '__main__':
    main()
