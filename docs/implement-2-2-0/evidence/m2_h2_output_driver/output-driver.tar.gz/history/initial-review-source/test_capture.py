"""Bounded capture and nonce readiness using caller-owned read doubles."""
import capture


def main():
    state = capture.new()
    chunks = iter([b'log H2_CAPACITY correct\nH2_RE', b'ADY nonce\n', b''])
    capture.collect(lambda: next(chunks), state)
    data = capture.snapshot(state)
    if data != b'log H2_CAPACITY correct\nH2_READY nonce\n':
        raise RuntimeError('captured bytes differ')
    capture.ready_markers(data, 'nonce', 'H2_CAPACITY correct')
    if capture.wait_ready(state, 'nonce', 'H2_CAPACITY correct', 15, lambda: 1, lambda: None, lambda: ['42']) != '42':
        raise RuntimeError('owned listener differs')
    for bad in (data + b'H2_READY nonce\n', data.replace(b'correct', b'wrong')):
        try:
            capture.ready_markers(bad, 'nonce', 'H2_CAPACITY correct')
        except ValueError:
            continue
        raise RuntimeError('bad readiness accepted')
    over = capture.new()
    capture.collect(iter([b'x' * 8192] * 9 + [b'']).__next__, over)
    raw = capture.inspect(over)
    if len(raw['bytes']) != 65536 or raw['overflow'] is not True:
        raise RuntimeError('overflow evidence lost')
    try:
        capture.snapshot(over)
    except ValueError:
        pass
    else:
        raise RuntimeError('capture overflow accepted')
    print('capture checks: PASS')


if __name__ == '__main__':
    main()
