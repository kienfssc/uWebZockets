"""Reset an unfinished upload after final response and refund its debt."""
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import contracts
import h2.config
import h2.connection
import protocol
from test_protocol import source_settings


def main():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    server.initiate_connection()
    server.data_to_send()
    sent = []
    state = protocol.new(client, 'early', 3, sent.append)
    protocol.initiate(state)
    server.receive_data(b''.join(sent)); sent.clear()
    protocol.accept(state, source_settings() + server.data_to_send())
    server.receive_data(b''.join(sent)); sent.clear()
    health = protocol.start(state, 'GET', '/health', [], True, 2, 200)
    server.receive_data(b''.join(sent)); sent.clear()
    server.send_headers(health, [(':status', '200'), ('x-middleware', 'retained')])
    server.send_data(health, b'ok', end_stream=True)
    protocol.accept(state, server.data_to_send())
    protocol.complete(state, health)
    protocol.settings(state, 0)
    server.receive_data(b''.join(sent)); sent.clear()
    protocol.accept(state, server.data_to_send())
    stream = protocol.start(state, 'POST', '/refused', [('content-length', '32')], False, 17, 403,
                            mode='hash_only', digest=contracts.EARLY_HASH, policy='refusal_after_final')
    protocol.send_data(state, stream, b'12345', False)
    server.receive_data(b''.join(sent)); sent.clear()
    server.send_headers(stream, [(':status', '403'), ('x-middleware', 'retained')])
    protocol.accept(state, server.data_to_send())
    protocol.grant(state, stream, 8)
    server.receive_data(b''.join(sent)); sent.clear()
    server.send_data(stream, b'early-fi')
    protocol.accept(state, server.data_to_send())
    if state['records'][stream]['bytes'] != 8 or state['records'][stream]['ended']:
        raise RuntimeError('early prefix differs')
    protocol.grant(state, stream, 9)
    server.receive_data(b''.join(sent)); sent.clear()
    server.send_data(stream, b'nal-order', end_stream=True)
    server.reset_stream(stream, error_code=0)
    protocol.accept(state, server.data_to_send())
    result = protocol.complete(state, stream)
    if not result['end'] or not result['reset'] or result['sha256'] != contracts.EARLY_HASH:
        raise RuntimeError('early terminal differs')
    if state['request']['connection_debt'] != 5 or not state['request']['streams'][stream]['reset']:
        raise RuntimeError('unfinished upload debt or reset lost')
    def refund(target):
        return b'\x00\x00\x04\x08\x00' + target.to_bytes(4, 'big') + (5).to_bytes(4, 'big')
    protocol.accept(state, refund(stream) + refund(0))
    if state['request']['connection_debt'] or stream in state['request']['streams']:
        raise RuntimeError('late refund was lost')
    print('unfinished upload reset checks: PASS')


if __name__ == '__main__':
    main()
