"""Run final status collection against a pure public H2 server codec."""
import json
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import contracts
import h2.config
import h2.connection
import h2.events
import orchestration
import protocol
from test_protocol import source_settings
from test_records import fixture_record


def main():
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server.initiate_connection()
    server.data_to_send()
    incoming = [source_settings()]
    pending = {}
    observed = []
    rows = {item['tag']: fixture_record(item) for item in contracts.expected_records([])}
    totals = {'middleware': 0, 'attempts': 0, 'begin': 0, 'end': 0, 'cancel': 0, 'failure': 0,
              'end_errors': 0, 'chunk_errors': 0, 'invalid_progress': 0, 'accepted': 0, 'active': 0,
              'errors': 0, 'buffered_middleware': 33, 'slot0_active': False, 'slot1_active': False}
    def respond(stream):
        path = pending.pop(stream)
        observed.append(path)
        if path == '/health':
            body = b'ok'
        elif path == '/primary':
            body = b'abc'
        elif path.startswith('/status/'):
            body = json.dumps(rows[path.removeprefix('/status/')]).encode()
        elif path == '/metrics':
            body = json.dumps(totals).encode()
        else:
            raise ValueError('unexpected request path')
        server.send_headers(stream, [(':status', '200'), ('x-middleware', 'retained')])
        server.send_data(stream, body, end_stream=True)
    def write(data):
        for event in server.receive_data(data):
            if isinstance(event, h2.events.RequestReceived):
                pending[event.stream_id] = dict(event.headers)[':path']
                if server.local_flow_control_window(event.stream_id) > 0:
                    respond(event.stream_id)
            if isinstance(event, h2.events.WindowUpdated) and event.stream_id in pending:
                respond(event.stream_id)
        data = server.data_to_send()
        if data:
            incoming.append(data)
    def read():
        if not incoming:
            raise ValueError('unexpected receive')
        return incoming.pop(0)
    state, api = orchestration.setup(client, 'producer_reuse', write, read)
    primary = protocol.start(state, 'POST', '/primary', [('content-length', '32')], False, 3, 200,
                             mode='hash_only', digest='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
    protocol.send_data(state, primary, contracts.P32, True)
    protocol.grant(state, primary, 3)
    api['finish'](primary)
    result = orchestration.collect_final(state, api, [])
    if result['records'] != list(rows.values()) or result['totals'] != totals:
        raise RuntimeError('final records differ')
    if observed != ['/health', '/primary'] + ['/status/' + tag for tag in contracts.TAGS] + ['/metrics']:
        raise RuntimeError('final ordering differs')
    print('final collection checks: PASS')


if __name__ == '__main__':
    main()
