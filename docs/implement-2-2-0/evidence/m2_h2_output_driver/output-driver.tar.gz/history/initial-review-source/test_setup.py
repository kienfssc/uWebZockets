"""Fixture setup must order certificate, launch and owned readiness."""
from types import SimpleNamespace
import process_setup


def main():
    calls = []
    def directory(path, mode):
        calls.append(('directory', path, mode))
    def certificate(argv, env, deadline):
        calls.append(('certificate', argv, env, deadline))
        return SimpleNamespace(stdout=b'', stderr=b'certificate-log')
    def chmod(path, mode):
        calls.append(('chmod', path, mode))
    def digest(path):
        calls.append(('digest', path))
        return 'a' * 64
    def spawn(argv, env):
        calls.append(('spawn', argv, env))
        return {'pid': 51}
    def start(pid):
        calls.append(('start', pid))
        return 'start-id'
    def collector(child):
        calls.append(('collector', child['pid']))
        return 'capture'
    def ready(child, start_id, capture, nonce, capacity, deadline):
        calls.append(('ready', child['pid'], start_id, capture, nonce, capacity, deadline))
        return 'inode'
    ops = {'directory': directory, 'certificate': certificate, 'chmod': chmod, 'digest': digest,
           'spawn': spawn, 'start': start, 'collector': collector, 'ready': ready}
    result = process_setup.prepare({}, '/tmp/run', '/tmp/binary', 'nonce', 'H2_CAPACITY expected', 900, lambda: 0, ops)
    if result['listener'] != 'inode' or result['cert_hash'] != 'a' * 64 or result['certificate_stderr_hex'] != b'certificate-log'.hex():
        raise RuntimeError('setup evidence differs')
    if [item[0] for item in calls] != ['directory', 'certificate', 'chmod', 'digest', 'spawn', 'start', 'collector', 'ready']:
        raise RuntimeError('setup order differs')
    env = calls[4][2]
    if env != {'H2_PROFILE_CERT': '/tmp/run/certificate.pem', 'H2_PROFILE_KEY': '/tmp/run/private-key.pem',
               'H2_PROFILE_NONCE': 'nonce', 'H2_PROFILE_FILE': '/tmp/run/transfer.bin'}:
        raise RuntimeError('fixture environment differs')
    print('process setup checks: PASS')


if __name__ == '__main__':
    main()
