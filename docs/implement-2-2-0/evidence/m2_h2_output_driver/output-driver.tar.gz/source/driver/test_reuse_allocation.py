"""Exercise the real reuse case and adapter until B's body reaches a pure codec."""
import json
import sys
sys.path.insert(0, '/tmp/uwz-task5d1-round3-current')
sys.path.insert(0, '/tmp/uwz-h2-client-tooling/packages')
import contracts
import h2.config
import h2.connection
import h2.events
import cases
import orchestration
from test_cases import body
from test_protocol import source_settings


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    server.initiate_connection()
    server.data_to_send()
    incoming = [source_settings()]
    pending = {}
    observed = []
    held = {'tag': 'producer_reuse', 'armed': True, 'done': False, 'offset': 0,
            'sha256': contracts.EMPTY_HASH, 'invocations': 1, 'attempts': 1,
            'writes': 0, 'blocked': 1, 'pending': 1, 'terminal_attempts': 0,
            'terminals': 0, 'checks': 1, 'after_reuse': 0, 'errors': 0,
            'binding_index': 0, 'binding_generation': 1}

    def respond(stream):
        path = pending.pop(stream)
        if path == '/health':
            data = b'ok'
        elif path == '/status/producer_reuse':
            data = json.dumps(body('producer_reuse')).encode()
        elif path == '/output/producer_reuse':
            data = json.dumps(held).encode()
        else:
            raise ValueError('unexpected response path: ' + path)
        server.send_headers(stream, [(':status', '200'), ('x-middleware', 'retained')])
        server.send_data(stream, data, end_stream=True)

    def write(data):
        for event in server.receive_data(data):
            if isinstance(event, h2.events.RequestReceived):
                fields = dict(event.headers)
                observed.append((event.stream_id, fields[':path']))
                if fields[':path'] in ('/health', '/status/producer_reuse', '/output/producer_reuse'):
                    pending[event.stream_id] = fields[':path']
                    if server.local_flow_control_window(event.stream_id) > 0:
                        respond(event.stream_id)
            if isinstance(event, h2.events.WindowUpdated) and event.stream_id in pending:
                respond(event.stream_id)
            if isinstance(event, h2.events.DataReceived) and event.stream_id == 3:
                require(event.data == contracts.P32, 'A body differs')
                server.send_headers(3, [(':status', '200'), ('x-middleware', 'retained')])
            if isinstance(event, h2.events.DataReceived) and event.stream_id == 9:
                require(event.data == contracts.P32 and event.stream_ended is not None, 'B body differs')
                raise RuntimeError('bounded stop after B body')
        data = server.data_to_send()
        if data:
            incoming.append(data)

    def read():
        require(bool(incoming), 'unexpected receive')
        return incoming.pop(0)

    state, api = orchestration.setup(client, 'producer_reuse', write, read)
    try:
        cases.producer_reuse(api)
    except RuntimeError as exc:
        if str(exc) != 'bounded stop after B body':
            raise
    else:
        raise RuntimeError('expected bounded stop')
    require(observed == [(1, '/health'), (3, '/limit/producer_reuse?case=producer_reuse'),
                         (5, '/status/producer_reuse'), (7, '/output/producer_reuse'),
                         (9, '/limit/producer_reuse_next?case=producer_reuse_next')],
            'actual stream allocation differs: ' + repr(observed))
    require(state['request']['sent'] == 64 and state['request']['streams'][9]['request_end'],
            'B body accounting differs')
    print('actual reuse allocation through B body: PASS (bounded stop)')


if __name__ == '__main__':
    main()
