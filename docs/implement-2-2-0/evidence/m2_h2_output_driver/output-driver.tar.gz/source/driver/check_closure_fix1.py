"""Check, mutate one owned source input, restore it, and check again."""
import argparse
import importlib.util
import os
from pathlib import Path
import stat
import sys


RUNTIME = Path('/tmp/uwz-task5d3-runtime-v5')
MANIFEST = Path('/tmp/uwz-task5d3-manifest-v5.json')
TARGET = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver/records.py')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('frozen_closure', RUNTIME / 'closure.py')
    if spec is None or spec.loader is None:
        raise ValueError('closure loader unavailable')
    module = importlib.util.module_from_spec(spec)
    sys.modules['frozen_closure'] = module
    spec.loader.exec_module(module)
    module.validate(MANIFEST, args.manifest_sha256)
    print('current closure: accepted')
    before = TARGET.read_bytes()
    mode = stat.S_IMODE(TARGET.stat().st_mode)
    print('mutated path:', TARGET)
    print('before sha256:', module.digest(TARGET))
    try:
        TARGET.write_bytes(before + b'\n')
        print('mutated sha256:', module.digest(TARGET))
        try:
            module.validate(MANIFEST, args.manifest_sha256)
        except ValueError as exc:
            if str(exc) != 'tree identity differs: ' + str(TARGET.parent):
                raise
            print('mutated actual input: rejected:', exc)
        else:
            raise ValueError('mutated input accepted')
    finally:
        TARGET.write_bytes(before)
        os.chmod(TARGET, mode)
    if TARGET.read_bytes() != before or stat.S_IMODE(TARGET.stat().st_mode) != mode:
        raise ValueError('source restoration differs')
    print('restored sha256:', module.digest(TARGET))
    module.validate(MANIFEST, args.manifest_sha256)
    print('restored closure: accepted')


if __name__ == '__main__':
    main()
