"""Freeze the current source and bind the actual fixture compile receipts."""
import json
from pathlib import Path
import shutil
import closure


MANIFEST = Path('/tmp/uwz-task5d3-manifest-v5.json')


def main():
    if closure.RUNTIME.exists() or MANIFEST.exists():
        raise ValueError('closure output already exists')
    if closure.digest(closure.BASE) != closure.BASE_HASH or closure.digest(closure.PUBLIC) != closure.PUBLIC_HASH:
        raise ValueError('source anchor differs')
    base = json.loads(closure.BASE.read_text())
    public = json.loads(closure.PUBLIC.read_text())
    source_before = closure.inventory(closure.SOURCE)
    closure.RUNTIME.mkdir(mode=0o700)
    for name in closure.RUNTIME_NAMES:
        shutil.copyfile(closure.SOURCE / name, closure.RUNTIME / name)
        (closure.RUNTIME / name).chmod(0o444)
    closure.RUNTIME.chmod(0o555)
    trees = {name: files for name, files in base['trees'].items()
             if name not in ('/tmp/uwz-task5c3-fixture-v1', '/tmp/uwz-task5c3-runtime-v2')}
    for path in (closure.SOURCE, closure.RUNTIME, closure.CLIENT, closure.FIXTURE, closure.COMPILE):
        trees[str(path)] = closure.inventory(path)
    if trees[str(closure.SOURCE)] != source_before:
        raise ValueError('source changed while freezing')
    retained = ('/home/codespace/.python/current/', '/lib/', '/lib64/', '/opt/conda/')
    inputs = {name: value for name, value in base['inputs'].items() if name.startswith(retained)}
    inputs.update({str(closure.BASE): closure.BASE_HASH, str(closure.PUBLIC): closure.PUBLIC_HASH,
                   str(closure.HELPER): closure.HELPER_HASH})
    binaries = {}
    for path, label in zip(closure.RECEIPTS, ('debug', 'release')):
        receipt = json.loads(path.read_text())
        inputs.update(receipt['inputs_before'])
        inputs[str(path)] = public['builds'][label]['receipt_sha256']
        binary = next(item.split('=', 1)[1] for item in receipt['argv'] if item.startswith('-femit-bin='))
        inputs[binary] = receipt['binary_sha256']
        binaries[label] = binary
        for suffix in ('stdout', 'stderr'):
            log = path.parent / (label + '.' + suffix)
            inputs[str(log)] = closure.digest(log)
    manifest = {'state': 'ready-for-independent-review', 'scope': 'source and pure preparation only',
                'trees': trees, 'inputs': inputs, 'binaries': binaries, 'capacity': closure.CAPACITY,
                'python': closure.PYTHON, 'python_flags': ['-B', '-S'],
                'environment': {'LC_ALL': 'C.UTF-8', 'PYTHONPATH': closure.PACKAGES + ':' + str(closure.CLIENT)}}
    MANIFEST.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    MANIFEST.chmod(0o444)
    expected = closure.digest(MANIFEST)
    closure.validate(MANIFEST, expected)
    print('runtime files:', len(trees[str(closure.RUNTIME)]))
    print('tree counts:', {name: len(files) for name, files in trees.items()})
    print('direct inputs:', len(inputs))
    print('manifest sha256:', expected)


if __name__ == '__main__':
    main()
