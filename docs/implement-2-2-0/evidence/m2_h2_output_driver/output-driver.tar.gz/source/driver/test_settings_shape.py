"""Compare the shared SETTINGS bytes with the approved server serialization."""
from test_protocol import source_settings


def main():
    expected = bytes.fromhex(
        '00001e040000000000'
        '000100001000000200000000000300000008000600004000000800000001'
    )
    actual = source_settings()
    if actual != expected:
        raise ValueError('server SETTINGS bytes differ: ' + actual.hex())
    print('approved server SETTINGS serialization: PASS')


if __name__ == '__main__':
    main()
