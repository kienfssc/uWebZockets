# Task 5d3 source and pure preparation report

Status: source and pure preparation completed; independent review is pending. The current closure is `/tmp/uwz-task5d3-manifest-v4.json`, SHA-256 `1076902ec74e5bbcc862b4818cd69ccba533cc256295f30c17aef2fd861aec96`; its read-only runtime is `/tmp/uwz-task5d3-runtime-v4`. These are preparation artifacts, not permission to run the fixture. No native binary, constructor, server, socket, SSLContext, compiler, certificate, file transfer, descriptor or fault probe, prior live checker, or general project gate was executed.

The owned source is `.uwz-work/evidence/h2-streaming/integration-owned/output-driver/`. It contains 19 runtime files, 24 focused test files, `freeze.py`, and `check_closure.py`. The guarded `run_live.py` validates the closure before loading the driver and requires `--run`, the exact interpreter/environment, a new private `/tmp` output directory, a binary mode and an explicit nonempty selection. It creates one fixture process per selection and one TLS connection per case, runs final33 on the last connection, checks post-deinit records and outputs, and records cleanup and failure observations. Socket, TLS, file and process setup behavior was exercised only with doubles; the pure H2 tests use public codecs and source-shaped bytes.

The source retains manual request/response credit pairing, raw ordered incoming accounting, separate HEADERS flushes, fixed 8,192-byte send/read bounds and eight active records. Large response completion contains hashes and terminal facts without retaining DATA bodies or decoding them. Bounded completion, prefix-hash, body and output observations are retained in the result. The five functions implement the held window, continuously read ready, A/B reuse, file and early 8+9 schedules. Their ordinary fixture behavior remains unobserved until a separately authorized native run.

## Actual input binding

The current manifest validates actual file bytes and inventory, including 45 owned source/tool files, 19 frozen runtime files, the reviewed 12-file client, 42 codec files, five current fixture files, and the separate five-file actual compile snapshot. The four unchanged current `profile.zig`, `output.zig`, `file_observer.zig`, and `prepare.py` files are compared against the compile snapshot; the historical compile snapshot's `test_prepare.py` is bound separately. It also binds 1,031 candidate files, 93 override files, the Zig library tree, zslay, the pinned helper, the interpreter, loader/tool/environment inputs, 2,413 direct inputs, and both actual Debug and ReleaseSafe receipts, their empty compiler logs and binaries. The candidate aggregate uses Path-sorted JSON pairs and default `json.dumps` separators.

Source identities and hashes:

- Current reviewed client aggregate: `4cc0b57f0347845f582d1f7e2621ee8ec0701fb83b0762590e7959370ecca81e`.
- Candidate aggregate: `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`.
- Helper: `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`.
- Debug receipt/binary: `c0fd9fad71383e63b501cda23e40b7b9ff0a690c0438bd97bc75edaba4246352` / `57b1fabd6ea6a66ce92e065dbc4a336810ddd38e88cece3bf1a63de17267fe3d`.
- ReleaseSafe receipt/binary: `66e4804752ea51d30430f4ca657305c4ab85242a8e4d540a64e431a8b79dc079` / `d1a8a2c0e7e86d1cf4add784a4f1c48d85afde15cbebe783d7766f3ab88fa543`.
- Full source and runtime SHA-256 inventories are `/tmp/uwz-task5d3-checks/source-final-sha256.txt` and `/tmp/uwz-task5d3-checks/runtime-final-sha256.txt`.

Exact freeze command, Python 3.14.2 with `-B -S`, exit 0:

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-driver/freeze.py
```

Raw `/tmp/uwz-task5d3-checks/freeze-v4.log`:

```text
runtime files: 19
tree counts: {'/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/lib': 19542, '/tmp/uwz-h2-client-tooling/packages': 42, '/tmp/uwz-reviewed-libxev-c223-loop-callbacks': 93, '/tmp/uwz-task4d-fix1-frozen': 1031, '/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy': 14, '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver': 45, '/tmp/uwz-task5d3-runtime-v4': 19, '/tmp/uwz-task5d1-round3-current': 12, '/tmp/uwz-task5d2-fix2-final-snapshot': 5, '/tmp/uwz-task5d2-fix1final/fixture': 5}
direct inputs: 2413
manifest sha256: 1076902ec74e5bbcc862b4818cd69ccba533cc256295f30c17aef2fd861aec96
```

The frozen runtime directory is mode 555, its files mode 444, and the manifest mode 444. Earlier v1-v3 snapshots and logs remain historical; only v4 is current.

## Focused preparation checks

The exact final command below ran the authored tests only, from `/workspaces/uWebZockets`, without rerunning the reviewed component suites. `-O` is Python optimization; it is not a Zig optimization mode. Exit 0; raw output is retained at `/tmp/uwz-task5d3-checks/focused-v6.log` and is reproduced below.

```sh
for mode in normal opt; do for file in .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_*.py; do if [ "$mode" = opt ]; then /home/codespace/.python/current/bin/python3 -B -O "$file"; else /home/codespace/.python/current/bin/python3 -B "$file"; fi; status=$?; printf '%s %s exit=%s\n' "$mode" "$file" "$status"; [ "$status" -eq 0 ] || exit "$status"; done; done
```

```text
case adapter checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_adapter.py exit=0
capture checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_capture.py exit=0
case accounting checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_case_counts.py exit=0
case scheduling checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_cases.py exit=0
failure cleanup checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_cleanup.py exit=0
connection setup checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_connection.py exit=0
diagnostic checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_diagnostics.py exit=0
whole-run orchestration checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_driver.py exit=0
early schedule checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_early.py exit=0
final collection checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_final.py exit=0
process identity checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_identity.py exit=0
AST and inert import checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_inert.py exit=0
orchestration setup checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_orchestration.py exit=0
owned I/O checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_owned_io.py exit=0
post-deinit evidence checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_post.py exit=0
host operation checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_process_io.py exit=0
protocol pairing checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_protocol.py exit=0
record boundary checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_records.py exit=0
ready and file schedule checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_remaining.py exit=0
unfinished upload reset checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_reset.py exit=0
session scheduling checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_sessions.py exit=0
process setup checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_setup.py exit=0
process shutdown checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_shutdown.py exit=0
window schedule checks: PASS
normal .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_window.py exit=0
case adapter checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_adapter.py exit=0
capture checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_capture.py exit=0
case accounting checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_case_counts.py exit=0
case scheduling checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_cases.py exit=0
failure cleanup checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_cleanup.py exit=0
connection setup checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_connection.py exit=0
diagnostic checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_diagnostics.py exit=0
whole-run orchestration checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_driver.py exit=0
early schedule checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_early.py exit=0
final collection checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_final.py exit=0
process identity checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_identity.py exit=0
AST and inert import checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_inert.py exit=0
orchestration setup checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_orchestration.py exit=0
owned I/O checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_owned_io.py exit=0
post-deinit evidence checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_post.py exit=0
host operation checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_process_io.py exit=0
protocol pairing checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_protocol.py exit=0
record boundary checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_records.py exit=0
ready and file schedule checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_remaining.py exit=0
unfinished upload reset checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_reset.py exit=0
session scheduling checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_sessions.py exit=0
process setup checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_setup.py exit=0
process shutdown checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_shutdown.py exit=0
window schedule checks: PASS
opt .uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_window.py exit=0
```

The public-codec integration checks cover first SETTINGS/ACK before health, a second acknowledged window, source-shaped server frames, headers and grants, hash-only binary completion, raw END before a NO_ERROR reset of an unfinished upload, late closed-stream and connection refunds, and final-stage debt carry. The pure final-stage test collects 32 ordered status responses and metrics from a public H2 server codec. Case-function doubles reject bad grant ordering, missing release prerequisites, mismatched reuse generation, duplicate file Content-Length and early ordering. Fixture record/totals tests reject changed counters, types and hashes; post-deinit tests reject altered selected snapshots and unselected file ownership. AST/inert imports were checked under empty and foreign argv with socket/TLS/process constructors replaced by rejecting doubles. None of these is an observed native fixture result.

Red failure logs and exits are retained under `/tmp/uwz-task5d3-checks/`, including `completion-red.log`, `capture-raw-red.log`, `no-start-red.log`, `file-header-red.log`, `directory-red.log`, and the earlier `*-red.log` files. Many initial reds show missing implementation symbols; the named later reds show the actual missing evidence, failure capture, cleanup and header checks. The final33 and reset codec tests were added to an existing implementation and are not represented as failing-before-fix regressions.

## Actual owned-input mutation proof

The following two commands ran sequentially, each exit 0; the second adds Python `-O`. Each checks the actual current manifest, appends one byte to the actual owned `records.py`, requires rejection, restores its original bytes and mode, and checks again. Raw results are retained in `/tmp/uwz-task5d3-checks/closure-v4-normal.log` and `closure-v4-opt.log`.

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-driver/check_closure.py --manifest-sha256 1076902ec74e5bbcc862b4818cd69ccba533cc256295f30c17aef2fd861aec96
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/output-driver/check_closure.py --manifest-sha256 1076902ec74e5bbcc862b4818cd69ccba533cc256295f30c17aef2fd861aec96
```

Both raw outputs:

```text
current closure: accepted
mutated path: /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver/records.py
before sha256: 56a592d54a95c5457880c8b7db14b479e245e58a74ff5dfd4d9798823d0b62f1
mutated sha256: 2aca112db4fa1256175b8ade4ced2a2eae6b67936b5a3b1acf09a5685811ca7b
mutated actual input: rejected: tree identity differs: /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver
restored sha256: 56a592d54a95c5457880c8b7db14b479e245e58a74ff5dfd4d9798823d0b62f1
restored closure: accepted
```

## Bounds, ownership and review notes

The reviewed stage bounds are 18,243,676 decrypted bytes for a producer, 1,693,852 for a file and 1,447,948 for early final. Final33 has budget 1,487,112 plus 13 times the actual remaining connection and stream request debts. Storage is bounded by eight active response records, 8,192-byte reads/sends, 65,536 captured server bytes, fewer than 4,096 bytes per small body, 74 completion facts per case connection and eight body/output/checkpoint observations per respective case. These are source-derived limits, not performance measurements.

Case auxiliary counts are 7/5/8/6/6 and request-flow counts are 33/33/64/33/32 for window, ready, reuse, file and early respectively. Buffered middleware is 33 final requests plus 7/5/7/6/5 for the corresponding selected cases. All five derive 37 case requests plus final33, 70 middleware observations, 63 buffered observations, 7 body middleware admissions and 6 successful 32-byte body callbacks. The reuse B upload is an admitted request, not buffered middleware. Producer retry counters are observed, checked monotonic and validated with source algebra; they are not fixed callback counts.

The file success check requires one transport close, no post-deinit second close, zero invalid spans/read errors, transferred ownership and the requested range/hash. It does not impose an exact read count or total under retries. No returned-error ownership proof follows from this success observation or the doubles. Root's `task-5d-returned-error-source-review.md` distinguishes current caller/wrapper/backend control flow from historical tests whose backend hashes differ. No descriptor or returned-error probe was performed here.

Self-review boundaries: the output-directory failure path tracks whether mkdir succeeded before cleanup or result writing; an unreaped Popen child is killed on failure even if initial start sampling failed, while a changed recorded start identity rejects forced signaling. The borrowed-metadata check is the fixture's own producer observation; the Python test does not manufacture a native callback. The guarded runtime and the source/receipt closure still require Root's independent review before any native attempt. Graphify's ignored prior graph was not modified because this assignment owns only the new output-driver directory, its new `/tmp` artifacts and this report.

No native five-case result, combined 40-case matrix, full local/protocol gates, milestone completion or production adoption is claimed.

## Fix round 1: reuse stream allocation and server SETTINGS

The earlier v4 status and manifest are superseded. The current source/preparation closure is `/tmp/uwz-task5d3-manifest-v5.json`, SHA-256 `aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890`; the frozen runtime is `/tmp/uwz-task5d3-runtime-v5`. This round addresses the independent review's two findings and is ready for scoped re-review, not native release.

The reuse case now expects B on stream 9: health consumed 1, A used 3, and the two real diagnostic GETs used 5 and 7. `test_reuse_allocation.py` executes the actual `cases.producer_reuse`, actual case adapter and actual protocol state against public in-memory H2 codecs, using bounded fixture-data doubles. It verifies the observed requests and 64 bytes of paired upload accounting. The deliberate bounded stop occurs only after B's real adapter identity check and its P32 DATA reached the server codec; it does not claim full reuse case completion. The earlier `test_cases.py` double now rejects wrong upload identities rather than echoing an arbitrary requested ID.

The shared `source_settings()` helper now emits settings IDs 1, 2, 3, 6 and 8 with values 4096, 0, 8, 16384 and 1. This corresponds to the retained server's `send_settings` at `/tmp/uwz-task4d-fix1-frozen/src/http2/server.zig:1930` and the reviewed source-shaped client test at `/tmp/uwz-task5d1-round3-current/test_client_core.py:175`. The new serialization test compares the complete shared frame to independent literal bytes. The adapter, setup, reset and final tests all import this shared helper. This was a preparation coverage mismatch; it does not establish a native runtime defect.

Changed owned files are `cases.py`, `closure.py` (v5 runtime path), `test_cases.py`, and `test_protocol.py`; new files are `test_reuse_allocation.py`, `test_settings_shape.py`, `freeze_fix1.py`, and `check_closure_fix1.py`. Among the 19 frozen runtime files only `cases.py` and `closure.py` differ from v4. Source hashes:

```text
7068df529c9de2f793ecbb146a30897c3c6477026282073cc322572fb2f45817  cases.py
f342419507accbd5fca0b6be5354b511cdff18b212689463745c9c115ceb1862  closure.py
a2b87df4f322c9857f64e0261634241681df37c0b3cf56fff8dad7c0abc3c1a3  test_cases.py
444e3418da44332bc1232c73fc3825ff76e4cf93154c947ac2a151d30eb7a5fc  test_protocol.py
9141986613e44cc294664c8a1fad8d0fdd6cbe0f7136d3c843be693cc1e4d73c  test_reuse_allocation.py
c0e223a95750a13db6c80695a305ebec4be600ac6855e35d4a9a2f1324a5c470  test_settings_shape.py
18e349ff705d29b7d1f9c548bbe80fd2d02893fe1a9789999a6e29b4e8292800  freeze_fix1.py
66441678bf342991cba84f76217503ac033d7f42f6cc9b3c49ba308a2851f240  check_closure_fix1.py
```

### Red before changes

Python 3.14.2, `-B -S`, normal and `-O`, from `/workspaces/uWebZockets`. The exact red command loop was:

```sh
for mode in normal opt; do for name in test_reuse_allocation test_settings_shape; do if [ "$mode" = opt ]; then /home/codespace/.python/current/bin/python3 -B -S -O ".uwz-work/evidence/h2-streaming/integration-owned/output-driver/$name.py"; else /home/codespace/.python/current/bin/python3 -B -S ".uwz-work/evidence/h2-streaming/integration-owned/output-driver/$name.py"; fi > "/tmp/uwz-task5d3-fix1-$name-red-$mode.log" 2>&1; printf '%s\n' "$?" > "/tmp/uwz-task5d3-fix1-$name-red-$mode.exit"; done; done
```

Both modes gave exit 1 for each test. Raw normal reuse failure (the optimized traceback is identical):

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_reuse_allocation.py", line 91, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_reuse_allocation.py", line 75, in main
    cases.producer_reuse(api)
    ~~~~~~~~~~~~~~~~~~~~^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver/cases.py", line 37, in producer_reuse
    b = api['start_upload']('producer_reuse_next', 5, mode='small')
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver/case_adapter.py", line 65, in start_upload
    require(stream == expected, 'upload stream identity')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver/case_adapter.py", line 9, in require
    raise ValueError(message)
ValueError: upload stream identity
```

Raw normal SETTINGS failure (the optimized traceback is identical):

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_settings_shape.py", line 17, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver/test_settings_shape.py", line 12, in main
    raise ValueError('server SETTINGS bytes differ: ' + actual.hex())
ValueError: server SETTINGS bytes differ: 00001e04000000000000010000100000030000006400040000ffff000500004000000600010000
```

### Green and focused checks

The two new tests passed after the fixes in both modes: `actual reuse allocation through B body: PASS (bounded stop)` and `approved server SETTINGS serialization: PASS`, each exit 0. Exact covering command, run from the same directory with Python 3.14.2, exit 0:

```sh
for mode in normal opt; do for name in test_reuse_allocation test_settings_shape test_cases test_protocol test_adapter test_orchestration test_reset test_final test_inert; do if [ "$mode" = opt ]; then /home/codespace/.python/current/bin/python3 -B -S -O ".uwz-work/evidence/h2-streaming/integration-owned/output-driver/$name.py"; else /home/codespace/.python/current/bin/python3 -B -S ".uwz-work/evidence/h2-streaming/integration-owned/output-driver/$name.py"; fi; status=$?; printf '%s %s exit=%s\n' "$mode" "$name" "$status"; [ "$status" -eq 0 ] || exit "$status"; done; done
```

Raw output, retained at `/tmp/uwz-task5d3-fix1-focused.log`:

```text
actual reuse allocation through B body: PASS (bounded stop)
normal test_reuse_allocation exit=0
approved server SETTINGS serialization: PASS
normal test_settings_shape exit=0
case scheduling checks: PASS
normal test_cases exit=0
protocol pairing checks: PASS
normal test_protocol exit=0
case adapter checks: PASS
normal test_adapter exit=0
orchestration setup checks: PASS
normal test_orchestration exit=0
unfinished upload reset checks: PASS
normal test_reset exit=0
final collection checks: PASS
normal test_final exit=0
AST and inert import checks: PASS
normal test_inert exit=0
actual reuse allocation through B body: PASS (bounded stop)
opt test_reuse_allocation exit=0
approved server SETTINGS serialization: PASS
opt test_settings_shape exit=0
case scheduling checks: PASS
opt test_cases exit=0
protocol pairing checks: PASS
opt test_protocol exit=0
case adapter checks: PASS
opt test_adapter exit=0
orchestration setup checks: PASS
opt test_orchestration exit=0
unfinished upload reset checks: PASS
opt test_reset exit=0
final collection checks: PASS
opt test_final exit=0
AST and inert import checks: PASS
opt test_inert exit=0
```

`test_inert.py` was also rerun normal and `-O` after adding the two new closure tools; both printed `AST and inert import checks: PASS`, exit 0 (`/tmp/uwz-task5d3-fix1-inert-after-tools.log`). No unchanged component test suite or native gate was rerun.

### V5 frozen closure and mutation proof

Exact freeze command, exit 0:

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-driver/freeze_fix1.py
```

Raw output:

```text
runtime files: 19
tree counts: {'/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/lib': 19542, '/tmp/uwz-h2-client-tooling/packages': 42, '/tmp/uwz-reviewed-libxev-c223-loop-callbacks': 93, '/tmp/uwz-task4d-fix1-frozen': 1031, '/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy': 14, '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver': 49, '/tmp/uwz-task5d3-runtime-v5': 19, '/tmp/uwz-task5d1-round3-current': 12, '/tmp/uwz-task5d2-fix2-final-snapshot': 5, '/tmp/uwz-task5d2-fix1final/fixture': 5}
direct inputs: 2413
manifest sha256: aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890
```

V5 binds the actual 49-file owned source/tool tree, 19-file runtime, reviewed 12-file client, current and actual compile five-file fixture trees, candidate, override, codec and tool inputs, and the same actual compile receipts and binaries. Runtime directory mode is 555; runtime files and manifest are 444. The v4 manifest remains byte-identical at SHA-256 `1076902ec74e5bbcc862b4818cd69ccba533cc256295f30c17aef2fd861aec96`; v4 and earlier snapshots were not overwritten. Debug receipt/binary remain `c0fd9fad71383e63b501cda23e40b7b9ff0a690c0438bd97bc75edaba4246352` / `57b1fabd6ea6a66ce92e065dbc4a336810ddd38e88cece3bf1a63de17267fe3d`; ReleaseSafe receipt/binary remain `66e4804752ea51d30430f4ca657305c4ab85242a8e4d540a64e431a8b79dc079` / `d1a8a2c0e7e86d1cf4add784a4f1c48d85afde15cbebe783d7766f3ab88fa543`.

Exact current-checker commands, run sequentially, each exit 0:

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/output-driver/check_closure_fix1.py --manifest-sha256 aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/output-driver/check_closure_fix1.py --manifest-sha256 aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890
```

Both raw outputs, retained separately at `/tmp/uwz-task5d3-fix1-closure-normal.log` and `-opt.log`:

```text
current closure: accepted
mutated path: /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver/records.py
before sha256: 56a592d54a95c5457880c8b7db14b479e245e58a74ff5dfd4d9798823d0b62f1
mutated sha256: 2aca112db4fa1256175b8ade4ced2a2eae6b67936b5a3b1acf09a5685811ca7b
mutated actual input: rejected: tree identity differs: /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/output-driver
restored sha256: 56a592d54a95c5457880c8b7db14b479e245e58a74ff5dfd4d9798823d0b62f1
restored closure: accepted
```

The actual mutated owned path was `records.py`; its original/restored mode was 666. The checker verified exact original bytes and mode after restoration before accepting the closure again. No native builds, binaries, fixture or reviewed component sources, receipts, old live scripts/checkers, sockets, SSLContext, certificates, descriptor or error/resource probes were executed or changed. Root's independent scoped re-review and separate exact native release remain pending. Native five-case, combined 40-case, full quality/platform/fuzz/package gates, returned-error runtime proof and adoption remain open.
