# Task5d3: output driver, case orchestration and preparation closure

Read this first; it is the implementation requirements. Implement the real
five-case output driver using the approved fixture and client components. This
is SOURCE AND PURE PREPARATION ONLY. No native execution is released. Root owns
independent review, exact later host execution, publication, commits and pushes.

Own only NEW
`.uwz-work/evidence/h2-streaming/integration-owned/output-driver/`, new
`/tmp/uwz-task5d3-*`, and `task-5d3-report.md` in this plan workspace. You are not
alone in this codebase; preserve other edits and all historical evidence. No
commits/pushes, product/dependency/ref/pin/public archive edits, external model
CLI, or subagents. Keep helpers cohesive, shallow and bounded; no forwarding-only
layers or large speculative framework. If a real product defect blocks the
contract, report it rather than editing product code or weakening the client.

## Binding source plan and current inputs

Read `task-5d3-architecture.md` for the exact schedules, action pairing, A/R/S
counts, fixture diagnostics, selected-subset accounting and final33 sequencing.
Read `task-5d-budget-io.md` and `task-5d-credit-order.md` for framing/work limits
and ordered refund authority. These files live beside this brief. Root adopts
the reuse A8 adjustment for the actual B diagnostic schema; no budget increase.
The architecture handoff's pending-fixture-preparation wording is historical:
both fixture source and tooling have now passed scoped independent review.

Current reviewed client: `/tmp/uwz-task5d1-round3-current`, twelve files,
digest4cc0b57f0347845f582d1f7e2621ee8ec0701fb83b0762590e7959370ecca81e.
Six runtime modules are byte-identical to the prior reviewed client core;
current tests are functions. Five current fixture files:
`/tmp/uwz-task5d2-fix2-final-snapshot`. Public source identities and actual
compile receipt hashes are in
`docs/implement-2-2-0/evidence/m2_h2_output_fixture/manifest.json`.
Unchanged controlled actual builds and five-file compile snapshot:
`/tmp/uwz-task5d2-fix1final/`. Its three Zig files and prepare.py match current;
its historical test_prepare.py differs. No recompilation is needed or allowed
in this pass. Bind the actual compile snapshot separately from current tooling.

Start orchestration/process/TLS/identity patterns from the nine-file preserved
`/tmp/uwz-task5c3-runtime-v2` and retained lifecycle-close preparation helpers.
Pinned independent helper:
`.uwz-work/evidence/h2-streaming/integration-client/h2_client.py` SHA256
07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00.
Pinned pure codecs `/tmp/uwz-h2-client-tooling/packages`,42files,
digest0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Python `/home/codespace/.python/current/bin/python3` (3.14.2).
Candidate `/tmp/uwz-task4d-fix1-frozen`,1031files,
digestfc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de.
Override `/tmp/uwz-reviewed-libxev-c223-loop-callbacks`,93files. All immutable.
Root commit717734c preserves fixture preparation. Do not rerun those completed
component suites merely for reassurance; run focused new integration checks.

Graphify before new source questions/searches:
`env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650`.
Provided paths and lines surfaced by an earlier read are already located.

## Execution boundary and current code style

Allowed: authored Python/source/AST, inert imports, standard hashing, pure public
h2.connection.H2Connection and serialized protocol bytes, caller-owned API/I/O/
clock/process doubles, file hashing/copy/freezing and closure-checker self-tests.
FS/subprocess behavior of future runner setup must be doubled in behavioral
tests. No real socket/SSLContext/client construction, native binary/constructor/
test/fixture/server, compiler build, certificate/transfer-file setup, old live
script/checker entrypoint, native resource/FD/kernel/registration/completion/
fault/error/schedule/interleaving/race/panic/crash/leak probe. Do not resurrect
the original stopped experiments or use generic full gates as authorization.
No invalid or dummy descriptor/native error probe. A source function may contain
future ordinary owned-loopback logic; do not execute it in preparation.

No authored Python classes/inheritance, including test or exception subclasses.
Use named functions, explicit dictionaries/records and caller-visible probe
state. Standard imported codecs/mock/SimpleNamespace are allowed; do not hide
mutable state behind them. No Python assert as a proof condition; checks must
remain active under -O. Imports inert under empty/foreign argv; main guarded.
No TODO/FIXME/XXX/HACK markers, emojis, dead code, speculative wrappers or silenced
errors. No widening limits/exclusions/success fallbacks. Preserve raw failures.

## Required real driver behavior

One owned process per selected subset, fresh TLS1.3/h2 connection per selected
case, final33 on last connection. Preserve PID/start/listener/nonce ownership,
certificate-before-health, exact graceful shutdown/cleanup/reap and key removal.
Future file setup uses a private caller path supplied as H2_PROFILE_FILE. Bounded
stdout65536, actual send/read8192, eight active response records. Ready15,
case30, whole900, idle grace15; final33 shares the existing last-case deadline.
No extra readiness health connection or pre-run33, waits, threshold widening,
fixed sleeps, socket option/linger/shutdown flag manipulation or retries.

Initialize both credit ledgers, raw parser and strict stage BEFORE first receive.
Pair initial SETTINGS once, await initial ACK before health1; pair custom
window settings once and await second ACK. Manually credit every response.
Public data_to_send(amount=8192) only. HEADERS flushed separately before stream
grants. wire.accept applies all incoming accounting ONCE; no legacy
flow.receive_batch, autoacks, duplicate terminals or refunds. Actual outgoing
calls must pair with both ledgers/stage before the next receive; errors abort.
Public window comparisons use caller-known full closure and never private codec
fields or swallowed stream-state exceptions. Complete and retire each response
once while preserving outstanding request debts after retirement.

Hash-only large outputs must never enter unconditional UTF8/JSON decoding or
retain DATA bytes. Preserve exact headers/count/hash/END/reset facts and bounded
prefix checkpoints. Small helper bodies remain <4096. All five concrete
schedules, counts, producer identities, subset models and final status schemas
from the handoff are mandatory, including online B index/generation while A is
held, real WouldBlock/offset barriers, partial early response8+9 and raw END
before NO_ERROR reset. Actual fixture metadata protocol is empty. Do not infer
server producer completion from a lack of received DATA or the done flag alone.

Source clarification: the handoff's phrase "blockedunchanged" means still
blocked with unchanged payload offset/hash, not numerically fixed retry counters.
tcp.zig step_http2_stream invokes a pending producer without a stream-credit
guard, and pump_http2_streams retries armed producers after output drains.
Diagnostic responses may therefore increase actual attempts/blocked/pending/
invocations. Require positive pending/block observations at held barriers,
monotonic counters and source relationships; never exact callback counts across
requests. This resolves wording against the existing actual-counts contract.

The post-deinit verifier must match nonce-scoped H2_CAPACITY/H2_READY, optional
selected B binding marker, four output states (including unselected defaults),
32 body rows, totals and actual file close observation. Formatters are actual
fixture schema. File success requires one transport close and no deinit double
close, bounded spans; no exact read count or total under retries. Unselected file
is created in future main but remains caller-owned through post-deinit output,
then ordinary main cleanup. No claim of returned-error ownership proof from
these future success observations or Python doubles; separate evidence remains.

## Meaningful preparation proof and closure

Write behavioral pure integration tests first. Exercise actual public H2 action
pairing and source-shaped server bytes through the real wire+both ledgers+stage,
including initial ACK sequencing, incoming resets with unfinished uploads and
late refunds, final stage carrying old debt, hash-only binary completion and
at least the actual case functions with API doubles that reject bad grants,
ordering, metadata/binding or omitted barriers. Selected-subset models must use
actual fixture JSON field normalization and reject wrong counters/types/hashes.
No tests that merely mirror the implementation or reprove third-party internals.
Exercise new evidence validators against good and altered caller-owned evidence.
Run focused new checks normal and -O with raw commands/output/exits retained.

Create actual immutable new runtime/fixture/tool closure and validator using
the current two native receipts and source identities. Keep helper/codec/Python
loader/options/env and all actual direct/tree/runtime inputs bound; no blanket
ambient env capture/secret leakage. Validate actual files, not only hash maps.
Use old closure machinery as basis but replace its one-file fixture assumption.
Guard execution; pure preparation validation must not invoke native operations.
Normal and -O current-checker proof: accept unchanged; append one byte to an
actual OWNED driver input (not copied identity data), reject; restore exact bytes
and mode; accept. Preserve before/mutated/restored hashes, raw exits/logs and
actual changed path. Candidate aggregate encoding is Path-sorted JSONpairs with
default json.dumps separators, not string-sorted names or alternate encoding.
New caches, copied snapshots and outputs stay under /tmp; do not grow workspace
with binaries. Native files/source/old evidence remain untouched.

Deliver report at task-5d3-report.md with changed files, actual commands/raw
results/optimization modes, source hashes, bounded storage/work derivations,
subset accounting, source/Io ownership questions and self-review. Return DONE
only for complete source/preparation; otherwise identify concrete missing work.
No native five-case/full40/fullgate/M2 or original-goal completion claim. Root
reads actual work before a fresh independent source/preparation review and any
later exact ordinary-host release.
