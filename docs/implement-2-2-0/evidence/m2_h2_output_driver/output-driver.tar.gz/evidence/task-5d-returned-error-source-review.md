# Returned-error file ownership: source and retained evidence

Original output architect /root/architect_h2_output_acceptance performed a
read-only focused followup; Root independently read the cited current functions,
hashed actual files and decompressed the retained historical log. No imports,
builds, descriptor values or native execution. This is a source-bound review,
not a new returned-error runtime test.

## Exact identities and historical limits

M1 H2 source_manifest.json SHA256
e306653d623ff1301f0d139dc5a6b5fe98b6bc8d976574b8d98904b9c34bd796;
focused_green.log.gz SHA256
6d2f277a8ff43adfcb4f76b7e86737e8276835497b706463dee64fd1ea37a855.
Both are under docs/implement-2-2-0/evidence/m1_d_http2. Actual decompressed log
records11passes including tests4/5: forbidden framing/failed heads retain caller
descriptor, and occupied slot/in-flight head pressure refuse before ownership.
Test src/tests/file_stream_http2_tests.zig SHA256
2df876d373184b669dac42288c9fc4df69ee57f6c298d75d794f3ab052c86155
matches current candidate, but tested production tcp329a4ee5 and serverd1702fb7
differ from current. No historical result is relabeled as current execution.

Current candidate /tmp/uwz-task4d-fix1-frozen:
- src/http/response.zig 35c3a015d56e7a1cc1bc001dea93308d64bdd0449621a356debc06568c6c1f54
- src/core/tcp.zig fb387a01c7cb29f7aa312801c42991edaacd3733584328ee488361760864873f
- src/http2/server.zig 243a7768d8e4e1640b515bfa11824484bea0146b5fb28eb4ade3969969832b78

Post-accept file_transfer.zig matches older M1 H1 identity0e90ea2b..., but that
alone says nothing about the returned-error arming boundary. Earlier M1 final
752-test sanitizer result belongs to its original checkpoints, not currentfc69.

## Current control flow

Response.stream_file response.zig504: idle/body/status/header/source validation,
missing callback and header combination failures precede arming. The H2 callback
error propagates. Response.state becomes ended only on callback success; the
wrapper itself neither stores nor closes the descriptor. Application-supplied
custom callbacks must honor that contract; the wrapper cannot undo a callback
that consumes ownership then reports error.

begin_http2_file tcp.zig1080: closing/missing stream/occupied output/status/head
acceptance/stale stream returned errors precede assigning source to h2_files.
HEAD/empty success closes and returns success. Nonempty success stores ownership
before stepping its producer; a producer failure is internally torn down, not
returned as an arming failure. Defers manage existing write/borrow state.

Current fixture file_observer.zig64: stream_file catch increments arm_errors and
propagates before file=null/transferred=true. Caller descriptor remains present
on returned error; cleanup80 closes retained caller descriptor using base Io.
Reviewed/current and actual compiled fixture versions both hash
190a1d55918df0a7aeb3f8ff96e8816eab6dfe08cb8151aafc3b16e2858fd87d.
Close observer may execute inline during successful arming and does not require
the post-return transferred flag. Native success/range/hash/once-only close
remain to be observed by the separately reviewed driver.

## Disposition

Keep exact-current source review and historical tests as distinct evidence.
No new error/pressure/refusal/invalid-descriptor experiment is authorized or
needed by this source followup. A direct pure public stream_file invocation
requires std.Io.File; do not manufacture invalid/dummy/undefined descriptors or
present a token mock/reimplemented branch as executing that API. Source review
does not close a requirement for exact-current runtime returned-error evidence
if that requirement applies at final adoption. Generic native/full gates remain
unrun under the existing stop boundary. Next ordinary file-success proof, all
five output cases, actual full40 and full quality/platform/adoption remain open.
