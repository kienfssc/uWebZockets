# Task5d3 fix round1/5

Original requirements/ownership/stop boundary in task-5d3-driver-brief.md remain.
Fix only these independent review findings and breakage caused by the fixes.
No native/build/socket/SSLContext/cert/transfer-file/descriptor/error/resource/
fault/probe execution or oldlive/checker entrypoint. Same original implementer,
same report; Root owns scoped re-review and any later exact native release.

Verbatim independent findings:

1. **P1 — Reuse case expects an already-consumed stream ID.** cases.py:37 expects
   B on stream5. Afterhealth1 andA3, precedingbody-status/output-statusGETs consume
   streams5/7. RealadapteropensB9 thenraises upload stream identity at
   case_adapter.py:65. Everyselectioncontainingreuse abortsbeforeBbody. CorrectB
   expectedID andaddpure regression executingrealadapter/protocolallocation
   throughbothdiagnostics. Currenttest_cases.py:30 simplyreturnsrequestedID,
   maskingthedefect.
2. **P2 — Shared source-shaped SETTINGS fixture doesnotrepresentapprovedserver.**
   test_protocol.py:17 emitsIDs1/3/4/5/6; retainedserveremits1/2/3/6/8.
   Approvedtuple(4096,0,8,16384,1)inreviewedtest_client_core.py:176.
   Newadapter/setup/reset/finaltests bypassactualomittedINITIAL_WINDOW_SIZEpath
   andadvertisedifferentlimits. Replacepayloadwithapprovedtuple andretainfocused
   normal/-Oevidence. Preparationcoveragegap; differencedoesNOTprove runtime
   incompatibility.

Read actual task-5d3-review-v1.md and originalfullreport. Preserve current
v4runtime19/manifest1076902e andallv1-v3history. No edits to reviewedcore12,
fixturecurrent/compiled5, candidate/override, nativebinaries/receipts orpublic
archives. No new abstraction/scope/capacity/deadline/budget/exclusion changes.

Required proof:
- Actual RED beforefix forreuse usingrealcases.producer_reuse plusactual
  case_adapter/protocol andpublicH2codecallocation throughAandbothdiagnostics.
  Standard inert I/O/fixture-data doubles allowed. Merelyupdatingfakeexpected5
  to9 orreimplementingstreamallocation isinsufficient. Ifusinganintentional
  boundedteststop, itmustoccurAFTERactualadapteridentitycheck (e.g. afterBbody
  actionbecomesreachable), sooldwrongassertionfailsbeforeit; distinguishthis
  focusedallocationproof fromfullcasecompletion. No nativeoperations.
- Independentactualserializationcheck againstapprovedserverIDs/values (locate
  retainedserver1930-1942/currentclienttest175-177); retainREDoldhelper/GREENnew.
  Callthesharedhelper fromnewadapter/setup/reset/finalproof, notalternatesynthetic
  tuple. No runtimefailureclaimedjustbecauseoldshape differed.
- Runcoveringnewreusecheck andtest_cases.py, test_protocol.py, test_adapter.py,
  test_orchestration.py, test_reset.py, test_final.py, test_inert.py normaland-O
  withpinnedPython -B -S; additionaltestsonlyifaffectedbyactualfixes. Preserve
  exactcommands/rawstdout/stderr/exits. No rerununchangedwholecomponent/native
  suites. No authoredclasses/inheritance/Assert proofconditions.
- Newseparatelyversionedruntime/currentmanifest/checkertools. Actualsource
  accept/mutate/reject/restore inbothmodes. Preserveexactbytes/mode/sourcemaps,
  actualcompilecohort/binaryidentities andallnativeunchanged. No overwritingv4
  orpretendingtheoldsnapshottestednewsource.
- Appendfullfixreporttocurrenttask-5d3-report.md: findings, changedfiles, covering
  commands/rawresults, newsource/freezeidentity, unchangednative andlimitations.
  Returnshortstatus/context; Rootreadsactualreport/evidencebeforere-review.

RootFixBASE:717734c551144fa6970ac1303ba7bda16dc2b9be (newfilesignored),
actualpreviousreviewsource maptask-5d3-review-source.json andfulldiff.
Rootwillgenerateactualscopedfilediffversusreviewedsourcebytes, notHEAD~1.
Keepallwritesinsideoriginalownership/newtask5d3temp/report; nosubagents/commits.
