"""Replay the established body-App compiler graph against the assembled sources."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/workspaces/uWebZockets')
out = Path(__file__).resolve().parent
draft = root / '.uwz-work/drafts/m2-h1-baseline'
artifacts = Path('/tmp/uwz-m2-h1-baseline-output')
seed = json.loads((out / 'compiler-input-seed.json').read_text())
template = Path(seed['template'])
label, module, mode = sys.argv[1:4]
filters = sys.argv[4:]
argv = []
skip_next = False
for arg in json.loads(template.read_text())['argv']:
    if skip_next:
        skip_next = False
        continue
    if arg in ('--test-no-exec', '-fno-emit-bin') or arg.startswith('-femit-bin='):
        continue
    if arg in ('--cache-dir', '--global-cache-dir'):
        skip_next = True
        continue
    if arg.startswith('-O'):
        arg = '-O' + mode
    if arg.startswith('-Mroot='):
        argv.extend(['--dep', 'zslay'])
        arg = '-Mroot=' + module
    elif arg.startswith('-Mc='):
        arg = '-Mc=' + seed['binding_copy']
    elif arg.startswith('-Mxev_impl='):
        arg = '-Mxev_impl=' + seed['override']['path']
    elif arg.startswith('-Mzslay=zig-pkg/'):
        arg = '-Mzslay=' + str(root / arg.split('=', 1)[1])
    argv.append(arg)
argv.extend(['-j2', '--cache-dir', '/tmp/uwz-m2-h1-baseline-cache',
             '--global-cache-dir', '/tmp/uwz-m2-h1-baseline-global'])
for value in filters:
    argv.extend(['--test-filter', value])
argv.append('--test-no-exec')
argv.append('-fno-emit-bin' if label.startswith('central-') else '-femit-bin=' + str(artifacts / label))

def sources():
    paths = sorted(p for p in draft.rglob('*') if p.is_file())
    values = [(str(p.relative_to(draft)), hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths]
    return hashlib.sha256(json.dumps(values).encode()).hexdigest()

def inputs():
    result = {}
    for arg in argv:
        path = arg.split('=', 1)[1] if arg.startswith('-M') else arg if arg.endswith('.a') else None
        if path is None:
            continue
        p = Path(path)
        if not p.is_absolute():
            p = draft / p
        if p.is_file():
            result[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
    return result

env = os.environ.copy()
env['UWZ_TEST_XEV_BACKEND'] = 'io_uring'
record = {'argv': argv, 'cwd': str(draft), 'environment': {'UWZ_TEST_XEV_BACKEND': 'io_uring'},
          'template': str(template), 'source_before': sources(), 'input_before': inputs(),
          'override_provenance': seed['override'], 'coverage': 'compile only'}
path = out / (label + '.json')
path.write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
with (out / (label + '.log')).open('wb') as log:
    result = subprocess.run(argv, cwd=draft, env=env, stdout=log, stderr=subprocess.STDOUT)
record.update(exit_status=result.returncode, elapsed_seconds=time.monotonic() - started,
              source_after=sources(), input_after=inputs())
binary = artifacts / label
if binary.is_file():
    record['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
path.write_text(json.dumps(record, indent=2) + '\n')
print((out / (label + '.log')).read_text(), end='')
print('Exit status:', result.returncode)
raise SystemExit(result.returncode)
