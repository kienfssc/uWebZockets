"""Execute an already compiled, explicitly selected existing test suite."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

out = Path(__file__).resolve().parent
label = sys.argv[1]
compiled = json.loads((out / (label + '.json')).read_text())
assert compiled['exit_status'] == 0
assert not label.startswith('central-')
binary = Path('/tmp/uwz-m2-h1-baseline-output') / label
assert hashlib.sha256(binary.read_bytes()).hexdigest() == compiled['binary_sha256']
env = os.environ.copy()
env['UWZ_TEST_XEV_BACKEND'] = 'io_uring'
record = {'argv': [str(binary)], 'cwd': compiled['cwd'],
          'environment': {'UWZ_TEST_XEV_BACKEND': 'io_uring'},
          'binary_sha256': compiled['binary_sha256'], 'compiled_record': str(out / (label + '.json'))}
started = time.monotonic()
with (out / (label + '-run.log')).open('wb') as log:
    result = subprocess.run([str(binary)], cwd=compiled['cwd'], env=env, stdout=log, stderr=subprocess.STDOUT)
record.update(exit_status=result.returncode, elapsed_seconds=time.monotonic() - started)
(out / (label + '-run.json')).write_text(json.dumps(record, indent=2) + '\n')
print((out / (label + '-run.log')).read_text(), end='')
print('Exit status:', result.returncode)
raise SystemExit(result.returncode)
