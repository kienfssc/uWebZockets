# M2 mechanical H1 baseline assembly

This isolated successor is an assembly of reviewed preparation, not a live upload
implementation. It starts from the 1009 regular tracked inputs of Root
`3d6b6f9dd829e4da04b960033f9b44f3a1608960` (production source `3cc8f81`).
It contains no Git repository or copied ignored dependency/build caches.
The later Root documentation-only checkpoint `9ea9c7b` is recorded separately;
the copied authority remains `3d6b6f9` and was not recopied.
The tracked h1spec gitlink is recorded as source metadata rather than copied
as a nested working tree. Exact bytes, modes, mtimes and Git object identities
are recorded in `root-input-manifest.json`; the 102,641,031 input bytes were
copied without hardlinks.

## Authority and composition

The authoritative input map is
`../m2-baseline-authority/authority.md`. `merge-ledger.json` records the
31 changed/new files, their source authorities and SHA-256 identities.
`assembly.patch` is the direct Root-to-successor patch; Git status inside an
untracked child tree was not used as a private repository diff.

The final independently reviewed platform guard supplies loop, TCP, cold owner,
App/config, eligible-target tests and documentation. Reviewed R2 App supplies
router/builder and the supporting client/UDP deltas. Final H2 v6 supplies
server/width-safe connection logic; H3 v7 supplies stream logic and its inherited
engine wiring. The pure H1 admission helper remains unconnected.

Shared files are composed explicitly:

- Final-guard TCP additionally receives only App-to-H2 `header_fn` and
  `select_http2_headers` additions.
- Current Root core tests receive the final-guard `xev` import and five pure
  callback/setup cases. Removing the preserved Root wheel helper/regression
  from that result produces the final-guard file exactly.
- Current Root support receives only Admission's `http1_upload` declaration.
- Current Root central tests retain all 46 prior imports and add the six
  reviewed App/admission/H2/H3 test imports exactly once.
- Width/admission facades are compiler verification inputs, not new library
  exports. Native H2/H3 protocol-client fixtures were excluded.

`assembly-audit.json` confirms preservation of all 989 untouched regular Root
files, the eight later Root additions, all multipart integrations, parser,
Request, decoder/common body state, corrected timer wheel, fuzz, and package
consumer paths. All four zon views and `src/root.zig` retain Root bytes.

## Verification scope

`verify.py` replays the existing body-App compiler graph with the selected
module/test filters against the successor. Every compile uses `--test-no-exec`;
the full central graph additionally uses `-fno-emit-bin`. Generated C bindings,
binaries, LLVM IR and compiler caches live under task-specific `/tmp` paths.
The sole explicit dependency test override is the immutable reviewed 93-file
libxev export `c223bd886c6a51d2cd60def39dd9a68d701fea73`, tree
`86c6944f53dc009d7503a9ab0bc873aef3cd7b79`. Production pins remain unchanged.
`compiler-input-seed.json` records the source compiler graph and binding copy.
Each check records argv, cwd, input/source hashes, exit status, raw output and,
when emitted, binary hash. `run.py` checks that hash before selected execution.

The initial unfiltered central compile is retained in
`central-ReleaseSafe.{json,log}`. Its graph lacked direct root `zslay` access;
adding the existing dependency to the replay graph resolved that graph error.
`central-with-zslay-ReleaseSafe` then isolated the existing exact default-slab
assertion as the remaining compile failure. Pure compile-time layout replay
on native/macOS/Windows recorded the combined layout in `layout-values.json`
and corresponding per-target records. Root approved a mechanical repair of
only the three exact expected totals: Linux 684,177,024; macOS 684,095,104;
Windows 684,676,736. Each increases by precisely 16,384 bytes for 1,024
connections: 8 R2 bytes and 8 H2 bytes per connection.
`layout-expectation-repair.patch` preserves the exact correction and comment.
No capacity, policy, tolerance, threshold or assertion was weakened.
The final full unfiltered central ReleaseSafe graph compiled successfully
without emitting or executing a binary (`central-final-ReleaseSafe.json`).

Final selected execution passed in both Debug and ReleaseSafe:

| Existing selected suite | Tests per mode | Evidence prefix |
| --- | ---: | --- |
| Pure central policy selection | 134 | `pure-policy` |
| Buffered chunk-decoder compatibility | 5 | `decoder-compat` |
| Healthy body-App startup/registry | 17 | `body-app` |
| Unchanged HTTP/2 server | 69 | `http2-legacy` |
| Unchanged QUIC | 35 | `quic-legacy` |

The 134-case selection contains 22 multipart parser, one 100,000,000-logical-byte
multipart case, 19 multipart sink, eight streaming-request, 21 common-body,
20 H0 head/decoder, seven H1 admission, 15 H2 refusal plus one width,
12 H3 refusal plus one width, five callback/setup and one timer-overflow,
and one config-setup case. These are existing pure policy tests, not a native
cancellation probe or a network upload claim. The unchanged healthy suites
ran with ordinary OS access and the existing `UWZ_TEST_XEV_BACKEND=io_uring`
assertion. No existing native fault suite was executed.

`verification-summary.json` binds all ten selected executions (520 tests in
total), their binaries and compiler inputs to the final frozen source
fingerprint `2795e885505248822125ef5ae5a1d695aaf557cb040040fb23c1bad74ec43e3f`.
`frozen-source-manifest.json` records all 1020 regular files at mode0444.
All frozen bytes and protected current Root source/pin bytes remained unchanged
after verification. The sole runtime-only `.zig-cache` symlink points to
`/tmp/uwz-m2-h1-baseline-output/runtime-cache`.

The required formatting, convention and release checks passed after the exact
layout repair: `zig fmt src builds examples tests fuzz`,
`sh scripts/check_conventions.sh`, and `sh scripts/check_release_version.sh`.
The existing convention script scanned all 176 source files in the isolated
tree. `graphify update .` passed with local AST extraction (12,949 nodes,
16,016 edges); its temporary output symlink directed generated graph files
under task-specific `/tmp` and was removed afterward. Root's graph was untouched.
All large generated outputs and caches remain outside the baseline source.

No full Root runtime, sanitizer, fuzz iteration, interoperability or release
claim is made. The stopped native fault experiment was not reconstructed or
executed. Native accept-failure, invalid-descriptor, injected-completion and
other fault cases remain compile-only. This work adds no lifecycle behavior,
actual H1 consumer, TLS hooks, cold-owner v3/retirement design or new API.

## Review and delivery

Root confirmed the independent frozen composition review completed with no
actionable findings and all source/evidence identities bound. No source changed
after that review. `summary.json` is the terminal handoff; it explicitly includes
the five decoder-compatibility add-on tests per mode (520 selected tests total).

The root agent owns archival reporting under
`docs/implement-2-2-0`, later lifecycle implementation, full combined gates,
immutable dependency adoption, staging, commits and pushes. This child makes
no Root edits, dependency fetches/patches, commits, references or publication.
The assembled preparation must remain isolated until the actual H1 consumer,
H2/H3 integration and dependency/release gates are ready.
