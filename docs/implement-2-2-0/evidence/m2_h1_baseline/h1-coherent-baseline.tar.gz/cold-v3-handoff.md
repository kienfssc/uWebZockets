# Cold-v3 data-only handoff

Architect /root/architect_iocp_cancel_result, read-only handoff after confirmed
BSD setup restriction. No builds, edits or probes by architect. Authoritative
plan: .uwz-work/evidence/h1-transport/r3/h1-head-driver-seam.md, receipt
c9dc98bddf82c834125dbddc8f4e44b8259c323eec76976c172ada04510f863a.
Activation precondition: eligible-retirement-contract.md. Root independently
reviews the coherent baseline before this next developer slice begins.

Own a NEW isolated successor, never edit frozen baseline/currentRoot. Paths:
core/http1_upload.zig named accepted head contracts (reuse IngressBounds);
core/http1_upload_storage.zig optional HeadTarget, delivery_active false,
pending_payload zero, CallbackPhase.admission appended. Test support only if
storage import needed; focused pure tests in existing centralized body_app_tests.
Preserve admission helpers/ArmError, inline two completions and timer.
No resolver invocation/binding, sink/TCP callbacks, scheduling or close code.
No config arithmetic, decoder or multipart edits. Production target stays null.

Drain rejects delivery_active and admission. Drained reset preserves head_target,
loop_handle, body generation, timer and completion contents; clears pending_payload
with per-request cursors/metadata. No second reservation flag; payload is accounting.
Write actual pure red tests for drain and reset before the delta, then green.
Inert caller-owned memory only; no native loop/timer scheduling, injection, faults,
cancellation/race/crash/leak/invalid descriptor/resource exhaustion probe.
Preservation needs source and content checks, not only address comparisons.

Record before/after size/alignment/offsets and enabled+disabled slabs on Linux,
macOS and Windows. Disabled totals equal coherent baseline, including existing
+16 bytes/connection R2+H2 footprint. Derive enabled growth from measurements.
Run focused pure tests, unchanged healthy and eligible foreign compilation.
Bind exact before/after hashes, complete argv, outcomes and preserved failures.
All binaries/cache/large generated artifacts under /tmp; do not alter pins.
Independent review required after implementation.

Existing cold owner is the earned seam: removing it would scatter target,
delivery pins and retained-prefix accounting into hot TCP/callback storage.
No additional abstraction is justified. Root owns production integration/git.
