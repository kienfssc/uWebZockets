const body = @import("../http/request_body.zig");
const decoder = @import("../http/body_decoder.zig");
const radix = @import("../router/radix.zig");

/// Physical tail capacity and the chunk-line content bound excluding CRLF.
pub const IngressBounds = struct {
    capacity: usize,
    line_content_limit: usize,
};

/// Existing admission/state errors, including an inconsistent rollback owner.
pub const ArmError = radix.BodyAdmissionError || body.BodyStateError || error{BodyAdmissionMissing};

/// Validates retained storage without narrowing a logical wire body length.
pub fn ingress_bounds(
    storage_capacity: usize,
    head_end: usize,
    framing: decoder.Framing,
    header_limit: usize,
) ?IngressBounds {
    if (head_end > storage_capacity) return null;
    const capacity = storage_capacity - head_end;
    const required: usize = switch (framing) {
        .none => 0,
        .content_length => |length| @intFromBool(length != 0),
        .chunked => 3,
    };
    if (capacity < required) return null;
    const line_content_limit = @min(header_limit, capacity -| 2);
    if (framing == .chunked and line_content_limit == 0) return null;
    return .{ .capacity = capacity, .line_content_limit = line_content_limit };
}

/// Transfers one router reservation to common state without callbacks or I/O.
/// Router, route definition and state must stay stable on the owning loop.
/// After success, only BodyState's terminal/reject booleans authorize release.
pub fn reserve_and_arm(
    router: *radix.Router,
    selected: radix.BodyMatch,
    state: *body.BodyState,
    target: body.BodyControlTarget,
    declared: ?u64,
) ArmError!body.BodyControl {
    if (state.phase != .inactive or state.reserved) return error.BodyStateBusy;
    try router.reserve_body_route(selected);
    return state.arm(target, selected.definition.limits, declared) catch |err| {
        // No callback can intervene: this reservation never entered BodyState.
        try router.release_body_route(selected.record_index);
        return err;
    };
}
