const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const stream = support.quic_stream;
const body = support.request_body;
const radix = support.radix;
const RouterBundle = radix.Bundle(.{ .stream_request_bodies = true });

const Sink = struct {
    fn begin(_: *anyopaque, _: *const support.streaming_request.StreamingRequest, _: body.BodyControl) !body.BodyBinding {
        return error.UnexpectedSinkCall;
    }
    fn chunk(_: *anyopaque, _: []const u8) !body.BodyProgress {
        return error.UnexpectedSinkCall;
    }
    fn end(_: *anyopaque, _: *const support.streaming_request.StreamingRequest, _: *support.http_response.Response) !void {
        return error.UnexpectedSinkCall;
    }
    fn cancel(_: *anyopaque, _: body.BodyCancelReason) void {
        @panic("header selection cannot call a sink");
    }
};

const WidthCase = struct {
    length: []const u8,
    path: []const u8 = "/upload",
    standalone: bool = false,
    duplicate: bool = false,
    field_ok: bool = true,
    finish_ok: bool = true,
};

fn release(_: *anyopaque, _: *stream.HeaderSet) void {}

fn add(headers: *stream.HeaderSet, name: []const u8, value: []const u8) bool {
    const offset = headers.write_offset;
    if (name.len + value.len > headers.storage.len - offset) return false;
    @memcpy(headers.storage[offset..][0..name.len], name);
    @memcpy(headers.storage[offset + name.len ..][0..value.len], value);
    headers.decoded = std.mem.zeroes(c.struct_uz_lsxpack_header);
    headers.decoded.buf = @ptrCast(headers.storage.ptr);
    headers.decoded.name_offset = @intCast(offset);
    headers.decoded.name_len = @intCast(name.len);
    headers.decoded.val_offset = @intCast(offset + name.len);
    headers.decoded.val_len = @intCast(value.len);
    return headers.process_header(@ptrCast(&headers.decoded));
}

test "body H3: wide wire length and legacy usize field remain compatible" {
    const cases = [_]WidthCase{
        .{ .length = "0" },
        .{ .length = "4" },
        .{ .length = "4294967296" },
        .{ .length = "18446744073709551615" },
        .{ .length = "18446744073709551616", .field_ok = false },
        .{ .length = "4294967296", .duplicate = true },
        .{ .length = "4294967296", .path = "/buffered", .finish_ok = false },
        .{ .length = "4294967296", .standalone = true, .field_ok = false },
    };
    var bundle = RouterBundle{};
    var router = try radix.Router.init(bundle.storage());
    var context: u8 = 0;
    const definition = body.BodyRoute{
        .sink = .{ .context = &context, .begin = Sink.begin, .chunk = Sink.chunk, .end = Sink.end, .cancel = Sink.cancel },
        .limits = .{ .max_body_bytes = std.math.maxInt(u64), .max_active = 1 },
    };
    try router.route_body(.post, "/upload", &definition);
    for (cases) |case| {
        var storage: [1024]u8 = undefined;
        var headers = stream.HeaderSet{};
        headers.reset(&context, release, &storage, &.{}, &.{}, .{ .request_body_size = 8 });
        headers.router = if (case.standalone) null else &router;
        try std.testing.expect(add(&headers, ":method", "POST"));
        try std.testing.expect(add(&headers, ":scheme", "https"));
        try std.testing.expect(add(&headers, ":authority", "localhost"));
        try std.testing.expect(add(&headers, ":path", case.path));
        try std.testing.expectEqual(case.field_ok, add(&headers, "content-length", case.length));
        if (!case.field_ok) continue;
        const wire = try std.fmt.parseUnsigned(u64, case.length, 10);
        try std.testing.expectEqual(wire, headers.declared_content_length.?);
        const legacy: ?usize = headers.content_length;
        try std.testing.expectEqual(std.math.cast(usize, wire), legacy);
        if (case.duplicate) {
            try std.testing.expect(!add(&headers, "content-length", case.length));
            continue;
        }
        try std.testing.expectEqual(case.finish_ok, headers.process_header(null));
        if (case.finish_ok) try std.testing.expectEqualStrings("unavailable", @tagName(headers.body_route));
    }
}
