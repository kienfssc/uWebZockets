const std = @import("std");
const support = @import("test_support");
const upload = support.http1_upload;
const radix = support.radix;
const body = support.request_body;
const RouterBundle = radix.Bundle(.{ .stream_request_bodies = true });

const Fixture = struct {
    bundle: RouterBundle = .{},
    router: radix.Router = .{},
    definition: body.BodyRoute = undefined,
    callbacks: usize = 0,

    fn init(self: *Fixture) !void {
        self.router = try radix.Router.init(self.bundle.storage());
        self.definition = .{
            .sink = .{ .context = self, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel_sink },
            .limits = .{ .max_body_bytes = 8, .max_active = 2 },
        };
        try self.router.route_body(.post, "/upload", &self.definition);
    }

    fn selected(self: *Fixture) radix.BodyMatch {
        return self.router.match("/upload", .post).?.body_match.?;
    }

    fn target(self: *Fixture) body.BodyControlTarget {
        return .{ .context = self, .resume_fn = resume_delivery, .cancel_fn = cancel };
    }

    fn begin(context: *anyopaque, _: *const support.streaming_request.StreamingRequest, _: body.BodyControl) !body.BodyBinding {
        const self: *Fixture = @ptrCast(@alignCast(context));
        self.callbacks += 1;
        return .{ .context = self };
    }

    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
        const self: *Fixture = @ptrCast(@alignCast(context));
        self.callbacks += 1;
        return .{ .consumed = bytes.len, .readiness = .ready };
    }

    fn end(context: *anyopaque, _: *const support.streaming_request.StreamingRequest, _: *support.http_response.Response) !void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        self.callbacks += 1;
    }

    fn cancel(context: *anyopaque) void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        self.callbacks += 1;
    }

    fn cancel_sink(context: *anyopaque, _: body.BodyCancelReason) void {
        cancel(context);
    }

    fn resume_delivery(context: *anyopaque) error{BodyDeliveryFailed}!void {
        cancel(context);
    }
};

test "H1 admission: fixed ingress bounds do not narrow logical lengths" {
    try std.testing.expect(upload.ingress_bounds(3, 4, .none, 16) == null);
    try std.testing.expectEqual(@as(usize, 0), upload.ingress_bounds(4, 4, .none, 16).?.capacity);
    try std.testing.expectEqual(@as(usize, 0), upload.ingress_bounds(4, 4, .{ .content_length = 0 }, 16).?.capacity);
    try std.testing.expect(upload.ingress_bounds(4, 4, .{ .content_length = 1 }, 16) == null);
    const bounds = upload.ingress_bounds(5, 4, .{ .content_length = std.math.maxInt(u64) }, 16).?;
    try std.testing.expectEqual(@as(usize, 1), bounds.capacity);
    try std.testing.expectEqual(@as(usize, 0), bounds.line_content_limit);
}

test "H1 admission: chunked ingress reserves delimiters with checked width" {
    try std.testing.expect(upload.ingress_bounds(6, 4, .chunked, 16) == null);
    try std.testing.expect(upload.ingress_bounds(7, 4, .chunked, 0) == null);
    const small = upload.ingress_bounds(7, 4, .chunked, 16).?;
    try std.testing.expectEqual(@as(usize, 3), small.capacity);
    try std.testing.expectEqual(@as(usize, 1), small.line_content_limit);
    const large = upload.ingress_bounds(std.math.maxInt(usize), 0, .chunked, std.math.maxInt(usize)).?;
    try std.testing.expectEqual(std.math.maxInt(usize) - 2, large.line_content_limit);
    try std.testing.expectEqual(@as(usize, 16), upload.ingress_bounds(128, 0, .chunked, 16).?.line_content_limit);
}

test "H1 admission: arm transfers one real router reservation without callbacks" {
    var fixture = Fixture{};
    try fixture.init();
    const selected = fixture.selected();
    var state = body.BodyState{};
    const control = try upload.reserve_and_arm(&fixture.router, selected, &state, fixture.target(), 4);
    try std.testing.expectEqual(@as(u16, 1), fixture.router.body.active[selected.record_index]);
    try std.testing.expect(state.reserved);
    try std.testing.expectEqual(body.BodyPhase.begin, state.phase);
    try std.testing.expectEqual(@as(?u64, 4), state.declared);
    try std.testing.expectEqual(@as(usize, 0), fixture.callbacks);
    try std.testing.expectError(error.BodyCallbackActive, control.cancel());
    try std.testing.expect(state.reject_begin());
    try fixture.router.release_body_route(selected.record_index);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[selected.record_index]);
    try std.testing.expectError(error.BodyControlExpired, control.cancel());
}

test "H1 admission: failed arm preserves a different outstanding reservation" {
    var fixture = Fixture{};
    try fixture.init();
    const selected = fixture.selected();
    try fixture.router.reserve_body_route(selected);
    var state = body.BodyState{ .generation = 99 };
    const before = state;
    try std.testing.expectError(error.BodyTooLarge, upload.reserve_and_arm(&fixture.router, selected, &state, fixture.target(), 9));
    try std.testing.expectEqualDeep(before, state);
    try std.testing.expectEqual(@as(u16, 1), fixture.router.body.active[selected.record_index]);
    try std.testing.expectEqual(@as(usize, 0), fixture.callbacks);
    try fixture.router.release_body_route(selected.record_index);
}

test "H1 admission: full quota and stale route leave common state untouched" {
    var fixture = Fixture{};
    try fixture.init();
    const selected = fixture.selected();
    try fixture.router.reserve_body_route(selected);
    try fixture.router.reserve_body_route(selected);
    var state = body.BodyState{ .generation = 17 };
    const before = state;
    try std.testing.expectError(error.BodyAdmissionFull, upload.reserve_and_arm(&fixture.router, selected, &state, fixture.target(), 0));
    var invalid = selected;
    invalid.record_index = std.math.maxInt(u16);
    try std.testing.expectError(error.InvalidBodyRoute, upload.reserve_and_arm(&fixture.router, invalid, &state, fixture.target(), 0));
    try std.testing.expectEqualDeep(before, state);
    try std.testing.expectEqual(@as(u16, 2), fixture.router.body.active[selected.record_index]);
    try std.testing.expectEqual(@as(usize, 0), fixture.callbacks);
    try fixture.router.release_body_route(selected.record_index);
    try fixture.router.release_body_route(selected.record_index);
}

test "H1 admission: busy or already reserved state cannot acquire a second slot" {
    var fixture = Fixture{};
    try fixture.init();
    const selected = fixture.selected();
    const phases = [_]body.BodyPhase{ .begin, .active, .chunk, .terminal };
    for (phases) |phase| {
        var state = body.BodyState{ .phase = phase, .generation = 23 };
        const before = state;
        try std.testing.expectError(error.BodyStateBusy, upload.reserve_and_arm(&fixture.router, selected, &state, fixture.target(), 0));
        try std.testing.expectEqualDeep(before, state);
    }
    var reserved = body.BodyState{ .reserved = true };
    try std.testing.expectError(error.BodyStateBusy, upload.reserve_and_arm(&fixture.router, selected, &reserved, fixture.target(), 0));
    try std.testing.expect(reserved.reserved);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[selected.record_index]);
}

test "H1 admission: terminal result remains the sole once-only release authority" {
    var fixture = Fixture{};
    try fixture.init();
    const selected = fixture.selected();
    var state = body.BodyState{};
    const control = try upload.reserve_and_arm(&fixture.router, selected, &state, fixture.target(), 0);
    try std.testing.expect(state.accept_begin(.{ .context = &fixture }) == null);
    const terminal = try state.take_end(true, 0);
    try std.testing.expectEqual(@as(*anyopaque, &fixture), terminal.end.context);
    try std.testing.expectError(error.BodyControlExpired, control.cancel());
    try std.testing.expectEqual(@as(u16, 1), fixture.router.body.active[selected.record_index]);
    if (state.finish_terminal()) try fixture.router.release_body_route(selected.record_index);
    try std.testing.expect(!state.finish_terminal());
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[selected.record_index]);
    try std.testing.expectEqual(@as(usize, 0), fixture.callbacks);
}
