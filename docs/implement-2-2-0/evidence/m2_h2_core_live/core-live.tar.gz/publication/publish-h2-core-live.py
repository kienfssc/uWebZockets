import gzip
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path, PurePosixPath

repo = Path('/workspaces/uWebZockets')
core = repo / '.uwz-work/evidence/h2-streaming/integration-owned/core'
output = repo / 'docs/implement-2-2-0/evidence/m2_h2_core_live'
output.mkdir(parents=True, exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
audit = json.loads((core / 'stage-b/root-result-audit.json').read_text())
assert audit['checks_passed'] and audit['postrun_preflight_identical']
assert audit['child_exit_zero_reaped'] and audit['key_absent']
assert len(audit['cases_passed']) == 5
members = {}


def add(name, path):
    assert name not in members and '..' not in PurePosixPath(name).parts
    assert not PurePosixPath(name).is_absolute() and path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    assert not data.startswith(b'\x7fELF'), name
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[0-9A-Z]{16}', data), name
    members[name] = data


for path in sorted(core.rglob('*')):
    if path.is_file():
        add('evidence/' + path.relative_to(core).as_posix(), path)
for label, root in [('v2', Path('/tmp/uwz-task5a-source-frozen-v2')),
                    ('final', Path('/tmp/uwz-task5a-fix1-frozen'))]:
    for path in sorted(root.iterdir()):
        add('fixture/' + label + '/' + path.name, path)
for name in ['task-5-plan.md', 'task-5a-brief.md', 'task-5a-report.md',
             'task-5a-fix-1-brief.md', 'task-5a-stage-b-report.md']:
    add('reports/' + name, repo / '.superpowers/sdd/h2_streaming_plan' / name)
add('reports/component.md', repo / 'docs/implement-2-2-0/m2_h2_core_live.md')
add('inputs/h2_client.py', repo / '.uwz-work/evidence/h2-streaming/integration-client/h2_client.py')
add('inputs/immutable-libxev-input.json', repo / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json')
add('publication/publish-h2-core-live.py', Path(__file__).resolve())
inventory = [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())]
members['inventory.json'] = (json.dumps({'binding': 'Publication-time bytes; individual records retain their actual source/run identities.', 'files': inventory}, indent=2) + '\n').encode()
archive = output / 'core-live.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    entries = tar.getmembers()
    assert len(entries) == len(members) == len({x.name for x in entries})
    for entry in entries:
        assert entry.isfile() and not PurePosixPath(entry.name).is_absolute() and '..' not in PurePosixPath(entry.name).parts
        assert tar.extractfile(entry).read() == members[entry.name]
case_data = json.loads((Path('/tmp/uwz-task5a-fix1-frozen') / 'case_manifest.json').read_text())
manifest = {'scope': 'One owned Linux ReleaseSafe core H2/TLS acceptance run; broader matrix and production adoption remain open.',
            'source_digest': audit['source_digest'], 'source_files': 1031,
            'source_checkpoint': '../m2_h2_native_tcp/README.md',
            'archive': archive.name, 'archive_sha256': sha(archive.read_bytes()),
            'archive_bytes': archive.stat().st_size, 'safe_regular_members': len(members),
            'inventory_entries': len(inventory), 'binary_sha256': audit['binary_sha256'],
            'review_manifest_sha256': sha((core / 'fix1/review-manifest.json').read_bytes()),
            'preflight_audit_sha256': audit['preflight_sha256'],
            'authorization_sha256': sha((core / 'fix1/stage-b-authorization.json').read_bytes()),
            'result_sha256': sha((core / 'stage-b/result.json').read_bytes()),
            'root_result_audit_sha256': sha((core / 'stage-b/root-result-audit.json').read_bytes()),
            'cases_passed': audit['cases_passed'], 'planned_unimplemented': case_data['planned_unimplemented'],
            'tls': 'TLS1.3 / h2', 'runtime_mode': 'ReleaseSafe', 'exit_status': 0,
            'runtime_retries': 0, 'child_exit_zero_reaped': True, 'private_key_removed': True,
            'remaining': ['All Task5b/5c cases and the combined H2 matrix', 'H3, multipart transport and genuine early data',
                          'Full native, sanitizer, compliance, physical lifecycle and platform gates',
                          'Maintained publication, production adoption and complete original milestones']}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(output / 'README.md').write_text(f'''# Core owned HTTP/2 request-streaming evidence

The [archive](core-live.tar.gz) preserves the reviewed fixture and bounded client,
original v2 and fix-round-1 sources, exact build/input inventories, retained codec
red/green, both independent reviews, Root identity audit and precise authorization,
executed command, raw run result/server log/public certificate and result audit.
All {len(members)} members are safe regular files; {len(inventory)} inventory entries verify.
No private key or compiled executable is included.

Archive SHA-256: `{manifest['archive_sha256']}` ({manifest['archive_bytes']} bytes).
See the [manifest](manifest.json) and [component report](../../m2_h2_core_live.md).

All five selected cases pass in one owned Linux ReleaseSafe run over TLS1.3/h2:
buffered compatibility, ordinary async response, declared and undeclared actual
100000000-byte uploads, and normal idle shutdown. Each upload has matching
independent client/server SHA-256
`190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2`,
begin/end/cancel1/1/0 and maximum offered span8192. The owned child exits0 and is
reaped, no forced cleanup or retry occurs, and the private key is removed.

Candidate source is the exact1031-file
`{manifest['source_digest']}` from the
[native composition checkpoint](../m2_h2_native_tcp/README.md); that checkpoint
supplies the cumulative source patch and reconstruction evidence. Use the pinned
[client tooling](../m2_h2_client/README.md), reviewed c223 override, C bindings
and static-library inputs whose complete identities are retained in this archive.
The prior source is unchanged; the core package adds test-only files. The exact
compiler argv, executable identities, runner argv/environment and absolute input
paths are in `evidence/*final*.json` and `evidence/fix1/stage-b-authorization.json`.
Source identity must be re-established before any new execution; archived
authorization describes this completed run, not arbitrary future runs.

Debug and ReleaseSafe compile successfully; only ReleaseSafe is run. Offline
checks establish codec and helper behavior; the live run separately establishes
the listed five cases. Raw reset detection covers bytes observed, not future
unread resets. Source/capacity bounds are not RSS, leak or native safety evidence.

All {len(case_data['planned_unimplemented'])} further planned cases remain open, including pause/credit/limits/quota,
metadata/control, producer/file/pressure/reuse, cancellation/error/disconnect,
active shutdown and the combined matrix. H3, multipart transport, genuine early
data, full quality/platform gates, maintained publication, production adoption
and complete M2 remain open. Stopped experiments were not resumed.
''')
print(json.dumps({k: manifest[k] for k in ['archive_sha256', 'archive_bytes', 'safe_regular_members', 'inventory_entries', 'result_sha256', 'root_result_audit_sha256']}, indent=2))
