# Task 5a Stage A preparation

The five-case source package is prepared for independent Root review, not live
execution. No fixture binary, client, server, helper self-check, certificate
command, constructor or socket was executed. Compilation is not evidence of
runtime correctness, native lifetime, or M2 completion. Root must separately
review the frozen sources and authorize the precise Stage B run.

The frozen package is `/tmp/uwz-task5a-source-frozen-v2`; the working sources,
commands, full source/client/override inventories, build records and logs are in
`.uwz-work/evidence/h2-streaming/integration-owned/core/`. The review manifest
`core/review-manifest.json` has SHA-256
`9735f7f0818e69471751edb1db89e0c8b903ff6374678394e23334bfc71e0d13`.
It binds the frozen package, both binaries, 1031-file candidate, 42-file client,
93-file override, zslay inventory, original bindings, six static libraries,
compiler, Python, OpenSSL, ELF interpreter and unchanged helper. It is a review
input, not evidence that review or Stage B authorization occurred.

Frozen SHA-256 identities:

| File | SHA-256 |
| --- | --- |
| profile.zig | `65072ddd66c74ea1593d0af3b234a899711a68d33bd8caf1bcf49fe909ce5217` |
| run_live.py | `08a9f06ef740f3da8a6c70f8509e468cd41886d7dcd2e3b68a6732afe5132006` |
| wire.py | `645a7f37d9419c77973588dc5af3a0002e3d787c26833462eb85663ee9a9811f` |
| prepare.py | `3d944c3f70e123386177b070230df2b09a16f10184b9ded272de95a5bb25829e` |
| case_manifest.json | `c9729f100bfe209dcf99f246d1bba8479b98797de420694701df5f3f80688bbe` |

`core/freeze-command.txt` records the offline identity procedure. Its raw output:

```
source files: 1031 sha256: fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de
client files: 42 sha256: 0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473
override files: 93
manifest sha256: 9735f7f0818e69471751edb1db89e0c8b903ff6374678394e23334bfc71e0d13
```

The independent helper is unchanged at SHA-256
`07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`.
The original r2 bindings and maintained c223 override remain inputs, not edits.
The ELF interpreter reported by `readelf -l` for the fixture, Python and
OpenSSL is `/lib64/ld-linux-x86-64.so.2`; its bytes are bound in the manifest.
The runner starts its child with an explicit three-variable environment and
records Python module paths and executable identities.

Final fixture builds used the fixed Zig 0.16 compiler, `-j2`, isolated `/tmp`
outputs and caches. Exact compiler argv and hashed inputs are in
`core/debug-final.command.json` and `core/release-final.command.json`.

```
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/core/prepare.py --optimization Debug --output /tmp/uwz-task5a-debug-final --cache-root /tmp/uwz-task5a-debug --record debug-final
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/core/prepare.py --optimization ReleaseSafe --output /tmp/uwz-task5a-release-final --cache-root /tmp/uwz-task5a-release --record release-final
```

Raw output for each: `Exit status: 0`. Both compiler logs are empty, SHA-256
`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.
Each record reports `inputs_unchanged: true` and source digest before and after
`fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`.
The Debug binary SHA-256 is
`5d884619e31222c2fb5f76d949cf673ec315e28be5512d46ad93d8fa3e6987c5`;
the ReleaseSafe binary SHA-256 is
`d30cc8ab210d8b934e42c0bdafbc6d2fd5926eaa4bd0f17b924e7332c2c64fdc`.
Neither was run. The runner binds the ReleaseSafe binary.

Syntax-only check of the exact frozen Python source, without imports or execution:

```
/home/codespace/.python/current/bin/python3 -B -c 'import ast,pathlib; r=pathlib.Path("/tmp/uwz-task5a-source-frozen-v2"); [ast.parse((r/f).read_text(),filename=f) for f in ("prepare.py","run_live.py","wire.py")]; print("frozen syntax OK")'
```

Raw output: `frozen syntax OK`.

An intentional compiler diagnostic of a separate derived temporary file records
the full configuration and calculated layout in `core/capacity.log` and its
exact argv in `core/capacity-command.json`. Raw outcome: `diagnostic exit status:
1`, specifically `error: found compile log statement`; this is not a successful
build. Its output records request stride 5888, H2 session bytes and aligned
stride 281200, slab 4098304, router storage 884352. The full default and explicit
config is retained in that log; notably 8 connections, streaming enabled,
request line 512, headers 4096/count 80, H1 body 256, H2 body 4096, encoded
headers 8192, H2 response headers 4096/count 32, captures 24, write queue 65536,
and development log disabled. The log SHA-256 is
`d677eadf0524e93cd3e4a8751b0a4e038eae1ed072fb04a36c3e111bcf096fa5`.

The fixture uses `Server.preset(...).build_https`, a public body route with a
100000000-byte limit and quota two, two stable caller-owned slots, public
buffered routes and `get_async`. The sink incrementally hashes accepted bytes,
records each tag, begin/end/cancel counts and maximum offered span, and produces
bounded JSON. The profile emits the effective configuration and computed slab
values, a nonce marker after listen and signal watcher installation, and a
post-deinit marker with both active flags.

The prepared assertions cover:

- `ready_buffered`: live TLS 1.3 and h2, owned certificate identity, health
  `200/ok`, exact 257-byte buffered echo with independent SHA, and unchanged
  sink counts.
- `async_delayed`: request HEADERS end the stream; exact `200`, text/plain,
  10-byte `delayed-ok`, normal end and no reset.
- `large_declared` and `large_undeclared`: unchanged helper generates exactly
  100000000 bytes in at most 8192-byte blocks, with or without Content-Length;
  independent client hash and server accepted count/hash must match
  `190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2`,
  with exact tag and begin/end/cancel `1/1/0`, bounded complete JSON, and
  aggregate slot recovery.
- `shutdown_idle`: all responses complete, no active slot or client stream,
  direct owned child gets SIGTERM, exits zero and is reaped, and its nonce and
  inactive post-deinit marker are present.

The wrapper limits reads and generated spans to 8192, retains at most eight
response records, bounds final/trailer fields at 32 and 4096 header bytes,
limits informational responses to 16 and 16384 aggregate bytes, bounds body
capture per response to its expected maximum, aggregates up to 64 event types,
and fails on reset, connection termination, premature EOF or excess body.
The complete planned matrix remains listed as unimplemented in the case manifest;
unsupported case names fail argument parsing. These are source assertions only;
none has been observed live.

The explicit `--run` entry requires the manifest SHA-256, exact absolute Python
with `-B -S`, exact client/helper PYTHONPATH, a fresh absolute `/tmp` output path,
and a selected case list ending in `shutdown_idle`. Its guard hashes all listed
files and compares exact tree inventories before importing client modules or
creating output. If separately authorized, it generates ephemeral localhost
material in a private run directory, records direct child PID/start identity and
owned loopback listener inode, checks nonce, TLS/ALPN and certificate fingerprint
before health, applies monotonic readiness/ordinary/upload/overall/graceful
limits of 15/30/180/900/15 seconds, and records results. It closes the client,
reaps its direct child, deletes the private key, and marks forced cleanup or any
setup/terminal failure unsuccessful. The runner has not been executed or
independently reviewed; this description is an implementation claim to review,
not observed behavior.

Remaining ordered work includes all Task 5b and 5c cases, the full combined
matrix, and other M2 gates. Idle shutdown does not substitute for active shutdown;
no quota, pause, credit, metadata, pressure, reset, lifecycle or platform claim
is established by this preparation.

## Fix round 1: offline verifier corrections, awaiting re-review

The preceding Stage A report and frozen v2 package are preserved; its report
preimage is `core/fix1/task-5a-report-preimage.md`. No Stage B execution was
performed or authorized. The fix changes test-only runner/wire code, adds an
offline check, and keeps the same cases and planned full matrix. The new source
package is `/tmp/uwz-task5a-fix1-frozen`, and the exact review manifest is
`core/fix1/review-manifest.json`, SHA-256
`0f2ff0dfbe0a73866b12fe7cc858a0db82c0ea7a009eb2fe634089769131f9c0`.
The preimage manifest remains SHA-256
`9735f7f0818e69471751edb1db89e0c8b903ff6374678394e23334bfc71e0d13`.
The runner and wire diffs are `core/fix1/run_live.diff` and `wire.diff`.

The runner checks that its own exact path and hash match the reviewed manifest,
and loads both wire and independent helper from explicitly checked paths rather
than implicit local imports. The manifest checks the complete frozen package
inventory along with the previously bound trees and inputs. Its output collector
continuously drains the owned child's combined pipe, retains at most 65536 bytes,
flags overflow, and causes the run to fail; certificate-command output is
explicitly discarded while its exit status remains checked. Socket close, child
signal, child wait, key deletion, log save and pipe close are separate cleanup
actions, with accumulated failures and no forced-cleanup success. The wire
observer keeps at most nine header bytes and a remaining-length counter, and
rejects raw RST_STREAM frames before handing bytes to hyper-h2, even when the
library would suppress a reset after stream completion. An incomplete observed
frame is completed before a response is reported. Detection applies to bytes
actually read; no claim is made about an unseen reset arriving after the runner
has stopped reading.

Frozen source SHA-256:

- `profile.zig`: `65072ddd66c74ea1593d0af3b234a899711a68d33bd8caf1bcf49fe909ce5217`
- `run_live.py`: `b36862a7f4c061119389de1930a55a1589689b70c9d83d33a2d95154286e85c2`
- `wire.py`: `8aff857fbdbe36a0b483c79cb52faa0670494ca976fdfc06552627e97c3ba78c`
- `offline_checks.py`: `d534d6391f0dd792ea576814eaa883e4169db699b558162c5dd423ff06b7544f`
- `prepare.py`: `3d944c3f70e123386177b070230df2b09a16f10184b9ded272de95a5bb25829e`
- `case_manifest.json`: `c9729f100bfe209dcf99f246d1bba8479b98797de420694701df5f3f80688bbe`

The deterministic red check invokes the actual v2 `wire.accept` through real
pinned h2/hyperframe codec data, with response END_STREAM followed by RST:

```
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S -c 'import importlib.util; p="/tmp/uwz-task5a-fix1-frozen/offline_checks.py"; spec=importlib.util.spec_from_file_location("checks",p); checks=importlib.util.module_from_spec(spec); spec.loader.exec_module(checks); checks.check_frames(checks.load("/tmp/uwz-task5a-source-frozen-v2/wire.py","old_wire"))'
```

Raw result, retained in `core/fix1/red-assert.log`: exit 1,
`AssertionError: expected rejection: unexpected raw HTTP/2 reset`. The v2
observation command with `--v2` exits 0 and prints
`v2 regression reproduced: END_STREAM followed by RST accepted`.

The fixed offline checks use no socket, server, native fixture, fake completion,
or child process:

```
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5a-fix1-frozen/offline_checks.py
```

Raw output, exit 0 (`core/fix1/green.log`):

```
raw reset rejected at every split and one-byte fragmentation; zero-length and payload frames consumed
fragment collector retains exactly 65536 bytes, flags overflow and discards later bytes
cleanup records independent errors and attempts all later actions
guard rejects alternate runner path and modified wire before module import
offline checks passed
```

A separate offline call of `check_manifest` using the real fix1 manifest
accepted the frozen runner and rejected the byte-identical working-copy runner
with `executing source path differs`. AST parsing of all four frozen Python
files returned `fix1 frozen syntax OK`; `zig fmt --check
/tmp/uwz-task5a-fix1-frozen/profile.zig` exited 0 with empty output. An
AST-only graphify refresh on the isolated scratch copy
`/tmp/uwz-task5a-fix1-graph` exited 0: 5 files, 94 nodes and 224 edges. It did
not update the shared workspace graph.

The offline `core/fix1/freeze-command.txt` identity check exited 0 with:

```
v2 manifest and all bound trees and inputs unchanged
profile matches both original compile input records; both original binaries unchanged
fix1 source files: 6
fix1 manifest sha256: 0f2ff0dfbe0a73866b12fe7cc858a0db82c0ea7a009eb2fe634089769131f9c0
```

Thus the prior Debug and ReleaseSafe commands and binaries remain the only
compile results: both exited 0, and no fixture was rebuilt or executed in this
fix round. Real process-output flood, native cleanup, TLS and network behavior
remain untested; the offline checks establish only the specified codec and pure
helper behavior. The original reviewers must review this fix diff before Root
can separately authorize any ordinary owned execution.

Additional exact offline commands:

```
PYTHONPATH=/tmp/uwz-h2-client-tooling/packages /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5a-fix1-frozen/offline_checks.py --v2
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/core/fix1/guard-command.txt
/home/codespace/.python/current/bin/python3 -B .uwz-work/evidence/h2-streaming/integration-owned/core/fix1/freeze-command.txt
/home/codespace/.python/current/bin/python3 -B -c 'import ast,pathlib; r=pathlib.Path("/tmp/uwz-task5a-fix1-frozen"); [ast.parse((r/f).read_text(),filename=f) for f in ("prepare.py","run_live.py","wire.py","offline_checks.py")]; print("fix1 frozen syntax OK")'
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check /tmp/uwz-task5a-fix1-frozen/profile.zig
graphify update /tmp/uwz-task5a-fix1-graph
```

Each command above exited 0. The guard command's raw result is saved in
`core/fix1/guard.log`; the freeze script and guard script themselves contain
the exact offline operations. No full project matrix was run in this fix round.
