# Task 5a Stage B: actual owned core run

Root authorized one exact ordinary owned ReleaseSafe run only after the two
independent fix-round-1 re-reviews passed and the complete identity audit passed.
The authorization is `core/fix1/stage-b-authorization.json`, SHA-256
`94c8524cb65ad630abedc816eaf7915bb76242c4a5507187b895347892648582`.
It binds exact argv/environment, manifest, runner, binary, endpoint, cases,
deadlines and cleanup scope. The Stage A report and original v2 evidence remain
unchanged; neither earlier source review nor compilation implied this execution.

The reviewed manifest is SHA-256
`0f2ff0dfbe0a73866b12fe7cc858a0db82c0ea7a009eb2fe634089769131f9c0`.
Root preflight audit SHA-256
`d4a0dad8fd88dc4573950c2b0c46f000dcdc52bdee514fd63899cd0fda58c5fd`
checks 25 inputs, all five inventories, both actual successful build records,
unchanged profile and binaries, offline red/green evidence and received reviews.

Exact executed command, from `/workspaces/uWebZockets`:

```sh
env PYTHONPATH=/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client /home/codespace/.python/current/bin/python3 -B -S /tmp/uwz-task5a-fix1-frozen/run_live.py --run --manifest /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/core/fix1/review-manifest.json --manifest-sha256 0f2ff0dfbe0a73866b12fe7cc858a0db82c0ea7a009eb2fe634089769131f9c0 --output /tmp/uwz-h2-core-owned-2026-10-28-r1 --cases ready_buffered async_delayed large_declared large_undeclared shutdown_idle
```

Exec session 54995 completed with exit 0, no command output, final chunk 678ffd;
no retry or restart. Raw results, server log and public certificate are copied
under `core/stage-b/`. The key was deleted and was not copied. The actual runner
used the owned PID/start identity, nonce, listener inode, TLS 1.3/h2 and certificate
fingerprint. Normal SIGTERM produced exit 0, reaping, no forced cleanup and no
cleanup errors. Root additionally verified the child PID and key were absent.

All five requested cases pass. Buffered echo has 257 exact bytes and unchanged
zero sink counts; async returns 200/text/plain/ten `delayed-ok` bytes. Each large
upload sends and accepts exactly 100000000 bytes with client/server SHA-256
`190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2`,
begin/end/cancel 1/1/0 and maximum offered span 8192. Final aggregate counters
are 2/2/0, active 0, with an inactive post-deinit marker. All 13 responses end
normally. No reset is present in the bytes observed; unseen future resets are
outside this assertion. The log is 1137 bytes, below its 65536-byte cap.

Raw result SHA-256:
`ae6f618eacc5d640889354ca322c395b6c135c258b3aa00286b3e3b1c6480d8f`.
Root result audit SHA-256:
`76b9e110514768484f44f2a7338b5ced5039e7ed5ffa39836a8dc71a302ee27e`.
Repeating only the read-only identity audit after execution yields byte-identical
preflight evidence; all original source, client, override, binary and other
inputs remain unchanged. No native tests or compiler runs were repeated.

This is one Linux ReleaseSafe positive core run with idle shutdown. It does not
complete Task 5b/5c, pressure, active shutdown, general physical lifetime safety,
sanitizers, platform/compliance gates, genuine early data, H3, multipart transport,
maintained publication, production adoption or full M2. Stopped experiments and
denied socket cases remain stopped. Root publishes this bounded evidence and
continues the full ordered plan.
