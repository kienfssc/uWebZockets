# Task5a fix round1/5: verifier identities, bounds and cleanup

Same implementer, no restart. Root re-read SDD fix-loop. Preserve immutable v2
sources, original9735f7f0 manifest, binaries/build records, report preimage/reviews.
Own runner/wire and justified small offline-check/helper files in core/fix1 plus
working source derivative; no production or unchanged helper/package edits.

Open findings, verbatim:

P1 — Bind executing runner and imported wire module to reviewed manifest.
run_live.py328/201 check_manifest verifies named frozen files but not __file__;
import wire resolves executing directory without origin/hash check. A working
copy beside modified wire passes guard. Require running source path/hash and
resolve/hash exact wire before import; reject alternate copies.

P2 — Enforce output bounds while child runs. run_live.py234/283 redirects both
streams to unrestricted regular file, checking only readiness/final. Flooding
during upload grows retention until deadline; stat/read_text also races growth.
Drain continuously with capped retention; fail overflow and preserve cleanup.

P2 — Attempt each cleanup independently. run_live.py292 wraps socket close,
child identity/kill/wait and private-key deletion in one try. Earlier exception
skips later actions. Protect actions separately/nested finally, aggregate errors,
preserve failure while still attempting child reaping and key deletion.

P2 — wire.py37/73 misses resets after normal completion. Pinned h2 suppresses
StreamReset when closed; expected DATA END_STREAM + RST in same read passes
no-reset assertion. Add bounded raw-frame observation before unchanged hyper-h2,
reject unexpected resets even after END_STREAM. Do not edit pinned dependencies.

Keep all core case bytes/status/terminal/capacity/deadline constraints and later
planned matrix. Bind every newly loaded local module before import as applicable.
Imported paths and bytes must be approved, not just an unrelated frozen copy.
No unbounded log file or stat/read race; cap total raw retention65536 while still
draining safely, detect overflow during progress and fail. Cleanup cannot return
success after errors/forced termination; no unowned process signal or endpoint.
Raw frame observer retains bounded header/control bytes, never payload copies;
use pinned codec where useful and handle fragmented/coalesced/zero-payload frames.

Root ruling: StageA now additionally permits deterministic OFFLINE data checks
for these fixes, no socket/client/server/native execution. Test actual v2 pure
wire.accept using real pinned h2/hyperframe codec bytes: response END_STREAM then
RST in one read must reproduce missed rejection; new code rejects same/fragmented
forms. This is client-verifier evidence, never Native/uWebZockets acceptance.
No fake socket, kernel handle or completion, no real child-flood/error probe.
Test cap collector using supplied byte fragments; test cleanup using non-I/O
actions raising ordinary exceptions and recording later attempts; test path/hash
guard with offline paths/files only, without calling run or endpoint setup.
Do not fabricate a red from missing API/declaration errors. New observer/guard
checks go in a named offline_checks.py; stdout/key/native cases remain source-
review obligations until actual later owned scope.

No fixture Zig changes are expected; reuse existing binaries if exact profile/
candidate/compiler/module inputs remain identical, with explicit byte proof and
old command attribution. No unnecessary recompile or new native gates. Freeze new
Python/source package+manifest with all new modules/checks and preimage/final/diff,
raw offline/syntax/identity commands/outcomes/hashes. Run zig fmt --check on the
unchanged profile and AST-only harness refresh on scratch when applicable. Keep
native/profile/binary/helper inventories stable. All heavy outputs/tmp; save small
evidence/core/fix1 and append same task-5a-report with preimage preserved.
Root will re-review only fix diff/new breakage with original reviewers once full
covering commands/outcomes exist. No StageB authorization, material generation,
server/client fixture binary execution, native probes, extra cases, production
fixes, subagents, commits/refs/fetches or reverts. You are not alone.
