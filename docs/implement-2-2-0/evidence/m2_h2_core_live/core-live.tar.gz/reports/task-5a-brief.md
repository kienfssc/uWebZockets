# Task5a StageA: prepare core owned H2/TLS harness

Read first: requirements and exact current slice. Read task-5-plan.md alongside
for the full retained matrix/public API references. This task prepares the core
slice only; Task5b/5c and remaining milestone acceptance are not complete or
optional. No server/client/native runtime is authorized in StageA.

Verify/read immutable /tmp/uwz-task4d-fix1-frozen,1031 files,
fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de.
Root HEAD273318e6d2ac98a7fdd6d311ce055a45356b6148 is clean/pushed. Use this as
an immutable library module input; no copy/edit of production source, tests,
exports, dependency pins or global gates. Existing c223 override, original r2 C
bindings and workspace static libs remain exact. Do not redo completed unit gates.

Own new test-only .uwz-work/evidence/h2-streaming/integration-owned/core/:
profile.zig, run_live.py, prepare.py, case_manifest.json, source/build/review
evidence and report. Add one focused wire.py or fixture-output module only if it
earns concrete bounded protocol/process/lifetime invariants; no generic framework.
Keep code flat/named, explicit inputs, no classes or hidden global state, max3
control levels. Reuse public H1 profile patterns, not its entire old runner.
All large sources/cache/binaries and future runtime files live under new/tmp paths.
Persist small working source snapshots before questions or at milestones.
You are not alone; no reverts/subagents/Root edits/commits/refs/pushes/fetches.

Implement only these selectable core case IDs, preserving other full-plan IDs as
explicit planned/unimplemented data, which fail if requested rather than skip:
ready_buffered, async_delayed, large_declared, large_undeclared, shutdown_idle.

Use the exact profile in task-5-plan:8 connections, streaming on, L512, H4096,
headers80, H1 body256, H2 body/response stride4096, H2 encoded header8192,
response headers4096/count32, captures24, write queue65536, unrelated features off.
Server.preset(io,comptime config).build_https supports captures24; do not choose
fixed16 ConfiguredApp. /upload/:tag has max_body_bytes100000000/max_active2 and
two caller-owned contexts. Every chunk hashes only accepted bytes incrementally;
no accumulating body. Track successful begin, end/cancel invocations, byte count,
final SHA, maximum offered span and stable case tag in fixed owned records.
Server must compute SHA, never return the expected constant as its observation.
Record all actual profile/capacity/slab values and helper/buffer bounds.

ready_buffered: strict TLS1.3/ALPNh2; GET health200 bodyok; buffered POST echo257
deterministic bytes exactly echoed, independently counted/hashed; no sink callback.
async_delayed: ordinary buffered get_async /delayed with HEADERS END_STREAM;
token.sleep_complete(10,"200 OK","Content-Type: text/plain\r\n","delayed-ok").
Exactly200/text/plain/10 bytes/normal end/no reset within30s; no timer precision or
cancellation/error-schedule claim, no retained Request/Response pointer.
large_declared and large_undeclared: actual100000000 bytes generated/sent in at
most8192-byte spans using unchanged reviewed generator; with/without Content-Length.
Require status200, actual sink accepted100000000 and server/client SHA
190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2 including
final22-byte marker, begin1/end1/cancel0, no full-body storage or fake acceptance.
Use bounded response JSON <4096 with tag/accepted/SHA/callback counts/max span;
verify exact expected fields and full response completion. Do not claim full
quota/control/metadata/pressure/lifecycle acceptance from this core subset.
shutdown_idle: after all responses and no active fixture binding, SIGTERM only
directly owned child through catch_shutdown_signals installed before run; normal
run/deinit, marker after deinit, exit0/reaped. Not the active-shutdown case.

Use immutable prepared helper .uwz-work/evidence/h2-streaming/integration-client/
h2_client.py SHA07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00
and pinned package42 files0f85bd19 under/tmp/uwz-h2-client-tooling/packages. No
source changes, package installs/downloads. Use actual independent H2 frames and
real configured App/body routes, never a raw stand-in server. The core runner may
use happy-path helper, while its later extension owns interleaved/reset cases.

Fixture sources use public API only. Keep App/definitions/context/record memory
stable through deinit. Context counters/status results retain owned data only,
never read expired metadata after callbacks/teardown. Main catches signals,
listens only127.0.0.1:28443, emits run-nonce marker after listen/watcher installation,
then run/deinit/post-marker. No public App.is_drained/bound-port API assumed.
TLS trust/fingerprint and alive owned PID/nonce are required before health contact.

prepare.py may compile Debug and ReleaseSafe using Zig0.16 fixed tool, -j2,
explicit candidate module/bindings/libs/c22393 source; Python syntax via ast parse
without importing or executing runner/packages. Save full argv/actual outcome/log
hash/binary/module/input/environment identities, complete1031 source and client42
checks, fixture source inventory and manifest. Do NOT run binaries/clients, native
constructors, server/helper selfchecks, openssl/material generation or create sockets.

Design explicit run flag + reviewed manifest/hash guard for StageB, but do not
invoke it. Import must create no children/files/sockets/TLS contexts. Later run
generates ephemeral localhost trust/key and regular fixture data only in private
new/tmp run dir; no keys in evidence. Absolute Python -B and exact PYTHONPATH,
bounded8192 generation/read spans, max8 response records,65536 prefix,16 infos/
16384 info-header budget plus final/trailer/event bounds. Absolute deadlines15s
ready/30s ordinary/180s each100MB/900s total/15s graceful. No automatic retries,
endpoint fallback or forced-cleanup success. Capture exact owned child identity,
listener/nonce, live TLS/ALPN, all byte/hash/terminal results and cleanup on every
exit. Server setup error is failure, never alternate success.

Original stopped native experiments/EPERM cases, native fault/resource/leak/
scheduling/interleaving/race/injected-completion/kernel-error/panic probes remain
prohibited. Any production defect is reported to Root/owner, never fixed here.
No native lifetime/full M2 claim follows from preparation. Root will independently
review exact sources then issue separate precise ordinary-owned execution scope.

Report .superpowers/sdd/h2_streaming_plan/task-5a-report.md: exact source/fixture/
binary/input identities, compile/syntax commands/raw outcomes, all implemented
assertions, process/cleanup design, planned matrix gaps and limitations. Freeze
the source package before requesting review; preserve actual failures/preimages.
Return concise status/artifact paths/check summary. Graphify before new codebase
search when graph exists; supplied public API/reference paths are located.
