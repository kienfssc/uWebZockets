"""Offline codec and pure-function regression checks; no sockets or processes."""
import argparse
import importlib.util
import hashlib
import json
from pathlib import Path
import sys
import tempfile

import h2.config
import h2.connection
from hyperframe.frame import RstStreamFrame


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def response_wire():
    client = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=True, header_encoding='utf-8'))
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False, header_encoding='utf-8'))
    client.initiate_connection()
    server.initiate_connection()
    server.receive_data(client.data_to_send())
    client.receive_data(server.data_to_send())
    client.send_headers(1, [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/')], end_stream=True)
    server.receive_data(client.data_to_send())
    server.send_headers(1, [(':status', '200')])
    server.send_data(1, b'ok', end_stream=True)
    reset = RstStreamFrame(1)
    reset.error_code = 8
    return client, server.data_to_send() + reset.serialize()


def old_regression(wire):
    client, data = response_wire()
    records, trace = {}, {}
    wire.register(records, 1, 2)
    wire.accept(client, data, records, trace)
    assert records[1]['ended'] and records[1]['reset'] is None
    print('v2 regression reproduced: END_STREAM followed by RST accepted')


def rejects(action, expected):
    try:
        action()
    except RuntimeError as error:
        assert expected in str(error), str(error)
        return
    raise AssertionError('expected rejection: ' + expected)


def check_frames(wire):
    _, sample = response_wire()
    for split in range(len(sample) + 1):
        client, data = response_wire()
        records, trace = {}, {}
        wire.register(records, 1, 2)
        def feed():
            wire.accept(client, data[:split], records, trace)
            wire.accept(client, data[split:], records, trace)
        rejects(feed, 'unexpected raw HTTP/2 reset')
    client, data = response_wire()
    records, trace = {}, {}
    wire.register(records, 1, 2)
    def one_byte():
        for byte in data:
            wire.accept(client, bytes([byte]), records, trace)
    rejects(one_byte, 'unexpected raw HTTP/2 reset')
    client, data = response_wire()
    records, trace = {}, {}
    wire.register(records, 1, 2)
    for byte in data[:-13]:
        wire.accept(client, bytes([byte]), records, trace)
    assert records[1]['ended'] and bytes(records[1]['body']) == b'ok'
    state = {'header': [], 'remaining': 0}
    frames = bytes.fromhex('000000040100000000000003000000000001aabbcc')
    for byte in frames:
        wire.observe_frames(bytes([byte]), state)
    assert state == {'header': [], 'remaining': 0}
    print('raw reset rejected at every split and one-byte fragmentation; zero-length and payload frames consumed')


def check_capture(runner):
    capture = runner.new_capture()
    for fragment in (b'a' * 8191, b'b', b'c' * 57344):
        runner.capture_fragment(capture, fragment)
    data, overflow, error = runner.capture_snapshot(capture)
    assert len(data) == 65536 and not overflow and error is None
    runner.check_capture(capture)
    runner.capture_fragment(capture, b'x')
    runner.capture_fragment(capture, b'y' * 8192)
    after, overflow, error = runner.capture_snapshot(capture)
    assert after == data and overflow and error is None
    rejects(lambda: runner.check_capture(capture), 'server output exceeds 65536')
    print('fragment collector retains exactly 65536 bytes, flags overflow and discards later bytes')


def check_cleanup(runner):
    calls = []
    def action(name, fail=False):
        def invoke():
            calls.append(name)
            if fail:
                raise ValueError(name)
        return invoke
    errors = runner.cleanup_actions((('socket', action('socket', True)), ('child_signal', action('child_signal', True)),
                                     ('child_wait', action('child_wait', True)), ('key', action('key')), ('log', action('log'))))
    assert calls == ['socket', 'child_signal', 'child_wait', 'key', 'log']
    assert [item['action'] for item in errors] == ['socket', 'child_signal', 'child_wait']
    print('cleanup records independent errors and attempts all later actions')


def check_paths(runner):
    with tempfile.TemporaryDirectory(prefix='uwz-fix1-path-', dir='/tmp') as directory:
        root = Path(directory)
        actual = Path(runner.__file__).absolute()
        alternate = root / 'run_live.py'
        alternate.write_bytes(actual.read_bytes())
        wire = root / 'wire.py'
        wire.write_text('value = 1\n')
        helper = root / 'helper.py'
        helper.write_text('value = 2\n')
        files = [actual, alternate, wire, helper]
        inputs = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
        runner.checked_path(actual, str(actual), inputs)
        rejects(lambda: runner.checked_path(alternate, str(actual), inputs), 'executing source path differs')
        manifest = {'state': 'ready-for-independent-review', 'trees': {}, 'inputs': inputs,
                    'runner': str(alternate), 'wire': str(wire), 'helper': str(helper)}
        manifest_path = root / 'manifest.json'
        manifest_path.write_text(json.dumps(manifest))
        manifest_digest = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
        rejects(lambda: runner.check_manifest(manifest_path, manifest_digest), 'executing source path differs')
        manifest['runner'] = str(actual)
        manifest_path.write_text(json.dumps(manifest))
        manifest_digest = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
        runner.check_manifest(manifest_path, manifest_digest)
        wire.write_text('value = 3\n')
        rejects(lambda: runner.check_manifest(manifest_path, manifest_digest), 'input identity differs')
        rejects(lambda: runner.load_bound('modified_wire', str(wire), inputs), 'executing source hash differs')
    print('guard rejects alternate runner path and modified wire before module import')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--v2', action='store_true')
    args = parser.parse_args()
    path = Path('/tmp/uwz-task5a-source-frozen-v2/wire.py') if args.v2 else Path(__file__).with_name('wire.py')
    wire = load(path, 'checked_wire')
    if args.v2:
        old_regression(wire)
        return
    runner = load(Path(__file__).with_name('run_live.py'), 'checked_runner')
    check_frames(wire)
    check_capture(runner)
    check_cleanup(runner)
    check_paths(runner)
    print('offline checks passed')


if __name__ == '__main__':
    main()
