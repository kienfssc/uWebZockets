# Fix round 1 protocol re-review

Received from `/root/review_h2_core_runner_protocol`, independently completed.

Closed-reset finding: ADDRESSED. SPEC: PASS for this scoped fix. QUALITY: PASS.
No new actionable findings.

`wire.py:35–58` observes raw frame headers before hyper-h2, rejects RST_STREAM
independently of stream state, and retains at most nine header bytes plus a
payload-length counter. `run_live.py:182–185` waits for an already-observed
partial frame before reporting completion.

The retained red result reproduces v2's missed rejection; green evidence covers
every split, one-byte fragmentation, zero-length frames, and payload traversal.

Limits: source and recorded offline evidence only. Live wrapper behavior remains
untested; resets arriving after reading stops remain outside the observation
claim. No Stage B or native acceptance follows from this review.
