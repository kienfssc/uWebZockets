"""Read-only identity audit before the separately authorized core run."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
CORE = HERE.parent
MANIFEST_SHA = '0f2ff0dfbe0a73866b12fe7cc858a0db82c0ea7a009eb2fe634089769131f9c0'


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as source:
        while block := source.read(1048576):
            value.update(block)
    return value.hexdigest()


def main():
    path = HERE / 'review-manifest.json'
    assert digest(path) == MANIFEST_SHA
    manifest = json.loads(path.read_text())
    assert manifest['runner'] == '/tmp/uwz-task5a-fix1-frozen/run_live.py'
    assert manifest['binary'] == '/tmp/uwz-task5a-release-final/profile'
    assert manifest['state'] == 'ready-for-independent-review'
    trees = []
    for root, expected in manifest['trees'].items():
        actual = {str(p.relative_to(root)): digest(p) for p in sorted(Path(root).rglob('*')) if p.is_file()}
        assert actual == expected, root
        tree_digest = hashlib.sha256(json.dumps(list(actual.items())).encode()).hexdigest()
        trees.append({'root': root, 'files': len(actual), 'sha256': tree_digest})
        if root == '/tmp/uwz-task4d-fix1-frozen':
            assert tree_digest == manifest['source_tree_digest']
        if root == '/tmp/uwz-h2-client-tooling/packages':
            assert tree_digest == manifest['client_tree_digest']
    for name, expected in manifest['inputs'].items():
        assert digest(name) == expected, name
    assert digest(CORE / 'review-manifest.json') == manifest['preimage_manifest_sha256']
    builds = []
    frozen = Path(manifest['runner']).parent
    for stem, mode, binary in (
        ('debug-final', 'Debug', '/tmp/uwz-task5a-debug-final/profile'),
        ('release-final', 'ReleaseSafe', manifest['binary']),
    ):
        record = json.loads((CORE / (stem + '.json')).read_text())
        command = json.loads((CORE / (stem + '.command.json')).read_text())
        assert record['exit_status'] == 0 and record['inputs_unchanged']
        assert record['optimization'] == mode
        assert record['source_tree_sha256'] == manifest['source_tree_digest']
        assert record['source_after_sha256'] == manifest['source_tree_digest']
        assert record['input_sha256'] == record['input_after'] == command['input_sha256']
        for name, expected in record['input_sha256'].items():
            assert digest(name) == expected, name
        for name, expected in record['fixture_before'].items():
            assert digest(frozen / name) == expected, name
        assert record['fixture_before'] == record['fixture_after']
        assert record['override_before'] == record['override_after']
        assert digest(binary) == record['binary_sha256']
        assert (CORE / (stem + '.log')).stat().st_size == 0
        builds.append({'mode': mode, 'binary': binary, 'sha256': digest(binary),
                       'record_sha256': digest(CORE / (stem + '.json')),
                       'command_sha256': digest(CORE / (stem + '.command.json'))})
    evidence_names = ('red-assert.log', 'green.log', 'guard.log', 'run_live.diff',
                      'wire.diff', 'review-process.md', 'review-protocol.md')
    evidence = {name: digest(HERE / name) for name in evidence_names}
    assert 'expected rejection: unexpected raw HTTP/2 reset' in (HERE / 'red-assert.log').read_text()
    assert (HERE / 'green.log').read_text().endswith('offline checks passed\n')
    assert 'working copy rejected: executing source path differs' in (HERE / 'guard.log').read_text()
    report = {'review_manifest_sha256': MANIFEST_SHA, 'trees': trees,
              'checked_input_files': len(manifest['inputs']), 'builds': builds,
              'evidence_sha256': evidence, 'runner_sha256': digest(manifest['runner']),
              'wire_sha256': digest(manifest['wire']), 'checks_passed': True,
              'scope': 'Identity and recorded evidence only; no native execution or new runtime claim.'}
    (HERE / 'root-preflight-audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'checks_passed': True, 'trees': [(x['files'], x['sha256']) for x in trees],
                      'inputs': len(manifest['inputs']), 'build_modes': [x['mode'] for x in builds],
                      'audit_sha256': digest(HERE / 'root-preflight-audit.json')}))


if __name__ == '__main__':
    main()
