# StageA v2 ownership/process review

Reviewer /root/review_h2_core_runner_process, read-only. SPEC and QUALITY request
changes; frozen5-file hashes and manifest9735f7f0 match report.

P1 run_live.py328/201: manifest validates named frozen files, not executing
__file__ or imported wire origin. Running a working copy beside modified wire
passes guard and executes unreviewed logic. Bind executing source path/hash and
resolve/hash exact wire before import; reject alternate copies.

P2 run_live.py234/283: child stdout/stderr go to unrestricted regular file;
checks only readiness/final leave uploads/failures unbounded. Eventual rejection
does not bound retained bytes. Size-check then unrestricted read_text also races
growth. Drain continuously with capped retention, fail overflow, preserve cleanup.

P2 run_live.py292: one cleanup try wraps socket close, child verification/kill/
wait and key deletion. Earlier exception skips all later actions; timed-out wait
leaves key, socket error skips child cleanup. Protect actions independently,
aggregate errors and preserve failure while attempting reaping/key removal.

Public stable lifecycle, copied tags/no retained callback objects, signal watcher,
post-deinit marker, strict TLS/ALPN/cert and direct child/start/nonce/listener
before-health checks are present. Missing markers/forced cleanup fail. No further
size/abstraction finding. No imports/builds/runtime; runtime paths unverified.
