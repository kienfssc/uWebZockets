"""Bounded HTTP/2 response observation for the core owned fixture."""
import hashlib
import h2.events

READ_BOUND = 8192
STREAM_LIMIT = 8
HEADER_FIELDS = 32
HEADER_BYTES = 4096
INFO_COUNT = 16
INFO_BYTES = 16384
EVENT_LIMIT = 64


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def register(records, stream_id, body_limit):
    require(len(records) < STREAM_LIMIT and stream_id not in records, "stream record bound")
    require(0 <= body_limit <= 4096, "invalid response limit")
    records[stream_id] = {"headers": None, "trailers": None, "informationals": 0,
                          "info_bytes": 0, "bytes": 0, "hash": hashlib.sha256(),
                          "body": bytearray(), "limit": body_limit, "ended": False,
                          "reset": None}


def checked_headers(headers):
    require(len(headers) <= HEADER_FIELDS, "header field count bound")
    size = sum(len(k.encode("utf-8")) + len(v.encode("utf-8")) + 32 for k, v in headers)
    require(size <= HEADER_BYTES, "header byte bound")
    return size


def accept(protocol, data, records, trace):
    require(len(data) <= READ_BOUND, "read exceeds bound")
    for event in protocol.receive_data(data):
        name = type(event).__name__
        require(name in trace or len(trace) < EVENT_LIMIT, "event type bound")
        trace[name] = trace.get(name, 0) + 1
        if isinstance(event, h2.events.ConnectionTerminated):
            raise RuntimeError("HTTP/2 connection terminated")
        if not isinstance(event, (h2.events.InformationalResponseReceived, h2.events.ResponseReceived,
                                  h2.events.TrailersReceived, h2.events.DataReceived,
                                  h2.events.StreamEnded, h2.events.StreamReset)):
            continue
        require(event.stream_id in records, "unregistered response stream")
        record = records[event.stream_id]
        if isinstance(event, h2.events.InformationalResponseReceived):
            size = checked_headers(event.headers)
            require(record["informationals"] < INFO_COUNT and record["info_bytes"] + size <= INFO_BYTES,
                    "informational bound")
            record["informationals"] += 1
            record["info_bytes"] += size
        elif isinstance(event, h2.events.ResponseReceived):
            checked_headers(event.headers)
            require(record["headers"] is None, "duplicate response headers")
            record["headers"] = list(event.headers)
        elif isinstance(event, h2.events.TrailersReceived):
            checked_headers(event.headers)
            require(record["trailers"] is None, "duplicate trailers")
            record["trailers"] = list(event.headers)
        elif isinstance(event, h2.events.DataReceived):
            require(not record["ended"], "DATA after end")
            require(record["bytes"] + len(event.data) <= record["limit"], "response body bound")
            record["bytes"] += len(event.data)
            record["hash"].update(event.data)
            record["body"].extend(event.data)
            protocol.acknowledge_received_data(event.flow_controlled_length, event.stream_id)
        elif isinstance(event, h2.events.StreamEnded):
            require(not record["ended"], "duplicate end")
            record["ended"] = True
        elif isinstance(event, h2.events.StreamReset):
            record["reset"] = int(event.error_code)
            raise RuntimeError("unexpected HTTP/2 reset")
