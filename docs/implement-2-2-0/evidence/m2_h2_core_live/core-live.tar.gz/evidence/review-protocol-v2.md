# StageA v2 protocol review

Reviewer /root/review_h2_core_runner_protocol, read-only.
SPEC REQUEST CHANGES; QUALITY PASS, no additional structural finding.

P2 at wire.py37/73: event-only observation misses reset after stream completion.
Pinned h2/stream.py731-738/1230-1236 suppresses StreamReset when closed. Expected
/delayed DATA END_STREAM followed by RST in the same read yields only StreamEnded;
reset staysNone and the promised no-reset assertion passes. Add bounded raw-frame
observation before unchanged hyper-h2 consumption, rejecting unexpected resets
even after END_STREAM. This is a verifier gap, not a dependency defect.

Remaining core assertions are connected to actual App/body routes, incremental
server hashing, independent generated/sent SHA, exact counts/callback deltas,
buffered echo/delayed response/idle shutdown. No generated-only success found.
No checks/runtime; later matrix/full lifecycle remains unverified.
