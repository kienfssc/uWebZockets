# Overflow decision correction plan

The existing pure Wheel suite passes. A single-advance regression with a later
far-deadline list head and an earlier overflow entry fails before correction:
the earlier callback is not delivered even though its deadline is reached.
A preliminary probe that first advanced near the earlier deadline passed;
its original source and raw result are retained separately.

The overflow list is insertion-ordered. next_event reads only its head, so it
can select a later migration boundary and skip an earlier due node during a
large advance. Change that actual decision to scan overflow entries for the
minimum migration time, retaining the existing fixed-slot search and all
state/count transitions. No new storage, allocation, clock or I/O is needed.
Keep this isolated draft pending independent review and root integration gates.
This is not a native scheduler/cancellation/race experiment or measured
wall-clock failure. It does not change response token or sleep semantics.
