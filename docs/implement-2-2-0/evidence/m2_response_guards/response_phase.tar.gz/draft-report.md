# M2 response-phase guard preparation

Prepared in `/tmp/uwz-m2-response-guards-draft`, detached exact base
`a7a5eee9a0bf224131f08174280229e8edac939d`. Original repository, other drafts,
Request/OwnedRequest, transport/config/router and dependency files were not
edited. No commits or pushes. All owned source is frozen for independent review.

## Change

Response has default-true request_body_complete. It is a transport phase input;
existing buffered constructors retain their behavior. After the established
ResponseAlreadyStarted check, begin_chunked/begin_stream/stream_file refuse an
incomplete upload with BodyNotComplete, before validation or any output/target/
producer/file ownership effect. The closed send_file API uses existing
BodyNotAllowed. Fixed finals and append_header remain available. JSON/SSE and
the first writable-stream write reach the canonical begin guard.

The flag is appended to the data fields, using existing tail padding. An initial
placement before framing preserved size but shifted existing framing/header
field offsets; that intermediate source was rejected. Final native field offsets
are identical to baseline, and actual Response size/alignment is unchanged on
all four measured targets. No config assertion or capacity was changed.

## Source

- `src/http/response.zig`: six added lines (field/comment and four guards),
  SHA256 `35c3a015d56e7a1cc1bc001dea93308d64bdd0449621a356debc06568c6c1f54`.
- `src/tests/request_body_response_tests.zig`: six focused centralized cases,
  SHA256 `c75b835724671af331f61c6481de81998aa4e27848acff198210fcfad1c17bb5`.
- `src/tests/main.zig`: one suite import, SHA256
  `9bd3f65d28ee7a0d642b9f70fe21723f1c7bbf5a2ea0a04ca8f7a86c337dba7d`.

Complete additive patch is
`/tmp/uwz-m2-response-guards-evidence/complete.patch`, SHA256
`96a2a06cbb1946186e1b8e7693151f09cd88ada8316bdbca1b6d38efd2081998`.
Root must serialize its shared test-main import with concurrent common work.

## Executed checks and retained evidence

Evidence directory: `/tmp/uwz-m2-response-guards-evidence`. Exact argv, raw logs
and numeric statuses accompany each check. Zig is 0.16.0. Focused tests use
actual clone source plus existing read-only translated bindings and cached C
archives; no new native C graph or full matrix was run.

- missing_phase_red: terminal 1, actual tests fail because baseline Response
  lacks request_body_complete; production source was unchanged at that point.
- legacy_before / legacy_after / legacy_final: terminal 0. One unchanged actual
  release-export consumer has both an exact original eleven-error narrow
  send_file wrapper and exhaustive catch. Its bytes never changed. Existing
  declaration membership evidence was reused, not repeated as a toy probe.
- phase_green: terminal 1, five tests pass; existing owned loopback fixture's
  socket creation returns sandbox EPERM. This environment failure is retained.
- phase_green_loopback: terminal 0, six tests pass after authorized escalation,
  on the intermediate field placement.
- phase_green_final: terminal 0, six tests pass on final source. They prove all
  starts/wrappers refuse without effects, pending/close state stays unchanged,
  valid files remain readable/caller-owned with no transfer/queue/ingress state
  mutation, existing started-state precedence, early fixed output and defaults.
- Final fmt --check (owned files), conventions, release-version checks: 0.
  Documentation links also checked 0; no docs changed in this slice.
- graphify update: terminal 0, AST-only extraction in isolated clone; retained
  sequential-fallback warning. Ignored graph output is not part of the patch.

Actual declaration probes intentionally return 1 solely for compileLog; each
record includes that classification. Final sizes equal baseline on native
Linux, x86_64-windows-gnu, aarch64-macos and x86_64-macos:

| Target | Response size/alignment | TcpConnection | Default slab |
| --- | --- | --- | --- |
| Linux native | 2160 / 8 | 25624 | 684160640 |
| Windows GNU | 2160 / 8 | 26112 | 684660352 |
| macOS arm64 | 2160 / 8 | 25544 | 684078720 |
| macOS x86_64 | 2160 / 8 | 25544 | 684078720 |

Request remains 2752, H2 session 1376, H2 storage/Bundle 517648, QUIC stream
880 POSIX/888 Windows, HeaderSet 2992 POSIX/3000 Windows. The unchanged H3 byte
slab estimate does not represent RSS or total external allocations. Full raw
measurements, exact target bindings and expected-exit classifications are in
final-layout-results.json, layout-final-* and offsets-final artifacts. Native
existing Response offsets (target/state/close/framing/headers/length) remain
0/104/105/106/107/96. Intermediate measurement artifacts remain historical only.

## Remaining gates

No live request streaming is implemented or advertised. No adapter yet sets the
new phase false. Independent code/lifetime review and actual combined-source
native, sanitizer, target/package/production checks remain root integration
requirements. Per root scope, no complete matrix was repeated in this draft.
The owned loopback fixture proves file refusal ownership, not a real upload
transport or throughput. Foreign declaration probes are not foreign runtime.
