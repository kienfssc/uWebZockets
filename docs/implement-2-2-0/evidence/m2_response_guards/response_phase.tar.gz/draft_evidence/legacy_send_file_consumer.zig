const std = @import("std");
const uz = @import("uWebZockets");
const LegacyFileError = error{
    ResponseAlreadyStarted,
    InvalidStatus,
    InvalidHeaders,
    BodyNotAllowed,
    WouldBlock,
    BufferOverflow,
    ConnectionClosed,
    TlsUnavailable,
    TlsWriteFailed,
    ZeroCopyUnavailable,
    FileBodyAlreadyActive,
};

fn narrow(output: *uz.Response, file: std.Io.File) LegacyFileError!void {
    try output.send_file("200 OK", "", file, 0, 8);
}

export fn legacy_narrow(output: *uz.Response, file: *const std.Io.File) bool {
    narrow(output, file.*) catch return false;
    return true;
}

export fn legacy_exhaustive(output: *uz.Response, file: *const std.Io.File) u8 {
    output.send_file("200 OK", "", file.*, 0, 8) catch |err| return switch (err) {
        error.ResponseAlreadyStarted => 1,
        error.InvalidStatus => 2,
        error.InvalidHeaders => 3,
        error.BodyNotAllowed => 4,
        error.WouldBlock => 5,
        error.BufferOverflow => 6,
        error.ConnectionClosed => 7,
        error.TlsUnavailable => 8,
        error.TlsWriteFailed => 9,
        error.ZeroCopyUnavailable => 10,
        error.FileBodyAlreadyActive => 11,
    };
    return 0;
}
