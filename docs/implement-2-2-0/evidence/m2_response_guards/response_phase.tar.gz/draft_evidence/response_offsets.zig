const Response = @import("test_support").http_response.Response;
comptime {
    @compileLog("Response", @sizeOf(Response), @alignOf(Response));
    @compileLog("offsets", @offsetOf(Response, "target"), @offsetOf(Response, "state"), @offsetOf(Response, "close_after_end"), @offsetOf(Response, "stream_framing"), @offsetOf(Response, "pending_headers"), @offsetOf(Response, "pending_header_length"));
}
