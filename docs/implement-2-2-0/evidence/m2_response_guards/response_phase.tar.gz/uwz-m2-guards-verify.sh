#!/bin/sh
set -u
evidence=$1
mkdir -p "$evidence"
export ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache
status=0
run_gate() {
    gate_name=$1
    shift
    printf '%s\n' "$*" > "$evidence/$gate_name.command.txt"
    "$@" > "$evidence/$gate_name.log" 2>&1
    gate_status=$?
    printf '%s\n' "$gate_status" > "$evidence/$gate_name.exit.txt"
    printf '%s exit %s\n' "$gate_name" "$gate_status"
    if [ "$gate_status" -ne 0 ]; then status=1; fi
}
git rev-parse HEAD > "$evidence/base_commit.txt" || exit 2
git diff HEAD --binary > "$evidence/tracked_source.patch" || exit 2
cp /tmp/uwz-m2-guards-integrated.sha256 "$evidence/owned_source.sha256" || exit 2
sha256sum -c "$evidence/owned_source.sha256" > "$evidence/owned_source_before.txt" || exit 2
sha256sum src/http/request.zig src/http/response.zig src/router/config.zig flake.lock build.zig.zon > "$evidence/baseline_sources_before.sha256"
zig version > "$evidence/zig_version.txt" || exit 2
run_gate format zig fmt --check src builds examples tests fuzz
run_gate conventions sh scripts/check_conventions.sh
run_gate version sh scripts/check_release_version.sh
run_gate docs sh scripts/check_docs.sh
run_gate dependencies sh scripts/check_dependency_forks.sh
run_gate native zig build test -j2 --cache-dir /tmp/uwz-original-zig-cache --summary all
run_gate build zig build -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate sanitizer zig build test -Dsanitize=true -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate release_safe zig build test-compile -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate windows zig build test-compile -Dtarget=x86_64-windows-gnu -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate macos_arm64 zig build test-compile -Dtarget=aarch64-macos -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1a-cache --summary all
run_gate package sh -c 'cd tests/package_consumer && zig build check -Doptimize=ReleaseSafe -j2 --cache-dir /tmp/uwz-frozen-m1-final-package --summary all'
run_gate package_paths sh scripts/check_package_paths.sh
sha256sum -c "$evidence/owned_source.sha256" > "$evidence/owned_source_after.txt" || status=1
sha256sum -c "$evidence/baseline_sources_before.sha256" > "$evidence/baseline_sources_after.txt" || status=1
printf '%s\n' "$status" > "$evidence/matrix.exit.txt"
exit "$status"
