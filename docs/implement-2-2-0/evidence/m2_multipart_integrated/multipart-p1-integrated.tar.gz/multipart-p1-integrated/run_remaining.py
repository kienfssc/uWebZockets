import os,sys,json,subprocess,hashlib,time
from pathlib import Path
root=Path('/workspaces/uWebZockets')
out=root/'.uwz-work/evidence/multipart-integrated'
zig='/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig'
env=os.environ.copy()
env['PATH']='/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin:/home/codespace/.codex/packages/app-server-daemon/releases/0.164.0-x86_64-unknown-linux-musl/codex-path:'+env['PATH']
env['ZIG_GLOBAL_CACHE_DIR']='/tmp/uwz-multipart-integrated-global'
paths=[p for p in subprocess.check_output(['git','ls-files','-z','--','src','builds','examples','tests','fuzz','oss-fuzz','build.zig','build.zig.zon','vendor'],cwd=root).decode().split('\0') if p and (root/p).is_file()]
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
initial=json.loads((out/'source-before.json').read_text())
assert hashes()==initial, 'Frozen source changed before resume'
env.update(json.loads((out/'sanitizer-env.json').read_text())['values'])
steps=[
 ('conventions',['sh','scripts/check_conventions.sh'],root),
 ('release-version',['sh','scripts/check_release_version.sh'],root),
 ('docs',['sh','scripts/check_docs.sh'],root),
 ('dependency-forks',['sh','scripts/check_dependency_forks.sh','--offline'],root),
 ('diff-check',['git','diff','HEAD','--check'],root),
 ('native',[zig,'build','test','-j2','--summary','all'],root),
 ('sanitize',[zig,'build','test','-j2','-Dsanitize=true','-Doptimize=ReleaseSafe','--summary','all'],root),
 ('release-safe',[zig,'build','test-compile','-j2','-Doptimize=ReleaseSafe','--summary','all'],root),
 ('release-fast',[zig,'build','lib','-j2','-Doptimize=ReleaseFast','--summary','all'],root),
 ('default-build',[zig,'build','-j2','-Doptimize=ReleaseSafe','--summary','all'],root),
 ('windows-gnu',[zig,'build','test-compile','-j2','-Dtarget=x86_64-windows-gnu','-Doptimize=ReleaseSafe','--summary','all'],root),
 ('macos-arm64',[zig,'build','test-compile','-j2','-Dtarget=aarch64-macos','-Doptimize=ReleaseSafe','--summary','all'],root),
 ('consumer',[zig,'build','check','-j2','-Doptimize=ReleaseSafe','--cache-dir','/tmp/uwz-multipart-consumer-cache','--summary','all'],root/'tests/package_consumer'),
 ('package-paths',['sh','scripts/check_package_paths.sh'],root),
 ('msan',[zig,'build','msan','-j2','-Dmemory-sanitize=true','-Doptimize=ReleaseSafe','--summary','all'],root),
 ('smith',[zig,'build','fuzz','-j2','--fuzz=100K','-Doptimize=ReleaseSafe','--summary','all'],root),
 ('oss-fuzz-objects',[zig,'build','oss-fuzz-objects','-j2','-Doptimize=ReleaseSafe','--summary','all'],root),
 ('oss-fuzz-smoke',[zig,'build','oss-fuzz-smoke','-j2','-Doptimize=ReleaseSafe','--summary','all'],root),
]
steps=steps[6:]
steps[0]=('sanitize-restored-env',steps[0][1],steps[0][2])
records=[]
for label,argv,cwd in steps:
 record={'label':label,'argv':argv,'cwd':str(cwd),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'source_before_matches':hashes()==initial}
 (out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print('START',label,flush=True); start=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as so,(out/(label+'.stderr')).open('wb') as se:r=subprocess.run(argv,cwd=cwd,env=env,stdout=so,stderr=se)
 record.update(exit_status=r.returncode,elapsed_seconds=time.monotonic()-start,source_after_matches=hashes()==initial)
 (out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');records.append(record)
 (out/'remaining-summary.json').write_text(json.dumps(records,indent=2)+'\n')
 print('END',label,r.returncode,round(record['elapsed_seconds'],2),flush=True)
 if r.returncode or not record['source_after_matches']:
  print((out/(label+'.stderr')).read_text()[-14000:],flush=True);sys.exit(r.returncode or 90)
(out/'source-after.json').write_text(json.dumps(hashes(),indent=2)+'\n')
print('MATRIX COMPLETE',len(records),flush=True)
