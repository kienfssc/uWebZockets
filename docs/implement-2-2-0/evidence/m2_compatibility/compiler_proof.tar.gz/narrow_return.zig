const Request = @import("request").http_request.Request;

const OldFormError = error{
    MissingContentType,
    UnsupportedMediaType,
    TooManyQueryParameters,
    QueryComponentTooLong,
};

fn buffered_form_count(req: *const Request) OldFormError!usize {
    const params = try req.form();
    return params.count;
}

export fn form_consumer(req: *const Request) usize {
    return buffered_form_count(req) catch |err| switch (err) {
        error.MissingContentType => 1,
        error.UnsupportedMediaType => 2,
        error.TooManyQueryParameters => 3,
        error.QueryComponentTooLong => 4,
    };
}
