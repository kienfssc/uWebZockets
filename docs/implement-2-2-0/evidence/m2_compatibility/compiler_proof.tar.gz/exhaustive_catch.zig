const Request = @import("request").http_request.Request;

export fn buffered_consumer() usize {
    var req = Request{ .body = "name=Zig" };
    req.header_names[0] = "content-type";
    req.header_values[0] = "application/x-www-form-urlencoded";
    req.header_count = 1;
    const params = req.form() catch |err| switch (err) {
        error.MissingContentType => return 1,
        error.UnsupportedMediaType => return 2,
        error.TooManyQueryParameters => return 3,
        error.QueryComponentTooLong => return 4,
    };
    return params.count;
}
