# M2 buffered helper error-set compatibility audit

Independent bounded audit, 2026-10-26 UTC. No source edits, C compilation,
linking, native/SAN/other gates, or live protocol runs. Probes only use Zig
0.16.0 build-obj -fno-emit-bin and isolated caches in this directory.

## Actionable finding

Frozen draft src/http/request.zig:205 adds error.BodyNotBuffered to the public
Request.form inferred return error set. This is a real buffered consumer source
break, not only a newly observable streaming-mode error. ADR0008 says full-body
APIs remain compatible; the first-slice plan says buffered helper results remain
compatible. The same runtime-selected Request type cannot both keep its old
closed error set and return a new distinct error through that same signature.

Baseline (actual original Request, byte-identical to commit
40931267a61cde32c7d3b4ad2e5ce98098ee7102):
error{MissingContentType, TooManyQueryParameters, QueryComponentTooLong,
UnsupportedMediaType}.

Frozen draft: the same four errors plus BodyNotBuffered.
The return payload remains query_module.QueryParams.

## Consumer proof

- narrow_return.zig: a wrapper declares the exact baseline four-error return
  type and uses try req.form(). baseline.status=0; draft.status=1, specifically
  BodyNotBuffered not being a member of the destination set.
- exhaustive_catch.zig: constructs a default, fully buffered Request with a
  valid form Content-Type and handles the four baseline errors exhaustively.
  exhaustive_catch-baseline.status=0; exhaustive_catch-draft.status=1,
  specifically an unhandled BodyNotBuffered error. No streaming route or mode
  opt-in is present in this consumer.
- inferred_names.zig: prints the actual reflected error names. Both exits are
  intentionally 1 because compileLog is a measurement, not a behavioral test.
  The names show exactly the four baseline errors and five draft errors above.
- inferred_set.zig was an earlier measurement that prints the unresolved
  inferred-type display, not its member names; its compileLog exits are also
  intentional and are retained without being called behavior failures.
- setup-module-path-* records the initial direct-request-module attempt, which
  was rejected for sibling imports outside that module root. It is a harness
  setup failure, not a behavioral RED. Final probes import the unchanged
  src/test_support.zig namespace so the source module root is src; its
  http_request.Request alias is the same actual type exported by src/root.zig.
  No production code is copied or modified to construct the tests.

Exact argv/text commands, stdout, stderr and statuses are retained per probe.
commands.json, additional-commands.json and inferred-names-commands.json retain
structured invocations. source-verification.json proves original Request matches
40931267 and all eight frozen draft source hashes remain unchanged.

## Compatibility decision required

1. If the new BodyNotBuffered behavior on these existing names is required,
   explicitly accept an error-set source break, revise the compatibility promise
   in the ADR/plan, and publish the migration obligation: exhaustive catches and
   explicit narrow error returns must add/handle BodyNotBuffered. Existing
   open-ended !/anyerror wrappers may continue compiling.
2. If strict buffered source compatibility is required, keep the legacy helper
   surface and introduce a separate checked/streaming-aware surface or request
   view. That requires a deliberate ADR/API adjustment: the currently mandated
   BodyNotBuffered result cannot be added to the same old closed error set.

Named error aliases or changing inferred ! to anyerror do not preserve the old
consumer contract. Mapping the condition to an unrelated old parse/media error
would discard the accepted distinct refusal semantics. Do not silently make
those changes. This audit proves Request.form; it does not instantiate generic
JSON/schema helpers or claim every helper has the same inferred error set.
