const Request = @import("request").http_request.Request;

comptime {
    const Return = @TypeOf(@as(*const Request, undefined).form());
    @compileLog(@typeInfo(Return).error_union.error_set);
}
