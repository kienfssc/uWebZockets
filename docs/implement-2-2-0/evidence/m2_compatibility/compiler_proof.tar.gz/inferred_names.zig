const Request = @import("request").http_request.Request;

comptime {
    const Return = @TypeOf(@as(*const Request, undefined).form());
    const Errors = @typeInfo(Return).error_union.error_set;
    for (@typeInfo(Errors).error_set.?) |item| @compileLog(item.name);
}
