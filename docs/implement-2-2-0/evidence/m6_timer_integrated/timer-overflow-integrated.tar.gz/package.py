from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,re,tarfile,subprocess
root=Path('/workspaces/uWebZockets')
e=root/'.uwz-work/evidence/m6-timer-integrated'
dest=root/'docs/implement-2-2-0/evidence/m6_timer_integrated'
dest.mkdir(parents=True,exist_ok=True)
records=json.loads((e/'root-summary.json').read_text())
assert len(records)==9
assert all(x['exit_status']==0 and x['source_before_matches'] and x['source_after_matches'] for x in records)
for name in ('central-Debug','central-ReleaseSafe','existing-Debug','existing-ReleaseSafe'):
 r=json.loads((e/(name+'.json')).read_text());assert r['exit_status']==0 and r['source_before']==r['source_after']
assert json.loads((e/'red.json').read_text())['exit_status']==1
assert 'expected 1, found 0' in (e/'red.log').read_text()
assert json.loads((e/'source-before-root-gates.json').read_text())==json.loads((e/'source-after-root-gates.json').read_text())
views={}
for name in ('build.zig.zon','build.zig.zon.json','build.zig.zon.nix','build.zig.zon.txt'):
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show','HEAD:'+name],cwd=root)
 views[name]=hashlib.sha256(data).hexdigest()
(e/'unchanged-dependency-views.json').write_text(json.dumps(views,indent=2)+'\n')
(e/'independent-review.md').write_text('''# Independent root integration review, 2026-10-27

Reviewer /root/review_h2_refusal_final, read-only. P2/P3 resolved, no new actionable
findings. Production contains only the reviewed minimum scan; new regression is
centralized, six old inline cases untouched. Attribution followup distinguishes
the passing first probe and actual failing source; historical archive unchanged.

Verified final evidence against263 source identities: actual behavioral red;
central1/1 and existing6/6 Debug/ReleaseSafe; native852/852; sanitizer852/852;
ReleaseSafe compile20/20; defaultbuild47/47; formatter/conventions/version/docs/
dependency checks pass. All recorded source identities remain stable. Reviewer
ran no builds/tests/probes. Approval covers this bounded correction only.
''')
(e/'SCOPE.md').write_text('''# Integrated pure timer overflow correction

Actual root baseline is parent44a106c4f2688bf348c0cf675c04bbbc8027e5dd plus the
retained production.diff/two source replacements. Root next_event now scans all
overflow entries for the earliest migration boundary, matching next_deadline.
No layout/API/allocation/callback/ownership change; cost is linear in overflow
entries per decision. New regression is only in src/tests/core_tests.zig.

Actual root behavioral red fails expected1/found0 before the decision correction;
new central and six existing cases pass Debug/ReleaseSafe. All root checks
pass with263 source identities unchanged: formatting, convention/version/docs/
dependency/whitespace, full native and C sanitizer852/852 each, ReleaseSafe20steps,
and default47steps. Existing Nix-rendered sanitizer environment is retained with
provenance; no sanitizer/assertion was disabled or weakened. No candidate libxev
override or root pin change was used. All four dependency views are unchanged.

Independent re-review resolves test placement and historical attribution findings.
The old timer archive is immutable. The old preimage JSON incorrectly calls the
passing first-probe hash its red source; the explicit followup points to the actual
failing single-leap source and raw record. Root central red is separately bound.

No new native clock/cancellation/fault/race/crash/leak experiment ran. The new test
uses scalar deadlines and caller-owned memory. Existing whole-root suites ran
unchanged except that one additional pure test. No wall-clock/performance claim,
response-token/sleep semantic change or completion of the whole C6 row follows.
''')
retained={};omitted={}
for p in sorted(e.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink(),str(p)
 name=p.relative_to(e).as_posix();data=p.read_bytes()
 if data.startswith(b'\x7fELF'):
  omitted[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};continue
 retained[name]=data
assert not omitted
values=[v.encode() for k,v in os.environ.items() if re.search(r'(?:TOKEN|SECRET|PASSWORD|CREDENTIAL|API_KEY)$',k) and len(v)>=20]
pattern=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})')
for name,data in retained.items():assert not any(v in data for v in values) and not pattern.search(data),name
inventory={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in retained.items()}
retained['inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
archive=dest/'timer-overflow-integrated.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(retained.items()):
    info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);info.mtime=0
    tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():
  path=PurePosixPath(member.name)
  assert member.isfile() and not path.is_absolute() and '..' not in path.parts
  assert tar.extractfile(member).read()==retained[member.name]
manifest={'date':'2026-10-27','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'safe_regular_members':len(retained),'inventory_entries':len(inventory),'source':json.loads((e/'integration-source.json').read_text()),'independent_review':'P2/P3 resolved; no new actionable findings','root_gates_all_passed':True,'native_and_sanitizer_tests_each':852,'credential_scan':'All retained bytes checked against environment credential values and GitHub token patterns','files':inventory}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('archive_sha256','archive_bytes','safe_regular_members','inventory_entries')},indent=2))
