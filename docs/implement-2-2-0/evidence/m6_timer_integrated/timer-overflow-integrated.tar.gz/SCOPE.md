# Integrated pure timer overflow correction

Actual root baseline is parent44a106c4f2688bf348c0cf675c04bbbc8027e5dd plus the
retained production.diff/two source replacements. Root next_event now scans all
overflow entries for the earliest migration boundary, matching next_deadline.
No layout/API/allocation/callback/ownership change; cost is linear in overflow
entries per decision. New regression is only in src/tests/core_tests.zig.

Actual root behavioral red fails expected1/found0 before the decision correction;
new central and six existing cases pass Debug/ReleaseSafe. All root checks
pass with263 source identities unchanged: formatting, convention/version/docs/
dependency/whitespace, full native and C sanitizer852/852 each, ReleaseSafe20steps,
and default47steps. Existing Nix-rendered sanitizer environment is retained with
provenance; no sanitizer/assertion was disabled or weakened. No candidate libxev
override or root pin change was used. All four dependency views are unchanged.

Independent re-review resolves test placement and historical attribution findings.
The old timer archive is immutable. The old preimage JSON incorrectly calls the
passing first-probe hash its red source; the explicit followup points to the actual
failing single-leap source and raw record. Root central red is separately bound.

No new native clock/cancellation/fault/race/crash/leak experiment ran. The new test
uses scalar deadlines and caller-owned memory. Existing whole-root suites ran
unchanged except that one additional pure test. No wall-clock/performance claim,
response-token/sleep semantic change or completion of the whole C6 row follows.
