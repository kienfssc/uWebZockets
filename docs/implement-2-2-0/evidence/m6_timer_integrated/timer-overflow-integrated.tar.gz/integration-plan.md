# Accepted pure timer correction integration

Original isolated plan and independent review establish the bounded next_event
minimum scan. Integrate only that production decision, with the same behavioral
regression moved to src/tests/core_tests.zig. Existing six inline wheel cases
remain unchanged; no public API/layout/ownership/callback/count change is made.
The central regression uses public Wheel types and caller-owned counter data,
without clock, OS, allocation or new native fault probe.

Correct the historical red-source attribution in a followup record without
mutating its archive. Reproduce red against actual root baseline, verify new
central and six existing pure tests in Debug/ReleaseSafe, then run project root
format/convention/version/docs/dependency/native/sanitizer/ReleaseSafe/build gates.
Independent re-review must resolve placement and evidence findings before commit.
C6 response token semantics and native parked-H2 reset remain separate open work.
