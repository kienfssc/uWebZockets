# Task 5e3b5a: queued trailers and receive credit

Status: implemented as two pure in-memory public-codec schedules; independent review is required. Supported selection is 23 cases; 17 remain unsupported and are rejected before actions. This is neither native fixture evidence nor all40 acceptance.

`credit_cases.py` uses the unchanged model's request contracts, payload spans, checkpoints and final records. Queued trailers sends the first 8192 bytes, checks the accepted-seven paused record and pending response, then sends 4097 bytes with seven padding bytes and the pad-length byte, followed by the two source trailers through `wire.send_trailers`. It checks that the second status is identical, bounds each early refund independently to 15, resumes through `/resume/queued_trailers_padding`, and validates the completion record. Exact J/C/R is 6/6/12297.

Receive credit starts one upload with independent connection and stream credit at 65535, sends exactly 65535 bytes in bounded spans, observes health and the zero-byte paused checkpoint, and verifies both independent debts and both exhausted windows. After the source resume, it observes the accepted-65535 unpaused record and pending response, waits for the independently paired connection and stream refunds, verifies both restored windows and zero aggregate stream debt, and sends the final byte with END. It validates the final model record. Exact J/C/R is 7/7/65536. This follows the source's bounded receive wait for earned refunds; it does not generate grants. `adapter.py` adds the actually used optional padding argument and dispatch/primary bindings; all DATA, trailers, responses and retirement use the reviewed wire seam. `cases.py` adds only the two implemented IDs. The three existing unsupported-count checks change 19 to 17 and retain rejection checks; `test_imports.py` adds both modules.

The authoritative final credit/fix1 `cases.py`, `profile.zig` and `run_live.py`, immutable model/catalogue, v9 wire/request ledger and combined fixture credit/formatting references are identified by hashes in `combined-cases/evidence/b5a/reference-sha256.txt`. The release addendum and input audit bind the full source identities. The final 20-module snapshot and SHA-256s are `evidence/b5a/snapshot/` and `snapshot-sha256.txt`; `source-comparison.json` compares against B4 completion: two new, six changed, zero missing, twelve unchanged. The B5 incomplete report and B1–B4 evidence remain intact.

## Test history and proof

The initial actual serialized-schedule test is retained as `evidence/b5a/initial-test.py`. Its `red.*` records exit 1, `ValueError: case schedule not implemented`; this is selection-only RED, not a behavioral failure. After implementing the queued schedule, `intermediate-1.*` records `queued_trailers_padding passed`, followed by the same selection-only rejection for receive credit. `intermediate-2.*` records both cases passing. `intermediate-3.*` records both passing plus the two synthetic sensitivity controls. No intermediate outcome has been omitted.

The focused test decodes actual outbound HEADERS and checks method, target, header order and multiplicity; it checks DATA stream, bounded ordinal, length, padding, END, trailing header fields and trailer ordinal. Independent incremental SHA-256 and byte/flow counters cover the serialized upload. It checks the source observation/resume order and exact paths, stage-enforced J/C/R, and uses fresh connection contexts sharing one synthetic application and selected-before state. The final collection checks all 67 statuses and metrics, including both selected records and untouched records. The post-implementation synthetic controls reject a changed paused byte count and an omitted stream refund; the latter is rejected on missing subsequent synthetic input, rather than being a native or standalone server fault. The synthetic application uses model records and is not independent fixture validation. No native run, independent server, or actual runtime cancellation/fault experiment was performed.

## Final verification

All commands used:

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/<name>.py
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/<name>.py
```

For each of `test_credit`, `test_admission`, `test_pause`, `test_continue_quota`, `test_selection`, `test_adapter`, `test_ready`, `test_async`, `test_negative`, `test_time`, `test_large`, `test_shared`, `test_imports` and `test_final`, both commands exited 0 with empty stderr. Separate complete stdout/stderr/exit receipts are under `evidence/b5a/{normal,optimized}-<name>.*`. No Zig optimization mode applies. The focused raw stdout in both modes is:

```text
queued_trailers_padding passed
receive_credit passed
paused_record rejected: record mismatch: bytes
missing_stream_credit rejected: missing synthetic response
```

`test_imports` reports `AST and inert import checks passed`; it imports with empty and foreign argv and rejecting effect doubles. The required graphify query preceded new source searches; a repeat is retained in `graphify.*`. `graphify update .` exited 0 and reported no relevant graph changes, retained in `graph-update.*`.

## Self-review and remaining work

The current code uses no alternate parser or duplicated refund, modifies no immutable core, fixture, model, capacity, deadline or budget, and retains caller integer time and bounded spans. The independent review must assess the credit/refund sequencing and strength of the synthetic tests. The test's fabricated peer and its model-derived records cannot establish native fixture behavior. No Zig matrix, compliance gate, build, socket, TLS, process, kernel, scheduler, real-clock or other prohibited native operation was run.

Parent note: the other eight B5 cases and all40/default/aggregate/native acceptance remain open. Review this unit and its evidence before accepting it; no Git or public delivery was performed.

## Description correction before review

Changed only the `cases.py` module description from “Twenty-one” to “Twenty-three” to match its existing tuple. No behavior changed and no RED was invented. The current `cases.py` SHA-256 is `e953654391d0ea71d9f17546f635a0b92cc40d00bcf276261b36d0864a46c59c`. The 20-module snapshot, hashes and comparison are under `evidence/b5a/completion/`; compared with the preceding B5a snapshot, only `cases.py` changed, with 19 unchanged and none added or missing. The preceding 28 results remain proof for the preceding source snapshot and were not rerun for this description change.

Using the same exact `PYTHONPATH` documented above, the current-source checks were:

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Both exited 0 with empty stderr and stdout `AST and inert import checks passed`. Separate raw stdout, stderr and exit receipts are in `evidence/b5a/completion/`. No Zig optimization mode applies. Independent review and the remaining cases and native acceptance remain open.
