# Task5e3b5a: concrete queued-trailer and receive-credit schedules

This smaller implementation unit follows the incomplete B5report: no code or
concrete immutable-core blocker was established. Root read handling-reports
and verified all18 current files still match pushed B4. Preserve that report.
The B5parent still requires all10 original cases; task-5e3b-unit-plan.json now
splits implementation granularity into2+2+3+3 without changing any requirement.
All40/default/aggregate/native/fullmilestone scope is unchanged.

Implement these two actual schedules now, reusing already-read source context.
Do not repeat a whole source mapping or stop after the old selection check.
Read B5brief for unchanged global source/API/proof/no-native constraints;
this brief narrows the immediate code assignment, not final acceptance.

Own new concrete credit/trailer schedule/tests, minimal required existing
adapter/cases/import updates and evidence/b5a plus task-5e3b5a-report.md. Root
authorizes exact existing unsupported assertions19->17 for this earned two-case
increment, preserving rejection checks. Do not add the other8 as supported
until their handlers are implemented/reviewed. Main dispatch becomes23source
cases, not full40; unsupported17 fail before actions. Preserve old B5evidence.

Use final credit/fix1/cases.py,profile.zig,run_live.py under the provided
integration-owned path, current combined fixture credit/formatting routes,
unchanged v3catalogue/model, v9wire and earned B1..B4adapter. Only two tags:
queued_trailers_padding and receive_credit. Exact J/C/R6/6/12297 and7/7/65536.

Queued case must preserve exact source headers, first accepted7 paused
checkpoint, queued remainder/padding and trailers, identical pre-resume record,
actual finite observation/resume order, canonical payload/hash and retained
trailer/metadata diagnostics. Request DATAflow includes padding8 beyond the
12289logicalbody; HEADERS/trailer/END actions go through canonical wire once.

Receive-credit must preserve exact source65536logicalbody, one DATA stream,
legitimate independent connection/aggregate-stream debt<=65535, actual window
exhaustion and earned refunds after the source's paused/resume sequence.
No invented credit/refund, scope conflation, extra observation heads or polling.
Reuse existing bounded credit loops only where their contract fits. Preserve
all exact source actions and the model's record, metadata and accepted hash.

Start with one actual public-codec schedule test and capture its pre-change
failure, then implement its used adapter seams and schedule before the second.
Keep initial test source and all real intermediate outcomes; accurately
qualify selection/API-only RED versus serialized behavior. Use actual bound
wire actions for DATA/padding/trailers/observation/retirement, no alternate raw
parser/codec bypass or direct invariant-evading state writes.

Check serialized headers/multiplicity, DATA/padding/trailer/END ordinals, exact
J/C/R, bounded independent hashes and paused/window/credit invariants. Use
bounded counts/ordinals, not frame histories. Prove shared synthetic app/fresh
connection/selected-before/final67+metrics with both new records. A real
immutable API gap requires the smallest failing pure call and required source
behavior; implement the independent case instead of ending with mapping only.
No model/core/fixture/budget/deadline/capacity change or numerical shortcut.

After final edits capture relevant normal/-O checks with separate raw stdout/
stderr/exit under evidence/b5a, including prior changed-seam regressions and
all authored helper inert/AST checks. Snapshot all current modules and compare
against18-module B4. Every authored helper has main guard and actual empty/
foreign-argv silent/inert imports; no classes/assert proof/custom exceptions,
unused speculative constants, hidden mutable globals or nesting beyond3.

Use pinned Python/-B -S for editing/metadata/tests and required graph query
before new source search/read. No native/socket/SSLContext/build/old live/
TLS-close/process/transfer/descriptor/kernel/fault/cancel/schedule/race/panic/
leak/real-clock execution; no agents/externalmodel/Git/public edits. You are
not alone; preserve others' work. Append parent note retaining incompleteall10.
Write full new b5areport and return concise DONE/realconcern/report/tests.
