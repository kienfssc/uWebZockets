"""Serialized queued trailer and receive-credit schedules against an in-memory peer."""
import hashlib
import json
import adapter
import h2_client
import hpack
import model
import test_ready


def check(case, app=None, prior=(), final=False):
    decoder, encoder = hpack.Decoder(), hpack.Encoder()
    if app is None:
        app = {'records': {tag: model.record(tag, False, 'before') for tag in model.SPECS}, 'heads': 0}
    peer = {'startup': True, 'buffer': bytearray(), 'pending': [], 'paths': [], 'stream': None,
            'frames': 0, 'logical': 0, 'flow': 0, 'hash': hashlib.sha256(), 'trailers': 0, 'resumed': False}

    def respond(stream, body):
        block = encoder.encode(((':status', '200'), ('x-middleware', 'retained')))
        peer['pending'].append(test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body))

    def request(path, stream):
        if path == '/health':
            respond(stream, b'ok')
        elif path.startswith('/status/'):
            respond(stream, json.dumps(app['records'][path[8:]]).encode())
        elif path == '/resume/' + case:
            if peer['resumed']:
                raise RuntimeError('duplicate resume')
            peer['resumed'] = True
            respond(stream, b'ok')
            if case == 'receive_credit':
                update = (65535).to_bytes(4, 'big')
                peer['pending'].append(test_ready.frame(8, 0, 0, update) + test_ready.frame(8, 0, peer['stream'], update))
            else:
                complete()
        elif path == '/metrics':
            metrics = {key: sum(item[key] for item in app['records'].values()) for key in model.COMMON_COUNTERS + ('bytes',)}
            metrics.update(active=0, paused=0, buffered_middleware=app['heads'] - metrics['middleware'], slot0_active=False, slot1_active=False)
            respond(stream, json.dumps(metrics).encode())
        else:
            raise RuntimeError('unexpected auxiliary request')

    def complete():
        item = model.record(case, True, 'after')
        item.update(chunks=2 if case == 'queued_trailers_padding' else 9, max_span=8192)
        app['records'][case] = item
        respond(peer['stream'], json.dumps(item).encode())

    def headers(packet, stream, flags):
        entries = list(decoder.decode(packet[9:]))
        if stream == peer['stream']:
            if entries != [('x-metadata', 'trailer-qtp'), ('x-trailer-only', 'discarded')] or flags != 5 or peer['frames'] != 2:
                raise RuntimeError('trailer ordinal differs')
            peer['trailers'] += 1
            return
        path = dict(entries)[':path']
        peer['paths'].append(path)
        app['heads'] += 1
        expected = [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)]
        contract = model.request_contract(case)
        if path == contract['target']:
            expected[0] = (':method', 'POST')
            expected.append(('content-length', str(contract['declared'])))
            if case == 'queued_trailers_padding':
                expected += [('x-metadata', 'initial-qtp'), ('x-initial-only', 'initial-only')]
            if entries != expected or flags != 4:
                raise RuntimeError('upload headers differ')
            peer['stream'] = stream
            item = model.checkpoint(case, 'paused')
            if item['bytes']:
                item.update(chunks=1, max_span=7)
            app['records'][case] = item
        else:
            if entries != expected or flags != 5:
                raise RuntimeError('auxiliary headers differ')
            request(path, stream)

    def data(packet, flags):
        size = len(packet) - 9
        ordinal = peer['frames']
        if case == 'queued_trailers_padding':
            expected = ((8192, 0), (4105, 8))
        else:
            expected = tuple((min(8192, 65535 - offset), 0) for offset in range(0, 65535, 8192)) + ((1, 1),)
        if ordinal >= len(expected) or (size, flags) != expected[ordinal]:
            raise RuntimeError('DATA ordinal differs')
        payload = packet[9:]
        if flags & 8:
            if payload[0] != 7 or payload[-7:] != bytes(7):
                raise RuntimeError('padding differs')
            payload = payload[1:-7]
        peer['hash'].update(payload)
        peer['logical'] += len(payload)
        peer['flow'] += size
        peer['frames'] += 1
        if flags & 1:
            complete()

    def send(data_bytes):
        if peer['startup']:
            peer['startup'] = False
            return
        peer['buffer'].extend(data_bytes)
        while len(peer['buffer']) >= 9:
            size = int.from_bytes(peer['buffer'][:3], 'big')
            if len(peer['buffer']) < size + 9:
                return
            packet = bytes(peer['buffer'][:size + 9])
            del peer['buffer'][:size + 9]
            kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
            if kind == 1:
                headers(packet, stream, flags)
            elif kind == 0:
                if stream != peer['stream']:
                    raise RuntimeError('DATA stream differs')
                data(packet, flags)

    def receive():
        if not peer['pending']:
            raise RuntimeError('missing synthetic response')
        return peer['pending'].pop(0), 2

    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, selected_before=prior, clock=lambda: 2)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), 2)
    adapter.run_case(context, receive)
    if final:
        adapter.final_collection(context, receive)
    size = 12289 if case == 'queued_trailers_padding' else 65536
    if peer['logical'] != size or peer['flow'] != size + (8 if size == 12289 else 0) or peer['hash'].hexdigest() != model.accepted_hash(size):
        raise RuntimeError('upload digest or flow differs')
    if peer['trailers'] != int(size == 12289):
        raise RuntimeError('trailers differ')
    print(case + ' passed')
    return app


def main():
    app = check('queued_trailers_padding')
    check('receive_credit', app=app, prior=('queued_trailers_padding',), final=True)


if __name__ == '__main__':
    main()
