# Task5e3b5b: concurrent routes and metadata helpers

Continue the unchanged all40 plan after reviewed/pushed B5a. Its commit and
20-module source map are in task-5e3b5a-root-commit-audit.json and
task-5e3b5a-root-completion-audit.json. B5parent still requires all10original
cases, subdivided2+2+3+3 only to make implementation progress; this task adds
concurrent_routes and metadata_helpers. Acceptedsource23/40 is not native or
milestone acceptance. Read B5brief/global release addendum for binding scope.

## Ownership and immutable sources

Own concrete concurrent/metadata schedule/tests, minimal actually-used existing
adapter/cases/import/helper changes, evidence/b5b and task-5e3b5b-report.md.
Preserve B1..B5a source/history. Root authorizes precise unsupported-count
assertions17->15 in existing test_pause.py,test_admission.py,
test_continue_quota.py and any current exact-count test; preserve assertions
and rejection loops. Update cases.py's description to match25 actual supported
cases. No unsupported successful handlers. Root owns public/Git; no agents or
externalmodelCLI. You are not alone; preserve others' edits.

Immutable model/catalogue:/tmp/uwz-task5e1-contract-v3; v9core:
/tmp/uwz-task5e3a-snapshot-v9/source; combined fixture:
/tmp/uwz-task5e2-Fix1Final2/fixture; pinned helper/codecs/Python from release
addendum. Final authority under .uwz-work/evidence/h2-streaming/:
integration-owned/credit/fix1/cases.py,profile.zig,run_live.py and
integration-owned/metadata/cases.py,profile.zig. Their exact hashes are bound
in task-5e3b-input-audit.json. Use current combined schema/request contracts,
not legacy family field aliases. Read references only, never old entrypoints.

Run prescribed graphify query before first source search/read and retain its
outcome. All directly invoked Python editing/metadata/tests use exact pinned
path and -B -S. Do not repeat known invocation/search-order deviations. Reuse
earned credit/padding/trailer/status/reset/held/retirement seams only where the
actual source contract fits; do not rewrite completed schedules.

## Exact implementation

concurrent_routes: J/C/R13/13/96. Preserve four separate records/tags:
concurrent_hold, concurrent_refused, concurrent_upload, concurrent_recovery.
Follow the exact source holder/refusal/independent-route/resume/recovery order,
with one finite authoritative status/metrics barrier at each specified point.
Validate route-level isolation, legitimate paused state, source-selected
refusal status/no100/final-before-reset policy, healthy independent upload and
post-release recovery. Preserve all source diagnostics and exact headers/
declarations/DATA/END/metadata. Keep the global/per-route quotas and HTTP/2
stream capacities unchanged. Do not infer a status or primary ID from role;
derive its binding from the actual request order and current model.

metadata_helpers: J/C/R6/6/32. Preserve exact source method/path/query/header
and capture construction, overflow/helper-refusal contracts, initial/trailer
separation and metadata/helper observations at middleware/begin/end. Use the
current fixture/model schema and request generator; no second expected-state
model, omitted helper checks or synthetic success placeholders. The exact
source trailers and canonical payload/hash must pass the same wire path.
Retain all five new persistent records across these two cases, with all other
records unchanged. Body token generation is private; producer-binding proof
belongs later and must not be invented in metadata status.

Every HEADERS/DATA/trailer/SETTINGS/grant/reset/observation/retirement pairs once
through canonical wire/parser/both ledgers/stage. Preserve fresh caller integer
time at action/read/drain/final points, inherited deadlines, all exact J/C/R/
settings/reset counts, bounded spans/hashes/captures and no frame/read histories.
Flush preceding actions before one same-connection observation; fail on mismatch
without polling/extra heads. No replayed refund, alternate parser/codec bypass,
direct invariant-evading writes or core/model/fixture/capacity/budget mutation.

The actual supported subset becomes25; remaining15 fail before actions.
Full40/default/aggregate/native and all original milestones remain required.
Prove both new schedules using fresh connection contexts sharing one synthetic
application/selected-before state, existing final67+metrics collection, all
five new records and all untouched records. Model-derived peer records remain
supplied synthetic input, not independent fixture correctness evidence.

## Proof and handoff

Begin with an actual serialized schedule test and retain initial test source,
real pre-change failure, all intermediate failures and exact scopes. Selection/
API-only REDs remain qualified; no missing-file or mutation-as-RED claims.
Implement concrete used seams/schedules, not another mapping-only handoff.
If a real immutable API blocks required behavior, report smallest failing pure
call/source requirement and continue the independent case, preserving both.

Independently check serialized method/path/query/header multiplicity,
declaration/Expect/END, DATA/trailer/reset ordinals, payload/hash/flow, distinct
route/record isolation, finite paused/active observations and actual helper
outcomes. Target negatives at those named invariants and label later synthetic
sensitivity controls accurately. No whole bodies or per-DATA/read histories.

After the last edit, capture relevant normal/-O checks with separate raw
stdout/stderr/exits under evidence/b5b, preserving prior changed-seam regressions.
No unrelated suite reruns. Snapshot every current module/hash, exact comparison
against20-module B5a. All authored helpers need main guards and actual empty/
foreign-argv silent/inert imports with rejecting effects. No authored classes,
custom exceptions/inheritance/assert proof, hidden mutable globals, unused
constants/dead code, stale descriptions or nesting beyond3 levels.

No native build/server/socket/SSLContext/TLS-close/process ownership/transfer/
descriptor/kernel/fault/cancel/schedule/race/panic/leak/real-clock experiment,
old live entrypoint, agents/externalmodelCLI/Git/public delivery. Pure codec
control/reset tests are within scope; stopped native probes remain stopped.
Write full report with contracts/APIs/files/commands/raw evidence/history/
identities/self-review/remaining facts; append parent note, B5/all40incomplete.
Return concise DONE/realconcerns/report/testsummary. Root reviews separately.
