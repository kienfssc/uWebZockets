# Task 5e3b5b completion report

Implemented both requested concrete schedules, metadata first and concurrency second. Supported selection is now 25/40; the other 15 selections fail before send/startup actions. This is pure in-memory public-codec evidence with supplied synthetic application records. Independent review remains with Root. Neither native fixture correctness, all40 execution, default/aggregate integration nor any original milestone is accepted by this source unit.

The original `task-5e3b5b-report.md`, original `evidence/b5b/initial-test.py`, red/graphify receipts and B1–B5a evidence are preserved. Every new receipt is under `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b5b/completion/` (called `completion/` below).

## Exact implementation and APIs

`metadata_cases.run(context, receive)` uses `model.request_contract('metadata_helpers')` verbatim for POST, target and the regular header entries. This includes `content-length: 32`, `x-mode: begin_paused`, x-h00 through x-h62 and the explicit regular `host: localhost`, in that order, after adapter-generated pseudo-headers including `:authority: localhost`. There is no authority API change. Exact target is `/meta/metadata_helpers/a01/a02/a03/a04/a05/a06/a07/a08/a09/a10/a11/a12/a13/a14/a15/a16?q=alpha&n=17`.

The schedule is health, upload HEADERS, 16 DATA without END, one status/pending barrier, second 16 DATA without END, END trailers `x-h62=changed` and `x-trailer-only=discarded`, one identical status/pending barrier, resume/finish, health. Both paused statuses validate the complete current model record, including begins1, bytes0, chunks0, ends0, cancels0, active/paused true and metadata/helper observations. The final body validates metadata_middleware, helpers_begin, helpers_end, metadata_begin and metadata_end as well as every common field. Its exact J/C/R is 6/6/32.

`concurrent_cases.start(context, tag)` binds actual model method/target/declaration and source-selected x-metadata/Expect entries. `active(context, receive)` makes one finite same-connection metrics request, compares all common counters and bytes against current model records plus selected-before state, and requires active2, paused1, both slots active and the exact buffered-middleware total. `finish` validates the full model terminal record.

The concurrent schedule is initial health; hold HEADERS and first16 DATA; paused status/pending; refusal HEADERS with declared1 and Expect; final503 followed by retained NO_ERROR0 reset and no100; independent upload HEADERS; active2 metrics barrier; upload32 DATA+END and finish; health; unchanged holder paused status; resume; holder16 accepted, ready and no-END status/pending; final holder16 DATA+END and finish; recovery HEADERS plus32 DATA+END and finish; health; retire refused; final health. Its exact J/C/R is 13/13/96, resets1. Four distinct records remain `concurrent_hold`, `concurrent_refused`, `concurrent_upload`, `concurrent_recovery`.

Both primary streams are stream3 because the first request is health and the second is the held upload. The test checks every newly allocated request stream against actual request ordinal; it does not infer primary from refusal/reset role. The refused concurrent stream is stream7 and is explicitly checked present in response records, stage and raw observer at both intervening health points, then absent from all three after the source-selected retirement.

All actions use existing `adapter.start/send_data/finish/retire/observe`, `wire.send_trailers`, `wire.accept/drain`, request/response ledgers, raw observer and output stage. Existing credit barrier/resume functions are reused because their actual route/policy fits these sources. No alternate codec/parser, refund replay, capacities, quotas, budgets, deadlines or immutable APIs changed. Actions are flushed before each single status/metrics observation. Mismatches fail; there is no status polling. Caller-provided integer clocks are read at action/read/drain/final boundaries; the new peer uses increasing synthetic integer time and retains the original case/whole deadlines. DATA and captured metadata are bounded and streaming hash/counter state replaces DATA/read histories.

## Files and comparisons

Added `metadata_cases.py`, `concurrent_cases.py`, `test_metadata_concurrency.py`.

Changed `adapter.py` only for the two primary stream bindings and concrete dispatch branches; `cases.py` only for the exact supported tuple and truthful 25-case description; `test_pause.py`, `test_admission.py`, `test_continue_quota.py` only for Root-authorized unsupported counts17->15; `test_imports.py` for the exact 23-module inventory. Existing assertions and rejection loops remain. No other existing module changed.

`completion/source-comparison.json` compares all current module hashes against the authoritative 20-module B5a root completion audit: **3 added, 6 changed, 0 missing, 14 unchanged**, 23 total. `completion/source.diff` is the full final source comparison using the matching B5a completion snapshot. `completion/snapshot/` and `snapshot-sha256.txt` retain every final current module. The preceding self-review snapshot remains separately under `pre-nesting-cleanup-snapshot/` with its comparison/hash list.

No core/model/fixture/product/dependency file was edited. No native build/server/socket/SSLContext/TLS/real-clock/process-ownership/transfer/descriptor/kernel/scheduling/race/panic/leak probe, old live entrypoint, external model CLI, subagent, Git operation or public delivery was run.

## Independent serialized checks and their limits

The new test decodes actual public-codec request HEADERS using the pinned HPACK decoder and checks exact ordered multiplicity, method, scheme, authority, regular host, target/query, declarations, Expect and HEADERS END. It checks initial headers separately from the exact terminal trailers, trailer ordinal/END, every DATA span/ordinal/END/payload, per-stream byte totals and canonical SHA256 `7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5`. It checks settings ACK count, reset count, finite barrier order, legitimate held states, pending primary, resumed accepted-prefix hash, distinct routes and refused retention/retirement.

The independently written contract check compares the current immutable metadata contract against source values for 66 headers with storage64+2, 17 captures with storage16+1, exact ordered tag/p01..p16 capture entries, missing case-sensitive capture `P16`, exact query pairs, the five helpers `(json, validate_json, validate_json_detailed, form, multipart)`, BodyNotBuffered refusal, empty text/bytes, untouched issue field/kind/pointer/length and allocator_used0. Source helper execution is still in immutable metadata/profile.zig and combined fixture metadata.zig. Actual helper outcomes in this test are supplied through synthetic status/body counters; no Zig helper was executed and these counters are not independent fixture correctness evidence.

A metadata connection and then a fresh concurrent connection share one caller-owned synthetic application and selected-before state. Existing final collection validates all67 body records plus metrics, preserving all five new records and every untouched record. Model-derived peer records are explicitly supplied synthetic inputs, not a second expected-state model or native observations.

Targeted synthetic peer negatives reject: each of five metadata/helper observations; nonzero paused bytes; false pause state; early final before resume; corruption of an unrelated record at final collection; wrong503; unexpected100 on refused stream; reset before final; reset code2 instead of0; wrong active count; wrong paused count; wrong slot count; wrong resumed prefix hash; contamination of holder metadata by the independent upload. All checks run normally and with -O. Seven additional direct synthetic **test-oracle sensitivity controls** reject omitted host, duplicate host, initial trailer contamination, initial END, wrong method, changed target/query and changed declaration. Those direct oracle controls are accurately limited to the checker; they are not additional serialized/native runs or behavioral RED.

## RED, intermediate results and self-review

The full initial serialized schedule test was authored and retained as `completion/initial-test.py` before any runtime implementation edit. Its actual preimplementation run is `completion/red.{stdout,stderr,exit}`: exit1, stdout empty, ending `ValueError: case schedule not implemented` from selection. This is **selection-only RED**, not a serialized-behavior failure. No stronger preimplementation behavioral RED is claimed and no mutation-as-RED experiment was run. The original actor's similarly limited RED remains unchanged.

After implementing metadata, the actual positive serialized metadata run including final collection passed: `metadata-first.*`, exit0, stderr empty, stdout `metadata_helpers passed: heads=6 small=6 flow=32`. Concurrency was implemented after that pass.

`combined-first.*` retains both positive schedule passes and all preceding negative results, followed by exit1 because the new test expected `invalid HEADERS` for wrong refusal status. The existing wire status validator actually rejects earlier with `wrong final status`; only this expected diagnostic was corrected. `combined-second.*` then reaches reset-code negative before exit1 because the expected diagnostic was `invalid reset`; the raw observer's actual diagnostic is `wrong reset code`, which was corrected. These are test diagnostic calibration failures, not immutable-core defects and not gate weakening. `combined-third.*` passes the complete new test before final cleanup.

A subsequent strict AST self-review identified maximum control nesting5 in the new test's elif chains. The first metadata audit reported:

```text
source comparison: 3 added, 6 changed, 0 missing, 14 unchanged; 23 total modules
immutable identities matched: 119; retained families=41 core=26 runtime=19; model=6 fixture=25 helper=1 codec=42
maximum control nesting concurrent_cases.py: 2
maximum control nesting metadata_cases.py: 1
maximum control nesting test_metadata_concurrency.py: 5
RuntimeError: new module nesting exceeds three
```

The combined console transcript is retained in `nesting-initial-console.txt`. This was an actual metadata/AST check failure, not behavioral RED. The earlier source snapshot preserves that version. Response/request dispatch was flattened with early returns and frame dispatch was separated from the receive-buffer loop. No schedule, expectation or threshold changed. Final strict AST depth is2/1/3 respectively. The affected new test and all-module inert-import proof were rerun normally and with -O after this last source edit. The other28 successful matrix checks cover unchanged files and runtime behavior; unrelated suites were not repeated for the test-only cleanup.

Self-review checked source contracts, ownership, serialized wire ordering, tests, import effects, bounds, error propagation, deadlines and gate integrity. New modules contain no classes, custom exceptions, assertion proof, hidden mutable globals, dead constants or comments restating code. All23 delivered modules have main guards and pass actual empty/foreign-argv silent/inert imports with rejecting caller-owned file/network/process/clock effects. This is self-review; Root's independent review remains required.

One exploratory `cat` of a guessed `evidence/b5a/completion/source-audit.json` returned missing-file exit1; that file was never a test or RED. The actual baseline authority was subsequently used: task-5e3b5a-root-completion-audit.json and its matching source snapshot. An ephemeral test-authoring script was removed after use; no additional executable helper is delivered.

## Commands and raw evidence

Every direct Python editing/metadata/test invocation used `/home/codespace/.python/current/bin/python3 -B -S`; optimized tests add `-O`. No Zig optimization mode applies. Every normal/optimized test receipt has separate raw stdout, stderr and exit files under completion/.

The first source query used the mandated graphify prefix **before the first source-file read/search**. Its raw stdout/stderr are `graphify.stdout/stderr`; the enclosing command returned0. The first command did not separately save the query exit. The same query was subsequently repeated with separate raw stdout/stderr/exit at `graphify-repeat.*`; it returned0. Both outputs are graph navigation only, not runtime proof.

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "Where are combined HTTP2 metadata_helpers concurrent_routes schedules and finite status metric adapter seams?" --budget 650
```

All tests used:

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

The initial RED, three combined intermediate checks and final current checks execute the same relative test file:

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py
```

The metadata-first command was exactly:

```sh
/home/codespace/.python/current/bin/python3 -B -S -c "import test_metadata_concurrency as t; t.check('metadata_helpers', final=True)"
```

The full changed-seam regression matrix ran each named module once in each mode, with individual raw captures `normal-<test>.*` and `optimized-<test>.*`:

```sh
for test_name in test_selection test_adapter test_ready test_async test_large test_final test_time test_shared test_negative test_pause test_admission test_continue_quota test_credit test_metadata_concurrency test_imports; do
    /home/codespace/.python/current/bin/python3 -B -S ".uwz-work/evidence/h2-streaming/integration-owned/combined-cases/$test_name.py"
done
for test_name in test_selection test_adapter test_ready test_async test_large test_final test_time test_shared test_negative test_pause test_admission test_continue_quota test_credit test_metadata_concurrency test_imports; do
    /home/codespace/.python/current/bin/python3 -B -S -O ".uwz-work/evidence/h2-streaming/integration-owned/combined-cases/$test_name.py"
done
```

After test-only nesting cleanup, exactly the affected tests were repeated with raw captures `cleanup-normal-<test>.*`, `cleanup-optimized-<test>.*`:

```sh
for test_name in test_metadata_concurrency test_imports; do
    /home/codespace/.python/current/bin/python3 -B -S ".uwz-work/evidence/h2-streaming/integration-owned/combined-cases/$test_name.py"
    /home/codespace/.python/current/bin/python3 -B -S -O ".uwz-work/evidence/h2-streaming/integration-owned/combined-cases/$test_name.py"
done
```

Shell capture format in each actual loop was `> completion/<stem>.stdout 2> completion/<stem>.stderr`, then `$?` was written separately to `<stem>.exit`. `final-results.json` retains the exact30 final applicable receipt identities, full raw stdout, exits and stderr byte counts. All30 are0 with empty stderr; 34 total successful matrix/cleanup executions were captured.

| Test | Normal exit | -O exit | Stderr |
| --- | ---: | ---: | --- |
| test_adapter | 0 | 0 | empty |
| test_admission | 0 | 0 | empty |
| test_async | 0 | 0 | empty |
| test_continue_quota | 0 | 0 | empty |
| test_credit | 0 | 0 | empty |
| test_final | 0 | 0 | empty |
| test_imports | 0 | 0 | empty |
| test_large | 0 | 0 | empty |
| test_metadata_concurrency | 0 | 0 | empty |
| test_negative | 0 | 0 | empty |
| test_pause | 0 | 0 | empty |
| test_ready | 0 | 0 | empty |
| test_selection | 0 | 0 | empty |
| test_shared | 0 | 0 | empty |
| test_time | 0 | 0 | empty |

The final new-suite raw stdout is:

```text
metadata helper/overflow contract checked; seven synthetic header oracle controls rejected
metadata_helpers passed: heads=6 small=6 flow=32
concurrent_routes passed: heads=13 small=13 flow=96
helpers_begin rejected: record mismatch: helpers_begin
helpers_end rejected: record mismatch: helpers_end
metadata_middleware rejected: record mismatch: metadata_middleware
metadata_begin rejected: record mismatch: metadata_begin
metadata_end rejected: record mismatch: metadata_end
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
refusal_status rejected: wrong final status
refusal_continue rejected: invalid HEADERS
reset_first rejected: reset order
reset_code rejected: wrong reset code
active_count rejected: concurrent active barrier differs
paused_count rejected: concurrent active barrier differs
slot_count rejected: concurrent active barrier differs
resume_prefix rejected: record mismatch: sha256
route_contamination rejected: record mismatch: metadata_begin
15 unsupported cases rejected before actions
```

An additional pinned `python3 -B -S -` metadata invocation loaded all47 retained completion initial/pre-cleanup/final-snapshot helpers under both empty and foreign argv, with the same rejecting caller effects and rejecting stdout/stderr. `auxiliary-inert-imports.{stdout,stderr,exit}` retain exit0, empty stderr and exact stdout `47 retained initial/snapshot helpers imported silently and inertly under empty and foreign argv`. These imports add no schedule/fixture acceptance claim.

Both final import proofs print exactly `AST and inert import checks passed`, exit0, stderr empty. The unchanged large-upload regression still uses both canonical100000000-byte payloads with streaming hashes, not estimates or flow-only zero blocks.

Pinned Python stdin metadata operations produced the final snapshot/comparison, difflib source comparison, complete immutable identity audit and raw result collection. `final-audit.stdout/stderr/exit` retain the final result: exit0, empty stderr, and:

```text
maximum control nesting concurrent_cases.py: 2
maximum control nesting metadata_cases.py: 1
maximum control nesting test_metadata_concurrency.py: 3
source comparison: 3 added, 6 changed, 0 missing, 14 unchanged; 23 total modules
immutable identities matched: 119; retained families=41 core=26 runtime=19; model=6 fixture=25 helper=1 codec=42
final result set: 30 normal/optimized checks exit 0, all stderr empty
```

Graph refresh used the prescribed prefix and `graphify update .`, with separate raw `graph-update.*` and `graph-update-final.*` receipts. It is AST-only and reports no relevant changes because these working evidence modules are ignored by graph extraction. No external API/key or semantic model was used.

No Zig build/fmt/sanitizer/fuzz/native/protocol-server gate was run: this task explicitly limits execution to pure Python codecs/controls/resets and prohibits native/build execution. There is no performance claim. MSan/ASan results are not claimed.

## Source identities

`completion/immutable-inputs.json` rechecks all41 retained family identities bound by task-5e3b-input-audit.json, all26 immutable v9 core files, all19 prior runtime source-only files, all25 fixture files, all6 model publication files and the helper. Its42 codec rows exactly retain the pinned aggregate SHA256. Final rechecks match all119 audit entries.

The model is `/tmp/uwz-task5e1-contract-v3`: catalogue SHA256 `7fa639c9372c8f01002fefba3647b2f82381e798484441d4b46c20d5d732453d`, model SHA256 `ebb6164c01617045b6120a00977aeae88609053318f89b1891d9ede5c89b8175`. Core remains `/tmp/uwz-task5e3a-snapshot-v9/source`; its published archive SHA256 is `74c1f96d1334d7e87b8f0e5fbeacfd39539d44c16e7fa6cb7702371e1dba442a` (archive value retained from the binding audit; core files were rehashed). Fixture `/tmp/uwz-task5e2-Fix1Final2/fixture` was read and rehashed only.

Authoritative credit/fix1 cases/profile/run_live hashes are respectively `77897c3ccbe4433641f08283f3556e5ff5543d04f0b137a14c42421e38918388`, `a370cb6c5a846ff0f628ebb7e76871f933cd5751249cfcb2d3a3898ebf3ef745`, `a69428257d582508dff18972c04ed4bdb22a124b1d12b3e2ede19857bf87d016`. Metadata cases/profile hashes are `d823af892f7ee77377cdd2d22686971e1cffd1c57788ca924c47efaf4ab53585`, `c12ecc91a886f015f46bc809284666d46195d786536a28a8de49e548d6fe85b1`.

Pinned helper SHA256 is `07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`. All42 codec files under `/tmp/uwz-h2-client-tooling/packages` match aggregate `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`, computed using the retained recipe SHA256(JSON ordered `(relative_path,file_sha256)` rows). No dependency fetch/install occurred.

| Final current module | SHA256 |
| --- | --- |
| adapter.py | `22ffbeff5bc7346e4f04463549af81ff2209d350d2f54683eae12761e7054421` |
| admission_cases.py | `b4cac4031f9be16bca938f7167bb327f4eae4fd5667b42cb70fc23782f8fbbcf` |
| cases.py | `395f1eabcded77786ffe857c342206f673b3d8a9275120bde98ac320b52c07ab` |
| concurrent_cases.py | `a9ab3e7b6f6a362c1c6d33788fa8b7c3ed5961989be1f58d7fd6cc66a998a7c1` |
| continue_quota_cases.py | `da533ef0fde4179c00427d11b689cba1fdf248e41ba01c98a47f37a08ec99e95` |
| credit_cases.py | `f953e2bacb92c4370904cf2b6e302a215aed9bd28210290406aac965e8d2178d` |
| metadata_cases.py | `7a48599c53779a2414f4492371174d35030e91d1dd61570408248b7eae12b83c` |
| pause_cases.py | `c7e28527478f3a3e52de22de019e1698083a8d03b4bca3100dd4788e77a8f250` |
| test_adapter.py | `d90f788f720c003060a71e481cf2dc2d411f991c9db71572a3279b0fe9b51290` |
| test_admission.py | `6abd01553bf0e4c96effe2eb6abc2eb6cfa2a2f4d2fda4ef55002005438d3e57` |
| test_async.py | `bcf31ec8037b3ba4861d25e7983efaeef269df5c084dc3922cc358d8e94ae314` |
| test_continue_quota.py | `cd2713a278e503ebf8c5d9cfee8eea706594f54d07f510229f3433300548c664` |
| test_credit.py | `bd03e99dbe6d1297bc96badf870c4be7486ef2524a14befd323bbebb8a9e0a65` |
| test_final.py | `bbcd200d37e232ca43fb417b4a757d88fe86bb186319f64bd4bf99e534ded694` |
| test_imports.py | `9649cc539e37f4cc5f0e023d645a46ff47c0e0ce4f3df12304cd83244a916977` |
| test_large.py | `5710cb5be11f777f2c0ba4f0b3a647227f75b5955dcf1f8cecd750419b46c7d0` |
| test_metadata_concurrency.py | `62d13cbae62b052f3acf9562db953bd92ad51ba675073276989a2bcd601e6531` |
| test_negative.py | `91ae248806c1402bd4219474c3e08e1ef2fcb5994d3e6f7b5e7f40fac4ec47f0` |
| test_pause.py | `ec6036b39ad2a98a906d5f061ea4793ed760e47285e444ab2f1702298a058499` |
| test_ready.py | `600ec8b0bc072aa4d9a52417425e77c56edc2e02680bdb01d9d288c52001b442` |
| test_selection.py | `748de021bec6e481702c6bac57c2a92722f16f32410dd25538d983fd25e22212` |
| test_shared.py | `cbd3370c4dd56990c126939503a35dd5eabd8a03ce71195865152510a973b91b` |
| test_time.py | `0e10a1c68bfdd754b67a656bd8f4cc05ca8fcf8c9af63ab66130e2e969edf967` |

## Remaining facts and parent note

No immutable API blocker was found. The missing explicit host from the previous actor's starting test was an omitted model contract entry and is now supplied correctly. Helper outcome/overflow correctness still requires eventual real fixture execution; this unit validates exact serialized stimuli and supplied synthetic diagnostics only. Root must independently review this diff and evidence before acceptance or delivery.

Parent note: metadata_helpers and concurrent_routes now add two concrete source schedules and five persistent records to the previously earned23-source subset. The supported subset is25; the remaining15 are rejected before actions. B5 still lacks its six cancellation/application schedules; B5/all40, default/aggregate/native execution and every original2.2.0 milestone remain incomplete. The original partial B5b and B5 parent reports are preserved; this completion report supersedes only the B5b implementation status.
