# Task5e3b5b completion: replacement implementation owner

Read task-5e3b5b-brief.md first: it remains the requirements, together with
task-5e3b-release-addendum.md. This addendum provides a concrete source handoff
after the original actor terminated incomplete. Do not repeat or claim its
selection-only RED as behavioral proof. Preserve its partial report and
evidence/b5b/initial-test.py plus red/graphify receipts intact.

Base remains pushed commit68fa32bd374a8c8965f4e2f74b6c0dd9efef742a.
All20 current modules match task-5e3b5a-root-completion-audit.json. No runtime
source edits or actual immutable API blocker were produced by the old actor.
Implement both assigned cases, not a mapping-only report or another initial
test handoff. Start with metadata, finish its actual serialized schedule and
covering test, then complete concurrency. Both original budgets and all five
records remain mandatory. Root owns independent review, publication and Git.

## Located source facts

Reference metadata/cases.py executes one POST to the model target, sends two
16-byte payload spans without END, sends trailers after the second span, then
makes the second finite paused status barrier. Both barriers require begins1,
bytes0,chunks0,ends0,cancels0,pausedtrue and a pending primary. Resume then finish.
The trailers are x-h62=changed and x-trailer-only=discarded. Preserve exact
initial metadata and all current model helper/overflow/middleware/begin/end
checks through the actual status validation, not fabricated diagnostics.

model.request_contract lines221..228 provides the entire target, header,
capture, storage and helper contract. Crucially header_entries explicitly ends
with ('host','localhost'). The old initial test omitted that explicit regular
host header. adapter.start already emits :authority localhost. No new authority
API or immutable-core defect follows from this omission; construct the current
model's actual header entries in exact source order (content-length, x-mode,
x-h00..x-h62, host). Check serialized multiplicity and the initial/trailer
separation independently. Source helper validations remain in profile.zig.

Reference credit/fix1/cases.py concurrent_routes executes:
hold request, first16DATA, paused barrier; refused request with Expect and
declared1, final503/reset retained; independent upload request; active2 metric
barrier;32DATA+END and finish upload; health; holder paused barrier; resume;
holder16accepted-ready barrier; final16DATA+END and finish holder; recovery
request32DATA+END and finish; health; retire refused; final health.
Exact target/query/metadata are model.request_contract/located source. Do not
infer a primary stream number from its tag; request-order bindings matter.

Both functions in references are tiny and located. Read them directly after
the required graphify query, then reuse actual earned status, metrics, resume,
trailer, retained-refusal and final collection seams. No broad architecture
rediscovery or old native entrypoint execution.

## Finish and report

Use the exact pinned Python -B -S for editing/metadata/testing as well as normal
and optimized checks. Keep evidence/b5b/original receipts; put new captures in
evidence/b5b/completion/. Retain actual new initial test/preimplementation
failure if obtained, and qualify its exact scope. No invented behavioral RED.
Complete the two schedules and serialized positive/targeted negative proofs,
changed-seam regressions, all-module AST/inert imports and exact final snapshot.
Model-derived supplied records are pure synthetic inputs, never native proof.

Write full task-5e3b5b-completion-report.md alongside this brief, preserving
task-5e3b5b-report.md as the original partial handoff. Include all exact commands,
raw evidence/results/failures, source identities and self-review; return only
concise DONE/real concerns/report path/test summary. Do not stop after one
selection check. A genuine smallest-call immutable API defect must be reported
with evidence while independently implementable work continues.

You are not alone. Do not revert others' edits. No subagents, external model
CLI, Git, public delivery, product/model/core/fixture mutation or native/build/
socket/SSLContext/real-clock/process/ownership/transfer/fault/cancel/scheduling/
descriptor/kernel/race/panic/leak experiment. Pure in-memory public codecs and
caller-owned synthetic control/reset tests only. Full all40 and every original
milestone remain required; this source unit alone cannot earn them.
