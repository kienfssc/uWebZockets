"""Exercise the metadata upload through the bound public codec."""
import adapter
import h2_client
import model
import test_ready


def main():
    sent = []
    context = adapter.open_case("metadata_helpers", h2_client.new_protocol(), sent.append, 1, 30001, 900001, clock=lambda: 2)
    settings = b"".join(k.to_bytes(2, "big") + v.to_bytes(4, "big") for k, v in ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b""), 2)
    contract = model.request_contract("metadata_helpers")
    stream = adapter.start(context, contract["method"], contract["target"], contract["header_entries"][:-1], False, True, 4095, held=True)
    adapter.send_data(context, stream, model.payload_span(32, 0, 16), False)
    if len(sent) < 2:
        raise RuntimeError("serialized request missing")


if __name__ == "__main__":
    main()
