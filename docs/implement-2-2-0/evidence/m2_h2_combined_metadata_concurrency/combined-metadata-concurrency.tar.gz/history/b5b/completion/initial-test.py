"""Serialized metadata and concurrent-route schedules with supplied synthetic records."""
import hashlib
import json
import adapter
import cases
import catalogue
import h2_client
import hpack
import model
import test_ready


def terminal(tag):
    item = model.record(tag, True, 'after')
    if item['bytes']:
        item.update(chunks=2 if tag in ('metadata_helpers', 'concurrent_hold') else 1,
                    max_span=16 if tag in ('metadata_helpers', 'concurrent_hold') else 32)
    return item


def expected_headers(tag):
    if tag == 'metadata_helpers':
        return [('content-length', '32'), ('x-mode', 'begin_paused')] + [
            ('x-h%02d' % n, 'v%02d' % n) for n in range(63)] + [('host', 'localhost')]
    extra = {'concurrent_hold': [('x-metadata', 'hold-metadata')],
             'concurrent_refused': [('expect', '100-continue')],
             'concurrent_upload': [('x-metadata', 'upload-metadata')], 'concurrent_recovery': []}
    return [('content-length', '1' if tag == 'concurrent_refused' else '32')] + extra[tag]


def target(tag):
    if tag == 'metadata_helpers':
        return '/meta/metadata_helpers/' + '/'.join('a%02d' % n for n in range(1, 17)) + '?q=alpha&n=17'
    return {'concurrent_hold': '/limit/concurrent_hold?case=hold',
            'concurrent_refused': '/limit/concurrent_refused',
            'concurrent_upload': '/upload/concurrent_upload?case=upload',
            'concurrent_recovery': '/limit/concurrent_recovery'}[tag]


def paths(case):
    if case == 'metadata_helpers':
        return ['/health', target(case), '/status/' + case, '/status/' + case,
                '/resume/' + case, '/health']
    return ['/health', target('concurrent_hold'), '/status/concurrent_hold',
            target('concurrent_refused'), target('concurrent_upload'), '/metrics', '/health',
            '/status/concurrent_hold', '/resume/concurrent_hold', '/status/concurrent_hold',
            target('concurrent_recovery'), '/health', '/health']


def check(case, *, app=None, prior=(), final=False, fault=None):
    decoder, encoder = hpack.Decoder(), hpack.Encoder()
    if app is None:
        app = {'records': {tag: model.record(tag, False, 'before') for tag in model.SPECS}, 'heads': 0}
    state = dict(startup=True, buffer=bytearray(), pending=[], heads=0, streams={}, payloads={},
                 resumed=False, statuses=0, trailers=0, settings=0, resets=0, metrics=0, final=False)
    order = paths(case)

    def response(stream, body, status='200', reset=False):
        block = encoder.encode(((':status', status), ('x-middleware', 'retained')))
        end = test_ready.frame(1, 5, stream, block)
        rst = test_ready.frame(3, 0, stream, (2 if fault == 'reset_code' else 0).to_bytes(4, 'big'))
        if reset and fault == 'reset_first':
            state['pending'].append(rst + end)
        elif reset and fault == 'refusal_continue':
            info = encoder.encode(((':status', '100'),))
            state['pending'].append(test_ready.frame(1, 4, stream, info) + end + rst)
        elif reset:
            state['pending'].extend((end, rst))
        else:
            state['pending'].append(test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body))
        state['resets'] += int(reset)

    def done(stream, tag):
        app['records'][tag] = terminal(tag)
        if fault in ('helpers_begin', 'helpers_end', 'metadata_middleware', 'metadata_begin', 'metadata_end') and tag == 'metadata_helpers':
            app['records'][tag][fault] = 0
        if fault == 'other_record':
            app['records']['empty_headers']['middleware'] = 1
        response(stream, json.dumps(app['records'][tag]).encode())

    def status_record(tag):
        item = dict(app['records'][tag])
        if not state['final'] and tag in ('metadata_helpers', 'concurrent_hold'):
            state['statuses'] += 1
            upload = next(stream for stream, name in state['streams'].items() if name == tag)
            count = state['payloads'][upload]['count']
            expected = (16 if state['statuses'] == 1 else 32) if case == 'metadata_helpers' else 16
            if count != expected or state['statuses'] > (2 if case == 'metadata_helpers' else 3):
                raise RuntimeError('status DATA ordinal differs')
            if case == 'metadata_helpers' and state['trailers'] != int(state['statuses'] == 2):
                raise RuntimeError('status trailer ordinal differs')
            if fault == 'paused_bytes' and not state['resumed']:
                item['bytes'] = 1
            if fault == 'not_paused' and not state['resumed']:
                item['paused'] = False
            if fault == 'resume_prefix' and state['resumed']:
                item['sha256'] = model.EMPTY_HASH
            if fault == 'helpers_begin' and tag == 'metadata_helpers':
                item['helpers_begin'] = 0
        return item

    def metrics(stream):
        state['metrics'] += 1
        values = {key: sum(item[key] for item in app['records'].values()) for key in model.COMMON_COUNTERS + ('bytes',)}
        active = sum(item['active'] for item in app['records'].values())
        paused = sum(item['paused'] for item in app['records'].values())
        values.update(active=active, paused=paused, buffered_middleware=app['heads'] - values['middleware'],
                      slot0_active=active > 0, slot1_active=active > 1)
        if not state['final'] and (active, paused, state['statuses']) != (2, 1, 1):
            raise RuntimeError('active metric ordinal differs')
        if fault == 'active_count' and not state['final']:
            values['active'] = 1
        if fault == 'paused_count' and not state['final']:
            values['paused'] = 0
        if fault == 'slot_count' and not state['final']:
            values['slot1_active'] = False
        response(stream, json.dumps(values).encode())

    def request(path, stream):
        if path == '/health':
            response(stream, b'ok')
        elif path.startswith('/status/'):
            response(stream, json.dumps(status_record(path[8:])).encode())
        elif path == '/metrics':
            metrics(stream)
        elif path.startswith('/resume/'):
            tag = path[8:]
            if state['resumed'] or state['statuses'] != 2:
                raise RuntimeError('resume ordinal differs')
            state['resumed'] = True
            response(stream, b'ok')
            upload = next(s for s, name in state['streams'].items() if name == tag)
            if tag == 'metadata_helpers':
                done(upload, tag)
                return
            item = app['records'][tag]
            item.update(bytes=16, sha256=hashlib.sha256(model.payload_span(32, 0, 16)).hexdigest(),
                        chunks=1, max_span=16, paused=False)
        else:
            raise RuntimeError('unexpected auxiliary request')

    def upload_headers(entries, stream, flags, tag):
        if entries != [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', target(tag))] + expected_headers(tag) or flags != 4:
            raise RuntimeError('upload header multiplicity or target differs')
        state['streams'][stream] = tag
        state['payloads'][stream] = dict(count=0, frames=0, digest=hashlib.sha256())
        if tag == 'concurrent_refused':
            app['records'][tag] = terminal(tag)
            response(stream, b'', status='200' if fault == 'refusal_status' else '503', reset=True)
            return
        item = terminal(tag)
        item.update(bytes=0, sha256=model.EMPTY_HASH, chunks=0, max_span=0, ends=0, active=True)
        if 'metadata_end' in item:
            item['metadata_end'] = 0
        if 'helpers_end' in item:
            item['helpers_end'] = 0
        item['paused'] = tag in ('metadata_helpers', 'concurrent_hold')
        app['records'][tag] = item

    def headers(packet, stream, flags):
        entries = list(decoder.decode(packet[9:]))
        if stream in state['streams']:
            if state['streams'][stream] != 'metadata_helpers' or entries != [('x-h62', 'changed'), ('x-trailer-only', 'discarded')]:
                raise RuntimeError('trailer fields differ')
            if flags != 5 or state['trailers'] or state['payloads'][stream]['frames'] != 2:
                raise RuntimeError('trailer END or ordinal differs')
            state['trailers'] += 1
            return
        path = dict(entries)[':path']
        index = state['heads']
        if index >= len(order) or path != order[index]:
            raise RuntimeError('request order differs')
        state['heads'] += 1
        app['heads'] += 1
        if path in (target(tag) for tag in (('metadata_helpers',) if case == 'metadata_helpers' else ('concurrent_hold', 'concurrent_refused', 'concurrent_upload', 'concurrent_recovery'))):
            tag = 'metadata_helpers' if case == 'metadata_helpers' else path.split('/')[-1].split('?')[0]
            upload_headers(entries, stream, flags, tag)
            return
        if entries != [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)] or flags != 5:
            raise RuntimeError('auxiliary headers differ')
        request(path, stream)

    def data(packet, stream, flags):
        tag = state['streams'][stream]
        item = state['payloads'][stream]
        payload = packet[9:]
        ordinal = item['frames']
        split = tag in ('metadata_helpers', 'concurrent_hold')
        expected_flags = 0 if tag == 'metadata_helpers' or tag == 'concurrent_hold' and ordinal == 0 else 1
        length = 16 if split else 32
        if ordinal >= (2 if split else 1) or tag == 'concurrent_refused' or len(payload) != length or flags != expected_flags:
            raise RuntimeError('DATA length END or ordinal differs')
        if payload != model.payload_span(32, item['count'], length):
            raise RuntimeError('DATA payload differs')
        if tag == 'concurrent_hold' and ordinal == 1 and (not state['resumed'] or state['statuses'] != 3):
            raise RuntimeError('holder END before ready barrier')
        item['frames'] += 1
        item['count'] += length
        item['digest'].update(payload)
        if fault == 'early_final' and split and ordinal == 0:
            done(stream, tag)
        elif flags & 1:
            done(stream, tag)

    def send(data_bytes):
        if state['startup']:
            state['startup'] = False
            return
        state['buffer'].extend(data_bytes)
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
            if kind == 1:
                headers(packet, stream, flags)
            elif kind == 0:
                data(packet, stream, flags)
            elif kind == 4:
                if flags != 1 or size or stream:
                    raise RuntimeError('settings ACK differs')
                state['settings'] += 1
            else:
                raise RuntimeError('unexpected client frame')

    def receive():
        if not state['pending']:
            raise RuntimeError('missing synthetic response')
        return state['pending'].pop(0), 2

    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001,
                                selected_before=prior, clock=lambda: 2)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), 2)
    adapter.run_case(context, receive)
    if state['heads'] != len(order) or state['settings'] != 1 or state['resets'] != int(case == 'concurrent_routes') or state['pending'] or state['buffer']:
        raise RuntimeError('case count or pending bytes differ')
    for stream, item in state['payloads'].items():
        refused = state['streams'][stream] == 'concurrent_refused'
        if item['count'] != (0 if refused else 32) or item['digest'].hexdigest() != (model.EMPTY_HASH if refused else model.H32):
            raise RuntimeError('payload hash or flow differs')
    if state['trailers'] != int(case == 'metadata_helpers'):
        raise RuntimeError('trailer count differs')
    if final:
        state['final'] = True
        order.extend('/status/' + tag for tag in model.SPECS)
        order.append('/metrics')
        adapter.final_collection(context, receive)
        if state['heads'] != len(order) or state['pending']:
            raise RuntimeError('final observations differ')
    print(case + ' passed: heads=%d small=%d flow=%d' % (context['stage']['limits']['heads'], context['stage']['limits']['small'], context['request']['case']['sent']))
    return app


def rejected(case, fault, message, *, final=False):
    try:
        check(case, fault=fault, final=final)
    except (ValueError, RuntimeError) as exc:
        if str(exc) != message:
            raise RuntimeError('fault rejected for wrong reason: ' + fault) from exc
        print(fault + ' rejected: ' + str(exc))
        return
    raise RuntimeError('fault accepted: ' + fault)


def main():
    app = check('metadata_helpers')
    check('concurrent_routes', app=app, prior=('metadata_helpers',), final=True)
    for fault in ('helpers_begin', 'helpers_end', 'metadata_middleware', 'metadata_begin', 'metadata_end'):
        rejected('metadata_helpers', fault, 'record mismatch: ' + fault)
    for case in ('metadata_helpers', 'concurrent_routes'):
        rejected(case, 'paused_bytes', 'record mismatch: bytes')
        rejected(case, 'not_paused', 'record mismatch: paused')
        rejected(case, 'early_final', 'invalid terminal')
        rejected(case, 'other_record', 'record mismatch: middleware', final=True)
    for fault, message in (('refusal_status', 'invalid HEADERS'), ('refusal_continue', 'invalid HEADERS'),
                           ('reset_first', 'reset order'), ('reset_code', 'invalid reset'),
                           ('active_count', 'concurrent active barrier differs'),
                           ('paused_count', 'concurrent active barrier differs'),
                           ('slot_count', 'concurrent active barrier differs'),
                           ('resume_prefix', 'record mismatch: sha256')):
        rejected('concurrent_routes', fault, message)
    remaining = [case for case in catalogue.CASES if case not in cases.IMPLEMENTED]
    if len(remaining) != 15:
        raise RuntimeError('unsupported inventory differs')
    for case in remaining:
        try:
            adapter.open_case(case, h2_client.new_protocol(), lambda _data: (_ for _ in ()).throw(RuntimeError('unsupported case acted')),
                              1, 30001, 900001, clock=lambda: 2)
        except ValueError as exc:
            if str(exc) != 'case schedule not implemented':
                raise
        else:
            raise RuntimeError('unsupported selection accepted')
    print('15 unsupported cases rejected before actions')


if __name__ == '__main__':
    main()
