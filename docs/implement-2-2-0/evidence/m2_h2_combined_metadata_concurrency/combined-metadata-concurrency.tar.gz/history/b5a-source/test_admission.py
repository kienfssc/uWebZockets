"""Serialized in-memory admission schedule checks."""
import hashlib
import json
import adapter
import cases
import catalogue
import h2_client
import hpack
import model
import test_ready


def completed(tag):
    result = model.record(tag, True, 'after')
    if result['bytes']:
        result.update(chunks=1, max_span=32)
    return result


def check(case, *, app=None, prior=(), final=False, fault=None):
    decoder, encoder = hpack.Decoder(), hpack.Encoder()
    if app is None:
        app = {'records': {tag: model.record(tag, False, 'before') for tag in model.SPECS}, 'heads': 0}
    state = {'startup': True, 'buffer': bytearray(), 'pending': [], 'paths': [], 'streams': {}, 'payloads': {}, 'barrier': False, 'status_seen': False}

    def response(stream, body, refusal=False):
        status = '413' if refusal else '200'
        block = encoder.encode(((':status', status), ('x-middleware', 'retained')))
        end = test_ready.frame(1, 5, stream, block) if refusal else test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body)
        reset = test_ready.frame(3, 0, stream, (0).to_bytes(4, 'big'))
        if refusal and fault == 'reset_first':
            state['pending'].append(reset + end)
        elif refusal and fault == 'continue':
            info = encoder.encode(((':status', '100'),))
            state['pending'].append(test_ready.frame(1, 4, stream, info) + end + reset)
        elif refusal and fault == 'refusal_data':
            state['pending'].append(test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, b'x') + reset)
        elif refusal:
            state['pending'].extend((end, reset))
        else:
            state['pending'].append(end)

    def done(tag, stream):
        app['records'][tag] = completed(tag)
        response(stream, json.dumps(app['records'][tag]).encode())

    def request(path, stream):
        if path == '/health':
            response(stream, b'ok')
        elif path == '/metrics':
            metrics = {key: sum(item[key] for item in app['records'].values()) for key in model.COMMON_COUNTERS + ('bytes',)}
            metrics.update(active=0, paused=0, buffered_middleware=app['heads'] - metrics['middleware'], slot0_active=False, slot1_active=False)
            response(stream, json.dumps(metrics).encode())
        elif path.startswith('/status/'):
            tag = path[8:]
            if case == tag == 'limit_observed_reject' and not state['barrier']:
                raise RuntimeError('status before accepted prefix')
            item = dict(app['records'][tag])
            if case == tag == 'limit_observed_reject':
                state['status_seen'] = True
                if fault == 'bad_prefix':
                    item['bytes'] = 31
            response(stream, json.dumps(item).encode())
        else:
            raise RuntimeError('unexpected request')

    def headers(packet, stream, flags):
        entries = list(decoder.decode(packet[9:]))
        values = dict(entries)
        path = values[':path']
        state['paths'].append(path)
        app['heads'] += 1
        if path.startswith(('/health', '/status/', '/metrics')):
            expected = [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)]
            if entries != expected or flags != 5:
                raise RuntimeError('auxiliary headers differ')
            request(path, stream)
            return
        tag = path.split('/')[-1]
        contract = model.request_contract(tag)
        expected = [(':method', contract['method']), (':scheme', 'https'), (':authority', 'localhost'), (':path', contract['target'])]
        if contract['declared'] is not None:
            expected.append(('content-length', str(contract['declared'])))
        declared_refusal = tag in ('limit_declared_reject', 'zero_declared_reject')
        if declared_refusal:
            expected.append(('expect', '100-continue'))
        end = tag in ('empty_headers', 'empty_declared', 'zero_declared_recovery', 'zero_observed_recovery')
        if entries != expected or flags != (5 if end else 4):
            raise RuntimeError('upload headers differ')
        state['streams'][stream] = tag
        state['payloads'][stream] = {'count': 0, 'hash': hashlib.sha256(), 'frames': 0}
        if declared_refusal:
            app['records'][tag] = completed(tag)
            response(stream, b'', refusal=True)
        elif end:
            done(tag, stream)

    def data(packet, stream, flags):
        tag = state['streams'][stream]
        payload = packet[9:]
        item = state['payloads'][stream]
        ordinal = item['frames']
        if tag == 'empty_data':
            expected = ((0, True),)
        elif tag == 'limit_observed_reject':
            expected = ((32, False), (1, False))
        elif tag == 'zero_observed_reject':
            expected = ((1, False),)
        else:
            expected = ((32, True),)
        if ordinal >= len(expected) or (len(payload), bool(flags & 1)) != expected[ordinal] or flags & ~1:
            raise RuntimeError('DATA ordinal differs')
        item['frames'] += 1
        item['count'] += len(payload)
        item['hash'].update(payload)
        if tag == 'limit_observed_reject' and ordinal == 1 and not state['status_seen']:
            raise RuntimeError('offending byte preceded status barrier')
        if tag == 'limit_observed_reject' and ordinal == 0:
            prefix = completed(tag)
            prefix.update(cancels=0, active=True, reason=None)
            app['records'][tag] = prefix
            state['barrier'] = True
        elif tag.endswith('_reject'):
            app['records'][tag] = completed(tag)
            response(stream, b'', refusal=True)
        elif flags & 1:
            done(tag, stream)

    def send(data_bytes):
        if state['startup']:
            state['startup'] = False
            return
        state['buffer'].extend(data_bytes)
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
            if kind == 1:
                headers(packet, stream, flags)
            elif kind == 0:
                data(packet, stream, flags)

    def receive():
        if not state['pending']:
            raise RuntimeError('missing synthetic response')
        return state['pending'].pop(0), 2

    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, selected_before=prior, clock=lambda: 2)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), 2)
    adapter.run_case(context, receive)
    expected = ['/health', model.request_contract(case)['target']]
    if case == 'limit_observed_reject':
        expected.append('/status/' + case)
    if case.endswith('_reject'):
        expected.append(model.request_contract(case.replace('_reject', '_recovery'))['target'])
    expected.append('/health')
    if final:
        adapter.final_collection(context, receive)
        expected += ['/status/' + tag for tag, _, _, _ in model.BODY_SPECS] + ['/metrics']
    if state['paths'] != expected:
        raise RuntimeError('request order differs')
    for stream, item in state['payloads'].items():
        tag = state['streams'][stream]
        expected_bytes = (model.payload_span(32, 0, 32) + b'x' if tag == 'limit_observed_reject' else
                          b'x' if tag == 'zero_observed_reject' else
                          model.payload_span(32, 0, 32) if tag.startswith('limit_') and not tag.endswith('_reject') else b'')
        expected_frames = 2 if tag == 'limit_observed_reject' else 0 if tag in ('empty_headers', 'empty_declared', 'zero_declared_recovery', 'zero_observed_recovery', 'limit_declared_reject', 'zero_declared_reject') else 1
        if item['frames'] != expected_frames or item['count'] != len(expected_bytes) or item['hash'].digest() != hashlib.sha256(expected_bytes).digest():
            raise RuntimeError('request body differs')
    print(case + ' passed: heads=%d flow=%d' % (context['stage']['limits']['heads'], context['request']['case']['sent']))
    return app


def main():
    names = adapter.ADMISSION_CASES
    if len([case for case in catalogue.CASES if case not in cases.IMPLEMENTED]) != 17:
        raise RuntimeError('unsupported inventory differs')
    for case in names:
        check(case)
    app, prior = None, ()
    for case in names:
        app = check(case, app=app, prior=prior, final=case == names[-1])
        prior += (case,)
    expected = {'reset_first': 'reset order', 'continue': 'invalid HEADERS',
                'refusal_data': 'response body bound', 'bad_prefix': 'record mismatch: bytes'}
    for fault, message in expected.items():
        try:
            check('limit_observed_reject' if fault == 'bad_prefix' else 'limit_declared_reject', fault=fault)
        except ValueError as exc:
            if str(exc) != message:
                raise RuntimeError('fault rejected for wrong reason: ' + fault) from exc
            print(fault + ' rejected: ' + str(exc))
        else:
            raise RuntimeError('fault accepted: ' + fault)


if __name__ == '__main__':
    main()
