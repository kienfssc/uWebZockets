"""Independently audit one recorded ordinary output run and its actual inputs."""
import base64
import hashlib
import json
import os
from pathlib import Path


ROOT = Path('/workspaces/uWebZockets')
WORK = ROOT / '.superpowers/sdd/h2_streaming_plan'
RUN = Path('/tmp/uwz-task5d3-host-attempt1/run')
TOTAL = 16777313
SENTINEL = b'final-upload-sentinel!'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(1048576):
            value.update(block)
    return value.hexdigest()


def periodic_hash(length, offset=0, suffix=b''):
    cycle = bytes(range(1, 252))
    value = hashlib.sha256()
    for index in range(0, length, 8192):
        size = min(8192, length - index)
        phase = (offset + index) % 251
        repeated = cycle * ((phase + size + 250) // 251)
        value.update(repeated[phase:phase + size])
    value.update(suffix)
    return value.hexdigest()


def check_record(row, tag, used, refused, body_hash, empty_hash):
    counters = ('accepted', 'attempts', 'begin', 'cancel', 'chunk_errors', 'chunks',
                'end', 'end_errors', 'errors', 'failure', 'invalid_progress', 'max_span',
                'metadata_begin', 'metadata_end', 'metadata_middleware', 'middleware',
                'stale_cancel', 'stale_resume')
    expected = dict.fromkeys(counters, 0)
    expected.update(tag=tag, active=False, paused=False, reason='none', sha256=empty_hash)
    if used:
        expected.update(middleware=1, metadata_middleware=1)
    if used and not refused:
        need(type(row['chunks']) is int and 1 <= row['chunks'] <= 32, 'body chunks')
        need(type(row['max_span']) is int and 1 <= row['max_span'] <= 32, 'body span')
        expected.update(accepted=32, attempts=1, begin=1, end=1, metadata_begin=1,
                        metadata_end=1, sha256=body_hash, chunks=row['chunks'], max_span=row['max_span'])
    need(row.keys() == expected.keys(), 'record keys')
    for key, value in expected.items():
        need(type(row[key]) is type(value) and row[key] == value, 'record ' + tag + '/' + key)


def producer(item, digest):
    need(item['armed'] is True and item['done'] is True and item['offset'] == TOTAL
         and item['sha256'] == digest and item['writes'] == (TOTAL + 8191) // 8192
         and item['terminals'] == 1 and item['errors'] == 0, 'producer completion')
    need(item['checks'] == item['invocations'] == item['pending'] + 1
         and item['blocked'] == item['pending']
         and item['blocked'] == item['attempts'] - item['writes'] + item['terminal_attempts'] - item['terminals'],
         'producer source counters')


def header(values, name, expected):
    need([value for key, value in values if key == name] == [expected], 'header ' + name)


def main():
    auth = json.loads((WORK / 'task-5d3-stage-b-authorization.json').read_text())
    manifest_path = Path(auth['manifest'])
    need(file_sha(manifest_path) == auth['manifest_sha256'], 'manifest identity')
    manifest = json.loads(manifest_path.read_text())
    for name, expected in manifest['inputs'].items():
        need(file_sha(name) == expected, 'direct input ' + name)
    for directory, expected in manifest['trees'].items():
        actual = {p.relative_to(directory).as_posix(): file_sha(p)
                  for p in sorted(Path(directory).rglob('*')) if p.is_file()}
        need(actual == expected, 'source tree ' + directory)
    result_path = RUN / 'result.json'
    result = json.loads(result_path.read_text())
    need(result['success'] is True and result['selection'] == auth['cases']
         and result['manifest_sha256'] == auth['manifest_sha256']
         and result['binary'] == auth['binary'] and result['binary_sha256'] == auth['binary_sha256']
         and result['binary_mode'] == 'debug', 'recorded run identity')
    for name in ('driver.stdout', 'driver.stderr'):
        need((RUN.parent / name).read_bytes() == b'', 'driver diagnostics')
    log = (RUN / 'server.log').read_bytes()
    need(log == bytes.fromhex(result['server_output_hex']) and len(log) <= 65536, 'server capture')
    nonce = result['nonce']
    lines = log.decode().splitlines()
    def markers(prefix):
        return [line.split(prefix, 1)[1] for line in lines if prefix in line]
    need(markers('H2_CAPACITY ') == [manifest['capacity'].removeprefix('H2_CAPACITY ')], 'capacity')
    need(markers('H2_READY ' + nonce) == [''], 'readiness')
    rows = [json.loads(value) for value in markers('H2_RECORD ' + nonce + ' ')]
    output = [json.loads(value) for value in markers('H2_OUTPUT ' + nonce + ' ')]
    totals = [json.loads(value) for value in markers('H2_DEINIT ' + nonce + ' ')]
    tags = ['producer_reuse', 'producer_reuse_next', 'output_pressure_window', 'output_pressure_ready',
            'stream_file', 'early_final_order', 'early_final_recovery'] + ['spare_%02d' % i for i in range(25)]
    body_hash = sha(bytes(range(1, 11)) + SENTINEL)
    empty_hash = sha(b'')
    producer_hash = periodic_hash(TOTAL - len(SENTINEL), suffix=SENTINEL)
    file_hash = periodic_hash(24593, offset=37)
    early_hash = sha(b'early-final-order')
    need(len(rows) == 32 and [row['tag'] for row in rows] == tags, 'record catalogue')
    for index, row in enumerate(rows):
        check_record(row, tags[index], index < 7, tags[index] == 'early_final_order', body_hash, empty_hash)
    expected_totals = dict(accepted=192, active=0, attempts=6, begin=6, buffered_middleware=63,
                           cancel=0, chunk_errors=0, end=6, end_errors=0, errors=0, failure=0,
                           invalid_progress=0, middleware=7, slot0_active=False, slot1_active=False)
    need(totals == [expected_totals] and result['sessions']['final']['records'] == rows
         and result['sessions']['final']['totals'] == expected_totals
         and result['post']['records'] == rows and result['post']['totals'] == expected_totals,
         'native/pre/post body observations')
    need(len(output) == 4 and result['post']['outputs'] == output, 'output catalogue')
    for item in output[:3]:
        producer(item, producer_hash)
    file = output[3]
    need(file['tag'] == 'stream_file' and file['arms'] == file['close_calls'] == file['closed_files'] == 1
         and file['transferred'] is True and file['caller_owned'] is False and file['arm_errors'] == 0
         and file['read_errors'] == file['invalid_spans'] == 0 and file['min_offset'] == 37
         and file['max_end'] == 24630 and file['reads'] >= 1 and file['requested'] >= file['returned'] >= 24593,
         'native file ownership/range')
    cases = result['sessions']['cases']
    need([item['case'] for item in cases] == auth['cases'], 'executed selection')
    spec = {'output_pressure_window': (5, TOTAL, producer_hash, 7, 8, 18243676),
            'output_pressure_ready': (5, TOTAL, producer_hash, 5, 6, 18243676),
            'producer_reuse': (3, TOTAL, producer_hash, 8, 9, 18243676),
            'stream_file': (5, 24593, file_hash, 6, 7, 1693852),
            'early_final_order': (7, 17, early_hash, 6, 40, 1447948)}
    primary_bytes = 0
    for case in cases:
        primary, size, digest, auxiliary, count, budget = spec[case['case']]
        facts = case['completions']
        need(len(facts) == count and sorted(item['stream'] for item in facts) == list(range(1, count * 2, 2)), 'response identities')
        need(case['stage']['acks'] == 2 and case['stage']['auxiliary'] == auxiliary
             and 0 < case['stage']['bytes'] <= budget and 0 < case['stage']['reads'] <= budget, 'case work')
        selected = [item for item in facts if item['stream'] == primary]
        need(len(selected) == 1, 'primary identity')
        item = selected[0]
        early = case['case'] == 'early_final_order'
        need(item['bytes'] == size and item['sha256'] == digest and item['end'] is True
             and item['reset'] is early and item['informationals'] == 0 and 'body_hex' not in item, 'primary bytes/terminals')
        header(item['headers'], ':status', '403' if early else '200')
        header(item['headers'], 'x-middleware', 'retained')
        if not early:
            header(item['headers'], 'content-type', 'application/octet-stream')
        if case['case'] == 'stream_file':
            header(item['headers'], 'content-length', '24593')
        for fact in facts:
            if 'body_hex' in fact:
                body = bytes.fromhex(fact['body_hex'])
                need(len(body) == fact['bytes'] < 4096 and sha(body) == fact['sha256'], 'retained small response')
        primary_bytes += size
    need(primary_bytes == 50356549 and sum(len(case['completions']) for case in cases) == 70, 'whole response accounting')
    window = cases[0]
    need([item['bytes'] for item in window['checkpoints']] == [0, 8192]
         and window['checkpoints'][1]['sha256'] == periodic_hash(8192)
         and all(item['end'] is False and item['reset'] is False for item in window['checkpoints']), 'window prefix barriers')
    reuse = cases[2]
    a_rows = [item for item in reuse['output_observations'] if item['tag'] == 'producer_reuse']
    b_rows = [item for item in reuse['output_observations'] if item['tag'] == 'producer_reuse_next']
    need(len(a_rows) == 3 and len(b_rows) == 1 and [item['offset'] for item in a_rows] == [0, 0, TOTAL]
         and all(item['pending'] > 0 and not item['done'] for item in a_rows[:2]), 'reuse held barriers')
    binding = [a_rows[0]['binding_index'], a_rows[0]['binding_generation'] + 1]
    need([b_rows[0]['binding_index'], b_rows[0]['binding_generation']] == binding == result['sessions']['binding']
         and output[0]['after_reuse'] >= 1, 'online binding reuse')
    need(markers('H2_BINDING ' + nonce + ' ') == ['tag=producer_reuse_next index=%d generation=%d' % tuple(binding)], 'binding log')
    early = cases[-1]
    need([item['bytes'] for item in early['checkpoints']] == [0, 8]
         and early['checkpoints'][1]['sha256'] == sha(b'early-fi')
         and all(item['end'] is False and item['reset'] is False for item in early['checkpoints'])
         and early['events'].get('StreamReset') == 1, 'early final ordering facts')
    final = result['sessions']['final']['stage']
    need(final['auxiliary'] == 33 and 0 < final['bytes'] <= final['budget'] <= 1487112 + 13 * 64, 'final work')
    setup = result['setup']
    for name in ('signalled', 'reaped', 'collector_joined', 'key_removed', 'transfer_removed'):
        need(setup.get(name) is True, 'cleanup ' + name)
    need(type(setup['exit_status']) is int and setup['exit_status'] == 0 and not setup.get('forced', False), 'normal exit')
    need(not Path('/proc', str(setup['pid'])).exists(), 'owned child remains')
    for name in ('private-key.pem', 'transfer.bin'):
        need(not os.path.lexists(RUN / name), 'temporary file remains')
    for name in ('/proc/net/tcp', '/proc/net/tcp6'):
        path = Path(name)
        if path.exists():
            need(not any(len(row.split()) > 9 and row.split()[9] == setup['listener']
                         for row in path.read_text().splitlines()[1:]), 'owned listener remains')
    certificate = ''.join(line for line in (RUN / 'certificate.pem').read_text().splitlines() if not line.startswith('-----'))
    need(sha(base64.b64decode(certificate, validate=True)) == setup['cert_hash'], 'certificate identity')
    audit = dict(status='PASS independently checked recorded native output evidence and actual post-run inputs',
                 result_sha256=file_sha(result_path), result_bytes=result_path.stat().st_size,
                 server_log_sha256=sha(log), server_log_bytes=len(log), cases=auth['cases'],
                 primary_response_bytes=primary_bytes, response_count=70, body_totals=expected_totals,
                 actual_file_observation=file, reuse_binding=binding, source_inputs_unchanged=True,
                 direct_inputs=len(manifest['inputs']), source_trees=len(manifest['trees']),
                 pid=setup['pid'], start=setup['start'], pid_absent=True, owned_listener_absent=True,
                 key_absent=True, transfer_absent=True, exit_status=0, reaped=True, forced_cleanup=False,
                 native_debug_attempts=1, native_release_safe_attempts=0,
                 full40_combined_executed=False, full_quality_gates_executed=False)
    (WORK / 'task-5d3-native-root-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps(audit, indent=2))


if __name__ == '__main__':
    main()
