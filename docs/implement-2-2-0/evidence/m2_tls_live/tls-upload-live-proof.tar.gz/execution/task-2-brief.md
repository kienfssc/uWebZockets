## Task 2: TLS fixture preparation and combined verification

Depends on Task1 reviewed code and accepted plaintext Task3b fixtures. Verification
owns NEW fixture/evidence paths only. Root owns combined copy/test-root/docs and
actual runtime release. Reuse fixed-capacity public sinks, independent output
producer context and owned client/server lifecycle. Generate ephemeral localhost
TLS material at runtime; never commit keys/certificates.

TLS clients require exact100000000 fixed and chunked with independent bounded
hash/count; TLS records larger than small ingress; begin/partial/final-byte and
framing/trailer pauses with explicit resume/no further data;100Continue after
accepted begin and strict no100/413/503 refusals; corrected failed-begin rollback;
split framing, limits, pipelines, producer metadata, real file fallback, ordinary
peer/close-notify/application-cancel/shutdown/end-error and once-only quota.
Keep legacy three echo cases, buffered/no-ALPN H1, healthy H2 and WS selection
with streaming configured; preserve replay rejection before streaming callbacks.
No allocator-wide absence claim without existing authorized evidence.

Combined independent review then applicable project gates remain mandatory:
fmt including builds, conventions, version/dependency/package checks, Debug,
ReleaseSafe compile, ASan/UBSan, existing MSan boundary smoke, bounded fuzz,
OSS-Fuzz objects/smoke, ReleaseFast/package consumer, h1spec and Autobahn plus
H2 regression coverage for shared dispatch. Cross compile is not Windows runtime.
No production adoption, capability flip or milestone completion from this unit.
