# Task 2a TLS fixture source preparation

Status: READY FOR SOURCE REVIEW. The public TLS profile compiles in ReleaseSafe
against the immutable plaintext acff baseline. This is API/link compatibility
only: it does NOT establish TLS upload functionality or validate Task1. All37
prepared network/API cases remain unexecuted. No certificate/key was generated,
server/client launched, port prechecked/contacted, or native experiment run.

Owned changes are only NEW `.uwz-work/evidence/h1-tls/integration/` and this report.
Plaintext fixtures, baseline/active implementation copies, production/config,
shared docs, refs and pins remain unchanged. No agent, commit, fetch, package,
new library build or maintained adoption was created. Root owns component review,
combined source, runtime release and later gates.

## Actual commands, results and identities

Final actual compile command from `/workspaces/uWebZockets`:

```sh
python3 .uwz-work/evidence/h1-tls/integration/compile.py --record compile-tls-baseline-r4 --output /tmp/uwz-h1-tls-profile-baseline-r4 --cache-root /tmp/uwz-h1-tls-profile-baseline-r2
```

Raw result: `Exit status: 0`. `compile-tls-baseline-r4.log` is empty. The explicit
compiler argv/cwd/environment and before-state are in `.command.json`; final
`.json` retains actual status, compiler/module/library/fixture pre/post hashes,
93-file override pre/post hashes and executable identity. The command invokes
Zig0.16.0 at `/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`,
ReleaseSafe, `-j2`, original r2 native C bindings, immutable c223 override and
existing native libraries. The cache-root is this SAME task's earlier r2 cache;
no predecessor cache, source tree, hardlink or symlink was copied. Binary/cache
outputs stay under `/tmp`. Earlier r1/r2/r3 source-preparation records and
preimages remain retained; r4 binds the final sources.

The complete1023 source before/after inventories are retained in
`compile-tls-baseline-r4-source-inputs.json` and `-source-after.json`, with equal
digests:

```text
acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b
```

All93 c223 override files match the immutable manifest before and after. All
recorded compiler/module-entry/native-library/fixture inputs are unchanged across
r4. This scope does not claim an inventory of every transitive external package.
`preparation.json` retains the final values and no-runtime qualification.

Final API-only binary: `/tmp/uwz-h1-tls-profile-baseline-r4/profile`

```text
sha256 f66a14d816440f37a3cb484daecd9171f1f7ddcb1f2da0e9c29dad90b2909229
```

Final fixture SHA256:

```text
profile.zig 7613991f81822c9b041cdb99b4f0c5e53ecce88dd18f7688c127892fab777b13
probe.py   0bbfba36bd9e9bfd51a48f094af5a62eb68670dded74fcd061a5a9997a9c040a
compile.py 26f2dbb7db70251b299ec60346ad0496794437c83ca6792263e9b50e0151218e
```

Other exact actual commands:

```sh
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check .uwz-work/evidence/h1-tls/integration/profile.zig
python3 .uwz-work/evidence/h1-tls/integration/verify_preparation.py
```

Formatter: exit0, raw output empty. AST/source check: exit0, raw output retained
in `ast-review.log`:

```text
Python AST syntax: passed; no harness import/execution
All25 plaintext request case entries retained; owned shutdown retained
TLS cases11 + original26 =37 prepared, none executed
Bounded payload/framing/hash helper ASTs unchanged
Only six approved API-abort cases can classify pre-final SSLEOFError
Public one-worker TLS setup; no private tls_ctx assignment
```

The checker normalizes only the old `port` parameter name to the explicit TLS
endpoint, then compares all25 original case entries; the owned shutdown remains
the26th baseline case. Payload/framing/hash helper ASTs remain unchanged.
`*.plaintext-preimage`, intermediate preimages, final unified diffs and actual
commands/logs are durable. The original plaintext fixture hashes still match
these captured preimages.

## Public setup, capacities and lifetime review

Root approved the public one-worker cluster setup after source inspection:
frozen `App.init_https` uses its default streaming-disabled configuration and
the builder has no configured single-App HTTPS constructor. The fixture uses
`Server.preset(...).build_cluster(...,1,...)`, public `worker(0)` for route
registration, `enable_https`, `listen`, `run`, then normal cluster deinit.
It never assigns App.tls_ctx, calls a private driver or adds a library API.
The separate configured-HTTPS DX plan remains with Root.

One worker owns every sink/control callback. All State, fixed route binding
slots, controls, definitions and independent producer context stay alive on the
main stack while the worker runs. The main thread reads final counters only
AFTER cluster.run joins and the cluster scope deinitializes its App. Final
snapshot/marker therefore retain actual owned join/deinit semantics.

Exact private public ServerConfig:

```text
workers1; connections8; streaming enabled
max_request_line_size512; max_header_size1024; max_body_size256
request_buffer_stride = align16(512+1024+1024+256) =2816
logical /upload max100000000; /limit max32; /empty max0; each max_active1
```

The status snapshot exposes these configured capacities. Coalesced/actual-record
cases retain their actual request head byte count and compute remaining physical
ingress as2816-head_bytes. The admission prefix leaves no body-sized allocation.
Caller-owned slots/SHA256/counting/metadata retain accepted-prefix semantics.
The outgoing producer context/scratch/initial expected copies are independent
of the upload binding; the post-reuse pending/progress checks remain mandatory.
No allocator call was added to chunk/end/producer. This is source inspection,
not a claim that TLS heaps, client libraries or all server allocations were
instrumented or absent.

The existing public static endpoint now reads only an owned `runtime/files`
directory. Ephemeral certificate/key paths stay OUTSIDE that static root. TLS
uses real static delivery fallback (`send_file` is unavailable on TLS), retaining
bounded file ownership/buffer behavior and exact16MiB+97 comparisons. No file,
completion or cleanup state is fabricated.

## TLS client and record evidence review

Main clients use normal Python stdlib SSLContext/SSLSocket, min=max TLS1.3,
CERT_REQUIRED/hostname verification through PROTOCOL_TLS_CLIENT, trusted ephemeral
localhost CA and server_hostname localhost. They require actual versionTLSv1.3,
selected ALPNhttp/1.1 (orNone in its separate no-ALPN case), and exact verified
peer DER SHA256. Actual version, ALPN, cipher, peer identity/hash, session-reused
value, endpoints, Python/ssl-module/extension identities and ssl library version
are recorded. Session reuse is NEVER treated as early-data evidence.

One additional record-retention case uses REAL public stdlib wrap_bio SSLObjects,
actual owned TCP packets and real handshake/verification. It does not fabricate
an SSL pointer/state/completion. After handshake and outgoing drain, exactly one
bounded plaintext write must be accepted fully. The client records the five-byte
header from its OWN generated ciphertext and requires pending == header_length+5,
proving exactly one actual output record. Its accepted plaintext write exceeds
the2816-byte stride. That record is sent unchanged; public HTTPS status must show
a begin-paused binding with accepted0, then normal HTTPS resume must finish7000
logical bytes without another application write on the upload connection.
Incoming TLS remains parsed/authenticated exclusively by stdlib SSL; the small
local-output metadata observation is not an inbound TLS parser/trust boundary.

The real BIO helper bounds TCP reads/writes to8192, cipher input to32768 and
verified HTTP response storage to4096. It parses complete bounded HTTP as data
arrives, retaining it BEFORE waiting for TLS closure. A partial HTTP observation
waits for more real verified bytes; close before complete framing remains failure.
No100MB response or upload buffer/file is built.

SSLSocket coalesced writes are recorded as application writes, not falsely
asserted to equal TLS records. Only the actual wrap_bio record case makes the
single-record observation. Its future evidence is required; nothing about the
record sizes has been observed in this compile-only phase.

## Exact prepared matrix

**37 total =25 retained request/API cases +11 TLS cases +1 owned shutdown.**
The retained26 cover both EXACT100000000 fixed/chunked uploads, bounded nonzero
payload/final sentinel/hash/count, zero/exact/oversize/quota, split chunk framing,
extensions/discarded trailers,100/refusal, begin/partial/final pauses, metadata
and middleware preservation, stream->stream->buffered pipeline, real file->health
and file->close, failed-begin rollback/retry, sink error/invalid progress, public
cancel/stale, malformed chunk, post-binding-reuse producer progress, simultaneous
three admitted route slots, ordinary peer disconnect, end-error/no-second-cancel
and owned active-upload shutdown. Corrected strict413/503 and once-only quota
retry checks remain. Malformed chunk now requires its specified complete400.

| Additional TLS case | Prepared behavior |
| --- | --- |
| tls_one_actual_record_retained | Real public BIO TLS handshake, verified peer, one observed record whose plaintext write exceeds ingress, accepted0 begin pause, resume/hash7000 without another body write, complete HTTP then authenticated TLS close |
| tls_coalesced_begin | One bounded write containing headers+7000 body, accepted0 pause, separate HTTPS resume, exact hash/end without another upload write |
| tls_coalesced_partial | Chunked7000 with extensions/trailer in one bounded write, accepted7 pause, resume retained suffix/framing with exact hash |
| tls_coalesced_final_trailers | Final7000th byte pauses before remaining framing/trailer validation; resume/end without another application byte |
| tls_close_notify_mid_body | Accept7 of257, actual public unwrap close-notify exchange, require authenticated TLS shutdown, exactly one peer_closed cancel/no end and successful same-route retry |
| tls_buffered_empty | Ordinary buffered empty echo, middleware retained, zero streaming callbacks |
| tls_buffered_fixed | Ordinary buffered64-byte fixed echo under B256, exact body/hash and no sink |
| tls_buffered_chunked | Buffered64-byte chunked echo with extension/discarded trailer and no sink |
| tls_no_alpn_h1 | Separate verified TLS1.3 context offers no ALPN; selectedNone and real H1 health/closure |
| tls_h2_health | Existing HTTP2-capable curl only; TLS1.3/verified peer, actual HTTP2 metadata/status200/bodyok and selected-h2 ALPN trace; no H1 sink |
| tls_websocket_health | Same configured TLS server; real101/accept, exact public WS greeting, masked normal close1000 and authenticated TLS closure; no H1 body sink |

No case was run, skipped, excluded or marked passed. If the existing curl lacks
HTTP2, its case fails explicitly; no weaker substitute is selected. The small
buffered echo checks do not replace the three unchanged existing tls_echo_tests:

```text
tls echo: default intake rejects a 100 KiB declaration before dispatch
tls echo: POST binary and chunked bodies survive keepalive and a bounded pipeline
tls echo: plaintext POST control returns the actual 100 KiB body
```

Those sources remain in the untouched acff inventory and must be rerun by Root
against the reviewed TLS candidate, with their original larger/default configs.
This private B256 profile cannot substitute for that legacy100KiB coverage.

## Source-backed EOF classification and evidence

Root's explicit narrow ruling follows the independently source-backed
`.uwz-work/evidence/h1-tls/transport/tls-eof-contract.md`, copied exactly as
`integration/tls-eof-contract.reviewed.md` with its hash recorded. Normal
successful close attempts SSL_shutdown; direct close_connection/tcp_upload.close
are abort paths. The inherited normal-close WANT_WRITE retry gap has a separate
candidate repair; it is a prerequisite to Root runtime, not a fixture workaround.

All sockets keep suppress_ragged_eofs=False. Successful replies/files/producers,
normal Connection:close and explicit close-notify exchange require authenticated
closure. Complete HTTP framing/body/hash is recorded separately and is not
misrepresented as close-notify. Bounded response observations preserve each fully
parsed final BEFORE closure checks and record TLS truncation/notification and
whether failure occurred before headers/body completion. SSLEOFError is never
silently converted to normal EOF.

Only these SIX exact case labels may explicitly classify SSLEOFError at a
pre-final-header peek as `intentional_tls_abort_no_final_plaintext`:
failed_begin, sink_error, invalid_progress, application_cancel_quota,
end_callback_error and owned_shutdown_active_upload. The peek must expose no
final plaintext prefix. If any final bytes are visible, the unchanged strict
framing/TLS parse applies; partial/malformed final output still fails. Other TLS
errors and arbitrary transport errors are not waived. No failed begin may emit100;
admitted cancellation can already have its actual100. Exact original callback,
reservation-reuse and terminal counters remain mandatory. Intentional TLS abort
is NOT labeled clean EOF, close-notify or successful HTTP upload.

Protocol refusals still require their complete400/413/503 with strict status and
no inappropriate100. The inherited explicitly approved transport-reset-after-
complete413 distinction remains separately recorded; no SSLEOFError is waived
there. Missing/partial response or TLS truncation remains a case failure.

Owned shutdown retains the ordinary Popen PID/listener socket-inode proof,
SIGTERM/wait/reap/no-forced-kill requirement, actual seven-byte active prefix and
single post-deinit H1_FINAL snapshot/marker. It now records an authorized abort
outcome distinctly instead of claiming that active-upload shutdown is graceful
TLS EOF. All final counter reads follow the one worker's join/deinit. The client
never contacts/kills another process or changes native buffer/timer/scheduling
state. Observer deadlines bound ordinary protocol readiness only.

## Runtime release, material handling and precise gaps

Certificates/keys are generated ONLY after Root runtime authorization and a
non-acff reviewed TLS source digest matching the build record. The client rejects
using this baseline API binary for TLS functionality, before any port precheck.
Ephemeral localhost material lives only in an owned0700 temporary directory;
private key mode0600, server static root is a separate files subdirectory, and
nothing copies PEM/key material to evidence. Records contain certificate identity
hash/subject and generation command/status/tool identity, not certificate/key
files or TLS key logs. Bytecode writing is disabled before helper imports.

Genuine0RTT/replay coverage is NOT prepared. Python's ordinary completed-handshake
clients/session-reused flag cannot prove SSL_in_early_data or rejection before
streaming callbacks. The safe-method policy/425 ordering, mTLS early-data policy
and genuine resumed early-data evidence remain required with Root/crypto; no
fake SSL state or handshake flag is substituted. This gap is explicit in future
runtime result metadata and is not counted as one of the37 prepared checks.

Other limitations: every37-case result remains pending; native platforms beyond
this API compilation are unvalidated; no allocator/sanitizer/leak/liveness or
performance claim is made. H2/WS checks are healthy selection/health, not their
compliance baselines. No stopped cancellation/fault/race/injection/panic probe
was reconstructed or prepared. Full project fmt including builds, conventions,
version/dependency/package, unit/regression, sanitizer/MSan, fuzz/OSS-Fuzz,
ReleaseFast, h1spec/Autobahn/H2/platform and maintained-adoption gates remain with
Root. No capability flag, production adoption or milestone completion follows
from this fixture compile.

After Task1/normal-close repair is reviewed and Root supplies a frozen combined
TLS source/digest, the exact replay shape is:

```sh
python3 .uwz-work/evidence/h1-tls/integration/compile.py --source "$tls_source" --expected-source-digest "$tls_source_sha256" --output /tmp/uwz-h1-tls-profile-reviewed --cache-root /tmp/uwz-h1-tls-profile-baseline-r2 --record compile-tls-reviewed
python3 .uwz-work/evidence/h1-tls/integration/probe.py --source "$tls_source" --server /tmp/uwz-h1-tls-profile-reviewed/profile --build-record /workspaces/uWebZockets/.uwz-work/evidence/h1-tls/integration/compile-tls-reviewed.json --artifacts /tmp/uwz-h1-tls-live-records --port 18887 --reviewed-tls-source-sha256 "$tls_source_sha256" --root-authorized-runtime
```

Root chooses its actual unused owned port and NEW artifacts/output directories;
no availability check is claimed here. Append normal `--loader`/`--library-path`
with actual existing Nix values if required. Root must retain the small actual
raw runtime evidence while keeping all TLS material ephemeral. Runtime remains
blocked on Root release; the authorization flag does not grant permission itself.

Only ignored private fixtures were edited; graph files were not refreshed
because they lie outside this worker's ownership. Final source/API/lifetime
self-review is complete; independent Root review remains required.


## Root-authorized shutdown fixture correction, round 1

Root actual b5 execution was **36/37 passed**, runner 1: owned child274544 exited -15 on SIGTERM, with no forced kill and no post-deinit marker. Original integration fixtures, compile/runtime records remain unchanged (all diagnosis identities rechecked). Root accepted the source-backed classification: the cluster fixture omitted explicit public signal setup; Cluster.run does not install it. This is a fixture lifecycle omission, not demonstrated TLS cancellation/deinit failure.

NEW derivative: `.uwz-work/evidence/h1-tls/integration-shutdown/`. Sole functional change is `try cluster.catch_shutdown_signals();` immediately before `try cluster.run();`. See `shutdown-signal.patch`, exact `*.approved-preimage`, `scoped-review.json`, and source references in original `shutdown-diagnosis-b5.md`. Client and compiler are byte-identical and AST-equal to approved originals. All37 client cases/assertions, including strict owned PID/reap/exit0, exactly one post-deinit snapshot, shutdown cancel reason/count, inactive slots and unchanged end/error counters are retained. State and cluster storage remain alive through join/deinit; signal callback only marshals shutdown through the public library watcher; no custom global/private access or worker self-join.

Actual compile-only command:

```sh
python3 .uwz-work/evidence/h1-tls/integration-shutdown/compile.py --source /tmp/uwz-m2-h1-tls-close --expected-source-digest b5cf3e793dde126c903abeed8586201274309dfad72fd6252ea54e9411e9aad8 --output /tmp/uwz-h1-tls-profile-shutdown-r1 --cache-root /tmp/uwz-h1-tls-profile-baseline-r2 --record compile-tls-shutdown-r1
```

Raw output `Exit status: 0`; compiler log empty; ReleaseSafe, -j2. Existing original bindings/c223 override/existing libraries only. `compile-tls-shutdown-r1{.command.json,.json,.log,-source-inputs.json,-source-after.json}` retain exact expanded command, full source/compiler/module/library/override/fixture pre/post hashes and binary identity. Full b5 source digest before/after equals expected b5cf3e793dde126c903abeed8586201274309dfad72fd6252ea54e9411e9aad8; all recorded inputs/fixtures/override unchanged. Compiler script's inherited qualification text mentions acff, but this actual explicit command/record targets reviewed b5; this is compile proof only.

Actual scoped checks, raw argv/status/stdout/stderr in `scoped-checks.json`:

```sh
python3 .uwz-work/evidence/h1-tls/integration-shutdown/verify_scoped.py
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check .uwz-work/evidence/h1-tls/integration-shutdown/profile.zig
```

Both exit0; fmt output empty. AST check output:

```text
Python AST syntax: passed; client/compiler byte identity and AST equality: passed
Approved preimages unchanged; profile sole-line change assertion: passed
All37 unchanged client cases/assertions retained; no runtime in correction preparation
```

SHA256:

- profile.zig: `1074312cbf573ba5a35a6c831d4ce2707d699ff937b52834483aef49937cdfe1`
- probe.py (unchanged): `0bbfba36bd9e9bfd51a48f094af5a62eb68670dded74fcd061a5a9997a9c040a`
- compile.py (unchanged): `26f2dbb7db70251b299ec60346ad0496794437c83ca6792263e9b50e0151218e`
- /tmp/uwz-h1-tls-profile-shutdown-r1/profile: `0236b0e165bb6db9748934aaa8dcc24b7d339032ab48fcdbfdbe367fae143aa6`

READY_FOR_SCOPED_REVIEW. No corrected-fixture runtime, certificates, server/client/port operations occurred. Original failure remains failure until Root reviews/runs the NEW variant; no37/37 claim. Single-App feature preparation remains stopped. Genuine0RTT and separate legacy/full matrix gaps remain as previously reported.
