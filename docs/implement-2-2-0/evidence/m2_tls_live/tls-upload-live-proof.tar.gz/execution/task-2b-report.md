# Task2b single-App configured HTTPS fixture preparation

Scope: NEW `.uwz-work/evidence/h1-tls/integration-single/` derivative only. Root reports corrected cluster execution37/37 runner0, child285505 exit0/reaped/no forced kill/post-deinit marker; final evidence review pending. That is separate evidence and is not execution of this single-App fixture. All original fixtures/runtime/compile records remain preserved. No certificates, server/client execution, port checks/contact or stopped native experiments were performed for Task2b.

## Change and retained checks

`profile.zig` uses exactly the public `uz.Server.preset(init.io, profile_config).build_https(init.arena.allocator(), certificate, private_key)` constructor to initialize one configured App. It replaces cluster construction/worker lookup/enable_https and uses server.listen/catch_shutdown_signals/run/deinit. Exact preimages are `*.cluster-preimage`; scoped patch `single-app.patch`. All sink, route, middleware, independent outgoing-producer context, fixed caller slots, status and final independent State snapshot logic is identical. `verify_scoped.py` asserts the exact setup transformation and byte/AST equality for unchanged client/compiler. No private TLS assignment/new library API.

All37 client cases/assertions remain byte-identical: original26 including exact100000000 fixed/chunked, strict413/503, failed-begin retry, framing/pipeline/files, metadata producer progress after slot reuse, fixed distinct bindings, peer disconnect/end-error/quota and owned active-upload shutdown; plus11 TLS cases (actual one-record retention, three coalesced pause/resume cases, close-notify mid-body, three buffered cases, no-ALPN H1, existing curl H2 health, WebSocket health). No gate was omitted or relaxed. Retained producer pending observation must be actual; strict successful TLS closure and approved six pre-final intentional-abort classifications remain unchanged. All37 are prepared; none have run through this constructor yet.

## Public API/lifetime review

Reviewed source `/tmp/uwz-m2-h1-tls-configured-combined`,1023files, digest `89dce088f5684c9173c45c572e785e7ff9c57991eb152ec76c46a58db481479d`; Root composition manifest `.uwz-work/evidence/h1-tls/combined-configured/source-manifest-v1.json` overlays four reviewed paths onto b5, constructor slice f6.

- src/router/builder.zig:377-389 build_https preserves captured full configuration and typed App, accepts caller allocator and NUL-terminated PEM paths; documents slab ownership/internal TLS startup allocation and stable address requirement.
- src/router/app.zig:465-480 init_https_configured initializes the configured slab and real TLS context, cleans startup failure and defers loop binding. Returned App is placed directly into local `var server` before route registration. It is not copied/moved afterward. loop_handle at :693 binds to that stable address.
- profile.zig retains startup-only arena dupeZ credential paths, whose arena remains alive through main. Runtime-only certificate/key generation remains external Python behavior; no key is archived. App deinit releases its caller-owned slab through its allocator and TLS context. No zero-startup-allocation or allocator-wide instrumentation claim.
- App.catch_shutdown_signals at src/router/app.zig:1547 installs the supported existing process-wide OS watcher before run; no new fixture singleton. App.run at :1516 drives this one loop directly on the main thread. There is no cluster thread, worker join or cluster deinit in this variant.
- State/context/body-route definitions remain outside the inner App block. Sink/control/producer callbacks run only on that loop. After run returns, block defer server.deinit completes before H1_FINAL and drained marker. Final counter read therefore occurs after deinit; no handle or borrowed metadata is dereferenced afterward. Existing client requires owned child exit0/reap/no forced kill, exactly one post-deinit marker/snapshot and exact cancellation/prefix/quota counters.

Same private small ingress profile: L512/H1024/B256, stride2816, max_connections8; logical body max100000000 and client writes<=8192. Client hashes/generates bounded payloads. Own MemoryBIO outgoing header evidence proves one actual record for its designated case; ordinary SSLSocket writes are not asserted to equal records. TLS1.3, ALPN and peer identity are actual future observations, not inferred from compile.

## Actual covering commands

```sh
python3 .uwz-work/evidence/h1-tls/integration-single/verify_scoped.py
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt --check .uwz-work/evidence/h1-tls/integration-single/profile.zig
python3 .uwz-work/evidence/h1-tls/integration-single/compile.py --source /tmp/uwz-m2-h1-tls-configured-combined --expected-source-digest 89dce088f5684c9173c45c572e785e7ff9c57991eb152ec76c46a58db481479d --output /tmp/uwz-h1-tls-profile-single-r1 --cache-root /tmp/uwz-h1-tls-profile-baseline-r2 --record compile-tls-single-r1
```

Scoped checks both exit0; fmt stdout/stderr empty. Exact argv/status/output retained in `scoped-checks.json`. AST output:

```text
Python syntax/AST equality and client/compiler byte identity: passed
Profile exact single-App setup transform; all other source identical: passed
All37 unchanged client cases/assertions retained; no runtime executed
```

## Limitations and release

Root independent source review and explicit runtime release remain required before starting the single-App fixture. Genuine0RTT remains unprepared; completed handshake/session reuse is not early-data evidence. Legacy three exact TLS echo regressions, full project/sanitizer/fuzz/compliance/package/platform/adoption gates remain separate Root work. Existing byte-identical compiler qualification text mentions immutable acff; actual explicit source/expected digest and retained full source inventories identify89dc here. Compile alone is not constructor TLS functionality proof. Only private ignored fixture code changed; no shared graph update outside owned scope.

## Final compile result and identities

Raw wrapper output `Exit status: 0`; empty compiler log; ReleaseSafe, -j2, original bindings/c223 override/existing libraries. No new dependency build. Exact expanded command/compiler/module/library/full-source1023/override93/fixture pre+post identities and status retained in `compile-tls-single-r1{.command.json,.json,.log,-source-inputs.json,-source-after.json}`. Full source digest before/after equals89dc above; all recorded inputs/fixtures/override unchanged.

- profile.zig SHA256: `a4f1bd122f5889256559cc8f02ad6a432cec156fb027d9c01a53066df3431016`
- probe.py SHA256: `0bbfba36bd9e9bfd51a48f094af5a62eb68670dded74fcd061a5a9997a9c040a`
- compile.py SHA256: `26f2dbb7db70251b299ec60346ad0496794437c83ca6792263e9b50e0151218e`
- /tmp/uwz-h1-tls-profile-single-r1/profile SHA256: `cdb1b66aab749951f1820f6fdc9cc1f2164a11920c2af3cc8c3051a8249e611b`

READY_FOR_SOURCE_REVIEW. All37 checks retained, none executed in this single-App variant.
