/usr/bin/curl --disable --version
