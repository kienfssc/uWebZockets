# Scoped TLS live-evidence review

Verdict: Approved for the ordinary TLS integration slice. No actionable findings in the retained evidence. This is evidence validation of the previously reviewed source and fixture, not release or whole-M2 approval. No build, fixture execution, native probe, or source modification was performed.

## Identities and provenance

- Reviewed source: `b5cf3e793dde126c903abeed8586201274309dfad72fd6252ea54e9411e9aad8` at `/tmp/uwz-m2-h1-tls-close`.
- Profile: `1074312cbf573ba5a35a6c831d4ce2707d699ff937b52834483aef49937cdfe1`.
- Client: `0bbfba36bd9e9bfd51a48f094af5a62eb68670dded74fcd061a5a9997a9c040a`.
- Compile driver: `26f2dbb7db70251b299ec60346ad0496794437c83ca6792263e9b50e0151218e`.
- Executed binary: `/tmp/uwz-h1-tls-profile-shutdown-r1/profile`, SHA-256 `0236b0e165bb6db9748934aaa8dcc24b7d339032ab48fcdbfdbe367fae143aa6`.
- Build record: `compile-tls-shutdown-r1.json`, SHA-256 `dce1d9a9ea5679642ccf872f6e3015e768ef8a6930bc3c77715692d4e23d34ae`; ReleaseSafe compilation exited 0 with empty log. Its actual source digest, command and binary bind the corrected TLS candidate. The inherited qualification string about the acff baseline is historical wording, not the compiled source identity.

Inspected `runtime-tls-shutdown-r1-{results.json,binding.json,server.log,runner.log}` and the build record. Runtime before/after bindings are identical and runner exit status is 0. Independently hashed all 1023 recorded source files, all 93 override files, and every runtime-bound file: no mismatches. Compile inputs agree with runtime bindings; compile before/after input, fixture and override maps agree. The override remains `c223bd886c6a51d2cd60def39dd9a68d701fea73`, with manifest `af909377909a4f0509e8b6c2fdcee1c96d2567d6757f33bf3c197f2ce4897980`. Compiler, native archives, module inputs, Python/SSL, curl, loader and runtime libraries are recorded and bound. This run did not execute the earlier acff API-only binary.

## Observed results

- All 37 cases passed. Fixed and chunked uploads each received exactly 100,000,000 bytes with matching client/server SHA-256 `190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2`, retained metadata/middleware, one end and no added cancellation.
- The generated single TLS record has a 7,206-byte ciphertext payload, 7,189 accepted plaintext bytes and 7,000 body bytes against actual request stride 2,816. The upload paused at zero accepted body bytes and completed at 7,000 after resume, with zero further application writes after pause and authenticated close-notify. Coalesced begin/partial/final-trailer cases paused at 0/7/7,000 bytes respectively and completed with matching hashes and no further application writes. These observations do not infer record boundaries from ordinary `SSLSocket.sendall` calls.
- Producer ownership after binding reuse is observed: after the same-route retry, output remained unfinished at 2,703,360 bytes, 48 callbacks and 48 metadata checks. Completion reached 16,777,313 bytes, 302 callbacks, 301 callbacks after upload end and 302 metadata checks. The exact response hash matches the retained-metadata-derived expected output; upload digest and middleware remain checked.
- All 178 Python connection records report TLS 1.3 and the expected peer certificate digest `9e2509269200ecdd382966193da3ebdbecbe60567e592f823ceba362e7c7308b`, with HTTP/1.1 or intentionally absent ALPN. The retained curl trace independently shows verified localhost certificate, TLS 1.3, selected h2 and HTTP/2 200. WSS records show upgrade 101, greeting and close code 1000; no-ALPN H1 returns the expected health body.
- Closure records contain 170 authenticated `close_notify_eof` outcomes and exactly six `intentional_tls_abort_no_final_plaintext` classifications: failed begin, sink error, invalid progress, application cancellation/quota, end callback error and owned active-upload shutdown. These aborts are not counted as graceful TLS EOF; successful response closure checks remain strict.
- Owned shutdown targeted child 285505 while seven upload bytes were accepted and the slot was active. The post-deinit numeric snapshot has one added cancellation, reason `shutdown`, unchanged end count and all three slots inactive. The server log contains the matching final snapshot and drained marker; the child exited 0, was reaped and needed no forced kill. This supports the reviewed signal watcher, join and deinit path for this ordinary run.

The original `integration/runtime-tls-b5-r1-results.json` still records 36/37, failed active-upload shutdown and child status -15. It remains a failed run; the corrected result does not relabel it.

## Limits

Genuine TLS 0-RTT/replay behavior remains unprepared and unverified. The evidence establishes the observed ordinary Linux TLS outcomes, not every WANT_WRITE/backpressure interleaving, allocation/liveness property, native failure path or all-platform behavior. Full-project gates, other M2 slices, maintained dependency adoption/protections and synchronized production pins remain separate integration obligations. No production-adoption or release approval is implied.
