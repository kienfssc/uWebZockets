"""Ordinary owned TLS checks. Run only after Root authorizes combined source."""
import argparse
import hashlib
import io
import importlib.util
import json
import os
import shlex
import socket
import ssl
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from contextlib import ExitStack
from typing import TypedDict

BOUND = 8192
EXACT = 100000000
FILE_SIZE = 16 * 1024 * 1024 + 97
SENTINEL = b'final-upload-sentinel!'
PROFILE_STRIDE = 2816
INTENTIONAL_ABORT_CASES = frozenset(('failed_begin', 'sink_error', 'invalid_progress', 'application_cancel_quota', 'end_callback_error', 'owned_shutdown_active_upload'))
BASELINE_SOURCE = 'acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b'
Endpoint = TypedDict('Endpoint', {'port': int, 'context': ssl.SSLContext, 'connections': list, 'expected_alpn': str | None, 'certificate_sha256': str, 'observations': dict})


def require(condition, detail):
    if not condition:
        raise RuntimeError(detail)


def payload(size):
    offset = 0
    pattern = bytes(range(1, 252))
    while offset < size:
        count = min(BOUND, size - offset)
        block = bytearray(pattern[(offset + index) % 251] for index in range(count))
        start = max(offset, size - len(SENTINEL))
        if start < offset + count:
            block[start - offset:] = SENTINEL[len(SENTINEL) - (size - start):]
        yield bytes(block)
        offset += count


def connect(endpoint: Endpoint):
    raw = socket.create_connection(('127.0.0.1', endpoint['port']), timeout=30)
    raw.settimeout(120)
    client = None
    try:
        client = endpoint['context'].wrap_socket(raw, server_hostname='localhost', suppress_ragged_eofs=False)
        require(client.version() == 'TLSv1.3', 'TLS version differs')
        require(client.selected_alpn_protocol() == endpoint['expected_alpn'], 'negotiated ALPN differs')
        certificate_hash = hashlib.sha256(client.getpeercert(binary_form=True)).hexdigest()
        require(certificate_hash == endpoint['certificate_sha256'], 'verified peer identity differs')
        require(len(endpoint['connections']) < 4096, 'connection evidence bound exceeded')
        endpoint['connections'].append({'tls_version': client.version(), 'alpn': client.selected_alpn_protocol(), 'cipher': client.cipher(), 'peer_certificate_sha256': certificate_hash, 'peer_identity': client.getpeercert(), 'local': client.getsockname(), 'remote': client.getpeername(), 'session_reused': client.session_reused})
        return client
    except BaseException:
        if client is not None:
            client.close()
        raw.close()
        raise


def read_line(source):
    line = source.readline(65537)
    if not line:
        raise EOFError('EOF before response header')
    require(len(line) <= 65536 and line.endswith(b'\r\n'), 'missing/bounded CRLF line')
    return line


def read_exact(source, size):
    require(0 <= size <= BOUND, 'harness read exceeds bound')
    data = source.read(size)
    if len(data) != size:
        raise EOFError(f'premature EOF: {len(data)} != {size}')
    return data


def parse_response(source, *, expected=None, expected_seed=None, interim_only=False, trace=None, upgrade=False):
    interim = []
    while True:
        if trace is not None:
            trace['read_stage'] = 'status_line'
        line = read_line(source)
        parts = line.split(maxsplit=2)
        require(len(parts) == 3 and parts[0] == b'HTTP/1.1', f'invalid status line: {line!r}')
        status = int(parts[1])
        fields = {}
        total = len(line)
        if trace is not None:
            trace['read_stage'] = 'headers'
        while (line := read_line(source)) != b'\r\n':
            total += len(line)
            require(total <= 65536, 'headers exceed bound')
            name, value = line[:-2].split(b':', 1)
            fields.setdefault(name.decode().lower(), []).append(value.strip().decode())
        if trace is not None:
            trace.setdefault('response_heads', []).append({'status': status, 'headers': fields})
        if status != 100:
            require(not interim_only, f'expected 100, got final {status}')
            break
        interim.append({'status': status, 'headers': fields})
        if interim_only:
            return {'interim': interim}
    if upgrade:
        require(status == 101, 'WebSocket upgrade status differs')
        return {'status': status, 'headers': fields, 'interim': interim}
    if trace is not None:
        trace['read_stage'] = 'framed_body'
    count = 0
    digest = hashlib.sha256()
    small = bytearray()

    def consume(size):
        nonlocal count
        while size:
            block = read_exact(source, min(BOUND, size))
            if expected is not None:
                require(block == expected.read(len(block)), f'exact file mismatch at {count}')
            elif expected_seed is not None:
                require(block == pattern_bytes(expected_seed, count, len(block)), f'producer byte mismatch at {count}')
            elif len(small) + len(block) <= 4096:
                small.extend(block)
            else:
                raise RuntimeError('unexpected non-file response exceeds 4096')
            digest.update(block)
            count += len(block)
            size -= len(block)

    if 'transfer-encoding' in fields:
        require(fields['transfer-encoding'] == ['chunked'] and 'content-length' not in fields, 'ambiguous response framing')
        while True:
            size = int(read_line(source).split(b';', 1)[0].strip(), 16)
            if not size:
                require(read_line(source) == b'\r\n', 'unexpected response trailers')
                break
            consume(size)
            require(read_exact(source, 2) == b'\r\n', 'chunk terminator differs')
    else:
        require(len(fields.get('content-length', [])) == 1, 'missing/surplus Content-Length')
        consume(int(fields['content-length'][0]))
    if expected is not None:
        require(expected.read(1) == b'', 'file response truncated expected fixture')
    result = {'status': status, 'headers': fields, 'bytes': count, 'sha256': digest.hexdigest(), 'body': bytes(small).decode('ascii'), 'interim': interim}
    if trace is not None:
        trace['complete_response'] = result
        trace['read_stage'] = 'framed_response_complete'
    return result


def ssl_error_record(error):
    return {'error': repr(error), 'errno': error.errno, 'library': getattr(error, 'library', None), 'reason': getattr(error, 'reason', None)}


def response(endpoint, source, *, expected=None, expected_seed=None, interim_only=False, trace=None, upgrade=False):
    observations = endpoint['observations']
    require(len(observations['http']) < 4096, 'HTTP observation bound exceeded')
    parser_trace = {} if trace is None else trace
    entry = {'case': observations['case'], 'source_id': id(source), 'framing_complete': False}
    observations['http'].append(entry)
    observations['last_response'][id(source)] = entry
    try:
        value = parse_response(source, expected=expected, expected_seed=expected_seed, interim_only=interim_only, trace=parser_trace, upgrade=upgrade)
    except ssl.SSLEOFError as error:
        entry.update(tls_terminal='truncated_before_http_completion', failure_stage=parser_trace.get('read_stage'), failure=ssl_error_record(error), parsed_heads=list(parser_trace.get('response_heads', [])))
        raise
    except ssl.SSLZeroReturnError as error:
        entry.update(tls_terminal='close_notify_before_http_completion', failure_stage=parser_trace.get('read_stage'), failure=ssl_error_record(error), parsed_heads=list(parser_trace.get('response_heads', [])))
        raise
    except EOFError as error:
        entry.update(tls_terminal='close_notify_before_http_completion', failure_stage=parser_trace.get('read_stage'), error=repr(error), parsed_heads=list(parser_trace.get('response_heads', [])))
        raise
    except Exception as error:
        entry.update(failure_stage=parser_trace.get('read_stage'), error=repr(error), parsed_heads=list(parser_trace.get('response_heads', [])))
        raise
    entry.update(framing_complete=not interim_only and not upgrade, response=value)
    return value


def close_tls_response(endpoint, source, detail, *, allow_reset=False):
    observations = endpoint['observations']
    previous = observations['last_response'].get(id(source), {})
    entry = {'case': observations['case'], 'source_id': id(source), 'detail': detail, 'http_framing_complete': previous.get('framing_complete', False), 'last_http_status': previous.get('response', {}).get('status')}
    observations['closures'].append(entry)
    try:
        extra = source.read(1)
    except ssl.SSLEOFError as error:
        entry.update(kind='tls_truncation', failure=ssl_error_record(error))
        raise
    except ssl.SSLZeroReturnError:
        entry['kind'] = 'close_notify_SSLZeroReturnError'
        return entry
    except ConnectionResetError as error:
        entry.update(kind='transport_reset', error=repr(error), errno=error.errno)
        require(allow_reset and entry['http_framing_complete'] and entry['last_http_status'] == 413, 'transport reset without permitted complete413')
        return entry
    except Exception as error:
        entry.update(kind='read_failure', error=repr(error))
        raise
    entry.update(kind='close_notify_eof' if not extra else 'surplus', extra_hex=extra.hex())
    require(not extra, detail)
    return entry


def peek_response(endpoint, source, *, intentional_abort=False):
    observations = endpoint['observations']
    entry = {'case': observations['case'], 'source_id': id(source), 'operation': 'peek_before_final_header'}
    try:
        data = source.peek(1)
    except ssl.SSLEOFError as error:
        permitted = intentional_abort and observations['case'] in INTENTIONAL_ABORT_CASES
        entry.update(kind='intentional_tls_abort_no_final_plaintext' if permitted else 'tls_truncation_before_final_header', failure=ssl_error_record(error), observed_final_prefix_bytes=0)
        observations['closures'].append(entry)
        if permitted:
            return None
        raise
    except ssl.SSLZeroReturnError:
        entry['kind'] = 'close_notify_before_final_header'
        observations['closures'].append(entry)
        return b''
    if not data:
        entry['kind'] = 'close_notify_before_final_header'
        observations['closures'].append(entry)
    return data


def head(path, size, *, chunked=False, pause='none', mode='normal', expect=False, close=False):
    fields = [f'POST {path} HTTP/1.1', 'Host: fixture', 'X-Metadata: retained-individual-header', f'X-Size: {size}', f'X-Pause: {pause}', f'X-Mode: {mode}']
    fields += ['Transfer-Encoding: chunked'] if chunked else [f'Content-Length: {size}']
    if expect:
        fields += ['Expect: 100-continue']
    if close:
        fields += ['Connection: close']
    return ('\r\n'.join(fields) + '\r\n\r\n').encode()


def send_payload(client, size, chunked=False, split=False):
    digest = hashlib.sha256()
    count = 0
    for block in payload(size):
        if chunked:
            prefix = f'{len(block):x};bounded=yes\r\n'.encode()
            if split:
                client.sendall(prefix[:1])
                client.sendall(prefix[1:])
            else:
                client.sendall(prefix)
        client.sendall(block)
        if chunked:
            client.sendall(b'\r\n')
        digest.update(block)
        count += len(block)
    if chunked:
        client.sendall(b'0\r\nX-Discarded-Trailer: ordinary\r\n\r\n')
    require(count == size, 'logical generator count differs')
    return {'bytes': count, 'sha256': digest.hexdigest()}


def get(endpoint, path):
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(f'GET {path} HTTP/1.1\r\nHost: fixture\r\nConnection: close\r\n\r\n'.encode())
        result = response(endpoint, source)
        close_tls_response(endpoint, source, 'surplus bytes after close response')
        require(result['status'] == 200, f'{path} status differs')
        return result


def counters(endpoint):
    return json.loads(get(endpoint, '/status')['body'])


def paused(endpoint):
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        value = counters(endpoint)
        if value['active'] and value['pause_reached']:
            return value
        time.sleep(0.02)
    raise RuntimeError('ordinary HTTP status did not report pause')


def upload_result(result, sent):
    require(result['status'] == 200, f'upload final status: {result}')
    require(result['headers'].get('x-middleware') == ['retained'], 'pending middleware header lost')
    actual = json.loads(result['body'])
    require(actual['bytes'] == sent['bytes'] and actual['sha256'] == sent['sha256'] and actual['metadata_ok'] is True, f'upload digest/metadata differs: {actual}, {sent}')
    return actual


def upload(endpoint, size, *, chunked=False, pause='none', expect=False, path='/upload/capture?q=retained'):
    before = counters(endpoint)
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head(path, size, chunked=chunked, pause=pause, expect=expect, close=True))
        interim = response(endpoint, source, interim_only=True) if expect else None
        pause_state = None
        if pause == 'begin':
            pause_state = paused(endpoint)
            require(get(endpoint, '/resume')['body'] == 'ok', 'begin resume failed')
        sent = send_payload(client, size, chunked, split=chunked)
        if pause in ('partial', 'final'):
            pause_state = paused(endpoint)
            require(pause_state['bytes'] == (7 if pause == 'partial' else size), 'accepted prefix count differs')
            require(get(endpoint, '/resume')['body'] == 'ok', 'body resume failed')
        result = response(endpoint, source)
        actual = upload_result(result, sent)
        close_tls_response(endpoint, source, 'upload response surplus / missing EOF')
    after = counters(endpoint)
    require(after['begins'] == before['begins'] + 1 and after['ends'] == before['ends'] + 1 and after['cancels'] == before['cancels'], 'successful upload terminal counts differ')
    require(get(endpoint, '/stale')['body'] == 'BodyControlExpired', 'completed control remained valid')
    return {'sent': sent, 'response': result, 'actual': actual, 'before': before, 'after': after, 'pause': pause_state, 'interim': interim}


def pipeline(endpoint):
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        sent = []
        for chunked in (False, True):
            client.sendall(head('/upload/pipeline?q=retained', 257, chunked=chunked))
            sent.append(send_payload(client, 257, chunked))
        client.sendall(b'POST /echo HTTP/1.1\r\nHost: fixture\r\nContent-Length: 4\r\nConnection: close\r\n\r\necho')
        values = [response(endpoint, source), response(endpoint, source), response(endpoint, source)]
        for item, expected in zip(values[:2], sent):
            upload_result(item, expected)
        require(values[2]['status'] == 200 and values[2]['body'] == 'echo', 'buffered pipeline differs')
        close_tls_response(endpoint, source, 'pipeline surplus / missing EOF')
        return values


def file_case(endpoint, fixture, close):
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source, fixture.open('rb') as expected:
        request = b'GET /files/large.bin HTTP/1.1\r\nHost: fixture\r\nAccept-Encoding: identity\r\n'
        request += b'Connection: close\r\n\r\n' if close else b'\r\nGET /health HTTP/1.1\r\nHost: fixture\r\nConnection: close\r\n\r\n'
        client.sendall(request)
        result = response(endpoint, source, expected=expected)
        require(result['status'] == 200 and result['bytes'] == FILE_SIZE, 'file status/length differs')
        sibling = None if close else response(endpoint, source)
        if sibling is not None:
            require(sibling['status'] == 200 and sibling['body'] == 'ok', 'file pipeline health differs')
        close_tls_response(endpoint, source, 'file response surplus / missing EOF')
        return {'file': result, 'health': sibling}


def observe_refusal(endpoint, path, size, *, expected_status):
    before = counters(endpoint)
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head(path, size, expect=True, close=True))
        result = response(endpoint, source)
        require(result['status'] == expected_status and not result['interim'], 'Expect refusal status/Continue differs')
        close_tls_response(endpoint, source, 'refusal surplus / missing EOF')
    after = counters(endpoint)
    require(after['ends'] == before['ends'] and after['cancels'] == before['cancels'] and after['begins'] == before['begins'], 'refusal acquired binding ownership')
    require(after['begin_calls'] == before['begin_calls'] and after['failed_begins'] == before['failed_begins'], 'refusal called begin')
    return {'response': result, 'before': before, 'after': after, 'sent_logical_bytes': 0}


def terminal_result(endpoint, source, *, intentional_abort=False, expected_status=None):
    prefix = peek_response(endpoint, source, intentional_abort=intentional_abort)
    if prefix is None:
        require(intentional_abort, 'unclassified TLS abort')
        return {'terminal': 'intentional_tls_abort_no_final_plaintext', 'evidence': endpoint['observations']['closures'][-1]}
    if not prefix:
        require(intentional_abort, 'protocol refusal lacked its required final response')
        return {'terminal': 'authenticated_close_notify_without_final_response'}
    value = response(endpoint, source)
    require(value['status'] >= 400 and (expected_status is None or value['status'] == expected_status), 'failed upload/refusal final status differs')
    close_tls_response(endpoint, source, 'failed upload surplus / missing EOF')
    return {'terminal': 'final_response', 'response': value}


def sink_failure(endpoint, mode):
    before = counters(endpoint)
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head('/upload/failure?q=retained', 257, mode=mode, close=True))
        sent = send_payload(client, 257)
        terminal = terminal_result(endpoint, source, intentional_abort=True)
    after = counters(endpoint)
    require(after['begins'] == before['begins'] + 1 and after['ends'] == before['ends'] and after['cancels'] == before['cancels'] + 1 and after['reason'] == 'sink_failure', 'sink failure terminal accounting differs')
    return {'sent': sent, 'terminal': terminal, 'before': before, 'after': after}


def application_cancel_and_quota(endpoint):
    before = counters(endpoint)
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head('/upload/held?q=retained', 257, pause='begin', expect=True))
        interim = response(endpoint, source, interim_only=True)
        held = paused(endpoint)
        refused = observe_refusal(endpoint, '/upload/quota?q=retained', 1, expected_status=503)
        require(refused['after']['begins'] == held['begins'], 'quota refusal called begin')
        require(get(endpoint, '/cancel')['body'] == 'ok', 'application cancel failed')
        terminal = terminal_result(endpoint, source, intentional_abort=True)
    after = counters(endpoint)
    require(after['begins'] == before['begins'] + 1 and after['ends'] == before['ends'] and after['cancels'] == before['cancels'] + 1 and after['reason'] == 'cancelled', 'application cancellation accounting differs')
    require(get(endpoint, '/stale')['body'] == 'BodyControlExpired', 'cancelled token remained valid')
    return {'before': before, 'after': after, 'held': held, 'quota': refused, 'interim': interim, 'terminal': terminal, 'sent_logical_bytes': 0}


def malformed_body(endpoint):
    before = counters(endpoint)
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head('/upload/malformed?q=retained', 1, chunked=True, expect=True, close=True))
        interim = response(endpoint, source, interim_only=True)
        client.sendall(b'G\r\n')
        terminal = terminal_result(endpoint, source, expected_status=400)
    after = counters(endpoint)
    require(after['ends'] == before['ends'] and after['cancels'] == before['cancels'] + 1 and after['reason'] == 'invalid_body', 'malformed framing accounting differs')
    return {'before': before, 'after': after, 'interim': interim, 'terminal': terminal}


def send_recorded(client, data, stage, trace, *, logical=False):
    trace['write_stage'] = stage
    offset = 0
    while offset < len(data):
        sent = client.send(memoryview(data)[offset:])
        require(sent > 0, 'zero-byte socket send')
        offset += sent
        trace['wire_bytes_sent'] = trace.get('wire_bytes_sent', 0) + sent
        if logical:
            trace['sent_logical_bytes'] += sent
            trace['sent_payload_hex'] = trace.get('sent_payload_hex', '') + bytes(memoryview(data)[offset - sent:offset]).hex()
    trace.setdefault('completed_writes', []).append(stage)


def close_after_complete_413(endpoint, source, trace):
    require(trace.get('complete_response', {}).get('status') == 413, 'closure inspection requires complete413')
    trace['read_stage'] = 'closure_after_complete413'
    trace['closure'] = close_tls_response(endpoint, source, 'surplus bytes after complete413', allow_reset=True)


def limit_terminal_counts(before, after):
    require(after['begin_calls'] == before['begin_calls'] + 1 and after['failed_begins'] == before['failed_begins'] and after['begins'] == before['begins'] + 1, 'chunked limit begin accounting differs')
    require(after['ends'] == before['ends'] and after['cancels'] == before['cancels'] + 1 and after['reason'] == 'body_too_large', 'chunked limit terminal accounting differs')
    require(after['bytes'] == 0 and not after['active'], 'offending chunk payload was accepted or binding remained active')


def chunked_limit(endpoint, trace, *, size_line_only=False):
    before = counters(endpoint)
    trace.update(before=before, declared_chunk_bytes=33, sent_logical_bytes=0, size_line_only=size_line_only)
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        send_recorded(client, head('/limit/chunked?q=retained', 33, chunked=True, expect=True, close=True), 'request_headers', trace)
        trace['interim'] = response(endpoint, source, interim_only=True, trace=trace)
        block = next(payload(33))
        require(len(block) == 33, 'bounded oversize fixture length differs')
        trace['offered_payload_sha256'] = hashlib.sha256(block).hexdigest()
        try:
            send_recorded(client, b'21\r\n' if size_line_only else b'21;bounded=yes\r\n', 'chunk_size_line', trace)
            if not size_line_only:
                send_recorded(client, block, 'rejected_chunk_payload', trace, logical=True)
                send_recorded(client, b'\r\n', 'rejected_chunk_crlf', trace)
                send_recorded(client, b'0\r\nX-Discarded-Trailer: ordinary\r\n\r\n', 'final_chunk_and_trailer', trace)
            trace['write_sequence_completed'] = True
        except OSError as error:
            trace['write_sequence_completed'] = False
            trace['write_error'] = {'stage': trace['write_stage'], 'errno': error.errno, 'error': repr(error)}
        result = response(endpoint, source, trace=trace)
        require(result['status'] == 413 and not result['interim'] and result['bytes'] == 0, 'chunked overlimit requires complete empty413')
        close_after_complete_413(endpoint, source, trace)
    after = counters(endpoint)
    trace['after'] = after
    limit_terminal_counts(before, after)
    if size_line_only:
        require(trace['sent_logical_bytes'] == 0 and trace['write_sequence_completed'], 'size-line-only case sent rejected payload or failed before size line')
    retry = upload(endpoint, 32, path='/limit/released?q=retained')
    trace['same_route_retry'] = retry
    require(retry['after']['cancels'] == after['cancels'] and retry['after']['begins'] == after['begins'] + 1 and retry['after']['ends'] == after['ends'] + 1, 'chunked limit did not release route reservation')
    return trace


def failed_begin(endpoint, trace):
    before = counters(endpoint)
    trace.update(before=before, sent_logical_bytes=0)
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        send_recorded(client, head('/upload/refused?q=retained', 1, mode='failed_begin', expect=True, close=True), 'request_headers', trace)
        trace['read_stage'] = 'before_any_response_header'
        prefix = peek_response(endpoint, source, intentional_abort=True)
        if prefix is None:
            trace['terminal'] = {'kind': 'intentional_tls_abort_no_final_plaintext', 'interim': [], 'response': None, 'evidence': endpoint['observations']['closures'][-1]}
        elif not prefix:
            trace['terminal'] = {'kind': 'authenticated_close_notify_before_final_header', 'interim': [], 'response': None}
        else:
            value = response(endpoint, source, trace=trace)
            require(value['status'] >= 400 and not value['interim'], 'failed begin emitted success or100')
            close_tls_response(endpoint, source, 'failed begin surplus / missing clean EOF')
            trace['terminal'] = {'kind': 'framed_error', 'response': value}
    after = counters(endpoint)
    trace['after_failed_begin'] = after
    require(after['begin_calls'] == before['begin_calls'] + 1 and after['failed_begins'] == before['failed_begins'] + 1, 'failed begin attempt/refusal accounting differs')
    require(after['begins'] == before['begins'] and after['ends'] == before['ends'] and after['cancels'] == before['cancels'] and not after['active'], 'failed begin acquired binding or terminal ownership')
    retry = upload(endpoint, 1, path='/upload/released?q=retained')
    trace['same_route_retry'] = retry
    require(retry['after']['begin_calls'] == after['begin_calls'] + 1 and retry['after']['failed_begins'] == after['failed_begins'] and retry['after']['begins'] == after['begins'] + 1 and retry['after']['ends'] == after['ends'] + 1 and retry['after']['cancels'] == after['cancels'], 'failed begin did not release route reservation')
    return trace


def pattern_bytes(seed, offset, size):
    require(bool(seed) and 0 <= size <= BOUND, 'producer comparison bound differs')
    return bytes(seed[(offset + index) % len(seed)] for index in range(size))


def wait_status(endpoint, predicate, detail):
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        value = counters(endpoint)
        if predicate(value):
            return value
        time.sleep(0.02)
    raise RuntimeError(detail)


def producer_case(endpoint, trace):
    before = counters(endpoint)
    trace['before'] = before
    target = '/upload/producer?q=retained'
    seed = (target + '|producer|retained-individual-header|q=retained\n').encode()
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        send_recorded(client, head(target, 257, mode='producer', expect=True, close=True), 'request_headers', trace)
        trace['interim'] = response(endpoint, source, interim_only=True, trace=trace)
        sent = send_payload(client, 257)
        trace['sent'] = sent
        ended = wait_status(endpoint, lambda value: value['ends'] == before['ends'] + 1 and not value['slot_active'][0], 'producer upload did not end before output read')
        trace['after_upload_end'] = ended
        require(ended['begins'] == before['begins'] + 1 and ended['cancels'] == before['cancels'], 'producer upload terminal accounting differs')
        require(ended['producer_upload_bytes'] == sent['bytes'] and ended['producer_upload_sha256'] == sent['sha256'], 'producer upload digest differs')
        require(get(endpoint, '/stale?slot=0')['body'] == 'BodyControlExpired', 'producer extended upload control lifetime')
        trace['same_route_binding_reuse'] = upload(endpoint, 1, path='/upload/rebound?q=replaced')
        rebound = counters(endpoint)
        trace['after_binding_reuse'] = rebound
        require(not rebound['producer_done'] and rebound['producer_bytes'] < FILE_SIZE, 'producer completed before post-reuse pending state was observed; scenario coverage missing')
        value = response(endpoint, source, expected_seed=seed, trace=trace)
        require(value['status'] == 200 and value['headers'].get('x-middleware') == ['retained'] and value['headers'].get('transfer-encoding') == ['chunked'], 'producer response headers differ')
        require(value['bytes'] == FILE_SIZE, 'producer output length differs')
        expected_hash = hashlib.sha256()
        for offset in range(0, FILE_SIZE, BOUND):
            expected_hash.update(pattern_bytes(seed, offset, min(BOUND, FILE_SIZE - offset)))
        require(value['sha256'] == expected_hash.hexdigest(), 'producer independent output hash differs')
        trace['expected_output'] = {'bytes': FILE_SIZE, 'sha256': expected_hash.hexdigest(), 'seed_hex': seed.hex()}
        trace['read_stage'] = 'producer_output_eof'
        close_tls_response(endpoint, source, 'producer output surplus / missing clean EOF')
    after = counters(endpoint)
    trace['after'] = after
    require(after['producer_done'] and after['producer_bytes'] == FILE_SIZE and after['producer_calls_after_end'] > 0, 'producer never completed a real invocation after upload cleanup')
    require(after['producer_calls'] > rebound['producer_calls'] and after['producer_calls_after_end'] > rebound['producer_calls_after_end'], 'producer did not run after the post-reuse snapshot')
    require(after['producer_metadata_checks'] > rebound['producer_metadata_checks'] and after['producer_bytes'] > rebound['producer_bytes'], 'retained metadata checks/output did not progress after binding reuse')
    require(after['producer_metadata_checks'] == after['producer_calls'], 'producer did not check retained metadata on every invocation')
    require(after['begins'] == before['begins'] + 2 and after['ends'] == before['ends'] + 2 and after['cancels'] == before['cancels'], 'producer/rebound terminal accounting differs')
    return trace


def simultaneous_routes(endpoint, trace):
    before = counters(endpoint)
    trace['before'] = before
    paths = ['/upload/simultaneous?q=retained', '/limit/simultaneous?q=retained', '/empty/simultaneous?q=retained']
    sizes = [257, 32, 0]
    with ExitStack() as owned:
        clients = [owned.enter_context(connect(endpoint)) for _ in paths]
        sources = [owned.enter_context(client.makefile('rb', buffering=BOUND)) for client in clients]
        trace['interim'] = []
        for client, source, path, size in zip(clients, sources, paths, sizes):
            client.sendall(head(path, size, pause='begin', expect=True, close=True))
            trace['interim'].append(response(endpoint, source, interim_only=True))
        admitted = wait_status(endpoint, lambda value: value['slot_active'] == [True, True, True], 'distinct routes did not hold three simultaneous bindings')
        trace['admitted'] = admitted
        require(admitted['begins'] == before['begins'] + 3 and admitted['ends'] == before['ends'] and admitted['cancels'] == before['cancels'], 'simultaneous admission terminal accounting differs')
        require(admitted['slot_begins'] == [count + 1 for count in before['slot_begins']], 'distinct route bindings did not use independent caller slots')
        sent = [send_payload(client, size) for client, size in zip(clients, sizes)]
        trace['sent'] = sent
        trace['responses'] = []
        for index, (source, expected) in enumerate(zip(sources, sent)):
            require(get(endpoint, f'/resume?slot={index}')['body'] == 'ok', 'distinct route resume failed')
            value = response(endpoint, source)
            upload_result(value, expected)
            trace['responses'].append(value)
            close_tls_response(endpoint, source, 'distinct route response surplus / missing EOF')
            require(get(endpoint, f'/stale?slot={index}')['body'] == 'BodyControlExpired', 'distinct route control did not expire')
    after = counters(endpoint)
    trace['after'] = after
    require(after['slot_active'] == [False, False, False] and after['ends'] == before['ends'] + 3 and after['cancels'] == before['cancels'], 'distinct route terminal ownership differs')
    require(after['slot_ends'] == [count + 1 for count in before['slot_ends']], 'distinct route end counts differ')
    return trace


def peer_disconnect(endpoint, trace):
    before = counters(endpoint)
    trace['before'] = before
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head('/upload/disconnect?q=retained', 257, expect=True))
        trace['interim'] = response(endpoint, source, interim_only=True)
        prefix = next(payload(257))[:7]
        client.sendall(prefix)
        trace['sent'] = {'bytes': len(prefix), 'sha256': hashlib.sha256(prefix).hexdigest()}
        trace['before_peer_close'] = wait_status(endpoint, lambda value: value['slot_active'][0] and value['slot_bytes'][0] == 7, 'server did not accept ordinary peer prefix')
    trace['peer_close'] = 'ordinary context-manager socket close; no shutdown flags or linger override'
    after = wait_status(endpoint, lambda value: value['cancels'] == before['cancels'] + 1 and not value['slot_active'][0], 'ordinary peer close did not terminate upload')
    trace['after'] = after
    require(after['begins'] == before['begins'] + 1 and after['ends'] == before['ends'] and after['reason'] == 'peer_closed' and after['slot_reasons'][0] == 'peer_closed', 'ordinary peer disconnect reason/terminal accounting differs')
    require(after['slot_cancels'][0] == before['slot_cancels'][0] + 1, 'peer disconnect cancelled wrong binding')
    require(get(endpoint, '/stale?slot=0')['body'] == 'BodyControlExpired', 'peer disconnect token remained valid')
    trace['same_route_retry'] = upload(endpoint, 1, path='/upload/after-peer?q=retained')
    return trace


def end_failure(endpoint, trace):
    before = counters(endpoint)
    trace['before'] = before
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head('/upload/end-failure?q=retained', 257, mode='end_error', expect=True, close=True))
        trace['interim'] = response(endpoint, source, interim_only=True)
        trace['sent'] = send_payload(client, 257)
        trace['terminal'] = terminal_result(endpoint, source, intentional_abort=True)
    after = counters(endpoint)
    trace['after_failed_end'] = after
    require(after['begin_calls'] == before['begin_calls'] + 1 and after['begins'] == before['begins'] + 1 and after['ends'] == before['ends'] + 1 and after['end_errors'] == before['end_errors'] + 1, 'failed end callback accounting differs')
    require(after['cancels'] == before['cancels'] and after['slot_cancels'] == before['slot_cancels'] and not after['slot_active'][0] and after['slot_bytes'][0] == 257, 'end error delivered second cancel or retained binding')
    require(get(endpoint, '/stale?slot=0')['body'] == 'BodyControlExpired', 'end error control remained valid')
    retry = upload(endpoint, 1, path='/upload/after-end-error?q=retained')
    trace['same_route_retry'] = retry
    require(retry['after']['begins'] == after['begins'] + 1 and retry['after']['ends'] == after['ends'] + 1 and retry['after']['end_errors'] == after['end_errors'] and retry['after']['cancels'] == after['cancels'], 'end error admission release/retry accounting differs')
    return trace


def prepare_shutdown_upload(endpoint, owned, trace):
    before = counters(endpoint)
    trace['before'] = before
    client = owned.enter_context(connect(endpoint))
    source = owned.enter_context(client.makefile('rb', buffering=BOUND))
    client.sendall(head('/upload/owned-shutdown?q=retained', 257, expect=True))
    trace['interim'] = response(endpoint, source, interim_only=True)
    prefix = next(payload(257))[:7]
    client.sendall(prefix)
    trace['sent'] = {'bytes': len(prefix), 'sha256': hashlib.sha256(prefix).hexdigest()}
    held = wait_status(endpoint, lambda value: value['slot_active'][0] and value['slot_bytes'][0] == 7, 'shutdown did not observe an active upload')
    trace['before_owned_sigterm'] = held
    require(held['begins'] == before['begins'] + 1 and held['ends'] == before['ends'] and held['cancels'] == before['cancels'], 'shutdown upload was not independently active')
    return source


def finish_shutdown_case(endpoint, source, trace, results, log):
    require(source is not None, 'shutdown upload preparation did not complete')
    require(results['child_reaped'] and results['child_status'] == 0 and not results['forced_kill_failure'], 'owned shutdown child failed / forced kill')
    require(results['post_deinit_marker'], 'owned shutdown post-deinit marker absent')
    snapshots = [line.partition('H1_FINAL ')[2] for line in log.splitlines() if 'H1_FINAL ' in line]
    require(len(snapshots) == 1, 'owned shutdown final callback snapshot absent/duplicated')
    final = json.loads(snapshots[0])
    trace['post_deinit_snapshot'] = final
    trace['upload_socket_terminal'] = terminal_result(endpoint, source, intentional_abort=True)
    before = trace['before']
    require(final['begins'] == before['begins'] + 1 and final['ends'] == before['ends'] and final['cancels'] == before['cancels'] + 1 and final['reason'] == 'shutdown', 'shutdown terminal counters/reason differ')
    require(final['slot_active'] == [False, False, False] and final['slot_bytes'][0] == 7 and final['slot_reasons'][0] == 'shutdown' and final['slot_cancels'][0] == before['slot_cancels'][0] + 1, 'shutdown binding/prefix accounting differs')
    require(final['end_errors'] == before['end_errors'] and final['failed_begins'] == before['failed_begins'], 'shutdown changed unrelated terminal counters')


def run_cases(endpoint, fixture, results, output):
    diagnostics = {}
    cases = [
        ('fixed_exact100000000', lambda: upload(endpoint, EXACT)),
        ('chunked_exact100000000', lambda: upload(endpoint, EXACT, chunked=True)),
        ('empty', lambda: upload(endpoint, 0, path='/empty/zero?q=retained')),
        ('empty_chunked', lambda: upload(endpoint, 0, chunked=True, path='/empty/zero?q=retained')),
        ('limit_exact32', lambda: upload(endpoint, 32, path='/limit/bound?q=retained')),
        ('limit_chunked_exact32', lambda: upload(endpoint, 32, chunked=True, path='/limit/bound?q=retained')),
        ('limit_chunked_over33', lambda: chunked_limit(endpoint, diagnostics.setdefault('limit_chunked_over33', {}))),
        ('limit_chunk_size_only33', lambda: chunked_limit(endpoint, diagnostics.setdefault('limit_chunk_size_only33', {}), size_line_only=True)),
        ('begin_expect100', lambda: upload(endpoint, 257, pause='begin', expect=True)),
        ('partial_prefix', lambda: upload(endpoint, 257, pause='partial', chunked=True)),
        ('final_byte_fixed', lambda: upload(endpoint, 257, pause='final')),
        ('final_byte_chunked', lambda: upload(endpoint, 257, pause='final', chunked=True)),
        ('stream_stream_buffered_pipeline', lambda: pipeline(endpoint)),
        ('file_health_pipeline', lambda: file_case(endpoint, fixture, False)),
        ('file_close', lambda: file_case(endpoint, fixture, True)),
        ('declared_limit_refusal', lambda: observe_refusal(endpoint, '/limit/refused?q=retained', 33, expected_status=413)),
        ('failed_begin', lambda: failed_begin(endpoint, diagnostics.setdefault('failed_begin', {}))),
        ('sink_error', lambda: sink_failure(endpoint, 'sink_error')),
        ('invalid_progress', lambda: sink_failure(endpoint, 'invalid_progress')),
        ('application_cancel_quota', lambda: application_cancel_and_quota(endpoint)),
        ('malformed_chunk', lambda: malformed_body(endpoint)),
        ('producer_metadata_after_upload', lambda: producer_case(endpoint, diagnostics.setdefault('producer_metadata_after_upload', {}))),
        ('simultaneous_distinct_routes', lambda: simultaneous_routes(endpoint, diagnostics.setdefault('simultaneous_distinct_routes', {}))),
        ('ordinary_peer_disconnect', lambda: peer_disconnect(endpoint, diagnostics.setdefault('ordinary_peer_disconnect', {}))),
        ('end_callback_error', lambda: end_failure(endpoint, diagnostics.setdefault('end_callback_error', {}))),
    ]
    for label, operation in cases:
        endpoint['observations']['case'] = label
        try:
            results['cases'][label] = {'status': 'passed', 'result': operation()}
        except Exception as error:
            results['cases'][label] = {'status': 'failed', 'error': repr(error), 'evidence': diagnostics.get(label, {})}
        output.write_text(json.dumps(results, indent=2) + '\n')


def certificates(runtime, artifacts, helpers):
    certificate = runtime / 'localhost.pem'
    private_key = runtime / 'localhost.key'
    openssl = shutil.which('openssl')
    require(openssl is not None, 'existing openssl executable required')
    arguments = [openssl, 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1', '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost,IP:127.0.0.1', '-keyout', str(private_key), '-out', str(certificate)]
    helpers.command(artifacts, 'certificate_generation', arguments, timeout=30)
    (artifacts / 'certificate_tool_identity.json').write_text(json.dumps({'path': openssl, **helpers.digest_file(Path(openssl))}, indent=2) + '\n')
    private_key.chmod(0o600)
    certificate_hash = hashlib.sha256(ssl.PEM_cert_to_DER_cert(certificate.read_text())).hexdigest()
    return certificate, private_key, certificate_hash


def tls_endpoint(port, certificate, certificate_hash, protocols, connections, observations):
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.load_verify_locations(cafile=str(certificate))
    if protocols:
        context.set_alpn_protocols(protocols)
    return Endpoint(port=port, context=context, connections=connections, expected_alpn=protocols[0] if protocols else None, certificate_sha256=certificate_hash, observations=observations)


def coalesced_pause(endpoint, trace, pause, chunked):
    before = counters(endpoint)
    trace['before'] = before
    size = 7000
    block = next(payload(size))
    request_head = head('/upload/retained-tls?q=retained', size, pause=pause, chunked=chunked, close=True)
    encoded = f'{size:x};retained=yes\r\n'.encode() + block + b'\r\n0\r\nX-Discarded-Trailer: ordinary\r\n\r\n' if chunked else block
    wire = request_head + encoded
    require(PROFILE_STRIDE < len(wire) <= BOUND, 'coalesced plaintext write does not exceed bounded ingress')
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(wire)
        trace['send'] = {'logical_bytes': size, 'sha256': hashlib.sha256(block).hexdigest(), 'plaintext_bytes': len(wire), 'application_write_calls': 1, 'head_bytes': len(request_head), 'available_plaintext_ingress': PROFILE_STRIDE - len(request_head), 'wire_tls_record_sizes': 'not inferred from SSLSocket.sendall'}
        observed = paused(endpoint)
        trace['pause'] = observed
        require(observed['request_stride'] == PROFILE_STRIDE, 'actual configured stride differs')
        expected = 0 if pause == 'begin' else 7 if pause == 'partial' else size
        require(observed['bytes'] == expected, 'coalesced pause accepted prefix differs')
        require(get(endpoint, '/resume')['body'] == 'ok', 'retained TLS/framing resume failed')
        value = response(endpoint, source, trace=trace)
        upload_result(value, {'bytes': size, 'sha256': trace['send']['sha256']})
        close_tls_response(endpoint, source, 'coalesced TLS response surplus / missing clean TLS EOF')
    after = counters(endpoint)
    trace['after'] = after
    require(after['begins'] == before['begins'] + 1 and after['ends'] == before['ends'] + 1 and after['cancels'] == before['cancels'], 'coalesced TLS terminal counts differ')
    trace['application_writes_after_pause'] = 0
    return trace


def close_notify_case(endpoint, trace):
    before = counters(endpoint)
    trace['before'] = before
    with connect(endpoint) as client:
        with client.makefile('rb', buffering=BOUND) as source:
            client.sendall(head('/upload/close-notify?q=retained', 257, expect=True))
            trace['interim'] = response(endpoint, source, interim_only=True)
            block = next(payload(257))[:7]
            client.sendall(block)
            trace['sent'] = {'bytes': 7, 'sha256': hashlib.sha256(block).hexdigest()}
            trace['before_close_notify'] = wait_status(endpoint, lambda value: value['slot_active'][0] and value['slot_bytes'][0] == 7, 'close-notify prefix was not accepted')
        trace['tls_shutdown_stage'] = 'public_SSLSocket_unwrap'
        try:
            with client.unwrap() as raw:
                trace['close_notify'] = 'public SSLSocket.unwrap completed bidirectional TLS shutdown'
                require(raw.recv(1) == b'', 'surplus transport bytes after TLS close-notify')
        except ssl.SSLError as error:
            trace['tls_shutdown_error'] = ssl_error_record(error)
            raise
    after = wait_status(endpoint, lambda value: value['cancels'] == before['cancels'] + 1 and not value['slot_active'][0], 'TLS close-notify did not terminate incomplete upload')
    trace['after'] = after
    require(after['reason'] == 'peer_closed' and after['ends'] == before['ends'] and after['begins'] == before['begins'] + 1, 'TLS close-notify terminal reason/count differs')
    require(after['slot_cancels'][0] == before['slot_cancels'][0] + 1, 'close-notify cancelled wrong binding')
    trace['same_route_retry'] = upload(endpoint, 1, path='/upload/after-notify?q=retained')
    return trace


def buffered_echo(endpoint, trace, mode):
    before = counters(endpoint)
    block = b'' if mode == 'empty' else (b'TLS buffered echo.' * 4)[:64]
    chunked = mode == 'chunked'
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(head('/echo', len(block), chunked=chunked, close=True))
        if chunked:
            client.sendall(f'{len(block):x};echo=yes\r\n'.encode() + block + b'\r\n0\r\nX-Discarded-Trailer: buffered\r\n\r\n')
        else:
            client.sendall(block)
        value = response(endpoint, source, trace=trace)
        require(value['status'] == 200 and value['body'].encode() == block and value['headers'].get('x-middleware') == ['retained'], 'buffered TLS echo differs')
        close_tls_response(endpoint, source, 'buffered TLS echo surplus / missing clean TLS EOF')
    after = counters(endpoint)
    require(after['begins'] == before['begins'] and after['ends'] == before['ends'] and after['cancels'] == before['cancels'], 'buffered echo entered streaming sink')
    trace.update(before=before, after=after, logical_bytes=len(block), sha256=hashlib.sha256(block).hexdigest())
    return trace


def no_alpn_case(endpoint, certificate, trace):
    alternative = tls_endpoint(endpoint['port'], certificate, endpoint['certificate_sha256'], [], endpoint['connections'], endpoint['observations'])
    value = get(alternative, '/health')
    require(value['body'] == 'ok', 'no-ALPN H1 health failed')
    trace['response'] = value
    return trace


def websocket_health(endpoint, trace):
    before = counters(endpoint)
    trace['before'] = before
    with connect(endpoint) as client, client.makefile('rb', buffering=BOUND) as source:
        client.sendall(b'GET /ws HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n\r\n')
        value = response(endpoint, source, upgrade=True, trace=trace)
        require(value['headers'].get('sec-websocket-accept') == ['s3pPLMBiTxaQ9kYGzzhZRbK+xOo='], 'WebSocket accept differs')
        require(read_exact(source, 4) == b'\x81\x02ok', 'WebSocket public greeting differs')
        mask = os.urandom(4)
        code = b'\x03\xe8'
        client.sendall(b'\x88\x82' + mask + bytes(byte ^ mask[index % 4] for index, byte in enumerate(code)))
        reply = read_exact(source, 4)
        require(reply == b'\x88\x02\x03\xe8', 'healthy WebSocket close reply differs')
        close_tls_response(endpoint, source, 'WebSocket surplus / missing clean TLS EOF')
        trace.update(upgrade=value, greeting='ok', close_reply_hex=reply.hex())
    after = counters(endpoint)
    trace['after'] = after
    require(after['begins'] == before['begins'] and after['ends'] == before['ends'] and after['cancels'] == before['cancels'], 'WebSocket path entered H1 body sink')
    return trace


def h2_health(endpoint, certificate, helpers, artifacts, trace):
    before = counters(endpoint)
    directory = artifacts / 'h2'
    directory.mkdir()
    curl = shutil.which('curl')
    require(curl is not None, 'existing HTTP2 curl required')
    version = helpers.command(directory, 'version', [curl, '--disable', '--version']).read_text()
    require('HTTP2' in version, 'existing curl lacks HTTP2; no replacement client is permitted')
    trace['tool'] = {'path': curl, 'version': version, **helpers.digest_file(Path(curl))}
    arguments = [curl, '--disable', '--silent', '--show-error', '--verbose', '--stderr', str(directory / 'health.trace'), '--http2', '--tlsv1.3', '--tls-max', '1.3', '--noproxy', '*', '--connect-timeout', '3', '--max-time', '30', '--cacert', str(certificate), '--resolve', f"localhost:{endpoint['port']}:127.0.0.1", '--dump-header', str(directory / 'health.headers'), '--output', str(directory / 'health.body'), '--write-out', '%{http_version} %{response_code} %{ssl_verify_result}\n', f"https://localhost:{endpoint['port']}/health"]
    metadata = helpers.command(directory, 'health', arguments, timeout=35).read_text().split()
    trace['metadata'] = metadata
    require(metadata == ['2', '200', '0'], 'HTTP2 negotiation/health/verification differs')
    require((directory / 'health.body').stat().st_size == 2 and (directory / 'health.body').read_bytes() == b'ok', 'HTTP2 body differs')
    tls_trace = (directory / 'health.trace').read_text()
    require('TLSv1.3' in tls_trace or 'TLS1.3' in tls_trace, 'HTTP2 actual TLS1.3 trace absent')
    accepted_alpn = [line for line in tls_trace.splitlines() if 'ALPN' in line and 'server accepted' in line]
    trace['accepted_alpn_lines'] = accepted_alpn
    require(any('h2' in line for line in accepted_alpn), 'HTTP2 actual selected h2 ALPN trace absent')
    trace['tls_trace_file'] = str(directory / 'health.trace')
    after = counters(endpoint)
    trace.update(before=before, after=after)
    require(after['begins'] == before['begins'] and after['ends'] == before['ends'] and after['cancels'] == before['cancels'], 'HTTP2 health entered H1 streaming sink')
    return trace


def flush_bio(raw, outgoing):
    while outgoing.pending:
        raw.sendall(outgoing.read(min(BOUND, outgoing.pending)))


def feed_bio(raw, incoming):
    data = raw.recv(BOUND)
    require(bool(data), 'unclean transport EOF before verified TLS close-notify')
    require(incoming.pending + len(data) <= 32768, 'client BIO ciphertext input bound exceeded')
    require(incoming.write(data) == len(data), 'client BIO rejected actual network bytes')


def bounded_record_response(decoded, trace):
    source = io.BytesIO(decoded)
    try:
        value = parse_response(source, trace=trace)
    except EOFError:
        # A partial verified TLS payload needs more real application bytes.
        trace['http_framing'] = 'incomplete_waiting_for_more_verified_plaintext'
        return None
    require(source.read(1) == b'', 'one-record response has surplus')
    trace['http_framing'] = 'complete_before_TLS_terminal'
    trace['http_wire_bytes'] = len(decoded)
    return value


def actual_record_retention(endpoint, trace):
    before = counters(endpoint)
    incoming = ssl.MemoryBIO()
    outgoing = ssl.MemoryBIO()
    client = endpoint['context'].wrap_bio(incoming, outgoing, server_side=False, server_hostname='localhost')
    with socket.create_connection(('127.0.0.1', endpoint['port']), timeout=30) as raw:
        raw.settimeout(120)
        while True:
            try:
                client.do_handshake()
                break
            except ssl.SSLWantReadError:
                flush_bio(raw, outgoing)
                feed_bio(raw, incoming)
            except ssl.SSLWantWriteError:
                require(outgoing.pending > 0, 'TLS handshake WANT_WRITE without actual output')
                flush_bio(raw, outgoing)
        flush_bio(raw, outgoing)
        require(client.version() == 'TLSv1.3' and client.selected_alpn_protocol() == 'http/1.1', 'real BIO client negotiation differs')
        peer_hash = hashlib.sha256(client.getpeercert(binary_form=True)).hexdigest()
        require(peer_hash == endpoint['certificate_sha256'], 'real BIO verified peer identity differs')
        trace['tls'] = {'version': client.version(), 'alpn': client.selected_alpn_protocol(), 'cipher': client.cipher(), 'peer_certificate_sha256': peer_hash}
        block = next(payload(7000))
        request_head = head('/upload/one-record?q=retained', len(block), pause='begin', close=True)
        plaintext = request_head + block
        require(PROFILE_STRIDE < len(plaintext) <= BOUND and outgoing.pending == 0, 'bounded real TLS write precondition differs')
        written = client.write(plaintext)
        require(written == len(plaintext), 'real TLS write did not accept full bounded application input')
        pending = outgoing.pending
        header = outgoing.read(5)
        require(len(header) == 5 and header[0] == 23, 'actual outgoing TLS record is not application ciphertext')
        record_length = int.from_bytes(header[3:5], 'big')
        require(pending == record_length + 5 and outgoing.pending == record_length, 'one actual application TLS write did not produce exactly one record')
        trace['record'] = {'header_hex': header.hex(), 'ciphertext_payload_bytes': record_length, 'ciphertext_record_count': 1, 'accepted_plaintext_bytes': written, 'logical_body_bytes': len(block), 'head_bytes': len(request_head), 'request_stride': PROFILE_STRIDE, 'available_plaintext_ingress': PROFILE_STRIDE - len(request_head)}
        raw.sendall(header)
        flush_bio(raw, outgoing)
        observed = paused(endpoint)
        trace['pause'] = observed
        require(observed['bytes'] == 0 and observed['request_stride'] == PROFILE_STRIDE, 'real one-record begin pause differs')
        require(get(endpoint, '/resume')['body'] == 'ok', 'real one-record resume failed')
        decoded = bytearray()
        final_response = None
        while True:
            try:
                data = client.read(BOUND)
            except ssl.SSLWantReadError:
                flush_bio(raw, outgoing)
                try:
                    feed_bio(raw, incoming)
                except Exception as error:
                    trace.update(tls_terminal='transport_EOF_or_failure_before_close_notify', tls_error=repr(error))
                    raise
                continue
            except ssl.SSLWantWriteError:
                require(outgoing.pending > 0, 'TLS response WANT_WRITE without actual output')
                flush_bio(raw, outgoing)
                continue
            except ssl.SSLZeroReturnError:
                trace['tls_terminal'] = 'actual SSLZeroReturnError reports peer close-notify'
                break
            except ssl.SSLError as error:
                trace.update(tls_terminal='TLS_error_before_close_notify', tls_error=ssl_error_record(error))
                raise
            if not data:
                trace['tls_terminal'] = 'actual SSL read returned close-notify EOF'
                break
            require(final_response is None, 'surplus TLS application bytes after complete HTTP response')
            require(len(decoded) + len(data) <= 4096, 'bounded one-record response exceeds fixture limit')
            decoded.extend(data)
            final_response = bounded_record_response(decoded, trace)
        require(final_response is not None, 'TLS close-notify arrived before complete HTTP framing')
        upload_result(final_response, {'bytes': len(block), 'sha256': hashlib.sha256(block).hexdigest()})
        trace['application_writes_after_pause'] = 0
    after = counters(endpoint)
    trace.update(before=before, after=after)
    require(after['begins'] == before['begins'] + 1 and after['ends'] == before['ends'] + 1 and after['cancels'] == before['cancels'], 'real one-record terminal counts differ')
    return trace


def run_tls_cases(endpoint, certificate, results, output, helpers):
    diagnostics = {}
    cases = [
        ('tls_one_actual_record_retained', lambda: actual_record_retention(endpoint, diagnostics.setdefault('tls_one_actual_record_retained', {}))),
        ('tls_coalesced_begin', lambda: coalesced_pause(endpoint, diagnostics.setdefault('tls_coalesced_begin', {}), 'begin', False)),
        ('tls_coalesced_partial', lambda: coalesced_pause(endpoint, diagnostics.setdefault('tls_coalesced_partial', {}), 'partial', True)),
        ('tls_coalesced_final_trailers', lambda: coalesced_pause(endpoint, diagnostics.setdefault('tls_coalesced_final_trailers', {}), 'final', True)),
        ('tls_close_notify_mid_body', lambda: close_notify_case(endpoint, diagnostics.setdefault('tls_close_notify_mid_body', {}))),
        ('tls_buffered_empty', lambda: buffered_echo(endpoint, diagnostics.setdefault('tls_buffered_empty', {}), 'empty')),
        ('tls_buffered_fixed', lambda: buffered_echo(endpoint, diagnostics.setdefault('tls_buffered_fixed', {}), 'fixed')),
        ('tls_buffered_chunked', lambda: buffered_echo(endpoint, diagnostics.setdefault('tls_buffered_chunked', {}), 'chunked')),
        ('tls_no_alpn_h1', lambda: no_alpn_case(endpoint, certificate, diagnostics.setdefault('tls_no_alpn_h1', {}))),
        ('tls_h2_health', lambda: h2_health(endpoint, certificate, helpers, output.parent, diagnostics.setdefault('tls_h2_health', {}))),
        ('tls_websocket_health', lambda: websocket_health(endpoint, diagnostics.setdefault('tls_websocket_health', {}))),
    ]
    for label, operation in cases:
        endpoint['observations']['case'] = label
        try:
            results['cases'][label] = {'status': 'passed', 'result': operation()}
        except Exception as error:
            results['cases'][label] = {'status': 'failed', 'error': repr(error), 'evidence': diagnostics.get(label, {})}
        output.write_text(json.dumps(results, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--server', type=Path, required=True)
    parser.add_argument('--build-record', type=Path, required=True)
    parser.add_argument('--artifacts', type=Path, required=True)
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--loader', default='')
    parser.add_argument('--library-path', default='')
    parser.add_argument('--root-authorized-runtime', action='store_true')
    parser.add_argument('--reviewed-tls-source-sha256', required=True)
    args = parser.parse_args()
    require(args.root_authorized_runtime, 'Root must explicitly authorize combined-source runtime first')
    args.artifacts.mkdir(parents=True, exist_ok=False)
    helper_path = args.source / 'tests/static_interop/probe.py'
    spec = importlib.util.spec_from_file_location('normal_static_helpers', helper_path)
    helpers = importlib.util.module_from_spec(spec)
    sys.dont_write_bytecode = True
    spec.loader.exec_module(helpers)
    build_record = json.loads(args.build_record.read_text())
    require(build_record['exit_status'] == 0 and build_record['binary_sha256'] == helpers.digest_file(args.server)['sha256'], 'binary differs from successful compile record')
    require(args.reviewed_tls_source_sha256 != BASELINE_SOURCE and build_record['source_tree_sha256'] == args.reviewed_tls_source_sha256, 'runtime requires Root reviewed TLS combined source; baseline compile is API evidence only')
    helpers.precheck_port(args.port)
    results = {'cases': {}, 'optimization': 'ReleaseSafe', 'allocation_scope': 'Bounded application sink and client chunks; no allocator instrumentation claim', 'helper': helpers.digest_file(helper_path), 'server_identity': helpers.digest_file(args.server), 'runtime_started': False, 'bytecode_writes_disabled': sys.dont_write_bytecode, 'build_record': build_record, 'build_record_identity': helpers.digest_file(args.build_record), 'python_version': sys.version, 'client_identity': helpers.digest_file(Path(__file__)), 'python_identity': helpers.digest_file(Path(os.sys.executable))}
    output = args.artifacts / 'results.json'
    forced = False
    with tempfile.TemporaryDirectory(prefix='uwz-h1-tls-profile-') as temporary, ExitStack() as owned_clients:
        runtime = Path(temporary)
        file_root = runtime / 'files'
        file_root.mkdir()
        fixture = file_root / 'large.bin'
        with fixture.open('wb') as target:
            for block in payload(FILE_SIZE):
                target.write(block)
        results['fixture'] = helpers.digest_file(fixture)
        certificate, private_key, certificate_hash = certificates(runtime, args.artifacts, helpers)
        connections = []
        observations = {'http': [], 'closures': [], 'last_response': {}, 'case': 'readiness'}
        endpoint = tls_endpoint(args.port, certificate, certificate_hash, ['http/1.1'], connections, observations)
        results['http_observations'] = observations['http']
        results['tls_closures'] = observations['closures']
        results['connections'] = connections
        results['ssl_library_version'] = ssl.OPENSSL_VERSION
        results['ssl_module_identity'] = {'path': ssl.__file__, **helpers.digest_file(Path(ssl.__file__))}
        results['ssl_extension_identity'] = {'path': sys.modules['_ssl'].__file__, **helpers.digest_file(Path(sys.modules['_ssl'].__file__))}
        results['replay_policy_gap'] = 'genuine 0RTT not prepared; completed handshake/session reuse is not early-data evidence'
        results['certificate_sha256'] = certificate_hash
        results['profile'] = {'request_stride': PROFILE_STRIDE, 'max_request_line_size': 512, 'max_header_size': 1024, 'max_buffered_body_size': 256, 'application_write_bound': BOUND, 'wire_tls_record_sizes': 'not measured by SSLSocket; one write is not asserted to equal one TLS record'}
        env_values = {'H1_PROFILE_ROOT': str(file_root), 'H1_PROFILE_PORT': str(args.port), 'H1_PROFILE_CERT': str(certificate), 'H1_PROFILE_KEY': str(private_key)}
        environment = dict(os.environ)
        environment.update(env_values)
        arguments = [str(args.server.resolve())]
        if args.loader:
            require(bool(args.library_path) and '*' not in args.loader, 'invalid loader prefix')
            arguments = [args.loader, '--library-path', args.library_path, *arguments]
        results.update(argv=arguments, cwd=str(args.source.resolve()), explicitly_passed_environment=env_values)
        (args.artifacts / 'server.command').write_text(shlex.join(arguments) + '\n')
        shutdown_source = None
        shutdown_trace = {}
        with (args.artifacts / 'server.log').open('wb') as log:
            server = subprocess.Popen(arguments, cwd=args.source, env=environment, stdout=log, stderr=subprocess.STDOUT)
            results.update(child_pid=server.pid, runtime_started=True, port=args.port)
            try:
                for _ in range(50):
                    require(server.poll() is None, 'owned server exited before readiness')
                    try:
                        record = helpers.listener_record(server.pid, args.port, False)
                        break
                    except RuntimeError:
                        time.sleep(0.1)
                else:
                    raise RuntimeError('owned server listener readiness deadline')
                results['listener_raw'] = record
                results['readiness'] = get(endpoint, '/health')
                require(results['readiness']['body'] == 'ok', 'health readiness differs')
                run_cases(endpoint, fixture, results, output)
                run_tls_cases(endpoint, certificate, results, output, helpers)
                endpoint['observations']['case'] = 'owned_shutdown_active_upload'
                results['cases']['owned_shutdown_active_upload'] = {'status': 'pending', 'evidence': shutdown_trace}
                try:
                    shutdown_source = prepare_shutdown_upload(endpoint, owned_clients, shutdown_trace)
                except Exception as error:
                    results['cases']['owned_shutdown_active_upload'].update(status='failed', error=repr(error))
            except Exception as error:
                results['harness_failure'] = repr(error)
                raise
            finally:
                if server.poll() is None:
                    shutdown_trace['owned_signal'] = {'kind': 'SIGTERM', 'pid': server.pid}
                    server.terminate()
                    try:
                        server.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        forced = True
                        server.kill()
                        server.wait(timeout=5)
                results.update(child_reaped=server.poll() is not None, child_status=server.returncode, forced_kill_failure=forced)
                output.write_text(json.dumps(results, indent=2) + '\n')
        server_log = (args.artifacts / 'server.log').read_text()
        results['post_deinit_marker'] = 'h1 profile shutdown drained' in server_log
        shutdown_case = results['cases'].get('owned_shutdown_active_upload')
        if shutdown_case is not None and shutdown_case['status'] == 'pending':
            try:
                finish_shutdown_case(endpoint, shutdown_source, shutdown_trace, results, server_log)
                shutdown_case.update(status='passed')
            except Exception as error:
                shutdown_case.update(status='failed', error=repr(error))
        output.write_text(json.dumps(results, indent=2) + '\n')
        require(not forced and server.returncode == 0, 'owned server shutdown/reap failed')
        require(results['post_deinit_marker'], 'post-deinit marker absent')
    require(all(item['status'] == 'passed' for item in results['cases'].values()), 'ordinary case failures; see results.json')


if __name__ == '__main__':
    main()
