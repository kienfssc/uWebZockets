"""Explicit compile-only replay. Never starts a server or client."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/workspaces/uWebZockets')
HERE = Path(__file__).resolve().parent
ZIG = '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig'


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as source:
        while data := source.read(8192):
            result.update(data)
    return result.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, default=Path('/tmp/uwz-m2-h1-plaintext-combined'))
    parser.add_argument('--output', type=Path, default=Path('/tmp/uwz-h1-tls-profile-baseline'))
    parser.add_argument('--record', default='compile')
    parser.add_argument('--cache-root', type=Path)
    parser.add_argument('--expected-source-digest', default='acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b')
    args = parser.parse_args()
    if args.output.exists() and any(args.output.iterdir()):
        raise RuntimeError('select a fresh output/cache directory')
    args.output.mkdir(parents=True, exist_ok=True)
    if (HERE / (args.record + '.json')).exists():
        raise RuntimeError('compile record already exists; select a fresh record label')
    cache_root = args.output if args.cache_root is None else args.cache_root
    if args.cache_root is not None and not ((cache_root / 'cache').is_dir() and (cache_root / 'global').is_dir()):
        raise RuntimeError('explicit cache reuse requires this task existing compiler cache directories')
    argv = [ZIG, 'build-exe', '-OReleaseSafe', '--dep', 'uWebZockets', '-Mroot=' + str(HERE / 'profile.zig'), '-OReleaseSafe', '--dep', 'c', '--dep', 'xev', '--dep', 'zslay', '-MuWebZockets=' + str(args.source / 'src/root.zig'), '-Mc=' + str(ROOT / '.uwz-work/evidence/h1-transport/r2/c-native.zig'), '--dep', 'xev_impl', '-Mxev=' + str(args.source / 'src/core/xev.zig'), '-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig']
    seed = json.loads((ROOT / '.uwz-work/evidence/body-app/focused-final-ReleaseSafe.command.json').read_text())['argv']
    zslay = next(value.split('=', 1)[1] for value in seed if value.startswith('-Mzslay='))
    argv += ['-Mzslay=' + str(ROOT / zslay), '-lc++', '-lc']
    argv += [str(ROOT / 'zig-out/lib' / name) for name in ('libuWebZockets.a', 'libssl.a', 'libcrypto.a', 'liblsquic.a', 'libdeflate.a', 'libz.a')]
    argv += ['-j2', '--cache-dir', str(cache_root / 'cache'), '--global-cache-dir', str(cache_root / 'global'), '-femit-bin=' + str(args.output / 'profile')]
    inputs = [Path(value.split('=', 1)[1]) for value in argv if value.startswith('-M')]
    inputs += [Path(value) for value in argv if value.endswith('.a')]
    inputs += [Path(ZIG)]
    source_inputs = {str(path.relative_to(args.source)): digest(path) for path in sorted(args.source.rglob('*')) if path.is_file()}
    (HERE / (args.record + '-source-inputs.json')).write_text(json.dumps(source_inputs, indent=2) + '\n')
    source_digest = hashlib.sha256(json.dumps(list(source_inputs.items())).encode()).hexdigest()
    if source_digest != args.expected_source_digest:
        raise RuntimeError('combined source digest differs from Root supplied coherent source')
    override_manifest = ROOT / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json'
    override = json.loads(override_manifest.read_text())
    override_inputs = {name: digest(Path(override['path']) / name) for name in override['files_sha256']}
    if override_inputs != override['files_sha256']:
        raise RuntimeError('c223 override differs from immutable input manifest')
    fixture_inputs = {path.name: digest(path) for path in (HERE / 'profile.zig', HERE / 'probe.py', HERE / 'compile.py')}
    record = {'qualification': 'TLS public fixture compile only; immutable acff baseline is not TLS streaming functionality', 'expected_source_digest': args.expected_source_digest, 'fixture_before': fixture_inputs, 'override_manifest_sha256': digest(override_manifest), 'override_before': override_inputs, 'source_tree_sha256': hashlib.sha256(json.dumps(list(source_inputs.items())).encode()).hexdigest(), 'source_tree_encoding': 'sha256(json.dumps(relative_path, file_sha256 pairs in sorted pathlib path order))', 'argv': argv, 'cwd': str(args.source), 'optimization': 'ReleaseSafe', 'explicit_environment': {}, 'input_sha256': {str(path): digest(path) for path in inputs}, 'execution': 'compile only; no server/client execution'}
    (HERE / (args.record + '.command.json')).write_text(json.dumps(record, indent=2) + '\n')
    with (HERE / (args.record + '.log')).open('wb') as log:
        result = subprocess.run(argv, cwd=args.source, stdout=log, stderr=subprocess.STDOUT)
    record['exit_status'] = result.returncode
    record['input_after'] = {str(path): digest(path) for path in inputs}
    record['fixture_after'] = {name: digest(HERE / name) for name in fixture_inputs}
    source_after = {str(path.relative_to(args.source)): digest(path) for path in sorted(args.source.rglob('*')) if path.is_file()}
    (HERE / (args.record + '-source-after.json')).write_text(json.dumps(source_after, indent=2) + '\n')
    record['source_after_sha256'] = hashlib.sha256(json.dumps(list(source_after.items())).encode()).hexdigest()
    record['override_after'] = {name: digest(Path(override['path']) / name) for name in override_inputs}
    record['inputs_unchanged'] = record['input_after'] == record['input_sha256'] and record['fixture_after'] == fixture_inputs and source_after == source_inputs and record['override_after'] == override_inputs
    if result.returncode == 0:
        record['binary_sha256'] = digest(args.output / 'profile')
    (HERE / (args.record + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print((HERE / (args.record + '.log')).read_text(), end='')
    print('Exit status:', result.returncode)
    raise SystemExit(result.returncode if record['inputs_unchanged'] else 1)


if __name__ == '__main__':
    main()
