# Task 2a shutdown fixture correction review

Finding: ADDRESSED. Scoped round verdict: Approved for prepared source. No new actionable breakage found; no outside-scope observations added.

The sole added call at profile.zig:374 registers public cluster shutdown handling before run. The cluster remains at its stable stack address through run/join/deinit. The existing watcher retains that cluster context on worker zero; its callback requests shutdown through the public per-worker wakeup path and stops the watcher, rather than joining or destroying the worker from its callback. Supervisor join/cleanup and the post-deinit snapshot remain unchanged. This addresses the fixture's omitted signal setup without weakening any of the 37 client assertions.

Verified actual corrected profile SHA-256 `1074312cbf573ba5a35a6c831d4ce2707d699ff937b52834483aef49937cdfe1`; client and compiler match their unchanged approved hashes. Inspected scoped diff/check records and actual compile-tls-shutdown-r1.json: ReleaseSafe compilation exits zero with empty log, stable b5 source before/after and 93-file override, and unchanged recorded inputs. Actual binary matches `0236b0e165bb6db9748934aaa8dcc24b7d339032ab48fcdbfdbe367fae143aa6`.

The original 36/37 run remains a failure: child 274544 exited -15 with no deinit marker. This correction has not yet established a successful owned shutdown or 37/37 runtime result. Root's authorized corrected run and evidence validation remain required. No build, runtime, probe, source/ref/pin edit or agent delegation was performed; only this report was written.
