import ast
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
original = out.with_name('integration')
for name in ('profile.zig', 'probe.py', 'compile.py'):
    assert (out / (name + '.approved-preimage')).read_bytes() == (original / name).read_bytes(), name
for name in ('probe.py', 'compile.py'):
    assert (out / name).read_bytes() == (original / name).read_bytes(), name
    assert ast.dump(ast.parse((out / name).read_text())) == ast.dump(ast.parse((original / name).read_text())), name
line = '        try cluster.catch_shutdown_signals();\n'
profile = (out / 'profile.zig').read_text()
assert profile.count(line) == 1
assert profile.replace(line, '') == (original / 'profile.zig').read_text()
assert line + '        try cluster.run();' in profile
print('Python AST syntax: passed; client/compiler byte identity and AST equality: passed')
print('Approved preimages unchanged; profile sole-line change assertion: passed')
print('All37 unchanged client cases/assertions retained; no runtime in correction preparation')
