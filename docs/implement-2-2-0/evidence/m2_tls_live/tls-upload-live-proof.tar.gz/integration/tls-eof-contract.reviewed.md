# TLS EOF contract: v3 source follow-up

Source-only review of candidate `2498622e3a120c6fd0cfee575ad1223b3961ce9e22cbeb9ba39b3d1d59be2cf7`
against acff baseline and pinned BoringSSL d3bf4795. No builds, clients, runtime
probes or implementation edits were performed.

## Normal close and intentional abort differ

Successful buffered request Connection: close reaches close_after_flush from
route_http_data. Streaming completion retains pending_close_requested and
resume_async_dispatch reaches the same path. Explicit response Connection: close
also invokes close_after_flush from Response.end_with_headers. That function
calls begin_tls_shutdown, flushes TLS output, then selects close_when_drained.
Thus normal successful close attempts SSL_shutdown; it is incorrect to claim
that all such closes simply free SSL without an alert.

deinit_tls itself only SSL_free/BIO_free; it does not initiate shutdown.
Direct close_connection and tcp_upload.close are abort paths, not graceful TLS
shutdown. Failed begin releases its rejected admission then closes directly;
end error completes terminal ownership then closes directly. ADR0008:114-116
assigns rollback to failed begin without cancel, and :125-130 explicitly says
end error aborts output without a second cancel. These cases need not produce
a successful HTTP response or authenticated TLS EOF. The fixture should record
an expected abort as an abort, without counting SSLEOFError as graceful success
or weakening ordinary successful cases. The exact emitted prefix is not a
successful-response contract for these abort cases.

## Actionable inherited gap: shutdown retry under output pressure

Severity: medium correctness/interoperability. In v3 tcp.zig begin_tls_shutdown
(around :1800), tls_shutdown_started is set before calling SSL_shutdown. A
negative result with WANT_WRITE is accepted, but the flag prevents any subsequent
SSL_shutdown attempt. Native write completion flushes network_bio, then closes
when the ring drains and close_when_drained is set; it never completes a pending
SSL_shutdown operation. Consequently a normal successful HTTP close can reach
physical close without close_notify when its first shutdown attempt blocks on
TLS output. This existed unchanged in acff; v3's new TLS-upload clients expose
the same shared closure contract rather than a newly introduced defect.

Pinned ssl.h:357-374 defines the first shutdown stage: zero/one means alert sent;
-1 is failure requiring SSL_get_error handling. ssl_lib.cc:1017-1085 explicitly
retries dispatch_alert on subsequent SSL_shutdown calls while alert_dispatch
remains pending. Merely draining the external BIO is not that retry. Since
close_when_drained prevents further SSL_read, a read cannot accidentally finish
the pending alert on this path either. This is a source-backed possible missing
alert, not a claim that every observed SSLEOFError has this cause.

Minimal ownership-safe repair requires retaining graceful-close intent through
the pending first stage, retrying it after actual TLS output progress, and
allowing physical graceful close only after first-stage success plus all BIO
and queued ciphertext drainage. Reuse the existing intent/flag if its semantics
can explicitly distinguish pending from completed first-stage work; do not mark
shutdown complete before SSL_shutdown succeeds. Retry and flushing must remain
inside existing delivery/native callback pins and finish before final close
tail. Stop after first-stage success; do not wait for reciprocal peer close_notify
or call SSL_shutdown again merely to enter its second stage. Fatal shutdown
failure may abort, but must not be counted as successful graceful closure.

There is also an existing early-data limitation: pinned SSL_shutdown silently
succeeds while SSL_in_init is true (ssl_lib.cc:1026-1031). Baseline's
is_tls_handshake_done can be true for accepted early data. A safe-method early
response followed by immediate close therefore does not establish authenticated
EOF merely because SSL_shutdown returned success. Preserve early-data method
policy and classify such closure explicitly; do not weaken replay checks or
assume the local handshake flag proves confirmed shutdown readiness.

## Evidence distinction

Keep suppress_ragged_eofs=False and strict SSLEOFError failure for ordinary
successful graceful-close clients. Exact Content-Length/body/hash establishes
HTTP payload receipt; it separately does not establish close_notify. Legacy
clients that suppress ragged EOF cannot prove authenticated TLS closure.
Intentional failed-begin/end-error clients should assert their specified
terminal/quota and abort outcome separately. Root must decide and review the
shared shutdown correction before asserting graceful TLS EOF under pressure;
no new fault/scheduling experiment is needed for this source finding.
