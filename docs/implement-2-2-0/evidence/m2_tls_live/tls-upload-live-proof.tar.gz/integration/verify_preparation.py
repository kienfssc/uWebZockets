"""Source/AST identity checks only. Never imports the runtime fixtures."""
import ast
import difflib
import hashlib
import json
from pathlib import Path


def function(tree, name):
    return next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)


def cases(tree, name):
    return next(node.value for node in function(tree, name).body if isinstance(node, ast.Assign) and isinstance(node.value, ast.List)).elts


def main():
    out = Path(__file__).resolve().parent
    before = ast.parse((out / 'probe.py.plaintext-preimage').read_text())
    after = ast.parse((out / 'probe.py').read_text())
    ast.parse((out / 'compile.py').read_text())
    for node in ast.walk(before):
        if isinstance(node, ast.Name) and node.id == 'port':
            node.id = 'endpoint'
        if isinstance(node, ast.arg) and node.arg == 'port':
            node.arg = 'endpoint'
    original = cases(before, 'run_cases')
    adapted = cases(after, 'run_cases')
    tls = cases(after, 'run_tls_cases')
    assert len(original) == len(adapted) == 25
    assert all(ast.dump(one) == ast.dump(two) for one, two in zip(original, adapted))
    unchanged = ('payload', 'head', 'send_payload', 'pattern_bytes', 'upload_result', 'send_recorded', 'limit_terminal_counts')
    for name in unchanged:
        assert ast.dump(function(before, name)) == ast.dump(function(after, name)), name
    assert len(tls) == 11
    whitelist = next(node.value for node in after.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'INTENTIONAL_ABORT_CASES' for target in node.targets))
    authorized = ast.literal_eval(whitelist.args[0])
    assert set(authorized) == {'failed_begin', 'sink_error', 'invalid_progress', 'application_cancel_quota', 'end_callback_error', 'owned_shutdown_active_upload'}
    profile = (out / 'profile.zig').read_text()
    assert '.tls_ctx' not in profile and 'cluster.enable_https' in profile and 'cluster.worker(0)' in profile
    for name in ('profile.zig', 'probe.py', 'compile.py'):
        (out / (name + '.diff')).write_text(''.join(difflib.unified_diff((out / (name + '.plaintext-preimage')).read_text().splitlines(True), (out / name).read_text().splitlines(True), fromfile=name + '.plaintext-preimage', tofile=name)))
    record = {'qualification': 'source preparation only; no TLS runtime', 'adapted_plaintext_request_cases': [node.elts[0].value for node in adapted], 'additional_tls_cases': [node.elts[0].value for node in tls], 'owned_shutdown_case': 'owned_shutdown_active_upload', 'total_prepared_cases': 25 + len(tls) + 1, 'plaintext_case_entries_preserved_after_explicit_endpoint_rename': True, 'unchanged_function_asts': list(unchanged), 'intentional_abort_whitelist': list(authorized), 'fixture_sha256': {name: hashlib.sha256((out / name).read_bytes()).hexdigest() for name in ('profile.zig', 'probe.py', 'compile.py')}, 'runtime_started': False}
    (out / 'ast-review.json').write_text(json.dumps(record, indent=2) + '\n')
    print('Python AST syntax: passed; no harness import/execution')
    print('All25 plaintext request case entries retained; owned shutdown retained')
    print('TLS cases11 + original26 =37 prepared, none executed')
    print('Bounded payload/framing/hash helper ASTs unchanged')
    print('Only six approved API-abort cases can classify pre-final SSLEOFError')
    print('Public one-worker TLS setup; no private tls_ctx assignment')


if __name__ == '__main__':
    main()
