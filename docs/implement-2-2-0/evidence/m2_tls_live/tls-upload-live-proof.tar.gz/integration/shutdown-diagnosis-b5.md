# Owned upload shutdown diagnosis (source only)

Root actual reviewed b5 run remains **36/37 passed, runner exit 1**. Sole case failure is owned_shutdown_active_upload. Original results, binding, server/runner logs, compile record and approved fixture were read without mutation; their identities are in shutdown-diagnosis-b5-inputs.json. No runtime, certificate generation, port contact, compilation or fixture edits occurred in this diagnosis.

## Finding

The fixture omitted explicit public shutdown-signal installation. Cluster.run does not promise or install SIGTERM handling. The observed owned child PID 274544 exited -15, reaped, without forced kill or post-deinit marker. These observations are consistent with an unhandled SIGTERM terminating the process before Zig defers run. They do not establish a TLS shutdown/cancellation/deinit implementation defect.

Exact reviewed source: /tmp/uwz-m2-h1-tls-close, full digest b5cf3e793dde126c903abeed8586201274309dfad72fd6252ea54e9411e9aad8.

Source references:

- profile.zig:354-374 builds a public one-worker cluster, enables HTTPS, listens and calls run, but never calls catch_shutdown_signals. The block defer deinit and final H1_FINAL/drained logging are at :356 and :376-377.
- reviewed src/router/app.zig:2011-2074 Cluster.run starts native workers, joins them (:2062) and cleans them up (:2064). There is no signal installation in this path.
- reviewed src/router/app.zig:2114-2130 Cluster.catch_shutdown_signals requires configured lifecycle state and explicitly constructs/starts the process-wide SignalWatcher anchored on worker zero. It is the supported API for this use.
- reviewed src/core/signal.zig:115-148 SignalWatcher.init replaces SIGINT/SIGTERM dispositions using the existing documented OS singleton/self-pipe. No fixture global or private TLS field is necessary.
- reviewed src/router/app.zig:2176-2181 on_cluster_shutdown_signal only requests shutdown and stops the watcher. It does not join workers from their own loop.
- reviewed src/router/app.zig:2098-2106 Cluster.request_shutdown forwards requests to every worker. App.request_shutdown at :615-620 sets the stop flag/wakes the loop. App.begin_shutdown at :629-649 closes listeners and active uploads through tcp_upload.close(..., .shutdown).
- reviewed docs/api.md:71-82 documents explicit installation before run and directs cluster applications to Cluster.catch_shutdown_signals.
- probe.py:640-653 correctly requires child exit 0, owned reap/no forced kill, one post-deinit snapshot, exactly one shutdown cancellation/no end, inactive fixed slots, seven-byte prefix and unchanged unrelated terminal counters. Those assertions should remain strict.

## Minimal correction proposed for Root ruling

Create a NEW cluster fixture variant preserving approved originals and all assertions. Add exactly `try cluster.catch_shutdown_signals();` before `try cluster.run();`, after listen in the current stable local cluster block. Install before the ready listener can be served; no moves/copies of cluster after installation. Keep State alive through run join and block deinit; read final counters only afterward. Use the library's supported watcher, not a fixture handler/global. This corrects missing setup while preserving the observed owned SIGTERM and full shutdown proof. Compile/review then Root-authorized runtime are still required before claiming the case passes.

Alternative: a NEW configured single-App TLS variant using Root's reviewed constructor, explicit app.catch_shutdown_signals before app.run and app.deinit before the marker can exercise the same public lifecycle. It requires a newly frozen combined source including that constructor and larger setup/binding changes. It is not necessary to correct this missing cluster call. Do not replace this case with an HTTP-only stop, accept -15, omit post-deinit proof or weaken cancellation/accounting.

No changes were made pending Root ruling. All 36 other actual cases remain passed; the failed 37th case remains failed. Genuine 0RTT remains a separate gap.
