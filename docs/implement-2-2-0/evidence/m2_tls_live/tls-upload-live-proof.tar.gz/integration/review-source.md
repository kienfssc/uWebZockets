# Task 2a public TLS fixture source review

Verdict: Approved for prepared source. No actionable findings in the scoped fixture review. No TLS runtime result is implied.

Reviewed exact fixture hashes:

- profile.zig: `7613991f81822c9b041cdb99b4f0c5e53ecce88dd18f7688c127892fab777b13`
- probe.py: `0bbfba36bd9e9bfd51a48f094af5a62eb68670dded74fcd061a5a9997a9c040a`
- compile.py: `26f2dbb7db70251b299ec60346ad0496794437c83ca6792263e9b50e0151218e`

The public one-worker cluster retains configured small ingress and stable caller-owned state through worker join and App deinit. Sink/control/producer ownership remains the reviewed plaintext design; final snapshots do not dereference expired controls or request slices. The producer test retains its mandatory pending snapshot after binding reuse and subsequent callback/metadata/output progress checks. Terminal/quota assertions and real same-route retries remain in the adapted cases.

The actual-record case uses real public wrap_bio handshake and certificate verification. It observes only its own generated record header, requires one record whose accepted plaintext exceeds the 2816-byte stride, and authenticates incoming data through stdlib SSL. The record and coalesced cases require the specified accepted prefix at pause, resume over a separate HTTPS request, and complete body/hash without another application write on the paused connection. Partial/final chunk cases retain framing and discarded trailers. This prepares a meaningful retained-input test without claiming sendall alone establishes record boundaries.

Successful response/file/producer/normal-close paths retain suppress_ragged_eofs=False and strict authenticated EOF checks. Only the six explicit case labels can classify SSLEOFError during a pre-final-header peek as intentional abort. Visible final plaintext instead takes strict framing and TLS parsing. Protocol refusals retain required statuses and complete response checks; post-complete413 transport reset remains distinct from TLS truncation. Close-notify uses real unwrap; ordinary disconnect and owned shutdown keep their separate reason/accounting contracts. Owned PID/readiness/signal/reap handling and joined post-deinit metrics remain required.

Healthy H2 uses the existing HTTP2 curl with verified TLS1.3 and actual h2 selection; absence of HTTP2 support fails explicitly. WSS checks upgrade acceptance, greeting and close framing. Ephemeral TLS material is generated only after authorization/source qualification, outside the served file root, and is not copied to retained evidence.

Inspected r4 compile provenance: status zero, empty compiler log, unchanged 1023-file acff source inventory, stable 93-file override inventory and exact fixture input hashes. The baseline binary is API/link compatibility evidence only. The client rejects the acff source identity before port precheck/certificate creation; functionality requires Root's new build bound to the approved complete TLS candidate (`b5cf3e793dde126c903abeed8586201274309dfad72fd6252ea54e9411e9aad8`) and its own compile record. No baseline binary should be used for TLS-upload acceptance.

Remaining gates: all 37 prepared cases require an authorized ordinary run and independent evidence validation. Genuine 0-RTT/replay/mTLS policy runtime coverage is explicitly unprepared and must not be inferred from completed handshakes or session reuse. Legacy TLS regressions, output-pressure close/retry evidence, native platform validation, sanitizer/compliance/performance work, maintained dependency adoption and full project gates remain separate; H2/WSS health is not full compliance. No build, runtime, certificate generation, port contact or native probe was performed during review. Only this report was written.
