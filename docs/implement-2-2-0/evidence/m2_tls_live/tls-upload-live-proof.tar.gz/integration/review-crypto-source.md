# TLS fixture source review r4

Verdict: no actionable crypto/TLS fixture findings. Source preparation is suitable
for Root-authorized execution against the reviewed combined implementation.
None of the 37 prepared cases is accepted as executed by this review.

Reviewed Task2a report, preparation.json, profile.zig, probe.py and compile.py.
Frozen r4 identities: profile `7613991f81822c9b041cdb99b4f0c5e53ecce88dd18f7688c127892fab777b13`,
probe `0bbfba36bd9e9bfd51a48f094af5a62eb68670dded74fcd061a5a9997a9c040a`,
compile `26f2dbb7db70251b299ec60346ad0496794437c83ca6792263e9b50e0151218e`.
No execution/build/probe or fixture changes performed; only this review written.

Clients require TLS1.3, hostname/certificate verification and actual selected
ALPN; the normal socket path checks the expected peer DER hash. No-ALPN remains
separate. H2 uses verified TLS1.3 curl and checks actual h2 selection; WebSocket
checks real upgrade/frames and strict TLS closure. No session-reuse fact is
misrepresented as accepted early data.

The public wrap_bio case performs real verification and observes exactly one
locally generated ciphertext record after accepting plaintext larger than the
2816-byte configured ingress stride. It requires begin-pause at accepted zero,
then explicit separate-connection resume without a second upload application
write. The response is incrementally authenticated by stdlib SSL, bounded to
4096 HTTP bytes, and complete HTTP framing precedes authenticated TLS EOF.
The case is a real record-retention test design, not fabricated SSL/native state.

Successful closure keeps suppress_ragged_eofs=False. SSLEOFError remains failure
for normal responses and malformed/partial final output. The six named abort
cases can classify only a pre-final-header peek truncation with no exposed final
plaintext as intentional abort. Complete response/body/hash evidence remains
separate from close-notify. The separately approved complete413 transport-reset
exception does not waive TLS truncation. Failed begin and end-error counters and
quota remain mandatory rather than being replaced by an EOF observation.

Ephemeral credentials are generated only inside the owned temporary directory;
the private key is chmod0600, the directory is private, and the static root is
its separate files subdirectory. Commands/evidence record identities and hashes,
not PEM contents or traffic secrets. No TLS key logging is prepared. Public
one-worker cluster setup retains callback/context/producer storage until run
joins and deinit completes; final shared counters are read afterward. Compile
and runtime guards distinguish API-only acff evidence from a reviewed TLS source.

Actual enabled-upload, output-pressure close-notify and H2/WS runtime results
remain pending. Genuine0RTT/425-before-streaming-callback evidence is explicitly
unprepared; completed handshakes/session reuse cannot fill that gap. The three
unchanged legacy TLS tests and full sanitizer/compliance/platform gates remain
separate required evidence. No allocation-wide or scheduling claim is made.
