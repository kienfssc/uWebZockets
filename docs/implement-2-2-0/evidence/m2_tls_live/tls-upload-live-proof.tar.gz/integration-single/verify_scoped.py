import ast
from pathlib import Path

out = Path(__file__).resolve().parent
original = out.with_name('integration-shutdown')
for name in ('profile.zig', 'probe.py', 'compile.py'):
    assert (out / (name + '.cluster-preimage')).read_bytes() == (original / name).read_bytes()
for name in ('probe.py', 'compile.py'):
    assert (out / name).read_bytes() == (original / name).read_bytes()
    assert ast.dump(ast.parse((out / name).read_text())) == ast.dump(ast.parse((original / name).read_text()))
before = (original / 'profile.zig').read_text()
expected = before.replace('        var cluster = try uz.Server.preset(init.io, profile_config).build_cluster(init.arena.allocator(), 1, .{});\n        defer cluster.deinit();\n        const server = cluster.worker(0) orelse return error.MissingWorker;', '        var server = try uz.Server.preset(init.io, profile_config).build_https(init.arena.allocator(), certificate, private_key);\n        defer server.deinit();')
expected = expected.replace('        try cluster.enable_https(certificate, private_key);\n', '').replace('try cluster.listen(', 'try server.listen(').replace('try cluster.catch_shutdown_signals();', 'try server.catch_shutdown_signals();').replace('try cluster.run();', 'try server.run();')
actual = (out / 'profile.zig').read_text()
assert expected == actual and '.tls_ctx' not in actual and 'cluster' not in actual
assert actual.index('defer server.deinit();') < actual.index('server.use(') < actual.index('server.listen(') < actual.index('server.catch_shutdown_signals();') < actual.index('server.run();') < actual.index('H1_FINAL ')
print('Python syntax/AST equality and client/compiler byte identity: passed')
print('Profile exact single-App setup transform; all other source identical: passed')
print('All37 unchanged client cases/assertions retained; no runtime executed')
