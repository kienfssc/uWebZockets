# Single-App TLS live-evidence review

Verdict: Approved for this ordinary public `build_https` integration slice. No actionable findings in the retained evidence. No builds, client/server execution or probes were performed during review.

Inspected `runtime-tls-single-r1-{results.json,binding.json,server.log,runner.log}`, the actual `compile-tls-single-r1.json`, and the recorded H2 trace. All 37 cases passed; runner exit status is 0 and its log is empty. Runtime before/after bindings agree exactly. Independently hashed the 1023 recorded source files, 93 override files and all bound fixture/compiler/library/tool/binary inputs with no mismatches. Build inputs agree with runtime bindings. This is execution of the previously reviewed single-App fixture, not reuse of the cluster result.

Bound identities:

- Source: `89dce088f5684c9173c45c572e785e7ff9c57991eb152ec76c46a58db481479d`.
- Profile: `a4f1bd122f5889256559cc8f02ad6a432cec156fb027d9c01a53066df3431016`.
- Client: `0bbfba36bd9e9bfd51a48f094af5a62eb68670dded74fcd061a5a9997a9c040a`.
- Binary `/tmp/uwz-h1-tls-profile-single-r1/profile`: `cdb1b66aab749951f1820f6fdc9cc1f2164a11920c2af3cc8c3051a8249e611b`.
- ReleaseSafe compile record: `6e1b2f33a66b5f1fc02aa7eba5768597f17536dd1ade97a97eb50797cff6ee9d`; compile exit 0, unchanged recorded inputs.
- Override: `c223bd886c6a51d2cd60def39dd9a68d701fea73`.

Both fixed and chunked uploads received exactly 100,000,000 bytes with matching sender/server SHA-256 `190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2`, retained metadata, one begin/end and no cancellation increment. The unchanged case matrix retains strict refusal, terminal/quota, file/pipeline and retry assertions.

The actual generated single record has 7,206 ciphertext payload bytes and 7,189 plaintext bytes, including a 7,000-byte body, against stride 2,816. Accepted body bytes were zero at pause and 7,000 after resume, with zero additional application writes after pause and authenticated close-notify. Coalesced begin/partial/final-trailer cases observed 0/7/7,000 bytes at pause and completed with the exact body digest, retained metadata and zero writes after pause.

The producer remained unfinished after actual same-route binding reuse: 2,703,360 bytes, 48 calls and 48 metadata checks. Completion reached 16,777,313 bytes, 302 calls, 301 calls after upload end and 302 metadata checks. The received output hash `7318ac97ab2b1a5fa391c1d60b3feed8ab0bf1febb3cb66d14b7192717a3edf1` matches the metadata-derived expected output. This observes real progress beyond binding reuse.

All 178 Python connection records report TLS 1.3 and the run's expected certificate digest `66acb15b08359fbf5e20540347cce45de383e139356ca56ad78bd68ea00f4b4b`; ALPN is HTTP/1.1 or intentionally absent. Curl's retained trace independently confirms certificate verification, TLS 1.3, selected h2 and HTTP/2 200. WSS records show 101, greeting and close code 1000; no-ALPN H1 health returns the expected body. These are healthy compatibility checks, not H2/H3 upload coverage.

The 176 closure records contain 170 authenticated close-notify outcomes and exactly the six approved pre-final-header intentional aborts: failed begin, sink error, invalid progress, application cancellation/quota, end callback error and active-upload shutdown. Intentional aborts remain explicitly distinct from graceful TLS EOF; successful closure checks were not relaxed.

Owned SIGTERM targeted child 310739 with seven accepted upload bytes and the slot active. The post-deinit snapshot records exactly one added cancellation, reason `shutdown`, unchanged end count, seven bytes and all slots inactive. The server log agrees with the final numeric snapshot and drained marker. The child exited 0, was reaped and required no forced kill. This validates the ordinary single-App signal/run/deinit path with State outliving the App.

The original cluster run remains recorded as 36/37 with child status -15. It has not been relabeled.

Limits: this review does not claim the separately running central three-target checks passed. Root reports the selected combined 35 tests passed in Debug and ReleaseSafe; this report's independent evidence review covers the live run. Genuine 0-RTT, H2/H3 uploads, full-project gates, native Windows and other platform runtime, all native failure/interleaving paths, and maintained dependency adoption/protections/production pins remain separate obligations. No whole-M2, production or release approval is implied.
