# Task2b fixture and composition review

Verdict: Approved as prepared source. No actionable findings. This review does not claim that the single-App variant has executed its 37 cases.

Reviewed `single-app.patch`, the resulting main block, public constructor/binding/signal/run interfaces, task report, scoped-check records, composition manifest and actual compile bindings. No builds, runtime, probes, source edits or dependency changes were performed.

At `profile.zig:357`, the public configured HTTPS constructor initializes one local App before registration and loop binding. The App remains at that address through listen, signal watcher installation, run and deferred deinit; the fixture does not copy it afterward. Full captured configuration reaches `init_https_configured`, which obtains the configured slab and TLS context before binding. The allocator and NUL-terminated credential paths outlive the App. State, callback contexts and body-route definitions are outside the App block and remain alive through deinit. The final numeric snapshot follows block exit and does not dereference a destroyed App or control token. The explicit App signal watcher uses this stable App context; run drives the single loop directly, without cluster worker/join assumptions.

The client and compile driver are byte-identical to the approved shutdown fixture. All 37 assertions, including producer progress after actual binding reuse, terminal/quota accounting and strict TLS closure classification, are retained. Actual execution must still establish these outcomes through this constructor. The earlier cluster 37/37 result is separate evidence.

Composition checked against all 1023 manifest entries at `/tmp/uwz-m2-h1-tls-configured-combined`: no hash mismatches. Exactly four paths differ from approved b5 and match constructor source f6 byte-for-byte: `src/router/app.zig`, `src/router/builder.zig`, `src/tests/tls_tests.zig`, `tests/package_consumer/main.zig`. The other 1019 files are identical to b5. Actual App/builder differences from b5 consist of the configured HTTPS constructor additions; the existing transport integration and shutdown behavior are preserved. No additional integration code edits were found.

Identities:

- Combined source: `89dce088f5684c9173c45c572e785e7ff9c57991eb152ec76c46a58db481479d`.
- Base: `b5cf3e793dde126c903abeed8586201274309dfad72fd6252ea54e9411e9aad8`.
- Constructor input: `f6f6e7d62a5b33c33f5c466f225b6476778094582759efc63482913e08ed9458`.
- Profile: `a4f1bd122f5889256559cc8f02ad6a432cec156fb027d9c01a53066df3431016`.
- Client: `0bbfba36bd9e9bfd51a48f094af5a62eb68670dded74fcd061a5a9997a9c040a`.
- Compile driver: `26f2dbb7db70251b299ec60346ad0496794437c83ca6792263e9b50e0151218e`.
- Binary `/tmp/uwz-h1-tls-profile-single-r1/profile`: `cdb1b66aab749951f1820f6fdc9cc1f2164a11920c2af3cc8c3051a8249e611b`.

The retained scoped AST/transform and format checks exited 0. `compile-tls-single-r1.json` records ReleaseSafe compilation exit 0 and an empty compiler log, with expected/before/after source digest 89dc. Input, fixture and override maps agree before/after. Independently hashing the recorded compile inputs and output binary found no mismatches. The inherited acff qualification text does not describe this command's actual source; no old API-only binary is approved for the forthcoming functionality run.

Remaining gates: ordinary single-App runtime, separately compiling combined selected tests, genuine 0-RTT, full-project/platform/sanitizer/compliance/package gates and maintained dependency adoption. This is neither whole-M2 nor release approval.
