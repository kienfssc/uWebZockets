# Configured HTTPS crypto review

Verdict: no actionable crypto/TLS findings in the additive configured HTTPS
constructors. Component suitable for Root integration, subject to the separate
API review and combined verification.

Reviewed candidate `f6f6e7d62a5b33c33f5c466f225b6476778094582759efc63482913e08ed9458`
against acff baseline, Task1 report/freeze, four-file implementation.patch,
actual App construction/destruction and unchanged TlsContext initialization.
No builds, executions, probes, source/ref/pin changes performed. Only this
review was written.

App.init_https_configured first obtains the existing configured App, then owns
its full cleanup via errdefer while existing TlsContext.init loads credentials.
The TLS assignment occurs only after successful context construction. Existing
TlsContext.init_with_alpn frees its SSL_CTX on certificate/key/check failure;
App.deinit releases configured startup owners, loop/resources and allocator slab.
Thus failure does not leave a partially installed context or abandon the caller
slab. The builder forwards its compile-time configuration and matching AppType
into this transaction rather than silently selecting default configuration.

The returned value retains unbound loop failure/head pointers and deferred
stable-placement binding. Neither additive method performs listen/run or exports
raw SSL state. Legacy init_https is unchanged. Both methods consume the same
TlsContext.init, retaining TLS1.3-only, h2/http1 ALPN, early-data method policy,
credential chain/key consistency checks and existing error propagation. No TLS
policy, context implementation, native transport, mTLS, QUIC, C ABI, layout or
dependency change appears in the patch.

Tests exercise ordinary generated credentials and existing malformed PEM errors,
including caller slab cleanup for direct and builder paths. Their counting
allocator proves the slab allocation/free, not BoringSSL heap absence. The !void
PEM helper avoids large by-value App error-union test copies without changing
production construction or crypto errors. Original stack-fault/backend records
remain acknowledged; no assertion weakening or new fault probe is claimed.

Reported evidence includes two focused Debug passes, 11 healthy Debug and 13
focused/healthy ReleaseSafe passes, central three-target semantic compilation,
explicit candidate consumer and six example compilations, and static checks.
These were not rerun here. Public consumer HTTPS is compiled, not executed.
Combined live TLS uploads, strict EOF, sanitizer/C-boundary and full release/
platform gates remain Root-owned. Constructor success does not independently
establish streaming runtime behavior or native Windows support.
