from pathlib import Path
import hashlib,json,os,subprocess,sys,time,re,shutil
root=Path('/workspaces/uWebZockets'); draft=Path('/tmp/uwz-m2-configured-https'); out=root/'.uwz-work/evidence/configured-https/implementation'; artifacts=Path('/tmp/uwz-m2-configured-https-artifacts');artifacts.mkdir(exist_ok=True)
cache=Path('/tmp/uwz-m2-configured-https-cache');glob=Path('/tmp/uwz-m2-configured-https-global')
seed=json.loads((root/'.uwz-work/evidence/m2-h1-baseline/compiler-input-seed.json').read_text())
seed['binding_copy']=str(artifacts/'bindings/c-native.zig')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sources():
 paths=[name for name,value in json.loads((out/'baseline-manifest.json').read_text())['files']]
 return hashlib.sha256(json.dumps([(name,sha(draft/name)) for name in paths]).encode()).hexdigest()
def override():
 m=json.loads((root/'.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json').read_text());p=Path(m['path']);values={n:sha(p/n) for n in m['files_sha256']};assert values==m['files_sha256'];return {'manifest_sha256':sha(root/'.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json'),'commit':m['commit'],'tree':m['tree'],'files_sha256':values}
def inputs(argv):
 result={}
 for arg in argv:
  val=arg.split('=',1)[1] if arg.startswith('-M') else arg if arg.endswith('.a') else None
  if val:
   p=Path(val);p=p if p.is_absolute() else draft/p
   if p.is_file():result[str(p)]=sha(p)
 if Path(argv[0]).is_file():result[argv[0]]=sha(argv[0])
 return result
def execute(label,argv,coverage,run=False):
 assert not (out/(label+'.json')).exists(),label
 env=os.environ.copy();env['UWZ_TEST_XEV_BACKEND']='epoll';env['PATH']='/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin:/home/codespace/.codex/packages/app-server-daemon/releases/0.164.0-x86_64-unknown-linux-musl/codex-path:'+env['PATH']
 record={'source_binding':'1023 baseline source paths; runtime .zig-cache/tmp PEM artifacts excluded', 'argv':argv,'cwd':str(draft),'environment':{'UWZ_TEST_XEV_BACKEND':env['UWZ_TEST_XEV_BACKEND']},'source_before':sources(),'input_before':inputs(argv),'override_before':override(),'coverage':coverage}
 if Path(argv[0]).is_file() and kind=='run':record['binary_before']=sha(argv[0])
 started=time.monotonic()
 with (out/(label+'.log')).open('wb') as log:result=subprocess.run(argv,cwd=draft,env=env,stdout=log,stderr=subprocess.STDOUT)
 if Path(argv[0]).is_file() and kind=='run':record['binary_after']=sha(argv[0])
 record.update(exit_status=result.returncode,elapsed_seconds=time.monotonic()-started,source_after=sources(),input_after=inputs(argv),override_after=override())
 binary=artifacts/label
 if binary.is_file():record['binary_sha256']=sha(binary)
 (out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print((out/(label+'.log')).read_text(),end='');print('Exit status:',result.returncode)
 return result.returncode
kind,label=sys.argv[1:3]
if kind=='test':
 module,mode=sys.argv[3:5];filters=sys.argv[5:];argv=[];skip=False
 for arg in json.loads(Path(seed['template']).read_text())['argv']:
  if skip:skip=False;continue
  if arg in ('--test-no-exec','-fno-emit-bin') or arg.startswith('-femit-bin='):continue
  if arg in ('--cache-dir','--global-cache-dir'):skip=True;continue
  if arg.startswith('-O'):arg='-O'+mode
  if arg.startswith('-Mroot='):argv+=['--dep','zslay'];arg='-Mroot='+module
  elif arg.startswith('-Mc='):arg='-Mc='+seed['binding_copy']
  elif arg.startswith('-Mxev_impl='):arg='-Mxev_impl='+seed['override']['path']
  elif arg.startswith('-Mzslay=zig-pkg/'):arg='-Mzslay='+str(root/arg.split('=',1)[1])
  argv.append(arg)
 argv+=['-j2','--cache-dir',str(cache),'--global-cache-dir',str(glob),'--test-no-exec','-femit-bin='+str(artifacts/label)]
 for f in filters:argv+=['--test-filter',f]
 sys.exit(execute(label,argv,'compile selected tests; no execution'))
elif kind=='run':
 compiled=json.loads((out/(label+'.json')).read_text());assert compiled['exit_status']==0
 binary=artifacts/label;assert sha(binary)==compiled['binary_sha256']
 status=execute(label+('-'+sys.argv[3] if len(sys.argv)>3 else '')+'-run',[str(binary)],'execute only selected pure tests or unchanged healthy App suite')
 runpath=out/(label+('-'+sys.argv[3] if len(sys.argv)>3 else '')+'-run.json')
 record=json.loads(runpath.read_text());record.update(compiled_record=str(out/(label+'.json')),binary_sha256=compiled['binary_sha256']);runpath.write_text(json.dumps(record,indent=2)+'\n')
 sys.exit(status)
elif kind=='layout':
 target=sys.argv[3];record=json.loads((root/('.uwz-work/evidence/m2-h1-baseline/layout-'+target+'.json')).read_text());argv=[]
 for arg in record['argv']:
  if arg.startswith('-Mroot='):arg='-Mroot=/tmp/uwz-m2-h1-plaintext-combined-layout.zig'
  if arg.startswith('-femit-llvm-ir='):arg='-femit-llvm-ir='+str(artifacts/(label+'.ll'))
  if arg.startswith('-Mc='):
   arg='-Mc='+str(Path(seed['binding_copy']) if target=='native' else Path('/tmp/uwz-m2-configured-https-artifacts/bindings')/('c-'+target+'.zig'))
  if arg=='/tmp/uwz-m2-h1-baseline-cache':arg=str(cache)
  if arg=='/tmp/uwz-m2-h1-baseline-global':arg=str(glob)
  argv.append(arg)
 status=execute(label,argv,'actual compiler layout and slab sizing only; no execution')
 if status==0:
  line=next(x for x in (artifacts/(label+'.ll')).read_text().splitlines() if '.uwz_cold_v3_layout =' in x and 'constant' in x)
  values=[int(x) for x in re.findall(r'i64 (\d+)',line)]
  labels=json.loads(Path('/tmp/uwz-m2-h1-plaintext-combined-layout-labels.json').read_text())
  assert len(values)==len(labels),(len(values),len(labels))
  (out/(label+'-values.json')).write_text(json.dumps(dict(zip(labels,values)),indent=2)+'\n')
  print(json.dumps(dict(zip(labels,values)),indent=2))
 sys.exit(status)
elif kind=='central':
 target=sys.argv[3];argv=[];skip=False
 for arg in json.loads(Path(seed['template']).read_text())['argv']:
  if skip:skip=False;continue
  if arg in ('--test-no-exec','-fno-emit-bin') or arg.startswith('-femit-bin=') or arg.endswith('.a'):continue
  if arg in ('--cache-dir','--global-cache-dir'):skip=True;continue
  if arg.startswith('-O'):arg='-OReleaseSafe'
  if arg=='native':arg=target
  if arg.startswith('-Mroot='):argv+=['--dep','zslay'];arg='-Mroot=src/tests/main.zig'
  elif arg.startswith('-Mc='):arg='-Mc='+str(Path('/tmp/uwz-m2-configured-https-artifacts/bindings')/('c-'+target+'.zig'))
  elif arg.startswith('-Mxev_impl='):arg='-Mxev_impl='+seed['override']['path']
  elif arg.startswith('-Mzslay=zig-pkg/'):arg='-Mzslay='+str(root/arg.split('=',1)[1])
  argv.append(arg)
 argv+=['-j2','--cache-dir',str(cache),'--global-cache-dir',str(glob),'--test-no-exec','-fno-emit-bin']
 sys.exit(execute(label,argv,'full centralized graph compile only on eligible target; no execution'))
elif kind=='observer':
 target=sys.argv[3];argv=[];skip=False
 for arg in json.loads(Path(seed['template']).read_text())['argv']:
  if skip:skip=False;continue
  if arg in ('--test-no-exec','-fno-emit-bin') or arg.startswith('-femit-bin=') or arg.endswith('.a'):continue
  if arg in ('--cache-dir','--global-cache-dir'):skip=True;continue
  if arg.startswith('-O'):arg='-OReleaseSafe'
  if arg=='native':arg=target
  if arg.startswith('-Mroot='):argv+=['--dep','zslay'];arg='-Mroot='+str(artifacts/'observer_compile.zig')
  elif arg.startswith('-Mc='):arg='-Mc='+str(artifacts/'bindings'/('c-'+target+'.zig'))
  elif arg.startswith('-Mxev_impl='):arg='-Mxev_impl='+seed['override']['path']
  elif arg.startswith('-Mzslay=zig-pkg/'):arg='-Mzslay='+str(root/arg.split('=',1)[1])
  argv.append(arg)
 argv+=['-j2','--cache-dir',str(cache),'--global-cache-dir',str(glob),'--test-no-exec','-fno-emit-bin','-femit-llvm-ir='+str(artifacts/(label+'.ll'))]
 sys.exit(execute(label,argv,'compile/codegen actual fixed observer new tag only; never execute'))
elif kind=='exe':
 module=sys.argv[3];argv=[];skip=False;consumer=module.startswith('tests/package_consumer/')
 for arg in json.loads(Path(seed['template']).read_text())['argv']:
  if skip:skip=False;continue
  if arg in ('--test-no-exec','-fno-emit-bin') or arg.startswith('-femit-bin='):continue
  if arg in ('--cache-dir','--global-cache-dir'):skip=True;continue
  if arg=='test':arg='build-exe'
  if arg.startswith('-O'):arg='-OReleaseSafe'
  if arg=='test_support':
   assert argv.pop()=='--dep';continue
  if arg.startswith('-Mroot='):
   if argv[-1:] == ['--dep']:argv.pop()
   argv+=['--dep','uWebZockets'];arg='-Mroot='+module
  elif arg.startswith('-Mtest_support='):arg='-MuWebZockets='+str(draft/'src/root.zig')
  elif arg.startswith('-Mc='):arg='-Mc='+seed['binding_copy']
  elif arg.startswith('-Mxev_impl='):arg='-Mxev_impl='+seed['override']['path']
  elif arg.startswith('-Mzslay=zig-pkg/'):arg='-Mzslay='+str(root/arg.split('=',1)[1])
  argv.append(arg)
 argv+=['-j2','--cache-dir',str(cache),'--global-cache-dir',str(glob),'-femit-bin='+str(artifacts/label)]
 sys.exit(execute(label,argv,'actual downstream candidate-module override compile and link; no execution' if consumer else 'existing example actual candidate-module compile and link; no execution'))
elif kind=='command':sys.exit(execute(label,sys.argv[3:],'scoped verification'))
