# Configured HTTPS implementation report

Owner: /root/implement_configured_https. Implementation and scoped verification complete; source frozen for independent API/crypto review. Root combined integration remains required.

## Source and contract

Only src/router/app.zig, src/router/builder.zig, src/tests/tls_tests.zig and tests/package_consumer/main.zig changed in /tmp/uwz-m2-configured-https. Source is a fresh nonlinked copy of the immutable 1023-file acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b baseline, with no inherited caches. Canonical candidate source digest is f6f6e7d62a5b33c33f5c466f225b6476778094582759efc63482913e08ed9458. Baseline/candidate manifests, four full preimages/snapshots and implementation.patch are under .uwz-work/evidence/configured-https/implementation.

App.init_https_configured takes the approved io, allocator, compile-time ServerConfig and sentinel PEM paths, initializes configured storage, and transactionally initializes the existing TLS context with App cleanup on error. The builder binds its captured full configuration and corresponding AppType. Existing init_https is unchanged. No field, capacity, TLS policy, raw SSL export, package pin, C ABI, H3, mTLS, cluster or native transport expansion.

The new tests use ordinary generated PEM material and assert actual request/header/capture/WS/queue carving, one initialized upload owner per connection, initial unbound loop/head/failure pointers, TLS private-key consistency and normal one-slab cleanup. They reuse the existing malformed certificate/private-key fixture bytes and exact CertificateLoadFailed/PrivateKeyLoadFailed errors across direct and builder construction. The counting allocator uses default nonfailing settings; its one allocation/free represents the caller slab, not BoringSSL's internal heap. No native failure is invented.

The private consumer has a real environment-dependent HTTPS branch. It semantically analyzes both public constructors, streaming body-route registration and shutdown/deinit with borrowed route/context lifetimes intact. The explicit -MuWebZockets=/tmp/uwz-m2-configured-https/src/root.zig override compiles the candidate instead of a cached old package. The linked binary retains init_https_configured and route_body symbols; this branch was compiled, never executed here. Existing consumer paths remain present.

## Verification results

- API-absence red: declaration-red.json/log failed because init_https_configured did not exist. This is declaration-only red, not a behavioral red and not evidence of missing build_https separately. The TLS test preimage was recovered by the inverse of the later test-only change, and its full source digest exactly matches the original compiler before/after record (declaration-red-recovery.json).
- Corrected focused Debug: configured-https-Debug-v2-ordinary-run.json/log passed 2/2 tests.
- ReleaseSafe focused plus selected healthy config/TLS/startup cases: configured-and-healthy-ReleaseSafe-epoll-run.json/log passed 13/13.
- Selected unchanged healthy Debug config/TLS/startup cases: healthy-Debug-epoll-run.json/log passed 11/11.
- Full central native, aarch64-macos and x86_64-windows-gnu semantic compilation: central-{native,macos,windows}.json/log passed. No cross-target execution or native central fault-suite execution.
- Actual candidate public consumer compile/link: public-consumer.json/log passed. Module paths and hashes are explicit; public-consumer-symbols.json/log records the retained constructor/body-registration symbols and unchanged binary hash.
- Existing custom_builder, hello_world, rpc_server, chat_server, http3_server and https_server actual candidate-module ReleaseSafe compile/link checks passed (example-*.json/log). These were direct compiler invocations using the approved prebuilt dependency graph; no examples were executed.
- Full-dir formatting: fmt-v2 and fmt-check-final passed for src/builds/examples/tests/fuzz. Final conventions and release-version checks passed (2.1.6).
- Graph: initial focused query succeeded using the existing installed CLI prefix after bare graphify returned 127. It was budget-truncated. graph-update.json/log passed code-only AST extraction on an independent identical source copy in /tmp/uwz-m2-configured-https-graph: 591 code files, 13,043 nodes and 16,258 edges, no clustering or LLM/API use. Parallel extraction was unavailable and fell back to sequential; 27 files yielded no symbols and 318 unsupported files were skipped. Compiler source was not mutated by graph output.

Every compiler/run command uses -j2 where applicable, original r2 C bindings, the immutable c223bd886c6a51d2cd60def39dd9a68d701fea73 libxev override and existing static libraries. driver.py records actual argv/cwd, source digest, compiler/module/static-library before/after hashes, full override manifests and emitted/executed binary hashes. Big artifacts and caches remain under /tmp. All compiler/static-input and override before/after identities matched.

## Preserved failures and interpretation

The first ordinary Debug run passed constructor configuration but then faulted in the PEM test. Static disassembly identified the test's by-value !App copies: its frame reserved 0x4f9ff0 (~5.2 MB), with another multi-MB expectError frame. The test-only helper now returns !void and normally deinits success, reducing the PEM test frame to 0x1030 (4,144 bytes) and each helper to about 1.16 MB. Original faulting binary/log and static evidence are retained; it was never rerun. Root explicitly approved one focused run of the corrected v2 binary, which passed. This is a test stack correction, not a production/native transport fix. No stack limits or assertions were changed.

The inherited evidence driver initially passed UWZ_TEST_XEV_BACKEND=io_uring while this sandbox actually selected epoll. The unchanged startup test correctly failed that assertion in both ordinary healthy selections; other selected tests passed. Source shows this variable only asserts the expected backend and never selects one. Root approved truthful epoll expectations. Both failed records remain, and final epoll runs preserve exact binary/source hashes without changing assertions.

The original stack fault interrupted tempDir cleanup, leaving three generated PEM files under the isolated candidate's .zig-cache/tmp. They were moved to /tmp artifacts, never copied as source or committed. That happened while public-consumer compilation was running. Original before/after tree digests therefore differ for that run despite identical compiler source/module/static inputs. source-digest-reconciliation.json and candidate-with-generated-pem-hashes.json bind those transient digest differences to the canonical unchanged 1023 source files. Later source hashes intentionally cover exactly the baseline source paths. No generated credentials are stored in durable repository evidence.

## Limitations and handoff

No live server/client port contact or upload, native fault/cancellation/schedule/race/resource/injected-completion/panic probe, whole native centralized runtime suite, fuzz, sanitizer, maintained adoption or full package-build gate ran in this component. The direct compiler invocations reuse the authorized existing libraries and explicit overrides; they do not claim a normal package fetch/build succeeded. Root owns final documentation, package/root integration, combined ordinary live TLS upload and adoption gates. No commits, fetches, dependency changes or subagents were created here.

Final freeze.json binds the four reviewed snapshots, immutable baseline, canonical source digest, exact command statuses and artifact hashes. Compiler version verification reports Zig 0.16.0. The report and source are frozen; later changes require a new checkpoint and review.
