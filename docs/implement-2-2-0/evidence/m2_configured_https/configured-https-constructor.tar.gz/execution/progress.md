# Configured HTTPS execution ledger

Plan .uwz-work/evidence/configured-https/configured_https.md; Root BASE9a7d16f.
Executable baseline acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b.

| Task pair/self | Interface | Finding and ruling |
| --- | --- | --- |
| Constructor/tests | Full ServerConfig and stable App | Actual configuration, unbound pointers and startup rollback are required; missing API red is labeled honestly. |
| Constructor/consumer | Public builder and AppType | New methods bind captured compile-time config; preserve old methods/errors and analyze the actual public call. |
| Constructor/TLS transport | Separate App/TCP ownership | Independent private source copies; Root composes reviewed disjoint overlays. No shared-source edits. |
| Constructor/TLS fixtures | Public setup | Cluster preparation continues; single-App fixture follows after both reviewed overlays. |
| Task1 self | Test integration vs fault boundary | Existing ordinary PEM startup fixtures and accounting are allowed; no native resource/error/cancellation probes. |

Root explicitly waives no-public-surface-change only for init_https_configured
and build_https. No policy, capability, C ABI, raw SSL or storage change allowed.
Independent work in separate copies is authorized by project AGENTS; Root owns
git/doc/test-root integration and immediately pushes each verified commit.

- [ ] Task1 implementation, meaningful checks and independent review.
- [ ] Root combined consumer/live/docs/final acceptance.
