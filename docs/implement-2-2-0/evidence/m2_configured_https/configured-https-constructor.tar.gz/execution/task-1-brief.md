## Task 1: constructor, contract tests and public consumer

Owner dx_router. Own src/router/app.zig, src/router/builder.zig,
src/tests/tls_tests.zig and tests/package_consumer/main.zig in the new copy only.
Existing test imports suffice. Root owns documentation and final promotion.

Add the two constructors. Test ordinary generated PEM initialization with
streaming enabled and nondefault request/header/capture capacities, actual carved
capacity/owner count and initially unbound loop/head pointers; normal deinit and
existing startup accounting must release ownership. Reuse tls_tests1339/1367 PEM
error fixtures for ordinary malformed credential rollback and exact errors, no
new native error/fault probes. API absence red is declaration-only; do not create
a deliberately wrong implementation to manufacture behavioral red.

Keep all legacy TLS/config/builder consumers. Update the PRIVATE package consumer
to semantically analyze configured HTTPS construction, body-route registration
and lifecycle through public exports (not a statically eliminated call). Preserve
existing checks. Use explicit source-module override for the private candidate,
not an old cached root package; no new package view/dependency pin.

Scoped fmt/conventions/version, selected Debug/RS constructor and existing
healthy TLS/config checks, native/macOS/Windows central semantic compilation,
public consumer and existing builder examples. Preserve actual outputs and
limitations; do not run the whole isolated native central fault suite. Freeze
for independent API/crypto ownership review before combined runtime.

Root later composes with reviewed TLS transport and runs an ordinary single-App
build_https profile with exact100000000 fixed/chunked, metadata/pause/pipeline and
owned shutdown. The existing cluster fixture remains independently useful.
Full package/fuzz/sanitizer/platform/maintained adoption gates remain open.

Root documentation follow-up: docs/tls.md, docs/api.md (configuration is comptime,
not runtime), concise README/CODEBASE/changelog/package example updates when the
coherent source is reviewable. No public functionality claim before evidence.
