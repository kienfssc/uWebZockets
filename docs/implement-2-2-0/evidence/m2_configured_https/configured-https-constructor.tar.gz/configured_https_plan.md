# Configured single-App HTTPS construction

Architect: /root/architect_h1_tls_streaming. Root accepts this separate additive
API slice for M2. It does not authorize a TLS capability claim or adoption.

## Global Constraints

- Read AGENTS.md/CODING_CONVENTION.md and API, Zig, DX and crypto instructions.
  Named explicit types, no anytype, fields, capacity changes, raw SSL exports,
  setters, policy/options variants or speculative abstraction.
- Start with immutable /tmp/uwz-m2-h1-plaintext-combined,1023files,digest
  acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b.
  Own only App/builder/tls_tests/package-consumer source in a NEW
  /tmp/uwz-m2-configured-https copy. No hardlinks, symlinks or inherited caches.
  Root serializes final overlays/docs/test roots. You are not alone; no reverts.
- Evidence .uwz-work/evidence/configured-https/implementation; big outputs/cache
  /tmp. Save actual source snapshots/preimages/patch/commands/raw statuses and
  full source/compiler/input/override/binary pre/post identities durably.
- Original r2 C bindings, immutable c223 libxev override and existing static
  libraries only; -j2; no fetch/build requirement/ref/pin/commit/agent changes.
- Graphify before new searches; supplied paths located, isolated tree not indexed.
- Stopped native experiment stays stopped. No native fault/schedule/race/leak/
  invalid-fd/resource/kernel/registration/injected-completion/panic probes.
  Reuse ordinary existing PEM startup fixtures/accounting and healthy suites;
  no cancellation experiments or invented SSL/native state.

## Evidence, contract and Root ruling

Baseline app.zig458 init_https calls init261/default_config155, which does not
preserve stream_request_bodies or all ingress configuration. Builder AppType62
specializes selected capacities; build374 alone passes the full captured config
to init_configured. Cluster enable_https1915 is currently the public workaround.
Root waives the previous no-public-surface-change constraint ONLY for:

```zig
pub fn init_https_configured(
    io: std.Io,
    allocator: std.mem.Allocator,
    comptime config: config_module.ServerConfig,
    cert_path: [:0]const u8,
    key_path: [:0]const u8,
) !Self;

pub fn build_https(
    self: Self,
    allocator: std.mem.Allocator,
    cert_path: [:0]const u8,
    key_path: [:0]const u8,
) !AppType;
```

App owns init_configured + errdefer deinit + existing TlsContext.init transaction.
Builder binds full captured compile-time config to its specialized AppType.
This configuration/type invariant earns its indirection. Existing init_https
signature/defaults/errors remain unchanged; no legacy refactor is required.
Successful construction must not call loop_handle, bind a head/failure target,
start listeners or publish a pointer to its temporary address. Binding occurs
after stable placement at explicit loop_handle/listen/run. Context cleanup follows
drained shutdown; failed TLS context initialization unwinds both TLS and App slab.
One caller-allocator slab allocation is distinct from BoringSSL startup allocations.

No ephemeral/mTLS/H3/cluster/C ABI expansion belongs here. Existing named types
and root exports suffice. Do not widen old helper/constructor errors.

## Task 1: constructor, contract tests and public consumer

Owner dx_router. Own src/router/app.zig, src/router/builder.zig,
src/tests/tls_tests.zig and tests/package_consumer/main.zig in the new copy only.
Existing test imports suffice. Root owns documentation and final promotion.

Add the two constructors. Test ordinary generated PEM initialization with
streaming enabled and nondefault request/header/capture capacities, actual carved
capacity/owner count and initially unbound loop/head pointers; normal deinit and
existing startup accounting must release ownership. Reuse tls_tests1339/1367 PEM
error fixtures for ordinary malformed credential rollback and exact errors, no
new native error/fault probes. API absence red is declaration-only; do not create
a deliberately wrong implementation to manufacture behavioral red.

Keep all legacy TLS/config/builder consumers. Update the PRIVATE package consumer
to semantically analyze configured HTTPS construction, body-route registration
and lifecycle through public exports (not a statically eliminated call). Preserve
existing checks. Use explicit source-module override for the private candidate,
not an old cached root package; no new package view/dependency pin.

Scoped fmt/conventions/version, selected Debug/RS constructor and existing
healthy TLS/config checks, native/macOS/Windows central semantic compilation,
public consumer and existing builder examples. Preserve actual outputs and
limitations; do not run the whole isolated native central fault suite. Freeze
for independent API/crypto ownership review before combined runtime.

Root later composes with reviewed TLS transport and runs an ordinary single-App
build_https profile with exact100000000 fixed/chunked, metadata/pause/pipeline and
owned shutdown. The existing cluster fixture remains independently useful.
Full package/fuzz/sanitizer/platform/maintained adoption gates remain open.

Root documentation follow-up: docs/tls.md, docs/api.md (configuration is comptime,
not runtime), concise README/CODEBASE/changelog/package example updates when the
coherent source is reviewable. No public functionality claim before evidence.
