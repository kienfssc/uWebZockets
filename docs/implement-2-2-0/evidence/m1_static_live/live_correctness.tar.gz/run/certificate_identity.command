openssl x509 -in /tmp/nix-shell.nFA5Ny/uwz-static-interop-ityzt209/cert.pem -noout -sha256 -fingerprint -dates
