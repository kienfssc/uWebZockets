nix develop --no-write-lock-file /workspaces/uWebZockets/scripts/http3_compliance --command bash /workspaces/uWebZockets/tests/static_interop/run.sh --clients /tmp/uwz-m1-static-live-fc0587a 
