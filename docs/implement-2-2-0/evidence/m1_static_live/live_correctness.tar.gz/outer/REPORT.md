# M1 public static-route live correctness gate

Source: `fc0587af169b1783d17f40cbdfb4bc16140e755a`, original checkout
`/workspaces/uWebZockets`. Before and after HEAD match; tracked/untracked status
is empty. No source edits, retries, or server restarts occurred during this run.

Exact command:

```sh
bash /tmp/uwz-m1-static-live-fc0587a-launch.sh
```

The retained launcher exports the pinned Nix PATH, `nix-command flakes`,
`ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache`, and
`ZIG_LOCAL_CACHE_DIR=/tmp/uwz-frozen-m1a-cache`, then invokes:

```sh
bash tests/static_interop/run.sh \
  fc0587af169b1783d17f40cbdfb4bc16140e755a \
  /tmp/uwz-m1-static-live-fc0587a
```

Consumer build: Zig 0.16.0, `-j2 -Doptimize=ReleaseSafe --summary all`.
Raw build result: `Build Summary: 17/17 steps succeeded`, exit 0.
Pinned clients: curl 8.21.0, ngtcp2 1.22.1, nghttp3 1.15.0, aioquic 1.3.0.
Exact source, package, tool, module, and flake identities are retained in the
artifact directory.

| Protocol/client | File bytes | Small checks | Connection reuse |
| --- | ---: | ---: | --- |
| Plaintext H1 / curl | 104857600 | 21 | Same connection ID, zero new connections |
| TLS H1 / curl | 104857600 | 21 | Same connection ID, zero new connections |
| TLS H2 / curl | 104857600 | 21 | Same connection ID, zero new connections |
| Live H3 / curl | 104857600 | 21 | Same connection ID, zero new connections |
| Live H3 / aioquic | 104857600 | Large plus sibling/reuse | One connection; stream IDs 0, 4, 8 |

Every large body matches every synthetic source byte, exact Content-Length,
and SHA-256
`47af9ae06dbe173a57e8e89b1af49daf42bd24ab6a3196072bdeb7dd63324db2`.
The source uses sparse zero interior and seven nonzero boundary sentinels.
All five raw large-body gzip archives are retained, each with archive SHA-256
`5a08a025eb7ffc544836ae1c77eb119c3bb377d02572f55c7971efab1d62a2b8`.
The comparison and file hashing read bound is 8192 bytes.

Curl completed 92 invocations and 96 HTTP responses with expected statuses.
All 84 small checks pass: identity default/304, gzip and Brotli raw full bodies,
HEAD, selected-coding 304, encoded ranges, matching/mismatching If-Range, 416,
distinct representation validators, Vary, source MIME, duplicate fields and
complete refusal. Both codings decode to exact 1376-byte original bodies on
all four protocols. The valid encoded Brotli fixture is 49 bytes.

Aioquic requires Content-Length 104857600 on the file stream, validates exact
EOF with END_STREAM, and completes the concurrent two-byte health sibling and
later two-byte health request on the same connection. Stream IDs are 0, 4, 8.
Health Content-Length is optional and validated if present. The largest actual
data event was 1440 bytes; legal larger events remain processed in 8192-byte
slices. The receive datagram buffer bound is 65536 bytes.

There are 23 retained nonempty curl transport qlogs. The low-level aioquic
trace is labeled application JSONL, not transport qlog. Raw headers, traces,
commands, outputs, body archives, generated results, certificate identity,
listener inode/PID ownership evidence, and individual statuses are retained.

All three owned server processes exit 0, with `server.forced=false` and the
post-shutdown/deinit drain marker. Their PIDs are gone. The owned runtime
directory and private certificate key are removed; the public test certificate
is retained. Before/after source statuses are empty.

Raw terminal status:

```text
build.status 0
clients.status 0
client_gate.status 0
gate.status 0
outer.status 0
static interop correctness gate passed; no throughput claim
```

Artifacts: `/tmp/uwz-m1-static-live-fc0587a`.
Launcher and raw outer output/status use the matching `-launch.sh`,
`-outer.log`, and `-outer.status` paths.
This is correctness evidence for this configuration. App/TLS/QUIC startup and
client-library internal allocations are not allocator-instrumented. No global
heap, performance, official HttpArena activation, or full-matrix claim is made.
