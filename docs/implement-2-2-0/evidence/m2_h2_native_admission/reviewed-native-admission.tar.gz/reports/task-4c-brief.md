# Task4c: carry the native early-data admission fact

Read this first: these are the requirements for the next bounded slice in
native_tcp_handoff_2026_10_28.md. Task4b is reviewed and published in d7c3ebe.
Use exact restored baseline /tmp/uwz-task4b-fix1-frozen, 1029 regular files,
tree aa420a97e62062d78c0d3c2fd2f35df11115ef85b8b7cfe316d3734d592a6fd0.
Verify every file before copying to a new /tmp candidate. No earlier task restart.

Own only src/http2/body_receive.zig, src/core/http2_upload.zig, and the existing
src/tests/http2_upload_driver_tests.zig in the new candidate. Root production,
App/config/Router/native TCP, dependency pins and all historical inputs stay
unchanged. You are not alone; do not revert others or spawn agents. No commits,
pushes, refs, fetches, maintained publication, native clients or live servers.

Stage A: propose the additive early_data_forbidden: bool = false member on
stack-only BodyHeadEvent. No retained factory, Router-context replacement,
extra connection/driver/slot pointer, or new stored state. Preserve legacy event
literals. Measure before and declaration-only after on Linux, macOS and Windows:
BodyHeadEvent/BodyEvent size/alignment and existing field offsets, plus actual
Session/TCP/Driver/Slot types and native slab totals/offsets for unchanged stored
layout evidence. Use compile-only CompileLog, not runtime/native experiments.
Store exact one-field diff, inventories/inputs/commands/raw hashed logs and table
under .uwz-work/evidence/h2-streaming/native-admission-fact/. Small helper inputs
must also be saved there, with all heavy copies/cache/binaries under /tmp.
Report measurements to Root and wait for an explicit adoption ruling before
projecting the field or implementing behavior. Padding absorption is not assumed.

Stage B, only after Root ruling: Driver.begin projects head.early_data_forbidden
into existing neutral body_admission.Input instead of the current literal false.
Target.context remains Router; existing startup resolver, metadata/capture,
reservation/response/Continue/error contracts are unchanged. Native policy
derivation via conn.early_data_forbids(method) belongs to the next TCP slice.

Add a meaningful failing-before/passing-after regression using the real encoded
HEADERS -> Session -> registered driver/admission fixture. Its caller-owned event
adapter copies/enriches the head as the native adapter will. A forbidden selected
head must yield425 before middleware, quota reservation, begin or100 Continue.
Check no quota leakage; a later ordinary sibling still enters the sink. Preserve
existing default-false positive coverage/literals. A declaration-only compile
failure is not the behavioral red: run the test with the field present but old
driver projection, retain actual compile0/run1 evidence, then change projection.
This proves policy input propagation; no genuine early-data/TLS/socket claim.

Use current Zig0.16/project conventions, named types, max3 control levels,
caller-owned bounded storage, no allocation, forwarding wrappers or speculative
API. The already oversized test fixture is a review flag; add only cohesive
coverage and explain its size change instead of mechanically splitting it.

Freeze source before covering checks. Run the concrete driver root and H1/shared
admission root in Debug/ReleaseSafe; use covering healthy App/config/H2 server/
refusal/frame/HPACK/queue/width positives only when the new field or evidence
shows need. Existing H2 server execution is limited to exact 'http2 server:'
filter40, healthy App only the previously approved8 filters. Complete central
graph may compile Linux/macOS/Windows; eligible32 queue/matrix/selected compile
evidence is distinct from unsupported full-driver32. Run formatting/conventions/
release-version/docs and identical-copy Graphify AST refresh after changes.
Do not weaken any gate or imply the full gate ran.

The original stopped native cancellation experiment, two EPERM socket cases,
all new native cancellation races/schedules/resource/kernel-error/injected-
completion/panic probes stay prohibited. Full isolated native runtime, sanitizer
runtime, h1spec runner and new native/client activation remain unrun. Preserve
all original full M2 acceptance gates and record these limitations honestly.

Create a final reconstruction package with preimages/finals/full inventory,
zero-context cumulative three-file patch, actual source/compiler/module/library/
override/binary/environment identities and immediate raw-log hashes. Override is
/tmp/uwz-reviewed-libxev-c223-loop-callbacks, checked93 files from local objects;
workspace zig-pkg/zslay and zig-out/lib plus preserved c bindings remain inputs.
The old Task4b record argv is a command reference, not evidence of a new run.
Write exact commands/outcomes/limitations and phase-A ruling in
.superpowers/sdd/h2_streaming_plan/task-4c-report.md before requesting review.
Return only DONE/status, artifact paths, source digest and a concise check summary.

Graphify query before new codebase searches if graph exists. Known brief/handoff
and supplied source locations are already located; do not read broad inventories
into tool output. No source edits to immutable baselines or relabeling old runs.
