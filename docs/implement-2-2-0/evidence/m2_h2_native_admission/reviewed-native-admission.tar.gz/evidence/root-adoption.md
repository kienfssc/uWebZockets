# Root Stage A adoption ruling

Approve the additive default-false early_data_forbidden member on stack-only
BodyHeadEvent and its projection into the existing admission input. No new
retained state, Router target replacement, native callback activation or genuine
TLS early-data claim is approved by this ruling.

Root inspected the one-field declaration patch and actual1029-file inventories:
baseline aa420a97e62062d78c0d3c2fd2f35df11115ef85b8b7cfe316d3734d592a6fd0,
declaration399d9ed213f6671ac9444b94f76627e3a187d7408fa2f9672c2b34a2a4ee4d30.
All paths match their expected bytes. Root verified twelve raw-log/helper hashes
and expected CompileLog exits, then compared actual compile-log outputs for each
of Linux/macOS/Windows: the only added output is the new head field at offset31;
all previous type/field/union/slab outputs and private offset values are equal.
Head stays32/8, Event40/8. No stored layout growth is introduced on those targets.
Eligible32 and full native gates retain their stated limitations.

Ruling: adopt the measured additive stack fact — it preserves existing literals
and the Router boundary while allowing native policy to reach shared admission.
If wrong, the cost is an additional internal event API field and a reviewed
three-file revert; no maintained pin or native activation is involved here.

Proceed to Stage B under task-4c-brief.md: actual encoded selected-head425 red
with the field present but old driver projection, then narrow projection and
covering checks. Save immediate raw-log hashes and final reconstruction package.
