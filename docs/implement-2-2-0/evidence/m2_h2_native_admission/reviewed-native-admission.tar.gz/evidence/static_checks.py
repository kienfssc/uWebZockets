import os,pathlib,subprocess,json,hashlib
E=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-admission-fact'); cwd='/tmp/uwz-task4c-final-frozen'
env=os.environ.copy(); env['PATH']='/home/codespace/.codex/packages/app-server-daemon/releases/0.165.0-x86_64-unknown-linux-musl/codex-path:'+env['PATH']
for name,args in [('fmt',['/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig','fmt','--check','src','builds','examples','tests','fuzz']),('conventions',['sh','scripts/check_conventions.sh']),('version',['sh','scripts/check_release_version.sh']),('docs',['sh','scripts/check_docs.sh'])]:
 r=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); p=E/(name+'.log'); p.write_bytes(r.stdout)
 (E/(name+'.json')).write_text(json.dumps({'argv':args,'cwd':cwd,'PATH':env['PATH'],'exit':r.returncode,'log_sha256':hashlib.sha256(r.stdout).hexdigest()},indent=2)+'\n'); print(name,r.returncode,flush=True)
