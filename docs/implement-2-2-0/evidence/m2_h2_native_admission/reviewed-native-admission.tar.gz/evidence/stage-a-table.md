# Declaration-only measurements

All entries are before = after, size/alignment in bytes. Existing field offsets and all native slab offsets match exactly. The new field is at offset 31 on each target. CompileLog exits 1 by design.

| Target | Head | Event | Session8 | TCP | Driver | Slot | Slab totals (profiles 0–3) |
|---|---:|---:|---:|---:|---:|---:|---|
| linux | 32/8 | 40/8 | 1392/8 | 25648/8 | 1288/8 | 152/8 | 2378336, 684185216, 764591744, 5431552 |
| macos | 32/8 | 40/8 | 1392/8 | 25568/8 | 1288/8 | 152/8 | 2378080, 684103296, 764477056, 5430656 |
| windows | 32/8 | 40/8 | 1392/8 | 26136/8 | 1288/8 | 152/8 | 2379616, 684684928, 765255296, 5436736 |

Head existing offsets: request 0, declared 8, stream_id 24, stream_index 28, end_stream 30. Full per-field and slab offset values are in the raw logs. Profiles correspond to layout.zig and offsets.zig. Accounting copies expose only layout_offsets visibility; their config hashes are in per-run records.

No runtime, native clients or behavior tests were performed. The field has not been adopted; Driver remains unchanged.
