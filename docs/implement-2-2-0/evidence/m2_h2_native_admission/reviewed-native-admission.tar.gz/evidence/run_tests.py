import hashlib,json,pathlib,subprocess,sys,os
E=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-admission-fact'); H=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-terminal/fix1')
source=pathlib.Path(sys.argv[1]); phase=sys.argv[2]; root=sys.argv[3]; mode=sys.argv[4]
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
inv=lambda d:[[str(f.relative_to(d)),sha(f)] for f in sorted(d.rglob('*')) if f.is_file()]
tree=lambda d:hashlib.sha256(json.dumps(inv(d)).encode()).hexdigest()
template=json.loads((H/f'final-{root}-{mode}.json').read_text()); args=template['argv'][:]
name=f'{phase}-{root}-{mode}'; binary='/tmp/uwz-task4c-artifacts/'+name
pathlib.Path(binary).parent.mkdir(exist_ok=True)
args=[('/tmp/uwz-task4c-cache' if a=='/tmp/uwz-task4b-artifacts/cache' else '/tmp/uwz-task4c-global' if a=='/tmp/uwz-task4b-artifacts/global' else '-femit-bin='+binary if a.startswith('-femit-bin=') else a) for a in args]
if phase=='red': args.extend(['--test-filter','enriched forbidden head'])
inputs={}
for a in args:
 p=None
 if a.startswith('-M') and '=' in a: p=a.split('=',1)[1]
 elif a.endswith('.a') or a==args[0]: p=a
 if p:
  path=pathlib.Path(p); path=path if path.is_absolute() else source/path
  if path.is_file(): inputs[str(path)]=sha(path)
over=pathlib.Path('/tmp/uwz-reviewed-libxev-c223-loop-callbacks'); override={p:h for p,h in inv(over)}
old=template['override_before']; assert override==old and len(override)==93
before=tree(source); comp=subprocess.run(args,cwd=source,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
cl=E/(name+'-compile.log'); cl.write_bytes(comp.stdout)
rec={'cwd':str(source),'source_before':before,'argv':args,'inputs':inputs,'override_sha256':hashlib.sha256(json.dumps(override,sort_keys=True).encode()).hexdigest(),'override_files':len(override),'compile_exit':comp.returncode,'compile_log_sha256':sha(cl),'environment':{k:os.environ.get(k) for k in ['PATH','LANG','LC_ALL','UWZ_TEST_XEV_BACKEND']}}
if comp.returncode==0:
 run=subprocess.run([binary],cwd=source,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); rl=E/(name+'-run.log'); rl.write_bytes(run.stdout)
 rec.update(binary_sha256=sha(binary),run_argv=[binary],run_exit=run.returncode,run_log_sha256=sha(rl))
rec['source_after']=tree(source); assert rec['source_after']==before
(E/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
print(name,'compile',comp.returncode,'run',rec.get('run_exit'),flush=True)
