import hashlib,json,pathlib,shutil,subprocess,os
E=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-admission-fact')
H=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-terminal/fix1')
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
records=[]
for variant, source in [('before',pathlib.Path('/tmp/uwz-task4b-fix1-frozen')),('after',pathlib.Path('/tmp/uwz-task4c-declaration'))]:
 acc=pathlib.Path('/tmp/uwz-task4c-accounting-'+variant)
 if not acc.exists(): shutil.copytree(source,acc)
 p=acc/'src/router/config.zig'; s=p.read_text(); assert s.count('fn layout_offsets(config: ServerConfig)')==1
 p.chmod(0o644); p.write_text(s.replace('fn layout_offsets(config: ServerConfig)','pub fn layout_offsets(config: ServerConfig)'))
 for osname in ['linux','macos','windows']:
  for kind in ['layout','offsets']:
   template=json.loads((H/f'measure-{kind}-{osname}-after.json').read_text())
   argv=template['argv'][:]
   argv=[('-Mroot='+str(E/(kind+'.zig'))) if x.startswith('-Mroot=') else ('/tmp/uwz-task4c-cache' if x=='/tmp/uwz-task4b-artifacts/cache' else '/tmp/uwz-task4c-global' if x=='/tmp/uwz-task4b-artifacts/global' else x) for x in argv]
   cwd=source if kind=='layout' else acc
   result=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   log=E/f'{kind}-{osname}-{variant}.log'; log.write_bytes(result.stdout)
   rec={'argv':argv,'cwd':str(cwd),'exit':result.returncode,'log_sha256':sha(log),'helper_sha256':sha(E/(kind+'.zig')),'source_tree': 'aa420a97e62062d78c0d3c2fd2f35df11115ef85b8b7cfe316d3734d592a6fd0' if variant=='before' else '399d9ed213f6671ac9444b94f76627e3a187d7408fa2f9672c2b34a2a4ee4d30','accounting_config_sha256':sha(p) if kind=='offsets' else None}
   (E/f'{kind}-{osname}-{variant}.json').write_text(json.dumps(rec,indent=2)+'\n')
   print(kind,osname,variant,result.returncode,'compile log',b'Compile Log Output:' in result.stdout,flush=True)
   records.append(rec)
(E/'environment.json').write_text(json.dumps({k:os.environ.get(k) for k in ['PATH','LANG','LC_ALL','ZIG_GLOBAL_CACHE_DIR']},sort_keys=True,indent=2)+'\n')
