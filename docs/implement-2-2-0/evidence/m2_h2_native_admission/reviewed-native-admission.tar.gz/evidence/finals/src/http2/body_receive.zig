const queue = @import("body_queue.zig");
const body = @import("../http/request_body.zig");
const Request = @import("../http/request.zig").Request;

/// Identity belongs to the Session slot; slices are borrowed only through return.
pub const BodyHeadEvent = struct { stream_id: u32, stream_index: u16, request: *Request, declared: ?u64, end_stream: bool, early_data_forbidden: bool = false };
pub const BodyDataEvent = struct { stream_id: u32, stream_index: u16, bytes: []const u8, fresh: bool, delivery_allowed: bool };
pub const BodyEndEvent = struct { stream_id: u32, stream_index: u16 };
/// A limit failure requests a fresh final response; ordinary closes only cancel.
pub const BodyClosedEvent = struct {
    stream_id: u32,
    stream_index: u16,
    reason: body.BodyCancelReason,
    final_body_too_large: bool = false,
};
pub const BodyEvent = union(enum) { head: BodyHeadEvent, data: BodyDataEvent, end: BodyEndEvent, closed: BodyClosedEvent };
pub const BodyHeadResult = union(enum) { accepted: body.BodyReadiness, final };
pub const BodyEventResult = union(enum) { head: BodyHeadResult, data: body.BodyProgress, done };
pub const BodySelectFn = *const fn (*anyopaque, *const Request) bool;
pub const BodyEventFn = *const fn (*anyopaque, BodyEvent) anyerror!BodyEventResult;

/// Receive ownership is separate from outgoing response and sink binding life.
pub const Mode = enum { buffered, streaming, ended };

/// One optional cold region, with no per-stream payload window or hidden owner.
pub fn receive_state(comptime max_streams: usize) type {
    return struct {
        queue: queue.Queue,
        connection_pending: u32 = 0,
        stream_pending: [max_streams]u32 = .{0} ** max_streams,
        modes: [max_streams]Mode = .{.buffered} ** max_streams,
        paused: [max_streams]bool = .{false} ** max_streams,
        eof: [max_streams]bool = .{false} ** max_streams,
        continue_pending: [max_streams]bool = .{false} ** max_streams,
        close_causes: [max_streams]?body.BodyCancelReason = .{null} ** max_streams,
        credit_abandoned: bool = false,
    };
}
