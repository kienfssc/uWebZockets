import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

repo = Path('/workspaces/uWebZockets')
evidence = repo / '.uwz-work/evidence/h2-streaming/native-admission-fact'
package = json.loads((evidence / 'package.json').read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(rows):
    return hashlib.sha256(json.dumps(rows).encode()).hexdigest()


inventories = {}
for name, root in [('baseline', Path('/tmp/uwz-task4b-fix1-frozen')), ('final', Path('/tmp/uwz-task4c-final-frozen'))]:
    rows = json.loads((evidence / (name + '-inventory.json')).read_text())
    assert len(rows) == 1029 and len({rel for rel, expected in rows}) == 1029
    assert all(sha(root / rel) == expected for rel, expected in rows)
    inventories[name] = rows
    assert digest(rows) == package[name + '_digest']

before, after = dict(inventories['baseline']), dict(inventories['final'])
changed = sorted(rel for rel in before if before[rel] != after[rel])
assert changed == sorted(package['paths']) and len(changed) == 3
red_rows = [[rel, before[rel] if rel == 'src/core/http2_upload.zig' else identity] for rel, identity in inventories['final']]
red_digest = digest(red_rows)
red = json.loads((evidence / 'red-http2_upload_driver_tests-Debug.json').read_text())
assert red['source_before'] == red['source_after'] == red_digest

override = json.loads((evidence / 'identity-recheck.json').read_text())['override_inventory']
override_root = Path('/tmp/uwz-reviewed-libxev-c223-loop-callbacks')
assert len(override) == 93 and all(sha(override_root / rel) == expected for rel, expected in override.items())
actual_override_paths = sorted(str(p.relative_to(override_root)) for p in override_root.rglob('*') if p.is_file())
assert actual_override_paths == sorted(override)
override_digest = hashlib.sha256(json.dumps(override, sort_keys=True).encode()).hexdigest()
assert sha(repo / '.uwz-work/evidence/loop-callbacks/immutable-libxev-input.json') == 'af909377909a4f0509e8b6c2fdcee1c96d2567d6757f33bf3c197f2ce4897980'

checks = []
for record_path in sorted(evidence.glob('*.json')):
    record = json.loads(record_path.read_text())
    if not isinstance(record, dict) or 'compile_exit' not in record:
        continue
    name = record_path.stem
    assert record['compile_exit'] == 0
    assert record['source_before'] == record['source_after']
    assert record['override_sha256'] == override_digest and record['override_files'] == 93
    for path, expected in record['inputs'].items():
        assert sha(Path(path)) == expected, path
    assert sha(evidence / (name + '-compile.log')) == record['compile_log_sha256']
    run_log = evidence / (name + '-run.log')
    assert sha(run_log) == record['run_log_sha256']
    assert sha(Path(record['run_argv'][0])) == record['binary_sha256']
    if name.startswith('red-'):
        assert record['run_exit'] == 1 and record['source_before'] == red_digest
        text = run_log.read_text()
        assert '425' in text and '100' in text and 'FAIL (TestExpectedEqual)' in text
        count = 1
    else:
        assert record['run_exit'] == 0 and record['source_before'] == package['final_digest']
        count = int(re.search(r'All (\d+) tests passed\.', run_log.read_text()).group(1))
        assert count == (40 if 'http2_upload_driver' in name else 7)
    checks.append({'record': record_path.name, 'source': record['source_before'], 'compile_exit': 0, 'run_exit': record['run_exit'], 'results': count, 'logs_binary_inputs_match': True})
assert len(checks) == 5

measurements = []
for target in ['linux', 'macos', 'windows']:
    outputs = {}
    for kind in ['layout', 'offsets']:
        for side in ['before', 'after']:
            name = f'{kind}-{target}-{side}'
            record = json.loads((evidence / (name + '.json')).read_text())
            log = evidence / (name + '.log')
            assert record['exit'] == 1 and sha(log) == record['log_sha256']
            assert sha(evidence / (kind + '.zig')) == record['helper_sha256']
            assert 'error: found compile log statement' in log.read_text()
            outputs[kind, side] = log.read_text().split('Compile Log Output:')[-1].strip().splitlines()
            measurements.append(name)
    added = [line for line in outputs['layout', 'after'] if '"early_data_forbidden"' in line]
    assert len(added) == 1 and '@as(comptime_int, 31)' in added[0]
    assert outputs['layout', 'before'] == [line for line in outputs['layout', 'after'] if '"early_data_forbidden"' not in line]
    assert outputs['offsets', 'before'] == outputs['offsets', 'after']

for name in ['fmt', 'conventions', 'version', 'docs', 'graphify']:
    record = json.loads((evidence / (name + '.json')).read_text())
    assert record['exit'] == 0 and sha(evidence / (name + '.log')) == record['log_sha256']
graph_root = Path('/tmp/uwz-task4c-graphify')
assert all(sha(graph_root / rel) == expected for rel, expected in inventories['final'])

patch = evidence / 'final.patch'
assert sha(patch) == package['patch_sha256']
scratch = Path('/tmp/uwz-task4c-root-reconstruct')
assert not scratch.exists()
for rel, expected in inventories['baseline']:
    path = scratch / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(Path('/tmp/uwz-task4b-fix1-frozen') / rel, path)
apply = []
for option in ['--check', None]:
    argv = ['git', 'apply', '--unidiff-zero'] + ([option] if option else []) + [str(patch)]
    result = subprocess.run(argv, cwd=scratch, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    apply.append({'argv': argv, 'exit': result.returncode, 'stderr': result.stderr})
assert all(sha(scratch / rel) == expected for rel, expected in inventories['final'])
assert len([p for p in scratch.rglob('*') if p.is_file()]) == 1029

audit = {'scope': 'evidence/reconstruction audit; no compiler/test/native action', 'baseline_digest': package['baseline_digest'], 'final_digest': package['final_digest'], 'source_files': 1029, 'changed_paths': changed, 'behavioral_red_digest': red_digest, 'runtime_checks': checks, 'selected_results_per_mode': 47, 'override_files': 93, 'measurement_records': measurements, 'static_and_ast_hashes_match': True, 'patch_sha256': sha(patch), 'apply': apply, 'exact_full_reconstruction': True, 'limits': ['No full central, native/live, sanitizer, h1spec or genuine TLS early-data acceptance', 'The declaration and red source paths were later reused; preserved inventories and the single production projection difference reconstruct their historical bytes', 'Measurements are CompileLog exit1 and not runtime tests']}
(evidence / 'root-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({'final_digest': audit['final_digest'], 'source_files': 1029, 'runtime_pairs': len(checks), 'results_per_mode': 47, 'override_files': 93, 'measurement_records': len(measurements), 'exact_full_reconstruction': True, 'root_audit_sha256': sha(evidence / 'root-audit.json')}, indent=2))
