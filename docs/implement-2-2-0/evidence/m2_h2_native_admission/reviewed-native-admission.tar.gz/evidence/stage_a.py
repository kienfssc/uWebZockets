import hashlib, json, pathlib, shutil, subprocess, os
E=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-admission-fact')
B=pathlib.Path('/tmp/uwz-task4b-fix1-frozen')
C=pathlib.Path('/tmp/uwz-task4c-declaration')
expected=json.loads(pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-terminal/fix1/source.json').read_text())
def inventory(p):
 return [[str(f.relative_to(p)),hashlib.sha256(f.read_bytes()).hexdigest()] for f in sorted(p.rglob('*')) if f.is_file()]
def digest(x): return hashlib.sha256(json.dumps(x).encode()).hexdigest()
b=inventory(B)
assert b==expected and len(b)==1029 and digest(b)=='aa420a97e62062d78c0d3c2fd2f35df11115ef85b8b7cfe316d3734d592a6fd0'
if not C.exists(): shutil.copytree(B,C)
assert inventory(C)==b
(E/'baseline-inventory.json').write_text(json.dumps(b,indent=2)+'\n')
p=C/'src/http2/body_receive.zig'
s=p.read_text(); a='declared: ?u64, end_stream: bool };'; n='declared: ?u64, end_stream: bool, early_data_forbidden: bool = false };'
assert s.count(a)==1
p.chmod(0o644)
p.write_text(s.replace(a,n))
c=inventory(C)
assert [x[0] for x,y in zip(c,b) if x!=y]==['src/http2/body_receive.zig']
(E/'declaration-inventory.json').write_text(json.dumps(c,indent=2)+'\n')
patch=subprocess.run(['diff','-u',str(B/'src/http2/body_receive.zig'),str(p)],capture_output=True,text=True)
assert patch.returncode==1
(E/'declaration.patch').write_text(patch.stdout)
print('baseline',digest(b),'candidate',digest(c),'files',len(c))
