import pathlib,hashlib,json,subprocess,shutil
E=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-admission-fact'); B=pathlib.Path('/tmp/uwz-task4b-fix1-frozen'); F=pathlib.Path('/tmp/uwz-task4c-final-frozen')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inv(d): return [[str(p.relative_to(d)),sha(p)] for p in sorted(d.rglob('*')) if p.is_file()]
b=inv(B); f=inv(F); assert len(b)==len(f)==1029
names=['src/http2/body_receive.zig','src/core/http2_upload.zig','src/tests/http2_upload_driver_tests.zig']
assert set(x[0] for x,y in zip(f,b) if x!=y)==set(names)
(E/'final-inventory.json').write_text(json.dumps(f,indent=2)+'\n')
for prefix,d in [('preimages',B),('finals',F)]:
 for n in names:
  dst=E/prefix/n; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(d/n,dst)
patch=b''
for n in names:
 r=subprocess.run(['diff','-U0','--label','a/'+n,'--label','b/'+n,str(B/n),str(F/n)],capture_output=True); assert r.returncode==1; patch+=r.stdout
(E/'final.patch').write_bytes(patch)
tree=lambda i:hashlib.sha256(json.dumps(i).encode()).hexdigest()
rec={'baseline_digest':tree(b),'final_digest':tree(f),'paths':names,'patch_sha256':sha(E/'final.patch'),'file_count':len(f),'preimage_hashes':{n:sha(B/n) for n in names},'final_hashes':{n:sha(F/n) for n in names}}
(E/'package.json').write_text(json.dumps(rec,indent=2)+'\n'); print(json.dumps(rec,indent=2))
