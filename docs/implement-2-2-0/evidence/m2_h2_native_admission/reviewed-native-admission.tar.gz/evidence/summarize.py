import hashlib,json,pathlib,re,os
E=pathlib.Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-admission-fact')
rows=[]
for platform in ('linux','macos','windows'):
 before=(E/f'layout-{platform}-before.log').read_text(); after=(E/f'layout-{platform}-after.log').read_text()
 assert before.splitlines()==[x for x in after.splitlines() if '"early_data_forbidden"' not in x]
 assert (E/f'offsets-{platform}-before.log').read_bytes()==(E/f'offsets-{platform}-after.log').read_bytes()
 types={}
 for t in ('BodyHeadEvent','Session8','TcpConnection','Driver','DriverSlot'):
  m=re.search(r'"type".*?"'+t+r'".*?@as\(comptime_int, (\d+)\), @as\(comptime_int, (\d+)\)',after); assert m,t; types[t]='/'.join(m.groups())
 m=re.search(r'"event_union".*?@as\(comptime_int, (\d+)\), @as\(comptime_int, (\d+)\)',after); types['BodyEvent']='/'.join(m.groups())
 offsets=re.findall(r'\.total_bytes = (\d+)',(E/f'offsets-{platform}-after.log').read_text()); assert len(offsets)==4
 rows.append((platform,types,offsets))
lines=['# Declaration-only measurements','', 'All entries are before = after, size/alignment in bytes. Existing field offsets and all native slab offsets match exactly. The new field is at offset 31 on each target. CompileLog exits 1 by design.','', '| Target | Head | Event | Session8 | TCP | Driver | Slot | Slab totals (profiles 0–3) |','|---|---:|---:|---:|---:|---:|---:|---|']
for p,t,o in rows: lines.append('| '+p+' | '+' | '.join(t[k] for k in ('BodyHeadEvent','BodyEvent','Session8','TcpConnection','Driver','DriverSlot'))+' | '+', '.join(o)+' |')
lines += ['', 'Head existing offsets: request 0, declared 8, stream_id 24, stream_index 28, end_stream 30. Full per-field and slab offset values are in the raw logs. Profiles correspond to layout.zig and offsets.zig. Accounting copies expose only layout_offsets visibility; their config hashes are in per-run records.','', 'No runtime, native clients or behavior tests were performed. The field has not been adopted; Driver remains unchanged.']
(E/'stage-a-table.md').write_text('\n'.join(lines)+'\n')
inputs=set()
for r in E.glob('layout-*-*.json'):
 rec=json.loads(r.read_text())
 for a in rec['argv']:
  if a.startswith('-M') and '=' in a:
   v=a.split('=',1)[1]; p=pathlib.Path(v); p=p if p.is_absolute() else pathlib.Path(rec['cwd'])/p
   if p.is_file(): inputs.add(str(p))
 inputs.add(rec['argv'][0])
inputs.update(str(E/x) for x in ['stage_a.py','measure.py','summarize.py','layout.zig','offsets.zig'])
(E/'inputs.json').write_text(json.dumps({p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in sorted(inputs)},indent=2)+'\n')
(E/'environment.json').write_text(json.dumps({k:os.environ.get(k) for k in ['PATH','LANG','LC_ALL','ZIG_GLOBAL_CACHE_DIR']},indent=2)+'\n')
print('\n'.join(lines))
