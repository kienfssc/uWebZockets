import sys,json,hashlib,subprocess,time
from pathlib import Path
base=Path('/workspaces/uWebZockets/.uwz-work/drafts/m2-multipart-sink')
out=Path('/workspaces/uWebZockets/.uwz-work/evidence/multipart-sink')
label=sys.argv[1]
argv=['/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig','test','--cache-dir','/tmp/uwz-multipart-sink-cache','--global-cache-dir','/tmp/uwz-multipart-sink-global',*sys.argv[2:],'--dep','test_support','-Mroot=src/tests/multipart_sink_tests.zig','-Mtest_support=src/multipart_sink_focus_support.zig']
files=['src/http/multipart.zig','src/http/multipart_streaming.zig','src/http/multipart_sink.zig','src/http/request_body.zig','src/tests/multipart_sink_tests.zig','src/multipart_sink_focus_support.zig']
def hashes(): return {f:hashlib.sha256((base/f).read_bytes()).hexdigest() for f in files if (base/f).is_file()}
record={'argv':argv,'cwd':str(base),'source_before':hashes()}
(out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
with (out/(label+'.stdout')).open('wb') as so,(out/(label+'.stderr')).open('wb') as se:
 p=subprocess.run(argv,cwd=base,stdout=so,stderr=se)
record.update(exit_status=p.returncode,elapsed_seconds=time.monotonic()-start,source_after=hashes())
(out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'label':label,'exit_status':p.returncode,'elapsed_seconds':record['elapsed_seconds']}))
print((out/(label+'.stderr')).read_text()[-16000:])
sys.exit(p.returncode)
