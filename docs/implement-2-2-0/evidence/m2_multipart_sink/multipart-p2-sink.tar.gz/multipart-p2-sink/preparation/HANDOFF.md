# P2 multipart part-sink adapter, preparation v1

Root-owned isolated clone; five source files are frozen by p2-v1-manifest.json, p2-v1.patch and p2-v1-sources.tar.gz. Parent is the current frozen root P1 overlay, not a new transport implementation. Source preimages retained. Production adapter95lines, plus additive multipart callback/sink aliases, test_support exposure and central import.

15 focused tests pass Debug/ReleaseSafe on actual parser/common BodyState. Covers complete entities, begin/write/end pause, every payload ack prefix, relocated and poisoned one-byte input through false-prefix replay, failed begin/no cancel, write/parser error cleanup after outer unwind, end owns allcleanup, invalid progress beforeack, failed finish cancels acceptedpart once, metadata pause cancellation and exact once. Three tests compose real BodyState/BodyControl toprove final paused end resumeswithout syntheticemptychunk, callbackfailure cleanup+expiredcontrol, and failed outerend releasesonce without latercancel.

Callbacks may not reenter adapter or freecontainingupload. Markactive onlyafterbeginsuccess; markinactivebeforeend; failedconsume latchesphase butretainsactivepartforoutercancel; finish owns cleanup even onerror; terminalcancel idempotent. Allstate explicit/callerowned, noallocation. No BodySinkfactory/filehelper orautomaticHTTPstatus policy.

RED missing-adapter failure retained. First implementation run8/9 passed; ninthfailed because testhardcodedheaderprefix58 instead ofactual60. Fixture corrected to independent payload offset; productionunchanged. Later15/15 successful. Fmt/conventions/release checks0; pure facade avoids eager Cexports and is retained. Actual combinedrootnative/SAN/cross/package/transport gates remain unrun forP2. RootP1matrix sourceuntouched.
