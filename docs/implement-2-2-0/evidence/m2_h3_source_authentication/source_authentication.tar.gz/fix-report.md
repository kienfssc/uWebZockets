# Source authentication publication evidence

Status: DONE as a source-only checkpoint, pending independent publication review.
Base6dd82957121ec8775efa3093b38837cf0641e17e, working-tree six-file publication.
Read the source-authentication brief and diff. The binary archive's actual raw
members are read-only review inputs; no execution is needed to review them.

Root ran python3 -B -S authenticate_qdec.py from the plan workspace on2026-10-29.
Tool/result/source are retained under qdec-provenance and the public archive.
All9 sequential Git commands exited0. list-heads advertised exact maintained
pin under refs/archive/current-pin; bundle verify, offline fetch and full strict
fsck succeeded in a fresh private temporary bare repo. Init's harmless default-
branch hint is retained in raw stderr. File transport only and disabled hooks;
existing repos/refs/pins/cache-source untouched. Cached source before/after
equals actual git-show bytes at the exact pin. No native/network/build activity.

Commit tree95340670eafa7f68d3b6aa5ed06e4c74e07663cc;
qdec blobc7046698107512a926542dcf46f5a8144b1010c7. The exact file and digests are
in the brief/manifest. Archive0f9a5b05b70bd12e02e303322015a2851a5765235f17526721d31706c87bd11b,
17863B,4safe regular members/3inventoryentries. Root readback checks each member
byte-for-byte against its original source, not merely the tar metadata.

Executed checks, current unchanged product source:
- zig fmt src builds examples tests fuzz: exit0, emptyoutput.
- sh scripts/check_conventions.sh: exit0, emptyoutput.
- sh scripts/check_release_version.sh: exit0, release metadata matches2.1.6.
- sh scripts/check_docs.sh: exit0, markdown documentation links resolve.
- git diff --check: exit0, emptyoutput.

No new behavior was implemented, so no behavioral red or product test claim.
Full native central/sanitizer/platform/compliance/genuineearlydata/adoption/
release gates remain open under the original stop boundaries. Current graph
refresh is separately recorded before commit. Source identities are the scope;
complete native reachability/enforcement is not proved by this checkpoint.

Self-review: unique regular member extraction only; outer/bundle SHA checks;
bare Git restore only; disabled hooks/system/global config and file-only
transport; exact advertised commit check before source read; cached data read
before/after; full raw statuses and stdout/stderr; portable recovery already
available in original archive. Current tool records absolute run paths and
requires fresh output; public README explicitly explains adaptation for another
checkout. No local dependency patch/build input or milestone closure added.

Root publication audit PASS:4safe members/3inventoryentries, all9command statuses/stream hashes, actual Git blob SHA1/source SHA256, original archive and embedded bundle digests match. AST-only graphify update . exit0:15548nodes/18579edges/2672communities, restricted parallel extraction falls back successfully to sequential; no API/LLM call. No full semantic-document extraction or native gate is claimed.

## Source authentication fix round 1, 2026-10-29

The v1 tool/result/source were copied byte-for-byte to
`qdec-provenance-v1/authenticate_qdec.py`, `result.json`, and
`lsquic_qdec_hdl.c` before the tool changed. Their SHA-256 digests are
`f960a141f59a87631daf1c13e4dbd26dd0de1198a83499c8f2af7da3b256a595`,
`ef0d28b122c15fd1e753f162749cda24879df6dcbd74a1012dbb729778746193`,
and `093dbe960188830e121518bf1f932c8cb7e570214d9dc4adcd699ef1b688940b`.
The original `qdec-provenance/` files were not overwritten.

The tool's `assert` proof checks were replaced with explicit `ValueError`,
`RuntimeError`, or `FileExistsError` failures. The retained tree, blob, source
length, and source SHA-256 are now checked as fixed commitments. The output
is `qdec-provenance-v2/`; the result records actual `sys.flags.optimize`,
interpreter name/version/executable. Import remains inert.

RED command, run against the v1 tool (SHA-256 above):

```sh
PYTHONOPTIMIZE=1 python3 -B -S -O -m unittest discover -s .superpowers/sdd/m2_h3_streaming_plan -p test_authenticate_qdec.py -v
```

Raw RED output (exit 1):

```text
test_optimized_execution_rejects_changed_cached_file (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_changed_cached_file) ... /workspaces/uWebZockets/.superpowers/sdd/m2_h3_streaming_plan/authenticate_qdec.py:27: ResourceWarning: unclosed file <_io.BufferedReader name='/workspaces/uWebZockets/docs/implement-2-2-0/evidence/m3_pin_archives/current_pins.tar.gz'>
  archive_sha = hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest()
ResourceWarning: Enable tracemalloc to get the object allocation traceback
FAIL
test_optimized_execution_rejects_failed_git_command (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_failed_git_command) ... /workspaces/uWebZockets/.superpowers/sdd/m2_h3_streaming_plan/authenticate_qdec.py:27: ResourceWarning: unclosed file <_io.BufferedReader name='/workspaces/uWebZockets/docs/implement-2-2-0/evidence/m3_pin_archives/current_pins.tar.gz'>
  archive_sha = hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest()
ResourceWarning: Enable tracemalloc to get the object allocation traceback
ERROR
test_optimized_execution_rejects_unadvertised_pin (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_unadvertised_pin) ... ERROR
test_optimized_execution_rejects_wrong_archive_digest (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_wrong_archive_digest) ... /workspaces/uWebZockets/.superpowers/sdd/m2_h3_streaming_plan/authenticate_qdec.py:27: ResourceWarning: unclosed file <_io.BufferedReader name='/workspaces/uWebZockets/docs/implement-2-2-0/evidence/m3_pin_archives/current_pins.tar.gz'>
  archive_sha = hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest()
ResourceWarning: Enable tracemalloc to get the object allocation traceback
FAIL
test_optimized_execution_rejects_wrong_bundle_digest (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_wrong_bundle_digest) ... /workspaces/uWebZockets/.superpowers/sdd/m2_h3_streaming_plan/authenticate_qdec.py:27: ResourceWarning: unclosed file <_io.BufferedReader name='/workspaces/uWebZockets/docs/implement-2-2-0/evidence/m3_pin_archives/current_pins.tar.gz'>
  archive_sha = hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest()
ResourceWarning: Enable tracemalloc to get the object allocation traceback
{"status": "PASS", "pin": "85bd081c9103c077a7cc98271d09334d0f1043d4", "tree": "95340670eafa7f68d3b6aa5ed06e4c74e07663cc", "source_blob": "c7046698107512a926542dcf46f5a8144b1010c7", "source_bytes": 31642, "source_sha256": "093dbe960188830e121518bf1f932c8cb7e570214d9dc4adcd699ef1b688940b", "scratch": "/tmp/uwz-h3-qdec-provenance-0p9dfdl3"}
{"status": "PASS", "pin": "85bd081c9103c077a7cc98271d09334d0f1043d4", "tree": "95340670eafa7f68d3b6aa5ed06e4c74e07663cc", "source_blob": "c7046698107512a926542dcf46f5a8144b1010c7", "source_bytes": 31642, "source_sha256": "093dbe960188830e121518bf1f932c8cb7e570214d9dc4adcd699ef1b688940b", "scratch": "/tmp/uwz-h3-qdec-provenance-7259quur"}
{"status": "PASS", "pin": "85bd081c9103c077a7cc98271d09334d0f1043d4", "tree": "95340670eafa7f68d3b6aa5ed06e4c74e07663cc", "source_blob": "c7046698107512a926542dcf46f5a8144b1010c7", "source_bytes": 31642, "source_sha256": "093dbe960188830e121518bf1f932c8cb7e570214d9dc4adcd699ef1b688940b", "scratch": "/tmp/uwz-h3-qdec-provenance-xn8qw0cy"}
FAIL

======================================================================
ERROR: test_optimized_execution_rejects_failed_git_command (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_failed_git_command)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.superpowers/sdd/m2_h3_streaming_plan/test_authenticate_qdec.py", line 58, in test_optimized_execution_rejects_failed_git_command
    tool.main()
    ~~~~~~~~~^^
  File "/workspaces/uWebZockets/.superpowers/sdd/m2_h3_streaming_plan/authenticate_qdec.py", line 66, in main
    git('--git-dir=' + str(bare), 'fetch', '--no-tags', str(bundle), refs[0] + ':refs/heads/pinned-source')
                                                                     ~~~~^^^
IndexError: list index out of range

======================================================================
ERROR: test_optimized_execution_rejects_unadvertised_pin (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_unadvertised_pin)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.superpowers/sdd/m2_h3_streaming_plan/test_authenticate_qdec.py", line 51, in test_optimized_execution_rejects_unadvertised_pin
    tool.main()
    ~~~~~~~~~^^
  File "/workspaces/uWebZockets/.superpowers/sdd/m2_h3_streaming_plan/authenticate_qdec.py", line 66, in main
    git('--git-dir=' + str(bare), 'fetch', '--no-tags', str(bundle), refs[0] + ':refs/heads/pinned-source')
                                                                     ~~~~^^^
IndexError: list index out of range

======================================================================
FAIL: test_optimized_execution_rejects_changed_cached_file (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_changed_cached_file)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.superpowers/sdd/m2_h3_streaming_plan/test_authenticate_qdec.py", line 32, in test_optimized_execution_rejects_changed_cached_file
    with self.assertRaisesRegex(ValueError, 'Cached source differs'):
         ~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: ValueError not raised

======================================================================
FAIL: test_optimized_execution_rejects_wrong_archive_digest (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_wrong_archive_digest)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.superpowers/sdd/m2_h3_streaming_plan/test_authenticate_qdec.py", line 38, in test_optimized_execution_rejects_wrong_archive_digest
    with self.assertRaisesRegex(ValueError, 'Archive SHA-256 differs'):
         ~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: ValueError not raised

======================================================================
FAIL: test_optimized_execution_rejects_wrong_bundle_digest (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_wrong_bundle_digest)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.superpowers/sdd/m2_h3_streaming_plan/test_authenticate_qdec.py", line 44, in test_optimized_execution_rejects_wrong_bundle_digest
    with self.assertRaisesRegex(ValueError, 'Bundle SHA-256 differs'):
         ~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: ValueError not raised

----------------------------------------------------------------------
Ran 5 tests in 7.597s

FAILED (failures=3, errors=2)
```

GREEN command (same exact command, corrected tool SHA-256
`7a368c7c3e2ccfccec285a385a82c5284bbacafd677759e523c32080b73ddc79`),
raw output (exit 0):

```text
test_optimized_execution_rejects_changed_cached_file (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_changed_cached_file) ... ok
test_optimized_execution_rejects_failed_git_command (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_failed_git_command) ... ok
test_optimized_execution_rejects_unadvertised_pin (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_unadvertised_pin) ... ok
test_optimized_execution_rejects_wrong_archive_digest (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_wrong_archive_digest) ... ok
test_optimized_execution_rejects_wrong_bundle_digest (test_authenticate_qdec.AuthenticationTests.test_optimized_execution_rejects_wrong_bundle_digest) ... ok

----------------------------------------------------------------------
Ran 5 tests in 3.147s

OK
```

The one actual corrected-tool run used this command, with exit 0:

```sh
PYTHONOPTIMIZE=1 python3 -B -S -O .superpowers/sdd/m2_h3_streaming_plan/authenticate_qdec.py
```

Raw actual stdout (stderr empty):

```text
{"status": "PASS", "pin": "85bd081c9103c077a7cc98271d09334d0f1043d4", "tree": "95340670eafa7f68d3b6aa5ed06e4c74e07663cc", "source_blob": "c7046698107512a926542dcf46f5a8144b1010c7", "source_bytes": 31642, "source_sha256": "093dbe960188830e121518bf1f932c8cb7e570214d9dc4adcd699ef1b688940b", "scratch": "/tmp/uwz-h3-qdec-provenance-67y_7mhc"}
```

`qdec-provenance-v2/result.json` SHA-256 is
`b2e148c8cdb4bce432383fc825e0ce616e41378c6012cf6de1ebf83f314d9889`.
It contains all nine raw Git command argv/cwd/exit/stdout/stderr and stream
hashes, the exact environment, the retained archive/bundle/pin/tree/blob/source
commitments, and the cached before/after equality. Every Git exit status is 0.
Archive SHA-256 is `d7fad900595499141777bb3f6fcdd8999f1a8e8917a1704432a1afc329a7a6c5`;
bundle SHA-256 is `cbe304c04e2157bbbb5c2eed2e81e9440809391fe4d4dc8c9df051e8325a7d58`
for 9365023 bytes. The actual interpreter was CPython
`3.14.2 (main, Sep 10 2026, 12:33:04) [GCC 13.3.0]` at
`/home/codespace/.python/current/bin/python3`, optimization level 1.
The v2 source SHA-256 is
`093dbe960188830e121518bf1f932c8cb7e570214d9dc4adcd699ef1b688940b`
and its bytes equal the v1 source. The result path remains private until Root
repackages it.

Self-review: every former proof-path assertion is now an unconditional check;
missing pin, failed Git status, wrong archive, wrong bundle, and changed cache
were exercised under optimization. Fresh v2 output and a private bare Git repo
were used. No existing Git source/ref/pin/cache was changed. This remains
source-only provenance; the original native and release gates remain open.

Required local gates after the fix:

```text
zig fmt src builds examples tests fuzz -> exit 127: /bin/bash: line 1: zig: command not found
sh scripts/check_conventions.sh -> exit 0, empty output
sh scripts/check_release_version.sh -> exit 0: release metadata matches 2.1.6
zig build test -> exit 127: /bin/bash: line 1: zig: command not found
git diff --check -> exit 0, empty output
graphify update . -> exit 0: No relevant changes; graphify-out left untouched.
```

A local search of `/workspaces/uWebZockets`, `/opt`, and `/usr/local` found no
Zig compiler executable. Thus the Zig formatting and central test gates were
attempted but could not run in this environment. This tool-only fix and its
optimized Python tests do not claim those gates passed.

Root clarification: the worker shell lacked zig on PATH; Zig exists at /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig. Root already ran actual formatting successfully before this tool-only fix. The worker central-test attempt returned127 before any native execution and is NOT a permitted future rerun: the original explicit native stop remains binding. Full central/sanitizer/platform gates remain unrun, not passed or claimed unavailable solely because of PATH. Root read all five actual optimized RED/GREEN outcomes and the actual v2 command/result before scoped re-review. Original v1 is historical only; current v2 proof uses explicit checks at optimization1.
