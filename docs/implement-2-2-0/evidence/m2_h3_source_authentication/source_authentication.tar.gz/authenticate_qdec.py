"""Authenticate one cached source file from the retained public pin bundle."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile


ROOT = Path('/workspaces/uWebZockets')
PIN = '85bd081c9103c077a7cc98271d09334d0f1043d4'
ARCHIVE_SHA = 'd7fad900595499141777bb3f6fcdd8999f1a8e8917a1704432a1afc329a7a6c5'
BUNDLE_SHA = 'cbe304c04e2157bbbb5c2eed2e81e9440809391fe4d4dc8c9df051e8325a7d58'
TREE = '95340670eafa7f68d3b6aa5ed06e4c74e07663cc'
SOURCE_BLOB = 'c7046698107512a926542dcf46f5a8144b1010c7'
SOURCE_BYTES = 31642
SOURCE_SHA = '093dbe960188830e121518bf1f932c8cb7e570214d9dc4adcd699ef1b688940b'
SOURCE = 'src/liblsquic/lsquic_qdec_hdl.c'
CACHED = ROOT / 'zig-pkg/N-V-__8AAHTbZwBjupXTEP40_CyE44mVS7bxW8RVOJfVt5eC' / SOURCE
OUTPUT = ROOT / '.superpowers/sdd/m2_h3_streaming_plan/qdec-provenance-v2'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    archive = ROOT / 'docs/implement-2-2-0/evidence/m3_pin_archives/current_pins.tar.gz'
    with archive.open('rb') as stream:
        archive_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    if archive_sha != ARCHIVE_SHA:
        raise ValueError('Archive SHA-256 differs from retained commitment')
    if OUTPUT.exists():
        raise FileExistsError('Preserve any previous result; use a new output version')
    cached_before = CACHED.read_bytes()
    scratch = Path(tempfile.mkdtemp(prefix='uwz-h3-qdec-provenance-'))
    bundle = scratch / 'lsquic.bundle'
    with tarfile.open(archive, 'r:gz') as package:
        matches = [m for m in package.getmembers() if m.name == 'bundles/lsquic.bundle']
        if len(matches) != 1 or not matches[0].isfile() or matches[0].size != 9365023:
            raise ValueError('Bundle member differs from retained commitment')
        member = package.extractfile(matches[0])
        if member is None:
            raise ValueError('Bundle member cannot be extracted')
        with member:
            data = member.read()
        if sha(data) != BUNDLE_SHA:
            raise ValueError('Bundle SHA-256 differs from retained commitment')
        bundle.write_bytes(data)
    bare = scratch / 'source.git'
    environment = {
        'PATH': os.environ['PATH'],
        'LC_ALL': 'C',
        'GIT_CONFIG_NOSYSTEM': '1',
        'GIT_CONFIG_GLOBAL': '/dev/null',
        'GIT_TERMINAL_PROMPT': '0',
        'GIT_ALLOW_PROTOCOL': 'file',
    }
    records = []

    def git(*arguments):
        argv = ['git', '-c', 'core.hooksPath=/dev/null', *arguments]
        result = subprocess.run(argv, cwd=scratch, env=environment, capture_output=True, timeout=60)
        records.append({
            'argv': argv, 'cwd': str(scratch), 'exit_status': result.returncode,
            'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr),
            'stdout': result.stdout.decode('utf-8'), 'stderr': result.stderr.decode('utf-8'),
        })
        if result.returncode != 0:
            raise RuntimeError(f'Git command failed: {records[-1]}')
        return result.stdout

    git('init', '--bare', str(bare))
    heads = git('bundle', 'list-heads', str(bundle)).decode().splitlines()
    refs = [line.split(' ', 1)[1] for line in heads if line.split(' ', 1)[0] == PIN]
    if not refs:
        raise ValueError('Exact pin is absent from bundle heads')
    git('--git-dir=' + str(bare), 'bundle', 'verify', str(bundle))
    git('--git-dir=' + str(bare), 'fetch', '--no-tags', str(bundle), refs[0] + ':refs/heads/pinned-source')
    commit = git('--git-dir=' + str(bare), 'rev-parse', 'refs/heads/pinned-source^{commit}').decode().strip()
    if commit != PIN:
        raise ValueError('Fetched commit differs from retained pin')
    tree = git('--git-dir=' + str(bare), 'rev-parse', PIN + '^{tree}').decode().strip()
    if tree != TREE:
        raise ValueError('Tree differs from retained commitment')
    blob = git('--git-dir=' + str(bare), 'rev-parse', PIN + ':' + SOURCE).decode().strip()
    if blob != SOURCE_BLOB:
        raise ValueError('Source blob differs from retained commitment')
    git('--git-dir=' + str(bare), 'fsck', '--full', '--strict')
    source = git('--git-dir=' + str(bare), 'show', PIN + ':' + SOURCE)
    if len(source) != SOURCE_BYTES or sha(source) != SOURCE_SHA:
        raise ValueError('Source bytes differ from retained commitment')
    if source != cached_before or source != CACHED.read_bytes():
        raise ValueError('Cached source differs from pinned source before or after authentication')
    OUTPUT.mkdir()
    (OUTPUT / 'lsquic_qdec_hdl.c').write_bytes(source)
    result = {
        'status': 'PASS', 'scope': 'Offline exact-pinned source authentication only',
        'archive_path': str(archive), 'archive_sha256': archive_sha,
        'bundle_member': 'bundles/lsquic.bundle', 'bundle_sha256': BUNDLE_SHA,
        'bundle_bytes': bundle.stat().st_size, 'bundle_advertised_ref': refs[0],
        'pin': commit, 'tree': tree, 'source_path': SOURCE, 'source_blob': blob,
        'source_bytes': len(source), 'source_sha256': sha(source),
        'cached_path': str(CACHED), 'cached_before_after_matches_pinned_source': True,
        'scratch': str(scratch), 'environment': environment, 'commands': records,
        'interpreter': {
            'executable': sys.executable, 'version': sys.version,
            'implementation': sys.implementation.name,
            'optimization_level': sys.flags.optimize,
        },
        'native_execution': False, 'network_access': False,
        'existing_repository_ref_pin_source_mutations': False,
    }
    (OUTPUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'pin', 'tree', 'source_blob', 'source_bytes', 'source_sha256', 'scratch')}))


if __name__ == '__main__':
    main()
