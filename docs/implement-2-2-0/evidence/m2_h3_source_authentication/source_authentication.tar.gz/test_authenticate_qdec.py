"""Regression tests for the offline source authentication proof path."""

from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import authenticate_qdec as tool


SOURCE = Path(__file__).parent / 'qdec-provenance-v1/lsquic_qdec_hdl.c'


class AuthenticationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='uwz-h3-qdec-test-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.cached = self.root / 'cached.c'
        self.cached.write_bytes(SOURCE.read_bytes())
        self.output = self.root / 'result'
        cached_patch = patch.object(tool, 'CACHED', self.cached)
        output_patch = patch.object(tool, 'OUTPUT', self.output)
        cached_patch.start()
        output_patch.start()
        self.addCleanup(cached_patch.stop)
        self.addCleanup(output_patch.stop)

    def test_optimized_execution_rejects_changed_cached_file(self):
        self.cached.write_bytes(self.cached.read_bytes() + b'changed')
        with self.assertRaisesRegex(ValueError, 'Cached source differs'):
            tool.main()
        self.assertFalse(self.output.exists())

    def test_optimized_execution_rejects_wrong_archive_digest(self):
        with patch.object(tool, 'ARCHIVE_SHA', '0' * 64):
            with self.assertRaisesRegex(ValueError, 'Archive SHA-256 differs'):
                tool.main()
        self.assertFalse(self.output.exists())

    def test_optimized_execution_rejects_wrong_bundle_digest(self):
        with patch.object(tool, 'BUNDLE_SHA', '0' * 64):
            with self.assertRaisesRegex(ValueError, 'Bundle SHA-256 differs'):
                tool.main()
        self.assertFalse(self.output.exists())

    def test_optimized_execution_rejects_unadvertised_pin(self):
        with patch.object(tool, 'PIN', '0' * 40):
            with self.assertRaisesRegex(ValueError, 'Exact pin is absent'):
                tool.main()
        self.assertFalse(self.output.exists())

    def test_optimized_execution_rejects_failed_git_command(self):
        failure = subprocess.CompletedProcess(['git'], 1, b'', b'git failed')
        with patch.object(tool.subprocess, 'run', return_value=failure):
            with self.assertRaisesRegex(RuntimeError, 'Git command failed'):
                tool.main()
        self.assertFalse(self.output.exists())


if __name__ == '__main__':
    unittest.main()
