const std = @import("std");
const body_queue = @import("test_support").http2_body_queue;

test "http2 body queue: sizing and sentinel bounds use numeric capacities" {
    const capacity = try body_queue.required_capacity(8);
    try std.testing.expectEqual(@as(usize, 73728), capacity.payload_bytes);
    try std.testing.expectEqual(@as(usize, 72), capacity.block_count);
    try std.testing.expectEqual(@as(usize, 432), capacity.block_count * @sizeOf(body_queue.Block));
    const maximum = try body_queue.required_capacity(65535);
    try std.testing.expectEqual(@as(usize, 65535), maximum.block_count);
    try std.testing.expectEqual(@as(usize, 67107840), maximum.payload_bytes);
    try std.testing.expectError(error.InvalidCapacity, body_queue.required_capacity(0));
    try std.testing.expectError(error.InvalidCapacity, body_queue.required_capacity(65536));
    try std.testing.expectError(error.InvalidCapacity, body_queue.required_capacity(std.math.maxInt(usize)));
}

test "http2 body queue: fragments preserve FIFO per stream and reclaim head credit" {
    var payload: [4096]u8 = undefined;
    var blocks: [4]body_queue.Block = undefined;
    var streams: [2]body_queue.Stream = undefined;
    var queue = try body_queue.init(.{ .payload = &payload, .blocks = &blocks, .streams = &streams });
    var first: [1500]u8 = undefined;
    for (&first, 0..) |*byte, i| byte.* = @intCast(i % 251);
    try body_queue.append(&queue, 0, first[0..600]);
    try body_queue.append(&queue, 1, "other");
    try body_queue.append(&queue, 0, first[600..]);
    try std.testing.expectEqual(@as(u16, 1), queue.free_count);
    try std.testing.expectEqualSlices(u8, first[0..1024], try body_queue.peek(&queue, 0));
    try std.testing.expectEqual(@as(u32, 0), try body_queue.consume(&queue, 0, 300));
    try std.testing.expectEqualSlices(u8, first[300..1024], try body_queue.peek(&queue, 0));
    try std.testing.expectEqual(@as(u32, 1024), try body_queue.consume(&queue, 0, 724));
    try std.testing.expectEqualSlices(u8, first[1024..], try body_queue.peek(&queue, 0));
    try std.testing.expectEqualSlices(u8, "other", try body_queue.peek(&queue, 1));
    try std.testing.expectEqual(@as(u32, 476), try body_queue.consume(&queue, 0, 476));
    try std.testing.expectEqual(@as(usize, 0), (try body_queue.peek(&queue, 0)).len);
    try std.testing.expectEqual(@as(u32, 5), try body_queue.reset(&queue, 1));
    try std.testing.expectEqual(@as(u16, 4), queue.free_count);
}
