const std = @import("std");
const connection = @import("connection.zig");

/// ADR 0008 retains consumed prefixes until a whole block can be reclaimed.
pub const block_size: usize = 1024;
/// No valid block or stream slot uses the u16 sentinel.
pub const none: u16 = std.math.maxInt(u16);

/// Intrusive free/occupied chain and byte offsets within one payload block.
pub const Block = struct {
    next: u16,
    read: u16,
    write: u16,
};

/// One FIFO per stream slab slot; lifecycle identity remains with the session.
pub const Stream = struct {
    head: u16,
    tail: u16,
};

/// Caller-owned disjoint storage, exclusively borrowed until the queue retires.
pub const Storage = struct {
    payload: []u8,
    blocks: []Block,
    streams: []Stream,
};

/// Initialize through init; callers must not change its fields or metadata.
pub const Queue = struct {
    storage: Storage,
    free_head: u16,
    free_count: u16,
};

/// Startup payload and metadata element counts; owner/alignment are separate.
pub const Capacity = struct {
    payload_bytes: usize,
    block_count: usize,
};

/// Capacity, caller-input and pending-credit failures leave their inputs intact.
pub const Error = error{
    InvalidCapacity,
    InvalidStorage,
    InvalidStream,
    InvalidConsume,
    QueueFull,
    InvalidCredit,
    FlowControlError,
};

/// The pool bound assumes the connection window never exceeds its initial size.
pub fn required_capacity(max_streams: usize) Error!Capacity {
    if (max_streams == 0 or max_streams > none) return error.InvalidCapacity;
    // At 65535 streams this is 65535 blocks, representable even on 32-bit hosts.
    const held_and_slack = @as(usize, connection.default_window_size) + max_streams * (block_size - 1);
    const block_count = (held_and_slack + block_size - 1) / block_size;
    return .{ .payload_bytes = block_count * block_size, .block_count = block_count };
}

/// Shape validation accepts small pools; enabled-session admission must also
/// enforce required_capacity before accepting DATA. No payload bytes are changed.
pub fn init(storage: Storage) Error!Queue {
    if (storage.blocks.len == 0 or storage.blocks.len > none or
        storage.streams.len == 0 or storage.streams.len > none) return error.InvalidCapacity;
    if (storage.payload.len != storage.blocks.len * block_size) return error.InvalidStorage;
    for (storage.blocks, 0..) |*block, i| {
        block.* = .{ .next = if (i + 1 < storage.blocks.len) @intCast(i + 1) else none, .read = 0, .write = 0 };
    }
    @memset(storage.streams, .{ .head = none, .tail = none });
    return .{ .storage = storage, .free_head = 0, .free_count = @intCast(storage.blocks.len) };
}

/// Copies all bytes or changes nothing. Input must not alias queue storage.
/// Only the existing tail's unwritten suffix is reusable, never its read prefix.
pub fn append(queue: *Queue, stream_index: u16, input: []const u8) Error!void {
    if (stream_index >= queue.storage.streams.len) return error.InvalidStream;
    const stream = &queue.storage.streams[stream_index];
    const tail_space = if (stream.tail == none) 0 else block_size - queue.storage.blocks[stream.tail].write;
    if (input.len > tail_space + @as(usize, queue.free_count) * block_size) return error.QueueFull;
    var copied: usize = 0;
    while (copied < input.len) {
        if (stream.tail == none or queue.storage.blocks[stream.tail].write == block_size) {
            const index = queue.free_head;
            const block = &queue.storage.blocks[index];
            queue.free_head = block.next;
            queue.free_count -= 1;
            block.* = .{ .next = none, .read = 0, .write = 0 };
            if (stream.tail == none) stream.head = index else queue.storage.blocks[stream.tail].next = index;
            stream.tail = index;
        }
        const block = &queue.storage.blocks[stream.tail];
        const count = @min(input.len - copied, block_size - block.write);
        const offset = @as(usize, stream.tail) * block_size + block.write;
        @memcpy(queue.storage.payload[offset..][0..count], input[copied..][0..count]);
        block.write += @intCast(count);
        copied += count;
    }
}

/// The head borrow lasts until consume/reset on this stream or queue retirement.
pub fn peek(queue: *const Queue, stream_index: u16) Error![]const u8 {
    if (stream_index >= queue.storage.streams.len) return error.InvalidStream;
    const head = queue.storage.streams[stream_index].head;
    if (head == none) return &.{};
    const block = queue.storage.blocks[head];
    const offset = @as(usize, head) * block_size;
    return queue.storage.payload[offset + block.read .. offset + block.write];
}

/// Consumes at most the exposed head. Returns newly eligible credit, including
/// earlier consumed prefixes, only when that block becomes free (ADR 0008).
pub fn consume(queue: *Queue, stream_index: u16, count: usize) Error!u32 {
    const available = try peek(queue, stream_index);
    if (count > available.len) return error.InvalidConsume;
    if (count == 0) return 0;
    const stream = &queue.storage.streams[stream_index];
    const block = &queue.storage.blocks[stream.head];
    block.read += @intCast(count);
    if (block.read != block.write) return 0;
    return reclaim_head(queue, stream);
}

/// Reclaims held bytes, including consumed prefixes, exactly once. The caller
/// retains connection credit and drops stream credit when retiring a stream.
pub fn reset(queue: *Queue, stream_index: u16) Error!u32 {
    if (stream_index >= queue.storage.streams.len) return error.InvalidStream;
    const stream = &queue.storage.streams[stream_index];
    var released: u32 = 0;
    // At most 65535 blocks of 1024 bytes: the sum fits u32.
    while (stream.head != none) released += reclaim_head(queue, stream);
    return released;
}

fn reclaim_head(queue: *Queue, stream: *Stream) u16 {
    const index = stream.head;
    const block = &queue.storage.blocks[index];
    const released = block.write;
    stream.head = block.next;
    if (stream.head == none) stream.tail = none;
    block.* = .{ .next = queue.free_head, .read = 0, .write = 0 };
    queue.free_head = index;
    queue.free_count += 1;
    return released;
}

/// WINDOW_UPDATE scopes have independent output acceptance (RFC 9113 6.9.1).
pub const CreditScope = enum { connection, stream };

const maximum_credit: u32 = 0x7fff_ffff;

/// Records already-debited reclaimed/delivered bytes or padding (RFC 9113 6.1).
/// A null stream records connection-only credit for an already closed stream.
/// The two pending pointers, when present, must refer to distinct counters.
pub fn release_credit(connection_pending: *u32, stream_pending: ?*u32, amount: u32) Error!void {
    const next_connection = try add_pending(connection_pending.*, amount);
    const next_stream = if (stream_pending) |pending| try add_pending(pending.*, amount) else 0;
    connection_pending.* = next_connection;
    if (stream_pending) |pending| pending.* = next_stream;
}

/// A reset preserves prior connection intent and drops obsolete stream intent.
/// `reclaimed` is the reset result, not bytes already released by consume.
pub fn reset_credit(connection_pending: *u32, stream_pending: *u32, reclaimed: u32) Error!void {
    const next_connection = try add_pending(connection_pending.*, reclaimed);
    connection_pending.* = next_connection;
    stream_pending.* = 0;
}

fn add_pending(pending: u32, amount: u32) Error!u32 {
    if (pending > maximum_credit or amount > maximum_credit - pending) return error.FlowControlError;
    return pending + amount;
}

/// Validate before output without granting credit. Increment must be nonzero
/// and fit pending intent and RFC 9113 6.9.1. The fixed pool forbids connection
/// credit above 65535; stream windows retain the existing signed i64 contract.
pub fn validate_credit(scope: CreditScope, window: i64, pending: u32, increment: u32) Error!void {
    if (increment == 0 or increment > maximum_credit or increment > pending or
        pending > maximum_credit) return error.InvalidCredit;
    const ceiling: i64 = if (scope == .connection) connection.default_window_size else maximum_credit;
    const floor: i64 = if (scope == .connection) 0 else -@as(i64, maximum_credit);
    if (window < floor or window > ceiling - increment) return error.FlowControlError;
}

/// Commit only after this scope's complete WINDOW_UPDATE frame is accepted.
/// Keep the window and counter exclusively borrowed between validation, output
/// and commit; a blocked write calls no commit. Stream identity is caller-owned.
pub fn commit_credit(scope: CreditScope, window: *i64, pending: *u32, increment: u32) Error!void {
    try validate_credit(scope, window.*, pending.*, increment);
    window.* += increment;
    pending.* -= increment;
}
