const std = @import("std");
const body_queue = @import("test_support").http2_body_queue;

test "http2 body queue: sizing and sentinel bounds use numeric capacities" {
    const capacity = try body_queue.required_capacity(8);
    try std.testing.expectEqual(@as(usize, 73728), capacity.payload_bytes);
    try std.testing.expectEqual(@as(usize, 72), capacity.block_count);
    try std.testing.expectEqual(@as(usize, 432), capacity.block_count * @sizeOf(body_queue.Block));
    const maximum = try body_queue.required_capacity(65535);
    try std.testing.expectEqual(@as(usize, 65535), maximum.block_count);
    try std.testing.expectEqual(@as(usize, 67107840), maximum.payload_bytes);
    try std.testing.expectError(error.InvalidCapacity, body_queue.required_capacity(0));
    try std.testing.expectError(error.InvalidCapacity, body_queue.required_capacity(65536));
    try std.testing.expectError(error.InvalidCapacity, body_queue.required_capacity(std.math.maxInt(usize)));
}

test "http2 body queue: fragments preserve FIFO per stream and reclaim head credit" {
    var payload: [4096]u8 = undefined;
    var blocks: [4]body_queue.Block = undefined;
    var streams: [2]body_queue.Stream = undefined;
    var queue = try body_queue.init(.{ .payload = &payload, .blocks = &blocks, .streams = &streams });
    var first: [1500]u8 = undefined;
    for (&first, 0..) |*byte, i| byte.* = @intCast(i % 251);
    try body_queue.append(&queue, 0, first[0..600]);
    try body_queue.append(&queue, 1, "other");
    try body_queue.append(&queue, 0, first[600..]);
    try std.testing.expectEqual(@as(u16, 1), queue.free_count);
    try std.testing.expectEqualSlices(u8, first[0..1024], try body_queue.peek(&queue, 0));
    try std.testing.expectEqual(@as(u32, 0), try body_queue.consume(&queue, 0, 300));
    try std.testing.expectEqualSlices(u8, first[300..1024], try body_queue.peek(&queue, 0));
    try std.testing.expectEqual(@as(u32, 1024), try body_queue.consume(&queue, 0, 724));
    try std.testing.expectEqualSlices(u8, first[1024..], try body_queue.peek(&queue, 0));
    try std.testing.expectEqualSlices(u8, "other", try body_queue.peek(&queue, 1));
    try std.testing.expectEqual(@as(u32, 476), try body_queue.consume(&queue, 0, 476));
    try std.testing.expectEqual(@as(usize, 0), (try body_queue.peek(&queue, 0)).len);
    try std.testing.expectEqual(@as(u32, 5), try body_queue.reset(&queue, 1));
    try std.testing.expectEqual(@as(u16, 4), queue.free_count);
}

test "http2 body queue: exhaustion and invalid operations leave all storage unchanged" {
    var payload: [2048]u8 = @splat(0xab);
    var blocks: [2]body_queue.Block = undefined;
    var streams: [2]body_queue.Stream = undefined;
    var queue = try body_queue.init(.{ .payload = &payload, .blocks = &blocks, .streams = &streams });
    try body_queue.append(&queue, 0, "abc");
    try body_queue.append(&queue, 1, "xyz");
    const old_payload = payload;
    const old_blocks = blocks;
    const old_streams = streams;
    const old_free_head = queue.free_head;
    var too_large: [1022]u8 = @splat(7);
    try std.testing.expectError(error.QueueFull, body_queue.append(&queue, 0, &too_large));
    try std.testing.expectError(error.InvalidStream, body_queue.append(&queue, 2, ""));
    try std.testing.expectError(error.InvalidStream, body_queue.peek(&queue, 65535));
    try std.testing.expectError(error.InvalidStream, body_queue.reset(&queue, 2));
    try std.testing.expectError(error.InvalidStream, body_queue.consume(&queue, 2, 0));
    try std.testing.expectError(error.InvalidConsume, body_queue.consume(&queue, 0, 4));
    try std.testing.expectEqualSlices(u8, &old_payload, &payload);
    try std.testing.expectEqualDeep(old_blocks, blocks);
    try std.testing.expectEqualDeep(old_streams, streams);
    try std.testing.expectEqual(old_free_head, queue.free_head);
    try std.testing.expectEqual(@as(u16, 0), queue.free_count);
    try body_queue.append(&queue, 0, "");
    try std.testing.expectEqualDeep(old_blocks, blocks);
    try std.testing.expectEqual(@as(u32, 0), try body_queue.consume(&queue, 0, 0));
    try body_queue.append(&queue, 0, too_large[0..1021]);
    try std.testing.expectEqual(@as(usize, 1024), (try body_queue.peek(&queue, 0)).len);
    try std.testing.expectError(error.QueueFull, body_queue.append(&queue, 0, "!"));
}

test "http2 body queue: consumed prefix stays held through tail reuse and reset" {
    var payload: [2048]u8 = undefined;
    var blocks: [2]body_queue.Block = undefined;
    var streams: [2]body_queue.Stream = undefined;
    var queue = try body_queue.init(.{ .payload = &payload, .blocks = &blocks, .streams = &streams });
    try body_queue.append(&queue, 0, "abcdef");
    try std.testing.expectEqual(@as(u32, 0), try body_queue.consume(&queue, 0, 5));
    try body_queue.append(&queue, 0, "ghij");
    try std.testing.expectEqualSlices(u8, "fghij", try body_queue.peek(&queue, 0));
    try std.testing.expectEqual(@as(u16, 1), queue.free_count);
    try std.testing.expectEqual(@as(u32, 10), try body_queue.reset(&queue, 0));
    try std.testing.expectEqual(@as(u32, 0), try body_queue.reset(&queue, 0));
    try std.testing.expectEqual(@as(u32, 0), try body_queue.consume(&queue, 0, 0));
    try std.testing.expectError(error.InvalidConsume, body_queue.consume(&queue, 0, 1));
    try body_queue.append(&queue, 1, "reuse");
    try std.testing.expectEqualSlices(u8, "reuse", try body_queue.peek(&queue, 1));
    try std.testing.expectEqual(@as(u32, 5), try body_queue.reset(&queue, 1));
    try std.testing.expectEqual(@as(u16, 2), queue.free_count);
}

test "http2 body queue: reset reclaims multiple blocks once without touching sibling" {
    var payload: [4096]u8 = undefined;
    var blocks: [4]body_queue.Block = undefined;
    var streams: [2]body_queue.Stream = undefined;
    var queue = try body_queue.init(.{ .payload = &payload, .blocks = &blocks, .streams = &streams });
    const input: [2500]u8 = @splat('x');
    try body_queue.append(&queue, 0, &input);
    try body_queue.append(&queue, 1, "sibling");
    try std.testing.expectEqual(@as(u32, 0), try body_queue.consume(&queue, 0, 1000));
    try std.testing.expectEqual(@as(u32, 2500), try body_queue.reset(&queue, 0));
    try std.testing.expectEqual(@as(u32, 0), try body_queue.reset(&queue, 0));
    try std.testing.expectEqualSlices(u8, "sibling", try body_queue.peek(&queue, 1));
    try body_queue.append(&queue, 0, &input);
    try std.testing.expectEqual(@as(u32, 1024), try body_queue.consume(&queue, 0, 1024));
    try std.testing.expectEqual(@as(u32, 1476), try body_queue.reset(&queue, 0));
}

test "http2 body queue: invalid storage shape is rejected before initialization" {
    var payload: [1025]u8 = @splat(0xcd);
    var blocks = [_]body_queue.Block{.{ .next = 42, .read = 12, .write = 15 }};
    var streams = [_]body_queue.Stream{.{ .head = 9, .tail = 10 }};
    const old_blocks = blocks;
    const old_streams = streams;
    try std.testing.expectError(error.InvalidStorage, body_queue.init(.{ .payload = &payload, .blocks = &blocks, .streams = &streams }));
    try std.testing.expectError(error.InvalidStorage, body_queue.init(.{ .payload = payload[0..1023], .blocks = &blocks, .streams = &streams }));
    try std.testing.expectError(error.InvalidCapacity, body_queue.init(.{ .payload = &.{}, .blocks = &.{}, .streams = &streams }));
    try std.testing.expectError(error.InvalidCapacity, body_queue.init(.{ .payload = payload[0..1024], .blocks = &blocks, .streams = &.{} }));
    try std.testing.expectEqualDeep(old_blocks, blocks);
    try std.testing.expectEqualDeep(old_streams, streams);
    for (payload) |byte| try std.testing.expectEqual(@as(u8, 0xcd), byte);
}

test "http2 body queue: independent credit intents and partial accepted scopes" {
    var connection_pending: u32 = 0;
    var stream_pending: u32 = 0;
    var connection_window: i64 = 65035;
    var stream_window: i64 = 65035;
    try body_queue.release_credit(&connection_pending, &stream_pending, 500);
    try body_queue.validate_credit(.connection, connection_window, connection_pending, 300);
    try body_queue.validate_credit(.stream, stream_window, stream_pending, 500);
    try std.testing.expectEqual(@as(i64, 65035), connection_window);
    try std.testing.expectEqual(@as(u32, 500), stream_pending);
    try body_queue.commit_credit(.connection, &connection_window, &connection_pending, 300);
    try std.testing.expectEqual(@as(i64, 65335), connection_window);
    try std.testing.expectEqual(@as(u32, 200), connection_pending);
    try std.testing.expectEqual(@as(u32, 500), stream_pending);
    try body_queue.commit_credit(.stream, &stream_window, &stream_pending, 500);
    try std.testing.expectEqual(@as(i64, 65535), stream_window);
    try std.testing.expectEqual(@as(u32, 0), stream_pending);
    try body_queue.commit_credit(.connection, &connection_window, &connection_pending, 200);
    try std.testing.expectEqual(@as(i64, 65535), connection_window);
    try std.testing.expectError(error.InvalidCredit, body_queue.commit_credit(.connection, &connection_window, &connection_pending, 200));
    try std.testing.expectEqual(@as(u32, 0), connection_pending);
}

test "http2 body queue: padding and reset preserve connection refund and drop stream intent" {
    var payload: [1024]u8 = undefined;
    var blocks: [1]body_queue.Block = undefined;
    var streams: [1]body_queue.Stream = undefined;
    var queue = try body_queue.init(.{ .payload = &payload, .blocks = &blocks, .streams = &streams });
    var connection_pending: u32 = 0;
    var stream_pending: u32 = 0;
    var connection_window: i64 = 65519;
    try body_queue.append(&queue, 0, "retained");
    // Eight padding bytes hold no blocks (RFC 9113 section 6.1).
    try body_queue.release_credit(&connection_pending, &stream_pending, 8);
    try body_queue.commit_credit(.connection, &connection_window, &connection_pending, 8);
    try std.testing.expectEqual(@as(u32, 0), try body_queue.consume(&queue, 0, 3));
    const reclaimed = try body_queue.reset(&queue, 0);
    try body_queue.reset_credit(&connection_pending, &stream_pending, reclaimed);
    try std.testing.expectEqual(@as(u32, 8), connection_pending);
    try std.testing.expectEqual(@as(u32, 0), stream_pending);
    try body_queue.reset_credit(&connection_pending, &stream_pending, try body_queue.reset(&queue, 0));
    try std.testing.expectEqual(@as(u32, 8), connection_pending);
    try body_queue.commit_credit(.connection, &connection_window, &connection_pending, 8);
    try std.testing.expectEqual(@as(i64, 65535), connection_window);
    try std.testing.expectEqual(@as(u16, 1), queue.free_count);
    // An already closed stream can contribute padding/discard credit only at connection scope.
    connection_window -= 1;
    try body_queue.release_credit(&connection_pending, null, 1);
    try body_queue.commit_credit(.connection, &connection_window, &connection_pending, 1);
    try std.testing.expectEqual(@as(i64, 65535), connection_window);
}

test "http2 body queue: credit overflow and invalid increments are atomic" {
    var connection_pending: u32 = 10;
    var stream_pending: u32 = 0x7fff_fffe;
    try std.testing.expectError(error.FlowControlError, body_queue.release_credit(&connection_pending, &stream_pending, 2));
    try std.testing.expectEqual(@as(u32, 10), connection_pending);
    try std.testing.expectEqual(@as(u32, 0x7fff_fffe), stream_pending);
    connection_pending = 0x7fff_ffff;
    try std.testing.expectError(error.FlowControlError, body_queue.release_credit(&connection_pending, &stream_pending, 1));
    try std.testing.expectError(error.FlowControlError, body_queue.reset_credit(&connection_pending, &stream_pending, 1));
    try std.testing.expectEqual(@as(u32, 0x7fff_fffe), stream_pending);
    try body_queue.release_credit(&connection_pending, &stream_pending, 0);
    try std.testing.expectError(error.FlowControlError, body_queue.release_credit(&connection_pending, null, std.math.maxInt(u32)));
    var window: i64 = 65535;
    var pending: u32 = 1;
    try std.testing.expectError(error.FlowControlError, body_queue.commit_credit(.connection, &window, &pending, 1));
    try std.testing.expectEqual(@as(i64, 65535), window);
    try std.testing.expectEqual(@as(u32, 1), pending);
    try std.testing.expectError(error.InvalidCredit, body_queue.validate_credit(.stream, 0, 1, 0));
    try std.testing.expectError(error.InvalidCredit, body_queue.validate_credit(.stream, 0, 1, 2));
    try std.testing.expectError(error.InvalidCredit, body_queue.validate_credit(.stream, 0, std.math.maxInt(u32), std.math.maxInt(u32)));
    try std.testing.expectError(error.FlowControlError, body_queue.validate_credit(.stream, std.math.maxInt(i64), 1, 1));
    try std.testing.expectError(error.FlowControlError, body_queue.validate_credit(.stream, std.math.minInt(i64), 1, 1));
    try std.testing.expectError(error.FlowControlError, body_queue.validate_credit(.connection, -1, 1, 1));
    try body_queue.validate_credit(.stream, -1, 1, 1);
    window = 0;
    pending = 0x7fff_ffff;
    try body_queue.commit_credit(.stream, &window, &pending, 0x7fff_ffff);
    try std.testing.expectEqual(@as(i64, 0x7fff_ffff), window);
    try std.testing.expectEqual(@as(u32, 0), pending);
}
