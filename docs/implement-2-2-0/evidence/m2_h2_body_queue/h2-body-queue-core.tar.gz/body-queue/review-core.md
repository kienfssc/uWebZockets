# Task 1 independent core review

No actionable findings. Approve the pure queue and pending-credit core within
the accepted Task 1 scope; production H2 request-streaming acceptance remains
dependent on integration and its required verification.

Reviewed baseline digest
`89dce088f5684c9173c45c572e785e7ff9c57991eb152ec76c46a58db481479d`
against candidate digest
`580199bc84e81779dd050943fc0b1bb7a9b8f1af113fcb28e7fab560fc105af6`.
Read the four-path patch, complete queue and tests, accepted task/architecture
constraints, ADR 0008, project conventions and HTTP specialist instructions.
Applied code-review-and-quality and the structural maintainability lens with
the AGENTS.md override. Changed-file snapshots match the candidate files.

The 194-line module keeps the queue and credit transitions in their protocol
ownership boundary. No actionable abstraction, file-growth or branching
regression was found. Count guards establish the 32-bit arithmetic and u16
sentinel bounds; the eight-stream result is 73728 payload bytes, 72 blocks and
432 bytes of Block metadata. Append preflights total capacity before mutation.
Consume retains partial-head credit; reclamation/reset include held prefixes
exactly once and preserve sibling chains. Storage disjointness, nonaliasing
append input and exclusive ownership are explicit caller preconditions.

Independent pending scopes and accepted-scope commits preserve retry accounting.
The connection ceiling protects the pool proof, while signed stream windows and
31-bit nonzero increments follow the existing contracts. Padding remains
eligible without occupying payload blocks. These checks align with
[RFC 9113 DATA accounting](https://www.rfc-editor.org/rfc/rfc9113.html#section-6.1)
and [flow-control updates](https://www.rfc-editor.org/rfc/rfc9113.html#section-6.9).
The actual output/commit and stream-identity sequence is still a caller
obligation for the next Session integration.

Verification limits:

- This review ran no compiler, test binary, native client or probe. It inspected
  recorded evidence. Both focused runs report 9/9 passing tests with matching
  pre/post candidate, input and override bindings. Tests use real caller storage,
  expected byte sequences and observable credit/error behavior.
- 32-bit, central native, macOS and Windows records establish semantic
  compilation only. Existing H1/TLS and 69 H2 tests were not re-executed here.
  Formatting, conventions and release-version checks record success against the
  unchanged candidate identity.
- The overlapping initial native declaration red is unsuitable as immutable
  proof. The frozen 32-bit red establishes a missing declaration only, not a
  behavioral regression red; the report discloses both limits.
- Real Session WINDOW_UPDATE acceptance/retry, startup carving and pool
  admission, enabled/disabled layout measurements, App admission and metadata,
  callback/reset lifetime, TCP/TLS composition and actual 100000000-byte H2
  delivery remain unimplemented/unverified in this slice.
- Full zig build test, h1spec, sanitizer/MSan, fuzz/OSS-Fuzz,
  package/examples/consumer/ReleaseFast, Autobahn, native Windows and maintained
  adoption gates remain outstanding for authorized integrated verification.

No source, index, reference, dependency pin or gate was changed by this review.
