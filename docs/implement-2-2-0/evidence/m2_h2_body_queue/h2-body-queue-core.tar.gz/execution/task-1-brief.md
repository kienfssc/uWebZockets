## Task 1: bounded receive queue and credit-intent core

Owner http_protocol. Own only NEW src/http2/body_queue.zig, NEW
src/tests/http2_body_queue_tests.zig, one private test_support export and one
private tests/main import in the new copy. Do not edit Connection/Session/App/
config/TCP or public root exports in this slice; their concrete integration is
the next dependent task. This is an earned foundation required by the accepted
H2 DATA driver, not a public streaming capability or complete H2 implementation.

Implement actual caller-owned1024byte block queue with checked sizing/initialization,
free-list next/read/write metadata, per-stream heads/tails, tail reuse, append,
head-prefix exposure, consume/reclaim and reset. Held consumed head prefixes do
not release credit until their block is freed. Reset returns held connection
credit once; repeated reset is idempotent. Check storage shape, all arithmetic,
stream/index/sentinel bounds and error atomicity. Do not allocate or fabricate
oversized memory slices for width tests; numeric sizing facts suffice.

Implement the corresponding small pure pending-credit operations needed for
separate connection/stream validation and commit after accepted WINDOW_UPDATE.
Queue reclamation returns actual credit amounts. Pending amounts remain until
explicit accepted-scope commit; connection success then blocked stream retry
cannot duplicate connection credit. Padding credit has no retained payload;
closed-stream reset drops obsolete stream intent while preserving connection
refund. Use the real existing window types/contracts after scoped source read,
not a generic transaction/token framework or invented connection-window increase.
No I/O/writer callback or native completion is fabricated to test acceptance.
If safe credit semantics need broader concrete Session coupling, report that
before adding speculative state; keep the queue contract clear and executable.

Meaningful tests use caller storage and independent expected byte sequences:
multiple streams, split append/tail reuse, partial heads, full/empty/zero data,
queue exhaustion with no mutation, block/stream reuse, repeated reset, exact
release including earlier consumed prefixes, padding/credit-only cases, partial
connection-vs-stream output intent commits, checked max-width sizing/overflow,
u16 sentinel representability, and accepted73728-byte/72block sizing at8streams.
Preserve genuine declaration/behavioral reds honestly; no manufactured bad stub
solely to claim red. Existing H1/TLS and69 H2 tests remain unchanged.

Run selected pure tests Debug/RS and eligible32bit compile, full central native/
macOS/Windows semantic compile, scoped full-dir fmt/conventions/version and AST
refresh; no entire isolated native fault suite. Preserve pre/post complete
source/input/compiler/binary/override/env bindings and raw failures/statuses.
Freeze snapshots/report for independent protocol/spec/quality review. No cold
slab/default layout assertion changes are needed yet. Report that Session/native
delivery, App admission, startup carving/layout measurements and actual100M H2
runtime remain unimplemented. Root must connect and verify the core before
production adoption; unused final production scaffolding is not acceptance.
