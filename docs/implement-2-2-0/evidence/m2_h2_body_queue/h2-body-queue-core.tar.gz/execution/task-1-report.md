# Task 1 report: bounded HTTP/2 receive queue and pending credit

Implemented and frozen for independent protocol review. This is the pure core
slice only; it is not request-streaming capability or milestone completion.

## Source and ownership

- Baseline: `/tmp/uwz-m2-h1-tls-configured-combined`, 1023 regular files,
  SHA256 manifest digest
  `89dce088f5684c9173c45c572e785e7ff9c57991eb152ec76c46a58db481479d`.
  Rechecked after the work: unchanged.
- Candidate: `/tmp/uwz-m2-h2-body-queue`, 1025 regular files, digest
  `580199bc84e81779dd050943fc0b1bb7a9b8f1af113fcb28e7fab560fc105af6`.
- Exactly four changed paths: new `src/http2/body_queue.zig`, new
  `src/tests/http2_body_queue_tests.zig`, one private `test_support.zig`
  export, one private `tests/main.zig` import. No other source edits.
- Evidence: `.uwz-work/evidence/h2-streaming/body-queue/`. `final/` contains
  full changed files; `preimages/` contains both existing registration files;
  `body-queue.patch` includes all four paths. `baseline.json`,
  `baseline-post.json`, `final-source.json`, and `source-*.json` bind all source.

## Implemented invariants

`Storage` borrows disjoint caller-owned payload, block metadata and per-stream
head/tail storage. `Block` uses three u16 fields (six bytes); `Stream` uses two
u16 fields. No allocator, I/O, logging, clock, random input, global mutable state,
public anytype, reflective type creation, writer callback, token or transaction
framework was added.

`required_capacity(8)` returns 73728 payload bytes and 72 blocks (432 metadata
bytes). The maximum supported 65535 stream slots requires 65535 blocks and
67107840 payload bytes. Guarding counts to 1..65535 before arithmetic proves all
sizing products and rounding fit 32-bit usize. The u16 value 65535 is reserved;
valid block and stream indices end at 65534. Zero, 65536 and usize maximum are
rejected as numeric capacities; tests never fabricate oversized slices.

Initialization validates nonzero representable counts and exact payload shape
before touching metadata. Small well-formed pools are supported for the core;
real enabled Session startup/admission must separately enforce the required
pool bound. Append first checks complete capacity, then fills the existing tail
and allocates blocks from its free list. Exhaustion changes no metadata or bytes.
Input must not alias queue storage; caller storage and metadata remain exclusive.

Peek exposes only a stream's current head. Consume accepts only a prefix of that
exposure. Partial consumption returns zero credit; reclaim returns the complete
written length, including earlier consumed bytes. No head-prefix compaction or
premature refund occurs. Reset returns the sum of all held written lengths once,
returns zero on repetition, and makes those blocks reusable without affecting
sibling queues. Whole-queue state is initialized through init and must not be
mutated behind these functions.

The small credit helpers use the existing signed i64 window and u32 increment
contracts. Release records already-debited eligible bytes in independently held
connection/stream counters; null stream pointer handles closed-stream credit.
Both additions validate before mutation. Reset preserves existing connection
intent, adds newly reclaimed bytes, and clears obsolete stream intent.
Counter pointers must identify distinct caller counters.

Validation is read-only and requires a nonzero pending-backed 31-bit increment.
Connection validation additionally preserves the 65535 ceiling required by the
pool proof. Stream validation supports signed windows and the 2^31-1 ceiling.
Commit changes only the explicitly accepted scope and amount. A blocked output
must call no commit. Validation/output/commit require exclusive access to the
same live window/counter and unchanged stream identity; enforcing that concrete
Session lifetime/output sequence is the next task. These tests explicitly call
pure accepted-scope commits; they do not fabricate writer or native outcomes.

## Source grounding and threats

Canonical ADR0008, HTTP/2 storage and credit, governs the fragmentation bound;
Root's withdrawn 2*W+2*F dispatch is not implemented. Local inspected contracts:
`connection.zig` initial window 13, receive fields 366/142,
`restore_receive_credit` 495, and `add_window` 986. Existing Connection functions
remain unchanged.

Official source verified:
[RFC 9113 section 6.1](https://www.rfc-editor.org/rfc/rfc9113.html#section-6.1)
counts padding in DATA flow control;
[sections 6.9–6.9.2](https://www.rfc-editor.org/rfc/rfc9113.html#section-6.9)
provide independent connection/stream updates, nonzero 31-bit increments,
maximum windows and initial 65535 credit. The queue accepts opaque payload bytes;
it introduces no framing parser or new external-byte trust-boundary decoder.

Reviewed abuse cases: peer fragmentation cannot recover consumed-prefix credit;
invalid slots/counts cannot index storage; oversized appends fail atomically;
maximum arithmetic cannot wrap; repeated reset does not refund twice; separately
committed credit does not duplicate the other scope; padding needs no payload
storage. No performance improvement is claimed without measurement.

## Verification and evidence limitations

Every command has raw `.log` output and `.json` argv/cwd/status/environment,
complete source manifests before/after, compiler SHA256, explicitly imported
module/binding/static-library identities, and immutable 93-file libxev override
identities. Native binaries are retained in
`/tmp/uwz-m2-h2-body-queue-artifacts/`, hashed at compilation and before/after
execution. Compiler is Zig 0.16.0 at the exact path in `zig-env.json`.
Original r2 target C bindings, immutable c223 override and existing static
libraries were used; no dependency fetch, new build dependency, ref or pin edit.
Compilation used `-j2` and separate /tmp caches.

| Check | Actual result |
| --- | --- |
| Frozen declaration red, x86-linux-musl | Expected missing `body_queue.zig`; status1 |
| Focused Debug | 9/9 pure caller-buffer tests pass |
| Focused ReleaseSafe | 9/9 pure caller-buffer tests pass |
| x86-linux-musl 32-bit ReleaseSafe | Focused pure semantic compile passes; no execution |
| Central native ReleaseSafe | Full test graph semantic compile passes; no execution |
| Central aarch64-macos ReleaseSafe | Full test graph semantic compile passes; no execution |
| Central x86_64-windows-gnu ReleaseSafe | Full test graph semantic compile passes; no execution |
| `zig fmt src builds examples tests fuzz` | Pass; no additional changes |
| `sh scripts/check_conventions.sh` | Pass |
| `sh scripts/check_release_version.sh` | Pass; existing 2.1.6 metadata consistent |
| Independent identical-copy `graphify update .` | Pass; AST-only refresh |

All successful source checks bind the same candidate digest. The initial native
declaration-red compile overlapped authoring additional tests: before/after
source identities differ. Its raw failure and both test snapshots are retained;
it is not immutable-source proof. The subsequent frozen 32-bit declaration red
has equal pre/post identities and establishes only a declaration failure, not a
behavioral red. No bad stub was manufactured to obtain a failing test.

The nine tests cover FIFO across streams/fragments, tail reuse, partial heads,
all-or-nothing exhaustion, full/empty/zero operations, invalid stream/counts,
invalid initialization, reset/reuse/idempotence/siblings, exact held-prefix
refunds, padding without retained payload, connection-only credits, independent
partial accepted scopes, reset after one scope committed, and arithmetic/window
limits using genuine buffers and numeric capacities.

Graph refresh ran in `/tmp/uwz-m2-h2-body-queue-graph`, not the immutable source.
Source manifests match before and after. It reported 318 unclassified files,
28 files with no modeled symbols, a denied parallel-extraction operation followed
by successful sequential extraction, and changed community labels. It generated
13084 nodes/16273 edges; these warnings remain in `graph-refresh.log` and do not
constitute semantic coverage or runtime proof.

## Required next steps and unrun gates

Root must integrate this core into the real H2 Session/storage/admission and
concrete upload driver before production adoption. Real WINDOW_UPDATE output
acceptance/retry, callback lifetime and reset ordering, App metadata/admission,
startup carving and enabled/disabled layout measurements, native transport/TLS
composition, and actual 100000000-byte H2 delivery remain unimplemented here.
No default slab/layout change or assertion change was made.

As explicitly scoped, no entire native fault suite, native client, native
schedule/interleaving/race/crash/leak/invalid-fd/registration/kernel/resource/
injected-completion/panic probe ran. The stopped experiment remains stopped.
Existing H1/TLS and 69 H2 test sources are unchanged. Their complete test graph
was compiled, but they were not re-executed in this slice. Full `zig build test`,
h1spec, sanitizer/MSan, fuzz/OSS-Fuzz, package/examples/consumer/ReleaseFast,
Autobahn, native Windows and maintained adoption gates remain for Root's later
integrated authorization. No parser, dispatch, wire framing or compliance gate
was changed by this pure foundation.
