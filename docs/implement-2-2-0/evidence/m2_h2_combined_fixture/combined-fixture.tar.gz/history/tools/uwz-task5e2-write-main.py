from pathlib import Path
import sys
out=Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-fixture')
p=out/'shared.zig';s=p.read_text().replace('pub const State = struct {','pub const Family = enum { core, pause, admission, credit, metadata, cancellation, application, lifecycle, output_body };\npub const State = struct {\n    family: Family,');p.write_text(s)
core='''const std = @import("std");
const uz = @import("uWebZockets");
const shared = @import("shared.zig");
const format_record = @import("formatting.zig").format_record;
pub fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const state: *shared.State = @ptrCast(@alignCast(context));
    const tag = request.params.get("tag") orelse return error.MissingTag;
    if (tag.len == 0 or tag.len > 32) return error.InvalidTag;
    for (tag) |c| if (!std.ascii.isAlphanumeric(c) and c != '_') return error.InvalidTag;
    const index: usize = if (std.mem.eql(u8, tag, "large_declared")) 0 else if (std.mem.eql(u8, tag, "large_undeclared")) 1 else return error.InvalidTag;
    const record = &state.records[index];
    record.attempts += 1;
    if (record.attempts != 1) return error.DuplicateTag;
    for (state.slots) |*slot| {
        if (slot.record != null) continue;
        slot.generation += 1;
        slot.owner = state;
        slot.index = index;
        slot.record = record;
        record.token = token;
        record.active = true;
        record.begins += 1;
        return .{ .context = slot, .readiness = .ready };
    }
    return error.NoFixtureSlot;
}
pub fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *shared.Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.max_span = @max(record.max_span, input.len);
    record.chunks += 1;
    record.hash.update(input);
    record.bytes += input.len;
    return .{ .consumed = input.len, .readiness = .ready };
}
pub fn end(context: *anyopaque, _: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *shared.Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.ends += 1;
    record.active = false;
    slot.record = null;
    var buffer: [768]u8 = undefined;
    const tag = if (slot.index == 0) "large_declared" else "large_undeclared";
    try response.text(try format_record(record, tag, &buffer));
}
pub fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *shared.Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse { slot.owner.errors += 1; return; };
    record.cancels += 1;
    record.reason = reason;
    record.active = false;
    record.paused = false;
    slot.record = null;
}
'''
(out/'core.zig').write_text(core)
names=('core','pause','admission','credit','metadata','cancellation','application','lifecycle','output_body')
counts=(2,5,22,6,1,6,6,12,7)
s='''const std = @import("std");
const uz = @import("uWebZockets");
const shared = @import("shared.zig");
const formatting = @import("formatting.zig");
const output_state = @import("output.zig");
const file_observer = @import("file_observer.zig");
const log_bounds = @import("log_bounds.zig");
const tags = @import("tags.zig").tags;
'''
for n in names:s+='const '+n+' = @import("'+n+'.zig");\n'
s+='''pub const config: uz.ServerConfig = .{
    .max_connections = 8, .stream_request_bodies = true,
    .max_request_line_size = 512, .max_header_size = 4096,
    .max_header_count = 80, .max_body_size = 256, .max_h2_body_size = 4096,
    .max_h2_header_block_size = 8192, .max_h2_response_header_size = 4096,
    .max_h2_response_header_count = 32, .max_route_params = 24,
    .write_queue_size = 65536, .enable_dev_log = false,
};
const Fixture = struct {
    records: [67]shared.Record = [_]shared.Record{.{}} ** 67,
    slots: [2]shared.Slot = .{ .{ .number = 0 }, .{ .number = 1 } },
    families: [9]shared.State = undefined,
    producers: [3]output_state.Producer = [_]output_state.Producer{.{}} ** 3,
    file: file_observer.State = .{},
    reuse_admitted: bool = false,
    buffered_middleware: u32 = 0,
    errors: u32 = 0,
};
fn initialize(fixture: *Fixture) void {
'''
offset=0
for i,(n,c) in enumerate(zip(names,counts)):
    s+=f'fixture.families[{i}] = .{{ .family = .{n}, .slots = &fixture.slots, .records = fixture.records[{offset}..{offset+c}], .producers = &fixture.producers, .file = &fixture.file, .reuse_admitted = &fixture.reuse_admitted }};\n';offset+=c
s+='''}
fn tag_index(tag: []const u8) ?usize {
    for (tags, 0..) |value, index| if (std.mem.eql(u8, tag, value)) return index;
    return null;
}
fn family_for(fixture: *Fixture, index: usize) *shared.State {
'''
offset=0
for i,c in enumerate(counts[:-1]):offset+=c;s+=f'if (index < {offset}) return &fixture.families[{i}];\n'
s+='return &fixture.families[8];\n}\n'
s+='''fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag");
    const body_route = std.mem.startsWith(u8, request.path, "/upload/") or std.mem.startsWith(u8, request.path, "/limit/") or std.mem.startsWith(u8, request.path, "/empty/") or std.mem.startsWith(u8, request.path, "/meta/");
    if (!body_route) {
        fixture.buffered_middleware += 1;
        response.append_header("X-Middleware", "retained") catch { fixture.errors += 1; return .stop; };
        return .continue_dispatch;
    }
    const index = tag_index(tag orelse { fixture.errors += 1; return .stop; }) orelse { fixture.errors += 1; return .stop; };
    const state = family_for(fixture, index);
    switch (state.family) {
        .core, .pause => {
            fixture.records[index].middleware += 1;
            response.append_header("X-Middleware", "retained") catch { fixture.errors += 1; return .stop; };
            return .continue_dispatch;
        },
'''
for n in names[2:]:s+=f'.{n} => return {n}.middleware(state, request, response),\n'
s+='''    }
}
fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    const index = tag_index(request.params.get("tag") orelse return error.MissingTag) orelse return error.InvalidTag;
    const state = family_for(fixture, index);
    return switch (state.family) {
'''
for n in names:s+=f'.{n} => {n}.begin(state, request, token),\n'
s+='};\n}\n'
for fn,args,ret,call in [('chunk','context: *anyopaque, input: []const u8','!uz.BodyProgress','context, input'),('end','context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response','!void','context, request, response'),('cancel','context: *anyopaque, reason: uz.BodyCancelReason','void','context, reason')]:
    s+=f'fn {fn}({args}) {ret} {{\nconst slot: *shared.Slot = @ptrCast(@alignCast(context));\nreturn switch (slot.owner.family) {{\n'
    for n in names:s+=f'.{n} => {n}.{fn}({call}),\n'
    s+='};\n}\n'
s+='''fn health(_: *uz.Request, response: *uz.Response) void {
    response.text("ok") catch |err| std.log.err("health: {}", .{err});
}
fn echo(request: *uz.Request, response: *uz.Response) void {
    response.bytes(request.bytes()) catch |err| std.log.err("echo: {}", .{err});
}
fn delayed(_: *uz.Request, token: uz.AsyncResponse) void {
    token.sleep_complete(10, "200 OK", "Content-Type: text/plain\\r\\n", "delayed-ok") catch |err| std.log.err("delayed: {}", .{err});
}
fn status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    const index = tag_index(request.get_param("tag") orelse { fixture.errors += 1; return; }) orelse { fixture.errors += 1; return; };
    var buffer: [768]u8 = undefined;
    const body = formatting.format_record(&fixture.records[index], tags[index], &buffer) catch { fixture.errors += 1; return; };
    response.text(body) catch { fixture.errors += 1; };
}
fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    const index = tag_index(request.get_param("tag") orelse { fixture.errors += 1; return; }) orelse { fixture.errors += 1; return; };
    const state = family_for(fixture, index);
    switch(state.family) {
        .core => { fixture.errors += 1; },
'''
for n in names[1:]:s+=f'.{n} => {n}.control(state, request, response),\n'
s+='''    }
}
fn output_status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    output_body.output_status(&fixture.families[8], request, response);
}
fn format_totals(fixture: *const Fixture, buffer: []u8) ![]const u8 {
    var totals: formatting.Totals = .{ .errors = fixture.errors, .buffered_middleware = fixture.buffered_middleware, .slot0_active = fixture.slots[0].record != null, .slot1_active = fixture.slots[1].record != null };
    for (fixture.families) |state| totals.errors += state.errors + state.failed;
    for (fixture.records) |record| formatting.add_record(&totals, &record);
    return formatting.format_totals(totals, buffer);
}
fn metrics(context: *anyopaque, _: *uz.Request, response: *uz.Response) void {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    var buffer: [1024]u8 = undefined;
    const body = format_totals(fixture, &buffer) catch { fixture.errors += 1; return; };
    response.text(body) catch { fixture.errors += 1; };
}
pub fn main(init: std.process.Init) !void {
    comptime log_bounds.prove(config);
    const nonce = init.environ_map.get("H2_PROFILE_NONCE") orelse return error.MissingNonce;
    try log_bounds.validate_nonce(nonce);
    const certificate = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_CERT") orelse return error.MissingCertificate);
    const key = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_KEY") orelse return error.MissingKey);
    var fixture: Fixture = .{};
    initialize(&fixture);
    defer file_observer.cleanup(&fixture.file);
    try file_observer.setup(&fixture.file, init.io, init.environ_map.get("H2_PROFILE_FILE") orelse return error.MissingFilePath);
    const sink: uz.BodySink = .{ .context = &fixture, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel };
    var upload: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 100000000, .max_active = 2 }, .middleware_policy = .headers_only };
    var limit: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 32, .max_active = 1 }, .middleware_policy = .headers_only };
    var empty: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 0, .max_active = 1 }, .middleware_policy = .headers_only };
    {
        var server = try uz.Server.preset(init.io, config).build_https(init.arena.allocator(), certificate, key);
        defer server.deinit();
        _ = try server.use(&fixture, middleware);
        _ = try server.route_body(.post, "/upload/:tag", &upload);
        _ = try server.route_body(.post, "/limit/:tag", &limit);
        _ = try server.route_body(.post, "/empty/:tag", &empty);
        _ = try server.route_body(.post, "/meta/:tag/:p01/:p02/:p03/:p04/:p05/:p06/:p07/:p08/:p09/:p10/:p11/:p12/:p13/:p14/:p15/:p16", &upload);
        _ = try server.get("/health", health);
        _ = try server.post("/echo", echo);
        _ = try server.get_async("/delayed", delayed);
        _ = try server.get_context("/status/:tag", &fixture, status);
        _ = try server.get_context("/metrics", &fixture, metrics);
        _ = try server.get_context("/resume/:tag", &fixture, resume_body);
        _ = try server.get_context("/control/:op/:tag", &fixture, control);
        _ = try server.get_context("/output/:tag", &fixture, output_status);
        std.log.info(log_bounds.capacity_format, .{ std.json.fmt(config, .{}), try config.request_buffer_stride(), try config.h2_session_bytes(), try config.h2_session_stride(), try config.slab_bytes(), try config.router_storage_bytes() });
        try server.listen("127.0.0.1", 28443);
        try server.catch_shutdown_signals();
        std.log.info("H2_READY {s}", .{nonce});
        try server.run();
    }
    const binding = fixture.families[8].records[1];
    std.log.info("H2_BINDING {s} tag=producer_reuse_next index={d} generation={d}", .{ nonce, binding.binding_index, binding.binding_generation });
    for (&fixture.records, 0..) |*record, index| {
        var buffer: [768]u8 = undefined;
        std.log.info("H2_RECORD {s} {s}", .{ nonce, try formatting.format_record(record, tags[index], &buffer) });
    }
    for (&fixture.producers, [_][]const u8{ "producer_reuse", "output_pressure_window", "output_pressure_ready" }) |*producer, tag| {
        var buffer: [1024]u8 = undefined;
        std.log.info("H2_OUTPUT {s} {s}", .{ nonce, try output_state.format(producer, tag, &buffer) });
    }
    var buffer: [1024]u8 = undefined;
    std.log.info("H2_OUTPUT {s} {s}", .{ nonce, try file_observer.format(&fixture.file, &buffer) });
    std.log.info("H2_DEINIT {s} {s}", .{ nonce, try format_totals(&fixture, &buffer) });
}
fn resume_body(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    const index = tag_index(request.get_param("tag") orelse { fixture.errors += 1; return; }) orelse { fixture.errors += 1; return; };
    const state = family_for(fixture, index);
    switch (state.family) {
        .admission => admission.control(state, request, response),
        .credit => credit.control(state, request, response),
        .metadata => metadata.control(state, request, response),
        else => { fixture.errors += 1; },
    }
}
'''
(out/'profile.zig').write_text(s)
# Aggregate canonical diagnostic schema remains the existing metrics interface.
p=out/'formatting.zig';s=p.read_text();s+='''pub const Totals = struct {
    middleware: u64 = 0, attempts: u64 = 0, begins: u64 = 0, ends: u64 = 0,
    cancels: u64 = 0, failures: u64 = 0, end_errors: u64 = 0, chunk_errors: u64 = 0,
    invalid_progress: u64 = 0, accepted: u64 = 0, active: u64 = 0, errors: u64 = 0,
    buffered_middleware: u64 = 0, slot0_active: bool = false, slot1_active: bool = false,
};
pub fn add_record(totals: *Totals, record: *const shared.Record) void {
'''
for k in ('middleware','attempts','begins','ends','cancels','failures','end_errors','chunk_errors','invalid_progress','errors'):s+=f'totals.{k} += record.{k};\n'
s+='totals.accepted += record.bytes;\ntotals.active += @intFromBool(record.active);\n}\n'
keys=('middleware','attempts','begin','end','cancel','failure','end_errors','chunk_errors','invalid_progress','accepted','active','errors','buffered_middleware','slot0_active','slot1_active')
import json
fmt='{{'+','.join('"'+k+'":{'+('any' if k.startswith('slot') else 'd')+'}' for k in keys)+'}}'
rename=dict(begin='begins',end='ends',cancel='cancels',failure='failures')
s+='pub fn format_totals(totals: Totals, output: []u8) ![]const u8 {\nreturn std.fmt.bufPrint(output, '+json.dumps(fmt)+', .{'+','.join('totals.'+rename.get(k,k) for k in keys)+'});\n}\n'
p.write_text(s)
