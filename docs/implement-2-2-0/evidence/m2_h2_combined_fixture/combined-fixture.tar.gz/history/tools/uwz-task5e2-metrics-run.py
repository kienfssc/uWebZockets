import json
from pathlib import Path
import subprocess
import sys

base = Path('/tmp/uwz-task5e2-' + sys.argv[1])
base.mkdir(exist_ok=False)
receipt = json.loads(Path('/tmp/uwz-task5e2-Final1/debug-receipt.json').read_text())
argv = receipt['argv'][:]
root = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-fixture/metrics_proof.zig'
for index, arg in enumerate(argv):
    if arg.startswith('-Mroot='):
        argv[index] = '-Mroot=' + root
    elif arg == '--cache-dir':
        argv[index + 1] = str(base / 'cache')
    elif arg == '--global-cache-dir':
        argv[index + 1] = str(base / 'global')
    elif arg.startswith('-femit-bin='):
        argv[index] = '-fno-emit-bin'
proc = subprocess.run(argv, cwd=receipt['cwd'], env={'LC_ALL': 'C.UTF-8'}, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(base / 'stdout').write_bytes(proc.stdout)
(base / 'stderr').write_bytes(proc.stderr)
(base / 'result.json').write_text(json.dumps({'argv': argv, 'cwd': receipt['cwd'], 'environment': {'LC_ALL': 'C.UTF-8'}, 'exit_status': proc.returncode}, indent=2) + '\n')
print('metrics proof compile exit=' + str(proc.returncode))
