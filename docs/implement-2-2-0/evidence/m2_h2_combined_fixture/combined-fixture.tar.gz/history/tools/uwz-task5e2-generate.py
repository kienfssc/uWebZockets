from pathlib import Path
import re, json, sys, hashlib
root=Path('/workspaces/uWebZockets')
owned=root/'.uwz-work/evidence/h2-streaming/integration-owned'
out=owned/'combined-fixture'
out.mkdir(exist_ok=False)
sys.path.insert(0,'/tmp/uwz-task5e1-contract-v3')
import model
families=(('core','core',2),('pause','pause-control/fix1',5),('admission','admission/fix1',22),('credit','credit/fix1',6),('metadata','metadata',1),('cancellation','lifecycle-control',6),('application','application-error',6),('lifecycle','lifecycle-close',12),('output_body',None,7))
source_map=[]
def declarations(source):
    starts=list(re.finditer(r'^(?:pub )?(?:fn|const) \w+',source,re.M))
    return {re.search(r'(?:fn|const) (\w+)',m.group()).group(1):source[m.start():starts[i+1].start() if i+1<len(starts) else len(source)] for i,m in enumerate(starts)}
record=declarations((Path('/tmp/uwz-task5d2-fix2-final-snapshot/profile.zig')).read_text())['Record']
record=record.replace('const Record','pub const Record').replace('    binding_index:', '    callback_checks: u32 = 0,\n    terminal_checks: u32 = 0,\n    helpers_begin: u32 = 0,\n    helpers_end: u32 = 0,\n    partial_done: bool = false,\n    binding_index:')
shared='''const std = @import("std");
const uz = @import("uWebZockets");
const Hash = std.crypto.hash.sha2.Sha256;
const output_state = @import("output.zig");
const file_observer = @import("file_observer.zig");
'''+record+'''
pub const Slot = struct {
    record: ?*Record = null,
    owner: *State = undefined,
    index: usize = 0,
    number: usize = 0,
    generation: u64 = 0,
};
pub const State = struct {
    slots: *[2]Slot,
    records: []Record,
    producers: *[3]output_state.Producer = undefined,
    file: *file_observer.State = undefined,
    reuse_admitted: *bool = undefined,
    buffered_middleware: u32 = 0,
    errors: u32 = 0,
    attempts: u32 = 0,
    failed: u32 = 0,
};
'''
(out/'shared.zig').write_text(shared)
for name,folder,count in families:
    if name=='core': continue
    path=owned/folder/'profile.zig' if folder else Path('/tmp/uwz-task5d2-fix2-final-snapshot/profile.zig')
    raw=path.read_text(); parts=declarations(raw)
    source_map.append(dict(family=name,path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size))
    tags=[row[0] for row in model.BODY_SPECS if row[1]==('output' if name=='output_body' else name)]
    result='''const std = @import("std");
const uz = @import("uWebZockets");
const shared = @import("shared.zig");
const Record = shared.Record;
const Slot = shared.Slot;
const State = shared.State;
const Hash = std.crypto.hash.sha2.Sha256;
const format_record = @import("formatting.zig").format_record;
const output_state = @import("output.zig");
const file_observer = @import("file_observer.zig");
'''
    result+='pub const tags = [_][]const u8{'+','.join(json.dumps(t) for t in tags)+'};\n'
    exclude={'std','uz','Hash','config','tags','Record','Slot','State','format_record','health','echo','status','Totals','totals','format_totals','metrics','main'}
    for key,value in parts.items():
        if key in exclude: continue
        value=value.replace('for (&state.slots)', 'for (state.slots)').replace('for (&state.slots,', 'for (state.slots,')
        value=value.replace('slot.* = .{ .owner = state, .record = record, .index = index };','slot.generation += 1;\n        slot.owner = state;\n        slot.record = record;\n        slot.index = index;')
        if name=='output_body':
            value=value.replace('state.reuse_admitted = true','state.reuse_admitted.* = true').replace('&state.reuse_admitted','state.reuse_admitted').replace('&state.file','state.file')
        value=re.sub(r'^fn (begin|chunk|end|cancel|middleware|control|output_status|tag_index)\(', r'pub fn \1(',value,flags=re.M)
        # One central route capture name preserves all existing control handlers.
        value=value.replace('get_param("action")','get_param("op")')
        result+=value
    (out/(name+'.zig')).write_text(result)
for name in ('output.zig','file_observer.zig'):
    path=Path('/tmp/uwz-task5d2-fix2-final-snapshot')/name
    (out/name).write_bytes(path.read_bytes())
    source_map.append(dict(family=name,path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size))
(out/'source_bindings.json').write_text(json.dumps(source_map,indent=2)+'\n')
# Canonical format schema, one formatter called by end/status/post-deinit.
common=list(model.COMMON_RECORD)
fields={'begins':'begins','ends':'ends','cancels':'cancels','failures':'failures'}
s='''const std = @import("std");
const shared = @import("shared.zig");
const Hash = std.crypto.hash.sha2.Sha256;
'''
for family,extras in model.FAMILY_EVIDENCE.items():
    keys=common+list(extras)
    fmt=[]; args=[]
    for key in keys:
        if key in ('tag','sha256'):
            fmt.append('"'+key+'":"{s}"'); args.append('tag' if key=='tag' else 'hex')
        elif key=='reason': fmt.append('"reason":{s}'); args.append('reason')
        elif key in ('active','paused'): fmt.append('"'+key+'":{any}');args.append('record.'+key)
        else:fmt.append('"'+key+'":{d}');args.append('record.'+key)
    template='{{'+','.join(fmt)+'}}'
    s+='fn format_'+family+'(record: *const shared.Record, tag: []const u8, hex: []const u8, reason: []const u8, output: []u8) ![]const u8 {\nreturn std.fmt.bufPrint(output, '+json.dumps(template)+', .{'+','.join(args)+'});\n}\n'
s+='pub fn format_record(record: *const shared.Record, tag: []const u8, output: []u8) ![]const u8 {\nvar hash = record.hash;\nvar digest: [32]u8 = undefined;\nhash.final(&digest);\nconst hex = std.fmt.bytesToHex(digest, .lower);\nconst reason = if (record.reason) |value| switch(value) {\n'
# actual source enum known via source locator
s+='inline else => "\\\"" ++ @tagName(value) ++ "\\\"",\n} else "null";\n'
for family in model.FAMILY_EVIDENCE:
    tags=[row[0] for row in model.BODY_SPECS if row[1]==family]
    for tag in tags:
        s+='if (std.mem.eql(u8, tag, '+json.dumps(tag)+')) return format_'+family+'(record, tag, &hex, reason, output);\n'
s+='return error.InvalidTag;\n}\n'
(out/'formatting.zig').write_text(s)
(out/'tags.zig').write_text('pub const tags = [_][]const u8{'+','.join(json.dumps(row[0]) for row in model.BODY_SPECS)+'};\n')
