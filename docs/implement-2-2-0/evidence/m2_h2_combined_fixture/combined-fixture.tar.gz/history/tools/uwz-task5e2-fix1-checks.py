import json
from pathlib import Path
import subprocess

base = Path('/tmp/uwz-task5e2-Fix1Checks')
base.mkdir(exist_ok=False)
fixture = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-fixture')
python = '/home/codespace/.python/current/bin/python3'
zig = '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig'
commands = []
for name in ('test_prepare', 'test_bounds_helper', 'check_structure'):
    for optimized in (False, True):
        label = name + ('-O' if optimized else '-normal')
        args = [python, '-B', '-S'] + (['-O'] if optimized else []) + [str(fixture / (name + '.py'))]
        commands.append((label, args))
commands.append(('fmt', [zig, 'fmt', '--check', str(fixture)]))
results = []
for label, argv in commands:
    proc = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (base / (label + '.stdout')).write_bytes(proc.stdout)
    (base / (label + '.stderr')).write_bytes(proc.stderr)
    results.append({'name': label, 'argv': argv, 'exit_status': proc.returncode})
    print(label + ' exit=' + str(proc.returncode))
(base / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
if any(item['exit_status'] for item in results):
    raise SystemExit(1)
