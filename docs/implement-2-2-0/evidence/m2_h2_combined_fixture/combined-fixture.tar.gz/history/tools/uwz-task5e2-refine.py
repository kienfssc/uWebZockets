from pathlib import Path
import re,json,hashlib,sys
out=Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-fixture')
for p in out.glob('*.zig'):
    s=p.read_text();lines=s.splitlines(True);seen=set();new=[]
    for line in lines:
        if line in seen and line.startswith('const ') and '@import(' in line:continue
        seen.add(line);new.append(line)
    s=''.join(new)
    for name in re.findall(r'^const (\w+) = (?:@import|shared\.)',s,re.M):
        if len(re.findall(r'\b'+name+r'\b',s))==1:s=re.sub(r'^const '+name+r' = .*?;\n','',s,flags=re.M)
    p.write_text(s)
p=out/'prepare.py';s=p.read_text().replace('Path(__file__).resolve().parent','Path(__file__).parent');p.write_text(s)
# Additional immutable source binding supplied and authenticated by Root.
p=out/'source_bindings.json';m=json.loads(p.read_text());core=out.parent/'core/profile.zig';m.append(dict(family='core',path=str(core),sha256=hashlib.sha256(core.read_bytes()).hexdigest(),bytes=core.stat().st_size));p.write_text(json.dumps(m,indent=2)+'\n')
(out/'lifecycle_source_identity.json').write_bytes(Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e2-lifecycle-source-identity.json').read_bytes())
sys.path.insert(0,'/tmp/uwz-task5e1-contract-v3');import model
records=model.records((), 'after')
s='''const std = @import("std");
const formatting = @import("formatting.zig");
const shared = @import("shared.zig");
pub fn prove() void {
    @setEvalBranchQuota(2000000);
    const record: shared.Record = .{};
    var buffer: [768]u8 = undefined;
'''
for tag,family,*_ in model.BODY_SPECS:
    expected={k:records[tag][k] for k in model.COMMON_RECORD+model.FAMILY_EVIDENCE[family]}
    expected['chunks']=0;expected['max_span']=0
    encoded=json.dumps(expected,separators=(',',':'))
    s+='const value_'+tag+' = formatting.format_record(&record,'+json.dumps(tag)+', &buffer) catch @compileError("default formatting '+tag+'");\n'
    s+='if (!std.mem.eql(u8, value_'+tag+', '+json.dumps(encoded)+')) @compileError("independent default schema '+tag+'");\n'
s+='}\n';(out/'schema_proof.zig').write_text(s)
p=out/'profile.zig';s=p.read_text().replace('comptime log_bounds.prove(config);','comptime log_bounds.prove(config);\n    comptime @import("schema_proof.zig").prove();');p.write_text(s)
