# Task5e2 fresh independent fixture review

Read task-5e2-fixture-brief.md first (requirements), then task-5e2-resume-brief.md
and the complete task-5e2-report.md. Task5e1 model/source/fix/publication is already
complete in1301d15; it is an immutable input, not native combined evidence.
This is a fresh task review, not another pass over Task5e1 or the old five outputs.

Base and current HEAD:1301d1542a9e23fdfb70b645d185f3f39d06c09b. The source is new
ignored preparation code, not a committed implementation range. Full24-file diff:
task-5e2-review.diff,191061bytes,SHA256
ac5dd9198c26f8d8591422150106fdebe1309bab901b8ec5b06edc00ab41819c.
It contains all22 final fixture/source/test/binding files plus the actual temporary
bound-observation Python helper and its Zig probe. Source paths/identities:
task-5e2-review-source.json. Read that diff once as the changed-source view; only
re-read changed files if a hunk cuts a needed function. No git diff reruns.
Root's separate M2 milestone status/link edit is outside this source review.

Root has read the actual report, new callback/control/formatter/prepare/proof code
and retained diagnostics. The copied output.zig and file_observer.zig remain
byte-identical to previously reviewed source; source bindings preserve that fact.
Root's final compile audit verifies actual22 frozen files/current owned equality,
all1031candidate and93override files, all12 original direct inputs, both actual
binary identities, controlled env/maps/empty compiler streams. Evidence:
task-5e2-root-compile-audit.json. Root independently parses all67 compiler-exercised
idle JSON literals and compares them to the unchanged reviewed model:
task-5e2-root-idle-schema-audit.json. These audits do not decide behavioral fidelity.

Read actual final receipts/stdout/stderr at /tmp/uwz-task5e2-Final1, with source at
its fixture directory. Successful Debug/ReleaseSafe compile artifacts were never
executed. Earlier Build1/Build2/Resume1/Resume2 failed Debug; Resume3 passed both
modes on an intermediate pre-cleanup source. All original snapshots/receipts stay
retained. The first implementer terminally failed at capacity, not an observation
timeout; Root preserved its partial22files and the replacement completed them.
The initial missing-prepare RED's exact original invocation is not retained; the
report explicitly limits that evidence. Current pure-check commands/stdout/exits
are in the report. Inspect their adequacy against the task requirements.

The supplemental bound probe /tmp/uwz-task5e2-Bounds1 intentionally exits1 from
@compileLog, independently from the successful fixture builds. Read its actual
receipt/stdout/stderr and Root's task-5e2-root-review-audit.json. Its22 copied source
files match Final1; one added probe evaluates the same proof. Observed values:
body462/output553/prefix51/allowance1440/retained39150, below the contractual bounds.
This establishes actual compiler evaluation; assess whether the source assumptions
cover all permitted values and actual logging/nonce prefixes. It is not a runtime
measurement or native error/fault experiment.

Apply .codex/agents/reviewer.toml, AGENTS.md, CODING_CONVENTION.md,
.agents/skills/code-review-and-quality/SKILL.md and the structural lens in
.agents/skills/thermo-nuclear-code-quality-review/SKILL.md (Root expressly requests
this task-scoped structural pass; AGENTS override governs the1000line review flag).
Use the superpowers task-reviewer-prompt.md method. No subagents or external model
CLI. Read source/retained evidence only; no passing-check reruns, imports, compiler
commands, old entrypoints, constructor/native/socket/TLS/descriptor/kernel/resource/
fault/cancel/schedule/race/panic/leak experiments. No Git/index/ref/product/evidence
mutations. You may write only task-5e2-review.md in this plan directory.

Binding requirements are the full original brief. In particular:
"Exactly67 persistent body records and two reusable application slots; no spare
namespaces." "Preserve every family callback/declaration/limit/quota/readiness/
partial/EOF/Continue/control/error/cancel/reset/recovery behavior from original
sources and reviewed independent model" and "The pure model is an oracle, not
permission to delete original self-checks." "Canonical wire record schema must
implement final model's exact keys and types"; "Output diagnostics/metrics retained."
"Guard scripts with main; imports silent/inert under empty/foreign argv."
No authored classes/assert proof statements/hidden mutable globals/ignored errors;
no forwarding wrappers/speculative abstractions, dead code or unused imports.
Preserve old source family helper predicates, borrowed fields/owned producer copies,
relative A->B binding, file ownership/close once, paused final transitions and
subset/idle defaults. New family views must remain valid for all callback/control
lifetimes. Judge model-facing interfaces and source metrics alongside body schemas.

Check source correspondence for named concrete risks, not a broad repository crawl.
Source_bindings.json points to corrected final family fixtures; lifecycle identity
is additionally authenticated by task-5e2-lifecycle-source-identity.json. Current
model: /tmp/uwz-task5e1-contract-v3, with notes and source map beside its report.
Before a new codebase search use graphify query; provided located files may be read:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650

Persist full report at task-5e2-review.md. Return explicit SPEC and QUALITY
verdicts, actionable severity/file:line/trigger/fix findings, structural conclusion
and exact verification limits. No claim of native combined40, M2, project gates,
production adoption or original goal completion follows from this review.
