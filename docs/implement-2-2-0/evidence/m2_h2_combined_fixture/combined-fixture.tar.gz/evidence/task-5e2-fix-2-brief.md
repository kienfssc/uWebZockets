# Task5e2 fix round2 of5: auxiliary recorder import boundary

Read task-5e2-review-fix-1.md, especially N1 verbatim. R1/R2-original/R3 and R4
are resolved; N1 is the sole blocking finding. Same current Terra owner resumes.
Root accepts the concrete import side effects. Preserve the original unguarded
metrics-run.py and fix1-checks.py and all existing evidence unchanged as history.

Own only NEW /tmp/uwz-task5e2-Fix2Tools/ (or another new task5e2 path), new pure
proof/result paths and append same task-5e2-report.md. Do not change the current
25-file owned fixture or Fix1Final2/Bounds2: their successful compiler/source
evidence remains valid and must not be rerun solely for this recorder change.
No agents/commits/pushes/product/model/pin/ref/public evidence edits. You are not
alone; preserve Root's pending publication work and every prior artifact.

Create guarded replacement recorders with explicit main(args), immutable import-
time definitions only, preserving operational command/evidence behavior for an
explicit future invocation. Provide a focused main-guarded AST and silent/inert
import checker for ALL newly authored current recorders/helpers, including itself,
both replacements and the current fixture helpers. Use visible rejecting caller-
owned doubles to prevent filesystem writes/copies/process/compiler actions during
the check. Test empty and foreign argv. Keep no classes/inheritance/assert proof
statements, hidden mutable globals, ignored errors or speculative framework.

Retain behavior-specific REDs against both actual historical recorder files,
before replacing their source role, and GREENs against the corrected replacements;
no actual filesystem/compiler action from a bad import may occur. The expected
IndexError or rejecting-double failure is evidence of the old problem, not an
unexpected native failure. Normal and -O pinnedPython -B -S checks must remain
active, with exact commands/stdout/stderr/exits in separate versioned result files.
Freeze the new small tool source snapshot/hash map. Add explicit command/refusal
coverage only if required by a new changed path; don't rerun unrelated passed
fixture/compiler/probe work. AST/import checks on unchanged helpers are permitted
as the new coverage boundary, not a new whole-suite run.

No compiler/build, fixture binary/server/native constructor/socket/TLS/SSLContext/
certificate/transfer-file/descriptor/kernel/resource/fault/cancel/schedule/race/
panic/leak operation or full native/project gate is authorized in this round.
This is pure caller-owned Python data/doubles/AST/import proof only.

Append exact changed files/APIs/raw results/identities/old-evidence preservation
and limitations to task-5e2-report.md. Root reads actual source/evidence then asks
the same reviewer's scoped N1 re-review; no fresh broad review or native claim.
