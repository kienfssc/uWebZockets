# Task5e2: combined HTTP/2 fixture and compile-only evidence

Released by Root after Task5e1 source/fix/publication reviews passed and commit
1301d1542a9e23fdfb70b645d185f3f39d06c09b was immediately pushed to fork.
Read this first, then task-5e-combined-architecture.md and the final reviewed
Task5e1 snapshot /tmp/uwz-task5e1-contract-v3 (model.py/source_notes.md) and
task-5e1-publication-source.json for all exact identities. The published archive
is docs/implement-2-2-0/evidence/m2_h2_combined_contract/combined-contract.tar.gz
SHA61d0640aabfd67528e61d394395694498174c2895a8beec74b47b49e715351b1.
This implements ordered preparation item2 only.
No combined client/ledgers/runtime/native execution or product adoption.

Ownership: NEW .uwz-work/evidence/h2-streaming/integration-owned/combined-fixture/,
new /tmp/uwz-task5e2-* and task-5e2-report.md. You are not alone in the repository;
preserve others' work, all prior artifacts, candidate, dependencies, model and
public evidence. No subagents, external model CLI, commits/pushes/ref/pin changes.
Root owns review/publication/execution releases. Read AGENTS/CODING and narrow
Zig0.16/best-practices/build/TDD skills before corresponding work. No new classes,
assert proof statements in Python, hidden state or ignored errors. Named explicit
types, pure functions for formatting/model/policy, shallow early-return control.

Inputs: immutable candidate /tmp/uwz-task4d-fix1-frozen (fc69/1031files), libxev
/tmp/uwz-reviewed-libxev-c223-loop-callbacks (93files), reviewed output fixture
/tmp/uwz-task5d2-fix2-final-snapshot (profile.zig, output.zig, file_observer.zig,
prepare.py, test_prepare.py). Reuse by copying into new owned fixture, not editing
old files. Output modules currently assume seven tags/32records and index metadata;
these cannot be relabeled all67. Exact family sources/metadata/helper contracts
are authenticated by final Task5e1 source map and prior published source archives;
corrected admission/pause/credit sources are fix1, not stale top-level history.
Compiler /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig.
Python /home/codespace/.python/current/bin/python3 with -B -S. Original actual
compile recipes: .uwz-work/evidence/h2-streaming/integration-owned/metadata/
fixture-debug-final.json and fixture-release-final.json, 12 nonfixture direct
inputs unchanged. No CMake/Ninja/system compiler or network dependency fetching.
Use /tmp caches/output and low compilation concurrency; preserve disk space.

Required combined behavior:
* Exactly67 persistent body records and two reusable application slots; no spare
  namespaces. All40 IDs, including buffered/async, and exact catalogued tags.
  Support fresh idle child with zero defaults; main child all39 ending active.
  Preserve native8connections/8H2streams/73728receive payload, 3producer8192
  scratches and one8192file scratch. No hot-path heap allocation or body retention.
* Preserve every family callback/declaration/limit/quota/readiness/partial/EOF/
  Continue/control/error/cancel/reset/recovery behavior from original sources and
  reviewed independent model, including exact accepted prefix/hash/one begin/end,
  failed-begin rollback, end_error without cancellation, trailer isolation and
  shared-slot generation-safe controls. The pure model is an oracle, not permission
  to delete original self-checks. Metadata66headers/17captures/zero allocator/
  BodyNotBuffered unchanged issue state/empty text+bytes and both query helpers,
  per-callback pause/control checks, errors0 and all stale-control observations.
* Producers preserve borrowed metadata versus owned copies with no Request pointer
  retention; real B slot same as A, generationA+1 despite earlier body activity;
  public callbacks/offset/hash/2049writes/end/algebra and after_reuse counter.
  File range37/24593/end24630, safe Io userdata delegation, transferred ownership,
  close once with no post-deinit second close. Returned-error ownership stays
  separately retained evidence, no forced-native-error probe.
* All routes retain public App/BodySink/Response APIs and same status/metrics/
  resume/cancel/producer/file controls needed by model and saved schedule. Do not
  add polling or async observation route; source handoff already proves one GET
  after full action flush. No extra wire heads or widened limits/deadlines.
* Canonical wire record schema must implement final model's exact keys and types,
  including None/null reason versus legacy none normalization; family extras
  preserved with exact untouched defaults. Output diagnostics/metrics retained.
  Pre-deinit evidence comes from the scheduled67 HTTP status responses plus
  metrics (and selected output/binding observations); emit one post-deinit log
  dump with67 body records+4 output records+metrics and binding marker. Do not
  duplicate both full dumps into the child log. Check correct shutdown cancel
  transition and no extra slot. Status formatting and post log formatting agree.
  Preserve the separate producer_reuse_next binding marker, selected relative
  A->B and unselected exact index0/generation0. The model's output pre/post check
  now requires binding_before/binding_after explicitly. Retain ready_buffered's
  bytes0..250+0..5 echo and async delayed-ok10/text/plain contracts; neither creates
  streaming sink activity. Idle child inherits the4096read limit in client scope.
* Prove actual formatter body<=768 bytes, output<=1024, prefixes<=64 and total
  <=62144<65536 for allowed state, not a guessed constant or copied calculation.
  Use actual formatter code exercised at comptime or a strictly pure isolated
  formatter helper check (no App/IO/descriptor/native constructor); compile-only
  proof is preferred. If source facts contradict proposed bounds, report smallest
  concrete correction to Root before changing contract/capacity. Include exact
  modes, bounded numbers/tags/reasons/field lengths used for bound proof. Include
  actual log severity/marker/nonce/separator bytes in prefix bounds and every
  capacity/ready/binding/metrics line in the2048-byte allowance. Bound the nonce
  at setup so its accepted range really fits the64-byte prefix contract; the
  prior fixture's nonce<=64 alone does not prove that prefix bound.

Allowed execution: source/hash/AST/inert imports and focused new pure preparation
checks normal/-O; actual Debug and ReleaseSafe compile-only commands of the new
fixture with complete controlled env {LC_ALL:C.UTF-8}, no inherited ambient env.
Preserve argv,cwd,env/hash, all inputs before/after, candidate/override/fixture
maps/digests, binary SHA, stdout/stderr/exit and all failed attempts honestly.
No fixture/server execution, TLS context/cert/transfer-file creation, socket,
descriptor/kernel/resource/fault/cancel/schedule/interleaving/race/panic/crash/leak
probe; no old native/checker entrypoint or project-wide/native suite. Neither
compiled binary is authorized to run. No full gate/adoption/milestone claim.
Guard scripts with main; imports silent/inert under empty/foreign argv. Test
actual preparation command construction/env/copy/hash/refusal paths with visible
caller-owned doubles, not mirrors of implementation or imports that compile.

Keep modules cohesive by responsibility; avoid a growing monolith or thin wrappers.
A real structural concern requires simplified ownership, not mechanical splitting.
Meaningful RED/GREEN for new pure behavior, then final normal/O outcomes and AST/
inert proof. Freeze new small source snapshot and all exact compile inputs.
Write full task-5e2-report.md with changed files/API/formatter proof/source bindings,
exact commands/raw results/failed attempts, actual Debug/RS receipts, self-review,
remaining facts and execution boundary. Return only status/report/test summary/
concerns. Root reads actual source/report/evidence then fresh independent review.
Graphify before new source questions; provided/earlier located paths can be read.
