# Task5e2 independent SPEC and QUALITY review

SPEC: NEEDS FIXES. QUALITY: NEEDS FIXES.

Four actionable findings: one P1, two P2, one P3. This is the task-scoped
review of the 24-file preparation diff identified by SHA-256
`ac5dd9198c26f8d8591422150106fdebe1309bab901b8ec5b06edc00ab41819c`,
against immutable Task5e1 at `1301d1542a9e23fdfb70b645d185f3f39d06c09b`.
Paths below are relative to
`.uwz-work/evidence/h2-streaming/integration-owned/combined-fixture/`
unless an absolute path is supplied.

## Findings, ordered by severity

### R1 — P1: Emit the approved metrics schema, including paused totals

Location: `formatting.zig:138-140`; aggregation at `formatting.zig:107-136`
and `profile.zig:217-221`.

The formatter emits `begin`, `end`, `cancel`, `failure`, and `accepted`, while
the approved model requires `begins`, `ends`, `cancels`, `failures`, and `bytes`.
It also omits the aggregate `paused` field entirely. The immutable model's
`metrics` and `validate_metrics` at
`/tmp/uwz-task5e1-contract-v3/model.py:365-393` require exact keys and types,
including `paused` and both slot booleans. The fixture's `/metrics` and
`H2_DEINIT` use this same incompatible formatter.

Concrete failure: final metrics from a fresh idle child already fail the model's
`metrics schema` check. Main active-shutdown evidence additionally cannot expose
the required paused count transition from one before shutdown to zero afterward.
Body-record default checks do not exercise this formatter, so both successful
builds and all 67 default body comparisons can pass with this defect.

Fix: use the model's exact metrics names, aggregate `record.paused` as an integer,
and retain the slot booleans. Add a pure/comptime formatter comparison covering
idle, selected terminal totals, and active-shutdown before/after against the
approved model schema. Refresh the changed formatter's size proof and final
source-bound compile evidence; do not add client-side guessed fields or weaken
`validate_metrics`.

### R2 — P2: Guard the supplemental probe helper against import-time execution

Location: `/tmp/uwz-task5e2-bounds-probe.py:7-13` and `:31-38`
(`evidence-tools/bounds-probe.py` in the supplied diff).

This Python file creates an attempt directory, copies the fixture, writes Zig
source, invokes the compiler, writes evidence, and prints at module scope. It
has no `main` guard. The explicit task requirement applies to preparation scripts:
imports must be silent and inert under empty or foreign argv. The current
`check_structure.py:16-17` only enumerates Python files inside the fixture, so it
does not cover this helper despite its inclusion in the reviewed source set.

Concrete failure: importing the retained helper now raises `FileExistsError`
because Bounds1 exists; on a fresh equivalent path it performs compilation and
filesystem mutations merely to load the module. Neither outcome is an inert
import.

Fix: put operational work in an explicitly called `main`, keep only immutable
definitions at module scope, and include the helper in the AST/inert-import
coverage. Preserve the original Bounds1 evidence; retain a corrected helper as
a new source artifact rather than rewriting the historical receipt's inputs.

### R3 — P2: Remove identical serializer implementations and duplicated dispatch

Location: `formatting.zig:3-29` and `:39-105`.

Nine family-named serializers duplicate the complete common schema. In
particular, core/admission are identical implementations, and cancellation,
application, lifecycle, and output are another four identical implementations.
The public formatter then spells out 67 tag comparisons to choose these copies,
duplicating the tag/family ownership already represented by the fixture.

This is a concrete structural defect under the requested second lens and the
project's no-redundant-abstraction rule: a single correction to the common schema
requires synchronized changes in nine long format strings and argument lists;
a control-family correction requires four identical edits. A missed edit makes
the same canonical field serialize differently solely because of its tag. The
family-named copies add no distinct invariant or type guarantee.

Fix: serialize the common record once, append only the explicitly named extra
field groups, and select a named schema shape through one bounded tag/family
mapping. At minimum collapse the byte-identical implementations and eliminate
the per-tag forwarding branch chain. Keep independent expected-schema evidence,
all exact keys/types, allocation-free buffers, and actual formatter bound checks.
This does not require a generic reflection framework or a mechanical file split.

### R4 — P3: Remove unused imports and aliases in the new family modules

Location: `admission.zig:4,8`, `application.zig:4,9`,
`cancellation.zig:4,8`, `credit.zig:4,8`, `lifecycle.zig:4,9`,
`metadata.zig:4,8`, `output_body.zig:4`, and `pause.zig:8`.

These `Record` aliases and `file_observer` imports have no uses in their respective
modules. Only pause uses its `Record` alias; only output_body uses its
`file_observer` import. The copied declarations falsely suggest that unrelated
families depend on file-output observation and remain after the reported cleanup.
Zig's lazy declaration handling lets the build pass, so compile success does not
establish the mandatory dead-code/import hygiene requirement.

Fix: delete the unused declarations in the owned fixture and retain only actual
dependencies. No behavior change or additional abstraction is needed.

## Structural conclusion

The main ownership decomposition is appropriate: `profile.zig:33-54` owns exactly
67 records, two reusable slots, three producer contexts, one file observer, and
nine persistent family views. The views point into main-owned storage rather
than escaping temporary contexts. Callback dispatch is centralized at
`profile.zig:105-160`, while family predicates remain in their owning modules.
No reviewed file crosses the project's 1000-line review flag; the largest is
309 lines. The relevant structural blocker is the serializer duplication in R3,
not file length. The structural lens supplements the normal correctness gate;
it does not override the fixture's capacities or authorize deleting self-checks.

## Named correspondence checks and retained evidence

- Shared-slot lifetime/reuse risk: read `shared.zig`, `profile.zig`, all nine
  family modules, and output capture/producer code in the full diff. Slot owners
  reference persistent family views; generation increments across families;
  output B records the actual reused slot/generation. Producer borrowed metadata
  and separate owned copies remain in `output.zig:52-65`; file transfer and
  cleanup remain in `file_observer.zig:64-82`.
- Lost-family-check risk: inspected the source-bound original core and corrected
  pause/admission/credit fixtures, metadata helper predicates, cancellation and
  application callback paths, lifecycle metadata/partial/end paths, and original
  output begin/chunk/end/metrics. The new code retains the inspected metadata
  66-header/17-capture checks, zero allocator/unchanged issue checks and both
  query helpers, callback-active/expired checks, accepted-prefix behavior,
  deliberate begin/chunk/end failures, and output hash checks. I found no
  additional dropped self-check in those comparisons. The model was treated as
  an immutable interface, not re-reviewed as a whole.
- Schema compatibility risk: compared the new body formatters/default literals
  with `model.py:15-50,103-176`, and the metrics formatter with
  `model.py:365-393`. Root's retained idle-schema audit corroborates all 67
  compiler-exercised default body literals, explicitly excluding metrics and
  runtime. R1 is outside that audit's claim.
- Bound-assumption risk: read `log_bounds.zig:18-137` against actual formatters
  and logging in `profile.zig:263-288`. The current proof uses every tag,
  longest encoded reason, fixed SHA width, allowed-schedule body counters,
  maximal producer/file counters, longer false boolean spellings, and a setup-
  enforced 32-byte safe nonce. Prefixes include `info: `, markers, separators and
  newline; allowance includes capacity, ready, binding and metrics. The actual
  Bounds1 diagnostic reports body 462, output 553, prefix 51, allowance 1440,
  retained 39150. This supports the current formatter's compile-time bound,
  not the corrected metrics formatter or runtime traffic.
- Build/evidence risk: read actual Final1 Debug/ReleaseSafe receipt commands,
  working directory, optimization, LC_ALL-only environment, 12 direct inputs,
  artifact identities and actual empty stdout/stderr. Both receipts report
  exit 0. Read Root's final source/input-map audit and source inventory; no claim
  here duplicates its full filesystem hash audit. Read Bounds1's actual receipt
  and diagnostic; its exit 1 is intentionally caused by `@compileLog` and is
  separate from the two successful fixture builds.
- Preparation-test risk: read `test_prepare.py:27-58` and
  `check_structure.py:14-47`, plus the complete implementer report. The focused
  checks exercise the real command builder, environment creator, snapshot copy
  with caller-owned doubles, and basic refusal functions. They do not exercise
  `retain_attempt`/`main` refusal ordering or the supplemental helper. The only
  retained RED is a missing-module diagnostic without its original invocation;
  this does not prove behavior-specific RED/GREEN coverage of final preparation.

## Verification limits

This review read the complete supplied diff once in sequential chunks, without
reopening changed source files or rerunning Git commands. Other source reads
were the named correspondence checks above. I read AGENTS.md,
CODING_CONVENTION.md, reviewer/HTTP-protocol/verification instructions, the task
briefs/report/architecture, both requested review skills, and the superpowers
task-reviewer method. Graphify was queried before the focused source searches.

No tests, imports of reviewed code, compiler commands, fixture binaries, native
constructors, sockets/TLS, descriptor/kernel/resource/fault/cancel/schedule/race/
panic/leak operations, or project gates were run. Only this review report was
written. The normal/-O pure-check passes are retained implementer evidence,
not reruns by this reviewer. Native combined40 behavior, runtime lifetimes,
wire ordering, final cleanup, broader project gates, M2, production adoption,
and original-goal completion remain unverified by this task review.
