# Task5e2 fix round 1 scoped re-review

SPEC: NEEDS FIXES.
QUALITY: NEEDS FIXES.

The original named targets of R1–R3 are resolved; R4's nonblocking cleanup is
also resolved. One new P2 finding remains in the supplemental fix tools: two
new scripts repeat the import-time execution defect. This does not approve
native execution or establish combined40, M2, project-gate, or production success.

Reviewed the complete 16-file fix diff once, SHA-256
`04f4322dcc4089b1e080c8f0b2873b8055f71d49387156e5d4141de7452ca4f1`,
against the prior reviewed source. Final source is the 25-file snapshot at
`/tmp/uwz-task5e2-Fix1Final2/fixture`. Base/HEAD remains
`1301d1542a9e23fdfb70b645d185f3f39d06c09b`; Root's documentation edit is outside
this review. Also reviewed the complete two-file supplemental tool diff,
SHA-256 `60180b331d5dbf2d5f401fd181a8b7eccc60e3076f3c119c646abace226801bc`,
and its identity map after Root supplied the omitted authored recorder scripts.
File references below are relative to the fixture unless absolute paths are given.

## New actionable finding

### N1 — P2: Guard both new auxiliary recorder scripts and include them in import checks

Locations: `/tmp/uwz-task5e2-metrics-run.py:6-24` and
`/tmp/uwz-task5e2-fix1-checks.py:5-26`.

Both files introduced during this fix perform operational work at module scope,
without a `main` guard. The metrics runner immediately indexes `sys.argv[1]`,
creates an attempt directory, invokes Zig, writes evidence and prints. The checks
runner creates its fixed directory and runs all seven commands while being
imported. These are the actual authored scripts cited by the fix report; they
are not untouched baseline tools.

Concrete failure: importing the metrics runner under empty argv raises
`IndexError`; foreign argv can cause directory creation and compiler execution.
Importing the checks runner currently raises `FileExistsError` at its already-
retained output directory, or starts filesystem mutations and tests/formatting
when that directory does not exist. Both violate the explicit silent/inert
import requirement. The fixture-only scan still excludes these `/tmp` files,
so the seven passing checks do not cover this newly introduced failure.

Fix: retain guarded replacement versions with explicit `main(args)` entrypoints
and include every newly authored recorder/helper in the AST and silent/inert
import coverage with rejecting caller-owned doubles. Preserve these original
scripts and their existing evidence as history. Do not rerun successful compiler
or native work merely to replace historical recorders; demonstrate the corrected
import behavior through the authorized focused pure checks and bind the new
source artifacts in the review package.

## Prior-finding verdicts

- **R1 — Resolved.** `formatting.zig:42-64` sums actual record fields, including
  integer paused counts, and emits the exact model metrics names and both slot
  booleans. The profile now uses `sum_records` before the same metrics formatter
  for HTTP and post-deinit output. `metrics_proof.zig:5-24` exercises that actual
  aggregation and serialization with record inputs for idle, selected terminal
  totals, and active shutdown before/after. The expected literals distinguish
  paused 1 from paused 0 and are independently matched to the immutable model in
  Root's retained audit. The original schema mismatch and lost paused evidence
  are corrected without changing the model or fabricating client defaults.
- **R2 — Original target resolved; equivalent new defect recorded as N1.**
  `bounds_probe.py:18-58` places filesystem and compiler work
  inside `main`, invoked only by its guard. Import-time content consists of
  imports and function definitions. `test_bounds_helper.py:12-32` imports the
  real helper under empty and foreign argv, captures output, and uses visible
  rejecting doubles for writes, copying and compiler execution. The helper now
  resides in the fixture and is included by the existing AST/import scan. The
  original unguarded helper and Bounds1 remain historical evidence, rather than
  being silently rewritten.
- **R3 — Resolved.** `formatting.zig:5-23` writes the common record exactly once
  and appends only one of five named extra-field groups. `tags.zig:5-30` supplies
  bounded tag lookup, one family mapping, and an exhaustive family-to-schema
  switch shared with profile dispatch. All family boundaries match their
  unchanged record slices. Unknown tags return `InvalidTag`, with an explicit
  compile-time check at `schema_proof.zig:8`. The nine duplicated serializers and
  67 forwarding branches are removed, while the independent 67 literal schema
  comparisons remain. No reflection framework, allocation, capacity increase,
  or callback/self-check removal was introduced.
- **R4 — Resolved, nonblocking cleanup.** The import-only hunks at the tops of
  admission, application, cancellation, credit, lifecycle, metadata, output_body
  and pause delete precisely the previously identified unused aliases/imports.
  Used pause Record and output_body file-observer declarations remain. No
  additional review loop is required for this observation.

## Fix evidence inspected

- Read the fix brief, original R1–R3 verbatim, appended implementation report,
  complete fix diff, final source map, and
  `task-5e2-root-fix-1-audit.json`, then the supplemental two-tool diff and map.
  The audit records unchanged candidate,
  override, direct inputs, and retained sources, preservation of initial review
  artifacts, 67 body proofs, and four metrics comparisons against the model.
  This reviewer did not repeat Root's complete filesystem hash audit.
- Read the actual metrics RED diagnostic and `result.json`: compiler exit 1
  at the idle comparison with `metrics differ from approved model`. Read
  Green3's `result.json` and empty streams: compiler exit 0. Both use the pinned
  compiler, controlled LC_ALL-only environment, and `-fno-emit-bin`. Final2's
  fixture builds additionally compile the current metrics proof.
- Read the actual helper RED traceback and exit file: exit 1 at the rejecting
  `mkdir` double, before filesystem mutation. The helper GREEN has exit 0,
  the expected silent/inert PASS line, and empty stderr.
- Read all seven entries in `/tmp/uwz-task5e2-Fix1Checks/results.json` and their
  actual stdout/stderr. Preparation, helper-import and structure checks pass in
  normal and optimized Python modes; the formatting check passes silently.
  All seven stderr streams are empty.
- Read Final2's actual Debug and ReleaseSafe receipt commands, controlled
  environment, statuses and artifact identities, plus actual empty compiler
  stdout/stderr. Both report exit 0. Artifact SHA-256 values are
  `37557e3932bc04d8d98b7ddccc1ed6479a555c5df9a562ea287ac9ea1405019c`
  and `3004debe07208fe508aa293141251213aad33c5eee6a086660efd18288780e76`.
- Read Fix1Bounds2's actual receipt and diagnostic. Its separate intentional
  compileLog exit 1 reports body 462, output 553, prefix 51, metrics line 324,
  allowance 1452, and retained 39162. The current code includes paused 2 in
  the maximal metrics example and retains all original contractual size
  assertions: `67*(462+64)+4*(553+64)+1452 = 39162 <= 62144 < 65536`.

## Structural assessment and verification limits

The formatter fix removes the identified duplication rather than redistributing it.
The formatter is reduced from 140 to 64 lines, and the explicit 30-line catalog
owns shared dispatch/schema selection. Ownership of the 67 records, two slots,
producer contexts and file observer is unchanged. The fix does not create a
file-size or branching-growth concern under the requested structural lens.
The tool boundary remains incomplete because N1 repeats the original helper
defect in newly authored orchestration scripts outside the covered inventory.

No tests, imports of reviewed code, compiler commands, native binaries,
constructors, sockets/TLS, descriptor/kernel/resource/fault/cancel/schedule/race/
panic/leak operations, Git commands or subagents were run by this reviewer.
Only this report was written. Existing passes were inspected, not rerun.

The metrics RED proof source was not separately frozen; its diagnostic and
command are retained, and the report explicitly states that provenance limit.
The current source and all four current proof scenarios are covered by the
final frozen compilation and independent model audit. The original preparation
orchestration refusal-ordering coverage limitation remains a separate,
nonblocking observation from the initial review; it is not reopened here.
Runtime wire behavior, lifecycle execution, cleanup, combined40 and broader
project gates remain outside this compile-only preparation review.
