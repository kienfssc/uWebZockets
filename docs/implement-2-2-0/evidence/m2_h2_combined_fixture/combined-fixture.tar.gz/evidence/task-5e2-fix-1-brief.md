# Task5e2 fix round1 of5

Same current replacement implementer resumes. Read task-5e2-review.md in full:
R1/R2/R3 are the blocking findings, copied verbatim there. Root accepts their
concrete source/model/import/structural defects; none is waived. Original/resume
requirements and pure/compile-only/no-native boundary remain unchanged. R4 is a
nonblocking hygiene observation recorded separately; inexpensive cleanup while
already touching this source is allowed, without turning it into another gate.

Ownership stays new combined-fixture, new task5e2 /tmp paths and append same
task-5e2-report.md. You are not alone; preserve all old source/evidence/model and
Root edits. No agents/commits/pushes/ref/pin/product/model edits or external CLI.
Do not rewrite immutable Final1, Bounds1, failed/intermediate attempts or old
probe helper. Freeze new corrected source/helper versions with new receipts.

R1: Emit exact approved model metrics (plural begins/ends/cancels/failures, bytes,
paused and all other required counters/flags). Aggregate actual record.paused;
don't fabricate a client default or weaken the model. Add meaningful failing-
before/passing-after pure/comptime comparisons for idle, selected terminal totals
and active shutdown before/after. Exercise actual aggregation and formatter,
not only manually populated expected literal metrics. Preserve independent
reviewed model as the oracle and every family callback/self-check.

R2: New guarded supplemental bound helper, explicit main, immutable definitions
only at import. Include it in AST/inert proof under empty/foreign argv, with
visible caller-owned doubles preventing filesystem/compiler side effects in the
behavioral RED. Preserve the original Bounds1 helper and receipt as history.
No fixture/server/native constructor/SSLContext/socket/descriptor/kernel/resource/
error/fault/cancel/schedule/race/panic/leak probe is allowed by this test. Normal
compiler diagnostics and the pure compileLog bound observation remain permitted.

R3: Serialize the common body schema once; append only named required extra-field
groups. Replace identical family serializers and67forwarding branches with one
bounded authoritative tag/family/schema mapping. Keep data/type contracts flat,
explicit and named; no reflection framework/anytype/general JSON framework or
mechanical file splitting. Preserve all67 exact keys/types/defaults/hashes and
rejection of unknown tags, zero hot-path allocation, stable views and old guards.
Keep independent literal schema proof and actual formatter/log bounds. Metrics
fix and refactoring must not remove existing source predicates/counter checks.

Covering checks: new metrics/probe-import regressions, existing test_prepare.py
and check_structure.py normal and-O with pinnedPython -B -S, focused pure/schema/
formatter compile-time proof, and final formatting check. Capture exact actual
behavioral RED/GREEN commands/standard streams/exits as separate versioned result
files, beyond report excerpts, so the fix has direct behavioral proof rather than
the initial missing-module diagnostic alone. No passing unrelated component reruns.

After all edits/cleanup, new actual Debug and ReleaseSafe compile-only commands
on the same final immutable snapshot, controlled LC_ALL-only env, all12 original
inputs/1031candidate/93override and retained source maps unchanged. Preserve exact
argv/cwd/env hashes/stdout/stderr/exits/artifact identities and all failed attempts.
Refresh actual bound values using a corrected guarded helper and separately
retained intentional compileLog exit1; successful fixture builds remain separate.
Neither binary is authorized to execute. No native/full40/project gate claim.

Append complete fix report to same task-5e2-report.md with APIs/mapping/aggregation/
proof changes, exact commands/raw results/new identities/self-review and limits.
Root reads actual diff/report/evidence before original reviewer's fix-only re-review.
