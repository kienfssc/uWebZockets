const profile = @import("profile.zig");
const bounds = @import("log_bounds.zig");
comptime { @compileLog(bounds.prove(profile.config)); }
pub fn main() void {}
