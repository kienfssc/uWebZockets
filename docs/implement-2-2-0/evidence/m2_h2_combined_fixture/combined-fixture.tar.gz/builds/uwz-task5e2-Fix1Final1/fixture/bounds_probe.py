"""Compile the actual formatter bound proof and retain its diagnostic."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}


def main(args):
    if len(args) != 2 or not all(name.isascii() and name.isalnum() for name in args):
        raise ValueError('source and new attempt names required')
    source = Path('/tmp/uwz-task5e2-' + args[0])
    base = Path('/tmp/uwz-task5e2-' + args[1])
    receipt = json.loads((source / 'debug-receipt.json').read_text())
    if receipt['exit_status'] != 0:
        raise ValueError('source compile was unsuccessful')
    base.mkdir(exist_ok=False)
    fixture = base / 'fixture'
    shutil.copytree(source / 'fixture', fixture)
    fixture.chmod(0o755)
    (fixture / 'bounds_probe.zig').write_text('const profile = @import("profile.zig");\nconst bounds = @import("log_bounds.zig");\ncomptime { @compileLog(bounds.prove(profile.config)); }\npub fn main() void {}\n')
    argv = receipt['argv'][:]
    for index, arg in enumerate(argv):
        if arg.startswith('-Mroot='):
            argv[index] = '-Mroot=' + str(fixture / 'bounds_probe.zig')
        elif arg == '--cache-dir':
            argv[index + 1] = str(base / 'cache')
        elif arg == '--global-cache-dir':
            argv[index + 1] = str(base / 'global')
        elif arg.startswith('-femit-bin='):
            argv[index] = '-fno-emit-bin'
    before = tree(fixture)
    inputs_before = {p: digest(Path(p)) for p in receipt['inputs_before']}
    proc = subprocess.run(argv, cwd=receipt['cwd'], env={'LC_ALL': 'C.UTF-8'}, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (base / 'stdout').write_bytes(proc.stdout)
    (base / 'stderr').write_bytes(proc.stderr)
    result = {'argv': argv, 'cwd': receipt['cwd'], 'environment': {'LC_ALL': 'C.UTF-8'}, 'exit_status': proc.returncode, 'fixture_before': before, 'fixture_after': tree(fixture), 'inputs_before': inputs_before, 'inputs_after': {p: digest(Path(p)) for p in inputs_before}, 'stdout_sha256': hashlib.sha256(proc.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(proc.stderr).hexdigest(), 'execution': 'compile only; compileLog intentionally reports values as a compiler error; no binary execution'}
    (base / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print('bounds compile exit=' + str(proc.returncode))


if __name__ == '__main__':
    main(sys.argv[1:])
