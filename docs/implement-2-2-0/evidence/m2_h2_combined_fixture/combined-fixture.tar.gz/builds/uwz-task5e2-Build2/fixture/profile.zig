const std = @import("std");
const uz = @import("uWebZockets");
const shared = @import("shared.zig");
const formatting = @import("formatting.zig");
const output_state = @import("output.zig");
const file_observer = @import("file_observer.zig");
const log_bounds = @import("log_bounds.zig");
const tags = @import("tags.zig").tags;
const core = @import("core.zig");
const pause = @import("pause.zig");
const admission = @import("admission.zig");
const credit = @import("credit.zig");
const metadata = @import("metadata.zig");
const cancellation = @import("cancellation.zig");
const application = @import("application.zig");
const lifecycle = @import("lifecycle.zig");
const output_body = @import("output_body.zig");
pub const config: uz.ServerConfig = .{
    .max_connections = 8,
    .stream_request_bodies = true,
    .max_request_line_size = 512,
    .max_header_size = 4096,
    .max_header_count = 80,
    .max_body_size = 256,
    .max_h2_body_size = 4096,
    .max_h2_header_block_size = 8192,
    .max_h2_response_header_size = 4096,
    .max_h2_response_header_count = 32,
    .max_route_params = 24,
    .write_queue_size = 65536,
    .enable_dev_log = false,
};
const Fixture = struct {
    records: [67]shared.Record = [_]shared.Record{.{}} ** 67,
    slots: [2]shared.Slot = .{ .{ .number = 0 }, .{ .number = 1 } },
    families: [9]shared.State = undefined,
    producers: [3]output_state.Producer = [_]output_state.Producer{.{}} ** 3,
    file: file_observer.State = .{},
    reuse_admitted: bool = false,
    buffered_middleware: u32 = 0,
    errors: u32 = 0,
};
fn initialize(fixture: *Fixture) void {
    fixture.families[0] = .{ .family = .core, .slots = &fixture.slots, .records = fixture.records[0..2], .producers = &fixture.producers, .file = &fixture.file, .reuse_admitted = &fixture.reuse_admitted };
    fixture.families[1] = .{ .family = .pause, .slots = &fixture.slots, .records = fixture.records[2..7], .producers = &fixture.producers, .file = &fixture.file, .reuse_admitted = &fixture.reuse_admitted };
    fixture.families[2] = .{ .family = .admission, .slots = &fixture.slots, .records = fixture.records[7..29], .producers = &fixture.producers, .file = &fixture.file, .reuse_admitted = &fixture.reuse_admitted };
    fixture.families[3] = .{ .family = .credit, .slots = &fixture.slots, .records = fixture.records[29..35], .producers = &fixture.producers, .file = &fixture.file, .reuse_admitted = &fixture.reuse_admitted };
    fixture.families[4] = .{ .family = .metadata, .slots = &fixture.slots, .records = fixture.records[35..36], .producers = &fixture.producers, .file = &fixture.file, .reuse_admitted = &fixture.reuse_admitted };
    fixture.families[5] = .{ .family = .cancellation, .slots = &fixture.slots, .records = fixture.records[36..42], .producers = &fixture.producers, .file = &fixture.file, .reuse_admitted = &fixture.reuse_admitted };
    fixture.families[6] = .{ .family = .application, .slots = &fixture.slots, .records = fixture.records[42..48], .producers = &fixture.producers, .file = &fixture.file, .reuse_admitted = &fixture.reuse_admitted };
    fixture.families[7] = .{ .family = .lifecycle, .slots = &fixture.slots, .records = fixture.records[48..60], .producers = &fixture.producers, .file = &fixture.file, .reuse_admitted = &fixture.reuse_admitted };
    fixture.families[8] = .{ .family = .output_body, .slots = &fixture.slots, .records = fixture.records[60..67], .producers = &fixture.producers, .file = &fixture.file, .reuse_admitted = &fixture.reuse_admitted };
}
fn tag_index(tag: []const u8) ?usize {
    for (tags, 0..) |value, index| if (std.mem.eql(u8, tag, value)) return index;
    return null;
}
fn family_for(fixture: *Fixture, index: usize) *shared.State {
    if (index < 2) return &fixture.families[0];
    if (index < 7) return &fixture.families[1];
    if (index < 29) return &fixture.families[2];
    if (index < 35) return &fixture.families[3];
    if (index < 36) return &fixture.families[4];
    if (index < 42) return &fixture.families[5];
    if (index < 48) return &fixture.families[6];
    if (index < 60) return &fixture.families[7];
    return &fixture.families[8];
}
fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag");
    const body_route = std.mem.startsWith(u8, request.path, "/upload/") or std.mem.startsWith(u8, request.path, "/limit/") or std.mem.startsWith(u8, request.path, "/empty/") or std.mem.startsWith(u8, request.path, "/meta/");
    if (!body_route) {
        fixture.buffered_middleware += 1;
        response.append_header("X-Middleware", "retained") catch {
            fixture.errors += 1;
            return .stop;
        };
        return .continue_dispatch;
    }
    const index = tag_index(tag orelse {
        fixture.errors += 1;
        return .stop;
    }) orelse {
        fixture.errors += 1;
        return .stop;
    };
    const state = family_for(fixture, index);
    switch (state.family) {
        .core, .pause => {
            fixture.records[index].middleware += 1;
            response.append_header("X-Middleware", "retained") catch {
                fixture.errors += 1;
                return .stop;
            };
            return .continue_dispatch;
        },
        .admission => return admission.middleware(state, request, response),
        .credit => return credit.middleware(state, request, response),
        .metadata => return metadata.middleware(state, request, response),
        .cancellation => return cancellation.middleware(state, request, response),
        .application => return application.middleware(state, request, response),
        .lifecycle => return lifecycle.middleware(state, request, response),
        .output_body => return output_body.middleware(state, request, response),
    }
}
fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    const index = tag_index(request.params.get("tag") orelse return error.MissingTag) orelse return error.InvalidTag;
    const state = family_for(fixture, index);
    return switch (state.family) {
        .core => core.begin(state, request, token),
        .pause => pause.begin(state, request, token),
        .admission => admission.begin(state, request, token),
        .credit => credit.begin(state, request, token),
        .metadata => metadata.begin(state, request, token),
        .cancellation => cancellation.begin(state, request, token),
        .application => application.begin(state, request, token),
        .lifecycle => lifecycle.begin(state, request, token),
        .output_body => output_body.begin(state, request, token),
    };
}
fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *shared.Slot = @ptrCast(@alignCast(context));
    return switch (slot.owner.family) {
        .core => core.chunk(context, input),
        .pause => pause.chunk(context, input),
        .admission => admission.chunk(context, input),
        .credit => credit.chunk(context, input),
        .metadata => metadata.chunk(context, input),
        .cancellation => cancellation.chunk(context, input),
        .application => application.chunk(context, input),
        .lifecycle => lifecycle.chunk(context, input),
        .output_body => output_body.chunk(context, input),
    };
}
fn end(context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *shared.Slot = @ptrCast(@alignCast(context));
    return switch (slot.owner.family) {
        .core => core.end(context, request, response),
        .pause => pause.end(context, request, response),
        .admission => admission.end(context, request, response),
        .credit => credit.end(context, request, response),
        .metadata => metadata.end(context, request, response),
        .cancellation => cancellation.end(context, request, response),
        .application => application.end(context, request, response),
        .lifecycle => lifecycle.end(context, request, response),
        .output_body => output_body.end(context, request, response),
    };
}
fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *shared.Slot = @ptrCast(@alignCast(context));
    return switch (slot.owner.family) {
        .core => core.cancel(context, reason),
        .pause => pause.cancel(context, reason),
        .admission => admission.cancel(context, reason),
        .credit => credit.cancel(context, reason),
        .metadata => metadata.cancel(context, reason),
        .cancellation => cancellation.cancel(context, reason),
        .application => application.cancel(context, reason),
        .lifecycle => lifecycle.cancel(context, reason),
        .output_body => output_body.cancel(context, reason),
    };
}
fn health(_: *uz.Request, response: *uz.Response) void {
    response.text("ok") catch |err| std.log.err("health: {}", .{err});
}
fn echo(request: *uz.Request, response: *uz.Response) void {
    response.bytes(request.bytes()) catch |err| std.log.err("echo: {}", .{err});
}
fn delayed(_: *uz.Request, token: uz.AsyncResponse) void {
    token.sleep_complete(10, "200 OK", "Content-Type: text/plain\r\n", "delayed-ok") catch |err| std.log.err("delayed: {}", .{err});
}
fn status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    const index = tag_index(request.get_param("tag") orelse {
        fixture.errors += 1;
        return;
    }) orelse {
        fixture.errors += 1;
        return;
    };
    var buffer: [768]u8 = undefined;
    const body = formatting.format_record(&fixture.records[index], tags[index], &buffer) catch {
        fixture.errors += 1;
        return;
    };
    response.text(body) catch {
        fixture.errors += 1;
    };
}
fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    const index = tag_index(request.get_param("tag") orelse {
        fixture.errors += 1;
        return;
    }) orelse {
        fixture.errors += 1;
        return;
    };
    const state = family_for(fixture, index);
    switch (state.family) {
        .core => {
            fixture.errors += 1;
        },
        .pause => pause.control(state, request, response),
        .admission => admission.control(state, request, response),
        .credit => credit.control(state, request, response),
        .metadata => metadata.control(state, request, response),
        .cancellation => cancellation.control(state, request, response),
        .application => application.control(state, request, response),
        .lifecycle => lifecycle.control(state, request, response),
        .output_body => output_body.control(state, request, response),
    }
}
fn output_status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    output_body.output_status(&fixture.families[8], request, response);
}
fn format_totals(fixture: *const Fixture, buffer: []u8) ![]const u8 {
    var totals: formatting.Totals = .{ .errors = fixture.errors, .buffered_middleware = fixture.buffered_middleware, .slot0_active = fixture.slots[0].record != null, .slot1_active = fixture.slots[1].record != null };
    for (fixture.families) |state| totals.errors += state.errors + state.failed;
    for (fixture.records) |record| formatting.add_record(&totals, &record);
    return formatting.format_totals(totals, buffer);
}
fn metrics(context: *anyopaque, _: *uz.Request, response: *uz.Response) void {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    var buffer: [1024]u8 = undefined;
    const body = format_totals(fixture, &buffer) catch {
        fixture.errors += 1;
        return;
    };
    response.text(body) catch {
        fixture.errors += 1;
    };
}
pub fn main(init: std.process.Init) !void {
    comptime log_bounds.prove(config);
    comptime @import("schema_proof.zig").prove();
    const nonce = init.environ_map.get("H2_PROFILE_NONCE") orelse return error.MissingNonce;
    try log_bounds.validate_nonce(nonce);
    const certificate = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_CERT") orelse return error.MissingCertificate);
    const key = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_KEY") orelse return error.MissingKey);
    var fixture: Fixture = .{};
    initialize(&fixture);
    defer file_observer.cleanup(&fixture.file);
    try file_observer.setup(&fixture.file, init.io, init.environ_map.get("H2_PROFILE_FILE") orelse return error.MissingFilePath);
    const sink: uz.BodySink = .{ .context = &fixture, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel };
    var upload: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 100000000, .max_active = 2 }, .middleware_policy = .headers_only };
    var limit: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 32, .max_active = 1 }, .middleware_policy = .headers_only };
    var empty: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 0, .max_active = 1 }, .middleware_policy = .headers_only };
    {
        var server = try uz.Server.preset(init.io, config).build_https(init.arena.allocator(), certificate, key);
        defer server.deinit();
        _ = try server.use(&fixture, middleware);
        _ = try server.route_body(.post, "/upload/:tag", &upload);
        _ = try server.route_body(.post, "/limit/:tag", &limit);
        _ = try server.route_body(.post, "/empty/:tag", &empty);
        _ = try server.route_body(.post, "/meta/:tag/:p01/:p02/:p03/:p04/:p05/:p06/:p07/:p08/:p09/:p10/:p11/:p12/:p13/:p14/:p15/:p16", &upload);
        _ = try server.get("/health", health);
        _ = try server.post("/echo", echo);
        _ = try server.get_async("/delayed", delayed);
        _ = try server.get_context("/status/:tag", &fixture, status);
        _ = try server.get_context("/metrics", &fixture, metrics);
        _ = try server.get_context("/resume/:tag", &fixture, resume_body);
        _ = try server.get_context("/control/:op/:tag", &fixture, control);
        _ = try server.get_context("/output/:tag", &fixture, output_status);
        std.log.info(log_bounds.capacity_format, .{ std.json.fmt(config, .{}), try config.request_buffer_stride(), try config.h2_session_bytes(), try config.h2_session_stride(), try config.slab_bytes(), try config.router_storage_bytes() });
        try server.listen("127.0.0.1", 28443);
        try server.catch_shutdown_signals();
        std.log.info("H2_READY {s}", .{nonce});
        try server.run();
    }
    const binding = fixture.families[8].records[1];
    std.log.info("H2_BINDING {s} tag=producer_reuse_next index={d} generation={d}", .{ nonce, binding.binding_index, binding.binding_generation });
    for (&fixture.records, 0..) |*record, index| {
        var buffer: [768]u8 = undefined;
        std.log.info("H2_RECORD {s} {s}", .{ nonce, try formatting.format_record(record, tags[index], &buffer) });
    }
    for (&fixture.producers, [_][]const u8{ "producer_reuse", "output_pressure_window", "output_pressure_ready" }) |*producer, tag| {
        var buffer: [1024]u8 = undefined;
        std.log.info("H2_OUTPUT {s} {s}", .{ nonce, try output_state.format(producer, tag, &buffer) });
    }
    var buffer: [1024]u8 = undefined;
    std.log.info("H2_OUTPUT {s} {s}", .{ nonce, try file_observer.format(&fixture.file, &buffer) });
    std.log.info("H2_DEINIT {s} {s}", .{ nonce, try format_totals(&fixture, &buffer) });
}
fn resume_body(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    const index = tag_index(request.get_param("tag") orelse {
        fixture.errors += 1;
        return;
    }) orelse {
        fixture.errors += 1;
        return;
    };
    const state = family_for(fixture, index);
    switch (state.family) {
        .admission => admission.control(state, request, response),
        .credit => credit.control(state, request, response),
        .metadata => metadata.control(state, request, response),
        else => {
            fixture.errors += 1;
        },
    }
}
