const std = @import("std");
const uz = @import("uWebZockets");
const shared = @import("shared.zig");
const Record = shared.Record;
const Slot = shared.Slot;
const State = shared.State;
const Hash = std.crypto.hash.sha2.Sha256;
const format_record = @import("formatting.zig").format_record;
const file_observer = @import("file_observer.zig");
pub const tags = [_][]const u8{ "disconnect", "disconnect_recovery", "reuse_0", "reuse_1", "reuse_2", "reuse_3", "reuse_4", "reuse_5", "reuse_6", "reuse_7", "reuse_8", "shutdown_active" };
pub fn tag_index(tag: []const u8) ?usize {
    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
    return null;
}
fn equal(actual: ?[]const u8, expected: []const u8) bool {
    return if (actual) |value| std.mem.eql(u8, value, expected) else false;
}
const ExpectedMetadata = struct { path: []const u8, query: []const u8, target: []const u8, header: []const u8 };
const expected_metadata = [_]ExpectedMetadata{
    .{ .path = "/limit/disconnect", .query = "case=disconnect", .target = "/limit/disconnect?case=disconnect", .header = "disconnect" },
    .{ .path = "/limit/disconnect_recovery", .query = "case=disconnect_recovery", .target = "/limit/disconnect_recovery?case=disconnect_recovery", .header = "disconnect_recovery" },
    .{ .path = "/limit/reuse_0", .query = "case=reuse_0", .target = "/limit/reuse_0?case=reuse_0", .header = "reuse_0" },
    .{ .path = "/limit/reuse_1", .query = "case=reuse_1", .target = "/limit/reuse_1?case=reuse_1", .header = "reuse_1" },
    .{ .path = "/limit/reuse_2", .query = "case=reuse_2", .target = "/limit/reuse_2?case=reuse_2", .header = "reuse_2" },
    .{ .path = "/limit/reuse_3", .query = "case=reuse_3", .target = "/limit/reuse_3?case=reuse_3", .header = "reuse_3" },
    .{ .path = "/limit/reuse_4", .query = "case=reuse_4", .target = "/limit/reuse_4?case=reuse_4", .header = "reuse_4" },
    .{ .path = "/limit/reuse_5", .query = "case=reuse_5", .target = "/limit/reuse_5?case=reuse_5", .header = "reuse_5" },
    .{ .path = "/limit/reuse_6", .query = "case=reuse_6", .target = "/limit/reuse_6?case=reuse_6", .header = "reuse_6" },
    .{ .path = "/limit/reuse_7", .query = "case=reuse_7", .target = "/limit/reuse_7?case=reuse_7", .header = "reuse_7" },
    .{ .path = "/limit/reuse_8", .query = "case=reuse_8", .target = "/limit/reuse_8?case=reuse_8", .header = "reuse_8" },
    .{ .path = "/limit/shutdown_active", .query = "case=shutdown_active", .target = "/limit/shutdown_active?case=shutdown_active", .header = "shutdown_active" },
};
fn metadata_matches(request: *const uz.StreamingRequest, index: usize) bool {
    if (index >= expected_metadata.len) return false;
    const expected = expected_metadata[index];
    return std.mem.eql(u8, request.method, "POST") and std.mem.eql(u8, request.path, expected.path) and
        std.mem.eql(u8, request.query, expected.query) and std.mem.eql(u8, request.target, expected.target) and
        equal(request.params.get("tag"), tags[index]) and equal(request.headers.get("x-case"), expected.header) and
        equal(request.headers.get("content-length"), "32");
}
pub fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
    const state: *State = @ptrCast(@alignCast(context));
    if (std.mem.startsWith(u8, request.path, "/limit/")) {
        const tag = request.get_param("tag") orelse {
            state.errors += 1;
            return .stop;
        };
        const index = tag_index(tag) orelse {
            state.errors += 1;
            return .stop;
        };
        if (index >= 12) {
            state.errors += 1;
            return .stop;
        }
        const record = &state.records[index];
        record.middleware += 1;
        if (metadata_matches(&uz.StreamingRequest.from_request(request), index)) {
            record.metadata_middleware += 1;
        } else record.errors += 1;
    } else state.buffered_middleware += 1;
    response.append_header("X-Middleware", "retained") catch {
        state.errors += 1;
        return .stop;
    };
    return .continue_dispatch;
}
pub fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.params.get("tag") orelse return error.MissingTag;
    const index = tag_index(tag) orelse return error.InvalidTag;
    if (index >= 12) return error.SpareTag;
    const record = &state.records[index];
    record.attempts += 1;
    if (record.attempts != 1 or record.middleware != 1 or !metadata_matches(request, index)) {
        record.errors += 1;
        record.failures += 1;
        return error.InvalidRequest;
    }
    record.metadata_begin += 1;
    for (state.slots) |*slot| {
        if (slot.record != null) continue;
        slot.generation += 1;
        slot.owner = state;
        slot.record = record;
        slot.index = index;
        record.token = token;
        record.begins += 1;
        record.active = true;
        return .{ .context = slot, .readiness = .ready };
    }
    record.failures += 1;
    record.errors += 1;
    return error.NoFixtureSlot;
}
pub fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.max_span = @max(record.max_span, input.len);
    record.chunks += 1;
    if ((slot.index == 0 or slot.index == 11) and record.bytes < 7) {
        const accepted: usize = @min(input.len, 7 - @as(usize, @intCast(record.bytes)));
        record.hash.update(input[0..accepted]);
        record.bytes += accepted;
        if (record.bytes == 7) {
            record.paused = true;
            return .{ .consumed = accepted, .readiness = .paused };
        }
        return .{ .consumed = accepted, .readiness = .ready };
    }
    record.hash.update(input);
    record.bytes += input.len;
    return .{ .consumed = input.len, .readiness = .ready };
}
pub fn end(context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.ends += 1;
    if (!metadata_matches(request, slot.index)) {
        record.errors += 1;
        record.end_errors += 1;
        record.active = false;
        record.paused = false;
        slot.record = null;
        return error.MetadataMismatch;
    }
    record.metadata_end += 1;
    var hash_copy = record.hash;
    var digest: [Hash.digest_length]u8 = undefined;
    hash_copy.final(&digest);
    const expected = [_]u8{ 0x7f, 0x0c, 0x58, 0x81, 0xa9, 0xae, 0x26, 0x83, 0xde, 0xbb, 0xa0, 0x16, 0xa4, 0x78, 0x6b, 0x6c, 0x08, 0xdc, 0x68, 0x4c, 0x5a, 0x33, 0x4f, 0xa0, 0xb9, 0x87, 0x6e, 0x6e, 0x32, 0xc3, 0x90, 0xb5 };
    if (record.bytes != 32 or !std.mem.eql(u8, &digest, &expected)) {
        record.errors += 1;
        record.end_errors += 1;
        record.active = false;
        record.paused = false;
        slot.record = null;
        return error.InvalidBody;
    }
    record.active = false;
    record.paused = false;
    slot.record = null;
    var output: [1024]u8 = undefined;
    const body = format_record(record, tags[slot.index], &output) catch |err| {
        record.end_errors += 1;
        return err;
    };
    response.text(body) catch |err| {
        record.end_errors += 1;
        return err;
    };
}
pub fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse {
        slot.owner.errors += 1;
        return;
    };
    record.cancels += 1;
    record.reason = reason;
    record.active = false;
    record.paused = false;
    slot.record = null;
}
pub fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    const record = &state.records[index];
    const token = record.token orelse {
        state.errors += 1;
        return;
    };
    const operation = request.get_param("op") orelse {
        state.errors += 1;
        return;
    };
    if (record.active) {
        state.errors += 1;
        return;
    }
    if (std.mem.eql(u8, operation, "resume")) {
        if (token.@"resume"()) |_| {
            state.errors += 1;
            return;
        } else |err| {
            if (err != error.BodyControlExpired) {
                state.errors += 1;
                return;
            }
        }
        record.stale_resume += 1;
    } else if (std.mem.eql(u8, operation, "cancel")) {
        if (token.cancel()) |_| {
            state.errors += 1;
            return;
        } else |err| {
            if (err != error.BodyControlExpired) {
                state.errors += 1;
                return;
            }
        }
        record.stale_cancel += 1;
    } else {
        state.errors += 1;
        return;
    }
    response.text("BodyControlExpired") catch {
        state.errors += 1;
    };
}
