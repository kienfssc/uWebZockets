const std = @import("std");
const uz = @import("uWebZockets");
const shared = @import("shared.zig");
const Record = shared.Record;
const Slot = shared.Slot;
const State = shared.State;
const Hash = std.crypto.hash.sha2.Sha256;
const format_record = @import("formatting.zig").format_record;
const file_observer = @import("file_observer.zig");
pub const tags = [_][]const u8{ "empty_headers", "empty_data", "empty_declared", "limit_declared", "limit_undeclared", "limit_declared_reject", "limit_declared_recovery", "limit_observed_reject", "limit_observed_recovery", "zero_declared_reject", "zero_declared_recovery", "zero_observed_reject", "zero_observed_recovery", "continue_ready", "continue_paused", "quota_holder_one", "quota_holder_two", "quota_refuse", "quota_recovery_one", "quota_recovery_two", "begin_failure", "begin_recovery" };
pub fn tag_index(tag: []const u8) ?usize {
    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
    return null;
}
fn account_body_head(state: *State, request: *const uz.Request) void {
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    if (index >= 22) {
        state.errors += 1;
        return;
    }
    state.records[index].middleware += 1;
}
pub fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
    const state: *State = @ptrCast(@alignCast(context));
    if (std.mem.startsWith(u8, request.path, "/upload/") or std.mem.startsWith(u8, request.path, "/limit/") or std.mem.startsWith(u8, request.path, "/empty/")) {
        account_body_head(state, request);
    } else state.buffered_middleware += 1;
    response.append_header("X-Middleware", "retained") catch {
        state.errors += 1;
        return .stop;
    };
    return .continue_dispatch;
}
pub fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.params.get("tag") orelse {
        state.errors += 1;
        return error.MissingTag;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return error.InvalidTag;
    };
    if (index >= 22) {
        state.errors += 1;
        return error.SpareTag;
    }
    const record = &state.records[index];
    record.attempts += 1;
    if (record.attempts != 1 or record.middleware != 1) {
        record.errors += 1;
        record.failures += 1;
        return error.DuplicateTag;
    }
    if (index == 20) {
        record.failures += 1;
        return error.DeliberateBeginFailure;
    }
    for (state.slots) |*slot| {
        if (slot.record != null) continue;
        slot.generation += 1;
        slot.owner = state;
        slot.record = record;
        slot.index = index;
        record.token = token;
        record.begins += 1;
        record.active = true;
        record.paused = index == 14;
        return .{ .context = slot, .readiness = if (record.paused) .paused else .ready };
    }
    record.failures += 1;
    record.errors += 1;
    return error.NoFixtureSlot;
}
pub fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.max_span = @max(record.max_span, input.len);
    record.chunks += 1;
    record.hash.update(input);
    record.bytes += input.len;
    return .{ .consumed = input.len, .readiness = .ready };
}
pub fn end(context: *anyopaque, _: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.ends += 1;
    record.active = false;
    record.paused = false;
    record.token = null;
    slot.record = null;
    var output: [1024]u8 = undefined;
    try response.text(try format_record(record, tags[slot.index], &output));
}
pub fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse {
        slot.owner.errors += 1;
        return;
    };
    record.cancels += 1;
    record.reason = reason;
    record.active = false;
    record.paused = false;
    record.token = null;
    slot.record = null;
}
pub fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    const token = state.records[index].token orelse {
        state.errors += 1;
        return;
    };
    if (!state.records[index].paused) {
        state.errors += 1;
        return;
    }
    state.records[index].paused = false;
    token.@"resume"() catch {
        state.errors += 1;
        response.text("error") catch {
            state.errors += 1;
        };
        return;
    };
    response.text("ok") catch {
        state.errors += 1;
    };
}
