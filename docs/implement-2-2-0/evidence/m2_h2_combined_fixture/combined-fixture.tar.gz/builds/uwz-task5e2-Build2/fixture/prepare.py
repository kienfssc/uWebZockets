"""Freeze reviewed inputs and compile twice; never execute either binary."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace

ROOT = Path('/workspaces/uWebZockets')
HERE = Path(__file__).parent
SOURCE = Path('/tmp/uwz-task4d-fix1-frozen')
OVERRIDE = Path('/tmp/uwz-reviewed-libxev-c223-loop-callbacks')
RECIPES = ROOT / '.uwz-work/evidence/h2-streaming/integration-owned/metadata'


def bytes_digest(value):
    return hashlib.sha256(value).hexdigest()


def digest(path):
    return bytes_digest(path.read_bytes())


def tree(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}


def tree_hash(mapping):
    return bytes_digest(json.dumps(list(mapping.items())).encode())


def environment():
    return {'LC_ALL': 'C.UTF-8'}


def attempt_path(name):
    if type(name) is not str or not name or not name.isascii() or not name.isalnum():
        raise ValueError('one ASCII alphanumeric attempt name required')
    return Path('/tmp/uwz-task5e2-' + name)


def command(recipe, snapshot, attempt, mode):
    if mode not in ('debug', 'release'):
        raise ValueError('invalid optimization mode')
    result = recipe['argv'][:]
    roots = 0
    for index, arg in enumerate(result):
        if arg.startswith('-Mroot='):
            result[index] = '-Mroot=' + str(snapshot / 'profile.zig')
            roots += 1
        if arg == '--cache-dir':
            result[index + 1] = str(attempt / (mode + '-cache'))
        if arg == '--global-cache-dir':
            result[index + 1] = str(attempt / (mode + '-global'))
        if arg.startswith('-femit-bin='):
            result[index] = '-femit-bin=' + str(attempt / (mode + '-profile'))
    if roots != 1:
        raise ValueError('exactly one root required')
    return result


def check_expected(actual, expected):
    if actual != expected:
        raise ValueError('input identity differs')


def copy_snapshot(owned, snapshot, names, api):
    result = {}
    for name in names:
        source = owned / name
        target = snapshot / name
        before = bytes_digest(api.read(source))
        api.copy(source, target)
        check_expected(bytes_digest(api.read(target)), before)
        api.immutable(target)
        result[name] = before
    return result


def immutable(path):
    path.chmod(0o444)


def retain_attempt(attempt, snapshot, fixture_before, source_before, override_before, recipe, mode):
    argv = command(recipe, snapshot, attempt, mode)
    inputs = {p: digest(Path(p)) for p in recipe['input_sha256'] if not p.endswith('/metadata/profile.zig')}
    expected = {p: h for p, h in recipe['input_sha256'].items() if not p.endswith('/metadata/profile.zig')}
    check_expected(inputs, expected)
    check_expected(tree_hash(source_before), recipe['expected_source_digest'])
    check_expected(override_before, recipe['override_before'])
    env = environment()
    proc = subprocess.run(argv, cwd=SOURCE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    (attempt / (mode + '.stdout')).write_bytes(proc.stdout)
    (attempt / (mode + '.stderr')).write_bytes(proc.stderr)
    after = {p: digest(Path(p)) for p in inputs}
    source_after = tree(SOURCE)
    override_after = tree(OVERRIDE)
    fixture_after = tree(snapshot)
    binary = attempt / (mode + '-profile')
    receipt = dict(argv=argv, cwd=str(SOURCE), optimization=recipe['optimization'], exit_status=proc.returncode,
                   environment=env, environment_sha256=bytes_digest(json.dumps(env,sort_keys=True,separators=(',',':')).encode()),
                   inputs_before=inputs, inputs_after=after, fixture_before=fixture_before, fixture_after=fixture_after,
                   source_before=source_before, source_after=source_after, source_before_sha256=tree_hash(source_before),
                   source_after_sha256=tree_hash(source_after), override_before=override_before, override_after=override_after,
                   binary_sha256=digest(binary) if binary.exists() else None,
                   stdout_sha256=bytes_digest(proc.stdout), stderr_sha256=bytes_digest(proc.stderr),
                   execution='compile only; binary not executed')
    (attempt / (mode + '-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    for actual, expected_value in ((after,inputs),(source_after,source_before),(override_after,override_before),(fixture_after,fixture_before)):
        check_expected(actual,expected_value)
    return proc.returncode


def main(args):
    if len(args) != 1:
        raise ValueError('one attempt name required')
    attempt = attempt_path(args[0])
    attempt.mkdir(exist_ok=False)
    snapshot = attempt / 'fixture'
    snapshot.mkdir()
    names = tuple(p.name for p in sorted(HERE.iterdir()) if p.is_file())
    api = SimpleNamespace(read=Path.read_bytes, copy=shutil.copyfile, immutable=immutable)
    fixture_before = copy_snapshot(HERE,snapshot,names,api)
    snapshot.chmod(0o555)
    source_before = tree(SOURCE)
    override_before = tree(OVERRIDE)
    if len(source_before) != 1031 or len(override_before) != 93:
        raise ValueError('unexpected source inventory')
    for mode, name in (('debug','fixture-debug-final.json'),('release','fixture-release-final.json')):
        recipe = json.loads((RECIPES/name).read_text())
        result = retain_attempt(attempt,snapshot,fixture_before,source_before,override_before,recipe,mode)
        print(mode + ' compile exit=' + str(result),flush=True)
        if result:
            return result
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
