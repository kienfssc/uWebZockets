const std = @import("std");
const shared = @import("shared.zig");
const Hash = std.crypto.hash.sha2.Sha256;
fn format_core(record: *const shared.Record, tag: []const u8, hex: []const u8, reason: []const u8, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"failures\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"errors\":{d},\"tag\":\"{s}\",\"bytes\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":{s}}}", .{ record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.chunk_errors, record.invalid_progress, record.errors, tag, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason });
}
fn format_pause(record: *const shared.Record, tag: []const u8, hex: []const u8, reason: []const u8, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"failures\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"errors\":{d},\"tag\":\"{s}\",\"bytes\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":{s},\"callback_checks\":{d},\"terminal_checks\":{d}}}", .{ record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.chunk_errors, record.invalid_progress, record.errors, tag, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.callback_checks, record.terminal_checks });
}
fn format_admission(record: *const shared.Record, tag: []const u8, hex: []const u8, reason: []const u8, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"failures\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"errors\":{d},\"tag\":\"{s}\",\"bytes\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":{s}}}", .{ record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.chunk_errors, record.invalid_progress, record.errors, tag, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason });
}
fn format_credit(record: *const shared.Record, tag: []const u8, hex: []const u8, reason: []const u8, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"failures\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"errors\":{d},\"tag\":\"{s}\",\"bytes\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":{s},\"metadata_begin\":{d},\"metadata_end\":{d}}}", .{ record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.chunk_errors, record.invalid_progress, record.errors, tag, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.metadata_begin, record.metadata_end });
}
fn format_metadata(record: *const shared.Record, tag: []const u8, hex: []const u8, reason: []const u8, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"failures\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"errors\":{d},\"tag\":\"{s}\",\"bytes\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":{s},\"metadata_middleware\":{d},\"helpers_begin\":{d},\"helpers_end\":{d},\"metadata_begin\":{d},\"metadata_end\":{d}}}", .{ record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.chunk_errors, record.invalid_progress, record.errors, tag, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.metadata_middleware, record.helpers_begin, record.helpers_end, record.metadata_begin, record.metadata_end });
}
fn format_cancellation(record: *const shared.Record, tag: []const u8, hex: []const u8, reason: []const u8, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"failures\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"errors\":{d},\"tag\":\"{s}\",\"bytes\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":{s},\"metadata_middleware\":{d},\"metadata_begin\":{d},\"metadata_end\":{d},\"stale_resume\":{d},\"stale_cancel\":{d}}}", .{ record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.chunk_errors, record.invalid_progress, record.errors, tag, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.metadata_middleware, record.metadata_begin, record.metadata_end, record.stale_resume, record.stale_cancel });
}
fn format_application(record: *const shared.Record, tag: []const u8, hex: []const u8, reason: []const u8, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"failures\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"errors\":{d},\"tag\":\"{s}\",\"bytes\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":{s},\"metadata_middleware\":{d},\"metadata_begin\":{d},\"metadata_end\":{d},\"stale_resume\":{d},\"stale_cancel\":{d}}}", .{ record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.chunk_errors, record.invalid_progress, record.errors, tag, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.metadata_middleware, record.metadata_begin, record.metadata_end, record.stale_resume, record.stale_cancel });
}
fn format_lifecycle(record: *const shared.Record, tag: []const u8, hex: []const u8, reason: []const u8, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"failures\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"errors\":{d},\"tag\":\"{s}\",\"bytes\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":{s},\"metadata_middleware\":{d},\"metadata_begin\":{d},\"metadata_end\":{d},\"stale_resume\":{d},\"stale_cancel\":{d}}}", .{ record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.chunk_errors, record.invalid_progress, record.errors, tag, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.metadata_middleware, record.metadata_begin, record.metadata_end, record.stale_resume, record.stale_cancel });
}
fn format_output(record: *const shared.Record, tag: []const u8, hex: []const u8, reason: []const u8, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"failures\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"errors\":{d},\"tag\":\"{s}\",\"bytes\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":{s},\"metadata_middleware\":{d},\"metadata_begin\":{d},\"metadata_end\":{d},\"stale_resume\":{d},\"stale_cancel\":{d}}}", .{ record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.chunk_errors, record.invalid_progress, record.errors, tag, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.metadata_middleware, record.metadata_begin, record.metadata_end, record.stale_resume, record.stale_cancel });
}
pub fn format_record(record: *const shared.Record, tag: []const u8, output: []u8) ![]const u8 {
    var hash = record.hash;
    var digest: [32]u8 = undefined;
    hash.final(&digest);
    const hex = std.fmt.bytesToHex(digest, .lower);
    const reason = if (record.reason) |value| switch (value) {
        inline else => "\"" ++ @tagName(value) ++ "\"",
    } else "null";
    if (std.mem.eql(u8, tag, "large_declared")) return format_core(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "large_undeclared")) return format_core(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "partial_pause")) return format_pause(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "final_pause")) return format_pause(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "begin_pause_empty")) return format_pause(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "control_one")) return format_pause(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "control_two")) return format_pause(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "empty_headers")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "empty_data")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "empty_declared")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "limit_declared")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "limit_undeclared")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "limit_declared_reject")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "limit_declared_recovery")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "limit_observed_reject")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "limit_observed_recovery")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "zero_declared_reject")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "zero_declared_recovery")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "zero_observed_reject")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "zero_observed_recovery")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "continue_ready")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "continue_paused")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "quota_holder_one")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "quota_holder_two")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "quota_refuse")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "quota_recovery_one")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "quota_recovery_two")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "begin_failure")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "begin_recovery")) return format_admission(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "queued_trailers_padding")) return format_credit(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "receive_credit")) return format_credit(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "concurrent_hold")) return format_credit(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "concurrent_refused")) return format_credit(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "concurrent_upload")) return format_credit(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "concurrent_recovery")) return format_credit(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "metadata_helpers")) return format_metadata(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "cancel_ready")) return format_cancellation(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "cancel_ready_recovery")) return format_cancellation(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "cancel_paused")) return format_cancellation(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "cancel_paused_recovery")) return format_cancellation(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "peer_reset")) return format_cancellation(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "peer_reset_recovery")) return format_cancellation(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "sink_error")) return format_application(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "sink_error_recovery")) return format_application(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "invalid_progress")) return format_application(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "invalid_progress_recovery")) return format_application(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "end_error")) return format_application(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "end_error_recovery")) return format_application(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "disconnect")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "disconnect_recovery")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "reuse_0")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "reuse_1")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "reuse_2")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "reuse_3")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "reuse_4")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "reuse_5")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "reuse_6")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "reuse_7")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "reuse_8")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "shutdown_active")) return format_lifecycle(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "producer_reuse")) return format_output(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "producer_reuse_next")) return format_output(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "output_pressure_window")) return format_output(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "output_pressure_ready")) return format_output(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "stream_file")) return format_output(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "early_final_order")) return format_output(record, tag, &hex, reason, output);
    if (std.mem.eql(u8, tag, "early_final_recovery")) return format_output(record, tag, &hex, reason, output);
    return error.InvalidTag;
}
pub const Totals = struct {
    middleware: u64 = 0,
    attempts: u64 = 0,
    begins: u64 = 0,
    ends: u64 = 0,
    cancels: u64 = 0,
    failures: u64 = 0,
    end_errors: u64 = 0,
    chunk_errors: u64 = 0,
    invalid_progress: u64 = 0,
    accepted: u64 = 0,
    active: u64 = 0,
    errors: u64 = 0,
    buffered_middleware: u64 = 0,
    slot0_active: bool = false,
    slot1_active: bool = false,
};
pub fn add_record(totals: *Totals, record: *const shared.Record) void {
    totals.middleware += record.middleware;
    totals.attempts += record.attempts;
    totals.begins += record.begins;
    totals.ends += record.ends;
    totals.cancels += record.cancels;
    totals.failures += record.failures;
    totals.end_errors += record.end_errors;
    totals.chunk_errors += record.chunk_errors;
    totals.invalid_progress += record.invalid_progress;
    totals.errors += record.errors;
    totals.accepted += record.bytes;
    totals.active += @intFromBool(record.active);
}
pub fn format_totals(totals: Totals, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"accepted\":{d},\"active\":{d},\"errors\":{d},\"buffered_middleware\":{d},\"slot0_active\":{any},\"slot1_active\":{any}}}", .{ totals.middleware, totals.attempts, totals.begins, totals.ends, totals.cancels, totals.failures, totals.end_errors, totals.chunk_errors, totals.invalid_progress, totals.accepted, totals.active, totals.errors, totals.buffered_middleware, totals.slot0_active, totals.slot1_active });
}
