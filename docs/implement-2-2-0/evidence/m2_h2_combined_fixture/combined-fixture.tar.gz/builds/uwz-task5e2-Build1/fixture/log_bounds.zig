const std = @import("std");
const uz = @import("uWebZockets");
const shared = @import("shared.zig");
const formatting = @import("formatting.zig");
const output = @import("output.zig");
const file_observer = @import("file_observer.zig");
const tags = @import("tags.zig").tags;
pub const capacity_format = "H2_CAPACITY config={f} request_stride={d} h2_bytes={d} h2_stride={d} slab={d} router={d}";
pub const nonce_limit = 32;
pub fn validate_nonce(nonce: []const u8) !void {
    if (nonce.len == 0 or nonce.len > nonce_limit) return error.InvalidNonce;
    for (nonce) |byte| if (!std.ascii.isAlphanumeric(byte) and byte != '_') return error.InvalidNonce;
}
fn require(condition: bool, comptime message: []const u8) void {
    if (!condition) @compileError(message);
}
pub fn prove(comptime config: uz.ServerConfig) void {
    @setEvalBranchQuota(2000000);
    var body_buffer: [768]u8 = undefined;
    var record: shared.Record = .{
        .bytes = 100000000,
        .chunks = 100000001,
        .max_span = 8192,
        .middleware = 1,
        .attempts = 1,
        .begins = 1,
        .ends = 1,
        .cancels = 1,
        .failures = 1,
        .end_errors = 1,
        .chunk_errors = 1,
        .invalid_progress = 1,
        .errors = std.math.maxInt(u32),
        .metadata_middleware = 1,
        .metadata_begin = 1,
        .metadata_end = 1,
        .helpers_begin = 1,
        .helpers_end = 1,
        .stale_resume = 36,
        .stale_cancel = 36,
        .callback_checks = 200000004,
        .terminal_checks = 2,
    };
    var longest_body: usize = 0;
    const reasons = [_]?uz.BodyCancelReason{ null, .body_too_large, .cancelled, .reset, .sink_failure, .peer_closed, .shutdown };
    for (tags) |tag| {
        for (reasons) |reason| {
            record.reason = reason;
            const value = formatting.format_record(&record, tag, &body_buffer) catch @compileError("body formatter exceeds 768");
            longest_body = @max(longest_body, value.len);
        }
    }
    var output_buffer: [1024]u8 = undefined;
    const maximum = std.math.maxInt(u64);
    var producer: output.Producer = .{
        .offset = std.math.maxInt(usize),
        .invocations = maximum,
        .attempts = maximum,
        .writes = maximum,
        .blocked = maximum,
        .pending = maximum,
        .terminal_attempts = maximum,
        .terminals = maximum,
        .checks = maximum,
        .after_reuse = maximum,
        .errors = maximum,
        .binding_index = 1,
        .binding_generation = maximum,
    };
    var longest_output: usize = 0;
    for ([_][]const u8{ "producer_reuse", "output_pressure_window", "output_pressure_ready" }) |tag| {
        const value = output.format(&producer, tag, &output_buffer) catch @compileError("producer formatter exceeds 1024");
        longest_output = @max(longest_output, value.len);
    }
    const file: file_observer.State = .{
        .reads = maximum,
        .requested = maximum,
        .returned = maximum,
        .read_errors = maximum,
        .close_calls = maximum,
        .closed_files = maximum,
        .invalid_spans = maximum,
        .min_offset = maximum,
        .max_end = maximum,
        .arms = maximum,
        .arm_errors = maximum,
    };
    const file_value = file_observer.format(&file, &output_buffer) catch @compileError("file formatter exceeds 1024");
    longest_output = @max(longest_output, file_value.len);
    const nonce = "n" ** nonce_limit;
    validate_nonce(nonce) catch @compileError("maximal nonce rejected");
    var prefix_buffer: [64]u8 = undefined;
    for ([_][]const u8{ "H2_RECORD", "H2_OUTPUT", "H2_DEINIT", "H2_BINDING", "H2_READY" }) |marker| {
        const prefix = std.fmt.bufPrint(&prefix_buffer, "info: {s} {s} \n", .{ marker, nonce }) catch @compileError("log prefix exceeds 64");
        require(prefix.len <= 64, "prefix bound");
    }
    var allowance_buffer: [2048]u8 = undefined;
    const capacity = std.fmt.bufPrint(&allowance_buffer, "info: " ++ capacity_format ++ "\n", .{ std.json.fmt(config, .{}), config.request_buffer_stride() catch @compileError("config stride"), config.h2_session_bytes() catch @compileError("h2 bytes"), config.h2_session_stride() catch @compileError("h2 stride"), config.slab_bytes() catch @compileError("slab"), config.router_storage_bytes() catch @compileError("router") }) catch @compileError("capacity log exceeds 2048");
    const ready = std.fmt.bufPrint(allowance_buffer[capacity.len..], "info: H2_READY {s}\n", .{nonce}) catch @compileError("ready allowance");
    const binding = std.fmt.bufPrint(allowance_buffer[capacity.len + ready.len ..], "info: H2_BINDING {s} tag=producer_reuse_next index={d} generation={d}\n", .{ nonce, @as(usize, 1), maximum }) catch @compileError("binding allowance");
    const totals: formatting.Totals = .{
        .middleware = 67,
        .attempts = 67,
        .begins = 67,
        .ends = 67,
        .cancels = 67,
        .failures = 67,
        .end_errors = 67,
        .chunk_errors = 67,
        .invalid_progress = 67,
        .accepted = 200091500,
        .active = 2,
        .errors = maximum,
        .buffered_middleware = 733,
    };
    const metric_body = formatting.format_totals(totals, &output_buffer) catch @compileError("metrics formatter exceeds 1024");
    const metrics_line = std.fmt.bufPrint(allowance_buffer[capacity.len + ready.len + binding.len ..], "info: H2_DEINIT {s} {s}\n", .{ nonce, metric_body }) catch @compileError("metrics allowance");
    const allowance = capacity.len + ready.len + binding.len + metrics_line.len;
    const retained = 67 * (longest_body + 64) + 4 * (longest_output + 64) + allowance;
    require(allowance <= 2048, "overhead allowance");
    require(retained <= 62144 and 62144 < 65536, "capture bound");
    _ = &producer;
}
