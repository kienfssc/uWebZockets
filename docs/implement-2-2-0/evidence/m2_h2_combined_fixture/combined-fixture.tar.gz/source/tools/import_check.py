"""Check source guards and imports without allowing side effects."""
import ast
import contextlib
import importlib.util
import io
from pathlib import Path
import shutil
import subprocess
import sys
from unittest.mock import patch


def refuse(*args, **kwargs):
    raise ValueError('side effect rejected during import')


def check_guard(path):
    source = ast.parse(path.read_text(), filename=str(path))
    if any(isinstance(node, (ast.Assert, ast.ClassDef)) for node in ast.walk(source)):
        raise ValueError('assert or class in ' + str(path))
    guard = source.body[-1]
    if not isinstance(guard, ast.If) or ast.unparse(guard.test) != "__name__ == '__main__'":
        raise ValueError('missing main guard in ' + str(path))


def import_inert(path, args):
    original_argv = sys.argv
    try:
        sys.argv = args[:]
        output = io.StringIO()
        error = io.StringIO()
        with patch.object(Path, 'mkdir', refuse), patch.object(Path, 'write_bytes', refuse), patch.object(Path, 'write_text', refuse), patch.object(Path, 'chmod', refuse), patch.object(Path, 'unlink', refuse), patch.object(Path, 'rename', refuse), patch.object(shutil, 'copytree', refuse), patch.object(shutil, 'copyfile', refuse), patch.object(subprocess, 'run', refuse):
            spec = importlib.util.spec_from_file_location('inert_check_module', path)
            module = importlib.util.module_from_spec(spec)
            with contextlib.redirect_stdout(output), contextlib.redirect_stderr(error):
                spec.loader.exec_module(module)
        if output.getvalue() or error.getvalue():
            raise ValueError('import emitted output: ' + str(path))
    finally:
        sys.argv = original_argv


def main(args):
    if len(args) == 3 and args[0] == 'legacy' and args[2] in ('empty', 'foreign'):
        import_inert(Path(args[1]), [] if args[2] == 'empty' else ['foreign', '--unexpected'])
        return
    if args:
        raise ValueError('invalid checker arguments')
    here = Path(__file__).parent
    fixture = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-fixture')
    paths = tuple(sorted(here.glob('*.py'))) + tuple(sorted(fixture.glob('*.py')))
    for path in paths:
        check_guard(path)
        for argv in ([], ['foreign', '--unexpected']):
            import_inert(path, argv)
    print('PASS guards and silent inert imports under empty/foreign argv:', len(paths), 'helpers')


if __name__ == '__main__':
    main(sys.argv[1:])
