"""Exercise recorder commands and refusal using caller-owned doubles."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from unittest.mock import patch


def load(path):
    spec = importlib.util.spec_from_file_location('recorder_test_module', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify(module, metrics):
    directories = []
    calls = []
    writes = {}
    def mkdir(path, *args, **kwargs):
        directories.append((str(path), kwargs))
    def read_text(path, *args, **kwargs):
        return json.dumps({'argv': ['zig', 'build-exe', '-Mroot=old', '--cache-dir', 'old', '--global-cache-dir', 'old', '-femit-bin=old'], 'cwd': '/candidate'})
    def write_text(path, value, *args, **kwargs):
        writes[str(path)] = value
    def write_bytes(path, value, *args, **kwargs):
        writes[str(path)] = value
    def run(argv, **kwargs):
        calls.append((argv, kwargs))
        return SimpleNamespace(stdout=b'out', stderr=b'err', returncode=0)
    with patch.object(Path, 'mkdir', mkdir), patch.object(Path, 'read_text', read_text), patch.object(Path, 'write_text', write_text), patch.object(Path, 'write_bytes', write_bytes), patch.object(subprocess, 'run', run), contextlib.redirect_stdout(io.StringIO()):
        for invalid in ([], ['../escape'], ['two', 'args']):
            try:
                module.main(invalid)
            except ValueError:
                continue
            raise ValueError('invalid arguments accepted')
        require(not directories and not calls and not writes, 'refusal caused side effects')
        module.main(['Fix2Double'])
    require(directories == [('/tmp/uwz-task5e2-Fix2Double', {'exist_ok': False})], 'attempt directory')
    if metrics:
        require(len(calls) == 1, 'metrics command count')
        argv, kwargs = calls[0]
        require(argv[2].endswith('/metrics_proof.zig') and argv[-1] == '-fno-emit-bin', 'metrics root/output')
        require(argv[4] == '/tmp/uwz-task5e2-Fix2Double/cache' and argv[6] == '/tmp/uwz-task5e2-Fix2Double/global', 'metrics caches')
        require(kwargs['cwd'] == '/candidate' and kwargs['env'] == {'LC_ALL': 'C.UTF-8'}, 'metrics cwd/environment')
        result = json.loads(writes['/tmp/uwz-task5e2-Fix2Double/result.json'])
        require(result['argv'] == argv and result['exit_status'] == 0, 'metrics receipt')
    else:
        require(len(calls) == 7, 'check command count')
        require(calls[-1][0][1:3] == ['fmt', '--check'], 'format command')
        result = json.loads(writes['/tmp/uwz-task5e2-Fix2Double/results.json'])
        require(len(result) == 7 and all(item['exit_status'] == 0 for item in result), 'check receipts')


def main(args):
    if args:
        raise ValueError('no arguments expected')
    here = Path(__file__).parent
    verify(load(here / 'metrics_run.py'), True)
    verify(load(here / 'checks_run.py'), False)
    print('PASS recorder command construction, receipts, and argument refusal')


if __name__ == '__main__':
    main(sys.argv[1:])
