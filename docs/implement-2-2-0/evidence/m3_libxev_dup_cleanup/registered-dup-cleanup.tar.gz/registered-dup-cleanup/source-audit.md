# Narrow registered-duplicate cancellation cleanup

Completed source audit only; no code, tests, compiler or native probe was run.
Inputs are frozen epoll bytes from c49f6df (unchanged by peer candidate 1b6c8ee),
the accepted dead-target plan, and the retained watcher source. This does not
claim measured descriptor leakage or complete generic epoll cancellation safety.

## Chosen boundary and typed contract

Change the `.cancel` branch only, after the accepted dead-target decision and
existing unsupported-cancel validation. Do not put an unconditional cleanup
after generic stop_completion: it also accepts deleting states and can invoke
timer callbacks that rearm or release their storage.

Propose this private **actual production decision**, used by the cancel branch:

```zig
fn registered_dup_cancel_fd(target: *const Completion) ?posix.fd_t;
```

It returns an owned fd only if all are true:

* target's private state is active;
* target.flags.threadpool is false;
* target.flags.dup is true;
* op tag is one of accept/connect/poll/read/pread/write/pwrite/send/recv/
  sendmsg/recvmsg, whose non-thread-pool start path registers through CTL_ADD.

Otherwise it returns null **without reading dup_fd or an operation fd payload**.
It reads only those defined state/flag/tag fields before the positive branch.
It mutates no target/loop state and performs no syscall or allocation. It must
not infer anything from public Completion.state(), which collapses private
adding/deleting/active. Nor may private active alone classify a worker or timer.

For a returned fd, the cancel branch performs this exact sequence:

```text
save owned duplicate through registered_dup_cancel_fd
stop_completion(target) exactly once
invalidate target.flags.dup_fd = 0
close saved duplicate exactly once
produce the existing cancellation acknowledgement
```

Keep flags.dup true: it is the request to use a distinct descriptor on the next
supported registration. Keep the operation's original socket/fd untouched.
The cache invalidation must precede close and ACK. On null, preserve the existing
stop path and do not access the target afterward merely for this cleanup. This
preserves timer callback lifetime, other states and existing result/count logic.

## Why the returned fd is initialized and owned

`Completion.flags` initializes dup=false and dup_fd=0 (`epoll.zig:957-963`).
fd_maybe_dup (`:1125-1131`) obtains the operation's original fd; when dup is
requested it either returns its existing positive cache or calls dup, stores
the result, and returns that stored descriptor. The non-thread-pool registration
branches all call this helper before CTL_ADD (`:587-789`). Only after a successful
registration does start mark the completion private-active and increment active
(`:863-870`). A registration failure takes the immediate result/callback path
with dead state (`:839-856`), rather than establishing private-active ownership.

Ordinary listener TCP.accept sets dup=true before add (`watcher/tcp.zig:145-158`)
and reaches the accept registration branch (`epoll.zig:587-601`). TCP.read uses
recv; TCP.write uses send (`watcher/tcp.zig:30-36`). Their stream watcher paths
set dup=true on epoll, do not mark TCP targets threadpool, and reach recv/send
registration (`epoll.zig:718-745`). Thus accepted listener, read and write
targets satisfy the same ownership proof. Thread-pool socket close is not a
target of this decision and is explicitly excluded.

**fd zero is valid.** The cache's existing reuse check is `dup_fd > 0`; zero
also represents the empty cache. A successful dup can nevertheless return fd 0
when it was free. Private-active registration plus the other predicates proves
that cached zero is owned in this case. Return `?fd_t` with a non-null value 0;
never use a positive-fd filter to decide cleanup. Resetting the cache to zero
preserves the existing empty-cache protocol, including this edge case.

## stop, count and callback ordering

For the positive decision, stop_completion takes its fd branch (`:872-880`),
which performs DEL but invokes no target callback. It decrements the target's
one active count and marks it dead (`:918-923`). It does not change dup_fd.
Therefore the retained target can safely have that cache invalidated immediately
after stop. No target pointer access is required after the saved fd is closed.
Closing the duplicate neither closes nor rewrites the separately owned original
descriptor. It does not affect completion counts or cancel result construction.

The canceller's normal immediate-result path then marks the canceller dead and
invokes ACK (`:839-856`), without a second target decrement. ACK cannot observe
the old live cache. R3 still retains the target/completion until the actual ACK
frame retires; this change does not authorize earlier transport reuse.

The accepted dead guard runs first. A dead non-timer target returns NotFound,
with no stale fd read, DEL, duplicate close, target callback or count mutation.
This covers the source ordering where a timer queues cancel and the same tick's
ready target later disarms: the entire ready batch performs its saved DEL/close
before the next submission phase starts the cancel. A rearmed target remains
registered/private-active and follows the successful cleanup above.

No previous ready batch remains concurrently on the loop thread when that
cancel starts; loop reentry is forbidden. DEL precedes close, so an fd number
reused by another thread cannot retain the old interest. Invalidating the cache
before close ensures subsequent supported add/reinitialization cannot reuse a
closed number from this cancellation. fd_maybe_dup sees the empty cache and
acquires a new owned duplicate. High-level TCP watcher reinitialization also
resets the cache; the cleanup must support reuse without relying on that reset.

## Preserved/excluded conditions

| Condition | Decision / scope |
| --- | --- |
| private-active, registered fd op, !threadpool, dup | Return owned duplicate; one stop, invalidate, close, then ACK. |
| private-active ordinary fd, !dup | Null; existing unregister/count behavior unchanged; never close original fd. |
| private-dead non-timer | Earlier NotFound guard; no snapshot or stop. |
| completed timer | Earlier accepted success rule; no duplicate handling. |
| adding or deleting | Null; queued membership/prior-registration ambiguity is outside this repair. |
| running/MPSC-queued worker | Null; private active is not epoll registration. No worker result read or ownership claim. |
| timer/cancel/noop/close/shutdown tag | Null; not a registered fd start path in this proof. |

This is not a generic adding/deleting/worker repair. Nor does it settle duplicate
allocation followed by registration failure, or the separate normal-disarm
cache-reuse behavior; those need their own ownership proof if included in a
broader claim. H1 must retain its constrained watcher/queue order, no explicit
delete, and completion lifetime through ACK. Listener original-fd close ordering
and all non-epoll callback retirement remain separate orchestration obligations.

## Required pure tests of that actual decision

After root accepts this plan, add no-syscall tests in the maintained backend
file, calling the same helper used by production:

1. Each registered fd tag above, private-active/!threadpool/dup, returns its
   cached operand; explicitly include accept, recv and send, fd 0, and a positive
   fd. Do not construct a loop or allocate real descriptors.
2. Dead/adding/deleting states, active worker, !dup and every excluded tag return
   null, without consulting undefined operation payloads or worker result data.
3. Relevant target fields are unchanged by the decision; a const input and no
   Loop parameter make count mutation impossible in this helper.
4. Keep the completed-timer/dead-fd decision tests from the accepted earlier
   change unchanged. Review the straight-line invalidate-before-close-before-ACK
   ordering and exactly-one stop in the actual production branch separately;
   do not create a test-only cancellation model or forwarding setter helper.

No native cancellation, descriptor-leak, race, injected-result or crash test is
requested. Root may authorize implementation, independent review, permitted pure
tests and unchanged existing healthy suites as separate phases.
