# Registered-duplicate cancellation cleanup candidate

Prepared source only; no compiler, unit/native test or cancellation probe has
run. The two new tests are declared pure tests of the actual production helper.
Independent review must precede any execution or candidate commit.

The private helper accepts const Completion and returns optional owned fd only
for private-active, non-worker, duplicate registrations with an explicit
registerable fd operation tag. It reads no cached descriptor otherwise. Zero
is a valid owned duplicate. The caller runs after the reviewed dead guard.
It saves that optional fd, stops once, clears the target cache before closing
the saved duplicate, and then follows existing ACK handling. It never closes
the operation's original fd or changes the dup request flag. No target access
occurs after close. Null cases retain the old stop path without post-stop target
access, preserving timer callback lifetime. Adding/deleting/worker behavior,
start-failure ownership and ordinary-disarm cache reuse are outside this fix.

The source audit proves the chosen registration predicates for accept/recv/send
and other listed fd operations. It is not runtime leak evidence or a general
cancellation/physical-close proof. Existing healthy results on base7b7 do not
verify this new delta. No active root dependency pin or remote ref is changed.
