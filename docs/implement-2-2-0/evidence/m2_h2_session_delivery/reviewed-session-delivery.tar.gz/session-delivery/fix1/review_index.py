from pathlib import Path
import json,hashlib,re
root=Path('/workspaces/uWebZockets');out=root/'.uwz-work/evidence/h2-streaming/session-delivery/fix1';source=Path('/tmp/uwz-m2-h2-session-delivery');base=Path('/tmp/uwz-m2-h2-body-queue');expected='1d53c6704d8f31c333052998a85a293834276f386b4239fdbf44556496a5342e'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def manifest(path):return [(str(p.relative_to(path)),sha(p)) for p in sorted(path.rglob('*')) if p.is_file()]
def digest(m):return hashlib.sha256(json.dumps(m).encode()).hexdigest()
assert digest(manifest(source))==expected;assert digest(manifest(base))=='580199bc84e81779dd050943fc0b1bb7a9b8f1af113fcb28e7fab560fc105af6'
runtime={};totals={}
for mode in ['Debug','ReleaseSafe']:
 total=0
 for suite in ['http2_upload_driver_tests','http2_tests','http2_hpack_tests','http2_body_queue_tests','body_h2_refusal_tests','body_h2_width_tests','http1_upload_admission_tests','http1_upload_driver_tests','body_h1_head_tests','http2_server_tests','body_app_tests']:
  label='fix1-final-'+suite+'-'+mode;m=json.loads((out/(label+'.json')).read_text());r=json.loads((out/(label+'-run.json')).read_text());assert m['exit_status']==r['exit_status']==0;assert m['source_before']==m['source_after']==r['source_before']==r['source_after']==expected
  assert m['inputs_before']==m['inputs_after'] and m['override_before']==m['override_after'];assert r['inputs_before']==r['inputs_after'] and r['override_before']==r['override_after'];assert m['binary_sha256']==r['inputs_before'][r['argv'][0]]
  count=int(re.search(r'All (\d+) tests passed', (out/(label+'-run.log')).read_text()).group(1));total+=count;argv=m['argv'];filters=[argv[i+1] for i,x in enumerate(argv[:-1]) if x=='--test-filter'];runtime[label]={'tests':count,'exit_status':0,'filters':filters,'compile_record_sha256':sha(out/(label+'.json')),'run_record_sha256':sha(out/(label+'-run.json')),'binary_sha256':m['binary_sha256'],'raw_log_sha256':sha(out/(label+'-run.log'))}
 assert total==173;totals[mode]=total
checks={}
for label in ['central-native','central-macos','central-windows','queue-32','selected-32','matrix-32','fmt-check','conventions','version','docs','patch-reconstruct']:
 p=out/('fix1-final-'+label+'.json');m=json.loads(p.read_text());assert m['exit_status']==0 and m['source_before']==m['source_after']==expected;assert m['inputs_before']==m['inputs_after'] and m['override_before']==m['override_after'];checks[p.name]={'exit_status':0,'record_sha256':sha(p),'raw_log_sha256':sha(p.with_suffix('.log'))}
for target in ['native','macos','windows']:
 p=out/('fix1-final-layout-'+target+'.json');m=json.loads(p.read_text());errors=re.findall(r'^.*error:.*$',p.with_suffix('.log').read_text(),re.M);assert m['exit_status']==1 and len(errors)==1 and 'found compile log statement' in errors[0];assert m['source_before']==m['source_after']==expected;assert m['inputs_before']==m['inputs_after'] and m['override_before']==m['override_after'];checks[p.name]={'exit_status':1,'classification':'intentional compileLog only; layout measurement, not passing test','record_sha256':sha(p),'raw_log_sha256':sha(p.with_suffix('.log'))}
ast=json.loads((out/'fix1-final-ast-refresh.json').read_text());assert ast['exit_status']==0 and ast['source_before']==ast['source_after'];assert digest(ast['source_before'])==expected
prior=json.loads((root/'.uwz-work/evidence/h2-streaming/body-queue/focused-rs.json').read_text());assert all(sha(p)==h for p,h in prior['inputs_before'].items())
original_bindings={}
for label in ['central-native','central-macos','central-windows']:
 old=json.loads((root/('.uwz-work/evidence/h2-streaming/body-queue/'+label+'.json')).read_text())
 for p,h in old['inputs_before'].items():
  if '/h1-transport/r2/c-' in p:assert sha(p)==h;original_bindings[p]=h
snapshot=json.loads((out/'freeze.json').read_text());assert sha(snapshot['full_snapshot'])==snapshot['full_snapshot_sha256']
for name,h in json.loads((out/'final-source.json').read_text()):
 p=out/'final'/name
 if p.exists():assert sha(p)==h
patch=json.loads((out/'patch-verification.json').read_text());assert patch['exit_status']==0 and patch['result_digest']==expected
record={'status':'fix round1 frozen for scoped F1-F4 re-review; no native activation or full acceptance claim','source':snapshot,'final_git_patch':'fix1.patch','final_git_patch_sha256':sha(out/'fix1.patch'),'runtime_totals':totals,'runtime':runtime,'checks':checks,'ast_record_sha256':sha(out/'fix1-final-ast-refresh.json'),'ast_graph_sha256':ast['graph_after'],'original_r2_bindings_unchanged':original_bindings,'original_focused_inputs_unchanged':prior['inputs_before'],'external_sources_manifest_sha256':sha(out/'../finish-external-sources.json'),'layout_measurements_sha256':sha(out/'layout-measurements.json'),'inline_layout_comparison_sha256':sha(out/'../finish-inline-layout-comparison.json'),'runner_sources':{p.name:sha(p) for p in sorted(out.glob('*.py'))},'history_preserved':True,'predecessor_review_package_sha256':sha(out.parent/'review-package.json'),'red_identity_sha256':sha(out/'red-production-identity.json'),'red_compile_exit':json.loads((out/'fix1-red.json').read_text())['exit_status'],'red_runtime_exit':json.loads((out/'fix1-red-run.json').read_text())['exit_status'],'excluded_runtime':'H2-server filter40/69; healthy App filters8/31; full isolated native central and socket/client/resource/timer/cancellation scenarios excluded from final runtime; assertions unchanged','remaining':'independent protocol/spec/quality/structural review; App/TCP/H1cold owner/native/TLS binding; live100000000-byte proof; full central/h1spec/sanitizer/fuzz/OSS-Fuzz/Autobahn/package/release/nativeWindows gates; complete concrete-driver32 blockers retained'}
(out/'review-package.json').write_text(json.dumps(record,indent=2)+'\n');print('Final source',expected,'Debug173 ReleaseSafe173; required scoped checks and exact patch reconstruction verified.')
