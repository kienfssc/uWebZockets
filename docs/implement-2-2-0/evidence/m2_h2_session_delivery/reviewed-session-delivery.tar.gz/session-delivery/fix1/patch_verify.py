from pathlib import Path
import shutil,hashlib,json,subprocess
root=Path('/workspaces/uWebZockets');out=root/'.uwz-work/evidence/h2-streaming/session-delivery/fix1';base=Path('/tmp/uwz-m2-h2-session-delivery-artifacts/fix1/v3-source');copy=Path('/tmp/uwz-m2-h2-session-delivery-artifacts/fix1/patch-copy');patch=out/'fix1.patch'
def manifest(path):return [(str(p.relative_to(path)),hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(path.rglob('*')) if p.is_file()]
def digest(m):return hashlib.sha256(json.dumps(m).encode()).hexdigest()
before=manifest(base);assert digest(before)=='7062cbc464f470029db5dc80b61a29e047dbae169267b99be2bf5382506ebb39';assert not copy.exists();shutil.copytree(base,copy)
r=subprocess.run(['git','apply',str(patch)],cwd=copy,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
actual=manifest(copy);expected=json.loads((out/'final-source.json').read_text());assert actual==[tuple(row) for row in expected],r.stdout
assert manifest(base)==before
record={'argv':['git','apply',str(patch)],'cwd':str(copy),'exit_status':r.returncode,'output':r.stdout,'baseline_digest':digest(before),'baseline_unchanged':True,'result_digest':digest(actual),'expected_final_digest':'1d53c6704d8f31c333052998a85a293834276f386b4239fdbf44556496a5342e','patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'all_source_files_equal_final':True}
(out/'patch-verification.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0;print(json.dumps(record,indent=2))
