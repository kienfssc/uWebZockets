# Task3 report: concrete registered-sink Session delivery

Status: implemented and frozen for independent review within Root's scoped caller-buffer/healthy-regression authorization. Native H2 upload activation and full M2 acceptance remain open. No commits, refs, pins, fetches, subagents, Root production edits or publication were performed.

## Exact delivery

Continued the original1029-file955c2798 candidate without replacing it. The preserved15/15 Debug run and every original failure/command record remain intact. Immutable1025-file baseline580199bc84e81779dd050943fc0b1bb7a9b8f1af113fcb28e7fab560fc105af6 is unchanged.

Final1029-file source: `7062cbc464f470029db5dc80b61a29e047dbae169267b99be2bf5382506ebb39`.

Evidence root: `.uwz-work/evidence/h2-streaming/session-delivery/`.

- Authoritative review/integration patch: `session-delivery-v3-git.patch`, SHA256`a72871a66f48f8ac5b798bfffe5887db5c269f397f51341fe1b83cb985e4182b`.
- Complete changed-file snapshots/preimages: `final-v3/`, `preimages-v3/`; complete source manifest: `finish-final-source-v3.json`.
- Full regular-byte source archive: `/tmp/uwz-m2-h2-session-delivery-artifacts/finish-frozen-source-v3.tar.gz`, SHA256`8f8e06bd53dd98cb1b819e6f066a842979246769dfe2b40016ee0c287a375e46`.
- `review-package.json` and `finish-final-identities.json` bind the commands, compiler, original r2 modules, static libraries,93-file c223 override,14-file zslay input, binaries and explicit environments. All final source before/after identities match the frozen digest.
- `finish-final3-git-patch-verification.json` proves a fresh independent baseline copy plus the Git patch reconstructs every final file exactly. The baseline remains unchanged.

Eleven changed paths: `src/core/http1_upload.zig`, `src/core/http2_upload.zig`, `src/http2/body_receive.zig`, `src/http2/server.zig`, `src/router/app.zig`, `src/router/body_admission.zig`, `src/test_support.zig`, `src/tests/body_h2_width_tests.zig`, `src/tests/config_tests.zig`, `src/tests/http2_upload_driver_tests.zig`, `src/tests/main.zig`.

## Implemented behavior

The shared actual router admission policy and reservation/arm operation serve App/H1 and the concrete H2 driver. Existing H1 helper names/error sets and nullable legacy H2 callbacks remain compatible. Actual registered BodyRoutes reach begin/chunk/end through encoded Session HEADERS/DATA, independent logical route limits, caller controls and fresh Responses. No Response pointer/factory is retained.

Session owns the enabled-only pool/receive region and separately durable connection/stream credit intents. Fresh DATA is observed once even under Continue/FIFO holds; synthetic readiness never replaces real sink readiness. Continue acceptance gates chunk/end, resume while blocked updates actual readiness, retained input drains FIFO, final-byte pause requires resume, and padding/reset refunds commit only accepted output scopes. Buffered/refused/WS refunds use the same enabled connection ledger. Callback borrows defer metadata cleanup/slot reuse and terminal notifications; controls expire before terminal calls and quota releases afterward. End errors do not trigger a second cancel.

Initial request/capture metadata remains pinned through output completion. Capture spill matrices hold20-capture sibling routes independently; trailers validate in scratch. Middleware bytes survive valid refusals/success using existing bounded response-header storage. A rejected unretainable header section is removed in full before a bounded503, before begin/100. Tests decode actual100/200/413/503 output rather than relying only on frame counts.

Framing decisions follow [RFC9113 sections8.1/8.1.1](https://www.rfc-editor.org/rfc/rfc9113.html#section-8.1), accepted receive credit follows [section6.9.1](https://www.rfc-editor.org/rfc/rfc9113.html#section-6.9.1), and expectation handling follows [RFC9110 section10.1.1](https://www.rfc-editor.org/rfc/rfc9110.html#section-10.1.1). Root's `delivery_allowed` correction supplies the additional internal observation/delivery contract. No throughput or native-runtime performance claim is made.

## Final verification

Each row below passed in both Debug and ReleaseSafe against the final frozen source, using the recorded original module/static-library bindings and compiler`-j2`. These are169 selected tests per mode,338 executions total; they do not constitute the full native central suite.

| Runtime root | Tests per mode |
| --- | ---: |
| concrete H2 driver/encoded Session |21|
| HTTP/2 frames |17|
| HPACK |8|
| body queue/credit |9|
| H2 refusal |15|
| H2 full-u64 width |2|
| H1 admission |7|
| H1 caller-buffer driver/TLS capacity helpers |30|
| actual App/H1 head resolver |12|
| filtered H2 server |40|
| selected healthy App |8|

Final H2-server filter is exactly`http2 server:`:40/69 tests. Final healthy App filters select8/31 tests:

- `body App: streaming config defaults off`
- `body App: enabled slab contains typed owners`
- `body App: startup stays unarmed`
- `body App: registration copies path`
- `body App: disabled registration and limits`
- `body App: middleware policy registration`
- `body App: null upload detach`
- `body App: pure body registry`

The complete central test graph semantically compiles for native Linux, aarch64 macOS and x86_64 Windows GNU. Eligible x86-32 ReleaseSafe semantic checks pass for the queue, selected encoded Session width root, and the driver-root filter`Bundle and carve`. This verifies the selected declarations/layout operations, not complete concrete-driver/native32 support. Complete-driver32 compilation still reaches existing`http/abort.zig` atomic-u64 and`ws/mask.zig` u64-to-usize errors; neither production module was changed.

Full-directory formatting, conventions, release-version and documentation-link checks pass. Actual final layouts on all3 targets have only intentional compileLog exit1; these are measurements, never reported as passing tests. Independent identical-copy AST refresh passes with unchanged source,0 model tokens,13165 nodes/16401 edges. Its raw warnings retain the sequential fallback after unavailable parallel extraction and28 files with no extracted symbols; Root's graph was not overwritten.

## Actual layout and alignment accounting

Actual final types on all3 targets: Session8=1392, Storage=296, Capacities=64, Callbacks=72, ReceiveState=144, Driver=1288, Slot=152, admission Target=24 bytes. TCP sizes are25648/25568/26136 for Linux/macOS/Windows; H1 cold owners remain2880/2848/3040. No deferred H1 H2-owner pointer or additional descriptor was added.

| Measured8-stream region/profile | Bytes on all3 targets |
| --- | ---: |
| low-level Session/Bundle default disabled |517648|
| low-level Session/Bundle default enabled |591984|
| private header1024 Session/Bundle disabled |379408|
| private header1024 Session/Bundle enabled |453744|
| enabled receive/pool increase |74336|
| separate caller-owned concrete driver |1288|

The receive increase is73728 payload +432 block metadata +32 heads/tails +144 receive state. Both supplied native profiles have zero capture spill; a larger route-param configuration supplies two separate caller matrices. Default disabled1024-connection slab growth is exactly8192 warm bytes. Exact final disabled slab totals: Linux684185216, macOS684103296, Windows684684928.

Native config with`stream_request_bodies=true` still leaves H2 startup disabled, as explicitly deferred. Actual existing H1-enabled config totals are687144576/687029888/687808128, and private8 H1-enabled totals4826496/4825600/4831680. They are not native H2-enabled totals.

The2-stream native width case exposed an enabled Bundle/carve alignment defect. Reordering enabled pool planning before frame storage fixed ordinary block residues. Root's additional nonaligned matrix exposed the deeper auto-layout packing issue. Existing Bundle arrays now use the common carve alignment A; a compile-time assertion proves A dominates every carved natural alignment. Sum of per-field roundups to A bounds sequential carve padding independently of automatic field order. No new/padding fields, capacity change or assertion relaxation was used.

For previously undersized nonaligned inline Bundles at1/2/3/4/8 streams, extra inline padding is72/64/72/56/40 bytes. Default/private8 sizes above are unchanged on all3 targets; caller-carved sizes do not increase. Disabled nonaligned plans at1/2/3/4/8 exactly match the immutable baseline. The10-shape matrix validates aligned/misaligned actual carve spans, alignment, disjointness, complete bounds, Bundle.storage pointers and zero-length disabled optional arrays/pointers; its selected32 semantic compile passes. Raw before/after measurements and failing preimages remain in the evidence directory.

## Preserved failures and scope limits

`finish-diagnosis.md` explains every continuation failure, with original snapshots and raw logs. The initial20-test run had18 passes and2 failures: one bad route-record/quota fixture expectation, and an initially impossible8-byte503 slot. Those test repairs are not presented as behavioral red. A separate corrected16-byte-slot test against the exact pre-fix driver fails0/1, independently proving the unretainable-middleware refusal defect. Native2-stream and nonaligned Bundle compile failures are real layout red evidence. Earlier freezes2c3c956b/a7206f9d and all initial compiler failures remain historical nonfinal artifacts.

One attempted existing H2-server batch included two producer-abort tests that call native xev.TCP.init. The sandbox rejected socket creation (Unexpected errno1);67 other tests passed. The batch was stopped, the following interrupted compile was explicitly recorded, and the native cases were not retried or escalated. Final runtime uses the audited40-test filter; no assertion was edited for sandbox behavior. Allocation-failure/resource/native timer/cancellation/client and uncertain retirement cases remain compile-only. The stopped experiment stays stopped. The backend expectation remains an assertion: selected healthy App tests actually observe epoll; it does not select the backend.

The first Git-format patch reconstruction failed because new-file-mode metadata was missing; that failure and patch remain. The authoritative Git patch adds mode metadata only and reconstructs the final source exactly. Coverage-correction sidecars explicitly qualify generic historical queue/32bit wording without overwriting terminal records.

Remaining gates: independent protocol/spec/quality/structural review; App/TCP startup and H1 cold-owner binding; native delivery-borrow/TLS/lifecycle composition; actual owned100000000-byte H2/TLS proof; full central runtime/h1spec, sanitizers/separate MSan, fuzz/OSS-Fuzz, Autobahn/shared-I/O, package/consumer/release and native Windows acceptance. Root owns promotion, final docs, commits/pushes and later native activation. Driver owner/capture storage must remain stable and its setup bind occurs once; connection reuse must preserve slot generations in the future native owner composition.
