from pathlib import Path
import hashlib,json,difflib,shutil,stat,tarfile
root=Path('/workspaces/uWebZockets');out=root/'.uwz-work/evidence/h2-streaming/session-delivery/fix1';base=Path('/tmp/uwz-m2-h2-session-delivery-artifacts/fix1/v3-source');source=Path('/tmp/uwz-m2-h2-session-delivery');art=Path('/tmp/uwz-m2-h2-session-delivery-artifacts/fix1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(path):
 rows=[]
 for p in sorted(path.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():
   assert stat.S_ISREG(p.stat().st_mode) and p.stat().st_nlink==1,p
   rows.append((str(p.relative_to(path)),sha(p)))
 return rows
def digest(rows):return hashlib.sha256(json.dumps(rows).encode()).hexdigest()
a=manifest(base);b=manifest(source);assert digest(a)=='7062cbc464f470029db5dc80b61a29e047dbae169267b99be2bf5382506ebb39'
ad=dict(a);bd=dict(b);changed=[n for n in sorted(set(ad)|set(bd)) if ad.get(n)!=bd.get(n)];patch=[]
for name in changed:
 old=(base/name).read_text() if name in ad else '';new=(source/name).read_text() if name in bd else ''
 for folder,origin,exists in [('final',source,name in bd),('preimages',base,name in ad)]:
  if not exists:continue
  target=out/folder/name;assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(origin/name,target)
 patch.append('diff --git a/'+name+' b/'+name+'\n')
 patch.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+name if name in ad else '/dev/null',tofile='b/'+name if name in bd else '/dev/null'))
(out/'fix1.patch').write_text(''.join(patch));(out/'final-source.json').write_text(json.dumps(b,indent=2)+'\n')
archive=art/'frozen-source.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for name,_ in b:tar.add(source/name,arcname=name,recursive=False)
record={'source':str(source),'file_count':len(b),'digest':digest(b),'baseline':str(base),'baseline_file_count':len(a),'baseline_digest':digest(a),'changed_paths':changed,'full_snapshot':str(archive),'full_snapshot_sha256':sha(archive),'patch_sha256':sha(out/'fix1.patch'),'all_regular_no_hardlinks_or_symlinks':True}
(out/'freeze.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
