# Scoped middleware/refusal re-review, fix round1

Reviewer: /root/review_h2_shared_admission. Read-only re-review of F4 and new
breakage in the four-path fix diff against frozen1d53c670 source.

F4 ADDRESSED: saved middleware bytes are copied into a fresh Response before
encoding. Cancellation invalidates controls; quota releases after cancel returns.
Identity/response checks suppress later413 after callback retirement. Session
retains final-acceptance-before-NO_ERROR-reset ordering.

Spec verdict: pass for scoped fix. Quality verdict: pass. Header restoration
earns its raw/encoded separation invariant; default-false stack event flag adds
no stored state or retained Response. No actionable fix-diff breakage found.

Recorded real F4 red is MissingSavedMiddleware. Final Debug/ReleaseSafe logs
pass25 driver tests, including blocked output, queued input, exact response/reset
counts and cancel-time retirement. No checks rerun. Native/TLS/lifecycle and full
runtime acceptance remain unverified.
