import subprocess,sys,json
from pathlib import Path
root=Path('/workspaces/uWebZockets');out=root/'.uwz-work/evidence/h2-streaming/session-delivery';driver=out/'finish_driver.py'
jobs=[]
for mode in ['Debug','ReleaseSafe']:
 for suite in ['http2_tests','http2_hpack_tests','http2_body_queue_tests','body_h2_refusal_tests','body_h2_width_tests','http1_upload_admission_tests','http1_upload_driver_tests','body_h1_head_tests']:
  old='finish-'+suite+'-'+mode
  if (out/(old+'-run.json')).exists():continue
  jobs.append(('finish-safe-'+suite+'-'+mode,mode,suite,[]))
 jobs.append(('finish-safe-h2server-'+mode,mode,'http2_server_tests',['http2 server:']))
 jobs.append(('finish-safe-app-'+mode,mode,'body_app_tests',['body App: streaming config defaults off','body App: enabled slab contains typed owners','body App: startup stays unarmed','body App: registration copies path','body App: disabled registration and limits','body App: middleware policy registration','body App: null upload detach','body App: pure body registry']))
for label,mode,suite,filters in jobs:
 r=subprocess.run([sys.executable,str(driver),'focused',label,mode,'native','src/tests/'+suite+'.zig']+filters,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(label,'compile',r.returncode,flush=True)
 if r.returncode:print(r.stdout,flush=True);continue
 r=subprocess.run([sys.executable,str(driver),'run',label],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(label,'run',r.returncode,r.stdout.strip().splitlines()[-2:],flush=True)
 if r.returncode:print(r.stdout,flush=True)
