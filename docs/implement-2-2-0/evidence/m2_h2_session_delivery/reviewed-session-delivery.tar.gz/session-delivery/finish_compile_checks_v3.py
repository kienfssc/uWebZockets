import subprocess,sys
from pathlib import Path
root=Path('/workspaces/uWebZockets');out=root/'.uwz-work/evidence/h2-streaming/session-delivery';driver=out/'finish_driver.py'
jobs=[]
for name,target in [('native','native'),('macos','aarch64-macos'),('windows','x86_64-windows-gnu')]:
 if name!='native':jobs.append(('central','finish-final3-central-'+name,'Debug',target,'src/tests/main.zig'))
 jobs.append(('layout','finish-final3-layout-'+name,'ReleaseSafe',target,'/tmp/uwz-m2-h2-session-delivery-artifacts/finish-layout.zig'))
jobs.append(('pure32','finish-final3-queue-32','ReleaseSafe','x86-linux-gnu','src/tests/http2_body_queue_tests.zig'))
jobs.append(('pure32','finish-final3-selected-32','ReleaseSafe','x86-linux-gnu','src/tests/body_h2_width_tests.zig'))
jobs.append(('pure32','finish-final3-matrix-32','ReleaseSafe','x86-linux-gnu','src/tests/http2_upload_driver_tests.zig','Bundle and carve'))
for args in jobs:
 r=subprocess.run([sys.executable,str(driver),*args],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(args[1],r.returncode,flush=True)
 if r.returncode and args[0]!='layout':print(r.stdout,flush=True)
