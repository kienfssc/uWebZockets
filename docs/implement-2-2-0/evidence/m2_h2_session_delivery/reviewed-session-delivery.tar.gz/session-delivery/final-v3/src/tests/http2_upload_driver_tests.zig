const std = @import("std");
const support = @import("test_support");
const server = support.http2_server;
const wire = support.http2;
const body = support.request_body;
const admission = support.body_admission;
const radix = support.radix;
const Request = support.http_request.Request;
const Response = support.http_response.Response;
const StreamingRequest = support.streaming_request.StreamingRequest;
const Session = server.server_session(4);
const Driver = support.http2_upload.upload_driver(4);
const capacities = Session.Capacities{ .stream_request_bodies = true, .body_size = 16, .request_header_size = 4096 };
const RouterBundle = radix.Bundle(.{ .stream_request_bodies = true, .max_route_params = 20 });
const ResetDuring = enum { none, begin, chunk, end, admission };

const Binding = struct {
    fixture: *Fixture,
    control: body.BodyControl,
    stream_id: u32,
    bytes: [4096]u8 = undefined,
    length: usize = 0,
    chunks: usize = 0,
    ends: usize = 0,
    cancels: usize = 0,
    reason: ?body.BodyCancelReason = null,
};

const Fixture = struct {
    bundle: Session.Bundle(capacities) = .{},
    session: Session = .{},
    driver: Driver = undefined,
    router_bundle: RouterBundle = .{},
    router: radix.Router = .{},
    definition: body.BodyRoute = undefined,
    captures_names: [16][]const u8 = undefined,
    captures_values: [16][]const u8 = undefined,
    bindings: [4]Binding = undefined,
    output: [4080]u8 = undefined,
    output_length: usize = 0,
    begins: usize = 0,
    middleware_calls: usize = 0,
    buffered_calls: usize = 0,
    pause_begin: bool = false,
    pause_prefix: ?usize = null,
    fail_begin: bool = false,
    fail_chunk: bool = false,
    fail_end: bool = false,
    reset_during: ResetDuring = .none,
    control_failure: bool = false,
    metadata_ok: bool = true,
    legacy: bool = false,
    legacy_refusal: bool = false,
    buffered_bytes: usize = 0,
    expected_active_in_end: u16 = 1,

    fn init(self: *Fixture) !void {
        self.session = try Session.init(self.bundle.storage());
        try self.session.reset();
        self.router = try radix.Router.init(self.router_bundle.storage());
        self.definition = .{ .sink = .{ .context = self, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel }, .limits = .{ .max_body_bytes = 4096, .max_active = 4 }, .middleware_policy = .headers_only };
        try self.router.route_body(.post, "/upload/:name", &self.definition);
        self.driver = .{ .session = &self.session, .context = self, .admission_target = .{ .context = self, .router = &self.router, .resolve = resolve }, .capture_names = &self.captures_names, .capture_values = &self.captures_values };
        self.driver.bind();
        try self.session.receive(wire.client_preface, self.callbacks());
        try self.frame(.settings, 0, 0, "");
        self.output_length = 0;
    }

    fn callbacks(self: *Fixture) server.Callbacks {
        return .{ .context = self, .write_fn = write, .request_fn = buffered, .header_fn = if (self.legacy) legacy_header else null, .body_select_fn = if (self.legacy) null else selects, .body_event_fn = if (self.legacy) null else event };
    }
    fn selects(context: *anyopaque, request: *const Request) bool {
        const self: *Fixture = @ptrCast(@alignCast(context));
        return self.driver.selects(request);
    }
    fn resolve(context: *anyopaque, input: *const admission.Input, response: *Response) admission.Decision {
        const self: *Fixture = @ptrCast(@alignCast(context));
        if (self.reset_during == .admission) {
            self.session.reset_stream(self.session.connection.streams.stream_ids[0], .cancel, self.callbacks()) catch {
                self.control_failure = true;
            };
            self.metadata_ok = self.metadata_ok and std.mem.startsWith(u8, input.request.path, "/upload/");
        }
        return admission.resolve_router(&self.router, input, response);
    }
    fn event(context: *anyopaque, input: server.BodyEvent) !server.BodyEventResult {
        const self: *Fixture = @ptrCast(@alignCast(context));
        const identity = switch (input) {
            inline else => |value| .{ value.stream_id, value.stream_index },
        };
        const slot = &self.driver.slots[identity[1]];
        var response = self.make_response(identity[0]);
        return self.driver.event(input, &response, .{ .context = slot, .resume_fn = resume_control, .cancel_fn = cancel_control });
    }
    fn resume_control(context: *anyopaque) error{BodyDeliveryFailed}!void {
        const slot: *Driver.Slot = @ptrCast(@alignCast(context));
        const self: *Fixture = @ptrCast(@alignCast(slot.owner.context));
        self.session.resume_body(slot.stream_id, self.callbacks()) catch return error.BodyDeliveryFailed;
    }
    fn cancel_control(context: *anyopaque) void {
        const slot: *Driver.Slot = @ptrCast(@alignCast(context));
        const self: *Fixture = @ptrCast(@alignCast(slot.owner.context));
        self.session.cancel_body(slot.stream_id, .cancelled, self.callbacks()) catch {
            self.control_failure = true;
        };
    }
    fn write(context: *anyopaque, parts: []const []const u8) !void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        var total: usize = 0;
        for (parts) |part| total += part.len;
        if (total > self.output.len - self.output_length) return error.WouldBlock;
        for (parts) |part| {
            @memcpy(self.output[self.output_length..][0..part.len], part);
            self.output_length += part.len;
        }
    }
    fn legacy_header(context: *anyopaque, _: *const Request) server.HeaderDecision {
        const self: *Fixture = @ptrCast(@alignCast(context));
        return if (self.legacy_refusal) .refuse_body else .buffered;
    }
    fn buffered(context: *anyopaque, request: *Request, _: u32) !void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        self.buffered_calls += 1;
        self.buffered_bytes += request.body.len;
    }
    fn make_response(self: *Fixture, stream_id: u32) Response {
        return .{ .target = .{ .http2 = .{ .context = self, .router = &self.router, .stream_id = stream_id, .end_fn = response_end, .begin_fn = response_begin, .write_fn = response_write, .finish_fn = response_finish } } };
    }
    fn response_end(context: *anyopaque, id: u32, status: []const u8, headers: []const u8, bytes: []const u8) !void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        try self.session.send_response(id, status, headers, bytes, self.callbacks());
    }
    fn response_begin(context: *anyopaque, id: u32, status: []const u8, headers: []const u8) !void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        try self.session.begin_response(id, status, headers, self.callbacks());
    }
    fn response_write(context: *anyopaque, id: u32, bytes: []const u8) !void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        try self.session.write_response_data(id, bytes, self.callbacks());
    }
    fn response_finish(context: *anyopaque, id: u32) !void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        try self.session.finish_response(id, self.callbacks());
    }
    fn begin(context: *anyopaque, request: *const StreamingRequest, control: body.BodyControl) !body.BodyBinding {
        const self: *Fixture = @ptrCast(@alignCast(context));
        const slot: *Driver.Slot = @fieldParentPtr("body", control.owner);
        self.begins += 1;
        const binding = &self.bindings[slot.index];
        binding.* = .{ .fixture = self, .control = control, .stream_id = slot.stream_id };
        if (self.reset_during == .begin) {
            try self.session.reset_stream(slot.stream_id, .cancel, self.callbacks());
            self.metadata_ok = self.metadata_ok and std.mem.startsWith(u8, request.path, "/upload/");
        }
        if (self.fail_begin) return error.ApplicationBeginFailed;
        return .{ .context = binding, .readiness = if (self.pause_begin) .paused else .ready };
    }
    fn chunk(context: *anyopaque, bytes: []const u8) !body.BodyProgress {
        const binding: *Binding = @ptrCast(@alignCast(context));
        const self = binding.fixture;
        binding.chunks += 1;
        if (self.reset_during == .chunk) {
            try self.session.reset_stream(binding.stream_id, .cancel, self.callbacks());
            self.metadata_ok = self.metadata_ok and std.mem.startsWith(u8, self.session.requests[0].path, "/upload/");
        }
        if (self.fail_chunk) return error.ApplicationChunkFailed;
        const consumed = @min(self.pause_prefix orelse bytes.len, bytes.len);
        @memcpy(binding.bytes[binding.length..][0..consumed], bytes[0..consumed]);
        binding.length += consumed;
        const paused = self.pause_prefix != null;
        self.pause_prefix = null;
        return .{ .consumed = consumed, .readiness = if (paused) .paused else .ready };
    }
    fn end(context: *anyopaque, request: *const StreamingRequest, response_value: *Response) !void {
        const binding: *Binding = @ptrCast(@alignCast(context));
        const self = binding.fixture;
        binding.ends += 1;
        try std.testing.expectError(error.BodyControlExpired, binding.control.cancel());
        const slot: *Driver.Slot = @fieldParentPtr("body", binding.control.owner);
        try std.testing.expectEqual(self.expected_active_in_end, self.router.body.active[slot.record_index]);
        self.metadata_ok = self.metadata_ok and request.params.get("name") != null;
        if (self.fail_end) return error.ApplicationEndFailed;
        if (self.reset_during == .end) {
            try self.session.reset_stream(binding.stream_id, .cancel, self.callbacks());
            self.metadata_ok = self.metadata_ok and request.params.get("name") != null;
            return;
        }
        try response_value.end("200 OK", "ok");
        self.metadata_ok = self.metadata_ok and std.mem.startsWith(u8, request.path, "/upload/");
    }
    fn cancel(context: *anyopaque, reason: body.BodyCancelReason) void {
        const binding: *Binding = @ptrCast(@alignCast(context));
        binding.cancels += 1;
        binding.reason = reason;
        binding.control.cancel() catch |err| {
            if (err != error.BodyControlExpired) binding.fixture.control_failure = true;
            return;
        };
        binding.fixture.control_failure = true;
    }
    fn frame(self: *Fixture, kind: wire.FrameType, flags: u8, id: u32, payload: []const u8) !void {
        var bytes: [16393]u8 = undefined;
        try (wire.FrameHeader{ .payload_length = @intCast(payload.len), .frame_type = @intFromEnum(kind), .flags = flags, .stream_id = id }).encode(bytes[0..9]);
        @memcpy(bytes[9..][0..payload.len], payload);
        try self.session.receive(bytes[0 .. 9 + payload.len], self.callbacks());
    }
    fn head(self: *Fixture, id: u32, length: ?[]const u8, expect: bool, end_stream: bool) !void {
        try self.head_path(id, "/upload/first", length, expect, end_stream);
    }
    fn head_path(self: *Fixture, id: u32, path: []const u8, length: ?[]const u8, expect: bool, end_stream: bool) !void {
        var bytes: [512]u8 = undefined;
        var used: usize = 0;
        try literal(&bytes, &used, ":method", "POST");
        try literal(&bytes, &used, ":scheme", "http");
        try literal(&bytes, &used, ":path", path);
        try literal(&bytes, &used, "x-initial", "retained");
        if (length) |value| try literal(&bytes, &used, "content-length", value);
        if (expect) try literal(&bytes, &used, "expect", "100-continue");
        try self.frame(.headers, if (end_stream) 5 else 4, id, bytes[0..used]);
    }
    /// Fill the actual writer with accepted PING/SETTINGS acknowledgements.
    fn fill_output(self: *Fixture, remaining: usize) !void {
        self.output_length = 0;
        const used = self.output.len - remaining;
        for (0..18) |settings| {
            if (settings * 9 > used or (used - settings * 9) % 17 != 0) continue;
            for (0..settings) |_| try self.frame(.settings, 0, 0, "");
            for (0..(used - settings * 9) / 17) |_| try self.frame(.ping, 0, 0, "12345678");
            try std.testing.expectEqual(used, self.output_length);
            return;
        }
        return error.UnrepresentableFill;
    }
    fn flush(self: *Fixture) !void {
        self.output_length = 0;
        try self.session.flush_pending(self.callbacks());
    }
};

fn literal(output: []u8, used: *usize, name: []const u8, value: []const u8) !void {
    if (name.len > 126 or value.len > 126 or 3 + name.len + value.len > output.len - used.*) return error.OutputTooSmall;
    output[used.*] = 0;
    output[used.* + 1] = @intCast(name.len);
    used.* += 2;
    @memcpy(output[used.*..][0..name.len], name);
    used.* += name.len;
    output[used.*] = @intCast(value.len);
    used.* += 1;
    @memcpy(output[used.*..][0..value.len], value);
    used.* += value.len;
}

fn frame_count(fixture: *const Fixture, kind: wire.FrameType, id: u32) !usize {
    var cursor: usize = 0;
    var count: usize = 0;
    while (cursor < fixture.output_length) {
        const header = try wire.FrameHeader.parse(fixture.output[cursor..][0..9]);
        if (header.frame_type == @intFromEnum(kind) and header.stream_id == id) count += 1;
        cursor += 9 + header.payload_length;
    }
    try std.testing.expectEqual(fixture.output_length, cursor);
    return count;
}

fn expect_status(fixture: *const Fixture, stream_id: u32, ordinal: usize, expected: []const u8) !void {
    var cursor: usize = 0;
    var seen: usize = 0;
    while (cursor < fixture.output_length) {
        const header = try wire.FrameHeader.parse(fixture.output[cursor..][0..9]);
        const payload = fixture.output[cursor + 9 ..][0..header.payload_length];
        cursor += 9 + header.payload_length;
        if (header.frame_type != @intFromEnum(wire.FrameType.headers) or header.stream_id != stream_id) continue;
        if (seen != ordinal) {
            seen += 1;
            continue;
        }
        var table = try support.http2_hpack.DynamicTable.init(&.{}, &.{}, 0);
        var decoder = support.http2_hpack.Decoder.init(&table, 4096);
        var fields: [16]support.http2_hpack.Header = undefined;
        var bytes: [4096]u8 = undefined;
        const decoded = try decoder.decode_fields(payload, &fields, &bytes);
        try std.testing.expectEqualStrings(":status", decoded[0].name);
        try std.testing.expectEqualStrings(expected, decoded[0].value);
        if (std.mem.eql(u8, expected, "100")) try std.testing.expectEqual(@as(u8, 0), header.flags & 1);
        return;
    }
    return error.MissingResponseHeaders;
}

test "http2 upload: encoded Session reaches registered begin chunk end beyond buffered stride" {
    var fixture = Fixture{};
    try fixture.init();
    try fixture.head(1, "100", false, false);
    const bytes: [100]u8 = @splat('a');
    try fixture.frame(.data, 1, 1, &bytes);
    try std.testing.expectEqual(@as(usize, 1), fixture.begins);
    try std.testing.expectEqual(@as(usize, 100), fixture.bindings[0].length);
    try std.testing.expectEqualSlices(u8, &bytes, fixture.bindings[0].bytes[0..100]);
    try std.testing.expectEqual(@as(usize, 1), fixture.bindings[0].ends);
    try std.testing.expectEqual(@as(usize, 0), fixture.bindings[0].cancels);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[0]);
    try std.testing.expect(fixture.metadata_ok);
    try std.testing.expectEqual(@as(usize, 1), try frame_count(&fixture, .headers, 1));
    try std.testing.expectEqual(@as(i64, 65535), fixture.session.connection.connection_receive_window);
}

test "http2 upload: partial pause retains FIFO observes fresh once and ends on public resume" {
    var fixture = Fixture{ .pause_prefix = 2 };
    try fixture.init();
    try fixture.head(1, "10", false, false);
    try fixture.frame(.data, 0, 1, "abcdef");
    try fixture.frame(.data, 1, 1, "ghij");
    try std.testing.expectEqual(@as(usize, 2), fixture.bindings[0].length);
    try std.testing.expectEqual(@as(u64, 10), fixture.driver.slots[0].body.observed);
    try std.testing.expectEqual(@as(usize, 0), fixture.bindings[0].ends);
    try fixture.bindings[0].control.@"resume"();
    try std.testing.expectEqualStrings("abcdefghij", fixture.bindings[0].bytes[0..10]);
    try std.testing.expectEqual(@as(usize, 1), fixture.bindings[0].ends);
    try std.testing.expectEqual(@as(i64, 65535), fixture.session.connection.connection_receive_window);
}

test "http2 upload: blocked Continue holds ready DATA and empty EOF until actual acceptance" {
    var fixture = Fixture{};
    try fixture.init();
    try fixture.fill_output(0);
    try fixture.head(1, "6", true, false);
    try fixture.frame(.data, 0, 1, "abc");
    try fixture.frame(.data, 1, 1, "def");
    try std.testing.expectEqual(@as(usize, 0), fixture.bindings[0].chunks);
    try std.testing.expectEqual(body.BodyReadiness.ready, fixture.driver.slots[0].body.readiness);
    try std.testing.expect(!fixture.session.body_receive.?.paused[0]);
    try std.testing.expectEqual(@as(u64, 6), fixture.driver.slots[0].body.observed);
    try fixture.flush();
    try std.testing.expectEqualStrings("abcdef", fixture.bindings[0].bytes[0..6]);
    try std.testing.expectEqual(@as(usize, 1), fixture.bindings[0].ends);
    try std.testing.expectEqual(@as(usize, 2), try frame_count(&fixture, .headers, 1));
    try expect_status(&fixture, 1, 0, "100");
    try expect_status(&fixture, 1, 1, "200");
    var empty = Fixture{};
    try empty.init();
    try empty.fill_output(0);
    try empty.head(1, "0", true, true);
    try std.testing.expectEqual(@as(usize, 0), empty.bindings[0].ends);
    try empty.flush();
    try std.testing.expectEqual(@as(usize, 1), empty.bindings[0].ends);
}

test "http2 upload: public resume while Continue blocked updates real readiness without delivery" {
    var fixture = Fixture{ .pause_begin = true };
    try fixture.init();
    try fixture.fill_output(0);
    try fixture.head(1, "3", true, false);
    try fixture.frame(.data, 1, 1, "abc");
    try fixture.bindings[0].control.@"resume"();
    try std.testing.expectEqual(@as(usize, 0), fixture.bindings[0].chunks);
    try std.testing.expect(!fixture.session.body_receive.?.paused[0]);
    try fixture.flush();
    try std.testing.expectEqual(@as(usize, 1), fixture.bindings[0].chunks);
    try std.testing.expectEqual(@as(usize, 1), fixture.bindings[0].ends);
}

test "http2 upload: final-byte pause and empty paused upload require explicit resume" {
    var fixture = Fixture{ .pause_prefix = 3 };
    try fixture.init();
    try fixture.head(1, "3", false, false);
    try fixture.frame(.data, 1, 1, "abc");
    try std.testing.expectEqual(@as(usize, 0), fixture.bindings[0].ends);
    try fixture.bindings[0].control.@"resume"();
    try std.testing.expectEqual(@as(usize, 1), fixture.bindings[0].ends);
    var empty = Fixture{ .pause_begin = true };
    try empty.init();
    try empty.head(1, "0", false, true);
    try std.testing.expectEqual(@as(usize, 0), empty.bindings[0].ends);
    try empty.bindings[0].control.@"resume"();
    try std.testing.expectEqual(@as(usize, 1), empty.bindings[0].ends);
}

test "http2 upload: limits while Continue blocked cancel once and final precedes reset" {
    var fixture = Fixture{};
    try fixture.init();
    fixture.definition.limits.max_body_bytes = 3;
    try fixture.fill_output(0);
    try fixture.head(1, null, true, false);
    try fixture.frame(.data, 0, 1, "abc");
    try fixture.frame(.data, 0, 1, "d");
    try std.testing.expectEqual(@as(usize, 0), fixture.bindings[0].chunks);
    try std.testing.expectEqual(@as(usize, 1), fixture.bindings[0].cancels);
    try std.testing.expectEqual(body.BodyCancelReason.body_too_large, fixture.bindings[0].reason.?);
    try std.testing.expectEqual(@as(usize, 0), fixture.session.pending_reset_count);
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[0]);
    try fixture.flush();
    const first = try wire.FrameHeader.parse(fixture.output[0..9]);
    // Credit may precede the response, but the reset must follow final HEADERS.
    _ = first;
    var cursor: usize = 0;
    var final_seen = false;
    while (cursor < fixture.output_length) {
        const header = try wire.FrameHeader.parse(fixture.output[cursor..][0..9]);
        if (header.frame_type == @intFromEnum(wire.FrameType.headers)) {
            try std.testing.expect(header.flags & 1 != 0);
            final_seen = true;
        }
        if (header.frame_type == @intFromEnum(wire.FrameType.rst_stream)) try std.testing.expect(final_seen);
        cursor += 9 + header.payload_length;
    }
    try std.testing.expect(final_seen);
    try expect_status(&fixture, 1, 0, "413");
    try std.testing.expectEqual(@as(i64, 65535), fixture.session.connection.connection_receive_window);
    try std.testing.expectEqual(@as(usize, 1), fixture.begins);
}

test "http2 upload: declared refusal malformed full u64 and known EOF mismatch precede begin" {
    const lengths = [_][]const u8{ "4097", "18446744073709551615", "18446744073709551616", "-1", "1x" };
    for (lengths, 0..) |length, index| {
        var fixture = Fixture{};
        try fixture.init();
        try fixture.head(1, length, true, false);
        try std.testing.expectEqual(@as(usize, 0), fixture.begins);
        try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[0]);
        if (index < 2) try expect_status(&fixture, 1, 0, "413");
    }
    var mismatch = Fixture{};
    try mismatch.init();
    try mismatch.head(1, "1", true, true);
    try std.testing.expectEqual(@as(usize, 0), mismatch.begins);
    var maximum = Fixture{};
    try maximum.init();
    maximum.definition.limits.max_body_bytes = std.math.maxInt(u64);
    try maximum.head(1, "18446744073709551615", false, false);
    try std.testing.expectEqual(@as(usize, 1), maximum.begins);
    try std.testing.expectEqual(std.math.maxInt(u64), maximum.driver.slots[0].body.declared.?);
    try maximum.bindings[0].control.cancel();
}

test "http2 upload: missing and undersized physical pools refuse before begin" {
    var missing = Fixture{};
    try missing.init();
    missing.session.body_receive = null;
    try missing.head(1, "100", true, false);
    try std.testing.expectEqual(@as(usize, 0), missing.begins);
    try std.testing.expectEqual(@as(usize, 1), try frame_count(&missing, .headers, 1));
    try expect_status(&missing, 1, 0, "503");
    var small = Fixture{};
    try small.init();
    var payload: [1024]u8 = undefined;
    var blocks: [1]support.http2_body_queue.Block = undefined;
    var streams: [4]support.http2_body_queue.Stream = undefined;
    small.session.body_receive.?.queue = try support.http2_body_queue.init(.{ .payload = &payload, .blocks = &blocks, .streams = &streams });
    try small.head(1, "100", true, false);
    try std.testing.expectEqual(@as(usize, 0), small.begins);
    try std.testing.expectEqual(@as(usize, 1), try frame_count(&small, .headers, 1));
    try expect_status(&small, 1, 0, "503");
}

test "http2 upload: quota and failed begin roll back exactly once" {
    var fixture = Fixture{};
    try fixture.init();
    fixture.definition.limits.max_active = 1;
    try fixture.router.use(&fixture, middleware);
    try fixture.head(1, null, false, false);
    try fixture.head(3, null, true, false);
    try std.testing.expectEqual(@as(usize, 1), fixture.begins);
    try std.testing.expectEqual(@as(usize, 2), fixture.middleware_calls);
    try expect_status(&fixture, 3, 0, "503");
    try std.testing.expect(std.mem.indexOf(u8, fixture.output[0..fixture.output_length], "x-saved") != null);
    try std.testing.expectEqual(@as(u16, 1), fixture.router.body.active[0]);
    try fixture.bindings[0].control.cancel();
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[0]);
    var failed = Fixture{ .fail_begin = true };
    try failed.init();
    try failed.head(1, null, true, false);
    try std.testing.expectEqual(@as(usize, 1), failed.begins);
    try std.testing.expectEqual(@as(usize, 0), failed.bindings[0].cancels);
    try std.testing.expectEqual(@as(u16, 0), failed.router.body.active[0]);
}

test "http2 upload: callback local resets defer metadata and terminal release through unwind" {
    for ([_]ResetDuring{ .begin, .chunk, .end }) |phase| {
        var fixture = Fixture{ .reset_during = phase };
        try fixture.init();
        try fixture.head(1, "3", false, false);
        if (phase != .begin) try fixture.frame(.data, 1, 1, "abc");
        try std.testing.expect(fixture.metadata_ok);
        try std.testing.expect(!fixture.control_failure);
        try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[0]);
        try std.testing.expectEqual(@as(usize, if (phase == .end) 1 else 0), fixture.bindings[0].ends);
        try std.testing.expectEqual(@as(usize, if (phase == .end) 0 else 1), fixture.bindings[0].cancels);
        try std.testing.expectError(error.BodyControlExpired, fixture.bindings[0].control.cancel());
    }
}

test "http2 upload: sink error and end error have one terminal and resumed failure is reported" {
    var chunk_failure = Fixture{ .fail_chunk = true };
    try chunk_failure.init();
    try chunk_failure.head(1, "3", false, false);
    try chunk_failure.frame(.data, 1, 1, "abc");
    try std.testing.expectEqual(@as(usize, 1), chunk_failure.bindings[0].cancels);
    try std.testing.expectEqual(body.BodyCancelReason.sink_failure, chunk_failure.bindings[0].reason.?);
    var end_failure = Fixture{ .fail_end = true, .pause_prefix = 3 };
    try end_failure.init();
    try end_failure.head(1, "3", false, false);
    try end_failure.frame(.data, 1, 1, "abc");
    try std.testing.expectError(error.BodyDeliveryFailed, end_failure.bindings[0].control.@"resume"());
    try std.testing.expectEqual(@as(usize, 1), end_failure.bindings[0].ends);
    try std.testing.expectEqual(@as(usize, 0), end_failure.bindings[0].cancels);
    try std.testing.expectEqual(@as(u16, 0), end_failure.router.body.active[0]);
}

test "http2 upload: accepted connection credit and blocked stream credit retry independently" {
    var fixture = Fixture{};
    try fixture.init();
    try fixture.head(1, null, false, false);
    try fixture.fill_output(13);
    try fixture.frame(.data, 0, 1, "abc");
    try std.testing.expectEqual(@as(i64, 65535), fixture.session.connection.connection_receive_window);
    try std.testing.expectEqual(@as(u32, 0), fixture.session.body_receive.?.connection_pending);
    try std.testing.expectEqual(@as(u32, 3), fixture.session.body_receive.?.stream_pending[0]);
    try fixture.flush();
    try std.testing.expectEqual(@as(usize, 0), try frame_count(&fixture, .window_update, 0));
    try std.testing.expectEqual(@as(usize, 1), try frame_count(&fixture, .window_update, 1));
    try fixture.bindings[0].control.cancel();
    try std.testing.expectEqual(@as(i64, 65535), fixture.session.connection.connection_receive_window);
}

test "http2 upload: padding refunds separately and reset reclaims queued credit once" {
    var fixture = Fixture{ .pause_begin = true };
    try fixture.init();
    try fixture.head(1, null, false, false);
    try fixture.frame(.data, 8, 1, "\x03abc000");
    try std.testing.expectEqual(@as(i64, 65532), fixture.session.connection.connection_receive_window);
    try std.testing.expectEqual(@as(u64, 3), fixture.driver.slots[0].body.observed);
    try fixture.fill_output(0);
    try fixture.bindings[0].control.cancel();
    try std.testing.expectEqual(@as(u32, 3), fixture.session.body_receive.?.connection_pending);
    try std.testing.expectEqual(@as(u32, 0), fixture.session.body_receive.?.stream_pending[0]);
    try fixture.flush();
    try std.testing.expectEqual(@as(i64, 65535), fixture.session.connection.connection_receive_window);
    try std.testing.expectEqual(@as(usize, 1), try frame_count(&fixture, .window_update, 0));
    try fixture.flush();
    try std.testing.expectEqual(@as(usize, 0), try frame_count(&fixture, .window_update, 0));
}

test "http2 upload: trailers preserve initial metadata and pending middleware headers" {
    var fixture = Fixture{ .pause_begin = true };
    try fixture.init();
    try fixture.router.use(&fixture, middleware);
    try fixture.head(1, "3", false, false);
    try fixture.frame(.data, 0, 1, "abc");
    var trailer: [80]u8 = undefined;
    var used: usize = 0;
    try literal(&trailer, &used, "x-initial", "trailer");
    try fixture.frame(.headers, 5, 1, trailer[0..used]);
    try std.testing.expectEqualStrings("retained", fixture.session.requests[0].get_header("x-initial").?);
    try fixture.bindings[0].control.@"resume"();
    try std.testing.expectEqual(@as(usize, 1), fixture.middleware_calls);
    try std.testing.expect(fixture.metadata_ok);
    try std.testing.expect(std.mem.indexOf(u8, fixture.output[0..fixture.output_length], "x-saved") != null);
}

fn middleware(context: *anyopaque, request: *Request, response: *Response) radix.MiddlewareResult {
    const fixture: *Fixture = @ptrCast(@alignCast(context));
    fixture.middleware_calls += 1;
    fixture.metadata_ok = fixture.metadata_ok and request.body.len == 0;
    response.append_header("x-saved", "middleware") catch {
        fixture.control_failure = true;
    };
    return .continue_dispatch;
}

test "http2 upload: missing capture matrix refuses and sibling slots retain isolated metadata" {
    var unavailable = Fixture{};
    try unavailable.init();
    unavailable.driver.capture_names = &.{};
    unavailable.driver.capture_values = &.{};
    try unavailable.head(1, null, false, false);
    try std.testing.expectEqual(@as(usize, 0), unavailable.begins);
    var fixture = Fixture{ .pause_begin = true };
    try fixture.init();
    try fixture.head(1, null, false, false);
    try fixture.head(3, null, false, false);
    try fixture.frame(.data, 0, 1, "first");
    try fixture.frame(.data, 0, 3, "second");
    try fixture.bindings[0].control.cancel();
    try std.testing.expectEqual(@as(usize, 0), fixture.bindings[1].cancels);
    try std.testing.expectEqualStrings("retained", fixture.session.requests[1].get_header("x-initial").?);
    try fixture.bindings[1].control.@"resume"();
    try std.testing.expectEqualStrings("second", fixture.bindings[1].bytes[0..6]);
    try fixture.bindings[1].control.cancel();
    try std.testing.expectEqual(@as(u16, 0), fixture.router.body.active[0]);
}

test "http2 upload: twenty captures stay isolated across sibling trailers and final output pressure" {
    var fixture = Fixture{ .pause_begin = true };
    try fixture.init();
    try fixture.router.route_body(.post, "/upload/:name/:b/:c/:d/:e/:f/:g/:h/:i/:j/:k/:l/:m/:n/:o/:p/:q/:r/:s/:t", &fixture.definition);
    const first = "/upload/a/b/c/d/e/f/g/h/i/j/k/l/m/n/o/p/q/r/s/first";
    const second = "/upload/z/y/x/w/v/u/t/s/r/q/p/o/n/m/l/k/j/i/h/second";
    try fixture.head_path(1, first, "1", false, false);
    try fixture.head_path(3, second, "1", false, false);
    try std.testing.expectEqual(@as(usize, 4), fixture.session.requests[0].extra_param_count);
    try std.testing.expectEqualStrings("first", fixture.session.requests[0].get_param("t").?);
    try std.testing.expectEqualStrings("second", fixture.session.requests[1].get_param("t").?);
    try fixture.frame(.data, 1, 1, "a");
    try fixture.frame(.data, 0, 3, "b");
    var trailer: [80]u8 = undefined;
    var used: usize = 0;
    try literal(&trailer, &used, "x-initial", "trailer");
    try fixture.frame(.headers, 5, 3, trailer[0..used]);
    try fixture.fill_output(0);
    fixture.expected_active_in_end = 2;
    try fixture.bindings[0].control.@"resume"();
    try std.testing.expectEqualStrings(first, fixture.session.requests[0].path);
    try std.testing.expectEqualStrings("first", fixture.session.requests[0].get_param("t").?);
    try std.testing.expectEqualStrings("retained", fixture.session.requests[1].get_header("x-initial").?);
    fixture.expected_active_in_end = 1;
    try fixture.bindings[1].control.@"resume"();
    try std.testing.expectEqualStrings("second", fixture.session.requests[1].get_param("t").?);
    try std.testing.expectEqual(@as(usize, 1), fixture.bindings[0].ends);
    try std.testing.expectEqual(@as(usize, 1), fixture.bindings[1].ends);
    try fixture.flush();
    try std.testing.expectEqual(@as(usize, 0), fixture.session.requests[0].path.len);
    try std.testing.expectEqual(@as(usize, 0), fixture.session.requests[1].path.len);
    try std.testing.expect(fixture.metadata_ok);
}

test "http2 upload: middleware capacity preflight and admission reset precede begin" {
    var capacity = Fixture{};
    try capacity.init();
    try capacity.router.use(&capacity, middleware);
    capacity.session.response_header_stride = 16;
    try capacity.head(1, null, true, false);
    try std.testing.expectEqual(@as(usize, 0), capacity.begins);
    try std.testing.expectEqual(@as(u16, 0), capacity.router.body.active[0]);
    try std.testing.expectEqual(@as(usize, 1), try frame_count(&capacity, .headers, 1));
    try expect_status(&capacity, 1, 0, "503");
    var reset = Fixture{ .reset_during = .admission };
    try reset.init();
    try reset.head(1, null, true, false);
    try std.testing.expectEqual(@as(usize, 0), reset.begins);
    try std.testing.expectEqual(@as(u16, 0), reset.router.body.active[0]);
    try std.testing.expect(reset.metadata_ok);
    try std.testing.expect(!reset.control_failure);
}

test "http2 upload: exact limit succeeds and held FIFO detects excess declared length once" {
    var exact = Fixture{};
    try exact.init();
    exact.definition.limits.max_body_bytes = 3;
    try exact.head(1, "3", false, false);
    try exact.frame(.data, 1, 1, "abc");
    try std.testing.expectEqual(@as(usize, 1), exact.bindings[0].ends);
    var overflow = Fixture{ .pause_begin = true };
    try overflow.init();
    try overflow.head(1, "3", false, false);
    try overflow.frame(.data, 0, 1, "abc");
    try overflow.frame(.data, 1, 1, "d");
    try std.testing.expectEqual(@as(usize, 0), overflow.bindings[0].chunks);
    try std.testing.expectEqual(@as(usize, 1), overflow.bindings[0].cancels);
    try std.testing.expectEqual(body.BodyCancelReason.invalid_body, overflow.bindings[0].reason.?);
    try std.testing.expectEqual(@as(i64, 65535), overflow.session.connection.connection_receive_window);
}

test "http2 upload: nullable streaming callbacks preserve legacy buffering refusal and credit retry" {
    var buffered = Fixture{ .legacy = true };
    try buffered.init();
    try buffered.head(1, "3", false, false);
    try buffered.fill_output(13);
    try buffered.frame(.data, 1, 1, "abc");
    try std.testing.expectEqual(@as(usize, 0), buffered.begins);
    try std.testing.expectEqual(@as(usize, 1), buffered.buffered_calls);
    try std.testing.expectEqual(@as(usize, 3), buffered.buffered_bytes);
    try std.testing.expectEqual(@as(u32, 3), buffered.session.body_receive.?.stream_pending[0]);
    try buffered.flush();
    try std.testing.expectEqual(@as(usize, 0), try frame_count(&buffered, .window_update, 0));
    try std.testing.expectEqual(@as(usize, 1), try frame_count(&buffered, .window_update, 1));
    var refused = Fixture{ .legacy = true, .legacy_refusal = true };
    try refused.init();
    try refused.head(1, null, false, false);
    try refused.fill_output(0);
    try refused.frame(.data, 1, 1, "abc");
    try std.testing.expectEqual(@as(usize, 0), refused.begins);
    try std.testing.expectEqual(@as(usize, 0), refused.buffered_calls);
    try refused.flush();
    try std.testing.expectEqual(@as(i64, 65535), refused.session.connection.connection_receive_window);
}

test "http2 upload: enabled carve is bounded and default storage has no receive region" {
    const off = Session.default_capacities;
    const on = Session.Capacities{ .stream_request_bodies = true };
    const disabled_bytes = comptime try Session.storage_bytes(off);
    const enabled_bytes = comptime try Session.storage_bytes(on);
    var region: [enabled_bytes]u8 align(Session.storage_alignment) = undefined;
    const disabled = try Session.carve_storage(region[0..disabled_bytes], off);
    try std.testing.expect(disabled.body_receive == null);
    const enabled = try Session.carve_storage(&region, on);
    const pool = try support.http2_body_queue.required_capacity(4);
    try std.testing.expectEqual(pool.payload_bytes, enabled.body_receive.?.queue.storage.payload.len);
    try std.testing.expectEqual(pool.block_count, enabled.body_receive.?.queue.storage.blocks.len);
    try std.testing.expectError(error.InvalidHttp2Capacity, Session.carve_storage(region[0 .. enabled_bytes - 1], on));
    var bundle = Session.Bundle(off){};
    try std.testing.expect(bundle.storage().body_receive == null);
}

const StorageRange = struct { start: usize, length: usize, alignment: usize };

fn storage_range(comptime T: type, values: []T) StorageRange {
    return .{ .start = @intFromPtr(values.ptr), .length = values.len * @sizeOf(T), .alignment = @alignOf(T) };
}

fn check_storage_ranges(comptime S: type, storage: S.Storage, start: usize, length: usize, alignment_floor: usize) !void {
    const state = storage.body_receive.?;
    const ranges = [_]StorageRange{
        storage_range(Request, storage.requests),
        storage_range(u8, storage.request_storage),
        storage_range(u8, storage.body_storage),
        storage_range(u8, storage.response_header_storage),
        storage_range(u8, storage.response_body_storage),
        storage_range(support.http2_hpack.Header, storage.decoded_headers),
        storage_range(u8, storage.decoded_header_bytes),
        storage_range(support.http2_hpack.DynamicEntry, storage.dynamic_entries),
        storage_range(u8, storage.dynamic_bytes),
        storage_range(u8, storage.header_block),
        storage_range(u8, storage.frame_buffer),
        storage_range(support.http2_hpack.Header, storage.response_fields),
        storage_range(u8, storage.response_encode),
        storage_range(u8, storage.lowercase_names),
        storage_range([]const u8, storage.header_extra_names),
        storage_range([]const u8, storage.header_extra_values),
        storage_range(S.ReceiveState, state[0..1]),
        storage_range(u8, state.queue.storage.payload),
        storage_range(support.http2_body_queue.Block, state.queue.storage.blocks),
        storage_range(support.http2_body_queue.Stream, state.queue.storage.streams),
    };
    for (ranges, 0..) |range, index| {
        if (range.length == 0) continue;
        try std.testing.expectEqual(@as(usize, 0), range.start % @max(range.alignment, alignment_floor));
        try std.testing.expect(range.start >= start and range.start + range.length <= start + length);
        for (ranges[0..index]) |previous| {
            if (previous.length == 0) continue;
            try std.testing.expect(range.start + range.length <= previous.start or previous.start + previous.length <= range.start);
        }
    }
}

fn check_bundle_carve(comptime count: usize, comptime nonaligned: bool) !void {
    const S = server.server_session(count);
    const caps = S.Capacities{
        .stream_request_bodies = true,
        .header_block_size = if (nonaligned) 257 else 512,
        .request_header_size = if (nonaligned) 4097 else 4096,
        .body_size = if (nonaligned) 17 else 16,
        .response_header_size = if (nonaligned) 2049 else 2048,
        .response_header_count = 33,
        .decoded_header_count = 65,
        .dynamic_table_size = if (nonaligned) 1025 else 1024,
    };
    const bytes = comptime try S.storage_bytes(caps);
    var region: [bytes + S.storage_alignment]u8 align(S.storage_alignment) = undefined;
    const aligned = try S.carve_storage(region[0..bytes], caps);
    try check_storage_ranges(S, aligned, @intFromPtr(&region), bytes, 1);
    const unaligned = try S.carve_storage(region[1..], caps);
    try check_storage_ranges(S, unaligned, @intFromPtr(region[1..].ptr), region.len - 1, 1);
    var bundle = S.Bundle(caps){};
    const storage = bundle.storage();
    try check_storage_ranges(S, storage, @intFromPtr(&bundle), @sizeOf(@TypeOf(bundle)), S.storage_alignment);
    _ = try S.init(storage);
    const pool = try support.http2_body_queue.required_capacity(count);
    try std.testing.expectEqual(pool.payload_bytes, storage.body_receive.?.queue.storage.payload.len);
    try std.testing.expectEqual(pool.block_count, storage.body_receive.?.queue.storage.blocks.len);
    var disabled = S.Bundle(.{}){};
    try std.testing.expect(disabled.storage().body_receive == null);
    try std.testing.expectEqual(@as(usize, 0), disabled.receive.len);
    try std.testing.expectEqual(@as(usize, 0), disabled.queue_payload.len);
    try std.testing.expectEqual(@as(usize, 0), disabled.queue_blocks.len);
    try std.testing.expectEqual(@as(usize, 0), disabled.queue_streams.len);
    const optional_pointers = [_]usize{ @intFromPtr(&disabled.receive), @intFromPtr(&disabled.queue_payload), @intFromPtr(&disabled.queue_blocks), @intFromPtr(&disabled.queue_streams) };
    for (optional_pointers) |pointer| {
        try std.testing.expectEqual(@as(usize, 0), pointer % S.storage_alignment);
        try std.testing.expect(pointer >= @intFromPtr(&disabled) and pointer <= @intFromPtr(&disabled) + @sizeOf(@TypeOf(disabled)));
    }
}

test "http2 upload: Bundle and carve cover metadata residues and nonaligned capacities" {
    inline for (.{ 1, 2, 3, 4, 8 }) |count| {
        try check_bundle_carve(count, false);
        try check_bundle_carve(count, true);
    }
}
