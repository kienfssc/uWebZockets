# Independent admission/H1 review: v3

Reviewer /root/review_h2_shared_admission. P2, server.zig1648: generated413 after
accepted unknown-length DATA exceeds route limit uses empty headers. Saved fitting
CORS/security/middleware bytes are only restored on driver.end (http2_upload174),
not cancellation/failure. Existing H1 tcp_upload.fail uses restored_response.
Route this refusal through a fresh Response carrying saved headers while keeping
final/reset ordering, cancellation once and quota ordering. Add encoded regression
with headers_only middleware plus real DATA overflow; existing overflow test has
no middleware.

No other actionable admission, H1 compatibility, capture-lifetime or structural
finding. Read-only; no checks rerun. No native/TLS/lifecycle/full-runtime approval.
