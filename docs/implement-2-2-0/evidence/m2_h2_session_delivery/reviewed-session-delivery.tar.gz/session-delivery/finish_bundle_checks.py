from pathlib import Path
import subprocess,sys
out=Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/session-delivery')
for stage,driver in [('before','finish_prealign_driver.py'),('after','finish_driver.py')]:
 for name,target in [('macos','aarch64-macos'),('windows','x86_64-windows-gnu')]:
  r=subprocess.run([sys.executable,str(out/driver),'layout','finish-bundle-'+stage+'-'+name,'ReleaseSafe',target,'/tmp/uwz-m2-h2-session-delivery-artifacts/finish-bundle-layout.zig'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(stage,name,r.returncode,flush=True)
for label,driver in [('baseline','finish_baseline_driver.py'),('final','finish_driver.py')]:
 r=subprocess.run([sys.executable,str(out/driver),'layout','finish-disabled-'+label,'ReleaseSafe','native','/tmp/uwz-m2-h2-session-delivery-artifacts/finish-disabled-layout.zig'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print('disabled',label,r.returncode,flush=True)
