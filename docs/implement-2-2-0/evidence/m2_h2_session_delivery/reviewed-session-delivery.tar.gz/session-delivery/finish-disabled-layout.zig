const s=@import("test_support");
comptime {
 @setEvalBranchQuota(100000);
 for (.{1,2,3,4,8}) |count| {
  const S=s.http2_server.server_session(count);
  const c=S.Capacities{.header_block_size=257,.request_header_size=4097,.body_size=17,.response_header_size=2049,.response_header_count=33,.decoded_header_count=65,.dynamic_table_size=1025};
  @compileLog("disabled",count,S.storage_bytes(c));
 }
}
