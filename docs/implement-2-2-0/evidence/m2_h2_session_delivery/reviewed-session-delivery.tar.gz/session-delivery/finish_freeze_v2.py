from pathlib import Path
import hashlib,json,difflib,shutil,stat,tarfile
root=Path('/workspaces/uWebZockets');out=root/'.uwz-work/evidence/h2-streaming/session-delivery';base=Path('/tmp/uwz-m2-h2-body-queue');source=Path('/tmp/uwz-m2-h2-session-delivery');art=Path('/tmp/uwz-m2-h2-session-delivery-artifacts')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(path):
 rows=[]
 for p in sorted(path.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():
   assert stat.S_ISREG(p.stat().st_mode) and p.stat().st_nlink==1,p
   rows.append((str(p.relative_to(path)),sha(p)))
 return rows
def digest(rows):return hashlib.sha256(json.dumps(rows).encode()).hexdigest()
a=manifest(base);b=manifest(source);assert digest(a)=='580199bc84e81779dd050943fc0b1bb7a9b8f1af113fcb28e7fab560fc105af6'
ad=dict(a);bd=dict(b);changed=[n for n in sorted(set(ad)|set(bd)) if ad.get(n)!=bd.get(n)];patch=[]
for name in changed:
 old=(base/name).read_text() if name in ad else '';new=(source/name).read_text() if name in bd else ''
 for folder,origin,exists in [('final-v2',source,name in bd),('preimages-v2',base,name in ad)]:
  if not exists:continue
  target=out/folder/name;assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(origin/name,target)
 patch.append('diff --git a/'+name+' b/'+name+'\n')
 patch.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+name if name in ad else '/dev/null',tofile='b/'+name if name in bd else '/dev/null'))
(out/'session-delivery-v2.patch').write_text(''.join(patch));(out/'finish-final-source-v2.json').write_text(json.dumps(b,indent=2)+'\n')
archive=art/'finish-frozen-source-v2.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for name,_ in b:tar.add(source/name,arcname=name,recursive=False)
record={'source':str(source),'file_count':len(b),'digest':digest(b),'baseline':str(base),'baseline_file_count':len(a),'baseline_digest':digest(a),'changed_paths':changed,'full_snapshot':str(archive),'full_snapshot_sha256':sha(archive),'patch_sha256':sha(out/'session-delivery-v2.patch'),'all_regular_no_hardlinks_or_symlinks':True}
(out/'finish-freeze-v2.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
