const s=@import("test_support");
comptime {
 @setEvalBranchQuota(100000);
 const S=s.http2_server.server_session(8);
 @compileLog("bundles8",@sizeOf(S.Bundle(.{})),@sizeOf(S.Bundle(.{.stream_request_bodies=true})),@sizeOf(S.Bundle(.{.request_header_size=1024})),@sizeOf(S.Bundle(.{.stream_request_bodies=true,.request_header_size=1024})));
 for (.{1,2,3,4,8}) |count| {
  const T=s.http2_server.server_session(count);
  const c=T.Capacities{.stream_request_bodies=true,.header_block_size=257,.request_header_size=4097,.body_size=17,.response_header_size=2049,.response_header_count=33,.decoded_header_count=65,.dynamic_table_size=1025};
  @compileLog("nonaligned",count,@sizeOf(T.Bundle(c)),T.storage_bytes(c));
 }
}
