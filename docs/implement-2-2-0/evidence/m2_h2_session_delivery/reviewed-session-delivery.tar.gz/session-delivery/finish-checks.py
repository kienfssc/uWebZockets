import subprocess,sys
from pathlib import Path
root=Path('/workspaces/uWebZockets')
driver=root/'.uwz-work/evidence/h2-streaming/session-delivery/finish_driver.py'
suites=['http2_tests','http2_hpack_tests','http2_server_tests','http2_body_queue_tests','body_h2_refusal_tests','body_h2_width_tests','http1_upload_admission_tests','http1_upload_driver_tests','body_h1_head_tests']
for mode in ['Debug','ReleaseSafe']:
 for suite in suites:
  label='finish-'+suite+'-'+mode
  cmd=[sys.executable,str(driver),'focused',label,mode,'native','src/tests/'+suite+'.zig']
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(label,'compile',r.returncode,flush=True)
  if r.returncode:print(r.stdout,flush=True);continue
  r=subprocess.run([sys.executable,str(driver),'run',label],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(label,'run',r.returncode,r.stdout.strip().splitlines()[-2:],flush=True)
  if r.returncode:print(r.stdout,flush=True)
