import subprocess,sys
from pathlib import Path
root=Path('/workspaces/uWebZockets');driver=root/'.uwz-work/evidence/h2-streaming/session-delivery/finish_driver.py'
app_filters=['body App: streaming config defaults off','body App: enabled slab contains typed owners','body App: startup stays unarmed','body App: registration copies path','body App: disabled registration and limits','body App: middleware policy registration','body App: null upload detach','body App: pure body registry']
for mode in ['Debug','ReleaseSafe']:
 for suite in ['http2_upload_driver_tests','http2_tests','http2_hpack_tests','http2_body_queue_tests','body_h2_refusal_tests','body_h2_width_tests','http1_upload_admission_tests','http1_upload_driver_tests','body_h1_head_tests','http2_server_tests','body_app_tests']:
  filters=app_filters if suite=='body_app_tests' else ['http2 server:'] if suite=='http2_server_tests' else []
  label='finish-final3-'+suite+'-'+mode
  r=subprocess.run([sys.executable,str(driver),'focused',label,mode,'native','src/tests/'+suite+'.zig']+filters,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(label,'compile',r.returncode,flush=True)
  if r.returncode:print(r.stdout,flush=True);continue
  r=subprocess.run([sys.executable,str(driver),'run',label],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(label,'run',r.returncode,r.stdout.strip().splitlines()[-2:],flush=True)
  if r.returncode:print(r.stdout,flush=True)
