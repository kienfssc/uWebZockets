# Independent protocol review: v3

Reviewer /root/review_h2_session_protocol. Request changes; read-only review,
no compiler/tests/native/socket/client runs. Supplied authoritative patch matched.
No separate structural maintainability defect beyond these correctness findings.

1. P1, server.zig1047: peer RST invokes notification/queue reclaim but does not
   flush connection_pending. A paused upload holding65535 bytes can be reset with
   no outstanding output; sibling DATA then stalls indefinitely. Flush after reset,
   preserving WouldBlock intent; test full-window peer reset and sibling progress.
2. P1, server.zig1777: buffered request_fn can reset/close its stream then return
   error. Error unwind clears callback_active but skips deferred notify/clear when
   identity is gone. initial_seen remains; reused slot treats next head as trailers.
   Apply success-equivalent unwind cleanup and test both reset/response-end then
   error, including streaming-disabled legacy behavior.
3. P2, server.zig1561: current DATA is refunded after callback error. If callback
   reset first, fail_body returns early at1632; prior reset flush preceded this
   refund. Flush closed-stream error-unwind credit and cover reset-then-error.

Reported selected tests/foreign compilation do not establish deferred native
activation or full acceptance. Stopped native experiment remains stopped.
