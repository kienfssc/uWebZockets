from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
root=Path('/workspaces/uWebZockets');source=Path('/tmp/uwz-m2-h2-session-delivery');draft=Path('/tmp/uwz-m2-h2-session-delivery-artifacts/finish-ast-copy-v3');out=root/'.uwz-work/evidence/h2-streaming/session-delivery'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(p):return [(str(f.relative_to(p)),sha(f)) for f in sorted(p.rglob('*')) if f.is_file() and 'graphify-out' not in f.relative_to(p).parts]
assert not draft.exists();shutil.copytree(source,draft);shutil.copytree(root/'graphify-out',draft/'graphify-out');assert manifest(source)==manifest(draft)
argv=[str(root/'.uwz-work/tools/graphify/bin/graphify'),'update','.'];env={k:os.environ[k] for k in ('PATH','HOME','LANG','LC_ALL','TMPDIR') if k in os.environ};env['PYTHONPATH']=str(root/'.uwz-work/tools/graphify')
record={'argv':argv,'cwd':str(draft),'environment':env,'source_before':manifest(draft),'executable_sha256':sha(Path(argv[0])),'graph_before':sha(draft/'graphify-out/graph.json')}
start=time.monotonic()
with (out/'finish-final3-ast-refresh.log').open('wb') as log:r=subprocess.run(argv,cwd=draft,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(exit_status=r.returncode,elapsed_seconds=time.monotonic()-start,source_after=manifest(draft),graph_after=sha(draft/'graphify-out/graph.json'))
(out/'finish-final3-ast-refresh.json').write_text(json.dumps(record,indent=2)+'\n');print((out/'finish-final3-ast-refresh.log').read_text(),end='');print('Exit status:',r.returncode);assert record['source_before']==record['source_after'];raise SystemExit(r.returncode)
