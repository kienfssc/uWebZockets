const s = @import("test_support");
const std = @import("std");
const S = s.http2_server.server_session(8);
const D = s.http2_upload.upload_driver(8);
fn layout(comptime name: []const u8, comptime T: type) void {
 @compileLog("type",name,@sizeOf(T),@alignOf(T));
 inline for (@typeInfo(T).@"struct".fields) |field| @compileLog("field",name,field.name,@offsetOf(T,field.name),@sizeOf(field.type),@alignOf(field.type));
}
comptime {
 @setEvalBranchQuota(100000);
 layout("Session8",S);layout("Storage",S.Storage);layout("Capacities",S.Capacities);layout("Callbacks",s.http2_server.Callbacks);
 layout("TcpConnection",s.tcp.TcpConnection);layout("Http1UploadStorage",s.http1_upload_storage.Http1UploadStorage);
 layout("ReceiveState",S.ReceiveState);layout("Driver",D);layout("DriverSlot",D.Slot);layout("AdmissionTarget",s.body_admission.Target);
 @compileLog("session_plans",S.storage_bytes(.{}),S.storage_bytes(.{.stream_request_bodies=true}));
 for (.{ s.config.ServerConfig{}, s.config.ServerConfig{.stream_request_bodies=true}, s.config.ServerConfig{.max_connections=8,.stream_request_bodies=true,.max_request_line_size=512,.max_header_size=1024,.max_body_size=256} },0..) |cfg,i| @compileLog("config",i,cfg.slab_bytes(),cfg.h2_session_bytes(),cfg.h2_capacities());
}
