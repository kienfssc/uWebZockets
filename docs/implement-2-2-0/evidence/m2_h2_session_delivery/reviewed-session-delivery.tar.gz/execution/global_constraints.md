# Accepted architecture and constraints
# HTTP/2 request-streaming architecture handoff

Architect: /root/architect_h2_request_streaming. Source-only handoff for M2;
no implementation, builds, probes or source edits were performed by architect.
Inspected baseline /tmp/uwz-m2-h1-plaintext-combined,1023files,digest
acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b.
Shared TCP integration must use the subsequent stable reviewed TLS baseline.

## Binding contract and corrected planning input

ADR0008 and 2.2.0-TODO.md M2 govern. Root's initial dispatch incorrectly named
2*W+2*F; Root withdrew that invented requirement before any changes. The accepted
pool bound remains round_up(65535 + max_streams*1023,1024): at8streams,73728
payload bytes plus432bytes of three-u16 metadata per block, before owner/alignment.
Do not double the pool or amend the ADR for that discarded formula.

Preserve buffered APIs, legacy nullableusize Content-Length and distinct fullu64
streaming declaration, M1 producers/files, existing capacities and helper errors.
No dependency adoption or native retirement redesign. No native fault/schedule/
interleaving/race/crash/leak/invalid-fd/resource/kernel/registration/injected-
completion/panic probes. Ordinary actual protocol/API clients and real pure
caller-owned operations are separate verification paths.

## Source-backed hazards and earned seams

- server.zig31/1266: keep read-only selection/provisional framing separate from
  an explicit admission/delivery contract; don't silently make selector reentrant.
- server.zig1364 and connection.zig495: current DATA buffering restores both
  receive windows before WINDOW_UPDATE output. Streaming needs independently
  durable, validated and committed connection/stream credit intents.
- server.zig1689/1728/1751: preserve actual final-frame acceptance and reset FIFO;
  send_reset currently clears a stream even under an active callback. Defer
  borrowed storage recycling through callback unwind.
- tcp.zig725: connection-shared route captures cannot retain concurrent streams.
  Enabled H2 needs per-stream captures and initial metadata through response life.
- app.zig717/http1_upload.zig92: extract actual transport-neutral App admission
  and reserve_and_arm for H1/H2 reuse. Never manufacture an H1 HeadReady for H2.
- tcp.zig3003/app.zig645: native connection close currently terminalizes H1 only.
  H2 must join existing delivery borrow and cause-preserving close/shutdown paths.

Three responsibilities: protocol block queue/credit transitions under http2;
concrete sink/BodyState/reservation/control driver under core; canonical route,
middleware and admission policy under router. Deleting queue/shared admission
would scatter fragmentation/credit or routing/middleware invariants across paths.
No generic continuation framework or forwarding-only adapter is justified.

## Storage and generation decision

Extend Session.Capacities/Storage/planning/carving/Bundle with default-disabled
optional queue storage; carve enabled-only per-stream upload owner/control state
in config. Queue is independent of positive buffered body_stride. Preserve control
generations outside transient Request resets across stream and connection reuse.
Use named data/callback aliases and additive defaulted optional contract fields.
Measure/report any default Session/Storage/Callback/TCP pointer or slice growth;
disabled configurations allocate no queue or per-stream upload owners. No assumed
zero growth and no unexplained assertion changes. Check all arithmetic/index
sentinels on eligible32bit targets and exact enabled/disabled layouts on3OS.

## Ordered slices and acceptance

1. Protocol queue/credit/startup, http_protocol with DX/transport guidance:
   focused http2/body_queue.zig, connection.zig, server.zig; serialized config.
   1024byte blocks with next/read/write metadata and per-stream head/tail. Fill
   tail, never compact consumed head or credit it early. Check sizing/rounding/
   alignment/index representability. Validate each WINDOW_UPDATE before writing;
   commit its receive-window scope only after the complete frame is accepted.
   WouldBlock retains intent; connection success then blocked stream update must
   not duplicate connection credit. Reset reclaims connection credit once and
   drops obsolete stream intent; padding becomes immediately eligible. Missing/
   undersized low-level pool refuses BodyIngressUnavailable/503 before begin/100.
   Caller-owned tests: fragmentation, partial heads, padding, reset/reuse, blocked
   output, checked arithmetic and unchanged disabled/buffered storage.

2. Shared admission/metadata, dx_router with protocol guidance:
   App, focused router policy module, H1 head/reservation adapters and cold config.
   Extract only neutral policy/reserve; retain H1 framing/upgrade/physical logic.
   H2 facts name stable Request, streamID/index, declared?u64, END_STREAM, earlydata,
   physical availability and metadata capacity. Preserve HEAD/ANY/buffered/QUERY/
   extended-CONNECT precedence, globals/order/latepolicy/quota/rollback. Per-stream
   captures and initial headers stay pinned through output. Preserve middleware
   headers in idle per-stream response-header bytes at min(2048,response_stride);
   preflight before begin, restore into fresh terminal Response before encoding.
   Keep all H1 checks and add real H2 head/refusal/metadata boundary cases.

3. Complete concrete delivery/output, http_protocol with transport:
   server, core/http2_upload.zig, cold owners and centralized tests. Reserve/arm,
   begin/rollback/accept and exactly one terminal. Status100 HEADERS has no END_STREAM,
   independent final metadata and persistent output retry; no repeated begin or
   lost DATA while blocked. Observe new payload once, queue remainder, validate
   accepted prefixes via common BodyState. Real resume drains queued input first,
   handles pending EOF with no bytes, then credit; final-byte pause requires resume.
   Validate/discard trailers without overwriting initial metadata. End requires
   exact length, valid trailers, empty queue and readiness. Keep HPACK decoding for
   refused/closed/locally reset streams. Generalize early-final refusal: NO_ERROR
   reset follows actual final HEADERS/DATA acceptance, retaining v6 hard-writer
   guard and ordered retry. Test complete large logical delivery beyond buffered
   stride, Continue/refusals, paused trailers, u64 headers/32bit, pressure/siblings.

4. Callback lifetime/TLS composition, transport with protocol/crypto:
   waits stable TLS source, then serialized TCP/App glue. Wire actual headers/DATA/
   completion/reset/drain and control contexts. Pin stream storage across every
   admission/sink/terminal callback; local reset/end may retire identity but cannot
   clear arrays/owners/captures until unwind. Use existing native delivery borrow,
   preserve first cause on close/timeout/peer/shutdown, cancel all accepted streams
   once before native owner release. Invalidate generation before notification,
   release quota after it. End error aborts without second cancel. Independent
   producer context/scratch and retained metadata survive upload cleanup. Paused
   stream must not stop connection parsing/TLS control or M1 output/timeout coverage.
   Pure callback-unwind/reset/reuse and ordinary owned lifecycle evidence required;
   no native scheduling/fault experiments.

5. Actual owned H2-over-TLS proof, verification then review/integration:
   exact100000000 logical bytes with independent bounded count/SHA256. Old live503
   proof sentZERO bytes and cannot satisfy this. Cover partial/final pauses,
   empty/exact/overlimit/100, queued trailers/padding, concurrent routes/healthy
   sibling, output pressure, metadata after binding reuse/producer completion,
   public cancel, ordinary disconnect/enderror/drained shutdown. Retain complete
   source/compiler/client/capacity/override identities and raw results.

## Fragmentation proof

connection.zig13/366 initializes connection credit65535; settings don't enlarge it.
DATA debits its complete payload including padding at745. Let H be bytes held in
occupied blocks including consumed prefixes: no credit returns for those bytes,
so H<=65535. Every occupied stream has at most one partially filled tail; other
blocks stay full even when their head prefix is consumed. Occupied capacity is
therefore <=H+max_streams*1023. Reclaimed blocks are free before credit is advertised;
pending credit remains debited until accepted output. Raising connection credit,
crediting head prefixes early or creating extra fragmented tails breaks the proof.

Pause retains stream input while connection parsing/control/output continues;
exhausting shared connection credit may block all inbound DATA, as the ADR states.
No unconditional sibling upload progress or output-context lifetime extension is
invented. Plan acceptance is not H2 capability or implementation acceptance.

Required gates remain full applicable formatting/conventions/version/docs/forks/
package checks; Debug/RS, sanitizers/separateMSan, enabled/disabled layouts, foreign/
32bit compilation, fuzz/OSS-Fuzz, examples/consumer/ReleaseFast, H1 compliance,
H2/HPACK regressions and shared-I/O Autobahn. NativeWindows and maintained adoption
remain explicit outstanding requirements. Root must scope/approve execution
against the stable composed TLS/constructor baseline before assigning code.

## Global Constraints

- Follow AGENTS/CODING, Zig0.16, named explicit data, no allocation/I/O/log/clock
  in queue/credit operations, no anytype or reflective type construction.
- Execution baseline is now frozen reviewed composed TLS/constructor source
  /tmp/uwz-m2-h1-tls-configured-combined,1023files,digest
  89dce088f5684c9173c45c572e785e7ff9c57991eb152ec76c46a58db481479d.
  Its selected35 tests pass Debug/RS; cluster37 TLS cases pass on reviewed b5;
  single-App37 runtime is independently active. Never mutate those inputs.
- Own a NEW /tmp/uwz-m2-h2-body-queue source copy, no hardlinks/symlinks/cache.
  Small snapshots/preimages/diffs and exact checks stay in
  .uwz-work/evidence/h2-streaming/body-queue; big binaries/cache/IR stay /tmp.
  You are not alone; no reverts, agents, commits, refs, pins or dependency fetch.
- Root owns final source promotion/docs/shared test registration. Original r2
  bindings, immutable c22393-file override and existing libraries only; -j2.
  Read .superpowers/sdd/h1_tls_plan/global_constraints.md for exact tool paths,
  source references and graphify prefix before new searches. Refresh AST after
  code changes using an independent identical copy if needed.
- No native fault, cancellation schedule/interleaving/race/crash/leak/invalid-fd/
  resource/kernel/registration/injected-completion/panic probes. This task is
  pure protocol storage/accounting with real caller buffers; no native clients.

