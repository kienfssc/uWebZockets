## Task 3: concrete registered-sink Session delivery

Owner http_protocol with DX/transport guidance. Implement the first vertical
slice in session_handoff_2026_10_28.md INCLUDING Root's delivery_allowed correction.
ADR0008/full M2 plan remain binding. This must reach real registered BodySinks
through actual encoded Session input and shared admission, not more unused helpers.

Own a fresh regular-byte copy /tmp/uwz-m2-h2-session-delivery of immutable1025-file
580199bc baseline. Evidence .uwz-work/evidence/h2-streaming/session-delivery; big
caches/binaries/IR /tmp only. Own server.zig, new core/http2_upload.zig, a focused
shared router/body_admission.zig (or equally focused earned seam), H1 admission
consumer/actual App resolver extraction, centralized driver tests, support exports,
main import and exact measured config layout assertions. A focused protocol
body_receive.zig is allowed if it earns queue/credit/identity invariants rather
than merely forwarding. Report before touching other paths. You are not alone;
no Root edits, other-agent reverts, subagents, commits/refs/pins/fetches.

Use the real named event/result contracts from the handoff. Keep legacy HeaderFn/
HeaderDecision and buffered behavior source compatible. New callbacks defaultnull;
streaming storage defaultsfalse/null. Add only approved Session/Storage pointer,
Capacities bool and two Callback pointers. Optional native H1 cold H2-owner pointer
and App startup/TCP activation are deferred to the next slice. Do not copy layout
proxy modules into behavior source. Add actual low-level enabled Session planning,
carving and Bundle storage; missing/undersized pool refuses503 before begin/100.
Disabled Session storage still allocates no pool/protocol/driver region.

Extract actual neutral policy/reserve logic used by App/H1; preserve helper error
sets and existing observable behavior. A direct function alias can preserve an
old helper name without a forwarding wrapper. No fabricated H1 HeadReady for H2.
The real test fixture registers BodyRoutes in Router and uses that same shared
policy with the concrete driver. Retain per-stream request/capture metadata through
response completion; preserve middleware bytes within existing response-header
storage at min2048/stride, restore into fresh Response before final encoding.
Native effect adapters remain inactive; caller-owned fixture supplies actual
explicit control targets/current callbacks and constructs fresh Responses.
Never retain a Response pointer or invent a native completion/result.

Implement complete observe-once/FIFO/pause/resume/EOF/trailer rules, accepted-scope
WINDOW_UPDATE retry, padding, Continue state, final-response/reset FIFO and borrowed
slot retirement from the handoff. Enabled buffered/refused/WS refunds share the
same pending connection ledger. Before invoking any body callback, defer stream
clear/reuse while borrowed and preserve cause. Controls invalidate before terminal,
quota releases after callback return; end error has no second cancel. Public
resume during blocked100 must update actual readiness without delivering. No new
input reentrancy or generic scheduler. Preserve initial metadata on trailers.

Tests must feed encoded HEADERS/DATA into the actual Session and inspect actual
caller-owned framed output and independent counts/bytes. Cover begin/chunk/end
beyond buffered stride; partial/final pauses and empty EOF; required100 blocked
using a genuinely full fixed output sink; ready/paused sink with DATA while100
blocks; resume before100 acceptance; FIFO old suffix+fresh frames; early limits
while held; exact/overlimit and full-u64 framing on32bit; no repeated begin;
declared/metadata/pool/quota refusals before begin; failed-begin rollback; sibling
isolation and capture overflow; middleware/initial metadata through trailers/
response; real local reset during callbacks/deferred cleanup; error/cancel/end
exactly once; separate connection-success/stream-blocked WU and reset refunds.
Do not manufacture a bad stub or native result to claim red. Preserve real failures.

Run new pure Session/driver tests Debug/RS and existing complete H2/HPACK/refusal/
queue suites plus affected H1 App/driver/admission tests. Only real caller data and
fixed writer capacity, no new sockets or native scheduling/fault experiments.
No full isolated native central suite. Full central3target and eligible32bit
semantic compile, full-dir fmt/conventions/version/docs, independent AST refresh,
before/after source/compiler/module/static-library/override/binary/env bindings.
Use original r2 bindings and unchanged93-file c223 override, existing static libs,
compiler -j2, caches /tmp. Check actual final layouts on all3targets; approved
default-disabled growth is8 bytes/connection, total8192 at1024. Cold protocol/driver
final types must be measured, never simply asserted equal to proxies. Keep exact
capacities and independent logical streaming route limits; do not substitute the
buffered body_stride or max_body_size as the selected upload limit.

Preserve the stopped experiment: no new native cancellation/schedule/interleaving/
race/crash/leak/invalid-fd/resource/registration/kernel/injected-completion/panic
probe. Ordinary callback-level local reset/public control is a logical protocol
operation only; no fake OS completion or callback timing experiment. No new live
client until independent source review and Root's scoped authorization.

Freeze complete snapshots/preimages/patch/manifests and task-3-report.md beside
the extracted brief for independent protocol/spec/quality/structural review. Report
actual commands/results and remaining startup/native/TLS/live100M/production/final
gates. Root owns final documentation, branch commits/pushes and later activation.
