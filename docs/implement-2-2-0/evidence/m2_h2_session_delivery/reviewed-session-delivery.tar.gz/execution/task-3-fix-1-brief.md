# Task3 fix round 1 of 5

Continue current frozen7062cbc4 candidate; do not recreate it. Original Task3 brief,
handoff/correction and all Root scope/alignment rulings remain binding. Two
independent final reviews request changes; Root inspected the cited source and
confirms all four findings. They agree with the spec, so no plan-conflict ruling
or scope reduction applies. No other features/ownership changes are authorized.

Read the complete findings in session-delivery/review-protocol-v3.md and
review-admission-v3.md. Covering source is centralized tests plus changed actual
server/driver paths. Fix requirements:

F1 P1: peer RST currently reclaims queued bytes through notify_stream_closed but
never flushes connection_pending. Attempt accepted-scope connection credit after
processing reset; WouldBlock retains intent without duplication. Real pure encoded
RST of a paused stream with65535 held bytes must release exactly65535 once and
allow sibling DATA without unrelated explicit flush/output. Include blocked credit
and retired-stream credit suppression as relevant. No native scheduling probes.

F2 P1: buffered request_fn reset/close then error skips deferred notify/clear after
callback_active drops. initial_seen remains and next stream is treated as trailers;
enabled state can also retain cause/credit. Apply equivalent deferred cleanup on
all callback exits. Test disabled and enabled sessions, reset-then-error and final
response-after-remote-end then error, slot reuse and no duplicate close notification.
These are software callbacks/encoded frames, never existing native socket cases.

F3 P2: body callback resets then errors; receive_body_data adds current DATA refund
after prior reset flush, fail_body returns because identity is gone. Flush the new
connection refund on that unwind, retaining accepted-scope/once-only accounting.
Test actual chunk callback reset-and-error plus expected restored window/sibling
progress. Keep current/queued/padding refunds distinct; no double refund.

F4 P2: post-admission BodyTooLarge currently sends413 with empty raw headers.
Preserve admitted fitting middleware/security headers via the concrete driver's
fresh Response failure path (as H1 does), while retaining controls-before-cancel,
quota-after-cancel and final-response/NO_ERROR-reset ordering. Do not produce
duplicate413, reset before full final acceptance, header alias corruption, or
second cancel. Test encoded DATA overflow with fitting saved middleware, including
output pressure; keep the existing narrow drop of unretainable rejected metadata.
If a minimal stack event contract change is needed, explain it; no new stored field
or retained Response/factory pointer without fresh accounting/Root approval.

Preserve all v3 source/preimages/patch/review/raw evidence. Add meaningful regressions
against the genuine frozen failing source before fixes; no manufactured bad stub,
no fake native outcome, no missing-declaration red called behavior. Keep snapshots
and actual statuses, and freeze before final recorded checks. Unique fix1 labels.

Run covering pure tests Debug/RS and affected previously authorized safe H1/H2/App
regressions. Compile entire central graph3targets/eligible32, actual layouts and
static/AST as justified by changed code; no broad repeat for unchanged unrelated
inputs. All compiler/source/module/override/binary/environment identities and raw
logs remain. Original two socket cases, native/resource/timer/cancellation probes
and full isolated native central suite stay stopped/compile-only; no retry,
escalation, reconstruction, socket, new client, dependency or Root mutation.

You are not alone. Own assigned candidate/modules/tests/evidence/report only; no
subagents, commits/push/ref/pin/fetch, other-agent reverts or client artifact edits.
Preserve capacities, warm/cold/layout contracts and all existing assertions.
Any genuinely necessary extra path/field requires explicit ruling before adoption.

Append fix report to task-3-report.md with each F1..F4 cause/change, covering tests,
exact commands/raw outcomes and source identities. Keep old report clearly v3
historical, not overwritten as final success. Freeze complete fix diff/preimages/
snapshots/review package for scoped re-review. Root will re-review all fixes before
native activation. Return concise status/tests/concerns.
