# HTTP/2 request-streaming architecture handoff

Architect: /root/architect_h2_request_streaming. Source-only handoff for M2;
no implementation, builds, probes or source edits were performed by architect.
Inspected baseline /tmp/uwz-m2-h1-plaintext-combined,1023files,digest
acff666a13770119f4dab5441a8996bbee70c18df2e96d92b1e99d07547b254b.
Shared TCP integration must use the subsequent stable reviewed TLS baseline.

## Binding contract and corrected planning input

ADR0008 and 2.2.0-TODO.md M2 govern. Root's initial dispatch incorrectly named
2*W+2*F; Root withdrew that invented requirement before any changes. The accepted
pool bound remains round_up(65535 + max_streams*1023,1024): at8streams,73728
payload bytes plus432bytes of three-u16 metadata per block, before owner/alignment.
Do not double the pool or amend the ADR for that discarded formula.

Preserve buffered APIs, legacy nullableusize Content-Length and distinct fullu64
streaming declaration, M1 producers/files, existing capacities and helper errors.
No dependency adoption or native retirement redesign. No native fault/schedule/
interleaving/race/crash/leak/invalid-fd/resource/kernel/registration/injected-
completion/panic probes. Ordinary actual protocol/API clients and real pure
caller-owned operations are separate verification paths.

## Source-backed hazards and earned seams

- server.zig31/1266: keep read-only selection/provisional framing separate from
  an explicit admission/delivery contract; don't silently make selector reentrant.
- server.zig1364 and connection.zig495: current DATA buffering restores both
  receive windows before WINDOW_UPDATE output. Streaming needs independently
  durable, validated and committed connection/stream credit intents.
- server.zig1689/1728/1751: preserve actual final-frame acceptance and reset FIFO;
  send_reset currently clears a stream even under an active callback. Defer
  borrowed storage recycling through callback unwind.
- tcp.zig725: connection-shared route captures cannot retain concurrent streams.
  Enabled H2 needs per-stream captures and initial metadata through response life.
- app.zig717/http1_upload.zig92: extract actual transport-neutral App admission
  and reserve_and_arm for H1/H2 reuse. Never manufacture an H1 HeadReady for H2.
- tcp.zig3003/app.zig645: native connection close currently terminalizes H1 only.
  H2 must join existing delivery borrow and cause-preserving close/shutdown paths.

Three responsibilities: protocol block queue/credit transitions under http2;
concrete sink/BodyState/reservation/control driver under core; canonical route,
middleware and admission policy under router. Deleting queue/shared admission
would scatter fragmentation/credit or routing/middleware invariants across paths.
No generic continuation framework or forwarding-only adapter is justified.

## Storage and generation decision

Extend Session.Capacities/Storage/planning/carving/Bundle with default-disabled
optional queue storage; carve enabled-only per-stream upload owner/control state
in config. Queue is independent of positive buffered body_stride. Preserve control
generations outside transient Request resets across stream and connection reuse.
Use named data/callback aliases and additive defaulted optional contract fields.
Measure/report any default Session/Storage/Callback/TCP pointer or slice growth;
disabled configurations allocate no queue or per-stream upload owners. No assumed
zero growth and no unexplained assertion changes. Check all arithmetic/index
sentinels on eligible32bit targets and exact enabled/disabled layouts on3OS.

## Ordered slices and acceptance

1. Protocol queue/credit/startup, http_protocol with DX/transport guidance:
   focused http2/body_queue.zig, connection.zig, server.zig; serialized config.
   1024byte blocks with next/read/write metadata and per-stream head/tail. Fill
   tail, never compact consumed head or credit it early. Check sizing/rounding/
   alignment/index representability. Validate each WINDOW_UPDATE before writing;
   commit its receive-window scope only after the complete frame is accepted.
   WouldBlock retains intent; connection success then blocked stream update must
   not duplicate connection credit. Reset reclaims connection credit once and
   drops obsolete stream intent; padding becomes immediately eligible. Missing/
   undersized low-level pool refuses BodyIngressUnavailable/503 before begin/100.
   Caller-owned tests: fragmentation, partial heads, padding, reset/reuse, blocked
   output, checked arithmetic and unchanged disabled/buffered storage.

2. Shared admission/metadata, dx_router with protocol guidance:
   App, focused router policy module, H1 head/reservation adapters and cold config.
   Extract only neutral policy/reserve; retain H1 framing/upgrade/physical logic.
   H2 facts name stable Request, streamID/index, declared?u64, END_STREAM, earlydata,
   physical availability and metadata capacity. Preserve HEAD/ANY/buffered/QUERY/
   extended-CONNECT precedence, globals/order/latepolicy/quota/rollback. Per-stream
   captures and initial headers stay pinned through output. Preserve middleware
   headers in idle per-stream response-header bytes at min(2048,response_stride);
   preflight before begin, restore into fresh terminal Response before encoding.
   Keep all H1 checks and add real H2 head/refusal/metadata boundary cases.

3. Complete concrete delivery/output, http_protocol with transport:
   server, core/http2_upload.zig, cold owners and centralized tests. Reserve/arm,
   begin/rollback/accept and exactly one terminal. Status100 HEADERS has no END_STREAM,
   independent final metadata and persistent output retry; no repeated begin or
   lost DATA while blocked. Observe new payload once, queue remainder, validate
   accepted prefixes via common BodyState. Real resume drains queued input first,
   handles pending EOF with no bytes, then credit; final-byte pause requires resume.
   Validate/discard trailers without overwriting initial metadata. End requires
   exact length, valid trailers, empty queue and readiness. Keep HPACK decoding for
   refused/closed/locally reset streams. Generalize early-final refusal: NO_ERROR
   reset follows actual final HEADERS/DATA acceptance, retaining v6 hard-writer
   guard and ordered retry. Test complete large logical delivery beyond buffered
   stride, Continue/refusals, paused trailers, u64 headers/32bit, pressure/siblings.

4. Callback lifetime/TLS composition, transport with protocol/crypto:
   waits stable TLS source, then serialized TCP/App glue. Wire actual headers/DATA/
   completion/reset/drain and control contexts. Pin stream storage across every
   admission/sink/terminal callback; local reset/end may retire identity but cannot
   clear arrays/owners/captures until unwind. Use existing native delivery borrow,
   preserve first cause on close/timeout/peer/shutdown, cancel all accepted streams
   once before native owner release. Invalidate generation before notification,
   release quota after it. End error aborts without second cancel. Independent
   producer context/scratch and retained metadata survive upload cleanup. Paused
   stream must not stop connection parsing/TLS control or M1 output/timeout coverage.
   Pure callback-unwind/reset/reuse and ordinary owned lifecycle evidence required;
   no native scheduling/fault experiments.

5. Actual owned H2-over-TLS proof, verification then review/integration:
   exact100000000 logical bytes with independent bounded count/SHA256. Old live503
   proof sentZERO bytes and cannot satisfy this. Cover partial/final pauses,
   empty/exact/overlimit/100, queued trailers/padding, concurrent routes/healthy
   sibling, output pressure, metadata after binding reuse/producer completion,
   public cancel, ordinary disconnect/enderror/drained shutdown. Retain complete
   source/compiler/client/capacity/override identities and raw results.

## Fragmentation proof

connection.zig13/366 initializes connection credit65535; settings don't enlarge it.
DATA debits its complete payload including padding at745. Let H be bytes held in
occupied blocks including consumed prefixes: no credit returns for those bytes,
so H<=65535. Every occupied stream has at most one partially filled tail; other
blocks stay full even when their head prefix is consumed. Occupied capacity is
therefore <=H+max_streams*1023. Reclaimed blocks are free before credit is advertised;
pending credit remains debited until accepted output. Raising connection credit,
crediting head prefixes early or creating extra fragmented tails breaks the proof.

Pause retains stream input while connection parsing/control/output continues;
exhausting shared connection credit may block all inbound DATA, as the ADR states.
No unconditional sibling upload progress or output-context lifetime extension is
invented. Plan acceptance is not H2 capability or implementation acceptance.

Required gates remain full applicable formatting/conventions/version/docs/forks/
package checks; Debug/RS, sanitizers/separateMSan, enabled/disabled layouts, foreign/
32bit compilation, fuzz/OSS-Fuzz, examples/consumer/ReleaseFast, H1 compliance,
H2/HPACK regressions and shared-I/O Autobahn. NativeWindows and maintained adoption
remain explicit outstanding requirements. Root must scope/approve execution
against the stable composed TLS/constructor baseline before assigning code.

## Global Constraints

- Follow AGENTS/CODING, Zig0.16, named explicit data, no allocation/I/O/log/clock
  in queue/credit operations, no anytype or reflective type construction.
- Execution baseline is now frozen reviewed composed TLS/constructor source
  /tmp/uwz-m2-h1-tls-configured-combined,1023files,digest
  89dce088f5684c9173c45c572e785e7ff9c57991eb152ec76c46a58db481479d.
  Its selected35 tests pass Debug/RS; cluster37 TLS cases pass on reviewed b5;
  single-App37 runtime is independently active. Never mutate those inputs.
- Own a NEW /tmp/uwz-m2-h2-body-queue source copy, no hardlinks/symlinks/cache.
  Small snapshots/preimages/diffs and exact checks stay in
  .uwz-work/evidence/h2-streaming/body-queue; big binaries/cache/IR stay /tmp.
  You are not alone; no reverts, agents, commits, refs, pins or dependency fetch.
- Root owns final source promotion/docs/shared test registration. Original r2
  bindings, immutable c22393-file override and existing libraries only; -j2.
  Read .superpowers/sdd/h1_tls_plan/global_constraints.md for exact tool paths,
  source references and graphify prefix before new searches. Refresh AST after
  code changes using an independent identical copy if needed.
- No native fault, cancellation schedule/interleaving/race/crash/leak/invalid-fd/
  resource/kernel/registration/injected-completion/panic probes. This task is
  pure protocol storage/accounting with real caller buffers; no native clients.

## Task 1: bounded receive queue and credit-intent core

Owner http_protocol. Own only NEW src/http2/body_queue.zig, NEW
src/tests/http2_body_queue_tests.zig, one private test_support export and one
private tests/main import in the new copy. Do not edit Connection/Session/App/
config/TCP or public root exports in this slice; their concrete integration is
the next dependent task. This is an earned foundation required by the accepted
H2 DATA driver, not a public streaming capability or complete H2 implementation.

Implement actual caller-owned1024byte block queue with checked sizing/initialization,
free-list next/read/write metadata, per-stream heads/tails, tail reuse, append,
head-prefix exposure, consume/reclaim and reset. Held consumed head prefixes do
not release credit until their block is freed. Reset returns held connection
credit once; repeated reset is idempotent. Check storage shape, all arithmetic,
stream/index/sentinel bounds and error atomicity. Do not allocate or fabricate
oversized memory slices for width tests; numeric sizing facts suffice.

Implement the corresponding small pure pending-credit operations needed for
separate connection/stream validation and commit after accepted WINDOW_UPDATE.
Queue reclamation returns actual credit amounts. Pending amounts remain until
explicit accepted-scope commit; connection success then blocked stream retry
cannot duplicate connection credit. Padding credit has no retained payload;
closed-stream reset drops obsolete stream intent while preserving connection
refund. Use the real existing window types/contracts after scoped source read,
not a generic transaction/token framework or invented connection-window increase.
No I/O/writer callback or native completion is fabricated to test acceptance.
If safe credit semantics need broader concrete Session coupling, report that
before adding speculative state; keep the queue contract clear and executable.

Meaningful tests use caller storage and independent expected byte sequences:
multiple streams, split append/tail reuse, partial heads, full/empty/zero data,
queue exhaustion with no mutation, block/stream reuse, repeated reset, exact
release including earlier consumed prefixes, padding/credit-only cases, partial
connection-vs-stream output intent commits, checked max-width sizing/overflow,
u16 sentinel representability, and accepted73728-byte/72block sizing at8streams.
Preserve genuine declaration/behavioral reds honestly; no manufactured bad stub
solely to claim red. Existing H1/TLS and69 H2 tests remain unchanged.

Run selected pure tests Debug/RS and eligible32bit compile, full central native/
macOS/Windows semantic compile, scoped full-dir fmt/conventions/version and AST
refresh; no entire isolated native fault suite. Preserve pre/post complete
source/input/compiler/binary/override/env bindings and raw failures/statuses.
Freeze snapshots/report for independent protocol/spec/quality review. No cold
slab/default layout assertion changes are needed yet. Report that Session/native
delivery, App admission, startup carving/layout measurements and actual100M H2
runtime remain unimplemented. Root must connect and verify the core before
production adoption; unused final production scaffolding is not acceptance.

## Task 2: measure proposed Session and cold-owner layouts

Read session_handoff_2026_10_28.md first for the accepted architect's concrete
field list and next vertical delivery slice. Root authorizes measurements only
in this task; no behavior implementation or source adoption. The full M2 goal,
first registered-sink integration and later native/live acceptance remain open.

Owner verification. Keep baseline /tmp/uwz-m2-h2-body-queue immutable at exact
1025-file digest580199bc84e81779dd050943fc0b1bb7a9b8f1af113fcb28e7fab560fc105af6.
Own only new /tmp/uwz-m2-h2-layout-proposal and /tmp layout artifacts/caches;
small source snapshots/records/report go .uwz-work/evidence/h2-streaming/layout.
These task-local paths override Task1's source/output paths in Global Constraints.
You are not alone; never revert others, change Root source, refs, pins or gates,
commit/push, fetch or dispatch subagents.

Measure actual baseline Session8, Storage, Capacities, Callbacks, TcpConnection,
Http1UploadStorage, BodyState, Queue and default/native/private storage planning
on native Linux, aarch64-macos and x86_64-windows-gnu. Private config is supplied
in .uwz-work/evidence/h1-tls/integration-single/profile.zig: eight connections,
L512/H1024/B256, eight native H2 streams. Inspect real config functions/arguments;
do not invent a plan API. Record exact compilation inputs and target bindings.

In a separate disposable prototype copy, add only the proposed declaration-only
fields: Session optional receive-state pointer; Storage default-null same pointer;
Capacities false streaming bool; Callbacks two default-null function pointers;
H1 cold owner optional H2 owner pointer. Pointee/function-type proxies are allowed
ONLY in the measurement artifact, explicitly labelled as layout proxies rather
than final implementation contracts. No behavior, admission, parser, constructor,
callback execution, capacity allocation or assertion edits. Keep baseline unchanged.
Measure actual resulting warm/default planning/layout totals; don't just sum8.

Use named private prototype data for proposed protocol/driver owner shapes from
the handoff and the real existing Queue/BodyState/route/cancel types. Measure
their alignment and optionals; where the shared target is not yet implemented,
label its layout proxy and show the assumed shape. Calculate enabled totals
including pool, metadata, stream heads/tails, state, driver slots, cold pointer
and config region alignment. State which totals are measured final-type facts
and which remain proposed-region arithmetic. No cold/slab assertion changes.

Use original r2 three-target C bindings, verified immutable c223 override and
existing compiler/static-library identities; -j2, caches and binaries /tmp only.
An intentional @compileLog compile-only report is acceptable: retain real status
and clearly classify expected compile-log termination, never a test pass/red.
No executable, tests, socket/client or native code runs. No full central native
suite and no new native cancellation/schedule/interleaving/race/crash/leak/
invalid-fd/resource/registration/kernel/injected-completion/panic probe.

Graphify first before new source searches using the prefix in Global Constraints;
the supplied paths and earlier located source lines may be read directly.
After prototype code edits refresh AST in an independent identical /tmp copy;
full immutable baseline/candidate/input/override manifests and raw command records
must survive. If a missing module/tool needs broader changes, report before
altering scope. Root owns final approval of fields/growth before Task3 behavior.

Write task-2-report.md beside the extracted task-2-brief.md. Report exact commands,
measured values, proxy assumptions, total arithmetic, source/input identities,
preserved failures and baseline immutability. Return only status, one-line
measurement summary and concerns. No new H2 capability claim follows.

## Task 3: concrete registered-sink Session delivery

Owner http_protocol with DX/transport guidance. Implement the first vertical
slice in session_handoff_2026_10_28.md INCLUDING Root's delivery_allowed correction.
ADR0008/full M2 plan remain binding. This must reach real registered BodySinks
through actual encoded Session input and shared admission, not more unused helpers.

Own a fresh regular-byte copy /tmp/uwz-m2-h2-session-delivery of immutable1025-file
580199bc baseline. Evidence .uwz-work/evidence/h2-streaming/session-delivery; big
caches/binaries/IR /tmp only. Own server.zig, new core/http2_upload.zig, a focused
shared router/body_admission.zig (or equally focused earned seam), H1 admission
consumer/actual App resolver extraction, centralized driver tests, support exports,
main import and exact measured config layout assertions. A focused protocol
body_receive.zig is allowed if it earns queue/credit/identity invariants rather
than merely forwarding. Report before touching other paths. You are not alone;
no Root edits, other-agent reverts, subagents, commits/refs/pins/fetches.

Use the real named event/result contracts from the handoff. Keep legacy HeaderFn/
HeaderDecision and buffered behavior source compatible. New callbacks defaultnull;
streaming storage defaultsfalse/null. Add only approved Session/Storage pointer,
Capacities bool and two Callback pointers. Optional native H1 cold H2-owner pointer
and App startup/TCP activation are deferred to the next slice. Do not copy layout
proxy modules into behavior source. Add actual low-level enabled Session planning,
carving and Bundle storage; missing/undersized pool refuses503 before begin/100.
Disabled Session storage still allocates no pool/protocol/driver region.

Extract actual neutral policy/reserve logic used by App/H1; preserve helper error
sets and existing observable behavior. A direct function alias can preserve an
old helper name without a forwarding wrapper. No fabricated H1 HeadReady for H2.
The real test fixture registers BodyRoutes in Router and uses that same shared
policy with the concrete driver. Retain per-stream request/capture metadata through
response completion; preserve middleware bytes within existing response-header
storage at min2048/stride, restore into fresh Response before final encoding.
Native effect adapters remain inactive; caller-owned fixture supplies actual
explicit control targets/current callbacks and constructs fresh Responses.
Never retain a Response pointer or invent a native completion/result.

Implement complete observe-once/FIFO/pause/resume/EOF/trailer rules, accepted-scope
WINDOW_UPDATE retry, padding, Continue state, final-response/reset FIFO and borrowed
slot retirement from the handoff. Enabled buffered/refused/WS refunds share the
same pending connection ledger. Before invoking any body callback, defer stream
clear/reuse while borrowed and preserve cause. Controls invalidate before terminal,
quota releases after callback return; end error has no second cancel. Public
resume during blocked100 must update actual readiness without delivering. No new
input reentrancy or generic scheduler. Preserve initial metadata on trailers.

Tests must feed encoded HEADERS/DATA into the actual Session and inspect actual
caller-owned framed output and independent counts/bytes. Cover begin/chunk/end
beyond buffered stride; partial/final pauses and empty EOF; required100 blocked
using a genuinely full fixed output sink; ready/paused sink with DATA while100
blocks; resume before100 acceptance; FIFO old suffix+fresh frames; early limits
while held; exact/overlimit and full-u64 framing on32bit; no repeated begin;
declared/metadata/pool/quota refusals before begin; failed-begin rollback; sibling
isolation and capture overflow; middleware/initial metadata through trailers/
response; real local reset during callbacks/deferred cleanup; error/cancel/end
exactly once; separate connection-success/stream-blocked WU and reset refunds.
Do not manufacture a bad stub or native result to claim red. Preserve real failures.

Run new pure Session/driver tests Debug/RS and existing complete H2/HPACK/refusal/
queue suites plus affected H1 App/driver/admission tests. Only real caller data and
fixed writer capacity, no new sockets or native scheduling/fault experiments.
No full isolated native central suite. Full central3target and eligible32bit
semantic compile, full-dir fmt/conventions/version/docs, independent AST refresh,
before/after source/compiler/module/static-library/override/binary/env bindings.
Use original r2 bindings and unchanged93-file c223 override, existing static libs,
compiler -j2, caches /tmp. Check actual final layouts on all3targets; approved
default-disabled growth is8 bytes/connection, total8192 at1024. Cold protocol/driver
final types must be measured, never simply asserted equal to proxies. Keep exact
capacities and independent logical streaming route limits; do not substitute the
buffered body_stride or max_body_size as the selected upload limit.

Preserve the stopped experiment: no new native cancellation/schedule/interleaving/
race/crash/leak/invalid-fd/resource/registration/kernel/injected-completion/panic
probe. Ordinary callback-level local reset/public control is a logical protocol
operation only; no fake OS completion or callback timing experiment. No new live
client until independent source review and Root's scoped authorization.

Freeze complete snapshots/preimages/patch/manifests and task-3-report.md beside
the extracted brief for independent protocol/spec/quality/structural review. Report
actual commands/results and remaining startup/native/TLS/live100M/production/final
gates. Root owns final documentation, branch commits/pushes and later activation.
