# Native HTTP/2 request-streaming handoff

Root records the operative source-only output of architect
/root/architect_h2_session_delivery. Inspected immutable1029-file v3 copy
/tmp/uwz-m2-h2-native-architecture-v3, restored from source archive
8f8e06bd53dd98cb1b819e6f066a842979246769dfe2b40016ee0c287a375e46.
No edits, builds, clients, probes or delegation. Task4 waits fixed/frozen Task3
F1-F4 and clean independent re-review. Original M2 gates remain binding.

## Startup and ownership

DX/transport extends router/config.zig: propagate stream_request_bodies through
ServerConfig.h2_capacities; extend LayoutOffsets/SlabLayout/layout_offsets/carve
with enabled-only typed driver and capture regions. Reuse Session's pool/receive
carve, never a second pool. Two capture matrices each contain checked/aligned
max_connections*8*(max_route_params-16) slices. Both supplied profiles have zero
overflow. Add only h2_upload: ?*Http2UploadDriver = null to existing
core/http1_upload_storage.zig; keep TCP's existing upload_owner pointer.

App.init_from_slab initializes each driver at its stable slab address before
attachment. Driver.bind initializes ownership/generations once. Session/native
context may reference stable connection slab; defer App/router/Loop associations
until App.loop_handle beside guarded H1 binding. Rollback may inspect initialized
slot state only, never unbound pointers. App.on_new_connection retains Session
carve/init/reset and later bind_upload_owner; never call Driver.bind again.

## Concrete native adapter

Transport/protocol adds focused core/tcp_http2_upload.zig. Session owns protocol
accounting and http2_upload owns sink lifecycle. TcpConnection.http2_callbacks
sets existing body_select_fn/body_event_fn only with a valid cold driver, keeping
legacy header_fn fallback. Selection delegates Driver.selects; dispatch derives
stream identity and passes a fresh native H2 Response to Driver.event.
BodyControlTarget.context is &driver.slots[index]; trampolines recover connection
from slot.owner.context. Resume calls Session.resume_body; public cancellation
uses Session.cancel_body while transport is usable. Delivery/output failure
finishes terminal cleanup before returning BodyDeliveryFailed.

Extract actual Response construction from dispatch_http2_request, including
producer/file/abort/compression hooks. Share explicit construction, never store
a Response/factory or create an adapter framework. Native admission copies
body_admission.Input and sets early_data_forbidden through
conn.early_data_forbids(input.method) before resolve_router; the fixture's false
policy is insufficient. Forward F4's stack-only final_body_too_large flag without
duplicate response generation. Extend route_http2_data and write-completion
h2.flush_pending adapters; Session owns Continue/queued DATA/EOF/credit retry.
Sink pause never sets connection-wide dispatch_suspended or stops H2/TLS control.
Enabled buffered dispatch also binds indexed driver capture matrices; shared
connection captures remain H1/disabled only. Preserve initial metadata through
response ownership.

## Complete-operation borrow and closure

Use tcp_upload.borrow around each complete Session receive/flush/resume/cancel
or response operation that may call back. Driver.event-only borrowing is too
narrow: Session accesses metadata afterward. finish_borrow occurs after all
Session/connection access and may release the connection; never access afterward.
Keep native retirement unchanged.

Add bounded Session.close_body_inputs(reason, callbacks) !void with no own
RST_STREAM/WINDOW_UPDATE/writer calls. Publish closed state; preserve existing
first causes and stamp all missing causes before callbacks. Retire identities
before terminal callbacks can write; a bounded stack ID snapshot needs no stored
field. Reuse deferred notification/reclaim, preserving admission/chunk/end borrows
through unwind. Invalidate controls before cancel, release quota after return,
never cancel after end. Clean every stream despite an individual callback error,
then propagate the first error.

Native H2 Response entry points reject conn.closing/closed Session before output
ownership or producer mutation; retired IDs also yield StreamClosed. Thus close
callbacks cannot write while metadata stays pinned. tcp_upload.close preserves
H2 causes before close_connection; its cancellation dispatch and
close_upload_connection use no-output closure. Existing shutdown/timeout/peer/
source cause sites remain authoritative; cancelled never replaces a first cause.

owner_pins_drained also checks driver slot phases/reservations/callback phases.
Driver.reset_drained requires all slots inactive/unreserved/outside callbacks
and enclosing native retirement/delivery borrows drained. Clear request fields,
preserving BodyState.generation, owner/index, captures and stable targets. Invoke
through release_closed_connection and existing H1-owner reset. Expired controls
alone never permit metadata reuse.

## Ordered slices and verification

1. Enabled storage, stable initialization/late binding and cold attachment;
   keep native body callbacks gated until the concrete adapter exists.
2. Actual adapter, buffered captures and whole-operation borrow discipline.
3. No-output terminalization, first-cause close and drained/generation-safe reuse.
4. Verification and independent protocol/transport review before activation.

Caller-owned checks cover carve bounds, disabled null/empty regions, inert
rollback-safe owners, late binding, stale-control rejection after drained reuse,
and actual adapter functions with registered sinks/fresh Responses. Include
blocked Continue resume, first-cause closure, callback unwind, F4 middleware413
and buffered/streaming capture coexistence. No new native cancellation/scheduling/
fault experiments, clients, dependency changes or publication are authorized.

Re-measure actual Linux/macOS/Windows layouts. Existing warm sizes and default
disabled growth8192 bytes stay unchanged. Measured Session pool/receive increment
is74336 bytes and driver1288 per connection. Measure H1-owner pointer/layout
delta, capture regions and alignment; never assume eight-byte cold growth or
final slab totals. No extra TCP pointer, capacity increase or hot-path allocation.
Deleting the concrete adapter would scatter control-context recovery, fresh
Response construction and complete-operation borrows; that invariant earns it.

Actual owned100000000-byte H2/TLS proof, applicable full regression/compliance
gates and native Windows acceptance remain open. Inherited authenticated
SSL_in_init EOF remains explicit abort/open genuine0RTT acceptance. Original
stopped experiments and the two socket EPERM cases remain stopped.
