# Session terminalization prerequisite before native H2 activation

Root operative record of /root/architect_h2_session_delivery's read-only
refinement against immutable fixed1d53 source. No edits/builds/tests/clients/
probes/delegation. Implement serially after Task4a review, owning only
http2/server.zig, core/http2_upload.zig and existing centralized driver tests.
TCP/App/config/H1-owner integration remains later. Original M2 gates persist.

## Internal contracts

- Session.close_body_inputs(reason: BodyCancelReason, callbacks: Callbacks)
  anyerror!void: bounded caller-owned protocol teardown. It invokes effects
  through callbacks, so it is not a strictly pure function. No native operations
  or own writer calls; no new stored fields or scheduling machinery.
- Driver.is_drained(self: *const Self) bool: initialized slot-state predicate.
- Driver.reset_drained(self: *Self) error{BodyStateBusy}!void: atomic preflight,
  request-state reset preserving generations and stable associations.

## Notification and bulk-close ordering

Baseline send_reset notifies before connection.reset_local. Retire identity first,
keeping the ID locally, while preserving existing reset FIFO acceptance/retry.
Otherwise stream_closed_fn requesting connection closure can redispatch itself.

call_body owns callback_active[index] only through its supplied event callback.
After return it clears the guard; vanished identity calls notify_stream_closed.
That helper defers while a prior callback owns the guard. Otherwise it acquires
the guard once for BOTH body notification and legacy stream_closed_fn. It must
not use call_body internally: that would clear metadata between callbacks or
recurse on unwind. Collect callback errors, complete remaining notification and
protocol cleanup, then clear guard/storage/scalars and return first error. Never
replay an attempted terminal notification just because it errored. call_body,
buffered dispatch and other callers must clear after completed borrow despite
errors, preserving original operation error over later cleanup error.

Bulk-close order:

1. Set existing self.closed=true; do not return solely because it was already
   true (GOAWAY can close input while streams still need cleanup).
2. Snapshot active IDs in bounded [max_streams]u32. Stamp only absent
   body_receive.close_causes for every affected stream before callbacks;
   preserve first causes and clear Continue retry intents.
3. Retire ALL snapshot identities with connection.reset_local before the first
   notification. This covers mixed buffered/streaming and disabled receive state.
4. Abandon pending_reset_head/count and unsent response/Continue intents without
   overwriting borrowed request/header/response bytes. Discard connection/stream
   credit intents without granting receive windows.
5. Notify every snapshot stream, accumulating first error while continuing
   through the rest. Active slots defer to existing call_body/dispatch unwind,
   which retains original ID and metadata.
6. On completed notification reclaim blocks, clear obsolete mode/stream intents
   and request scalars. Bulk-close reclamation must not recreate credit work.
   Current-DATA and fail_body unwind after callback closure likewise skip new
   refund intent when closed with no identities. No double reclamation or
   receive-window increase without accepted output.

Nested/repeated close sees no active IDs and cannot redispatch. final_body_too_large
is false. Driver request_cancel/finish_terminal invalidates generation before
cancel and releases quota afterward. Admission closure creates no accepted binding;
successful begin followed by deferred closure cancels once; failed begin never
cancels; closure during end never adds a second terminal callback.

## GOAWAY compatibility ruling

Withdraw the preliminary blanket self.closed guards on flush_pending, reset
flushing and credit flushing. Architect confirmed a concrete baseline conflict:
send_goaway sets closed without retiring active streams or their pending output;
flush_pending/flush_pending_stream still allow those responses to complete.

Use explicit bulk teardown's stronger invariant: all IDs retired and intents
abandoned. Leave ordinary flush/send_frame behavior intact, preserving intentional
GOAWAY output and existing active-stream retries. Do not discard pre-existing
GOAWAY credit merely for closed=true; bulk close owns abandonment. The closed/no-
identities condition prevents only fresh teardown-unwind refund work.

Smallest regression: encoded real request; block DATA but accept control frames;
queue a buffered response; feed malformed PING producing GOAWAY. is_closed must
hold while response stream remains active. Unblock DATA and flush: exact body and
END_STREAM accepted once. Paired bulk-close case retires stream and flushes no
additional bytes. Both are actual caller-buffer protocol tests, no native probe.

Retired identities make existing send_response/begin_response/begin_file_response/
write_response_data/finish_response lookups fail StreamClosed before Session
output ownership mutation. Fresh Responses must observe that. Native producer/
file ownership and bytes already copied into transport ring remain the existing
stream_closed_fn/native layer's responsibility; later TCP entry guards must
reject closure before mutating those out-of-scope resources.

## Driver drain and reset

is_drained checks initialized slots only: body.phase==inactive, !body.reserved,
callback_phase==none, no accepted binding/live control target. Do not dereference
Session/context/admission/capture bytes: rollback may precede late binding.
Nonzero historical IDs/counters are not active ownership; a completed binding can
still have Session-owned response metadata.

reset_drained preflights every slot and returns BodyStateBusy without any mutation
if one is busy. Reset request fields preserving body.generation, owner/index and
all driver Session/context/admission/capture associations. Never call bind again.
Expired BodyState.target stays null; preserving targets means stable associations,
never resurrecting a prior live control target.

Caller proves no enclosing Session/native delivery borrow, drained native
retirement/release gates, no response owner depending on reusable metadata and
serialized Session reset/reuse. Slot drain alone does not prove connection drain.
An arbitrary supplied callback failing before honoring application ownership can
leave its driver non-drained; that must block native release rather than be hidden.

## Required caller-buffer coverage

Two accepted streams with held DATA/blocked credit/Continue: no teardown output,
all IDs retired/first causes preserved before first callback, once-only cancel
and quota-after-cancel. Close from actual middleware/begin/chunk/end and ordinary
stream_closed_fn; metadata readable in both terminal notification callbacks,
nested close harmless, no second end/cancel. Real driver cleanup followed by
supplied callback error must not skip sibling/protocol cleanup or replay terminal.
Mixed/disabled closure, fresh Response post-close refusal without writer/ownership
mutation, and fresh/queued DATA unwind without credit output/double reclamation.
Busy reset is atomic; drained reset preserves generations/associations and old
controls remain expired after actual Session/slot reuse. Retain GOAWAY retry proof.

No native cancellation schedule/interleaving/race/crash/leak/resource/invalid-fd/
kernel/registration/injected-completion/panic probe or stopped-case retry. Original
stopped experiment and two sandbox-denied socket cases remain stopped. Root must
authorize the next implementation brief after current Task4a review; this record
is source-backed architecture, not implementation or runtime acceptance.

## Root superseding credit ruling

The later real GOAWAY-last-stream regression disproves uniqueness of the earlier
closed/no-identities teardown predicate and exposes obsolete per-stream pending
credit. RFC9113 sections5.2.1/6.9 permit receiver update policy choice, but Root
chooses exact preservation of the established ordinary GOAWAY refund behavior:
four pending padding plus three reclaimed bytes produce seven connection credits.
The assertion stays unchanged. This withdraws the earlier terminal-receive
approximation for deciding fresh-credit abandonment.

Propose one default-false credit_abandoned bool in optional ReceiveState, with
declaration-only three-target/native8/generic-width accounting before adoption.
Only explicit bulk input close sets it; ordinary GOAWAY does not. Always clear
retired stream intents; reclaim queued/current bytes without new connection credit
only on explicit abandonment. Reset clears the marker. No new Session/TCP flag,
payload/window/capacity change or unmeasured profile growth is authorized.
See task-4b-brief.md's appended ruling for measurement/adoption requirements.

Source: https://www.rfc-editor.org/rfc/rfc9113.html#section-5.2.1 and
https://www.rfc-editor.org/rfc/rfc9113.html#section-6.9, read2026-10-28.

Root approved the measured one-field adoption after all18 diagnostic records:
native8/default-disabled profiles unchanged across3OS; enabled generic2 metadata/
Bundle/carve +8 bytes, generic1/3/4/8 unchanged. Exact values and mandatory32-bit
qualification are appended to task-4b-brief.md. No payload/window/capacity or extra
Session/TCP field change is approved. Ordinary seven-credit GOAWAY test stays.
