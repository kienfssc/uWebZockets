# Task4b fix round1/5: terminal cleanup nesting

Root integration source review found an Important/P2 convention defect after the
two scoped reviews: final485 server.notify_stream_closed has four nested control
levels (body_receive -> nonbuffered mode -> optional event_fn -> result validation;
also nested credit-error capture). CODING_CONVENTION.md105 requires at most three
levels and a named helper. This is binding source hygiene, not a preference or
permission to weaken the checker. Root re-read SDD fix-loop before this round.

Continue existing implementation; preserve immutable485 tree, source inventories,
all old patches/raw evidence, reviews and root audit. No completed task/source
sequence restart. Own only current candidate src/http2/server.zig for this fix.

Flatten notify_stream_closed with guard clauses/appropriately named helpers that
earn actual terminal-result validation and queue/credit-retirement invariants.
Do not add forwarding-only wrappers or generic callback frameworks. Keep maximum
control nesting three in every changed helper/parent. Preserve callback_active
across body AND legacy callback, first causes, all metadata pins, terminal-result
validation, first-error precedence, unconditional queue/ledger cleanup and both
explicit-abandonment/ordinary seven-credit GOAWAY semantics. Queue reset errors
must not skip the existing subsequent cleanup attempt. No fields/API/capacities/
flags/output/error policy changes; is_drained/reset_drained remain unchanged.

This is source refactoring; no fabricated behavioral red or pointless new tests.
Existing centralized http2_upload_driver_tests covers39 terminal/callback cases;
http2_server_tests exact40 filter and affected refusal/frame/HPACK/queue/width,
H1/App/config/admission roots retain their assigned coverage. Freeze new source
before covering checks Debug/ReleaseSafe and final compile/static/AST evidence;
reuse unchanged measurements only with exact type/field/carve proof, never claim
an old command ran on a new source hash. Add immediate raw-log hashes to NEW
command records where practical; old absent historical hashes remain explicit.
No broad native/full-suite/live/fault/stopped-case execution. Existing constraints
and approved generic2/+4 32-bit rounding all persist.

Preserve old root-audit/public patch as historical; new fix evidence belongs under
native-terminal/fix1 with full preimage/final/diff/source/command/binary/input
bindings, reconstructing patch and report appendix in task-4b-report.md. Include
exact covering commands, raw outcomes and evidence source IDs BEFORE re-review.
Root re-reviews only this fix diff and new breakage with existing reviewers.
No Root source edits, extra paths, subagents, commits/push/ref/pin/fetch/publication,
clients or reverts. You are not alone. All heavy artifacts/copies/cache stay/tmp.
