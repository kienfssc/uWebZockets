# Task4b: Session teardown and generation-preserving driver reset

This is the next serial prerequisite from the approved native H2 plan, before
TCP body callback activation. Task4a d69 startup/storage has clean independent
spec/quality/structural review. Root preserves the original full M2 scope; this
slice does not establish native delivery, callback lifetime composition or release.

Read native_terminal_handoff_2026_10_28.md first, INCLUDING its GOAWAY compatibility
ruling. It supersedes the architect's withdrawn blanket closed-state flush guards.
The earlier native_handoff_2026_10_28.md remains later TCP integration context.
Read relevant project protocol/transport instructions and narrow skills on demand.

Create NEW regular-byte /tmp/uwz-m2-h2-terminal-inputs from immutable
/tmp/uwz-m2-h2-native-startup,1029files,digest
d69d1fb4f318f660ec5163315b1e70824a4a112803ad980bdcda7572b6d2c13f.
Verify every path against native-startup/final-source.json before editing.
Own only candidate src/http2/server.zig, src/core/http2_upload.zig and existing
src/tests/http2_upload_driver_tests.zig. No TCP/App/config/H1-owner changes here.
The fixture file approaches1000 lines; explain cohesive growth/structure in your
report. No mechanical split or unrelated extraction. If an extra test/helper path
is genuinely needed, propose its interface/ownership to Root before editing it.

## Concrete operations

Add internal Session.close_body_inputs(self, reason: BodyCancelReason,
callbacks: Callbacks) anyerror!void. It invokes supplied callbacks, so do not call
it strictly pure. It performs no own native or writer operation, allocates nothing
and adds no stored field. Required behavior:

1. Fix ordinary send_reset to retire identity through connection.reset_local
   before notification, retaining existing output acceptance/reset FIFO/retry.
2. notify_stream_closed guards BOTH body and legacy notification with existing
   callback_active. It must not call call_body internally. Preserve metadata until
   both callbacks return, capture errors rather than exiting before cleanup, and
   never replay an attempted terminal because it errored. call_body/dispatch and
   notification callers clear only after borrow completion on every exit and
   retain the original operation error if later cleanup also fails.
3. Bulk close sets existing closed=true, snapshots IDs in bounded [max_streams]u32,
   stamps all missing first causes before callbacks, preserves existing causes,
   clears Continue intents and retires ALL snapshot identities before notification.
   Already closed is not enough to return: GOAWAY can leave active streams.
4. Abandon pending reset/response/Continue output intents without overwriting
   borrowed bytes. Discard pending credit without increasing receive windows.
   Notify all snapshot streams despite one error, return first error afterward.
   Active admission/chunk/end slots defer cleanup through actual callback unwind.
5. Reclaim queues exactly once and clear obsolete stream/mode/scalar state after
   notification. Deferred queue/current-DATA/fail_body unwind after bulk closure
   must not create new credit intent. Closed with no stream identities is the
   existing-state teardown invariant, not a new flag. Preserve ordinary credit
   accounting and pre-existing GOAWAY intents outside explicit bulk teardown.
6. Repeated/nested closure is harmless. final_body_too_large stays false. Expire
   controls before cancel, release quota after callback; successful begin followed
   by closure cancels once, failed begin never cancels, end gets no second cancel.

Do not blanket-guard flush_pending/reset flushing/send_frame on self.closed.
send_goaway already sets that flag while retaining streams/pending response bytes.
Normal GOAWAY output and active-stream response completion must remain intact.
Bulk teardown instead retires all IDs and abandons intents; existing response
lookups then return StreamClosed before Session output ownership mutation.
Native producer/file resources and transport-ring bytes remain existing external
stream_closed_fn/native responsibilities for the next TCP slice.

Add Driver.is_drained(self: *const Self) bool and
Driver.reset_drained(self: *Self) error{BodyStateBusy}!void. Inspect initialized
slot state only: inactive body, no reservation/accepted binding/live body target,
callback_phase none. Do not require historical stream_id==0 and never dereference
Session/context/admission/capture data for this predicate (rollback can be unbound).
Reset preflights every slot before mutation; busy returns atomically unchanged.
On success reset request fields, preserving body.generation, slot owner/index and
driver Session/context/admission/capture associations. Expired body targets remain
null, never resurrect prior controls; never call bind again.

Caller preconditions remain explicit and outside slot-state proof: no enclosing
Session/native delivery borrow, drained native retirement/release gates, no live
response owner depending on reusable metadata and serialized Session reset/reuse.
An arbitrary supplied callback failing before its own cleanup may leave a driver
non-drained; never hide that or claim native release safe.

## Regression and compatibility evidence

Use actual encoded Session/registered driver/caller-buffer fixtures. Before
production edits, freeze/run meaningful existing-API regressions for retire-before-
notify reentry and callback-error cleanup if demonstrable; missing declarations
are declaration evidence only. NEVER edit a source while its compiler/runtime
command is running. Preserve all red sources/logs/actual identities; no bad stub,
fabricated native outcome, huge fake slice, injected completion or timer schedule.

Required coverage: two accepted streams with held data/blocked credit/Continue;
all IDs retired/first causes visible before first callback; no own teardown output;
once-only terminal and quota-after-cancel. Closure from real middleware/begin/
chunk/end/ordinary stream_closed_fn; metadata readable in both notification
callbacks; nested close; no cancel-after-end. Real driver cleanup followed by a
supplied event error still cleans siblings/protocol state and propagates first
error, with no replay. Mixed buffered/streaming and disabled closure. Fresh Response
attempts fail after close without writer/output-owner mutation. Fresh/queued DATA
unwind never advertises teardown credit or double-frees. Busy reset is atomic;
drained reset preserves generations/associations and stale controls remain expired
after actual Session/slot reuse.

Mandatory GOAWAY regression: real encoded request, actual bounded caller writer
pressure that blocks DATA but admits small control frames, pending buffered body,
malformed PING producing GOAWAY. Session is closed but stream stays active; actual
output-space progress then flush accepts exact pending body+END_STREAM once.
Paired explicit bulk close retires stream and emits no further pending output.
Do not fabricate OS outcomes or weaken the pressure/assertions to pass.

Freeze before final checks. Cover changed protocol/driver tests plus affected
approved H2 frames/HPACK/queue/refusal/width/server and H1/App regressions in Debug/
ReleaseSafe. Compile central graph Linux/macOS/Windows and eligible32 roots;
measure actual stored types/offsets/carves/profile totals on3OS (expect unchanged,
not assumed). CompileLog-only exit1 is measurement, not a test. Run fmt/conventions/
version/docs and independent identical-copy AST. Broad/repeated checks need changed
inputs or unresolved concerns. Preserve all errors, capacities, thresholds and
backend expectations. No layout growth/extra field is approved; explain any need
to Root before adoption. No root export/dependency change.

Runtime H2-server filter stays http2 server: (40/69), healthy App the eight exact
positive filters in Task3/4a (8/31). Full isolated native runtime and stopped/
socket/resource/timer/cancellation cases stay compile-only, never retried or
reconstructed. No native cancellation schedules/interleavings/races/crashes/leaks/
invalid-fd/kernel/registration/resource-exhaustion/injected-completion/panic probes,
new clients/live server, refs/pins/fetch/publication, commits/pushes or subagents.
You are not alone: never revert others or modify Root/other-agent/client paths.

All heavy copies/caches/binaries/IR stay /tmp; small snapshots/preimages/patches/
inventories/exact commands/raw results/input/binary/environment identities go to
.uwz-work/evidence/h2-streaming/native-terminal. Write full report to
.superpowers/sdd/h2_streaming_plan/task-4b-report.md, then return concise status/
tests/concerns. Include reconstructing Git patch and frozen review package. Use
original r2 modules/static libs/c22393-file override/Zig0.16 compiler -j2 and two
affinity CPUs; inherited exact tool paths remain. Root reviews before integration.
Graph query before new codebase search/source reads; supplied/located paths
readable directly. Refresh AST on independent identical copy; graph stays ignored.

## Root credit-state ruling: supersedes terminal-receive approximation

The developer's real GOAWAY-last-stream red exposes two facts: closed/no-active-
identities is not unique bulk teardown, and skipping reset_credit leaves obsolete
stream credit that later fails InvalidBodyCreditIdentity. Preserve the existing
seven-byte ordinary GOAWAY assertion (four pending padding plus three reclaimed
queued bytes), pending-response/reset behavior and open-session reset refunds.
Do not weaken that test to accept a wire-output omission.

Root withdraws the earlier closed/no-identities refund-disposition requirement.
Own one additional candidate path, src/http2/body_receive.zig. Proposed minimal
explicit disposition is default-false credit_abandoned: bool in existing optional
ReceiveState. No extra Session/TCP pointer or flag, no payload/window/capacity
change. It distinguishes explicit bulk credit abandonment from ordinary GOAWAY.

First create a separate declaration-only measurement copy, changing only this
field from the exact current red candidate. Measure actual size/alignment/offsets,
enabled/disabled Session/Bundle/carve/native profile totals on Linux/macOS/Windows
for native8 and eligible generic1/2/3/4/8 shapes. Preserve exact source delta and
raw compileLog exit1 classification. Report BEFORE adopting into the implementation;
Root will rule on any measured growth. Native8/default-disabled growth is not
preapproved; do not assume padding makes this free. Current red source/evidence
and original baseline remain immutable. No further broad checks until correction.

After Root's measurement ruling, explicit close_body_inputs sets credit_abandoned
before callbacks and abandons its credit intents. Deferred/current/queued teardown
reclamation frees storage without making new connection credit work. Ordinary
GOAWAY leaves the flag false and retains normal seven-byte refund behavior.
Retirement ALWAYS clears obsolete stream credit regardless of refund disposition.
Session/receive reset initializes the flag false; repeated bulk closure remains
idempotent. Preserve real reset/reuse and all output/metadata invariants above.
This is an architectural correction before independent review, not a completed
fix or test pass. No active native operation or stopped experiment is authorized.

Root reviewed credit-field-measurement.md, exact one-field delta and18 terminal
compileLog measurement records. Adoption approved: native8 ReceiveState remains
144 bytes, every native3OS slab/carve/type/offset total and default-disabled plan
unchanged. Enabled generic2 grows ReceiveState80->88, Bundle249720->249728 and
carve249712->249720, shifting subsequent Bundle fields8 bytes. This measured
opt-in metadata growth is approved; payload/window capacities and all disabled
generic plans stay unchanged. Generic1/3/4/8 measured sizes remain unchanged.
Keep exact existing seven-credit regression. Eligible32 declaration/storage
checks remain required; report any natural-alignment rounding for the same one
field explicitly, without claiming complete32/native support. No other growth or
field is approved. Continue correction with the same developer; freeze new source
and rerun affected checks, preserving all earlier red/prototype evidence.

Root accepts the reported eligible32 declaration rounding for this same field:
alignment4; enabled generic2/4/8 ReceiveState and Bundle/carve +4 bytes each,
generic1/3, Session and disabled shapes unchanged. No complete32/native claim.

Error-policy clarification after independent source review: preserve legacy
buffered request_fn error absorption when retirement/cleanup succeeds, including
handler-initiated bulk close. Original-error precedence applies when operation
and cleanup errors would otherwise both surface. No new buffered error API is
intended. Direct tests of both compound-error combinations remain reported gaps;
source proof and existing F2 regressions suffice for this component, without a
claim that those combinations or native release behavior were executed.
