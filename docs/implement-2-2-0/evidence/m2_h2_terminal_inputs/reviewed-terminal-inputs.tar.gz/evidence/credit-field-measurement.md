# Declaration-only credit marker measurement

Measured before adoption: `/tmp/uwz-task4b-credit-field-measure` is a regular-byte copy of the frozen GOAWAY-red candidate with exactly one source difference, the trailing default-false `credit_abandoned: bool` member in `ReceiveState`. The exact one-field delta and path hashes are `credit-field-measure-delta.patch` and `credit-field-measure-inventory.json`; no implementation file was changed. Three-target generic width, native layout, and profile/carve CompileLog source, commands, source/input/environment identities, raw logs and classifications are in `credit-{width,layout,offsets}-*-{before,after}.{json,log}` and `credit-measure-status.json`. All 18 invocations returned the expected compile-log-only exit 1 and their inputs remained unchanged. This is a measurement, not a passing test.

Across Linux, macOS and Windows, these generic-width results are identical, in bytes:

| Width | ReceiveState before → after | Enabled Bundle before → after | Enabled carve before → after | Disabled Bundle and carve |
|---|---:|---:|---:|---|
| 1 | 72 → 72 | 192680 → 192680 | 192672 → 192672 | unchanged |
| 2 | 80 → 88 | 249720 → 249728 | 249712 → 249720 | unchanged |
| 3 | 96 → 96 | 306776 → 306776 | 306760 → 306760 | unchanged |
| 4 | 104 → 104 | 363808 → 363808 | 363808 → 363808 | unchanged |
| 8 | 144 → 144 | 591984 → 591984 | 591984 → 591984 | unchanged |

Every ReceiveState alignment remains 8; marker offsets at widths 1, 2, 3, 4 and 8 are 70, 80, 90, 100 and 140 respectively. Existing ReceiveState fields and Session sizes/offsets remain unchanged. At width 2, the enabled Bundle receive field grows 8 bytes and every subsequent Bundle field moves 8 bytes; other widths' Bundle field offsets are unchanged. Disabled Bundles and carves are unchanged at each width. Native width-8 Session, enabled and disabled Bundles, Session storage plans, native TCP and upload types, and all measured native slab/profile totals and offsets are unchanged across all three OS targets. The visibility-only accounting override for the private profile function is separately recorded in `credit-field-accounting-override.json`; it is not part of the candidate or the one-field derivative.

The observed enabled width-2 growth is not yet approved. Root must rule before the declaration is adopted or any behavioral fix is applied. No native runtime, sockets or stopped cases were exercised.
