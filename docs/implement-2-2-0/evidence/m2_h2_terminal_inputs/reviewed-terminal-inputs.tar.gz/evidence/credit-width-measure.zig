const s = @import("test_support");
const std = @import("std");
fn layout(comptime name: []const u8, comptime T: type) void {
    @compileLog("type", name, @sizeOf(T), @alignOf(T));
    inline for (@typeInfo(T).@"struct".fields) |field| @compileLog("field", name, field.name, @offsetOf(T, field.name), @sizeOf(field.type), @alignOf(field.type));
}
fn measure(comptime width: usize) void {
    const S = s.http2_server.server_session(width);
    @compileLog("width", width);
    layout("Session", S);
    layout("ReceiveState", S.ReceiveState);
    layout("BundleDisabled", S.Bundle(.{}));
    layout("BundleEnabled", S.Bundle(.{ .stream_request_bodies = true }));
    @compileLog("carve", width, S.storage_bytes(.{}), S.storage_bytes(.{ .stream_request_bodies = true }));
}
comptime {
    @setEvalBranchQuota(1000000);
    measure(1);
    measure(2);
    measure(3);
    measure(4);
    measure(8);
}
