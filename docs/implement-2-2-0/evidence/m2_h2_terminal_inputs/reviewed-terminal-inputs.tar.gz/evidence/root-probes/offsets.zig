const s = @import("test_support");
comptime {
    @setEvalBranchQuota(100000);
    for (.{ s.config.ServerConfig{ .max_connections = 2, .max_route_params = 20, .stream_request_bodies = true }, s.config.ServerConfig{}, s.config.ServerConfig{ .stream_request_bodies = true }, s.config.ServerConfig{ .max_connections = 8, .stream_request_bodies = true, .max_request_line_size = 512, .max_header_size = 1024, .max_body_size = 256 } }, 0..) |cfg, i| {
        @compileLog("offsets", i, s.config.layout_offsets(cfg));
    }
}
